package com.nop.cartoonstudio

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.ui.Modifier
import androidx.lifecycle.ViewModelProvider

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val vm = ViewModelProvider(this)[EditorViewModel::class.java]
        setContent {
            CartoonTheme {
                Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
                    if (vm.boneEditorOpen) {
                        BoneEditorScreen(vm.skeleton) { vm.boneEditorOpen = false }
                    } else {
                        EditorScreen(vm)
                    }
                }
            }
        }
    }
}
