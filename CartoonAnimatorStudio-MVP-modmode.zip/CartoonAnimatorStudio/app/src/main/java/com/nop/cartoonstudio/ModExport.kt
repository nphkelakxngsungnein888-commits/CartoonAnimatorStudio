package com.nop.cartoonstudio

import android.content.ContentValues
import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.Rect
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.FileOutputStream
import java.io.IOException
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream

/**
 * โหมดม็อด Terraria: แปลงตัวละครในแอป -> แผ่นสไปรต์ (PNG) + โค้ด C# ของม็อด + manifest.json รวมเป็น ZIP
 * ทุกอย่างที่นี่ไม่แตะระบบเดิมของแอป: อ่านชิ้นส่วน/เฟรมที่ส่งเข้ามา แล้ววาดด้วย drawScene ตัวเดียวกับตอนส่งออกปกติ
 *
 * สถานะ: ยังไม่ได้ compile/ทดสอบ โค้ด C# ที่สร้างเขียนตามรูปแบบ tModLoader 1.4.x (ความจำ) ต้องตรวจกับเวอร์ชันที่ใช้จริง
 * ชื่อ ItemID/TileID/SpawnCondition ที่ให้เลือกจำกัดไว้เฉพาะชื่อที่มั่นใจว่ามี (ไม่เดาชื่ออื่น)
 */
enum class ModKind(val label: String) {
    MONSTER("มอนสเตอร์"),
    TOWN("NPC ชาวเมือง"),
    SWORD("อาวุธฟัน"),
    STAFF("อาวุธยิง + กระสุน"),
}

data class ModConfig(
    val kind: ModKind,
    val modName: String,
    val className: String,
    val displayName: String,
    val characterId: Int, // ตัวละครของมอน/NPC/อาวุธ
    val projectileCharacterId: Int, // ตัวละครของกระสุน (เฉพาะอาวุธยิง)
    val maxSide: Int, // ด้านยาวสุดของเฟรม/ภาพที่ส่งออก (px)
    val projMaxSide: Int,
    val faceRightInApp: Boolean, // ตัวละครในแอปหันขวา -> กลับภาพให้หันซ้าย (ค่าเริ่มต้นของเกมที่ผมจำได้ ต้องทดสอบ)
    val fps: Float,
    val idle: IntRange, // นับจาก 0
    val walk: IntRange,
    val life: Int,
    val damage: Int,
    val defense: Int,
    val knockback: Float,
    val value: Int,
    val ai: Int,
    val spawn: Int,
    val dropItem: Int,
    val dropMin: Int,
    val dropMax: Int,
    val names: List<String>,
    val dialogue: List<String>,
    val shop: List<Int>,
    val weaponFrame: Int, // นับจาก 0
    val rotateDeg: Int,
    val useTime: Int,
    val mana: Int,
    val shootSpeed: Float,
    val rarity: Int,
    val station: Int,
    val ingredient: Int,
    val ingredientCount: Int,
    val penetrate: Int,
    val lifetimeTicks: Int,
)

class ModFile(val path: String, val bytes: ByteArray)

class ModBuild(
    val files: List<ModFile>,
    val preview: Bitmap?,
    val notes: List<String>,
    val mainCode: String,
)

private class SheetInfo(val bitmap: Bitmap, val frameW: Int, val frameH: Int, val frameCount: Int)

object ModExport {
    /** ชื่อที่เลือกได้ (เฉพาะชื่อที่มั่นใจว่ามีใน ItemID/TileID/ItemRarityID/NPCID ของ tModLoader 1.4) */
    val ITEMS = listOf("Wood", "Torch", "Gel", "Rope", "WoodenArrow", "StoneBlock", "IronBar", "FallenStar", "LesserHealingPotion")
    val STATIONS = listOf("ไม่ต้องใช้", "WorkBenches", "Anvils", "Furnaces") // 0 = ไม่ใช้
    val RARITIES = listOf("White", "Blue", "Green", "Orange")
    val AI_NAMES = listOf("เดินไล่", "กระโดดแบบสไลม์", "บิน")
    val SPAWN_NAMES = listOf("พื้นผิว กลางคืน", "พื้นผิว กลางวัน")

    private const val RES = 512 // ความละเอียดตอนวาด/วัดขอบ (พิกเซล ต่อกรอบโลก 600 หน่วย)
    private const val ALPHA_MIN = 8
    private const val MAX_SHEET_H = 4096
    private const val NO_PIXELS = "ไม่พบภาพที่มองเห็นของตัวละครที่เลือก (เช็กว่าเลือกตัวละครถูก และไม่ได้ซ่อนไว้)"

    /** ตัดให้เหลือ A-Z a-z 0-9 ขึ้นต้นด้วยตัวอักษร (ใช้เป็นชื่อคลาส/ชื่อไฟล์ภาพ/namespace) */
    fun cleanId(raw: String, fallback: String): String {
        val sb = StringBuilder()
        for (c in raw) if (c in 'A'..'Z' || c in 'a'..'z' || c in '0'..'9') sb.append(c)
        var s = sb.toString()
        if (s.isEmpty() || s[0] in '0'..'9') s = fallback + s
        return s
    }

    private fun cs(s: String): String =
        s.replace("\\", "\\\\").replace("\"", "\\\"").replace("\n", " ").replace("\r", " ")

    // ---------- วาด/ตัด/ย่อภาพ ----------

    private fun renderFrame(parts: List<Part>, poses: Map<Int, Pose>, index: Int, flip: Boolean): Bitmap {
        val bmp = Bitmap.createBitmap(RES, RES, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bmp)
        val paint = Paint(Paint.FILTER_BITMAP_FLAG or Paint.ANTI_ALIAS_FLAG)
        val s = RES / Exporter.WORLD_WINDOW
        canvas.translate(RES / 2f, RES / 2f)
        canvas.scale(if (flip) -s else s, s) // กล้องเดียวกับ Exporter.buildSheet (กลับซ้ายขวารอบกึ่งกลางเมื่อ flip)
        drawScene(canvas, parts, { id -> poses[id] ?: Pose() }, paint, index.toFloat())
        return bmp
    }

    /** กรอบพิกเซลที่ไม่โปร่งใส [left, top, right, bottom] (รวมขอบ) หรือ null ถ้าว่างเปล่า */
    private fun bounds(bmp: Bitmap, buf: IntArray): IntArray? {
        val w = bmp.width
        val h = bmp.height
        bmp.getPixels(buf, 0, w, 0, 0, w, h)
        var l = w
        var t = h
        var r = -1
        var b = -1
        for (y in 0 until h) {
            val row = y * w
            for (x in 0 until w) {
                if ((buf[row + x] ushr 24) > ALPHA_MIN) {
                    if (x < l) l = x
                    if (x > r) r = x
                    if (y < t) t = y
                    if (y > b) b = y
                }
            }
        }
        return if (r < 0) null else intArrayOf(l, t, r, b)
    }

    private fun trim(bmp: Bitmap): Bitmap {
        val b = bounds(bmp, IntArray(bmp.width * bmp.height)) ?: throw IOException(NO_PIXELS)
        return Bitmap.createBitmap(bmp, b[0], b[1], b[2] - b[0] + 1, b[3] - b[1] + 1)
    }

    private fun scaleDown(bmp: Bitmap, maxSide: Int): Bitmap {
        val k = minOf(1f, maxSide.toFloat() / maxOf(bmp.width, bmp.height))
        if (k >= 1f) return bmp
        val w = Math.round(bmp.width * k).coerceAtLeast(1)
        val h = Math.round(bmp.height * k).coerceAtLeast(1)
        return Bitmap.createScaledBitmap(bmp, w, h, true)
    }

    /**
     * แผ่นสไปรต์แนวตั้ง (เฟรมเรียงบนลงล่าง ขนาดเท่ากันทุกเฟรม): ตัดขอบว่างด้วยกรอบรวมของ "ทุกเฟรม" (ไม่ตัดรายเฟรม
     * เพราะเกมหารความสูงรูปด้วยจำนวนเฟรม) แล้วย่อให้ด้านยาวสุดไม่เกิน maxSide เท้า/ขอบล่างของกรอบรวมคือขอบล่างเฟรม
     */
    private fun buildSheet(parts: List<Part>, frames: List<Map<Int, Pose>>, maxSide: Int, flip: Boolean): SheetInfo {
        val buf = IntArray(RES * RES)
        var l = RES
        var t = RES
        var r = -1
        var b = -1
        for (i in frames.indices) { // รอบแรก: หากรอบรวม (วาดทีละเฟรมแล้วทิ้ง ไม่เก็บทุกเฟรมในหน่วยความจำ)
            val f = renderFrame(parts, frames[i], i, flip)
            try {
                bounds(f, buf)?.let {
                    if (it[0] < l) l = it[0]
                    if (it[1] < t) t = it[1]
                    if (it[2] > r) r = it[2]
                    if (it[3] > b) b = it[3]
                }
            } finally { f.recycle() }
        }
        if (r < 0) throw IOException(NO_PIXELS)
        val bw = r - l + 1
        val bh = b - t + 1
        val k = minOf(1f, maxSide.toFloat() / maxOf(bw, bh))
        val fw = Math.round(bw * k).coerceAtLeast(1)
        val fh = Math.round(bh * k).coerceAtLeast(1)
        if (fh.toLong() * frames.size > MAX_SHEET_H) {
            throw IOException("แผ่นสไปรต์สูงเกิน $MAX_SHEET_H px (${frames.size} เฟรม × $fh px) ลดขนาดเฟรมหรือจำนวนเฟรม")
        }
        val sheet = Bitmap.createBitmap(fw, fh * frames.size, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(sheet)
        val paint = Paint(Paint.FILTER_BITMAP_FLAG or Paint.ANTI_ALIAS_FLAG)
        val src = Rect(l, t, r + 1, b + 1)
        for (i in frames.indices) { // รอบสอง: วาดซ้ำแล้วตัด/ย่อลงช่องของเฟรมนั้น
            val f = renderFrame(parts, frames[i], i, flip)
            try {
                canvas.drawBitmap(f, src, Rect(0, i * fh, fw, (i + 1) * fh), paint)
            } finally { f.recycle() }
        }
        return SheetInfo(sheet, fw, fh, frames.size)
    }

    /** ภาพเดียว (อาวุธ): วาดเฟรมที่เลือก -> ตัดขอบ -> หมุน -> ตัดขอบอีกรอบ -> ย่อ */
    private fun buildSingle(parts: List<Part>, frames: List<Map<Int, Pose>>, frame: Int, rotateDeg: Int, maxSide: Int): Bitmap {
        val idx = frame.coerceIn(0, frames.size - 1)
        val f = renderFrame(parts, frames[idx], idx, false)
        var cur = trim(f)
        if (rotateDeg % 360 != 0) {
            val m = Matrix()
            m.postRotate(rotateDeg.toFloat()) // ตามเข็มนาฬิกา
            cur = trim(Bitmap.createBitmap(cur, 0, 0, cur.width, cur.height, m, true))
        }
        return scaleDown(cur, maxSide)
    }

    private fun png(bmp: Bitmap): ByteArray {
        val o = ByteArrayOutputStream()
        if (!bmp.compress(Bitmap.CompressFormat.PNG, 100, o)) throw IOException("เข้ารหัส PNG ไม่สำเร็จ")
        return o.toByteArray()
    }

    // ---------- สร้างทุกไฟล์ ----------

    /** ควรเรียกใน Dispatchers.Default (หนัก) ส่ง parts/frames ที่คัดลอกมาจากหน้าจอแล้ว */
    fun build(allParts: List<Part>, frames: List<Map<Int, Pose>>, cfg: ModConfig): ModBuild {
        if (frames.isEmpty()) throw IOException("ยังไม่มีเฟรม")
        val mod = cleanId(cfg.modName, "Mod")
        val cls = cleanId(cfg.className, "Thing")
        val c = cfg.copy(modName = mod, className = cls)
        val files = ArrayList<ModFile>()
        val notes = ArrayList<String>()
        val partsOf = { cid: Int ->
            allParts.filter { it.characterId == cid }.also { if (it.isEmpty()) throw IOException("เลือกตัวละครก่อน (ยังไม่มีชิ้นส่วนของตัวละครที่เลือก)") }
        }
        var preview: Bitmap? = null
        var mainCode = ""

        when (c.kind) {
            ModKind.MONSTER, ModKind.TOWN -> {
                val sh = buildSheet(partsOf(c.characterId), frames, c.maxSide, c.faceRightInApp)
                preview = sh.bitmap
                if (c.kind == ModKind.MONSTER) {
                    if (c.idle.last >= sh.frameCount || c.walk.last >= sh.frameCount) {
                        throw IOException("ช่วงเฟรมยืน/เดินเกินจำนวนเฟรมที่มี (${sh.frameCount} เฟรม)")
                    }
                    mainCode = genMonster(c, sh)
                    files.add(ModFile("NPCs/$cls.png", png(sh.bitmap)))
                    files.add(ModFile("NPCs/$cls.cs", mainCode.toByteArray(Charsets.UTF_8)))
                } else {
                    if (sh.frameCount != 25) notes.add("NPC ชาวเมืองตามตัวอย่างทางการใช้ 25 เฟรม แต่งานนี้มี ${sh.frameCount} เฟรม ท่าและลำดับเฟรมพิเศษอาจไม่ตรง [ตรวจ]")
                    val side = minOf(sh.frameW, (sh.frameH * 0.4f).toInt()).coerceAtLeast(1)
                    val head = Bitmap.createBitmap(sh.bitmap, (sh.frameW - side) / 2, 0, side, side)
                    val icon = Bitmap.createScaledBitmap(head, 28, 28, true)
                    notes.add("ไอคอนหัว (_Head.png) ครอปจากส่วนบนของเฟรมแรกให้โดยประมาณ ขนาด 28 px ควรตรวจและเปลี่ยนเองถ้าไม่ตรงหัว [ตรวจ]")
                    mainCode = genTown(c, sh)
                    files.add(ModFile("NPCs/Town/$cls.png", png(sh.bitmap)))
                    files.add(ModFile("NPCs/Town/${cls}_Head.png", png(icon)))
                    files.add(ModFile("NPCs/Town/$cls.cs", mainCode.toByteArray(Charsets.UTF_8)))
                }
            }
            ModKind.SWORD -> {
                val img = buildSingle(partsOf(c.characterId), frames, c.weaponFrame, c.rotateDeg, c.maxSide)
                preview = img
                mainCode = genSword(c, img.width, img.height)
                files.add(ModFile("Items/Weapons/$cls.png", png(img)))
                files.add(ModFile("Items/Weapons/$cls.cs", mainCode.toByteArray(Charsets.UTF_8)))
            }
            ModKind.STAFF -> {
                val img = buildSingle(partsOf(c.characterId), frames, c.weaponFrame, c.rotateDeg, c.maxSide)
                val proj = cleanId(cls + "Bolt", "Bolt")
                val sh = buildSheet(partsOf(c.projectileCharacterId), frames, c.projMaxSide, false)
                preview = img
                mainCode = genStaff(c, img.width, img.height, proj)
                files.add(ModFile("Items/Weapons/$cls.png", png(img)))
                files.add(ModFile("Items/Weapons/$cls.cs", mainCode.toByteArray(Charsets.UTF_8)))
                files.add(ModFile("Projectiles/$proj.png", png(sh.bitmap)))
                files.add(ModFile("Projectiles/$proj.cs", genProjectile(c, sh, proj).toByteArray(Charsets.UTF_8)))
            }
        }
        files.add(ModFile("manifest.json", manifest(c, notes).toString(2).toByteArray(Charsets.UTF_8)))
        files.add(ModFile("README.txt", readme(c).toByteArray(Charsets.UTF_8)))
        return ModBuild(files, preview, notes, mainCode)
    }

    // ---------- ZIP ----------

    private fun zipBytes(files: List<ModFile>): ByteArray {
        val o = ByteArrayOutputStream()
        ZipOutputStream(o).use { z ->
            for (f in files) {
                z.putNextEntry(ZipEntry(f.path))
                z.write(f.bytes)
                z.closeEntry()
            }
        }
        return o.toByteArray()
    }

    /** บันทึก ZIP ลงโฟลเดอร์ Download/CartoonAnimatorStudio คืนตำแหน่งที่บันทึก ควรเรียกใน Dispatchers.IO */
    fun saveZip(context: Context, files: List<ModFile>, displayName: String): String {
        val data = zipBytes(files)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            val values = ContentValues().apply {
                put(MediaStore.Downloads.DISPLAY_NAME, "$displayName.zip")
                put(MediaStore.Downloads.MIME_TYPE, "application/zip")
                put(MediaStore.Downloads.RELATIVE_PATH, "Download/CartoonAnimatorStudio")
                put(MediaStore.Downloads.IS_PENDING, 1)
            }
            val resolver = context.contentResolver
            val uri = resolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values)
                ?: throw IOException("สร้างไฟล์ในโฟลเดอร์ดาวน์โหลดไม่ได้")
            try {
                val out = resolver.openOutputStream(uri) ?: throw IOException("เปิดไฟล์เพื่อเขียนไม่ได้")
                out.use { it.write(data) }
                values.clear()
                values.put(MediaStore.Downloads.IS_PENDING, 0)
                resolver.update(uri, values, null, null)
            } catch (e: Exception) {
                resolver.delete(uri, null, null)
                throw e
            }
            return "Download/CartoonAnimatorStudio/$displayName.zip"
        } else {
            val dir = File(context.getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS), "CartoonAnimatorStudio")
            if (!dir.exists() && !dir.mkdirs()) throw IOException("สร้างโฟลเดอร์ไม่ได้")
            val f = File(dir, "$displayName.zip")
            FileOutputStream(f).use { it.write(data) }
            return f.absolutePath
        }
    }

    // ---------- manifest / README ----------

    private fun manifest(c: ModConfig, notes: List<String>): JSONObject {
        val o = JSONObject()
        o.put("schema", 1)
        o.put("generator", "Cartoon Animator Studio - Terraria mod mode")
        o.put("target", "tmodloader-1.4.x (ต้องยืนยันเวอร์ชันจริงก่อนใช้)")
        o.put("kind", c.kind.name)
        o.put("modName", c.modName)
        o.put("class", c.className)
        o.put("displayName", c.displayName)
        o.put("fps", c.fps.toDouble())
        o.put("faceRightInApp", c.faceRightInApp)
        o.put("life", c.life)
        o.put("damage", c.damage)
        o.put("defense", c.defense)
        o.put("knockback", c.knockback.toDouble())
        o.put("useTime", c.useTime)
        o.put("mana", c.mana)
        o.put("rotateDeg", c.rotateDeg)
        o.put("notes", JSONArray(notes))
        return o
    }

    private fun readme(c: ModConfig): String = """
ไฟล์ชุดนี้สร้างโดยโหมดม็อด Terraria ของ Cartoon Animator Studio
ชนิด: ${c.kind.label}   ชื่อ: ${c.className}

วิธีใช้
1. แตก ZIP แล้วนำโฟลเดอร์ NPCs / Items / Projectiles (เฉพาะที่มี) ไปไว้ในโฟลเดอร์ของม็อดชื่อ ${c.modName}
   (โครงโฟลเดอร์ต้องตรงกับ namespace: เกมหาไฟล์ภาพจากชื่อ namespace + ชื่อคลาส)
2. ไฟล์ .png กับ .cs ต้องชื่อเดียวกัน (ชื่อคลาส)
3. build ม็อดตามวิธีที่ใช้อยู่ แล้วทดสอบในเกม

ข้อควรรู้
- โค้ด C# ยังไม่ได้ compile และยังไม่ได้ทดสอบในเกม เขียนตามรูปแบบ tModLoader 1.4.x
  ถ้าชื่อ API ไม่ตรงกับเวอร์ชันที่ใช้ ให้แก้ตามของจริง
- ตัวเลขกรอบชน ความเร็วอนิเมชัน สเตตัส ปรับแก้ได้ที่ค่าบนสุดของคลาสและใน SetDefaults
- ภาพต้นฉบับ NPC/มอนสเตอร์: เกมวาดภาพหันซ้ายเป็นค่าเริ่มต้น (ความจำ ต้องทดสอบ) ถ้าหันผิดด้านให้สลับตัวเลือกกลับภาพแล้วส่งออกใหม่
""".trimStart()

    // ---------- สร้างโค้ด C# ----------

    private const val HEADER = "// สร้างโดย Cartoon Animator Studio (โหมดม็อด Terraria) ยังไม่ได้ compile ยังไม่ได้ทดสอบ รูปแบบ tModLoader 1.4.x"

    private fun ticks(fps: Float): Int = Math.round(60f / fps.coerceIn(FPS_MIN, FPS_MAX)).coerceAtLeast(1)

    private fun itemId(i: Int): String = "ItemID." + ITEMS[i.coerceIn(0, ITEMS.size - 1)]

    private fun recipeBlock(c: ModConfig): String {
        val sb = StringBuilder()
        sb.append("            CreateRecipe()\n")
        sb.append("                .AddIngredient(${itemId(c.ingredient)}, ${c.ingredientCount})\n")
        if (c.station in 1 until STATIONS.size) sb.append("                .AddTile(TileID.${STATIONS[c.station]})\n")
        sb.append("                .Register();")
        return sb.toString()
    }

    private fun rarityId(c: ModConfig) = "ItemRarityID." + RARITIES[c.rarity.coerceIn(0, RARITIES.size - 1)]

    private fun genMonster(c: ModConfig, sh: SheetInfo): String {
        val hitW = (sh.frameW * 0.7f).toInt().coerceAtLeast(8)
        val hitH = (sh.frameH * 0.9f).toInt().coerceAtLeast(8)
        val aiStyle = when (c.ai) { 1 -> "1"; 2 -> "2"; else -> "3" }
        val aiType = when (c.ai) { 1 -> "NPCID.BlueSlime"; 2 -> "NPCID.DemonEye"; else -> "NPCID.Zombie" }
        val spawn = if (c.spawn == 1) "SpawnCondition.OverworldDay" else "SpawnCondition.OverworldNightMonster"
        return """
$HEADER
// ภาพ: ${c.className}.png (แผ่นสไปรต์ ${sh.frameCount} เฟรม ขนาดเฟรม ${sh.frameW}x${sh.frameH} px เรียงบนลงล่าง)
using Terraria;
using Terraria.GameContent.ItemDropRules;
using Terraria.ID;
using Terraria.ModLoader;

namespace ${c.modName}.NPCs
{
    public class ${c.className} : ModNPC
    {
        // ช่วงเฟรมในแผ่นสไปรต์ (นับจาก 0 รวมต้นและปลาย)
        private const int IdleStart = ${c.idle.first}, IdleEnd = ${c.idle.last};
        private const int WalkStart = ${c.walk.first}, WalkEnd = ${c.walk.last};
        // เกมอัปเดต 60 ครั้ง/วินาที: tick ต่อเฟรม = 60 / fps (${fmtFps(c.fps)} fps)
        private const int TicksPerFrame = ${ticks(c.fps)};

        public override void SetStaticDefaults()
        {
            Main.npcFrameCount[Type] = ${sh.frameCount};
        }

        public override void SetDefaults()
        {
            NPC.width = $hitW;      // กรอบชน (ปรับเองได้ ไม่จำเป็นต้องเท่าขนาดภาพ)
            NPC.height = $hitH;
            NPC.damage = ${c.damage};
            NPC.defense = ${c.defense};
            NPC.lifeMax = ${c.life};
            NPC.knockBackResist = ${c.knockback}f;
            NPC.value = ${c.value}f;   // เหรียญที่ดรอป (หน่วยทองแดง)
            NPC.HitSound = SoundID.NPCHit1;
            NPC.DeathSound = SoundID.NPCDeath1;
            NPC.aiStyle = $aiStyle;
            AIType = $aiType;
        }

        public override void FindFrame(int frameHeight)
        {
            bool moving = System.Math.Abs(NPC.velocity.X) > 0.1f;
            int start = moving ? WalkStart : IdleStart;
            int end = moving ? WalkEnd : IdleEnd;

            int current = NPC.frame.Y / frameHeight;
            if (current < start || current > end) current = start;

            NPC.frameCounter += 1;
            if (NPC.frameCounter >= TicksPerFrame)
            {
                NPC.frameCounter = 0;
                current = current >= end ? start : current + 1;
            }
            NPC.frame.Y = current * frameHeight;
        }

        public override float SpawnChance(NPCSpawnInfo spawnInfo)
        {
            return $spawn.Chance * 0.5f;
        }

        public override void ModifyNPCLoot(NPCLoot npcLoot)
        {
            npcLoot.Add(ItemDropRule.Common(${itemId(c.dropItem)}, 1, ${c.dropMin}, ${c.dropMax}));
        }
    }
}
""".trimStart()
    }

    private fun genTown(c: ModConfig, sh: SheetInfo): String {
        val hitW = (sh.frameW * 0.45f).toInt().coerceAtLeast(8)
        val hitH = (sh.frameH * 0.9f).toInt().coerceAtLeast(8)
        val names = (if (c.names.isEmpty()) listOf("Villager") else c.names).joinToString(", ") { "\"" + cs(it) + "\"" }
        val lines = if (c.dialogue.isEmpty()) listOf("Hello.") else c.dialogue
        val cases = StringBuilder()
        lines.forEachIndexed { i, s ->
            if (i < lines.size - 1) cases.append("                case $i: return \"${cs(s)}\";\n")
            else cases.append("                default: return \"${cs(s)}\";\n")
        }
        val shop = StringBuilder()
        for (i in c.shop) shop.append("                .Add(${itemId(i)})\n")
        return """
$HEADER
// ส่วนนี้ผูกกับเวอร์ชัน tModLoader มากที่สุด จุดที่เสี่ยงผิดเวอร์ชันมีเครื่องหมาย [ตรวจ]
// ภาพ: ${c.className}.png (${sh.frameCount} เฟรม ${sh.frameW}x${sh.frameH} px) และ ${c.className}_Head.png (ไอคอนหัว)
using System.Collections.Generic;
using Terraria;
using Terraria.ID;
using Terraria.ModLoader;

namespace ${c.modName}.NPCs.Town
{
    [AutoloadHead]
    public class ${c.className} : ModNPC
    {
        public const string ShopName = "Shop";

        public override void SetStaticDefaults()
        {
            Main.npcFrameCount[Type] = 25;                  // [ตรวจ] จำนวนเฟรมตามตัวอย่างทางการ (แผ่นของนพมี ${sh.frameCount})
            NPCID.Sets.ExtraFramesCount[Type] = 9;          // [ตรวจ]
            NPCID.Sets.AttackFrameCount[Type] = 4;          // [ตรวจ]
            NPCID.Sets.DangerDetectRange[Type] = 700;
            NPCID.Sets.AttackType[Type] = 0;
            NPCID.Sets.AttackTime[Type] = 90;
            NPCID.Sets.AttackAverageChance[Type] = 30;
        }

        public override void SetDefaults()
        {
            NPC.townNPC = true;
            NPC.friendly = true;
            NPC.width = $hitW;
            NPC.height = $hitH;
            NPC.aiStyle = 7;
            NPC.damage = ${c.damage};
            NPC.defense = ${c.defense};
            NPC.lifeMax = ${c.life};
            NPC.HitSound = SoundID.NPCHit1;
            NPC.DeathSound = SoundID.NPCDeath1;
            NPC.knockBackResist = 0.5f;
            AnimationType = NPCID.Guide;
        }

        public override bool CanTownNPCSpawn(int numTownNPCs)   // [ตรวจ] รูปแบบพารามิเตอร์ต่างกันตามเวอร์ชัน
        {
            return true;
        }

        public override List<string> SetNPCNameList()
        {
            return new List<string> { $names };
        }

        public override string GetChat()
        {
            switch (Main.rand.Next(${lines.size}))
            {
$cases            }
        }

        public override void SetChatButtons(ref string button, ref string button2)
        {
            button = "Shop";
        }

        public override void OnChatButtonClicked(bool firstButton, ref string shop)
        {
            if (firstButton) shop = ShopName;               // [ตรวจ]
        }

        public override void AddShops()                      // [ตรวจ] เวอร์ชันเก่ากว่า 1.4.4 ใช้ SetupShop แทน
        {
            new NPCShop(Type, ShopName)
$shop                .Register();
        }
    }
}
""".trimStart()
    }

    private fun genSword(c: ModConfig, w: Int, h: Int): String = """
$HEADER
// ภาพ: ${c.className}.png (ภาพเดียว ${w}x${h} px หมุนมา ${c.rotateDeg} องศา ปลายดาบควรชี้ขึ้นขวา ด้ามอยู่ล่างซ้าย)
using Terraria;
using Terraria.ID;
using Terraria.ModLoader;

namespace ${c.modName}.Items.Weapons
{
    public class ${c.className} : ModItem
    {
        public override void SetDefaults()
        {
            Item.width = $w;
            Item.height = $h;
            Item.damage = ${c.damage};
            Item.DamageType = DamageClass.Melee;
            Item.useTime = ${c.useTime};
            Item.useAnimation = ${c.useTime};
            Item.useStyle = ItemUseStyleID.Swing;
            Item.knockBack = ${c.knockback}f;
            Item.value = Item.buyPrice(silver: 50);
            Item.rare = ${rarityId(c)};
            Item.UseSound = SoundID.Item1;
            Item.autoReuse = true;
        }

        public override void AddRecipes()
        {
${recipeBlock(c)}
        }
    }
}
""".trimStart()

    private fun genStaff(c: ModConfig, w: Int, h: Int, proj: String): String = """
$HEADER
// ภาพ: ${c.className}.png (ภาพเดียว ${w}x${h} px) กระสุนอยู่ในไฟล์ $proj.cs
using Terraria;
using Terraria.ID;
using Terraria.ModLoader;
using ${c.modName}.Projectiles;

namespace ${c.modName}.Items.Weapons
{
    public class ${c.className} : ModItem
    {
        public override void SetDefaults()
        {
            Item.width = $w;
            Item.height = $h;
            Item.damage = ${c.damage};
            Item.DamageType = DamageClass.Magic;
            Item.mana = ${c.mana};
            Item.useTime = ${c.useTime};
            Item.useAnimation = ${c.useTime};
            Item.useStyle = ItemUseStyleID.Shoot;
            Item.noMelee = true;
            Item.knockBack = ${c.knockback}f;
            Item.value = Item.buyPrice(silver: 80);
            Item.rare = ${rarityId(c)};
            Item.UseSound = SoundID.Item43;
            Item.autoReuse = true;
            Item.shoot = ModContent.ProjectileType<$proj>();
            Item.shootSpeed = ${c.shootSpeed}f;
        }

        public override void AddRecipes()
        {
${recipeBlock(c)}
        }
    }
}
""".trimStart()

    private fun genProjectile(c: ModConfig, sh: SheetInfo, proj: String): String {
        val hit = minOf(sh.frameW, sh.frameH).coerceAtLeast(8)
        return """
$HEADER
// ภาพ: $proj.png (แผ่นสไปรต์ ${sh.frameCount} เฟรม ${sh.frameW}x${sh.frameH} px ภาพต้องหันไปทางขวา เพราะโค้ดหมุนตามทิศที่ยิง)
using Terraria;
using Terraria.ModLoader;

namespace ${c.modName}.Projectiles
{
    public class $proj : ModProjectile
    {
        private const int TicksPerFrame = ${ticks(c.fps)};

        public override void SetStaticDefaults()
        {
            Main.projFrames[Type] = ${sh.frameCount};
        }

        public override void SetDefaults()
        {
            Projectile.width = $hit;
            Projectile.height = $hit;
            Projectile.friendly = true;
            Projectile.DamageType = DamageClass.Magic;
            Projectile.penetrate = ${c.penetrate};
            Projectile.timeLeft = ${c.lifetimeTicks};
            Projectile.tileCollide = true;
            Projectile.ignoreWater = true;
        }

        public override void AI()
        {
            Projectile.rotation = Projectile.velocity.ToRotation();

            Projectile.frameCounter++;
            if (Projectile.frameCounter >= TicksPerFrame)
            {
                Projectile.frameCounter = 0;
                Projectile.frame = (Projectile.frame + 1) % Main.projFrames[Type];
            }
        }
    }
}
""".trimStart()
    }
}
