package com.nop.cartoonstudio

import android.graphics.Bitmap
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/**
 * โหมดม็อด Terraria (หน้าจอแยกจากโหมดแอนิเมต สลับด้วยปุ่มในเมนูตั้งค่า / ปุ่มกลับ)
 * ใช้ตัวละคร/เฟรมจากงานที่เปิดอยู่ ไม่แก้ข้อมูลงานเลย (อ่านอย่างเดียว)
 */
@Composable
fun ModModeScreen(vm: EditorViewModel, onClose: () -> Unit) {
    BackHandler(onBack = onClose)
    val context = LocalContext.current
    val scope = rememberCoroutineScope()

    // ----- สถานะฟอร์ม (rememberSaveable: หมุนจอแล้วไม่หาย) -----
    var kindIdx by rememberSaveable { mutableIntStateOf(0) }
    var modName by rememberSaveable { mutableStateOf("MyMod") }
    var className by rememberSaveable { mutableStateOf("MyThing") }
    var displayName by rememberSaveable { mutableStateOf("My Thing") }
    var charId by rememberSaveable { mutableIntStateOf(0) }
    var projCharId by rememberSaveable { mutableIntStateOf(0) }
    var sizeIdx by rememberSaveable { mutableIntStateOf(2) }
    var projSizeIdx by rememberSaveable { mutableIntStateOf(0) }
    var faceRight by rememberSaveable { mutableStateOf(true) }
    var idleS by rememberSaveable { mutableStateOf("1") }
    var idleE by rememberSaveable { mutableStateOf("1") }
    var walkS by rememberSaveable { mutableStateOf("1") }
    var walkE by rememberSaveable { mutableStateOf("1") }
    var life by rememberSaveable { mutableStateOf("60") }
    var damage by rememberSaveable { mutableStateOf("20") }
    var defense by rememberSaveable { mutableStateOf("4") }
    var kbIdx by rememberSaveable { mutableIntStateOf(1) }
    var wkbIdx by rememberSaveable { mutableIntStateOf(2) }
    var value by rememberSaveable { mutableStateOf("60") }
    var aiIdx by rememberSaveable { mutableIntStateOf(0) }
    var spawnIdx by rememberSaveable { mutableIntStateOf(0) }
    var dropIdx by rememberSaveable { mutableIntStateOf(2) }
    var dropMin by rememberSaveable { mutableStateOf("1") }
    var dropMax by rememberSaveable { mutableStateOf("3") }
    var names by rememberSaveable { mutableStateOf("Nop, Mali") }
    var dialogue by rememberSaveable { mutableStateOf("Hello, traveler. | Need something from the shop?") }
    var shopMask by rememberSaveable { mutableStateOf("1") } // รายการ index ของสินค้า คั่นด้วย ,
    var weaponFrame by rememberSaveable { mutableStateOf("1") }
    var rotIdx by rememberSaveable { mutableIntStateOf(0) }
    var useTime by rememberSaveable { mutableStateOf("20") }
    var mana by rememberSaveable { mutableStateOf("8") }
    var speed by rememberSaveable { mutableStateOf("10") }
    var rarityIdx by rememberSaveable { mutableIntStateOf(1) }
    var stationIdx by rememberSaveable { mutableIntStateOf(1) }
    var ingIdx by rememberSaveable { mutableIntStateOf(0) }
    var ingCount by rememberSaveable { mutableStateOf("20") }
    var penetrate by rememberSaveable { mutableStateOf("1") }
    var lifetime by rememberSaveable { mutableStateOf("120") }

    var error by remember { mutableStateOf<String?>(null) }
    var status by remember { mutableStateOf<String?>(null) }
    var busy by remember { mutableStateOf(false) }
    var result by remember { mutableStateOf<ModBuild?>(null) }
    var showCode by remember { mutableStateOf(false) }

    val kind = ModKind.values()[kindIdx]
    val characters = vm.project.characters()
    // ตัวละครที่เลือก: ถ้ายังไม่ได้เลือก/ถูกลบไปแล้ว ใช้ตัวแรกในงาน
    val effChar = characters.firstOrNull { it.first == charId }?.first ?: characters.firstOrNull()?.first ?: 0
    val effProj = characters.firstOrNull { it.first == projCharId }?.first ?: characters.getOrNull(1)?.first ?: effChar
    val sizes = listOf(64, 96, 128, 192)
    val projSizes = listOf(16, 24, 32, 48)
    val rotations = listOf(0, 45, 90, 135, 180, -45, -90)
    val knockbacks = listOf(0f, 0.5f, 1f)
    val weaponKnockbacks = listOf(1f, 3f, 5f, 7f)
    val hasPath = vm.project.pathOf(effChar) != null

    fun ints(s: String): Int? = s.trim().toIntOrNull()

    /** สร้าง ModConfig จากฟอร์ม หรือคืนข้อความผิดพลาด */
    fun readConfig(): Pair<ModConfig?, String?> {
        if (characters.isEmpty()) return null to "ยังไม่มีตัวละครในงาน (ไปโหมดแอนิเมต โหลดหรือสร้างตัวละครก่อน)"
        val frameN = vm.project.frameCount
        fun num(label: String, s: String, lo: Int, hi: Int): Int? = ints(s)?.takeIf { it in lo..hi }
        val l = num("เลือด", life, 1, 1_000_000) ?: return null to "เลือดต้องเป็นเลข 1 ขึ้นไป"
        val d = num("พลังโจมตี", damage, 0, 100_000) ?: return null to "พลังโจมตีต้องเป็นเลข 0 ขึ้นไป"
        val df = num("เกราะ", defense, 0, 100_000) ?: return null to "เกราะต้องเป็นเลข 0 ขึ้นไป"
        val v = num("เหรียญ", value, 0, 100_000_000) ?: return null to "เหรียญที่ดรอปต้องเป็นเลข 0 ขึ้นไป"
        val ut = num("ความเร็วใช้", useTime, 1, 1000) ?: return null to "ความเร็วใช้ต้องอยู่ 1–1000"
        val mn = num("มานา", mana, 0, 1000) ?: return null to "มานาต้องอยู่ 0–1000"
        val sp = num("ความเร็วกระสุน", speed, 1, 100) ?: return null to "ความเร็วกระสุนต้องอยู่ 1–100"
        val ic = num("จำนวนวัตถุดิบ", ingCount, 1, 9999) ?: return null to "จำนวนวัตถุดิบต้องอยู่ 1–9999"
        val pn = num("ทะลุ", penetrate, 1, 100) ?: return null to "จำนวนทะลุต้องอยู่ 1–100"
        val lt = num("อายุกระสุน", lifetime, 1, 100_000) ?: return null to "อายุกระสุนต้องเป็นเลข 1 ขึ้นไป"
        val dmin = num("ดรอปต่ำสุด", dropMin, 1, 9999) ?: return null to "ดรอปต่ำสุดต้องอยู่ 1–9999"
        val dmax = num("ดรอปสูงสุด", dropMax, 1, 9999) ?: return null to "ดรอปสูงสุดต้องอยู่ 1–9999"
        if (dmax < dmin) return null to "ดรอปสูงสุดต้องไม่น้อยกว่าต่ำสุด"
        val wf = num("เฟรมอาวุธ", weaponFrame, 1, frameN) ?: return null to "เฟรมที่ใช้เป็นภาพอาวุธต้องอยู่ 1–$frameN"

        fun range(a: String, b: String, name: String): Pair<IntRange?, String?> {
            val s = num(name, a, 1, frameN)
            val e = num(name, b, 1, frameN)
            if (s == null || e == null) return null to "ช่วงเฟรม$name ต้องอยู่ 1–$frameN"
            if (e < s) return null to "ช่วงเฟรม$name: เฟรมจบต้องไม่น้อยกว่าเฟรมเริ่ม"
            return (s - 1)..(e - 1) to null
        }
        val (idle, idleErr) = range(idleS, idleE, "ยืน")
        val (walk, walkErr) = range(walkS, walkE, "เดิน")
        if (kind == ModKind.MONSTER) {
            if (idle == null) return null to idleErr
            if (walk == null) return null to walkErr
        }
        if (kind == ModKind.STAFF && effProj == effChar && characters.size < 2) {
            return null to "อาวุธยิงต้องมีตัวละคร 2 ตัวในงาน: ตัวอาวุธ กับ ตัวกระสุน"
        }
        val shop = shopMask.split(",").mapNotNull { it.trim().toIntOrNull() }.filter { it in ModExport.ITEMS.indices }.distinct()
        val cfg = ModConfig(
            kind = kind,
            modName = modName,
            className = className,
            displayName = displayName,
            characterId = effChar,
            projectileCharacterId = effProj,
            maxSide = sizes[sizeIdx],
            projMaxSide = projSizes[projSizeIdx],
            faceRightInApp = faceRight,
            fps = vm.fps,
            idle = idle ?: 0..0,
            walk = walk ?: 0..0,
            life = l, damage = d, defense = df,
            knockback = if (kind == ModKind.SWORD || kind == ModKind.STAFF) weaponKnockbacks[wkbIdx] else knockbacks[kbIdx],
            value = v,
            ai = aiIdx, spawn = spawnIdx,
            dropItem = dropIdx, dropMin = dmin, dropMax = dmax,
            names = names.split(",").map { it.trim() }.filter { it.isNotEmpty() },
            dialogue = dialogue.split("|").map { it.trim() }.filter { it.isNotEmpty() },
            shop = shop,
            weaponFrame = wf - 1,
            rotateDeg = rotations[rotIdx],
            useTime = ut, mana = mn,
            shootSpeed = sp.toFloat(),
            rarity = rarityIdx, station = stationIdx,
            ingredient = ingIdx, ingredientCount = ic,
            penetrate = pn, lifetimeTicks = lt,
        )
        return cfg to null
    }

    fun build() {
        val (cfg, err) = readConfig()
        if (cfg == null) {
            error = err
            return
        }
        error = null
        status = null
        busy = true
        val parts = vm.project.parts.toList() // คัดลอกบนเธรดหลักก่อนส่งไปเธรดเบื้องหลัง (เหมือนหน้าส่งออกสไปรต์ชีตเดิม)
        val frames = vm.project.snapshotFrames()
        scope.launch {
            val r = runCatching { withContext(Dispatchers.Default) { ModExport.build(parts, frames, cfg) } }
            busy = false
            r.onSuccess { result = it; showCode = false }
                .onFailure { result = null; error = "สร้างไม่สำเร็จ: ${it.message ?: it.javaClass.simpleName}" }
        }
    }

    fun save() {
        val r = result ?: return
        busy = true
        val cls = ModExport.cleanId(className, "Thing")
        scope.launch {
            val s = runCatching {
                withContext(Dispatchers.IO) { ModExport.saveZip(context, r.files, "terraria_mod_${cls}_${System.currentTimeMillis()}") }
            }
            busy = false
            s.onSuccess { status = "บันทึกแล้ว: $it" }
                .onFailure { error = "บันทึกไม่สำเร็จ: ${it.message ?: it.javaClass.simpleName}" }
        }
    }

    Column(
        Modifier
            .fillMaxSize()
            .background(Palette.Bg)
            .systemBarsPadding()
            .verticalScroll(rememberScrollState())
            .padding(14.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        Row(Modifier.fillMaxWidth(), verticalAlignment = androidx.compose.ui.Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            OutlinedButton(onClick = onClose, enabled = !busy) { Text("← โหมดแอนิเมต") }
            Text("🎮 โหมดม็อด Terraria", fontWeight = FontWeight.Bold, fontSize = 18.sp, color = Palette.Accent)
        }
        Text(
            "ทำตัวละครในโหมดแอนิเมตตามปกติ แล้วมาที่นี่เพื่อส่งออกเป็นแผ่นสไปรต์ + โค้ดม็อด (.cs) ในไฟล์ ZIP\n" +
                "โค้ดที่สร้างยังไม่ได้ compile และยังไม่ได้ทดสอบในเกม เขียนตามรูปแบบ tModLoader 1.4.x ต้องตรวจกับเวอร์ชันที่ใช้จริง",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )

        Card("ชนิดที่จะสร้าง") {
            ChoiceRow(ModKind.values().map { it.label }, kindIdx, !busy) { kindIdx = it; result = null }
            Text(
                when (kind) {
                    ModKind.MONSTER -> "มอนสเตอร์: ใช้ตัวละคร + อนิเมชันทุกเฟรมของงาน เรียงเป็นแผ่นสไปรต์แนวตั้ง"
                    ModKind.TOWN -> "NPC ชาวเมือง: ต้องมี 25 เฟรมตามตัวอย่างทางการ (ยังต้องตรวจลำดับเฟรมพิเศษ) + ไอคอนหัว"
                    ModKind.SWORD -> "อาวุธฟัน: ภาพนิ่งภาพเดียวจากเฟรมที่เลือก ท่าฟันเกมทำเอง"
                    ModKind.STAFF -> "อาวุธยิง: ตัวละคร 1 ตัวเป็นภาพอาวุธ + ตัวละครอีก 1 ตัวเป็นกระสุน (มีอนิเมชัน)"
                },
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
        }

        Card("ชื่อ") {
            OutlinedTextField(modName, { modName = it; result = null }, label = { Text("ชื่อม็อด (อังกฤษ/ตัวเลข ไม่เว้นวรรค)") }, singleLine = true, modifier = Modifier.fillMaxWidth())
            OutlinedTextField(className, { className = it; result = null }, label = { Text("ชื่อคลาส = ชื่อไฟล์ภาพ (อังกฤษ/ตัวเลข)") }, singleLine = true, modifier = Modifier.fillMaxWidth())
            OutlinedTextField(displayName, { displayName = it; result = null }, label = { Text("ชื่อที่โชว์ (เก็บใน manifest)") }, singleLine = true, modifier = Modifier.fillMaxWidth())
        }

        Card(if (kind == ModKind.STAFF) "ตัวละครของอาวุธ" else "ตัวละคร") {
            if (characters.isEmpty()) {
                Text("ยังไม่มีตัวละครในงาน", color = MaterialTheme.colorScheme.error)
            } else {
                ChoiceRow(characters.map { it.second.ifBlank { "ตัวละคร ${it.first}" } }, characters.indexOfFirst { it.first == effChar }, !busy) {
                    charId = characters[it].first; result = null
                }
                if (hasPath && (kind == ModKind.MONSTER || kind == ModKind.TOWN)) {
                    Text(
                        "ตัวละครนี้มีเส้นทางเคลื่อนที่ ตำแหน่งที่เลื่อนไปจะติดเข้าไปในแผ่นสไปรต์ด้วย ถ้าต้องการให้ยืนกับที่ ให้ลบเส้นทางก่อน",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.error,
                    )
                }
            }
            if (kind == ModKind.STAFF && characters.isNotEmpty()) {
                Text("ตัวละครของกระสุน", fontWeight = FontWeight.Bold)
                ChoiceRow(characters.map { it.second.ifBlank { "ตัวละคร ${it.first}" } }, characters.indexOfFirst { it.first == effProj }, !busy) {
                    projCharId = characters[it].first; result = null
                }
            }
        }

        Card("ขนาดภาพที่ส่งออก (ด้านยาวสุด)") {
            ChoiceRow(sizes.map { "$it px" }, sizeIdx, !busy) { sizeIdx = it; result = null }
            if (kind == ModKind.STAFF) {
                Text("ขนาดกระสุน", fontWeight = FontWeight.Bold)
                ChoiceRow(projSizes.map { "$it px" }, projSizeIdx, !busy) { projSizeIdx = it; result = null }
            }
            Text(
                "ตัดขอบว่างด้วยกรอบรวมของทุกเฟรม (ไม่ตัดรายเฟรม) เฟรมจึงขนาดเท่ากันทุกเฟรมตามที่เกมต้องการ",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
        }

        if (kind == ModKind.MONSTER || kind == ModKind.TOWN) {
            Card("ทิศหน้าของตัวละครในแอป") {
                ChoiceRow(listOf("หันขวา (กลับภาพให้)", "หันซ้าย (ไม่กลับ)"), if (faceRight) 0 else 1, !busy) { faceRight = it == 0; result = null }
                Text(
                    "ตามที่ผมจำ ภาพ NPC ในเกมหันซ้ายเป็นค่าเริ่มต้น ยังไม่ยืนยัน ถ้าในเกมหันผิดด้านให้สลับตัวเลือกนี้แล้วส่งออกใหม่",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
        }

        if (kind == ModKind.MONSTER) {
            Card("ช่วงเฟรมอนิเมชัน (เลขเฟรมเริ่มที่ 1 มี ${vm.project.frameCount} เฟรม)") {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    PadField(idleS, { idleS = it; result = null }, label = "ยืน: เริ่ม", modifier = Modifier.weight(1f))
                    PadField(idleE, { idleE = it; result = null }, label = "ยืน: จบ", modifier = Modifier.weight(1f))
                }
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    PadField(walkS, { walkS = it; result = null }, label = "เดิน: เริ่ม", modifier = Modifier.weight(1f))
                    PadField(walkE, { walkE = it; result = null }, label = "เดิน: จบ", modifier = Modifier.weight(1f))
                }
                Text(
                    "ความเร็วอนิเมชันใช้ค่า fps ปกติของงาน (${fmtFps(vm.fps)} fps) ช่วงความเร็วเฉพาะเฟรมที่ตั้งไว้ไม่ถูกนำไปใช้ในโค้ด",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
        }

        if (kind == ModKind.MONSTER || kind == ModKind.TOWN) {
            Card("ค่าสถานะ") {
                PadField(life, { life = it; result = null }, label = "เลือด")
                PadField(damage, { damage = it; result = null }, label = "พลังโจมตี", allowZero = true)
                PadField(defense, { defense = it; result = null }, label = "เกราะ", allowZero = true)
                if (kind == ModKind.MONSTER) {
                    Text("การถูกผลัก (0% = ไม่ถูกผลัก)", fontWeight = FontWeight.Bold)
                    ChoiceRow(listOf("0%", "50%", "100%"), kbIdx, !busy) { kbIdx = it; result = null }
                    PadField(value, { value = it; result = null }, label = "เหรียญที่ดรอป (ทองแดง)", allowZero = true)
                    Text("พฤติกรรม", fontWeight = FontWeight.Bold)
                    ChoiceRow(ModExport.AI_NAMES, aiIdx, !busy) { aiIdx = it; result = null }
                    Text("จุดเกิด", fontWeight = FontWeight.Bold)
                    ChoiceRow(ModExport.SPAWN_NAMES, spawnIdx, !busy) { spawnIdx = it; result = null }
                    Text("ของที่ดรอป", fontWeight = FontWeight.Bold)
                    ChoiceRow(ModExport.ITEMS, dropIdx, !busy) { dropIdx = it; result = null }
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        PadField(dropMin, { dropMin = it; result = null }, label = "ต่ำสุด", modifier = Modifier.weight(1f))
                        PadField(dropMax, { dropMax = it; result = null }, label = "สูงสุด", modifier = Modifier.weight(1f))
                    }
                }
            }
        }

        if (kind == ModKind.TOWN) {
            Card("บทพูดและร้านค้า") {
                OutlinedTextField(names, { names = it; result = null }, label = { Text("รายชื่อสุ่ม (คั่นด้วย ,)") }, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(dialogue, { dialogue = it; result = null }, label = { Text("บทพูดสุ่ม (คั่นด้วย |)") }, modifier = Modifier.fillMaxWidth())
                Text("สินค้าในร้าน (แตะเพื่อเลือก/เลิกเลือก)", fontWeight = FontWeight.Bold)
                val chosen = shopMask.split(",").mapNotNull { it.trim().toIntOrNull() }.toSet()
                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    ModExport.ITEMS.forEachIndexed { i, n ->
                        FilterChip(
                            selected = i in chosen,
                            onClick = {
                                val next = if (i in chosen) chosen - i else chosen + i
                                shopMask = next.sorted().joinToString(",")
                                result = null
                            },
                            label = { Text(n) },
                            enabled = !busy,
                        )
                    }
                }
            }
        }

        if (kind == ModKind.SWORD || kind == ModKind.STAFF) {
            Card("ภาพอาวุธ") {
                PadField(weaponFrame, { weaponFrame = it; result = null }, label = "ใช้เฟรมที่ (1–${vm.project.frameCount})")
                Text("หมุนภาพ (องศา ตามเข็ม) ให้ปลายอาวุธชี้ขึ้นขวา ด้ามอยู่ล่างซ้าย", fontWeight = FontWeight.Bold)
                ChoiceRow(listOf(0, 45, 90, 135, 180, -45, -90).map { "$it°" }, rotIdx, !busy) { rotIdx = it; result = null }
                Text(
                    "ดูตัวอย่างแล้วปรับมุมจนปลายชี้ขึ้นขวา (ยังไม่มีการหามุมอัตโนมัติ)",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
            Card("ค่าสถานะอาวุธ") {
                PadField(damage, { damage = it; result = null }, label = "พลังโจมตี", allowZero = true)
                PadField(useTime, { useTime = it; result = null }, label = "ความเร็วใช้ (tick ต่อครั้ง ยิ่งน้อยยิ่งเร็ว)")
                Text("แรงผลัก (ค่าที่ใส่ในโค้ด ดาบทั่วไป 3-7)", fontWeight = FontWeight.Bold)
                ChoiceRow(weaponKnockbacks.map { fmtFps(it) }, wkbIdx, !busy) { wkbIdx = it; result = null }
                Text("ความหายาก", fontWeight = FontWeight.Bold)
                ChoiceRow(ModExport.RARITIES, rarityIdx, !busy) { rarityIdx = it; result = null }
                if (kind == ModKind.STAFF) {
                    PadField(mana, { mana = it; result = null }, label = "มานาต่อครั้ง", allowZero = true)
                    PadField(speed, { speed = it; result = null }, label = "ความเร็วกระสุน")
                    PadField(penetrate, { penetrate = it; result = null }, label = "ทะลุศัตรูได้กี่ตัว")
                    PadField(lifetime, { lifetime = it; result = null }, label = "อายุกระสุน (tick 60 = 1 วินาที)")
                }
            }
            Card("สูตรคราฟต์") {
                Text("โต๊ะทำงาน", fontWeight = FontWeight.Bold)
                ChoiceRow(ModExport.STATIONS, stationIdx, !busy) { stationIdx = it; result = null }
                Text("วัตถุดิบ", fontWeight = FontWeight.Bold)
                ChoiceRow(ModExport.ITEMS, ingIdx, !busy) { ingIdx = it; result = null }
                PadField(ingCount, { ingCount = it; result = null }, label = "จำนวน")
            }
        }

        error?.let { Text(it, color = MaterialTheme.colorScheme.error) }
        status?.let { Text(it, color = MaterialTheme.colorScheme.primary) }
        if (busy) Text("กำลังทำงาน...", color = MaterialTheme.colorScheme.primary)

        Button(onClick = { build() }, enabled = !busy, modifier = Modifier.fillMaxWidth()) { Text("สร้างและดูตัวอย่าง") }

        result?.let { r ->
            Card("ผลลัพธ์") {
                r.preview?.let { bmp -> PreviewImage(bmp) }
                r.notes.forEach { Text("• $it", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.error) }
                Text("ไฟล์ใน ZIP:", fontWeight = FontWeight.Bold)
                r.files.forEach { Text("• ${it.path}  (${it.bytes.size} ไบต์)", style = MaterialTheme.typography.bodySmall) }
                OutlinedButton(onClick = { showCode = !showCode }, modifier = Modifier.fillMaxWidth()) {
                    Text(if (showCode) "ซ่อนโค้ด" else "ดูโค้ดหลัก (.cs)")
                }
                if (showCode) {
                    SelectionContainer {
                        Text(
                            r.mainCode,
                            fontFamily = FontFamily.Monospace,
                            fontSize = 11.sp,
                            modifier = Modifier
                                .fillMaxWidth()
                                .heightIn(max = 360.dp)
                                .background(Color(0xFF0E0E14))
                                .verticalScroll(rememberScrollState())
                                .horizontalScroll(rememberScrollState())
                                .padding(8.dp),
                        )
                    }
                }
                Button(onClick = { save() }, enabled = !busy, modifier = Modifier.fillMaxWidth()) { Text("บันทึกเป็น ZIP (ดาวน์โหลด)") }
            }
        }
    }
}

@Composable
private fun PreviewImage(bmp: Bitmap) {
    // ภาพโปร่งใส: วางบนพื้นเทาเพื่อให้เห็นขอบ (แผ่นสูงมาก จำกัดความสูงที่แสดง)
    Image(
        bitmap = bmp.asImageBitmap(),
        contentDescription = "ตัวอย่างภาพที่จะส่งออก",
        contentScale = ContentScale.Fit,
        modifier = Modifier.fillMaxWidth().heightIn(max = 260.dp).background(Color(0xFF555555)),
    )
}

@Composable
private fun Card(title: String, content: @Composable () -> Unit) {
    val shape = RoundedCornerShape(16.dp)
    Column(
        Modifier
            .fillMaxWidth()
            .clip(shape)
            .background(Palette.PanelHigh)
            .border(1.dp, Palette.Stroke, shape)
            .padding(12.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp),
    ) {
        Text(title, fontWeight = FontWeight.Bold, color = Palette.Accent)
        content()
    }
}

/** แถวตัวเลือก (เลื่อนซ้ายขวาได้) เลือกได้ทีละอัน */
@Composable
private fun ChoiceRow(options: List<String>, selected: Int, enabled: Boolean = true, onSelect: (Int) -> Unit) {
    Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        options.forEachIndexed { i, label ->
            FilterChip(selected = i == selected, onClick = { onSelect(i) }, label = { Text(label) }, enabled = enabled)
        }
    }
}
