package com.nop.cartoonstudio

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder
import android.os.PowerManager
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import java.io.File

/**
 * งานส่งออกวิดีโอที่กำลังทำอยู่ (อยู่นอก ViewModel/หน้าจอ เพื่อให้รันต่อได้ตอนออกจากแอปหรือหมุนจอ)
 * หน้าจอแค่ตั้ง request แล้วสั่งเริ่ม ExportService ส่วนความคืบหน้า/ผลลัพธ์อ่านจากค่าด้านล่าง
 */
object ExportJob {
    class Request(
        val parts: List<Part>,
        val frames: List<Map<Int, Pose>>,
        val w: Int,
        val h: Int,
        val fps: Int,
        val loops: Int,
        val background: Int,
        val fpsTable: List<Int>,
        val loopN: Int,
        val quality: Int = 0, // ระดับความชัดวิดีโอ 0=มาตรฐาน 1=ชัด 2=ชัดมาก
    )

    var running by mutableStateOf(false)
    var progress by mutableStateOf("")
    var doneMessage by mutableStateOf<String?>(null) // ตั้งเมื่อบันทึกสำเร็จ หน้าจอรับไปแสดงแล้วเคลียร์
    var error by mutableStateOf<String?>(null) // ตั้งเมื่อล้มเหลว หน้าจอรับไปแสดงแล้วเคลียร์

    @Volatile
    var request: Request? = null
}

/** Foreground service: ให้ระบบไม่ปิดแอประหว่างเข้ารหัสวิดีโอ แม้ผู้ใช้ออกจากแอป (มีแจ้งเตือนแสดงความคืบหน้า) */
class ExportService : Service() {
    private companion object {
        const val CHANNEL = "export"
        const val NOTIF_RUNNING = 1001
        const val NOTIF_DONE = 1002
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        nm.createNotificationChannel(NotificationChannel(CHANNEL, "สร้างวิดีโอ", NotificationManager.IMPORTANCE_LOW))

        // ต้องเรียก startForeground ทันทีหลังถูกสั่งเริ่ม (ภายใน 5 วินาที) ไม่งั้นระบบปิดแอป
        val first = buildRunning("กำลังเริ่ม...", 0, 0)
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(NOTIF_RUNNING, first, ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC)
        } else {
            startForeground(NOTIF_RUNNING, first)
        }

        val req = ExportJob.request
        ExportJob.request = null
        if (req == null) {
            ExportJob.running = false
            stopForeground(Service.STOP_FOREGROUND_REMOVE)
            stopSelf(startId)
            return START_NOT_STICKY
        }

        // กัน CPU หลับตอนปิดจอ (มีเวลาหมดอายุ 30 นาที)
        val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
        val wl = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "cartoonstudio:export")
        wl.acquire(30L * 60L * 1000L)

        Thread {
            var message: String? = null
            var err: String? = null
            try {
                val tmp = File(cacheDir, "export_${System.currentTimeMillis()}.mp4")
                try {
                    var lastPct = -1
                    Exporter.encodeVideo(
                        req.parts, req.frames,
                        Exporter.videoSize(req.w), Exporter.videoSize(req.h),
                        req.fps, req.loops, req.background, tmp,
                        fpsAt = { i -> req.fpsTable[i] },
                        loopN = req.loopN,
                        quality = req.quality,
                    ) { done, total ->
                        val text = "กำลังเข้ารหัส $done / $total เฟรม"
                        ExportJob.progress = text
                        val pct = if (total > 0) done * 100 / total else 0
                        if (pct != lastPct) { // อัปเดตแจ้งเตือนเมื่อเปอร์เซ็นต์เปลี่ยนเท่านั้น
                            lastPct = pct
                            nm.notify(NOTIF_RUNNING, buildRunning(text, total, done))
                        }
                    }
                    message = "บันทึกวิดีโอแล้ว: " + Exporter.saveVideo(this@ExportService, tmp, "animation_${System.currentTimeMillis()}")
                } finally {
                    tmp.delete()
                }
            } catch (t: Throwable) {
                err = "สร้างวิดีโอไม่สำเร็จ: ${t.message ?: t.javaClass.simpleName}"
            } finally {
                if (wl.isHeld) wl.release()
            }
            ExportJob.progress = ""
            if (err == null) ExportJob.doneMessage = message else ExportJob.error = err
            ExportJob.running = false
            stopForeground(Service.STOP_FOREGROUND_REMOVE)
            nm.notify(NOTIF_DONE, buildDone(err ?: message ?: ""))
            stopSelf(startId)
        }.start()
        return START_NOT_STICKY
    }

    private fun openApp(): PendingIntent = PendingIntent.getActivity(
        this, 0,
        Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP),
        PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT,
    )

    private fun buildRunning(text: String, total: Int, done: Int): Notification {
        val b = Notification.Builder(this, CHANNEL)
            .setSmallIcon(android.R.drawable.stat_sys_download)
            .setContentTitle("กำลังสร้างวิดีโอ")
            .setContentText(text)
            .setOngoing(true)
            .setContentIntent(openApp())
        if (total > 0) b.setProgress(total, done, false) else b.setProgress(0, 0, true)
        return b.build()
    }

    private fun buildDone(text: String): Notification =
        Notification.Builder(this, CHANNEL)
            .setSmallIcon(android.R.drawable.stat_sys_download_done)
            .setContentTitle("Cartoon Animator Studio")
            .setContentText(text)
            .setContentIntent(openApp())
            .setAutoCancel(true)
            .build()
}
