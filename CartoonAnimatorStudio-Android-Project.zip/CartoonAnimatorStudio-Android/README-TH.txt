Cartoon Animator Studio — Android project (WebView APK wrapper)

สิ่งที่มีในเวอร์ชันนี้
- เปิดตัวแก้ไข Cartoon Animator Studio ในแอป Android จริง
- เลือกรูปจากแกลเลอรี/ไฟล์ในเครื่อง
- บันทึกภาพ PNG, Sprite Sheet และไฟล์โปรเจกต์ผ่านหน้าต่างบันทึกของ Android
- เป็น MVP สำหรับแก้ไขภาพหลักและจัดเฟรม ไม่ใช่ระบบแยกชิ้นส่วน/กระดูกอัตโนมัติเต็มรูปแบบ

วิธีสร้าง APK ด้วย Android Studio (Windows/Mac/Linux)
1. ติดตั้ง Android Studio รุ่นปัจจุบันจากเว็บไซต์ทางการของ Android Developers
2. แตกไฟล์ ZIP นี้ลงในโฟลเดอร์ที่เข้าถึงง่าย
3. เปิด Android Studio > Open แล้วเลือกโฟลเดอร์ CartoonAnimatorStudio-Android
4. รอ Gradle Sync และติดตั้ง Android SDK Platform 35 หากระบบร้องขอ
5. เลือกเมนู Build > Build Bundle(s) / APK(s) > Build APK(s)
6. เมื่อสร้างเสร็จ กด Locate ในข้อความแจ้งเตือนเพื่อเปิดไฟล์ APK
   ตำแหน่งปกติ: app/build/outputs/apk/debug/app-debug.apk
7. ส่ง APK ไปยังโทรศัพท์ Android แล้วแตะไฟล์เพื่อติดตั้ง
8. หากมีคำเตือน ให้เปิดอนุญาต “ติดตั้งแอปที่ไม่รู้จัก” สำหรับแอปที่ใช้เปิด APK แล้วติดตั้งต่อ
9. หลังติดตั้งเสร็จ สามารถปิดการอนุญาตดังกล่าวได้

วิธีสร้างผ่าน GitHub Actions
1. สร้าง repository บน GitHub และอัปโหลดไฟล์ทั้งหมดในโฟลเดอร์นี้
2. เปิดแท็บ Actions แล้วเลือก “Build Android APK”
3. กด Run workflow หรือ push เข้า branch main/master
4. เมื่อ workflow สำเร็จ เปิดรายการงานที่เสร็จแล้ว แล้วดาวน์โหลด artifact ชื่อ CartoonAnimatorStudio-debug-apk
5. แตก ZIP artifact เพื่อรับ app-debug.apk แล้วติดตั้งบนโทรศัพท์

หมายเหตุ
- ไฟล์ที่สร้างด้วยวิธีนี้เป็น debug APK สำหรับทดลอง/ติดตั้งเอง ไม่ใช่ไฟล์ที่เซ็นสำหรับเผยแพร่บน Play Store
- ไม่สามารถแนบ APK ที่คอมไพล์แล้วจากสภาพแวดล้อมนี้ได้ เพราะไม่มี Android SDK/Gradle build environment ติดตั้งไว้ จึงจัดเตรียมโปรเจกต์ Android ที่เปิดใน Android Studio และ workflow สำหรับสร้าง APK ให้แทน
