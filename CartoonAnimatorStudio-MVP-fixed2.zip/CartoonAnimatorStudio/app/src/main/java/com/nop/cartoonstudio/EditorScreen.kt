package com.nop.cartoonstudio

import android.graphics.Bitmap
import android.widget.Toast
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.gestures.calculateCentroid
import androidx.compose.foundation.gestures.calculatePan
import androidx.compose.foundation.gestures.calculateZoom
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Slider
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.runtime.withFrameNanos
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.drawIntoCanvas
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlin.math.roundToInt

@Composable
fun EditorScreen(vm: EditorViewModel) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var showExport by remember { mutableStateOf(false) }
    var showLoad by remember { mutableStateOf(false) }
    var showDelete by remember { mutableStateOf(false) }
    var updating by remember { mutableStateOf(false) }
    var showSettings by remember { mutableStateOf(false) }
    var showFrameEdit by remember { mutableStateOf(false) }
    val paint = remember {
        android.graphics.Paint(android.graphics.Paint.FILTER_BITMAP_FLAG or android.graphics.Paint.ANTI_ALIAS_FLAG)
    }

    LaunchedEffect(vm.message) {
        val m = vm.message
        if (m != null) {
            Toast.makeText(context, m, Toast.LENGTH_LONG).show()
            vm.message = null
        }
    }

    LaunchedEffect(vm.playing) {
        if (vm.playing) {
            var last = withFrameNanos { it }
            while (vm.playing) {
                val now = withFrameNanos { it }
                vm.tick((now - last) / 1_000_000_000f)
                last = now
            }
        }
    }

    fun startUpdate() {
        scope.launch {
            updating = true
            val r = runCatching { withContext(Dispatchers.IO) { AppUpdater.download(context) } }
            updating = false
            r.onSuccess { f ->
                if (!AppUpdater.install(context, f)) {
                    vm.message = "อนุญาตให้แอปนี้ติดตั้งแอป แล้วกด \"อัปเดตแอป\" อีกครั้ง"
                }
            }.onFailure { vm.message = "อัปเดตไม่สำเร็จ: ${it.message ?: it.javaClass.simpleName}" }
        }
    }

    Column(Modifier.fillMaxSize().systemBarsPadding().background(Palette.Bg)) {
        // แถบบน: ชื่อแอป + ตั้งค่า + ส่งออก
        Row(
            Modifier.fillMaxWidth().background(Palette.Panel).padding(horizontal = 14.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            Text(
                "Cartoon Animator Studio",
                Modifier.weight(1f),
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.primary,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
            )
            Box(
                Modifier
                    .size(44.dp)
                    .clip(CircleShape)
                    .background(Palette.PanelHigh)
                    .border(1.dp, Palette.Stroke, CircleShape)
                    .clickable { showSettings = true },
                contentAlignment = Alignment.Center,
            ) { Text("⚙", fontSize = 22.sp, color = Color(0xFFE7E3EE)) }
            PillButton("ส่งออก", onClick = { showExport = true }, style = PillStyle.PRIMARY)
        }

        // ผืนผ้าใบ
        Box(
            Modifier
                .weight(1f)
                .fillMaxWidth()
                .padding(horizontal = 10.dp, vertical = 8.dp)
                .clip(RoundedCornerShape(18.dp))
                .border(1.dp, Palette.Stroke, RoundedCornerShape(18.dp)),
        ) {
            Canvas(
                Modifier
                    .fillMaxSize()
                    .onSizeChanged { vm.onCanvasSize(it) }
                    .pointerInput(Unit) {
                        awaitEachGesture {
                            val down = awaitFirstDown(requireUnconsumed = false)
                            vm.onDown(down.position)
                            var multi = false
                            do {
                                val event = awaitPointerEvent()
                                val pressed = event.changes.filter { it.pressed }
                                if (pressed.size >= 2) {
                                    multi = true
                                    vm.onTransform(event.calculateCentroid(), event.calculatePan(), event.calculateZoom())
                                    event.changes.forEach { it.consume() }
                                } else if (pressed.size == 1 && !multi) {
                                    val c = pressed[0]
                                    val d = c.position - c.previousPosition
                                    if (d != Offset.Zero) vm.onDrag(c.position, d)
                                    c.consume()
                                }
                            } while (event.changes.any { it.pressed })
                            vm.onUp()
                        }
                    },
            ) {
                drawRect(Color(0xFF1B1D22))
                drawGuides(vm)
                drawIntoCanvas { canvas ->
                    val nc = canvas.nativeCanvas
                    nc.save()
                    nc.translate(vm.canvasSize.width / 2f + vm.pan.x, vm.canvasSize.height / 2f + vm.pan.y)
                    nc.scale(vm.zoom, vm.zoom)
                    val onion = vm.onionOpacity
                    if (!vm.playing && vm.currentFrame > 0 && onion > 0.01f) { // เงาลางๆ ของเฟรมก่อนหน้า
                        val prev = vm.currentFrame - 1
                        nc.saveLayerAlpha(null, (onion * 255f).roundToInt().coerceIn(0, 255))
                        drawScene(nc, vm.project.parts, { id -> vm.project.poseAt(prev, id) }, paint)
                        nc.restore()
                    }
                    drawScene(nc, vm.project.parts, vm.poseOf(), paint)
                    nc.restore()
                }
                drawOverlay(vm)
            }
            if (vm.project.parts.isNotEmpty() && (vm.tool == Tool.CHAR_SCALE || vm.tool == Tool.CHAR_ROTATE)) {
                Surface(
                    color = Color(0xCC000000),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.align(Alignment.TopStart).padding(10.dp),
                ) {
                    Text(
                        if (vm.tool == Tool.CHAR_SCALE) {
                            "ขนาด ${(vm.charScale * 100f).roundToInt()}%\nใช้ 2 นิ้วถ่างออก = ใหญ่ขึ้น หุบเข้า = เล็กลง"
                        } else {
                            "มุม ${vm.characterAngle().roundToInt()}°\nลากนิ้วรอบจุดหลัก = หมุนตัวละคร"
                        },
                        Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
                        color = Color.White,
                        style = MaterialTheme.typography.bodySmall,
                    )
                }
            }
            if (vm.project.parts.isEmpty()) {
                Text(
                    "ยังไม่มีตัวละคร\nกด \"โหลดตัวละคร\" ด้านล่างเพื่อเริ่ม",
                    Modifier.align(Alignment.Center).padding(24.dp),
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    textAlign = TextAlign.Center,
                )
            }
        }

        // แผงล่าง: เหลือแต่เครื่องมือแอนิเมต + โหลดตัวละคร
        Surface(
            color = Palette.Panel,
            shape = RoundedCornerShape(topStart = 22.dp, topEnd = 22.dp),
            modifier = Modifier.fillMaxWidth(),
        ) {
            Column(
                Modifier.heightIn(max = 290.dp).verticalScroll(rememberScrollState()).padding(top = 12.dp, bottom = 10.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                Row(
                    Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()).padding(horizontal = 12.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    PillButton("📂 โหลดตัวละคร", onClick = { showLoad = true }, style = PillStyle.TONAL)
                    PillButton("🗑 ลบตัวละคร", onClick = { showDelete = true }, style = PillStyle.TONAL)
                    // กดซ้ำ = กลับโหมดปกติ (เดิมกลับด้วยปุ่ม "ย้าย" ซึ่งเอาออกแล้ว)
                    Chip("หมุนตัวละคร", vm.tool == Tool.CHAR_ROTATE) {
                        vm.tool = if (vm.tool == Tool.CHAR_ROTATE) Tool.MOVE else Tool.CHAR_ROTATE
                    }
                    Chip("ขยายตัวละคร", vm.tool == Tool.CHAR_SCALE) {
                        vm.tool = if (vm.tool == Tool.CHAR_SCALE) Tool.MOVE else Tool.CHAR_SCALE
                    }
                    // เปิดหน้าต่างตั้งความเร็วเล่นเฉพาะช่วงเฟรม (ไฮไลต์เมื่อเฟรมที่เลือกอยู่ในช่วงที่ตั้งความเร็วไว้)
                    Chip("แก้ไขเฟรม", vm.project.rangeAt(vm.currentFrame) != null, enabled = !vm.playing) { showFrameEdit = true }
                }

                if (vm.project.parts.isNotEmpty()) {
                    // เลเยอร์ (ไว้เลือกชิ้นที่แตะยาก)
                    LazyRow(
                        Modifier.fillMaxWidth().padding(horizontal = 12.dp),
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                    ) {
                        items(vm.project.parts, key = { it.id }) { part ->
                            Chip(part.name, part.id == vm.selectedId) { vm.selectedId = part.id }
                        }
                    }
                    val sel = vm.selected
                    Text(
                        if (sel == null) "แตะชิ้นส่วนบนผืนผ้าใบ หรือเลือกจากรายการเลเยอร์" else "เลือกอยู่: ${sel.name}",
                        Modifier.padding(horizontal = 14.dp),
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
                Timeline(vm)
            }
        }
    }

    if (showSettings) {
        SettingsDialog(
            vm,
            updating = updating,
            onOpenBones = { showSettings = false; vm.boneEditorOpen = true },
            onUpdate = { startUpdate() },
        ) { showSettings = false }
    }
    if (showLoad) LoadCharacterDialog(vm) { showLoad = false }
    if (showDelete) DeleteCharacterDialog(vm) { showDelete = false }
    if (showFrameEdit) FrameSpeedDialog(vm) { showFrameEdit = false }
    if (showExport) ExportDialog(vm) { showExport = false }
}

private enum class PillStyle { PRIMARY, TONAL, OUTLINE, DANGER }

private val TonalBg = Color(0xFF42338A)
private val TonalFg = Color(0xFFE9E0FF)
private val NormalFg = Color(0xFFE7E3EE)

/** ปุ่มทรงแคปซูลของแอป: PRIMARY = ม่วงทึบ, TONAL = ม่วงเข้ม, OUTLINE = พื้นเทาขอบบาง, DANGER = ตัวอักษรแดงอ่อน */
@Composable
private fun PillButton(
    label: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    enabled: Boolean = true,
    style: PillStyle = PillStyle.OUTLINE,
) {
    val shape = RoundedCornerShape(50)
    val bg = when (style) {
        PillStyle.PRIMARY -> Palette.Accent
        PillStyle.TONAL -> TonalBg
        else -> Palette.PanelHigh
    }
    val fg = when (style) {
        PillStyle.PRIMARY -> Color(0xFF2A1A66)
        PillStyle.TONAL -> TonalFg
        PillStyle.DANGER -> Color(0xFFFF8A80)
        PillStyle.OUTLINE -> NormalFg
    }
    val edge = when (style) {
        PillStyle.PRIMARY -> Palette.Accent
        PillStyle.TONAL -> Color(0xFF6B58C9)
        else -> Palette.Stroke
    }
    Box(
        modifier
            .heightIn(min = 44.dp)
            .alpha(if (enabled) 1f else 0.38f)
            .clip(shape)
            .background(bg)
            .border(1.dp, edge, shape)
            .clickable(enabled = enabled, onClick = onClick)
            .padding(horizontal = 18.dp, vertical = 8.dp),
        contentAlignment = Alignment.Center,
    ) { Text(label, color = fg, fontWeight = FontWeight.Medium, textAlign = TextAlign.Center) }
}

/** ชิปเลือก/สลับ (ใช้กับเครื่องมือ, วนซ้ำ, ชื่อชิ้นส่วน) */
@Composable
private fun Chip(label: String, selected: Boolean, enabled: Boolean = true, onClick: () -> Unit) {
    val shape = RoundedCornerShape(50)
    Box(
        Modifier
            .heightIn(min = 44.dp)
            .alpha(if (enabled) 1f else 0.38f)
            .clip(shape)
            .background(if (selected) TonalBg else Palette.PanelHigh)
            .border(1.dp, if (selected) Palette.Accent else Palette.Stroke, shape)
            .clickable(enabled = enabled, onClick = onClick)
            .padding(horizontal = 16.dp, vertical = 8.dp),
        contentAlignment = Alignment.Center,
    ) {
        Text(
            label,
            color = if (selected) TonalFg else Color(0xFFC9C4D4),
            fontWeight = if (selected) FontWeight.Bold else FontWeight.Normal,
        )
    }
}

/** ปุ่มเลขเฟรม (วงกลม) */
@Composable
private fun FrameChip(number: Int, selected: Boolean, custom: Boolean = false, onClick: () -> Unit) {
    Box(
        Modifier
            .size(44.dp)
            .clip(CircleShape)
            .background(if (selected) TonalBg else if (custom) Color(0xFF223545) else Palette.PanelHigh)
            .border(
                if (selected || custom) 2.dp else 1.dp,
                if (selected) Palette.Accent else if (custom) Color(0xFF4FC3F7) else Palette.Stroke,
                CircleShape,
            )
            .clickable(onClick = onClick),
        contentAlignment = Alignment.Center,
    ) {
        Text(
            "$number",
            color = if (selected) TonalFg else Color(0xFFC9C4D4),
            fontWeight = if (selected) FontWeight.Bold else FontWeight.Normal,
        )
    }
}

/** ปุ่ม + ท้ายแถวเฟรม: เพิ่มเฟรมใหม่ (คัดลอกท่าจากเฟรมท้ายสุด) */
@Composable
private fun AddFrameButton(enabled: Boolean, onClick: () -> Unit) {
    Box(
        Modifier
            .size(44.dp)
            .alpha(if (enabled) 1f else 0.38f)
            .clip(CircleShape)
            .background(Palette.Accent)
            .clickable(enabled = enabled, onClick = onClick),
        contentAlignment = Alignment.Center,
    ) { Text("+", color = Color(0xFF2A1A66), fontSize = 26.sp, fontWeight = FontWeight.Bold) }
}

/** เมนูตั้งค่า: กระดูก / อัปเดตแอป / ขนาดวิดีโอ / ความจางของเงาเฟรมที่แล้ว */
@Composable
private fun SettingsDialog(
    vm: EditorViewModel,
    updating: Boolean,
    onOpenBones: () -> Unit,
    onUpdate: () -> Unit,
    onDismiss: () -> Unit,
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("ตั้งค่า") },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                PillButton("กระดูก (สร้าง/แก้ไขตัวละคร)", onClick = onOpenBones, modifier = Modifier.fillMaxWidth(), style = PillStyle.TONAL)
                PillButton(
                    if (updating) "กำลังโหลด..." else "อัปเดตแอป",
                    onClick = onUpdate,
                    modifier = Modifier.fillMaxWidth(),
                    enabled = !updating,
                )
                VideoSizeSetting(vm)
                Column {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("ความจางของเฟรมที่แล้ว", Modifier.weight(1f))
                        Text("${(vm.onionOpacity * 100f).roundToInt()}%", color = MaterialTheme.colorScheme.primary)
                    }
                    Slider(
                        value = vm.onionOpacity,
                        onValueChange = { vm.onionOpacity = it },
                        valueRange = 0f..1f,
                    )
                    Text(
                        "เงาลางๆ ของเฟรมก่อนหน้าบนผืนผ้าใบ (0% = ปิด)",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
            }
        },
        confirmButton = { TextButton(onClick = onDismiss) { Text("ปิด") } },
    )
}

/** ตั้งขนาดวิดีโอ [ความสูง] × [ความยาว] (px): เปลี่ยนแล้วเส้นประสีฟ้าบนผืนผ้าใบเปลี่ยนตามทันที และเป็นค่าเริ่มต้นตอนส่งออกวิดีโอ */
@Composable
private fun VideoSizeSetting(vm: EditorViewModel) {
    val shape = RoundedCornerShape(16.dp)
    Column(
        Modifier
            .fillMaxWidth()
            .clip(shape)
            .background(Palette.PanelHigh)
            .border(1.dp, Palette.Stroke, shape)
            .padding(12.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp),
    ) {
        Text("ขนาดวิดีโอ", fontWeight = FontWeight.Bold, color = Palette.Accent)
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            SizeField("ความสูง", vm.videoHeight, Modifier.weight(1f)) { vm.videoHeight = it }
            Text("×", fontSize = 20.sp, color = NormalFg)
            SizeField("ความยาว", vm.videoWidth, Modifier.weight(1f)) { vm.videoWidth = it }
        }
        Text(
            "หน่วย px ใส่ได้ 64–1920 · เส้นประสีฟ้าบนผืนผ้าใบเปลี่ยนตามทันที · ตอนส่งออกจะปัดเป็นพหุคูณของ 16",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
    }
}

/** ช่องใส่ขนาด (px) ใช้ค่าใหม่ทันทีที่พิมพ์ถูกช่วง 64–1920 (พิมพ์ยังไม่ครบ/นอกช่วง = ขึ้นสีแดงและยังใช้ค่าเดิมอยู่) */
@Composable
private fun SizeField(label: String, value: Int, modifier: Modifier, onValid: (Int) -> Unit) {
    var text by remember(value) { mutableStateOf(value.toString()) }
    OutlinedTextField(
        value = text,
        onValueChange = { raw ->
            val digits = raw.filter { it.isDigit() }.take(4)
            text = digits
            val n = digits.toIntOrNull()
            if (n != null && n in 64..1920) onValid(n)
        },
        modifier = modifier,
        label = { Text(label) },
        singleLine = true,
        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
        isError = text.toIntOrNull()?.let { it !in 64..1920 } ?: true,
    )
}

/**
 * แก้ไขเฟรม: ตั้งความเร็วเล่นเฉพาะช่วงเฟรม "จากเฟรมที่เลือก ถึง เลขที่ใส่" ช่วงนั้นเล่นตามความเร็วที่ใส่แทนความเร็วปกติ
 * ตั้งทับช่วงที่มีอยู่แล้วไม่ได้ (ต้องรีเซ็ตช่วงเดิมก่อน) · รีเซ็ต = ล้างช่วงที่เฟรมที่เลือกอยู่ให้กลับไปใช้ความเร็วปกติ
 */
@Composable
private fun FrameSpeedDialog(vm: EditorViewModel, onDismiss: () -> Unit) {
    val project = vm.project
    val from = remember { vm.currentFrame } // เฟรมที่เลือกตอนเปิดหน้าต่าง (เริ่มที่ 0)
    val fromN = from + 1
    var toText by remember { mutableStateOf("") }
    var fpsText by remember { mutableStateOf(vm.fps.toString()) }
    val here = project.rangeAt(from)
    val toN = toText.toIntOrNull()
    val fpsN = fpsText.toIntOrNull()
    val error = project.speedRangeError(fromN, toN, fpsN)
    val showError = error != null && (toText.isNotEmpty() || here != null)
    val card = RoundedCornerShape(14.dp)
    val pill = RoundedCornerShape(50)
    val dim = MaterialTheme.colorScheme.onSurfaceVariant

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("แก้ไขเฟรม") },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Text(
                    "ช่วงเฟรมที่ตั้งไว้จะเล่นตามความเร็วที่ใส่ แทนความเร็วปกติ (${vm.fps} fps)",
                    style = MaterialTheme.typography.bodySmall,
                    color = dim,
                )
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    Box(
                        Modifier
                            .clip(pill)
                            .background(TonalBg)
                            .border(1.dp, Palette.Accent, pill)
                            .padding(horizontal = 16.dp, vertical = 12.dp),
                        contentAlignment = Alignment.Center,
                    ) { Text("เฟรม $fromN", color = TonalFg, fontWeight = FontWeight.Bold) }
                    Text("ถึง", color = NormalFg)
                    OutlinedTextField(
                        value = toText,
                        onValueChange = { toText = it.filter { c -> c.isDigit() }.take(4) },
                        modifier = Modifier.weight(1f),
                        singleLine = true,
                        label = { Text("เลขเฟรม") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    )
                }
                OutlinedTextField(
                    value = fpsText,
                    onValueChange = { fpsText = it.filter { c -> c.isDigit() }.take(3) },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true,
                    label = { Text("ความเร็ว (fps)") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    isError = fpsN?.let { it !in 1..240 } ?: true,
                )
                if (error == null && toN != null && fpsN != null) {
                    val n = toN - fromN + 1
                    val secs = String.format(java.util.Locale.US, "%.2f", n.toFloat() / fpsN)
                    Text(
                        "เฟรม $fromN–$toN · $n เฟรม · ใช้เวลา $secs วินาที",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.primary,
                    )
                } else if (error != null && showError) {
                    Box(Modifier.fillMaxWidth().clip(card).background(Color(0x33FF8A80)).padding(10.dp)) {
                        Text(error, style = MaterialTheme.typography.bodySmall, color = Color(0xFFFF8A80))
                    }
                }
                if (project.speedRanges.isNotEmpty()) {
                    Text("ช่วงที่ตั้งความเร็วไว้แล้ว", fontWeight = FontWeight.Bold, color = Palette.Accent)
                    for (r in project.speedRanges.sortedBy { it.start }) {
                        val mine = r == here
                        Row(
                            Modifier
                                .fillMaxWidth()
                                .clip(card)
                                .background(if (mine) TonalBg else Palette.PanelHigh)
                                .border(1.dp, if (mine) Palette.Accent else Palette.Stroke, card)
                                .padding(horizontal = 12.dp, vertical = 8.dp),
                            verticalAlignment = Alignment.CenterVertically,
                        ) {
                            Text("เฟรม ${r.start + 1}–${r.end + 1}", Modifier.weight(1f), color = if (mine) TonalFg else NormalFg)
                            Text("${r.fps} fps", color = Palette.Accent, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        },
        confirmButton = {
            PillButton("ตกลง", enabled = error == null, style = PillStyle.PRIMARY, onClick = {
                val t = toN
                val f = fpsN
                if (error == null && t != null && f != null) {
                    project.addSpeedRange(fromN, t, f)
                    vm.message = "ตั้งความเร็วเฟรม $fromN–$t = $f fps แล้ว"
                    onDismiss()
                }
            })
        },
        dismissButton = {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                PillButton("รีเซ็ต", enabled = here != null, style = PillStyle.DANGER, onClick = {
                    here?.let {
                        project.speedRanges.remove(it)
                        vm.message = "รีเซ็ตเฟรม ${it.start + 1}–${it.end + 1} กลับเป็นความเร็วปกติ (${vm.fps} fps) แล้ว"
                        onDismiss()
                    }
                })
                PillButton("ปิด", onClick = onDismiss)
            }
        },
    )
}

/** รายการตัวละครที่เซฟไว้ในแอป (เซฟจากเมนูกระดูก) แตะเพื่อโหลดเข้าฉากแอนิเมต */
@Composable
private fun LoadCharacterDialog(vm: EditorViewModel, onDismiss: () -> Unit) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var saved by remember { mutableStateOf<List<SavedCharacter>?>(null) }
    var busy by remember { mutableStateOf(false) }
    var pending by remember { mutableStateOf<String?>(null) } // ชื่อที่รอยืนยันการแทนที่

    LaunchedEffect(Unit) {
        saved = runCatching { withContext(Dispatchers.IO) { CharacterStore.list(context) } }.getOrDefault(emptyList())
    }

    fun load(name: String) {
        busy = true
        scope.launch {
            val r = runCatching {
                withContext(Dispatchers.IO) { CharacterToParts.prepare(CharacterStore.load(context, name)) }
            }
            busy = false
            r.onSuccess { built ->
                vm.loadCharacter(built)
                vm.message = "โหลดตัวละคร \"$name\" แล้ว"
                onDismiss()
            }.onFailure {
                vm.message = "โหลดไม่สำเร็จ: ${it.message ?: it.javaClass.simpleName}"
            }
        }
    }

    AlertDialog(
        onDismissRequest = { if (!busy) onDismiss() },
        title = { Text("โหลดตัวละคร") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                val list = saved
                when {
                    list == null -> Text("กำลังอ่านรายการ...")
                    list.isEmpty() -> Text(
                        "ยังไม่มีตัวละครที่บันทึกไว้\nไปที่เมนู \"กระดูก\" สร้างตัวละคร แล้วกด \"เซฟตัวละคร\"",
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                    else -> LazyColumn(
                        Modifier.heightIn(max = 320.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp),
                    ) {
                        items(list, key = { it.name }) { c ->
                            CharacterRow(c, enabled = !busy) {
                                if (vm.project.parts.isEmpty()) load(c.name) else pending = c.name
                            }
                        }
                    }
                }
                if (busy) Text("กำลังโหลด...", color = MaterialTheme.colorScheme.primary)
            }
        },
        confirmButton = { TextButton(enabled = !busy, onClick = onDismiss) { Text("ปิด") } },
    )

    pending?.let { name ->
        AlertDialog(
            onDismissRequest = { pending = null },
            title = { Text("แทนที่ตัวละครปัจจุบัน?") },
            text = { Text("การโหลด \"$name\" จะแทนที่ตัวละครและท่าแอนิเมตทั้งหมดที่มีอยู่ตอนนี้") },
            confirmButton = { TextButton(onClick = { pending = null; load(name) }) { Text("โหลดเลย") } },
            dismissButton = { TextButton(onClick = { pending = null }) { Text("ยกเลิก") } },
        )
    }
}

/** รายการตัวละครที่เซฟไว้ แตะตัวที่จะลบ -> ถามยืนยัน (ยกเลิก / ตกลงลบ) -> ลบจากที่เก็บของแอป */
@Composable
private fun DeleteCharacterDialog(vm: EditorViewModel, onDismiss: () -> Unit) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var saved by remember { mutableStateOf<List<SavedCharacter>?>(null) }
    var busy by remember { mutableStateOf(false) }
    var pending by remember { mutableStateOf<String?>(null) } // ชื่อที่รอยืนยันการลบ

    LaunchedEffect(Unit) {
        saved = runCatching { withContext(Dispatchers.IO) { CharacterStore.list(context) } }.getOrDefault(emptyList())
    }

    fun delete(name: String) {
        busy = true
        scope.launch {
            val r = runCatching { withContext(Dispatchers.IO) { CharacterStore.delete(context, name) } }
            busy = false
            r.onSuccess {
                vm.message = "ลบตัวละคร \"$name\" แล้ว"
                saved = saved?.filter { it.name != name }
            }.onFailure {
                vm.message = "ลบไม่สำเร็จ: ${it.message ?: it.javaClass.simpleName}"
            }
        }
    }

    AlertDialog(
        onDismissRequest = { if (!busy) onDismiss() },
        title = { Text("ลบตัวละคร") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                val list = saved
                when {
                    list == null -> Text("กำลังอ่านรายการ...")
                    list.isEmpty() -> Text(
                        "ไม่มีตัวละครที่บันทึกไว้",
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                    else -> LazyColumn(
                        Modifier.heightIn(max = 320.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp),
                    ) {
                        items(list, key = { it.name }) { c ->
                            CharacterRow(c, enabled = !busy, actionLabel = "ลบ") { pending = c.name }
                        }
                    }
                }
                if (busy) Text("กำลังลบ...", color = MaterialTheme.colorScheme.primary)
            }
        },
        confirmButton = { TextButton(enabled = !busy, onClick = onDismiss) { Text("ปิด") } },
    )

    pending?.let { name ->
        AlertDialog(
            onDismissRequest = { pending = null },
            title = { Text("ลบตัวละคร?") },
            text = { Text("ต้องการลบ \"$name\" ใช่ไหม ลบแล้วกู้คืนไม่ได้") },
            confirmButton = { TextButton(onClick = { pending = null; delete(name) }) { Text("ตกลง ลบ") } },
            dismissButton = { TextButton(onClick = { pending = null }) { Text("ยกเลิก") } },
        )
    }
}

@Composable
private fun CharacterRow(c: SavedCharacter, enabled: Boolean, actionLabel: String = "โหลด", onClick: () -> Unit) {
    val date = remember(c.savedAt) {
        java.text.DateFormat.getDateTimeInstance(java.text.DateFormat.MEDIUM, java.text.DateFormat.SHORT)
            .format(java.util.Date(c.savedAt))
    }
    Row(
        Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(14.dp))
            .background(Palette.PanelHigh)
            .clickable(enabled = enabled, onClick = onClick)
            .padding(horizontal = 14.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Column(Modifier.weight(1f)) {
            Text(c.name, maxLines = 1, overflow = TextOverflow.Ellipsis, fontWeight = FontWeight.Bold)
            Text(date, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        Text(actionLabel, color = MaterialTheme.colorScheme.primary)
    }
}

@Composable
private fun Timeline(vm: EditorViewModel) {
    val listState = rememberLazyListState()
    var confirmDeleteFrame by remember { mutableStateOf(false) }
    LaunchedEffect(vm.project.frameCount) { listState.animateScrollToItem(vm.project.frameCount) } // เลื่อนไปที่ปุ่ม + เมื่อเพิ่มเฟรม
    if (vm.mode != Mode.ANIMATE) {
        Text(
            "สลับไปโหมดแอนิเมตเพื่อใช้ไทม์ไลน์",
            Modifier.padding(horizontal = 12.dp, vertical = 4.dp),
            style = MaterialTheme.typography.bodySmall,
        )
        return
    }
    LazyRow(
        Modifier.fillMaxWidth().padding(horizontal = 8.dp),
        state = listState,
        horizontalArrangement = Arrangement.spacedBy(8.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        items(vm.project.frameCount) { i ->
            FrameChip(i + 1, vm.currentFrame == i, custom = vm.project.rangeAt(i) != null) {
                if (!vm.playing) {
                    vm.currentFrame = i
                    vm.playhead = i.toFloat()
                }
            }
        }
        item { AddFrameButton(enabled = !vm.playing) { vm.addFrame() } }
    }
    Row(
        Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()).padding(horizontal = 8.dp),
        horizontalArrangement = Arrangement.spacedBy(8.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        PillButton(if (vm.playing) "⏸ พัก" else "▶ เล่น", onClick = { vm.togglePlay() }, style = PillStyle.PRIMARY)
        PillButton("⏹ หยุด", onClick = { vm.stop() })
        Chip("วนซ้ำ", vm.loop) { vm.loop = !vm.loop }
        FpsField(vm)
    }
    Row(
        Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()).padding(horizontal = 8.dp),
        horizontalArrangement = Arrangement.spacedBy(8.dp),
    ) {
        PillButton("คัดลอกจากเฟรมก่อน", onClick = { vm.copyFromPreviousFrame() }, enabled = !vm.playing)
        PillButton("รีเซ็ตท่าชิ้นนี้", onClick = { vm.resetSelectedPose() }, enabled = !vm.playing)
        PillButton("ล้างเฟรมนี้", onClick = { vm.clearFrame() }, enabled = !vm.playing, style = PillStyle.DANGER)
        PillButton(
            "ลบเฟรมนี้",
            onClick = { confirmDeleteFrame = true },
            enabled = !vm.playing && vm.project.frameCount > 1,
            style = PillStyle.DANGER,
        )
    }

    if (confirmDeleteFrame) {
        AlertDialog(
            onDismissRequest = { confirmDeleteFrame = false },
            title = { Text("ลบเฟรม ${vm.currentFrame + 1}?") },
            text = { Text("เฟรมนี้จะถูกลบออก เฟรมหลังจากนี้จะเลื่อนขึ้นมาแทน (ย้อนกลับไม่ได้)") },
            confirmButton = {
                TextButton(onClick = { confirmDeleteFrame = false; vm.deleteCurrentFrame() }) {
                    Text("ลบเฟรม", color = Color(0xFFFF8A80))
                }
            },
            dismissButton = { TextButton(onClick = { confirmDeleteFrame = false }) { Text("ยกเลิก") } },
        )
    }
}

/** ช่องใส่ความเร็วเฟรม (fps) ใส่เลขจำนวนเต็ม 1–240 เปลี่ยนค่าทันทีที่พิมพ์ถูกช่วง */
@Composable
private fun FpsField(vm: EditorViewModel) {
    var text by remember(vm.fps) { mutableStateOf(vm.fps.toString()) }
    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        Text("ความเร็ว", color = Color(0xFFC9C4D4))
        OutlinedTextField(
            value = text,
            onValueChange = { raw ->
                val digits = raw.filter { it.isDigit() }.take(3)
                text = digits
                val n = digits.toIntOrNull()
                if (n != null && n in 1..240) vm.fps = n
            },
            singleLine = true,
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
            isError = text.toIntOrNull()?.let { it !in 1..240 } ?: true,
            modifier = Modifier.width(92.dp),
        )
        Text("fps", color = Color(0xFFC9C4D4))
    }
}

private enum class ExportKind { IMAGE, VIDEO }

/** ส่งออก: เลือกก่อนว่าจะเป็นรูป (Sprite Sheet) หรือวิดีโอ (MP4) */
@Composable
private fun ExportDialog(vm: EditorViewModel, onDismiss: () -> Unit) {
    var kind by remember { mutableStateOf<ExportKind?>(null) }
    when (kind) {
        ExportKind.IMAGE -> ImageExportDialog(vm, onDismiss)
        ExportKind.VIDEO -> VideoExportDialog(vm, onDismiss)
        null -> AlertDialog(
            onDismissRequest = onDismiss,
            title = { Text("ส่งออกเป็น") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    ExportChoiceCard("🖼", "รูป", "Sprite Sheet (PNG พื้นหลังโปร่งใส) รวมทุกเฟรมในรูปเดียว") { kind = ExportKind.IMAGE }
                    ExportChoiceCard("🎬", "วิดีโอ", "ไฟล์ MP4 เล่นแอนิเมชันตามความเร็วเฟรม (เลือกสีพื้นหลังได้)") { kind = ExportKind.VIDEO }
                }
            },
            confirmButton = { TextButton(onClick = onDismiss) { Text("ยกเลิก") } },
        )
    }
}

@Composable
private fun ExportChoiceCard(icon: String, title: String, desc: String, onClick: () -> Unit) {
    val shape = RoundedCornerShape(16.dp)
    Row(
        Modifier
            .fillMaxWidth()
            .clip(shape)
            .background(Palette.PanelHigh)
            .border(1.dp, Palette.Stroke, shape)
            .clickable(onClick = onClick)
            .padding(14.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(14.dp),
    ) {
        Text(icon, fontSize = 30.sp)
        Column(Modifier.weight(1f)) {
            Text(title, fontWeight = FontWeight.Bold, color = Palette.Accent)
            Text(desc, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}

@Composable
private fun VideoExportDialog(vm: EditorViewModel, onDismiss: () -> Unit) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var w by remember { mutableStateOf(vm.videoWidth.toString()) } // ค่าเริ่มต้นมาจากขนาดวิดีโอในเมนูตั้งค่า
    var h by remember { mutableStateOf(vm.videoHeight.toString()) }
    var loops by remember { mutableStateOf("3") }
    var bg by remember { mutableIntStateOf(0) }
    var error by remember { mutableStateOf<String?>(null) }
    var busy by remember { mutableStateOf(false) }
    var progress by remember { mutableStateOf("") }
    val bgColors = listOf(0xFFFFFFFF.toInt(), 0xFF000000.toInt(), 0xFF00B140.toInt())
    val bgNames = listOf("ขาว", "ดำ", "เขียว")

    fun start() {
        val fw = w.toIntOrNull()
        val fh = h.toIntOrNull()
        val lp = loops.toIntOrNull()
        val err = Exporter.validateVideo(fw, fh, lp, vm.project.frameCount)
        if (err != null) {
            error = err
            return
        }
        if (vm.project.parts.isEmpty()) {
            error = "ยังไม่มีชิ้นส่วนให้ส่งออก"
            return
        }
        error = null
        busy = true
        progress = "กำลังเริ่ม..."
        val parts = vm.project.parts.toList()
        val frames = vm.project.snapshotFrames()
        val fps = vm.fps
        val fpsTable = List(frames.size) { i -> vm.project.fpsAt(i, fps) } // ความเร็วรายเฟรม (รวมช่วงที่ตั้งเอง) อ่านบน main thread ก่อนส่งเข้า IO
        val color = bgColors[bg]
        scope.launch {
            val result = runCatching {
                withContext(Dispatchers.IO) {
                    val tmp = java.io.File(context.cacheDir, "export_${System.currentTimeMillis()}.mp4")
                    try {
                        Exporter.encodeVideo(parts, frames, Exporter.videoSize(fw!!), Exporter.videoSize(fh!!), fps, lp!!, color, tmp, fpsAt = { i -> fpsTable[i] }) { done, total ->
                            progress = "กำลังเข้ารหัส $done / $total เฟรม"
                        }
                        Exporter.saveVideo(context, tmp, "animation_${System.currentTimeMillis()}")
                    } finally {
                        tmp.delete()
                    }
                }
            }
            busy = false
            result.onSuccess {
                vm.message = "บันทึกวิดีโอแล้ว: $it"
                onDismiss()
            }.onFailure {
                error = "สร้างวิดีโอไม่สำเร็จ: ${it.message ?: it.javaClass.simpleName}"
            }
        }
    }

    AlertDialog(
        onDismissRequest = { if (!busy) onDismiss() },
        title = { Text("ส่งออกวิดีโอ (MP4)") },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(w, { w = it }, label = { Text("กว้าง (px)") }, singleLine = true, enabled = !busy)
                OutlinedTextField(h, { h = it }, label = { Text("สูง (px)") }, singleLine = true, enabled = !busy)
                OutlinedTextField(loops, { loops = it }, label = { Text("วนกี่รอบ") }, singleLine = true, enabled = !busy)
                Text("สีพื้นหลัง (MP4 ไม่มีความโปร่งใส)", style = MaterialTheme.typography.bodySmall)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    bgNames.forEachIndexed { i, n -> Chip(n, bg == i, enabled = !busy) { bg = i } }
                }
                Text(
                    "ความเร็ว ${vm.fps} fps (แก้ได้ที่ช่องความเร็วในไทม์ไลน์)" +
                        (if (vm.project.speedRanges.isNotEmpty()) " + ${vm.project.speedRanges.size} ช่วงที่ตั้งความเร็วเอง (ใช้ในวิดีโอด้วย)" else "") +
                        " · ${vm.project.frameCount} เฟรม · ขนาดจะปัดเป็นพหุคูณของ 16",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
                error?.let { Text(it, color = MaterialTheme.colorScheme.error) }
                if (busy) Text(progress, color = MaterialTheme.colorScheme.primary)
            }
        },
        confirmButton = { TextButton(enabled = !busy, onClick = { start() }) { Text("สร้างวิดีโอ") } },
        dismissButton = { TextButton(enabled = !busy, onClick = onDismiss) { Text("ปิด") } },
    )
}

@Composable
private fun ImageExportDialog(vm: EditorViewModel, onDismiss: () -> Unit) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var w by remember { mutableStateOf("256") }
    var h by remember { mutableStateOf("256") }
    var cols by remember { mutableStateOf(minOf(5, vm.project.frameCount).toString()) } // คอลัมน์ต้องไม่เกินจำนวนเฟรม
    var preview by remember { mutableStateOf<Bitmap?>(null) }
    var error by remember { mutableStateOf<String?>(null) }
    var busy by remember { mutableStateOf(false) }

    fun generate(onDone: (Bitmap) -> Unit) {
        val fw = w.toIntOrNull()
        val fh = h.toIntOrNull()
        val c = cols.toIntOrNull()
        val err = Exporter.validate(fw, fh, c, vm.project.frameCount)
        if (err != null) {
            error = err
            return
        }
        if (vm.project.parts.isEmpty()) {
            error = "ยังไม่มีชิ้นส่วนให้ส่งออก"
            return
        }
        error = null
        busy = true
        val parts = vm.project.parts.toList()
        val frames = vm.project.snapshotFrames()
        scope.launch {
            val result = runCatching {
                withContext(Dispatchers.Default) { Exporter.buildSheet(parts, frames, fw!!, fh!!, c!!) }
            }
            busy = false
            result.onSuccess {
                preview = it
                onDone(it)
            }.onFailure {
                error = "สร้างสไปรต์ชีตไม่สำเร็จ: ${it.message ?: it.javaClass.simpleName}"
            }
        }
    }

    AlertDialog(
        onDismissRequest = { if (!busy) onDismiss() },
        title = { Text("ส่งออก Sprite Sheet (PNG โปร่งใส)") },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(w, { w = it; preview = null }, label = { Text("กว้างต่อเฟรม (px)") }, singleLine = true)
                OutlinedTextField(h, { h = it; preview = null }, label = { Text("สูงต่อเฟรม (px)") }, singleLine = true)
                OutlinedTextField(cols, { cols = it; preview = null }, label = { Text("จำนวนคอลัมน์") }, singleLine = true)
                Text(
                    "จำนวนแถวคำนวณอัตโนมัติจาก ${vm.project.frameCount} เฟรม ÷ คอลัมน์",
                    style = MaterialTheme.typography.bodySmall,
                )
                error?.let { Text(it, color = MaterialTheme.colorScheme.error) }
                preview?.let {
                    Image(
                        bitmap = it.asImageBitmap(),
                        contentDescription = "ตัวอย่างสไปรต์ชีต",
                        contentScale = ContentScale.Fit,
                        modifier = Modifier.fillMaxWidth().heightIn(max = 200.dp).background(Color(0xFF555555)),
                    )
                }
                if (busy) Text("กำลังประมวลผล...")
            }
        },
        confirmButton = {
            Row {
                TextButton(enabled = !busy, onClick = { generate { } }) { Text("ดูตัวอย่าง") }
                TextButton(enabled = !busy, onClick = {
                    generate { bmp ->
                        scope.launch {
                            busy = true
                            val saved = runCatching {
                                withContext(Dispatchers.IO) {
                                    Exporter.savePng(context, bmp, "spritesheet_${System.currentTimeMillis()}")
                                }
                            }
                            busy = false
                            saved.onSuccess {
                                vm.message = "บันทึกแล้ว: $it"
                                onDismiss()
                            }.onFailure {
                                error = "บันทึกไม่สำเร็จ: ${it.message ?: it.javaClass.simpleName}"
                            }
                        }
                    }
                }) { Text("บันทึก") }
            }
        },
        dismissButton = { TextButton(enabled = !busy, onClick = onDismiss) { Text("ปิด") } },
    )
}

private fun DrawScope.drawGuides(vm: EditorViewModel) {
    val grid = Color(0xFF2A2D34)
    val axis = Color(0xFF3B404A)
    for (k in -10..10) {
        val c = if (k == 0) axis else grid
        drawLine(c, vm.toScreen(Offset(k * 100f, -1000f)), vm.toScreen(Offset(k * 100f, 1000f)), 1.5f)
        drawLine(c, vm.toScreen(Offset(-1000f, k * 100f)), vm.toScreen(Offset(1000f, k * 100f)), 1.5f)
    }
    // กรอบส่งออก: สิ่งที่อยู่ในกรอบนี้คือสิ่งที่จะอยู่ในแต่ละเฟรมของวิดีโอ (ขนาดตั้งในเมนูตั้งค่า)
    val (fw, fh) = Exporter.frameWorldSize(vm.videoWidth, vm.videoHeight) // กรอบตามขนาดวิดีโอในเมนูตั้งค่า (ค่าเริ่มต้น 512x512 = จัตุรัส 600 หน่วยเหมือนเดิม)
    drawRect(
        Color(0xFF4FC3F7),
        topLeft = vm.toScreen(Offset(-fw / 2f, -fh / 2f)),
        size = Size(fw * vm.zoom, fh * vm.zoom),
        style = Stroke(width = 2f, pathEffect = PathEffect.dashPathEffect(floatArrayOf(14f, 10f))),
    )
}

private fun DrawScope.drawOverlay(vm: EditorViewModel) {
    val parts = vm.project.parts
    val poseFn = vm.poseOf()
    val joints = computeJointMatrices(parts, poseFn)
    val sel = vm.selected
    val screenPos = HashMap<Int, Offset>()
    for (p in parts) {
        val j = joints[p.id] ?: continue
        val pt = floatArrayOf(0f, 0f)
        j.mapPoints(pt)
        screenPos[p.id] = vm.toScreen(Offset(pt[0], pt[1]))
    }
    for (p in parts) { // กระดูก = เส้นเชื่อมข้อต่อ parent -> ข้อต่อลูก
        val pid = p.parentId ?: continue
        val a = screenPos[pid] ?: continue
        val b = screenPos[p.id] ?: continue
        drawLine(Color(0x88FFFFFF), a, b, 3f)
    }
    for (p in parts) { // ปลายของกระดูกที่ไม่มีลูก (เช่น มือ): วาดตามทิศจริงของกระดูก ให้เหมือนหน้าแก้ไขกระดูก
        if (p.boneLength <= 0f || parts.any { it.parentId == p.id }) continue
        val a = screenPos[p.id] ?: continue
        val j = joints[p.id] ?: continue
        val pt = floatArrayOf(p.boneLength, 0f)
        j.mapPoints(pt)
        val b = vm.toScreen(Offset(pt[0], pt[1]))
        drawLine(Color(0x88FFFFFF), a, b, 3f)
        drawCircle(Color(0xFFFFD54F), 6f, b)
    }
    for (p in parts) { // จุดต่อ (ปลายกระดูก): เส้นจากข้อต่อไปยังจุดปลาย แล้วจุดเขียวให้จับลาก
        if (!p.hasTip) continue
        val a = screenPos[p.id] ?: continue
        val b = Offset(a.x, a.y + tipLength(p) * vm.zoom) // ปุ่มเขียวอยู่ใต้ปุ่มแดงในแนวตั้งเสมอ
        drawLine(Color(0xFF4FC3F7), a, b, 4f)
        drawCircle(Color(0xFF69F0AE), if (p.id == sel?.id) 16f else 10f, b)
    }
    for (p in parts) {
        val s = screenPos[p.id] ?: continue
        val isSel = p.id == sel?.id && p.boneLength <= 0f // ชิ้นที่มาจากกระดูก: จุดแดงอยู่ที่ปลายกระดูก (ด้านล่าง)
        drawCircle(if (isSel) Color(0xFFFF5252) else Color(0xFFFFD54F), if (isSel) 10f else 6f, s)
    }
    for (r in parts) { // จุดหลัก (ข้อต่อราก): ลากเพื่อย้ายทั้งตัวละคร
        if (r.parentId != null) continue
        val s = screenPos[r.id] ?: continue
        if (vm.mainDragging) drawCircle(Color(0xFFFF5252), 10f, s)
        drawCircle(Color(0xAAFFFFFF), 16f, s, style = Stroke(width = 2.5f))
    }
    if (sel != null && sel.boneLength > 0f) { // กระดูกที่เลือก: จุดแดงที่ปลายกระดูก (จุดที่แตะลากได้)
        val j = joints[sel.id]
        if (j != null) {
            val tp = floatArrayOf(sel.boneLength, 0f)
            j.mapPoints(tp)
            drawCircle(Color(0xFFFF5252), 10f, vm.toScreen(Offset(tp[0], tp[1])))
        }
    }
}
