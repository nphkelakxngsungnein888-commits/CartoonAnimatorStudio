# Advanced Brush implementation notes

This archive contains the brush-engine changes made in this iteration.

Implemented and connected to the existing editor:
- Additional brush shapes: circle, rectangle, diamond, horizontal line, vertical line.
- Start/end force ramp and distance response for grab and advanced warp tools.
- Stable per-grid-point jitter for force, size, and angle.
- Actual drag-path stabilizer filtering (instead of merely reducing brush strength).
- Brush scale values are no longer clamped to the former 10%-400% range in the warp calculations; near-zero values receive a tiny mathematical fallback to avoid division by zero.
- Advanced warp deformation amount is no longer clamped to a fixed 10,000% ceiling.
- New settings are serialized with the image-studio workspace and restored on load.
- Mask stroke spacing controls the interpolation distance between paint samples.

Not claimed as complete in this archive:
- Dual Brush, Multi Brush, custom bitmap texture brushes, and automatic body-part-aware Smart Brush are not implemented as fully working tools.
- Stylus hardware pressure/tilt depends on the Android input path and device support; the existing pressure setting remains simulated.
- A full Android Gradle build was not run in this environment. The ZIP archive integrity was checked and the modified Sculpt.kt passed a Kotlin syntax-oriented compiler check, but this is not a substitute for an Android build or on-device test.

The numeric input fields accept large finite values, decimals, and signed values. Some controls with percentage semantics are still interpreted as percentages by the effect math; unrestricted text entry does not imply every mathematical operation can produce a useful image at every possible value.
