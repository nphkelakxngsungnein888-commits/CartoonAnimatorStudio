# Advanced Brush implementation notes

This archive contains the brush-engine changes made in this iteration.

Implemented and connected to the existing editor:
- Additional brush shapes: circle, rectangle, diamond, horizontal line, vertical line.
- Start/end force ramp and distance response for grab and advanced warp tools.
- Stable per-grid-point jitter for force, size, and angle.
- Actual drag-path stabilizer filtering (instead of merely reducing brush strength).
- Brush scale values are no longer clamped to the former 10%-400% range in the warp calculations; near-zero values receive a tiny mathematical fallback to avoid division by zero.
- Advanced warp deformation amount is no longer clamped to a fixed 10,000% ceiling.
- New settings are serialized with the image-studio workspace and restored on load.
- Mask stroke spacing controls the interpolation distance between paint samples.

Not claimed as complete in this archive:
- Dual Brush, Multi Brush, custom bitmap texture brushes, and automatic body-part-aware Smart Brush are not implemented as fully working tools.
- Stylus hardware pressure/tilt depends on the Android input path and device support; the existing pressure setting remains simulated.
- A full Android Gradle build was not run in this environment. The ZIP archive integrity was checked and the modified Sculpt.kt passed a Kotlin syntax-oriented compiler check, but this is not a substitute for an Android build or on-device test.

The numeric input fields accept large finite values, decimals, and signed values. Some controls with percentage semantics are still interpreted as percentages by the effect math; unrestricted text entry does not imply every mathematical operation can produce a useful image at every possible value.

## 15 additional advanced deformation brushes

The following tools are now present in the sculpt tool selector and are routed through `Sculpt.applyAdvancedWarp`. Each tool has a mode-specific parameter panel, a recommended-settings action, and matching parameter-preview entries in `ParamPreviewRegistry`. The preview compares low / current / high values using the actual warp engine.

| Tool | Main adjustable values | Recommended example |
|---|---|---|
| Arc Bend | Strength 0–200%, bend axis −360°…360°, brush X/Y 10–400%, falloff 0–100% | Strength 75%, angle 25°, X 180%, Y 70%, falloff 80% |
| Taper | Strength, taper direction, taper level 0.1–10, brush X/Y | Strength 90%, angle 0°, level 2, X 140%, Y 65% |
| Rigid Transform | Strength, rotation −180°…180°, brush X/Y, edge falloff | Strength 65%, rotation 30°, X/Y 110%, falloff 100% |
| Ribbon Bend | Strength, ribbon axis, brush X/Y, cycles 0.1–20, length 2–2000 px, phase −360°…360° | Strength 80%, X 250%, Y 35%, 1 cycle, 180 px, phase 0° |
| Edge Slide | Strength, slide direction, edge protection, brush hardness, falloff | Strength 50%, angle 90°, edge protection 60%, hardness 20% |
| Contour Flow | Strength, flow axis, ripple count 0.1–20, flow distance 2–2000 px, phase | Strength 60%, 2 ridges, 120 px, phase 90° |
| Fan Deform | Strength, fan axis, lobe count 1–24, phase, brush X/Y | Strength 75%, 5 lobes, phase 0°, X/Y 100% |
| Origami Fold | Strength, fold axis, hardness, falloff, maximum deformation | Strength 65%, axis 45°, hardness 65%, falloff 80% |
| Topology Remap | Strength, grid frequency 0.1–20, cell size 2–2000 px, phase, mesh smoothing | Strength 45%, frequency 3, cell size 70 px, phase 30°, smoothing 15% |
| Boundary Tension | Strength, edge protection, hardness, smoothness, maximum deformation | Strength 60%, edge protection 80%, hardness 30%, smoothness 70% |
| Viscous Melt | Strength, melt direction, falloff, flow amount, melt reach 2–2000 px | Strength 80%, direction 90°, falloff 70%, flow 60%, reach 100 px |
| Segment Offset | Strength, strip direction, segment span 2–2000 px, strips per span 0.1–20, phase | Strength 80%, direction 0°, span 24 px, 6 strips, phase 0° |
| Asymmetric Warp | Strength, asymmetry axis, brush X/Y, left/right bias, falloff | Strength 65%, X 160%, Y 80%, bias 90°, falloff 75% |
| Directional Compress | Strength, compression axis, brush X/Y, smoothness | Strength 70%, axis 0°, X/Y 100%, smoothness 70% |
| Surface Roll | Strength, roll axis, roll radius 2–2000 px, cycles 0.1–8, falloff | Strength 70%, radius 120 px, 1 cycle, falloff 60% |

All these controls reuse existing `WarpSettings` fields, so no additional project-file schema or migration is needed. The `Topology Remap` tool moves existing mesh points through a cross-grid displacement field; it does **not** change the mesh point count or connectivity. The global brush tab continues to expose shared controls such as radius, pressure, brush shape, falloff, and mesh safety.

The “recommended values” action writes the example settings into the current workspace. Each parameter's preview icon opens its low / current / high comparison; the user can apply the displayed sample from that preview sheet.
