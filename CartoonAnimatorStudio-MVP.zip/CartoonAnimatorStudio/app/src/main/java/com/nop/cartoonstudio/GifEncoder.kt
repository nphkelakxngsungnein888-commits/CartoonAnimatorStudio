package com.nop.cartoonstudio

import java.io.OutputStream

/**
 * ตัวเข้ารหัส GIF แอนิเมชันที่เขียนเอง (ไม่พึ่งไลบรารี และไม่ใช้คลาสของ Android จึงทดสอบบน JVM ได้)
 *
 * - พาเลตต์รวมทั้งแอนิเมชัน 1 ชุด (median cut จากทุกเฟรม) สีไม่กะพริบระหว่างเฟรมและไฟล์เล็กกว่าพาเลตต์ต่อเฟรม
 * - โปร่งใสแบบ 1 บิต: พิกเซลที่ alpha < 128 = โปร่งใส (index 0 สงวนไว้) ขอบจึงอาจหยาบเล็กน้อยตามข้อจำกัดของ GIF
 * - เฟรมเต็มขนาดทุกเฟรม + disposal 2 เมื่อโปร่งใส กันภาพเฟรมก่อนค้างซ้อน
 * - เรนเดอร์ 2 รอบ (รอบแรกเก็บสี รอบสองเข้ารหัส) จึงไม่ต้องเก็บทุกเฟรมไว้ในหน่วยความจำ
 */
object GifEncoder {
    /**
     * @param renderFrame เติมพิกเซล ARGB (ไม่ใช่ premultiplied) ของเฟรมที่ k ลง px (ขนาด w*h) ต้องได้ผลเหมือนเดิมทุกครั้งที่เรียก
     * @param delaysCs เวลาของแต่ละเฟรมเป็นหน่วย 1/100 วินาที
     * @param loopTotal จำนวนรอบที่เล่นทั้งหมด (0 = ไม่จำกัด)
     */
    fun encode(
        out: OutputStream,
        w: Int,
        h: Int,
        frameCount: Int,
        delaysCs: IntArray,
        transparent: Boolean,
        loopTotal: Int,
        renderFrame: (Int, IntArray) -> Unit,
        onProgress: (Int, Int) -> Unit = { _, _ -> },
    ) {
        require(frameCount > 0 && w in 1..65535 && h in 1..65535)
        val px = IntArray(w * h)

        // ---- รอบที่ 1: นับสีทุกเฟรม (ลดเหลือ 5 บิตต่อช่อง แต่เก็บผลรวมสีจริงไว้เฉลี่ย) ----
        val cnt = IntArray(32768)
        val sumR = LongArray(32768)
        val sumG = LongArray(32768)
        val sumB = LongArray(32768)
        for (k in 0 until frameCount) {
            renderFrame(k, px)
            for (c in px) {
                if (transparent && (c ushr 24) < 128) continue
                val r = (c shr 16) and 0xFF
                val g = (c shr 8) and 0xFF
                val b = c and 0xFF
                val key = ((r shr 3) shl 10) or ((g shr 3) shl 5) or (b shr 3)
                cnt[key]++
                sumR[key] += r.toLong()
                sumG[key] += g.toLong()
                sumB[key] += b.toLong()
            }
            onProgress(k + 1, frameCount * 2)
        }

        val reserved = if (transparent) 1 else 0
        val maxColors = 256 - reserved
        val lut = IntArray(32768) // key -> index ในพาเลตต์ (รวม index ที่สงวนไว้แล้ว)
        val palette = buildPalette(cnt, sumR, sumG, sumB, maxColors, reserved, lut)
        val used = palette.size / 3 // รวมช่องสงวน
        var bits = 2
        while ((1 shl bits) < used) bits++
        val tableSize = 1 shl bits

        // ---- เขียนส่วนหัว ----
        val o = out
        o.write("GIF89a".toByteArray(Charsets.US_ASCII))
        writeShort(o, w)
        writeShort(o, h)
        o.write(0x80 or ((bits - 1) shl 4) or (bits - 1)) // มีตารางสีรวม, ขนาดตาราง = 2^bits
        o.write(0) // สีพื้นหลัง (index 0)
        o.write(0) // aspect ratio
        o.write(palette, 0, palette.size)
        for (i in palette.size until tableSize * 3) o.write(0)
        if (loopTotal != 1) { // เล่นรอบเดียว = ไม่ใส่ส่วนขยายนี้; GIF นับเป็น "เล่นซ้ำอีกกี่รอบ" จึงลบออก 1
            o.write(byteArrayOf(0x21, 0xFF.toByte(), 0x0B))
            o.write("NETSCAPE2.0".toByteArray(Charsets.US_ASCII))
            o.write(byteArrayOf(0x03, 0x01))
            writeShort(o, if (loopTotal <= 0) 0 else (loopTotal - 1).coerceAtMost(65535))
            o.write(0)
        }

        // ---- รอบที่ 2: เข้ารหัสทีละเฟรม ----
        val idx = ByteArray(w * h)
        for (k in 0 until frameCount) {
            renderFrame(k, px)
            for (i in px.indices) {
                val c = px[i]
                idx[i] = if (transparent && (c ushr 24) < 128) {
                    0
                } else {
                    val key = ((((c shr 16) and 0xFF) shr 3) shl 10) or ((((c shr 8) and 0xFF) shr 3) shl 5) or ((c and 0xFF) shr 3)
                    lut[key].toByte()
                }
            }
            // Graphic Control Extension
            o.write(byteArrayOf(0x21, 0xF9.toByte(), 0x04))
            o.write(if (transparent) (2 shl 2) or 1 else (1 shl 2)) // disposal 2 + โปร่งใส | disposal 1 (คงไว้ ทับเต็มเฟรม)
            writeShort(o, delaysCs[k].coerceIn(1, 65535))
            o.write(0) // index สีโปร่งใส
            o.write(0)
            // Image Descriptor (เต็มภาพ ไม่มีตารางสีเฉพาะเฟรม)
            o.write(0x2C)
            writeShort(o, 0)
            writeShort(o, 0)
            writeShort(o, w)
            writeShort(o, h)
            o.write(0)
            lzw(idx, bits, o)
            onProgress(frameCount + k + 1, frameCount * 2)
        }
        o.write(0x3B)
        o.flush()
    }

    private fun writeShort(o: OutputStream, v: Int) {
        o.write(v and 0xFF)
        o.write((v shr 8) and 0xFF)
    }

    // ---------- Median cut ----------

    /** คืนพาเลตต์ RGB (ช่องที่สงวนเป็นสีดำอยู่ต้นตาราง) และเติม lut ให้ทุกสีที่พบ */
    private fun buildPalette(
        cnt: IntArray, sumR: LongArray, sumG: LongArray, sumB: LongArray,
        maxColors: Int, reserved: Int, lut: IntArray,
    ): ByteArray {
        var n = 0
        for (c in cnt) if (c > 0) n++
        val keys = IntArray(n)
        run {
            var j = 0
            for (key in cnt.indices) if (cnt[key] > 0) keys[j++] = key
        }
        val boxes = ArrayList<IntArray>() // [start, end) ในช่วงของ keys
        if (n > 0) boxes.add(intArrayOf(0, n))

        fun channel(key: Int, ch: Int): Int = when (ch) {
            0 -> (key shr 10) and 31
            1 -> (key shr 5) and 31
            else -> key and 31
        }

        // คะแนนของกล่อง = ประชากร × ช่วงสีที่กว้างสุด (กล่องที่มีสีเดียวแบ่งไม่ได้)
        fun score(b: IntArray): Long {
            if (b[1] - b[0] < 2) return -1L
            var pop = 0L
            val mn = intArrayOf(31, 31, 31)
            val mx = intArrayOf(0, 0, 0)
            for (i in b[0] until b[1]) {
                val key = keys[i]
                pop += cnt[key]
                for (ch in 0..2) {
                    val v = channel(key, ch)
                    if (v < mn[ch]) mn[ch] = v
                    if (v > mx[ch]) mx[ch] = v
                }
            }
            val range = maxOf(mx[0] - mn[0], mx[1] - mn[1], mx[2] - mn[2]) + 1
            return pop * range
        }

        while (boxes.size < maxColors) {
            var best = -1
            var bestScore = 0L
            for (i in boxes.indices) {
                val s = score(boxes[i])
                if (s > bestScore) { bestScore = s; best = i }
            }
            if (best < 0) break
            val b = boxes[best]
            // เลือกช่องสีที่ช่วงกว้างสุดแล้วเรียงตามช่องนั้น
            val mn = intArrayOf(31, 31, 31)
            val mx = intArrayOf(0, 0, 0)
            for (i in b[0] until b[1]) for (ch in 0..2) {
                val v = channel(keys[i], ch)
                if (v < mn[ch]) mn[ch] = v
                if (v > mx[ch]) mx[ch] = v
            }
            var axis = 0
            for (ch in 1..2) if (mx[ch] - mn[ch] > mx[axis] - mn[axis]) axis = ch
            val len = b[1] - b[0]
            val sortKeys = LongArray(len) { (channel(keys[b[0] + it], axis).toLong() shl 20) or keys[b[0] + it].toLong() }
            sortKeys.sort()
            for (i in 0 until len) keys[b[0] + i] = (sortKeys[i] and 0xFFFFF).toInt()
            // ตัดที่จุดกึ่งกลางของจำนวนพิกเซล (ให้ทั้งสองฝั่งมีอย่างน้อย 1 สี)
            var total = 0L
            for (i in b[0] until b[1]) total += cnt[keys[i]]
            var acc = 0L
            var cut = b[0] + 1
            for (i in b[0] until b[1] - 1) {
                acc += cnt[keys[i]]
                cut = i + 1
                if (acc * 2 >= total) break
            }
            boxes[best] = intArrayOf(b[0], cut)
            boxes.add(intArrayOf(cut, b[1]))
        }

        val pal = ByteArray((boxes.size + reserved) * 3)
        for ((bi, b) in boxes.withIndex()) {
            var pop = 0L
            var r = 0L
            var g = 0L
            var bl = 0L
            for (i in b[0] until b[1]) {
                val key = keys[i]
                pop += cnt[key]
                r += sumR[key]
                g += sumG[key]
                bl += sumB[key]
            }
            val p = (bi + reserved) * 3
            if (pop > 0) {
                pal[p] = (r / pop).toByte()
                pal[p + 1] = (g / pop).toByte()
                pal[p + 2] = (bl / pop).toByte()
            }
            for (i in b[0] until b[1]) lut[keys[i]] = bi + reserved
        }
        return pal
    }

    // ---------- LZW ----------

    private const val HASH_SIZE = 1 shl 14 // ใหญ่กว่า 2 × 4096 พอ ล้างตารางถูก

    private fun lzw(pixels: ByteArray, minCodeSize: Int, out: OutputStream) {
        out.write(minCodeSize)
        val sink = SubBlockSink(out)
        val clear = 1 shl minCodeSize
        val eoi = clear + 1
        var codeSize = minCodeSize + 1
        var next = eoi + 1
        val hKey = IntArray(HASH_SIZE)
        val hVal = IntArray(HASH_SIZE)
        java.util.Arrays.fill(hKey, -1)

        var bitBuf = 0
        var bitCnt = 0
        fun emit(code: Int) {
            bitBuf = bitBuf or (code shl bitCnt)
            bitCnt += codeSize
            while (bitCnt >= 8) {
                sink.put(bitBuf and 0xFF)
                bitBuf = bitBuf ushr 8
                bitCnt -= 8
            }
        }

        emit(clear)
        var prefix = pixels[0].toInt() and 0xFF
        for (i in 1 until pixels.size) {
            val c = pixels[i].toInt() and 0xFF
            val key = (prefix shl 8) or c
            var hsh = (key * -1640531535) ushr (32 - 14)
            var found = -1
            while (hKey[hsh] != -1) {
                if (hKey[hsh] == key) { found = hVal[hsh]; break }
                hsh = (hsh + 1) and (HASH_SIZE - 1)
            }
            if (found >= 0) {
                prefix = found
                continue
            }
            emit(prefix)
            if (next == (1 shl codeSize) && codeSize < 12) codeSize++ // ตัวถอดรหัสขยายความกว้างเมื่อตารางของมันเต็มพอดี (ตามหลังตัวเข้ารหัส 1 ก้าว)
            if (next < 4096) {
                hKey[hsh] = key
                hVal[hsh] = next
                next++
            } else {
                emit(clear)
                java.util.Arrays.fill(hKey, -1)
                codeSize = minCodeSize + 1
                next = eoi + 1
            }
            prefix = c
        }
        emit(prefix)
        if (next == (1 shl codeSize) && codeSize < 12) codeSize++
        emit(eoi)
        if (bitCnt > 0) sink.put(bitBuf and 0xFF)
        sink.finish()
    }

    /** รวมไบต์เป็นบล็อกละ ≤ 255 ไบต์ตามรูปแบบ GIF แล้วปิดด้วยบล็อกว่าง */
    private class SubBlockSink(val out: OutputStream) {
        private val buf = ByteArray(255)
        private var n = 0
        fun put(b: Int) {
            buf[n++] = b.toByte()
            if (n == 255) flush()
        }
        private fun flush() {
            if (n == 0) return
            out.write(n)
            out.write(buf, 0, n)
            n = 0
        }
        fun finish() {
            flush()
            out.write(0)
        }
    }
}
