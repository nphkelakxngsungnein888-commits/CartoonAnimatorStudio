package com.nop.cartoonstudio

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Paint
import androidx.compose.ui.geometry.Offset
import kotlin.math.ceil
import kotlin.math.max
import kotlin.math.min

/** ชิ้นส่วนแอนิเมตที่แปลงจากกระดูก 1 เส้น (ยังไม่ผูกกับ Project) */
class BuiltPart(
    val boneId: Int,
    val parentBoneId: Int?,
    val name: String,
    val bitmap: Bitmap,
    val pivotX: Float,
    val pivotY: Float,
    val scale: Float,
    val x: Float,
    val y: Float,
    val restRotation: Float,
    val boneLength: Float, // ความยาวกระดูกในหน่วยโลก (ใช้วาดปลายกระดูกของกระดูกที่ไม่มีลูก เช่น มือ)
)

/**
 * แปลงโครงกระดูก (ระบบกระดูก) เป็นชิ้นส่วนของฉากแอนิเมต (ระบบ Part)
 * - กระดูก 1 เส้น = 1 ชิ้น: รวมภาพทั้งหมดของเส้นนั้นเป็นภาพเดียว (ภาพของกระดูกเส้นเดียวกันขยับด้วยกันอยู่แล้ว)
 * - ข้อต่อของชิ้น = โคนกระดูก; ชิ้นลูกอยู่ที่ปลายกระดูกพ่อ (x = ความยาวพ่อ, y = 0 ในกรอบของพ่อ)
 * - กรอบของกระดูก: แกน x ชี้ไปทางปลาย, y ชี้ลง; มุมกระดูกเป็นทวนเข็ม (บวก) แต่ Matrix.rotate เป็นตามเข็ม จึงใช้ restRotation = -angle
 * - ย่อตัวละครทั้งตัวให้พอดีกรอบส่งออก (ไม่ขยายถ้าเล็กอยู่แล้ว) และวางกึ่งกลางที่ (0,0) ของฉาก
 * ฟังก์ชันนี้สร้าง Bitmap จึงควรเรียกใน Dispatchers.IO
 */
object CharacterToParts {
    private const val FIT_RATIO = 0.8f
    private const val MAX_SIDE = 1024f

    private class Flat(val bitmap: Bitmap, val pivotX: Float, val pivotY: Float, val k: Float)

    fun prepare(skeleton: Skeleton): List<BuiltPart> {
        if (skeleton.bones.isEmpty()) return emptyList()

        // ขอบเขตของตัวละครทั้งตัว (พิกัดโครงกระดูก ท่าตั้งต้น) รวมจุดราก (0,0)
        var minX = 0f
        var minY = 0f
        var maxX = 0f
        var maxY = 0f
        fun include(x: Float, y: Float) {
            if (x < minX) minX = x
            if (y < minY) minY = y
            if (x > maxX) maxX = x
            if (y > maxY) maxY = y
        }
        for (b in skeleton.bones) {
            val tip = skeleton.tipOf(b)
            include(tip.x, tip.y)
            val base = skeleton.baseOf(b)
            val ang = skeleton.worldAngle(b)
            for (img in b.images) {
                val w = img.bitmap.width.toFloat()
                val h = img.bitmap.height.toFloat()
                val pts = floatArrayOf(0f, 0f, w, 0f, w, h, 0f, h)
                boneImageMatrix(img, base, ang).mapPoints(pts)
                for (i in 0 until 4) include(pts[i * 2], pts[i * 2 + 1])
            }
        }
        val extent = max(max(maxX - minX, maxY - minY), 1f)
        val fit = min(1f, FIT_RATIO * Exporter.WORLD_WINDOW / extent)
        val cx = (minX + maxX) / 2f
        val cy = (minY + maxY) / 2f

        val paint = Paint(Paint.FILTER_BITMAP_FLAG or Paint.ANTI_ALIAS_FLAG)
        val out = ArrayList<BuiltPart>()
        skeleton.bones.forEachIndexed { index, b ->
            val parent = skeleton.bone(b.parentId)
            val flat = flatten(b, paint)
            out.add(
                BuiltPart(
                    boneId = b.id,
                    parentBoneId = parent?.id,
                    name = "กระดูก ${index + 1}",
                    bitmap = flat.bitmap,
                    pivotX = flat.pivotX,
                    pivotY = flat.pivotY,
                    scale = fit / flat.k,
                    x = if (parent == null) -cx * fit else parent.length * fit,
                    y = if (parent == null) -cy * fit else 0f,
                    restRotation = -b.angle,
                    boneLength = b.length * fit,
                ),
            )
        }
        return out
    }

    /** รวมภาพของกระดูกเป็นภาพเดียวในกรอบของกระดูก (ละเอียดตามภาพต้นฉบับ แต่ด้านยาวไม่เกิน MAX_SIDE) */
    private fun flatten(b: Bone, paint: Paint): Flat {
        if (b.images.isEmpty()) { // กระดูกที่ไม่มีภาพ: ภาพโปร่งใส 1x1 ให้ลำดับชั้นพ่อ-ลูกยังอยู่
            return Flat(Bitmap.createBitmap(1, 1, Bitmap.Config.ARGB_8888), 0.5f, 0.5f, 1f)
        }
        val mats = b.images.map { boneImageMatrix(it, Offset.Zero, 0f) }
        var lx = Float.MAX_VALUE
        var ly = Float.MAX_VALUE
        var hx = -Float.MAX_VALUE
        var hy = -Float.MAX_VALUE
        b.images.forEachIndexed { i, img ->
            val w = img.bitmap.width.toFloat()
            val h = img.bitmap.height.toFloat()
            val pts = floatArrayOf(0f, 0f, w, 0f, w, h, 0f, h)
            mats[i].mapPoints(pts)
            for (j in 0 until 4) {
                lx = min(lx, pts[j * 2])
                hx = max(hx, pts[j * 2])
                ly = min(ly, pts[j * 2 + 1])
                hy = max(hy, pts[j * 2 + 1])
            }
        }
        val bw = max(hx - lx, 1f)
        val bh = max(hy - ly, 1f)
        val density = b.images.maxOf { 1f / max(it.scale, 0.05f) } // พิกเซลต้นฉบับต่อ 1 หน่วยในกรอบกระดูก
        val k = min(density, MAX_SIDE / max(bw, bh))
        val pw = max(ceil(bw * k).toInt(), 1)
        val ph = max(ceil(bh * k).toInt(), 1)
        val bmp = Bitmap.createBitmap(pw, ph, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bmp)
        b.images.forEachIndexed { i, img ->
            val m = mats[i]
            m.postTranslate(-lx, -ly)
            m.postScale(k, k)
            canvas.drawBitmap(img.bitmap, m, paint)
        }
        return Flat(bmp, -lx * k, -ly * k, k) // ข้อต่อ = จุด (0,0) ของกรอบกระดูก
    }
}
