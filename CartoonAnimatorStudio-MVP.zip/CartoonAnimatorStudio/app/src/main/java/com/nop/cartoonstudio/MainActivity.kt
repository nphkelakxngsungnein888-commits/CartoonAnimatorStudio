package com.nop.cartoonstudio

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.core.content.ContextCompat
import androidx.lifecycle.ViewModelProvider
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext

class MainActivity : ComponentActivity() {
    private lateinit var vm: EditorViewModel

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        vm = ViewModelProvider(this)[EditorViewModel::class.java]

        // Android 13+: ต้องขออนุญาตแจ้งเตือน ไม่งั้นมองไม่เห็นแถบความคืบหน้าตอนสร้างวิดีโอเบื้องหลัง (ไม่อนุญาตก็ยังสร้างวิดีโอได้)
        val askNotif = registerForActivityResult(ActivityResultContracts.RequestPermission()) { }
        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            askNotif.launch(Manifest.permission.POST_NOTIFICATIONS)
        }

        setContent {
            // กู้งานที่เซฟอัตโนมัติไว้ (ทำครั้งเดียวต่อ ViewModel: หมุนจอ ViewModel ยังอยู่ ไม่ต้องกู้ใหม่)
            LaunchedEffect(Unit) {
                if (vm.restoring) {
                    try {
                        val restored = withContext(Dispatchers.IO) { AutoSave.read(applicationContext) }
                        if (restored != null) AutoSave.apply(vm, restored)
                        vm.restoring = false
                    } catch (e: CancellationException) {
                        throw e // ถูกยกเลิกกลางทาง (restoring ยังเป็น true) รอบหน้าจะกู้ใหม่ ห้ามปลดล็อกการเซฟ
                    } catch (e: Throwable) {
                        AutoSave.quarantine(applicationContext)
                        vm.message = "กู้งานที่ค้างไว้ไม่สำเร็จ (${e.message ?: e.javaClass.simpleName}) เริ่มใหม่ งานเดิมเก็บไว้ในโฟลเดอร์ autosave_failed"
                        vm.restoring = false
                    }
                }
            }

            // เซฟอัตโนมัติทุก 2.5 วินาที (ข้ามถ้าข้อมูลไม่เปลี่ยน) ไม่เริ่มจนกว่าจะกู้เสร็จ กันเขียนทับงานเดิมด้วยของว่าง
            LaunchedEffect(vm.restoring) {
                if (!vm.restoring) {
                    while (true) {
                        delay(2500)
                        val snap = runCatching { AutoSave.capture(vm) }.getOrNull() ?: continue
                        runCatching { withContext(Dispatchers.IO) { AutoSave.write(applicationContext, snap) } }
                    }
                }
            }

            CartoonTheme {
                Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
                    if (vm.restoring) {
                        Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                            Text("กำลังกู้งานที่ทำค้างไว้...")
                        }
                    } else if (vm.boneEditorOpen) {
                        BoneEditorScreen(vm.skeleton) { vm.boneEditorOpen = false }
                    } else {
                        EditorScreen(vm)
                    }
                }
            }
        }
    }

    /** ออกจากแอป/สลับแอป: เซฟทันทีก่อนระบบจะปิดแอปเบื้องหลัง (ไม่ผิดพลาดแล้วทำให้แอปค้าง) */
    override fun onStop() {
        super.onStop()
        if (!vm.restoring) {
            runCatching { AutoSave.write(applicationContext, AutoSave.capture(vm)) }
        }
    }
}
