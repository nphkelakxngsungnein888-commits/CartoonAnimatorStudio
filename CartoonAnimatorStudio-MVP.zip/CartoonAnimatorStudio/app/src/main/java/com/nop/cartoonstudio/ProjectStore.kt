package com.nop.cartoonstudio

import android.content.Context
import android.graphics.Bitmap
import org.json.JSONObject
import java.io.File
import java.io.FileOutputStream
import java.io.IOException

/** งานที่เซฟไว้ (ข้อมูลสำหรับแสดงในรายการ) */
data class SavedProject(val name: String, val savedAt: Long, val parts: Int, val frames: Int)

/**
 * เก็บงานที่ผู้ใช้กด "เซฟงาน" เอง (ตัวละครในฉาก เฟรม/ท่า โครงกระดูก ค่าตั้งต่างๆ) ไว้ในที่เก็บส่วนตัวของแอป
 * รูปแบบ: filesDir/projects/<ชื่อ>/state.json + meta.json + ไฟล์ PNG ของแต่ละภาพ
 * ใช้รูปแบบข้อมูลเดียวกับเซฟอัตโนมัติ (AutoSave) แต่แยกโฟลเดอร์ จึงไม่ปนกับงานที่ค้างไว้
 * ฟังก์ชันที่แตะไฟล์ทั้งหมดต้องเรียกใน Dispatchers.IO
 */
object ProjectStore {
    private const val DIR = "projects"
    private const val META_FILE = "meta.json"
    private const val AUDIO_DIR = "audio"

    private fun root(context: Context): File = File(context.filesDir, DIR)

    /** ตัดอักขระที่ใช้เป็นชื่อโฟลเดอร์ไม่ได้ ชื่อที่ได้ไม่ขึ้นต้นด้วยจุด และยาวไม่เกิน 40 ตัวอักษร */
    fun cleanName(raw: String): String =
        raw.replace(Regex("[\\\\/:*?\"<>|\\p{Cntrl}]"), "").trim().trimStart('.').take(40).trim()

    fun list(context: Context): List<SavedProject> {
        val dirs = root(context).listFiles() ?: return emptyList()
        return dirs
            .filter { it.isDirectory && !it.name.startsWith(".") && File(it, AutoSave.JSON_FILE).isFile }
            .map { d ->
                val meta = runCatching { JSONObject(File(d, META_FILE).readText(Charsets.UTF_8)) }.getOrNull()
                SavedProject(
                    name = d.name,
                    savedAt = File(d, AutoSave.JSON_FILE).lastModified(),
                    parts = meta?.optInt("parts", 0) ?: 0,
                    frames = meta?.optInt("frames", 0) ?: 0,
                )
            }
            .sortedByDescending { it.savedAt }
    }

    fun exists(context: Context, rawName: String): Boolean {
        val name = cleanName(rawName)
        return name.isNotEmpty() && File(File(root(context), name), AutoSave.JSON_FILE).isFile
    }

    /**
     * บันทึก (ชื่อซ้ำ = เขียนทับงานเดิม) เขียนลงโฟลเดอร์ชั่วคราวก่อนแล้วค่อยสลับ
     * ถ้าเขียนไม่สำเร็จ งานเดิมที่ชื่อเดียวกันจะไม่เสีย คืนชื่อที่ใช้บันทึกจริง (หลังตัดอักขระต้องห้าม)
     */
    fun save(context: Context, rawName: String, snap: AutoSaveSnapshot, parts: Int, frames: Int): String {
        val name = cleanName(rawName)
        if (name.isEmpty()) throw IOException("ชื่องานไม่ถูกต้อง")
        val base = root(context)
        if (!base.exists() && !base.mkdirs()) throw IOException("สร้างโฟลเดอร์เก็บงานไม่ได้")

        val target = File(base, name)
        val tmp = File(base, ".tmp_$name")
        val old = File(base, ".old_$name")
        tmp.deleteRecursively()
        old.deleteRecursively()
        if (!tmp.mkdirs()) throw IOException("สร้างโฟลเดอร์ชั่วคราวไม่ได้")
        try {
            for ((file, bmp) in snap.images) {
                FileOutputStream(File(tmp, file)).use {
                    if (!bmp.compress(Bitmap.CompressFormat.PNG, 100, it)) throw IOException("เข้ารหัส PNG ไม่สำเร็จ")
                }
            }
            val audioNames = snap.audioFiles.distinct()
            if (audioNames.isNotEmpty()) { // คัดลอกไฟล์เสียงที่ใช้อยู่เข้าโฟลเดอร์งาน (งานจึงพกเสียงไปด้วย)
                val ad = File(tmp, AUDIO_DIR)
                if (!ad.mkdirs()) throw IOException("สร้างโฟลเดอร์เสียงไม่ได้")
                for (n in audioNames) {
                    val src = AudioStore.fileOf(n) ?: continue
                    if (src.isFile) src.copyTo(File(ad, n), overwrite = true)
                }
            }
            File(tmp, META_FILE).writeText(
                JSONObject().put("parts", parts).put("frames", frames).toString(),
                Charsets.UTF_8,
            )
            File(tmp, AutoSave.JSON_FILE).writeText(snap.json, Charsets.UTF_8) // เขียนไฟล์หลักเป็นไฟล์สุดท้าย ถ้ามีไฟล์นี้แปลว่าเขียนครบแล้ว

            if (target.exists() && !target.renameTo(old)) throw IOException("สลับงานเดิมไม่สำเร็จ")
            if (!tmp.renameTo(target)) {
                old.renameTo(target) // เอางานเดิมกลับคืน
                throw IOException("บันทึกงานไม่สำเร็จ")
            }
            old.deleteRecursively()
        } catch (e: Throwable) {
            tmp.deleteRecursively()
            throw e
        }
        return name
    }

    /** อ่านงานที่เซฟไว้ (ยังไม่ใส่เข้าแอป: ให้เรียก AutoSave.apply บน main thread ต่อ) */
    fun read(context: Context, name: String): Restored {
        val dir = File(root(context), cleanName(name))
        // ไฟล์เสียงของงานนี้: คัดลอกเข้าที่เก็บเสียงของแอป (ถ้ายังไม่มี) ให้ AutoSave.apply หาเจอ
        File(dir, AUDIO_DIR).listFiles()?.forEach { f ->
            val dst = AudioStore.fileOf(f.name)
            if (f.isFile && dst != null && !dst.isFile) {
                AudioStore.dir(context)
                runCatching { f.copyTo(dst, overwrite = false) }
            }
        }
        return AutoSave.readFrom(dir) ?: throw IOException("ไม่พบงานที่เซฟไว้ชื่อ \"$name\"")
    }

    fun delete(context: Context, name: String) {
        val clean = cleanName(name)
        if (clean.isEmpty()) return
        val dir = File(root(context), clean)
        if (dir.exists() && !dir.deleteRecursively()) throw IOException("ลบงานไม่สำเร็จ")
    }
}
