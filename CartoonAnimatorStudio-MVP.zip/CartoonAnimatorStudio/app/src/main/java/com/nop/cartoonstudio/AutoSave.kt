package com.nop.cartoonstudio

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.ui.geometry.Offset
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.FileOutputStream
import java.io.IOException
import java.util.WeakHashMap

/** ข้อมูลที่จับไว้ ณ ตอนหนึ่ง (จับบน main thread แล้วค่อยเขียนลงไฟล์ใน thread อื่น) */
class AutoSaveSnapshot(val json: String, val images: Map<String, Bitmap>)

class RestoredImage(val bmp: Bitmap, val x: Float, val y: Float, val rotation: Float, val scale: Float)
class RestoredBone(
    val id: Int, val parent: Int, val length: Float, val angle: Float, val locked: Boolean, val images: List<RestoredImage>,
    val role: String = "NORMAL", val name: String = "",
)
class RestoredPart(
    val id: Int, val name: String, val parent: Int, val bmp: Bitmap,
    val x: Float, val y: Float, val pivotX: Float, val pivotY: Float, val restRotation: Float, val boneLength: Float,
    val hasTip: Boolean, val tipX: Float, val tipY: Float, val scale: Float, val flipX: Boolean, val visible: Boolean,
    val characterId: Int, val characterName: String,
    val mirrorH: Boolean = false, val mirrorV: Boolean = false, val charScale: Float = 1f,
    val role: String = "NORMAL", val homeRest: Float = 0f,
)
class Restored(
    val bones: List<RestoredBone>,
    val parts: List<RestoredPart>,
    val frames: List<Map<Int, Pose>>,
    val speed: List<SpeedRange>,
    val vm: JSONObject,
    val paths: List<MotionPath> = emptyList(), // เส้นทางเคลื่อนที่ (ไฟล์เซฟเก่าไม่มี = ว่าง)
)

/**
 * เซฟงานที่ทำค้างไว้อัตโนมัติ (โครงกระดูก + ภาพ + ตัวละครในฉาก + เฟรม/ท่า + ค่าตั้งต่างๆ)
 * ไว้ที่ filesDir/autosave เพื่อให้เปิดแอปใหม่ (แม้ระบบปิดแอปตอนอยู่เบื้องหลัง) แล้วงานยังอยู่
 * ภาพ PNG เขียนครั้งเดียวต่อภาพ (ตั้งชื่อไฟล์ตามตัว Bitmap) ส่วน state.json เขียนใหม่ทุกครั้งที่ข้อมูลเปลี่ยน
 */
object AutoSave {
    private const val DIR = "autosave"
    internal const val JSON_FILE = "state.json"
    private const val VERSION = 1

    private val lock = Any() // กันเขียน/อ่านไฟล์ชนกัน
    private val nameLock = Any() // เฉพาะ names/counter (สั้นๆ) เพื่อไม่ให้ main thread รอตอนกำลังเข้ารหัส PNG
    private val names = WeakHashMap<Bitmap, String>() // Bitmap -> ชื่อไฟล์ PNG
    private val onDisk = HashSet<String>() // ชื่อไฟล์ที่เขียนลงดิสก์แล้ว
    private var counter = 0
    private var lastJson: String? = null

    private const val ERR_FILE = "autosave_error.txt"

    /** จดสาเหตุที่เซฟไม่สำเร็จลงไฟล์ (ตอนออกจากแอปแสดง Toast ไม่ได้) ครั้งหน้าที่เปิดแอปจะอ่านมาแจ้ง */
    fun noteError(context: Context, msg: String) {
        runCatching { File(context.filesDir, ERR_FILE).writeText(msg, Charsets.UTF_8) }
    }

    /** อ่านแล้วลบข้อความผิดพลาดที่จดไว้ คืน null ถ้าไม่มี */
    fun takeError(context: Context): String? {
        val f = File(context.filesDir, ERR_FILE)
        if (!f.isFile) return null
        val t = runCatching { f.readText(Charsets.UTF_8) }.getOrNull()
        f.delete()
        return t?.takeIf { it.isNotBlank() }
    }

    /** จับสถานะปัจจุบัน: เรียกบน main thread (อ่านค่า Compose state) */
    fun capture(vm: EditorViewModel): AutoSaveSnapshot {
        val images = LinkedHashMap<String, Bitmap>()
        fun nameOf(bmp: Bitmap): String = synchronized(nameLock) {
            val n = names.getOrPut(bmp) { "img${counter++}.png" }
            images[n] = bmp
            n
        }

        val bones = JSONArray()
        for (b in vm.skeleton.bones) {
            val imgs = JSONArray()
            for (img in b.images) {
                imgs.put(
                    JSONObject()
                        .put("file", nameOf(img.bitmap))
                        .put("x", img.x.toDouble())
                        .put("y", img.y.toDouble())
                        .put("rotation", img.rotation.toDouble())
                        .put("scale", img.scale.toDouble()),
                )
            }
            bones.put(
                JSONObject()
                    .put("id", b.id)
                    .put("parent", b.parentId ?: -1)
                    .put("length", b.length.toDouble())
                    .put("angle", b.angle.toDouble())
                    .put("locked", b.lengthLocked)
                    .put("role", b.role.name)
                    .put("name", b.name)
                    .put("images", imgs),
            )
        }

        val parts = JSONArray()
        for (p in vm.project.parts) {
            parts.put(
                JSONObject()
                    .put("id", p.id)
                    .put("name", p.name)
                    .put("parent", p.parentId ?: -1)
                    .put("file", nameOf(p.bitmap))
                    .put("x", p.x.toDouble())
                    .put("y", p.y.toDouble())
                    .put("pivotX", p.pivotX.toDouble())
                    .put("pivotY", p.pivotY.toDouble())
                    .put("restRotation", p.restRotation.toDouble())
                    .put("boneLength", p.boneLength.toDouble())
                    .put("hasTip", p.hasTip)
                    .put("tipX", p.tipX.toDouble())
                    .put("tipY", p.tipY.toDouble())
                    .put("scale", p.scale.toDouble())
                    .put("flipX", p.flipX)
                    .put("visible", p.visible)
                    .put("characterId", p.characterId)
                    .put("characterName", p.characterName)
                    .put("mirrorH", p.mirrorH)
                    .put("mirrorV", p.mirrorV)
                    .put("cscale", p.charScale.toDouble())
                    .put("role", p.role.name)
                    .put("homeRest", p.homeRest.toDouble()),
            )
        }

        val frames = JSONArray()
        for (f in vm.project.frames) {
            val fo = JSONArray()
            for (e in f.entries.sortedBy { it.key }) { // เรียงตาม id ให้ผลคงที่ (ใช้เทียบว่าข้อมูลเปลี่ยนไหม)
                val pj = JSONArray()
                    .put(e.key)
                    .put(e.value.rotation.toDouble())
                    .put(e.value.dx.toDouble())
                    .put(e.value.dy.toDouble())
                val flags = (if (e.value.flipH) 1 else 0) or (if (e.value.flipV) 2 else 0)
                if (flags != 0) pj.put(flags) // เขียนเฉพาะเมื่อมีการพลิก ไฟล์เก่า/ท่าปกติขนาดเท่าเดิม
                fo.put(pj)
            }
            frames.put(fo)
        }

        val speed = JSONArray()
        for (r in vm.project.speedRanges) speed.put(JSONArray().put(r.start).put(r.end).put(r.fps.toDouble()))

        val paths = JSONArray()
        for (mp in vm.project.paths) {
            val pts = JSONArray()
            for (o in mp.points) pts.put(JSONArray().put(o.x.toDouble()).put(o.y.toDouble()))
            paths.put(
                JSONObject()
                    .put("char", mp.characterId)
                    .put("pts", pts)
                    .put("smooth", mp.smooth)
                    .put("start", mp.startFrame)
                    .put("end", mp.endFrame)
                    .put("frameT", JSONArray().also { a -> for (t in mp.frameT) a.put(t.toDouble()) })
                    .put("heading", mp.followHeading)
                    .put("closed", mp.closed)
                    .put("baseRot", mp.baseRotation.toDouble())
                    .put("headingWritten", mp.headingWritten),
            )
        }

        val v = JSONObject()
            .put("fps", vm.fps.toDouble())
            .put("videoW", vm.videoWidth)
            .put("videoH", vm.videoHeight)
            .put("onion", vm.onionOpacity.toDouble())
            .put("currentFrame", vm.currentFrame)
            .put("zoom", vm.zoom.toDouble())
            .put("panX", vm.pan.x.toDouble())
            .put("panY", vm.pan.y.toDouble())
            .put("tool", vm.tool.name)
            .put("mode", vm.mode.name)
            .put("selectedId", vm.selectedId ?: -1)
            .put("loop", vm.loop)
            .put("boneEditorOpen", vm.boneEditorOpen)

        val json = JSONObject()
            .put("version", VERSION)
            .put("vm", v)
            .put("bones", bones)
            .put("parts", parts)
            .put("frames", frames)
            .put("speed", speed)
            .put("paths", paths)
            .toString()
        return AutoSaveSnapshot(json, images)
    }

    /** เขียนลงไฟล์ (เรียกใน thread ไหนก็ได้ ไม่แตะ Compose state) ถ้าข้อมูลเหมือนครั้งก่อนจะข้าม */
    fun write(context: Context, snap: AutoSaveSnapshot) {
        synchronized(lock) { doWrite(context, snap) }
    }

    private fun doWrite(context: Context, snap: AutoSaveSnapshot) {
        val dir = File(context.filesDir, DIR)
        if (!dir.exists() && !dir.mkdirs()) throw IOException("สร้างโฟลเดอร์ autosave ไม่ได้")
        val imagesOk = snap.images.keys.all { it in onDisk && File(dir, it).isFile }
        if (snap.json == lastJson && imagesOk) return

        for ((name, bmp) in snap.images) {
            if (name in onDisk && File(dir, name).isFile) continue
            val tmp = File(dir, "$name.tmp")
            FileOutputStream(tmp).use {
                if (!bmp.compress(Bitmap.CompressFormat.PNG, 100, it)) throw IOException("เข้ารหัส PNG ไม่สำเร็จ")
            }
            if (!tmp.renameTo(File(dir, name))) {
                tmp.delete()
                throw IOException("บันทึกภาพ $name ไม่สำเร็จ")
            }
            onDisk.add(name)
        }

        val tmpJson = File(dir, "$JSON_FILE.tmp")
        tmpJson.writeText(snap.json, Charsets.UTF_8)
        if (!tmpJson.renameTo(File(dir, JSON_FILE))) { // rename ทับไฟล์เดิมแบบสมบูรณ์ ไม่ให้ไฟล์ครึ่งๆ กลางๆ
            tmpJson.delete()
            throw IOException("บันทึก state.json ไม่สำเร็จ")
        }
        lastJson = snap.json
        File(context.filesDir, ERR_FILE).delete() // เซฟสำเร็จแล้ว ข้อความผิดพลาดเก่าไม่ต้องแจ้งอีก

        // เก็บกวาด PNG ที่ไม่มีอะไรอ้างถึงแล้ว (ทำหลังเขียน json สำเร็จเท่านั้น)
        val keep = snap.images.keys
        dir.listFiles()?.forEach { f ->
            if (f.name.endsWith(".png") && f.name !in keep) {
                f.delete()
                onDisk.remove(f.name)
            }
        }
    }

    /** อ่าน autosave (เรียกใน Dispatchers.IO) คืน null ถ้ายังไม่มี ไม่แตะ Compose state */
    fun read(context: Context): Restored? = synchronized(lock) { doRead(File(context.filesDir, DIR), register = true) }

    /**
     * อ่านงานที่เซฟไว้เองจากโฟลเดอร์ dir (ดู ProjectStore) เรียกใน Dispatchers.IO คืน null ถ้าไม่มีไฟล์
     * ไม่ลงทะเบียนชื่อไฟล์ภาพเข้าระบบเซฟอัตโนมัติ (ชื่อไฟล์ในโฟลเดอร์นี้อาจชนกับของ autosave ได้)
     */
    fun readFrom(dir: File): Restored? = synchronized(lock) { doRead(dir, register = false) }

    private fun doRead(dir: File, register: Boolean): Restored? {
        val jf = File(dir, JSON_FILE)
        if (!jf.isFile) return null
        val root = JSONObject(jf.readText(Charsets.UTF_8))

        var maxIdx = -1
        fun bmp(file: String): Bitmap {
            if (file.contains('/') || file.contains('\\') || file.contains("..")) throw IOException("ชื่อไฟล์ภาพไม่ถูกต้อง")
            val b = BitmapFactory.decodeFile(File(dir, file).path) ?: throw IOException("อ่านภาพ $file ไม่ได้")
            if (register) {
                synchronized(nameLock) { names[b] = file }
                onDisk.add(file)
                Regex("img(\\d+)\\.png").matchEntire(file)?.groupValues?.get(1)?.toIntOrNull()?.let { if (it > maxIdx) maxIdx = it }
            }
            return b
        }

        val bones = ArrayList<RestoredBone>()
        val ba = root.getJSONArray("bones")
        for (i in 0 until ba.length()) {
            val o = ba.getJSONObject(i)
            val imgs = ArrayList<RestoredImage>()
            val ia = o.optJSONArray("images")
            if (ia != null) {
                for (j in 0 until ia.length()) {
                    val io = ia.getJSONObject(j)
                    imgs.add(
                        RestoredImage(
                            bmp(io.getString("file")),
                            io.optDouble("x", 0.0).toFloat(),
                            io.optDouble("y", 0.0).toFloat(),
                            io.optDouble("rotation", 0.0).toFloat(),
                            io.optDouble("scale", 1.0).toFloat(),
                        ),
                    )
                }
            }
            bones.add(
                RestoredBone(
                    o.getInt("id"), o.optInt("parent", -1),
                    o.getDouble("length").toFloat(), o.getDouble("angle").toFloat(),
                    o.optBoolean("locked", false), imgs,
                    o.optString("role", "NORMAL"), o.optString("name", ""),
                ),
            )
        }

        val parts = ArrayList<RestoredPart>()
        val pa = root.getJSONArray("parts")
        for (i in 0 until pa.length()) {
            val o = pa.getJSONObject(i)
            parts.add(
                RestoredPart(
                    id = o.getInt("id"),
                    name = o.optString("name", ""),
                    parent = o.optInt("parent", -1),
                    bmp = bmp(o.getString("file")),
                    x = o.optDouble("x", 0.0).toFloat(),
                    y = o.optDouble("y", 0.0).toFloat(),
                    pivotX = o.optDouble("pivotX", 0.0).toFloat(),
                    pivotY = o.optDouble("pivotY", 0.0).toFloat(),
                    restRotation = o.optDouble("restRotation", 0.0).toFloat(),
                    boneLength = o.optDouble("boneLength", 0.0).toFloat(),
                    hasTip = o.optBoolean("hasTip", false),
                    tipX = o.optDouble("tipX", 0.0).toFloat(),
                    tipY = o.optDouble("tipY", 0.0).toFloat(),
                    scale = o.optDouble("scale", 1.0).toFloat(),
                    flipX = o.optBoolean("flipX", false),
                    visible = o.optBoolean("visible", true),
                    characterId = o.optInt("characterId", 0),
                    characterName = o.optString("characterName", ""),
                    mirrorH = o.optBoolean("mirrorH", false),
                    mirrorV = o.optBoolean("mirrorV", false),
                    charScale = o.optDouble("cscale", 1.0).toFloat(),
                    role = o.optString("role", "NORMAL"),
                    homeRest = o.optDouble("homeRest", 0.0).toFloat(),
                ),
            )
        }

        val frames = ArrayList<Map<Int, Pose>>()
        val fa = root.getJSONArray("frames")
        for (i in 0 until fa.length()) {
            val fo = fa.getJSONArray(i)
            val m = HashMap<Int, Pose>()
            for (j in 0 until fo.length()) {
                val e = fo.getJSONArray(j)
                val flags = if (e.length() > 4) e.getInt(4) else 0
                m[e.getInt(0)] = Pose(
                    rotation = e.getDouble(1).toFloat(),
                    dx = e.getDouble(2).toFloat(),
                    dy = e.getDouble(3).toFloat(),
                    flipH = (flags and 1) != 0,
                    flipV = (flags and 2) != 0,
                )
            }
            frames.add(m)
        }

        val speed = ArrayList<SpeedRange>()
        val sa = root.optJSONArray("speed")
        if (sa != null) {
            for (i in 0 until sa.length()) {
                val e = sa.getJSONArray(i)
                speed.add(SpeedRange(e.getInt(0), e.getInt(1), e.getDouble(2).toFloat()))
            }
        }

        if (register) {
            synchronized(nameLock) { counter = maxIdx + 1 } // ชื่อไฟล์ภาพใหม่ต้องไม่ชนของเดิม
            lastJson = null
        }
        val paths = ArrayList<MotionPath>()
        val pathArr = root.optJSONArray("paths")
        if (pathArr != null) {
            for (i in 0 until pathArr.length()) {
                val o = pathArr.getJSONObject(i)
                val pj = o.getJSONArray("pts")
                val pts = ArrayList<Offset>()
                for (j in 0 until pj.length()) {
                    val e = pj.getJSONArray(j)
                    pts.add(Offset(e.getDouble(0).toFloat(), e.getDouble(1).toFloat()))
                }
                paths.add(
                    MotionPath(
                        characterId = o.getInt("char"),
                        points = pts,
                        smooth = o.optBoolean("smooth", true),
                        startFrame = o.optInt("start", 0),
                        endFrame = o.optInt("end", 0),
                        frameT = o.optJSONArray("frameT")?.let { a -> List(a.length()) { i -> a.getDouble(i).toFloat() } } ?: emptyList(),
                        followHeading = o.optBoolean("heading", false),
                        closed = o.optBoolean("closed", false),
                        baseRotation = o.optDouble("baseRot", 0.0).toFloat(),
                        headingWritten = o.optBoolean("headingWritten", false),
                    ),
                )
            }
        }
        return Restored(bones, parts, frames, speed, root.getJSONObject("vm"), paths)
    }

    /** ใส่ข้อมูลที่อ่านมาเข้า vm: เรียกบน main thread เท่านั้น (id ถูกกำหนดใหม่ แต่ความสัมพันธ์พ่อ-ลูกและท่าคงเดิม) */
    fun apply(vm: EditorViewModel, r: Restored) {
        // --- โครงกระดูก (เติมกระดูกที่ parent ถูกเติมแล้วก่อน แล้วคืนลำดับชั้นตามที่เซฟไว้) ---
        val sk = Skeleton()
        val boneIdMap = HashMap<Int, Int>()
        val pending = ArrayList(r.bones)
        var progress = true
        while (pending.isNotEmpty() && progress) {
            progress = false
            val iter = pending.iterator()
            while (iter.hasNext()) {
                val rb = iter.next()
                if (rb.parent != -1 && !boneIdMap.containsKey(rb.parent)) continue
                val bone = sk.add(if (rb.parent == -1) null else boneIdMap[rb.parent], rb.length, rb.angle)
                bone.lengthLocked = rb.locked
                bone.role = runCatching { BoneRole.valueOf(rb.role) }.getOrDefault(BoneRole.NORMAL)
                bone.name = rb.name
                for (ri in rb.images) {
                    val img = BoneImage(ri.bmp)
                    img.x = ri.x
                    img.y = ri.y
                    img.rotation = ri.rotation
                    img.scale = ri.scale
                    bone.images.add(img)
                }
                boneIdMap[rb.id] = bone.id
                iter.remove()
                progress = true
            }
        }
        if (pending.isNotEmpty()) throw IOException("autosave เสียหาย (โครงกระดูกไม่ครบ)")
        sk.reorder(r.bones.mapNotNull { boneIdMap[it.id] })
        vm.skeleton.replaceWith(sk)

        // --- ตัวละครในฉากแอนิเมต ---
        val project = vm.project
        project.clear()
        val partIdMap = HashMap<Int, Int>()
        val charIdMap = HashMap<Int, Int>()
        for (rp in r.parts) {
            val p = project.addPart(rp.name, rp.bmp)
            p.pivotX = rp.pivotX
            p.pivotY = rp.pivotY
            p.x = rp.x
            p.y = rp.y
            p.restRotation = rp.restRotation
            p.boneLength = rp.boneLength
            p.hasTip = rp.hasTip
            p.tipX = rp.tipX
            p.tipY = rp.tipY
            p.scale = rp.scale
            p.flipX = rp.flipX
            p.visible = rp.visible
            p.mirrorH = rp.mirrorH
            p.mirrorV = rp.mirrorV
            p.charScale = rp.charScale
            p.role = runCatching { BoneRole.valueOf(rp.role) }.getOrDefault(BoneRole.NORMAL)
            p.homeRest = rp.homeRest
            if (rp.characterId != 0) {
                p.characterId = charIdMap.getOrPut(rp.characterId) { project.newCharacterId() }
                p.characterName = rp.characterName
            }
            partIdMap[rp.id] = p.id
        }
        for (rp in r.parts) {
            if (rp.parent == -1) continue
            project.part(partIdMap[rp.id])?.parentId = partIdMap[rp.parent]
        }
        r.frames.forEachIndexed { i, fm ->
            val map = if (i == 0) project.frames[0] else mutableStateMapOf<Int, Pose>().also { project.frames.add(it) }
            for ((oldId, pose) in fm) partIdMap[oldId]?.let { map[it] = pose }
        }
        project.speedRanges.addAll(r.speed)
        for (rp in r.paths) { // เส้นทาง: เลขตัวละครถูกกำหนดใหม่ตอนโหลด จึงแปลงตามตาราง และคุมช่วงเฟรมไม่ให้เกินจำนวนเฟรมที่มี
            val cid = charIdMap[rp.characterId] ?: continue
            val last = project.frameCount - 1
            val s0 = rp.startFrame.coerceIn(0, last)
            project.paths.add(rp.copy(characterId = cid, startFrame = s0, endFrame = rp.endFrame.coerceIn(s0, last)))
        }

        // --- ค่าตั้งต่างๆ ---
        val v = r.vm
        vm.playing = false
        vm.fps = v.optDouble("fps", 12.0).toFloat().coerceIn(FPS_MIN, FPS_MAX)
        vm.videoWidth = v.optInt("videoW", vm.videoWidth)
        vm.videoHeight = v.optInt("videoH", vm.videoHeight)
        vm.onionOpacity = v.optDouble("onion", 0.3).toFloat()
        vm.loop = v.optBoolean("loop", true)
        vm.currentFrame = v.optInt("currentFrame", 0).coerceIn(0, project.frameCount - 1)
        vm.playhead = vm.currentFrame.toFloat()
        runCatching { Tool.valueOf(v.optString("tool")) }.getOrNull()?.let { vm.tool = it }
        runCatching { Mode.valueOf(v.optString("mode")) }.getOrNull()?.let { vm.mode = it }
        vm.selectedCharacterId = null
        if (vm.tool == Tool.CHAR_ROTATE || vm.tool == Tool.CHAR_SCALE) vm.tool = Tool.MOVE // เครื่องมือหมุน/ขยายใช้ได้ตอนเปิดเมนูตัวละครเท่านั้น
        vm.selectedId = v.optInt("selectedId", -1).takeIf { it != -1 }?.let { partIdMap[it] }
        vm.restoreView(
            v.optDouble("zoom", 1.0).toFloat().coerceIn(0.1f, 20f),
            Offset(v.optDouble("panX", 0.0).toFloat(), v.optDouble("panY", 0.0).toFloat()),
        )
        vm.boneEditorOpen = v.optBoolean("boneEditorOpen", false)
        vm.clearHistory() // โหลดงานใหม่เข้ามา ประวัติย้อนกลับของงานเดิมใช้ไม่ได้แล้ว
    }

    /** autosave อ่านไม่ได้: ย้ายโฟลเดอร์ไปเก็บไว้ (autosave_failed) กันถูกเขียนทับ แล้วเริ่มใหม่ */
    fun quarantine(context: Context) {
        synchronized(lock) {
            val dir = File(context.filesDir, DIR)
            val bad = File(context.filesDir, "autosave_failed")
            bad.deleteRecursively()
            if (dir.exists() && !dir.renameTo(bad)) dir.deleteRecursively()
            synchronized(nameLock) {
                names.clear()
                counter = 0
            }
            onDisk.clear()
            lastJson = null
        }
    }
}
