package com.nop.cartoonstudio

import java.io.ByteArrayOutputStream
import java.io.OutputStream
import java.util.zip.CRC32
import java.util.zip.Deflater

/**
 * ตัวเข้ารหัส APNG (PNG เคลื่อนไหว) ที่เขียนเอง ไม่พึ่งไลบรารีและไม่ใช้คลาสของ Android (ทดสอบบน JVM ได้)
 *
 * - โปร่งใสเต็ม 8 บิตต่อพิกเซล (RGBA) ขอบเนียนกว่า GIF มาก
 * - ทุกเฟรมเต็มขนาด blend = SOURCE (ทับแทนที่ ไม่ผสม) dispose = NONE จึงไม่มีภาพเฟรมก่อนค้าง แม้เฟรมโปร่งใส
 * - เฟรมแรกเป็น IDAT ด้วย ผู้ดูที่เล่น APNG ไม่ได้จะเห็นเป็นรูปนิ่งเฟรมแรก
 */
object ApngEncoder {
    private val SIGNATURE = byteArrayOf(0x89.toByte(), 0x50, 0x4E, 0x47, 0x0D, 0x0A, 0x1A, 0x0A)

    /**
     * @param renderFrame เติมพิกเซล ARGB (ไม่ใช่ premultiplied) ของเฟรมที่ k ลง px (ขนาด w*h)
     * @param delaysMs เวลาของแต่ละเฟรมเป็นมิลลิวินาที
     * @param loopTotal จำนวนรอบที่เล่นทั้งหมด (0 = ไม่จำกัด)
     */
    fun encode(
        out: OutputStream,
        w: Int,
        h: Int,
        frameCount: Int,
        delaysMs: IntArray,
        loopTotal: Int,
        renderFrame: (Int, IntArray) -> Unit,
        onProgress: (Int, Int) -> Unit = { _, _ -> },
    ) {
        require(frameCount > 0 && w > 0 && h > 0)
        out.write(SIGNATURE)

        val ihdr = ByteArray(13)
        putInt(ihdr, 0, w)
        putInt(ihdr, 4, h)
        ihdr[8] = 8 // 8 บิตต่อช่อง
        ihdr[9] = 6 // RGBA
        chunk(out, "IHDR", ihdr)

        val actl = ByteArray(8)
        putInt(actl, 0, frameCount)
        putInt(actl, 4, loopTotal.coerceAtLeast(0))
        chunk(out, "acTL", actl)

        val px = IntArray(w * h)
        val stride = w * 4
        val raw = ByteArray((stride + 1) * h)
        var seq = 0
        for (k in 0 until frameCount) {
            renderFrame(k, px)

            val fctl = ByteArray(26)
            putInt(fctl, 0, seq++)
            putInt(fctl, 4, w)
            putInt(fctl, 8, h)
            putInt(fctl, 12, 0) // x
            putInt(fctl, 16, 0) // y
            putShort(fctl, 20, delaysMs[k].coerceIn(1, 65535)) // delay_num (ms)
            putShort(fctl, 22, 1000) // delay_den
            fctl[24] = 0 // dispose NONE
            fctl[25] = 0 // blend SOURCE
            chunk(out, "fcTL", fctl)

            val z = deflateFrame(px, w, h, raw)
            if (k == 0) {
                chunk(out, "IDAT", z, 0, z.size)
            } else {
                // fdAT = หมายเลขลำดับ 4 ไบต์ + ข้อมูลบีบอัด; แบ่งก้อนไม่ให้ใหญ่เกินไป
                var off = 0
                while (off < z.size) {
                    val len = minOf(z.size - off, 1 shl 20)
                    val body = ByteArray(4 + len)
                    putInt(body, 0, seq++)
                    System.arraycopy(z, off, body, 4, len)
                    chunk(out, "fdAT", body)
                    off += len
                }
            }
            onProgress(k + 1, frameCount)
        }
        chunk(out, "IEND", ByteArray(0))
        out.flush()
    }

    /** แปลงพิกเซลเป็นแถวสแกน (เลือกฟิลเตอร์ต่อแถว: None / Sub / Up ตามผลรวมค่าสัมบูรณ์ที่น้อยสุด) แล้วบีบอัด zlib */
    private fun deflateFrame(px: IntArray, w: Int, h: Int, raw: ByteArray): ByteArray {
        val stride = w * 4
        val none = ByteArray(stride)
        val sub = ByteArray(stride)
        val up = ByteArray(stride)
        var prev: ByteArray? = null
        val cur = ByteArray(stride)
        for (y in 0 until h) {
            var p = 0
            for (x in 0 until w) {
                val c = px[y * w + x]
                cur[p++] = (c shr 16).toByte()
                cur[p++] = (c shr 8).toByte()
                cur[p++] = c.toByte()
                cur[p++] = (c ushr 24).toByte()
            }
            var sNone = 0
            var sSub = 0
            var sUp = 0
            for (i in 0 until stride) {
                val v = cur[i].toInt()
                val left = if (i >= 4) cur[i - 4].toInt() else 0
                val above = if (prev != null) prev[i].toInt() else 0
                none[i] = v.toByte()
                sub[i] = (v - left).toByte()
                up[i] = (v - above).toByte()
                sNone += Math.abs(none[i].toInt())
                sSub += Math.abs(sub[i].toInt())
                sUp += Math.abs(up[i].toInt())
            }
            val base = y * (stride + 1)
            when {
                sUp <= sNone && sUp <= sSub && prev != null -> { raw[base] = 2; System.arraycopy(up, 0, raw, base + 1, stride) }
                sSub < sNone -> { raw[base] = 1; System.arraycopy(sub, 0, raw, base + 1, stride) }
                else -> { raw[base] = 0; System.arraycopy(none, 0, raw, base + 1, stride) }
            }
            prev = (prev ?: ByteArray(stride)).also { System.arraycopy(cur, 0, it, 0, stride) }
        }
        val d = Deflater(6)
        try {
            d.setInput(raw, 0, raw.size)
            d.finish()
            val bo = ByteArrayOutputStream(raw.size / 4 + 64)
            val buf = ByteArray(32 * 1024)
            while (!d.finished()) {
                val n = d.deflate(buf)
                bo.write(buf, 0, n)
            }
            return bo.toByteArray()
        } finally {
            d.end()
        }
    }

    private fun chunk(out: OutputStream, type: String, data: ByteArray, off: Int = 0, len: Int = data.size) {
        val t = type.toByteArray(Charsets.US_ASCII)
        val head = ByteArray(4)
        putInt(head, 0, len)
        out.write(head)
        out.write(t)
        out.write(data, off, len)
        val crc = CRC32()
        crc.update(t)
        crc.update(data, off, len)
        putInt(head, 0, crc.value.toInt())
        out.write(head)
    }

    private fun putInt(b: ByteArray, o: Int, v: Int) {
        b[o] = (v ushr 24).toByte()
        b[o + 1] = (v ushr 16).toByte()
        b[o + 2] = (v ushr 8).toByte()
        b[o + 3] = v.toByte()
    }

    private fun putShort(b: ByteArray, o: Int, v: Int) {
        b[o] = (v ushr 8).toByte()
        b[o + 1] = v.toByte()
    }
}
