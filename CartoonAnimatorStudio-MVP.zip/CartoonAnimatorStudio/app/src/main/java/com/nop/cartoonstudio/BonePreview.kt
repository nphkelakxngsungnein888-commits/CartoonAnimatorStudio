package com.nop.cartoonstudio

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.drawIntoCanvas
import androidx.compose.ui.graphics.drawscope.withTransform
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlin.math.cos
import kotlin.math.exp
import kotlin.math.sin

/**
 * ดูตัวอย่าง (รอบที่ 3): ลากที่ปลายกระดูก -> กระดูกหมุนรอบจุดโคนที่ยึดไว้ พร้อมภาพของมัน (ชิ้นเดียวกัน)
 * กระดูกที่พ่วงต่อตามไปด้วย ท่าที่ขยับเป็นแค่ตอนดูตัวอย่าง ไม่แก้โครงกระดูกจริง
 * ปุ่มกลม 3 ปุ่ม ลากเพื่อ หมุน / ขยาย / ย้าย ทั้งตัวละคร
 */
@Composable
fun BonePreview(skeleton: Skeleton, onClose: () -> Unit) {
    var canvasSize by remember { mutableStateOf(IntSize.Zero) }
    var tx by remember { mutableFloatStateOf(0f) }
    var ty by remember { mutableFloatStateOf(0f) }
    var rot by remember { mutableFloatStateOf(0f) }
    var charScale by remember { mutableFloatStateOf(1f) }
    var draggingId by remember { mutableStateOf<Int?>(null) }
    var dragPos by remember { mutableStateOf<Offset?>(null) }
    val paint = remember {
        android.graphics.Paint(android.graphics.Paint.FILTER_BITMAP_FLAG or android.graphics.Paint.ANTI_ALIAS_FLAG)
    }

    BackHandler(onBack = onClose)

    // เริ่มดูตัวอย่างด้วยท่าตั้งต้น (ยังไม่ขยับ)
    LaunchedEffect(Unit) { for (b in skeleton.bones) b.poseAngle = 0f }

    // จุดบนจอ <-> จุดในพิกัดโครงกระดูก (คิดการย้าย/หมุน/ขยายทั้งตัวละครด้วย)
    fun toSkel(o: Offset): Offset {
        val v = Offset(o.x - (canvasSize.width / 2f + tx), o.y - (canvasSize.height / 2f + ty)) / charScale
        val r = Math.toRadians(-rot.toDouble())
        val c = cos(r).toFloat()
        val s = sin(r).toFloat()
        return Offset(v.x * c - v.y * s, v.x * s + v.y * c)
    }

    fun toScreen(p: Offset): Offset {
        val r = Math.toRadians(rot.toDouble())
        val c = cos(r).toFloat()
        val s = sin(r).toFloat()
        val v = Offset(p.x * c - p.y * s, p.x * s + p.y * c) * charScale
        return Offset(v.x + canvasSize.width / 2f + tx, v.y + canvasSize.height / 2f + ty)
    }

    Box(
        Modifier
            .fillMaxSize()
            .systemBarsPadding()
            .background(Color(0xFF3A3A44))
            .pointerInput(Unit) { detectTapGestures { } }, // กันการสัมผัสทะลุไปหน้าด้านล่าง
    ) {
        Canvas(
            Modifier
                .fillMaxSize()
                .onSizeChanged { canvasSize = it }
                .pointerInput(skeleton) {
                    detectDragGestures(
                        onDragStart = { o ->
                            var best: Bone? = null
                            var bestD = 70f
                            for (b in skeleton.bones) {
                                val d = (toScreen(skeleton.tipOf(b, true)) - o).getDistance()
                                if (d < bestD) {
                                    bestD = d
                                    best = b
                                }
                            }
                            draggingId = best?.id
                            dragPos = o
                        },
                        onDragEnd = {
                            draggingId = null
                            dragPos = null
                        },
                        onDragCancel = {
                            draggingId = null
                            dragPos = null
                        },
                        onDrag = { change, _ ->
                            change.consume()
                            val b = skeleton.bone(draggingId)
                            if (b != null) {
                                skeleton.aimPose(b, toSkel(change.position))
                                dragPos = change.position
                            }
                        },
                    )
                },
        ) {
            val cx = this.size.width / 2f
            val cy = this.size.height / 2f
            // กรอบเวที
            drawRect(
                Color(0xFF00B8D4),
                topLeft = Offset(6f, 6f),
                size = Size(this.size.width - 12f, this.size.height - 12f),
                style = Stroke(width = 2f),
            )
            withTransform({
                translate(cx + tx, cy + ty)
                rotate(rot, Offset.Zero)
                scale(charScale, charScale, Offset.Zero)
            }) {
                drawIntoCanvas { c -> // ภาพ: หมุนไปกับกระดูก (ไม่มีกรอบ)
                    for (b in skeleton.bones) {
                        if (b.images.isEmpty()) continue
                        val base = skeleton.baseOf(b, true)
                        val ang = skeleton.worldAngle(b, true)
                        for (img in b.images) c.nativeCanvas.drawBitmap(img.bitmap, boneImageMatrix(img, base, ang), paint)
                    }
                }
                for (b in skeleton.bones) { // กระดูก: เส้นส้มบาง จุดปลาย
                    val a = skeleton.baseOf(b, true)
                    val t = skeleton.tipOf(b, true)
                    drawLine(Color(0xFFFF9800), a, t, strokeWidth = 3f)
                    drawCircle(Color(0xFFFF9800), radius = 5f, center = t)
                }
                drawCircle(Color(0xFFFF9800), radius = 7f, center = Offset.Zero)
            }
            val fingerPos = dragPos
            if (fingerPos != null) drawCircle(Color(0xFFFF00FF), radius = 14f, center = fingerPos) // จุดสีชมพูตรงนิ้ว
        }

        PreviewHandle(Color(0xFF76FF03), "หมุน", Modifier.align(Alignment.TopStart).padding(12.dp)) { d ->
            rot += d.x * 0.5f
        }
        PreviewHandle(Color(0xFFFFA000), "ขยาย", Modifier.align(Alignment.TopEnd).padding(12.dp)) { d ->
            charScale = (charScale * exp(d.x / 200f)).coerceIn(0.2f, 5f)
        }
        PreviewHandle(Color(0xFF29B6F6), "ย้าย", Modifier.align(Alignment.BottomEnd).padding(12.dp)) { d ->
            tx += d.x
            ty += d.y
        }

        Box(Modifier.align(Alignment.BottomStart).padding(12.dp)) {
            OutlinedButton(onClick = onClose) { Text("ปิด") }
        }
        Box(Modifier.align(Alignment.BottomCenter).padding(12.dp)) {
            OutlinedButton(onClick = {
                for (b in skeleton.bones) b.poseAngle = 0f
                tx = 0f
                ty = 0f
                rot = 0f
                charScale = 1f
            }) { Text("รีเซ็ตท่า") }
        }
    }
}

@Composable
private fun PreviewHandle(color: Color, label: String, modifier: Modifier, onDrag: (Offset) -> Unit) {
    Box(
        modifier
            .size(56.dp)
            .clip(CircleShape)
            .background(color)
            .pointerInput(Unit) {
                detectDragGestures { change, d ->
                    change.consume()
                    onDrag(d)
                }
            },
        contentAlignment = Alignment.Center,
    ) { Text(label, color = Color.White, fontSize = 12.sp) }
}
