package com.nop.cartoonstudio

import kotlin.math.abs
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.hypot
import kotlin.math.sin

/**
 * Adaptive Mesh Smart Joint Pin (หมุดข้อต่ออัจฉริยะ) — ใช้กับโหมดสร้างวิดีโอด้วยรูปภาพ
 *
 * หมุด 1 ตัว = ข้อต่อ 1 จุดบนภาพ (เช่น ข้อศอก เข่า คอ หาง): ส่วนที่อยู่ด้านหลังหมุดนิ่ง ส่วนที่อยู่ด้านหน้า (ตามทิศที่ตั้ง) หมุนรอบหมุดตามมุมงอ
 * ระหว่างสองส่วนมีช่วงผสมนุ่ม ๆ เป็นรูปพัดรอบหมุด (วัดเป็นมุมรอบหมุด ไม่ใช่ระยะ) จึงโค้งกลมเหมือนข้อต่อจริงและตาข่ายไม่พับ
 *
 * สูตรหลัก: จุดตาข่าย v (ตำแหน่งตั้งต้น) มีน้ำหนัก w(v) จาก 0 (ด้านนิ่ง) ถึง 1 (ด้านขยับ) ตามมุม α ระหว่าง (v − หมุด) กับทิศ:
 *   v' = หมุด + R(มุมงอ × w) · (v − หมุด)
 * วัดน้ำหนักเป็นมุม ทำให้ Jacobian = 1 ± มุมงอ × w′(α) ไม่ขึ้นกับระยะ → ไม่พับเมื่อ |มุมงอ| < 4/3 × ความนุ่ม (ทดสอบด้วยสคริปต์จำลองตรงกับสูตร)
 *
 * หมุดต่อเป็นสายได้ (ไหล่ → ศอก → ข้อมือ): หมุดลูกหมุนก่อน แล้วหมุดแม่หมุนทุกอย่างที่อยู่ในส่วนของมัน (รวมหมุดลูก) — เหมือนกระดูก
 * ตาข่ายแบบถี่ตามจุด (Adaptive): เส้นตาข่ายถี่ขึ้นรอบหมุดเพื่อให้ข้อต่อโค้งกลม ที่อื่นห่างลงโดยจำนวนช่องรวมเท่าเดิม
 *
 * ไฟล์นี้ไม่พึ่ง Android (ทดสอบบน JVM ได้)
 */
data class JointPin(
    val id: Int,
    val name: String = "",
    /** ตำแหน่งหมุด (พิกเซลของ bitmap ในภาพตั้งต้น) */
    val x: Float,
    val y: Float,
    /** ทิศไปทางส่วนที่ขยับ (องศา: 0 = ขวา, 90 = ลง, 180 = ซ้าย, 270 = ขึ้น) */
    val dirDeg: Float = 0f,
    /** ความนุ่มของข้อต่อ = ครึ่งความกว้างช่วงผสม (องศา 10–90): มากขึ้น = โค้งนุ่ม งอได้มาก · น้อยลง = หักคม งอได้น้อย */
    val soft: Float = 45f,
    /** ระยะส่งผล (พิกเซล) ส่วนที่ไกลจากหมุดเกินนี้ไม่ขยับตาม · 0 = ทั้งภาพ */
    val reach: Float = 0f,
    /** รัศมีที่ตาข่ายถี่รอบหมุด (พิกเซล) · 0 = อัตโนมัติ */
    val meshRadius: Float = 0f,
    /** หมุดแม่ที่ติดอยู่ (id) · 0 = ไม่ติดหมุดใด */
    val parentId: Int = 0,
    /** จำกัดมุมงอ (องศา) เช่น ข้อศอกงอได้ทางเดียว: ต่ำสุด 0 สูงสุด 120 */
    val minDeg: Float = -180f,
    val maxDeg: Float = 180f,
)

/** ชุดหมุดข้อต่อของคลิปหนึ่งคลิป + ตั้งค่าตาข่ายถี่ตามจุด */
data class PinRig(
    val pins: List<JointPin> = emptyList(),
    /** เปิดตาข่ายถี่ตามจุด */
    val adaptive: Boolean = true,
    /** ความถี่เพิ่มรอบหมุด (0–6): 3 = รอบหมุดถี่กว่าปกติ ≈ 4 เท่า */
    val density: Float = 3f,
)

object JointPins {
    const val MAX_PINS = 8
    const val SOFT_MIN = 10f
    const val SOFT_MAX = 90f
    const val DENSITY_MAX = 6f

    private const val DEG = 0.017453292f // องศา → เรเดียน
    private const val RAD = 57.29578f // เรเดียน → องศา
    private const val HALF_PI = 1.5707964f
    private const val SAFETY = 0.92f // เผื่อไว้จากมุมที่ทดสอบแล้วไม่พับพอดี

    // ───────────── สายหมุด (ลำดับขั้นพ่อ–ลูก) ─────────────

    fun indexOfId(pins: List<JointPin>, id: Int): Int = pins.indexOfFirst { it.id == id }

    /** ลำดับหมุดแม่ของหมุดลำดับ k: แม่, ยายถึงบรรพบุรุษ (กันวนซ้ำ) */
    fun ancestorsOf(pins: List<JointPin>, k: Int): List<Int> {
        val out = ArrayList<Int>()
        var cur = k
        while (out.size < pins.size) {
            val pid = pins[cur].parentId
            if (pid == 0) break
            val pi = indexOfId(pins, pid)
            if (pi < 0 || pi == k || pi in out) break
            out.add(pi)
            cur = pi
        }
        return out
    }

    /** ลำดับการคำนวณ: หมุดลูกก่อนหมุดแม่ (ลึกสุดก่อน) */
    fun order(pins: List<JointPin>): List<Int> =
        pins.indices.sortedByDescending { ancestorsOf(pins, it).size }

    /** หมุดนี้ถูกตั้งเป็นแม่ของ (หรือเป็นบรรพบุรุษของ) หมุดลำดับ k ไหม — ใช้กันเลือกแม่วนเป็นวง */
    fun isDescendant(pins: List<JointPin>, k: Int, ofIndex: Int): Boolean = ofIndex in ancestorsOf(pins, k)

    // ───────────── น้ำหนักของหมุด ─────────────

    /** น้ำหนักของจุด (x, y) (ตำแหน่งตั้งต้น) ต่อหมุดนี้: 0 = ด้านนิ่ง · 1 = ด้านขยับ · ระหว่างนั้น = ช่วงผสมนุ่ม */
    fun weight(pin: JointPin, x: Float, y: Float): Float {
        val qx = x - pin.x
        val qy = y - pin.y
        val r = hypot(qx, qy)
        if (r < 1e-3f) return 0.5f // ตรงหมุดพอดี: หมุนรอบตัวเองไม่ย้ายที่
        val rad = pin.dirDeg * DEG
        val dx = cos(rad)
        val dy = sin(rad)
        val dot = qx * dx + qy * dy
        val cr = abs(qx * dy - qy * dx)
        val al = atan2(cr, dot) // มุมจากทิศ 0..π
        val psi = pin.soft.coerceIn(SOFT_MIN, SOFT_MAX) * DEG
        val t = ((HALF_PI + psi - al) / (2f * psi)).coerceIn(0f, 1f)
        var w = t * t * (3f - 2f * t)
        if (pin.reach > 0f) {
            val s = ((r - pin.reach) / (0.25f * pin.reach)).coerceIn(0f, 1f)
            w *= 1f - s * s * (3f - 2f * s)
        }
        return w
    }

    // ───────────── ขีดจำกัดมุม ─────────────

    /** มุมงอสูงสุด (องศา) ที่ตาข่ายยังไม่พับ ตามความนุ่ม (ทดสอบแล้ว: ไม่พับถึง 4/3 × ความนุ่ม ไม่ขึ้นกับความละเอียดตาข่าย) */
    fun safeLimitDeg(pin: JointPin): Float = (SAFETY * 4f / 3f * pin.soft.coerceIn(SOFT_MIN, SOFT_MAX)).coerceAtMost(180f)

    /** ช่วงมุมที่ใช้ได้จริง = ช่วงที่ผู้ใช้จำกัด ∩ ช่วงที่ไม่พับ */
    fun minAngle(pin: JointPin): Float = maxOf(pin.minDeg, -safeLimitDeg(pin))
    fun maxAngle(pin: JointPin): Float = minOf(pin.maxDeg, safeLimitDeg(pin))

    fun clampAngle(pin: JointPin, a: Float): Float {
        val lo = minAngle(pin)
        val hi = maxAngle(pin)
        return if (hi < lo) lo else a.coerceIn(lo, hi)
    }

    // ───────────── คำนวณตาข่ายที่งอแล้ว ─────────────

    /**
     * ตาข่ายที่ใช้วาดจริง: ท่าที่ปั้นด้วยมือ (g.off) ถูกงอตามมุมของหมุดทุกตัว (g.pinAngles)
     * ไม่มีหมุด/ไม่มีมุมงอ = คืน g เดิม · ผลลัพธ์ไม่มี pinAngles (เป็นออฟเซ็ตล้วน ๆ) จึงใช้กับ drawBitmapMesh ได้ตรง ๆ
     */
    fun effective(rig: PinRig, w: Int, h: Int, g: SculptGrid?): SculptGrid? {
        if (g == null || rig.pins.isEmpty()) return g
        val pa = g.pinAngles ?: return g
        val pins = rig.pins
        val angles = FloatArray(pins.size) { pa.getOrNull(it) ?: 0f }
        if (angles.all { it == 0f }) return g
        val seq = order(pins).filter { angles[it] != 0f }
        val out = FloatArray(g.off.size)
        var n = 0
        for (j in 0..g.rows) for (i in 0..g.cols) {
            val rx = g.restX(i, w)
            val ry = g.restY(j, h)
            var cx = rx + g.off[2 * n]
            var cy = ry + g.off[2 * n + 1]
            for (k in seq) {
                val pin = pins[k]
                val wt = weight(pin, rx, ry) // น้ำหนักวัดจากตำแหน่งตั้งต้น: ส่วนไหนของภาพไม่เปลี่ยนตามการปั้น
                if (wt <= 0f) continue
                val th = angles[k] * wt * DEG
                val c = cos(th)
                val s = sin(th)
                val qx = cx - pin.x
                val qy = cy - pin.y
                cx = pin.x + qx * c - qy * s
                cy = pin.y + qx * s + qy * c
            }
            out[2 * n] = cx - rx
            out[2 * n + 1] = cy - ry
            n++
        }
        return SculptGrid(g.cols, g.rows, out, g.xs, g.ys)
    }

    /** ตำแหน่งบนภาพ (พิกเซล bitmap) หลังถูกหมุดตามรายการ chain หมุน: จุดเริ่มคือ (x, y) ตำแหน่งตั้งต้น */
    fun forward(rig: PinRig, g: SculptGrid?, x: Float, y: Float, chain: List<Int>): Pair<Float, Float> {
        var cx = x
        var cy = y
        for (k in chain) {
            val pin = rig.pins.getOrNull(k) ?: continue
            val a = g?.angleOf(k) ?: 0f
            if (a == 0f) continue
            val wt = weight(pin, x, y)
            if (wt <= 0f) continue
            val th = a * wt * DEG
            val c = cos(th)
            val s = sin(th)
            val qx = cx - pin.x
            val qy = cy - pin.y
            cx = pin.x + qx * c - qy * s
            cy = pin.y + qx * s + qy * c
        }
        return Pair(cx, cy)
    }

    /** ตำแหน่งหมุดลำดับ k ตอนนี้ (ขยับตามหมุดแม่) */
    fun pinPosition(rig: PinRig, g: SculptGrid?, k: Int): Pair<Float, Float> {
        val pin = rig.pins[k]
        return forward(rig, g, pin.x, pin.y, ancestorsOf(rig.pins, k))
    }

    /** ความยาวเส้นนำทาง (ที่จับสีเขียว) บนภาพ: พิกเซล bitmap */
    fun handleLength(pin: JointPin, w: Int, h: Int): Float {
        val base = maxOf(60f, 0.22f * maxOf(w, h))
        return if (pin.reach > 0f) minOf(base, maxOf(40f, pin.reach)) else base
    }

    /** ปลายที่จับสีเขียวตอนนี้ (ตามมุมงอของหมุดนี้และหมุดแม่) */
    fun handlePosition(rig: PinRig, g: SculptGrid?, k: Int, w: Int, h: Int): Pair<Float, Float> {
        val pin = rig.pins[k]
        val len = handleLength(pin, w, h)
        val rad = pin.dirDeg * DEG
        val ex = pin.x + cos(rad) * len
        val ey = pin.y + sin(rad) * len
        return forward(rig, g, ex, ey, listOf(k) + ancestorsOf(rig.pins, k))
    }

    /**
     * มุมงอ (องศา) ของหมุดลำดับ k ที่ทำให้ปลายที่จับชี้ไปทาง (tx, ty) ใช้ตอนลากที่จับสีเขียว
     * คิดจากทิศของเส้นนำทางที่ถูกหมุดแม่พาไปแล้ว (ไม่นับมุมของหมุดนี้)
     */
    fun angleToward(rig: PinRig, g: SculptGrid?, k: Int, w: Int, h: Int, tx: Float, ty: Float): Float {
        val pin = rig.pins[k]
        val anc = ancestorsOf(rig.pins, k)
        val (px, py) = forward(rig, g, pin.x, pin.y, anc)
        val len = handleLength(pin, w, h)
        val rad = pin.dirDeg * DEG
        val (ax, ay) = forward(rig, g, pin.x + cos(rad) * len, pin.y + sin(rad) * len, anc)
        val base = atan2(ay - py, ax - px)
        val target = atan2(ty - py, tx - px)
        var d = (target - base) * RAD
        while (d > 180f) d -= 360f
        while (d <= -180f) d += 360f
        return d
    }

    // ───────────── ตาข่ายถี่ตามจุด (Adaptive) ─────────────

    fun meshRadiusOf(pin: JointPin, w: Int, h: Int): Float =
        if (pin.meshRadius > 0f) pin.meshRadius else maxOf(30f, 0.18f * maxOf(w, h))

    /**
     * ตำแหน่งเส้นตาข่าย (สัดส่วน 0..1) ที่ถี่รอบหมุด: ความหนาแน่น = 1 + ความถี่ × (ก้อนรอบหมุดแต่ละตัว) แล้วแบ่งช่องให้เท่ากันตามความหนาแน่นสะสม
     * คืน (xs, ys) = (null, null) เมื่อไม่ต้องใช้ตาข่ายถี่ (ปิดไว้/ไม่มีหมุด) → ตาข่ายเว้นระยะเท่ากันแบบเดิม
     */
    fun layout(rig: PinRig, w: Int, h: Int, cols: Int, rows: Int): Pair<FloatArray?, FloatArray?> {
        if (!rig.adaptive || rig.pins.isEmpty() || rig.density <= 0f) return Pair(null, null)
        val gain = rig.density.coerceIn(0f, DENSITY_MAX)
        val cx = FloatArray(rig.pins.size) { rig.pins[it].x / w }
        val cy = FloatArray(rig.pins.size) { rig.pins[it].y / h }
        val hx = FloatArray(rig.pins.size) { meshRadiusOf(rig.pins[it], w, h) / w }
        val hy = FloatArray(rig.pins.size) { meshRadiusOf(rig.pins[it], w, h) / h }
        return Pair(breaksFor(cols, cx, hx, gain), breaksFor(rows, cy, hy, gain))
    }

    private fun breaksFor(n: Int, centers: FloatArray, halves: FloatArray, gain: Float): FloatArray {
        val steps = 1024
        val cum = FloatArray(steps + 1)
        var acc = 0f
        for (s in 0 until steps) {
            val u = (s + 0.5f) / steps
            var rho = 1f
            for (k in centers.indices) {
                val d = abs(u - centers[k])
                val hh = maxOf(halves[k], 1e-3f)
                val t = ((d - hh) / (0.5f * hh)).coerceIn(0f, 1f)
                rho += gain * (1f - t * t * (3f - 2f * t))
            }
            acc += rho
            cum[s + 1] = acc
        }
        val out = FloatArray(n + 1)
        var s = 0
        for (i in 0..n) {
            val target = acc * i / n
            while (s < steps - 1 && cum[s + 1] < target) s++
            val span = cum[s + 1] - cum[s]
            out[i] = ((s + if (span > 0f) ((target - cum[s]) / span).coerceIn(0f, 1f) else 0f) / steps).coerceIn(0f, 1f)
        }
        out[0] = 0f
        out[n] = 1f
        return out
    }

    /** ตาข่ายเปล่า (ไม่บิด) ที่ใช้รูปแบบเส้นตาข่ายตามหมุดของคลิป */
    fun zeroGrid(rig: PinRig, w: Int, h: Int, cols: Int, rows: Int): SculptGrid {
        val (xs, ys) = layout(rig, w, h, cols, rows)
        return SculptGrid.zero(cols, rows, xs, ys)
    }

    /** แปลงท่าที่มีอยู่ให้เข้ากับรูปแบบเส้นตาข่ายตามหมุดตอนนี้ (ไม่เปลี่ยนก็คืนอันเดิม) */
    fun relayout(rig: PinRig, w: Int, h: Int, g: SculptGrid?, cols: Int, rows: Int): SculptGrid? {
        if (g == null) return null
        val (xs, ys) = layout(rig, w, h, cols, rows)
        return Sculpt.resample(g, cols, rows, xs, ys)
    }

    // ───────────── ตัวช่วยแก้ชุดหมุด / มุมงอ ─────────────

    /** ตั้งมุมงอของหมุดลำดับ k ในท่านี้ (ไม่มีท่า = สร้างตาข่ายเปล่าตามรูปแบบหมุด) */
    fun withAngle(rig: PinRig, w: Int, h: Int, g: SculptGrid?, cols: Int, rows: Int, k: Int, deg: Float): SculptGrid {
        val base = g ?: zeroGrid(rig, w, h, cols, rows)
        val n = maxOf(rig.pins.size, base.pinAngles?.size ?: 0, k + 1)
        val a = FloatArray(n) { base.angleOf(it) }
        a[k] = deg
        return SculptGrid(base.cols, base.rows, base.off, base.xs, base.ys, a)
    }

    /** ลบมุมงอของหมุดลำดับ k ออกจากท่า (ตอนลบหมุด) */
    fun dropAngle(g: SculptGrid?, k: Int): SculptGrid? {
        val pa = g?.pinAngles ?: return g
        if (k >= pa.size) return g
        val a = FloatArray(pa.size - 1) { if (it < k) pa[it] else pa[it + 1] }
        return SculptGrid(g.cols, g.rows, g.off, g.xs, g.ys, a)
    }

    /** ตั้งมุมงอทุกหมุดเป็น 0 ในท่านี้ */
    fun clearAngles(g: SculptGrid?): SculptGrid? {
        if (g == null || g.pinAngles == null) return g
        return SculptGrid(g.cols, g.rows, g.off, g.xs, g.ys, null)
    }

    /** สร้างหมุดใหม่ที่จุด (x, y): ตั้งค่าเริ่มต้นให้ใช้ได้ทันที · ติดกับหมุดที่ครอบคลุมจุดนี้อยู่โดยอัตโนมัติ (ไม่ใช่ก็ไม่ติด) */
    fun newPin(rig: PinRig, w: Int, h: Int, x: Float, y: Float, dirDeg: Float?): JointPin {
        val id = (rig.pins.maxOfOrNull { it.id } ?: 0) + 1
        val dir = dirDeg ?: run {
            val dx = x - w / 2f
            val dy = y - h / 2f
            if (hypot(dx, dy) > 0.12f * maxOf(w, h)) atan2(dy, dx) * RAD else 0f
        }
        var parent = 0
        var best = Float.MAX_VALUE
        rig.pins.forEach { p ->
            if (weight(p, x, y) >= 0.9f) {
                val d = hypot(p.x - x, p.y - y)
                if (d < best) { best = d; parent = p.id }
            }
        }
        val dirNorm = ((dir % 360f) + 360f) % 360f
        return JointPin(id = id, name = "หมุด $id", x = x, y = y, dirDeg = dirNorm, parentId = parent)
    }

    /** ลบหมุดลำดับ k: หมุดลูกของมันย้ายไปติดกับแม่ของมัน */
    fun removePin(rig: PinRig, k: Int): PinRig {
        val gone = rig.pins[k]
        val left = rig.pins.filterIndexed { i, _ -> i != k }.map { if (it.parentId == gone.id) it.copy(parentId = gone.parentId) else it }
        return rig.copy(pins = left)
    }
}
