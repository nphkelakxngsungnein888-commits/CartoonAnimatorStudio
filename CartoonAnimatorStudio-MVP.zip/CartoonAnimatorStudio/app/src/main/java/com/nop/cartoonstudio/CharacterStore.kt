package com.nop.cartoonstudio

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.FileOutputStream
import java.io.IOException

/** ตัวละครที่เซฟไว้ (ข้อมูลสำหรับแสดงในรายการ) */
data class SavedCharacter(val name: String, val savedAt: Long)

/**
 * เก็บตัวละคร (โครงกระดูก + ภาพของแต่ละกระดูก) ไว้ในที่เก็บส่วนตัวของแอป
 * รูปแบบ: filesDir/characters/<ชื่อ>/character.json + ไฟล์ PNG ของแต่ละภาพ
 * ฟังก์ชันที่แตะไฟล์ทั้งหมดควรเรียกใน Dispatchers.IO
 */
object CharacterStore {
    private const val DIR = "characters"
    private const val JSON_FILE = "character.json"
    private const val FORMAT_VERSION = 1

    private fun root(context: Context): File = File(context.filesDir, DIR)

    /** ตัดอักขระที่ใช้เป็นชื่อโฟลเดอร์ไม่ได้ ชื่อที่ได้ไม่ขึ้นต้นด้วยจุด และยาวไม่เกิน 40 ตัวอักษร */
    fun cleanName(raw: String): String =
        raw.replace(Regex("[\\\\/:*?\"<>|\\p{Cntrl}]"), "").trim().trimStart('.').take(40).trim()

    fun list(context: Context): List<SavedCharacter> {
        val dirs = root(context).listFiles() ?: return emptyList()
        return dirs
            .filter { it.isDirectory && !it.name.startsWith(".") && File(it, JSON_FILE).isFile }
            .map { SavedCharacter(it.name, File(it, JSON_FILE).lastModified()) }
            .sortedByDescending { it.savedAt }
    }

    /** บันทึก (ชื่อซ้ำ = เขียนทับตัวเดิม) เขียนลงโฟลเดอร์ชั่วคราวก่อน แล้วค่อยสลับ เพื่อไม่ให้ตัวเดิมเสียถ้าเขียนไม่สำเร็จ */
    fun save(context: Context, rawName: String, skeleton: Skeleton) {
        val name = cleanName(rawName)
        if (name.isEmpty()) throw IOException("ชื่อตัวละครไม่ถูกต้อง")
        if (skeleton.bones.isEmpty()) throw IOException("ยังไม่มีกระดูกให้บันทึก")
        val base = root(context)
        if (!base.exists() && !base.mkdirs()) throw IOException("สร้างโฟลเดอร์เก็บตัวละครไม่ได้")

        val tmp = File(base, ".tmp_$name")
        val old = File(base, ".old_$name")
        tmp.deleteRecursively()
        old.deleteRecursively()
        if (!tmp.mkdirs()) throw IOException("สร้างโฟลเดอร์ชั่วคราวไม่ได้")
        try {
            val bonesJson = JSONArray()
            for (b in skeleton.bones) {
                val imgs = JSONArray()
                b.images.forEachIndexed { i, img ->
                    val file = "b${b.id}_$i.png"
                    FileOutputStream(File(tmp, file)).use {
                        if (!img.bitmap.compress(Bitmap.CompressFormat.PNG, 100, it)) {
                            throw IOException("เข้ารหัส PNG ไม่สำเร็จ")
                        }
                    }
                    imgs.put(
                        JSONObject()
                            .put("file", file)
                            .put("x", img.x.toDouble())
                            .put("y", img.y.toDouble())
                            .put("rotation", img.rotation.toDouble())
                            .put("scale", img.scale.toDouble()),
                    )
                }
                bonesJson.put(
                    JSONObject()
                        .put("id", b.id)
                        .put("parent", b.parentId ?: -1)
                        .put("length", b.length.toDouble())
                        .put("angle", b.angle.toDouble())
                        .put("images", imgs),
                )
            }
            val doc = JSONObject()
                .put("version", FORMAT_VERSION)
                .put("name", name)
                .put("bones", bonesJson)
            File(tmp, JSON_FILE).writeText(doc.toString(), Charsets.UTF_8)

            val dest = File(base, name)
            if (dest.exists() && !dest.renameTo(old)) throw IOException("เขียนทับตัวละครเดิมไม่ได้")
            if (!tmp.renameTo(dest)) {
                if (old.exists()) old.renameTo(dest) // คืนตัวเดิม
                throw IOException("บันทึกไม่สำเร็จ")
            }
            old.deleteRecursively()
        } finally {
            tmp.deleteRecursively() // ถ้าสำเร็จโฟลเดอร์นี้ถูกย้ายไปแล้ว ไม่มีอะไรให้ลบ
        }
    }

    /** ลบตัวละครที่เซฟไว้ทั้งโฟลเดอร์ (ชื่อต้องเป็นชื่อที่ผ่าน cleanName แล้ว กันลบนอกโฟลเดอร์เก็บตัวละคร) */
    fun delete(context: Context, name: String) {
        if (name.isEmpty() || name != cleanName(name)) throw IOException("ชื่อตัวละครไม่ถูกต้อง")
        val dir = File(root(context), name)
        if (!dir.isDirectory) throw IOException("ไม่พบตัวละคร \"$name\"")
        if (!dir.deleteRecursively()) throw IOException("ลบ \"$name\" ไม่สำเร็จ")
    }

    /** อ่านตัวละครกลับเป็นโครงกระดูกชุดใหม่ (id ของกระดูกถูกกำหนดใหม่ แต่ลำดับและความสัมพันธ์พ่อ-ลูกเหมือนเดิม) */
    fun load(context: Context, name: String): Skeleton {
        val dir = File(root(context), name)
        val jsonFile = File(dir, JSON_FILE)
        if (!jsonFile.isFile) throw IOException("ไม่พบไฟล์ตัวละคร")
        val arr = JSONObject(jsonFile.readText(Charsets.UTF_8)).getJSONArray("bones")

        val pending = ArrayList<JSONObject>()
        for (i in 0 until arr.length()) pending.add(arr.getJSONObject(i))

        val sk = Skeleton()
        val idMap = HashMap<Int, Int>() // id ในไฟล์ -> id ใหม่
        var progress = true
        while (pending.isNotEmpty() && progress) { // เติมกระดูกที่ parent ถูกเติมแล้วก่อนเสมอ
            progress = false
            val iter = pending.iterator()
            while (iter.hasNext()) {
                val o = iter.next()
                val p = o.optInt("parent", -1)
                if (p != -1 && !idMap.containsKey(p)) continue
                val bone = sk.add(
                    if (p == -1) null else idMap[p],
                    o.getDouble("length").toFloat(),
                    o.getDouble("angle").toFloat(),
                )
                idMap[o.getInt("id")] = bone.id
                val imgs = o.optJSONArray("images")
                if (imgs != null) {
                    for (j in 0 until imgs.length()) {
                        val io = imgs.getJSONObject(j)
                        val fname = io.getString("file")
                        if (fname.contains('/') || fname.contains('\\') || fname.contains("..")) {
                            throw IOException("ชื่อไฟล์ภาพในตัวละครไม่ถูกต้อง")
                        }
                        val bmp = BitmapFactory.decodeFile(File(dir, fname).path)
                            ?: throw IOException("อ่านภาพ $fname ไม่ได้")
                        val img = BoneImage(bmp)
                        img.x = io.optDouble("x", 0.0).toFloat()
                        img.y = io.optDouble("y", 0.0).toFloat()
                        img.rotation = io.optDouble("rotation", 0.0).toFloat()
                        img.scale = io.optDouble("scale", 1.0).toFloat()
                        bone.images.add(img)
                    }
                }
                iter.remove()
                progress = true
            }
        }
        if (pending.isNotEmpty()) throw IOException("ไฟล์ตัวละครเสียหาย (โครงกระดูกไม่ครบ)")
        // คืนลำดับชั้นตามที่เซฟไว้ (ลูปด้านบนเติมพ่อก่อนลูก ลำดับอาจไม่ตรงกับในไฟล์)
        sk.reorder((0 until arr.length()).mapNotNull { idMap[arr.getJSONObject(it).getInt("id")] })
        return sk
    }
}
