package com.nop.cartoonstudio

import android.content.Context
import android.media.MediaCodec
import android.media.MediaExtractor
import android.media.MediaFormat
import android.net.Uri
import android.provider.OpenableColumns
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import java.io.BufferedOutputStream
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.io.IOException
import java.io.RandomAccessFile
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.util.UUID

const val AUDIO_RATE = 44100 // เสียงทุกไฟล์ถูกแปลงเป็น 44100 Hz สเตอริโอ 16 บิต (WAV) ตอนนำเข้า
const val PEAKS_PER_SEC = 100 // จำนวนจุดคลื่นเสียงต่อวินาที (ไว้วาดคลื่น)
const val AUDIO_MIN_DUR = 0.1f // ตัดเสียงให้สั้นสุดได้กี่วินาที
const val WAV_HEADER = 44

/**
 * แถบเสียงหนึ่งแถบบนไทม์ไลน์ (อิงเวลาจริงเป็นวินาที ไม่ผูกกับเลขเฟรม)
 * startSec = ตำแหน่งเริ่มบนไทม์ไลน์, offsetSec = เริ่มเล่นจากวินาทีที่เท่าไหร่ของไฟล์ (ตัดหัว),
 * durSec = ความยาวที่เล่นจริง (ตัดท้าย), srcSec = ความยาวทั้งไฟล์
 */
class AudioClip(val id: Int, val file: String, name: String, val srcSec: Float) {
    var name by mutableStateOf(name)
    var startSec by mutableFloatStateOf(0f)
    var offsetSec by mutableFloatStateOf(0f)
    var durSec by mutableFloatStateOf(srcSec)
    var volume by mutableFloatStateOf(1f)
    var muted by mutableStateOf(false)
    var peaks by mutableStateOf<FloatArray?>(null) // 0..1 จุดละ 1/PEAKS_PER_SEC วินาที (null = ยังไม่ได้อ่าน)
}

/** แปลงระหว่างเวลา (วินาที) กับตำแหน่งเฟรม (ทศนิยม) ตามความเร็วของแต่ละเฟรม */
object AudioTimeline {
    /** เวลาเริ่มของแต่ละเฟรม ขนาด n+1 (ตัวสุดท้าย = เวลารวม) */
    fun starts(project: Project, fps: Float): FloatArray {
        val n = project.frameCount
        val a = FloatArray(n + 1)
        for (i in 0 until n) a[i + 1] = a[i] + 1f / project.fpsAt(i, fps).coerceAtLeast(FPS_MIN)
        return a
    }

    fun timeToPos(t: Float, st: FloatArray): Float {
        val n = st.size - 1
        if (n <= 0) return 0f
        if (t <= 0f) return 0f
        val total = st[n]
        if (t >= total) {
            val d = (st[n] - st[n - 1]).coerceAtLeast(0.0001f)
            return n + (t - total) / d
        }
        var lo = 0
        var hi = n - 1
        while (lo < hi) {
            val mid = (lo + hi + 1) / 2
            if (st[mid] <= t) lo = mid else hi = mid - 1
        }
        val d = (st[lo + 1] - st[lo]).coerceAtLeast(0.0001f)
        return lo + (t - st[lo]) / d
    }

    fun posToTime(pos: Float, st: FloatArray): Float {
        val n = st.size - 1
        if (n <= 0 || pos <= 0f) return 0f
        if (pos >= n) return st[n] + (pos - n) * (st[n] - st[n - 1])
        val i = pos.toInt().coerceIn(0, n - 1)
        return st[i] + (pos - i) * (st[i + 1] - st[i])
    }
}

/** ที่เก็บไฟล์เสียง (WAV) ของแอป + อ่านคลื่นเสียง */
object AudioStore {
    private var root: File? = null

    fun init(context: Context) {
        root = File(context.applicationContext.filesDir, "audio")
    }

    fun dir(context: Context): File {
        val d = root ?: File(context.applicationContext.filesDir, "audio").also { root = it }
        if (!d.exists()) d.mkdirs()
        return d
    }

    /** ไฟล์ในที่เก็บ (ต้อง init ก่อน) คืน null ถ้าชื่อไม่ปลอดภัย */
    fun fileOf(name: String): File? {
        if (!isSafeName(name)) return null
        val d = root ?: return null
        return File(d, name)
    }

    fun isSafeName(n: String): Boolean =
        n.isNotEmpty() && n.endsWith(".wav") && !n.contains('/') && !n.contains('\\') && !n.contains("..")

    fun newFileName(): String = "a${System.currentTimeMillis()}_${UUID.randomUUID().toString().take(8)}.wav"

    /** ลบไฟล์ที่ไม่มีแถบเสียงอ้างถึง และเก่ากว่า 10 นาที (กันลบไฟล์ที่เพิ่งแปลงเสร็จแต่ยังไม่ได้ใส่) */
    fun cleanup(context: Context, keep: Set<String>) {
        val now = System.currentTimeMillis()
        dir(context).listFiles()?.forEach { f ->
            if (f.isFile && f.name !in keep && now - f.lastModified() > 10 * 60 * 1000L) f.delete()
        }
    }

    fun displayName(context: Context, uri: Uri): String {
        val n = runCatching {
            context.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c ->
                if (c.moveToFirst()) c.getString(0) else null
            }
        }.getOrNull()
        val base = (n ?: uri.lastPathSegment ?: "เสียง").substringBeforeLast('.')
        return base.take(40).ifBlank { "เสียง" }
    }

    class Imported(val file: String, val name: String, val durSec: Float, val peaks: FloatArray)

    /** แปลงไฟล์เสียงหรือวิดีโอเป็น WAV ในที่เก็บ (เรียกใน Dispatchers.IO) */
    fun importFrom(context: Context, uri: Uri, onProgress: (Float) -> Unit): Imported {
        val name = displayName(context, uri)
        val fileName = newFileName()
        val out = File(dir(context), fileName)
        try {
            val r = AudioDecoder.decodeToWav(context, uri, out, onProgress)
            return Imported(fileName, name, r.durSec, r.peaks)
        } catch (t: Throwable) {
            out.delete()
            throw t
        }
    }

    /** อ่านคลื่นเสียงจากไฟล์ WAV ของเรา (เรียกใน Dispatchers.IO) */
    fun readPeaks(file: File): FloatArray {
        val win = AUDIO_RATE / PEAKS_PER_SEC
        val peaks = ArrayList<Float>()
        FileInputStream(file).use { fis ->
            var skipped = 0L
            while (skipped < WAV_HEADER) {
                val s = fis.skip(WAV_HEADER - skipped)
                if (s <= 0) break
                skipped += s
            }
            val buf = ByteArray(4 * 8192)
            var winMax = 0
            var winCount = 0
            while (true) {
                var n = 0
                while (n < buf.size) {
                    val r = fis.read(buf, n, buf.size - n)
                    if (r < 0) break
                    n += r
                }
                val frames = n / 4
                for (i in 0 until frames) {
                    val l = (buf[i * 4].toInt() and 0xFF) or (buf[i * 4 + 1].toInt() shl 8)
                    val r = (buf[i * 4 + 2].toInt() and 0xFF) or (buf[i * 4 + 3].toInt() shl 8)
                    val a = maxOf(Math.abs(l), Math.abs(r))
                    if (a > winMax) winMax = a
                    if (++winCount >= win) {
                        peaks.add(minOf(1f, winMax / 32768f))
                        winMax = 0
                        winCount = 0
                    }
                }
                if (n < buf.size) break
            }
            if (winCount > 0) peaks.add(minOf(1f, winMax / 32768f))
        }
        return peaks.toFloatArray()
    }

    /** เติมคลื่นเสียงให้แถบที่ยังไม่มี (เช่นหลังโหลดงาน) เรียกใน Dispatchers.IO แล้วตั้งค่าบน main */
    fun peaksFor(clip: AudioClip): FloatArray? {
        val f = fileOf(clip.file) ?: return null
        if (!f.isFile) return null
        return runCatching { readPeaks(f) }.getOrNull()
    }
}

/** ถอดเสียงจากไฟล์เสียงหรือวิดีโอ (MediaExtractor + MediaCodec) เป็น WAV 44100 Hz สเตอริโอ 16 บิต */
object AudioDecoder {
    class Result(val durSec: Float, val peaks: FloatArray)

    private const val ENCODING_PCM_FLOAT = 4

    fun decodeToWav(context: Context, uri: Uri, out: File, onProgress: (Float) -> Unit): Result {
        val ex = MediaExtractor()
        var codec: MediaCodec? = null
        var bos: BufferedOutputStream? = null
        try {
            ex.setDataSource(context, uri, null)
            var track = -1
            var fmt: MediaFormat? = null
            for (i in 0 until ex.trackCount) {
                val f = ex.getTrackFormat(i)
                if ((f.getString(MediaFormat.KEY_MIME) ?: "").startsWith("audio/")) {
                    track = i
                    fmt = f
                    break
                }
            }
            if (track < 0 || fmt == null) throw IOException("ไฟล์นี้ไม่มีเสียง")
            ex.selectTrack(track)
            val mime = fmt.getString(MediaFormat.KEY_MIME) ?: throw IOException("อ่านชนิดเสียงไม่ได้")
            val totalUs = if (fmt.containsKey(MediaFormat.KEY_DURATION)) fmt.getLong(MediaFormat.KEY_DURATION) else 0L
            var inRate = if (fmt.containsKey(MediaFormat.KEY_SAMPLE_RATE)) fmt.getInteger(MediaFormat.KEY_SAMPLE_RATE) else AUDIO_RATE
            var ch = if (fmt.containsKey(MediaFormat.KEY_CHANNEL_COUNT)) fmt.getInteger(MediaFormat.KEY_CHANNEL_COUNT) else 2
            var pcmFloat = false

            val c = MediaCodec.createDecoderByType(mime)
            codec = c
            c.configure(fmt, null, null, 0)
            c.start()

            val os = BufferedOutputStream(FileOutputStream(out), 1 shl 16)
            bos = os
            os.write(ByteArray(WAV_HEADER)) // เว้นที่ไว้เขียนหัวไฟล์ทีหลัง

            // ตัวเขียน PCM + คลื่นเสียง
            val outBuf = ByteArray(1 shl 16)
            var outPos = 0
            var framesOut = 0L
            val win = AUDIO_RATE / PEAKS_PER_SEC
            var winMax = 0
            var winCount = 0
            var pk = FloatArray(1024)
            var pkN = 0
            fun addPeak(v: Float) {
                if (pkN == pk.size) pk = pk.copyOf(pk.size * 2)
                pk[pkN++] = v
            }
            fun emit(l0: Int, r0: Int) {
                val l = l0.coerceIn(-32768, 32767)
                val r = r0.coerceIn(-32768, 32767)
                if (outPos + 4 > outBuf.size) {
                    os.write(outBuf, 0, outPos)
                    outPos = 0
                }
                outBuf[outPos++] = (l and 0xFF).toByte()
                outBuf[outPos++] = ((l shr 8) and 0xFF).toByte()
                outBuf[outPos++] = (r and 0xFF).toByte()
                outBuf[outPos++] = ((r shr 8) and 0xFF).toByte()
                val a = maxOf(Math.abs(l), Math.abs(r))
                if (a > winMax) winMax = a
                if (++winCount >= win) {
                    addPeak(minOf(1f, winMax / 32768f))
                    winMax = 0
                    winCount = 0
                }
                framesOut++
            }

            // ตัวแปลงอัตราสุ่ม (เชิงเส้น): prev = เฟรมก่อนหน้า, t = ตำแหน่งระหว่าง prev กับเฟรมใหม่
            var started = false
            var prevL = 0f
            var prevR = 0f
            var t = 0.0
            fun feed(l: Float, r: Float) {
                if (inRate == AUDIO_RATE) {
                    emit(Math.round(l), Math.round(r))
                    return
                }
                if (!started) {
                    started = true
                    prevL = l
                    prevR = r
                    t = 0.0
                    return
                }
                val step = inRate.toDouble() / AUDIO_RATE
                while (t < 1.0) {
                    val f = t.toFloat()
                    emit(Math.round(prevL + (l - prevL) * f), Math.round(prevR + (r - prevR) * f))
                    t += step
                }
                t -= 1.0
                prevL = l
                prevR = r
            }

            val info = MediaCodec.BufferInfo()
            var inputDone = false
            var outputDone = false
            var idle = 0
            while (!outputDone) {
                var progressed = false
                if (!inputDone) {
                    val ii = c.dequeueInputBuffer(10_000L)
                    if (ii >= 0) {
                        val ib = c.getInputBuffer(ii) ?: throw IOException("ตัวถอดเสียงไม่พร้อม")
                        val sz = ex.readSampleData(ib, 0)
                        if (sz < 0) {
                            c.queueInputBuffer(ii, 0, 0, 0, MediaCodec.BUFFER_FLAG_END_OF_STREAM)
                            inputDone = true
                        } else {
                            c.queueInputBuffer(ii, 0, sz, ex.sampleTime, 0)
                            ex.advance()
                        }
                        progressed = true
                    }
                }
                val oi = c.dequeueOutputBuffer(info, 10_000L)
                if (oi == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) {
                    val of = c.outputFormat
                    if (of.containsKey(MediaFormat.KEY_SAMPLE_RATE)) inRate = of.getInteger(MediaFormat.KEY_SAMPLE_RATE)
                    if (of.containsKey(MediaFormat.KEY_CHANNEL_COUNT)) ch = of.getInteger(MediaFormat.KEY_CHANNEL_COUNT)
                    pcmFloat = of.containsKey(MediaFormat.KEY_PCM_ENCODING) &&
                        of.getInteger(MediaFormat.KEY_PCM_ENCODING) == ENCODING_PCM_FLOAT
                    started = false // อัตราสุ่มเปลี่ยน: เริ่มตัวแปลงใหม่
                    progressed = true
                } else if (oi >= 0) {
                    val ob = c.getOutputBuffer(oi)
                    if (ob != null && info.size > 0 && ch > 0) {
                        ob.position(info.offset)
                        ob.limit(info.offset + info.size)
                        ob.order(ByteOrder.LITTLE_ENDIAN)
                        if (pcmFloat) {
                            val fb = ob.asFloatBuffer()
                            val frames = fb.remaining() / ch
                            for (i in 0 until frames) {
                                val l = fb.get(i * ch) * 32767f
                                val r = if (ch >= 2) fb.get(i * ch + 1) * 32767f else l
                                feed(l, r)
                            }
                        } else {
                            val sb = ob.asShortBuffer()
                            val frames = sb.remaining() / ch
                            for (i in 0 until frames) {
                                val l = sb.get(i * ch).toFloat()
                                val r = if (ch >= 2) sb.get(i * ch + 1).toFloat() else l
                                feed(l, r)
                            }
                        }
                    }
                    if (totalUs > 0) onProgress((info.presentationTimeUs.toFloat() / totalUs).coerceIn(0f, 1f))
                    c.releaseOutputBuffer(oi, false)
                    if ((info.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0) outputDone = true
                    progressed = true
                }
                if (progressed) idle = 0 else if (++idle > 3000) throw IOException("ถอดเสียงไม่สำเร็จ (ตัวถอดเสียงไม่ตอบสนอง)")
            }

            if (outPos > 0) os.write(outBuf, 0, outPos)
            if (winCount > 0) addPeak(minOf(1f, winMax / 32768f))
            os.flush()
            os.close()
            bos = null
            if (framesOut <= 0L) throw IOException("ไม่พบข้อมูลเสียงในไฟล์")
            writeWavHeader(out, framesOut * 4L)
            onProgress(1f)
            return Result(framesOut.toFloat() / AUDIO_RATE, pk.copyOf(pkN))
        } finally {
            runCatching { bos?.close() }
            runCatching { codec?.stop() }
            runCatching { codec?.release() }
            runCatching { ex.release() }
        }
    }

    private fun writeWavHeader(file: File, dataLen: Long) {
        val h = ByteBuffer.allocate(WAV_HEADER).order(ByteOrder.LITTLE_ENDIAN)
        h.put("RIFF".toByteArray(Charsets.US_ASCII))
        h.putInt((36L + dataLen).toInt())
        h.put("WAVE".toByteArray(Charsets.US_ASCII))
        h.put("fmt ".toByteArray(Charsets.US_ASCII))
        h.putInt(16)
        h.putShort(1.toShort()) // PCM
        h.putShort(2.toShort()) // สเตอริโอ
        h.putInt(AUDIO_RATE)
        h.putInt(AUDIO_RATE * 4)
        h.putShort(4.toShort())
        h.putShort(16.toShort())
        h.put("data".toByteArray(Charsets.US_ASCII))
        h.putInt(dataLen.toInt())
        RandomAccessFile(file, "rw").use { raf ->
            raf.seek(0)
            raf.write(h.array())
        }
    }
}
