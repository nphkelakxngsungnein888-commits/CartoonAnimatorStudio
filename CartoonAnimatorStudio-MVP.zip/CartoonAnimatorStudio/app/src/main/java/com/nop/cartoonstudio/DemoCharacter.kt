package com.nop.cartoonstudio

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.RectF

/** ตัวละครทดสอบ (สร้างด้วยโค้ด) เพื่อลองระบบ rig โดยไม่ต้องมีไฟล์ PNG */
object DemoCharacter {
    private val outline = 0xFF1E1E1E.toInt()

    private fun shape(w: Int, h: Int, color: Int, radius: Float): Bitmap {
        val bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        val c = Canvas(bmp)
        val fill = Paint(Paint.ANTI_ALIAS_FLAG).apply { this.color = color }
        val line = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.STROKE
            strokeWidth = 2f
            this.color = outline
        }
        val r = RectF(1f, 1f, w - 1f, h - 1f)
        c.drawRoundRect(r, radius, radius, fill)
        c.drawRoundRect(r, radius, radius, line)
        return bmp
    }

    fun build(project: Project) {
        val skin = 0xFFF2C14E.toInt()
        val torso = project.addPart("ลำตัว", shape(80, 120, 0xFF3F7FBF.toInt(), 22f))
        torso.x = 0f
        torso.y = -40f

        fun limb(name: String, parent: Part, w: Int, h: Int, color: Int, jx: Float, jy: Float): Part {
            val p = project.addPart(name, shape(w, h, color, w / 2f), parent.id)
            p.pivotX = w / 2f
            p.pivotY = 8f
            p.x = jx
            p.y = jy
            return p
        }

        fun leg(tag: String, hipX: Float, color: Int) {
            val thigh = limb("ต้นขา $tag", torso, 28, 86, color, hipX, 52f)
            val shin = limb("หน้าแข้ง $tag", thigh, 24, 86, color, 0f, 70f)
            val foot = project.addPart("เท้า $tag", shape(56, 22, color, 10f), shin.id)
            foot.pivotX = 14f
            foot.pivotY = 8f
            foot.x = 0f
            foot.y = 70f
        }

        fun arm(tag: String, shoulderX: Float, color: Int) {
            val upper = limb("แขนท่อนบน $tag", torso, 24, 76, color, shoulderX, -48f)
            val fore = limb("แขนท่อนล่าง $tag", upper, 22, 70, color, 0f, 60f)
            val hand = project.addPart("มือ $tag", shape(30, 30, skin, 15f), fore.id)
            hand.pivotX = 15f
            hand.pivotY = 8f
            hand.x = 0f
            hand.y = 54f
        }

        leg("L", -20f, 0xFF81B29A.toInt())
        leg("R", 20f, 0xFF5E8C75.toInt())
        val head = project.addPart("หัว", shape(70, 70, skin, 35f), torso.id)
        head.pivotX = 35f
        head.pivotY = 62f
        head.x = 0f
        head.y = -60f
        arm("L", -40f, 0xFFE07A5F.toInt())
        arm("R", 40f, 0xFFB5523B.toInt())
    }
}
