package com.nop.cartoonstudio

import androidx.compose.ui.geometry.Offset
import kotlin.math.atan2
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min

/** ตำแหน่ง + ทิศ (องศา) ของตัวละครบนเส้นทางในเฟรมหนึ่ง */
data class PathSample(val pos: Offset, val heading: Float)

/**
 * คณิตศาสตร์ของเส้นทาง (ไม่แตะ Compose state/โครงกระดูก จึงทดสอบแยกได้)
 * พิกัดทั้งหมดเป็นพิกัดฉาก (world) ไม่ใช่พิกัดหน้าจอ
 */
object PathMath {
    private const val SUBDIV = 16 // จำนวนช่วงย่อยต่อ 1 ช่วงของเส้นโค้ง

    /** เส้นหนาแน่น: จุดบนเส้นเรียงตามลำดับ + เลขช่วงควบคุม (segment) ที่จุดนั้นอยู่ */
    class Dense(val pts: List<Offset>, val seg: List<Int>)

    private fun catmull(p0: Offset, p1: Offset, p2: Offset, p3: Offset, t: Float): Offset {
        val t2 = t * t
        val t3 = t2 * t
        fun c(a: Float, b: Float, c: Float, d: Float): Float =
            0.5f * ((2f * b) + (-a + c) * t + (2f * a - 5f * b + 4f * c - d) * t2 + (-a + 3f * b - 3f * c + d) * t3)
        return Offset(c(p0.x, p1.x, p2.x, p3.x), c(p0.y, p1.y, p2.y, p3.y))
    }

    /** เส้นหนาแน่นจากจุดควบคุม: smooth = เส้นโค้งเนียนผ่านทุกจุด, ไม่ใช่ = เส้นตรงต่อจุด, closed = ต่อปลายกลับจุดเริ่ม */
    fun dense(points: List<Offset>, smooth: Boolean, closed: Boolean): Dense {
        val n = points.size
        if (n == 0) return Dense(emptyList(), emptyList())
        if (n == 1) return Dense(listOf(points[0]), listOf(0))
        val segCount = if (closed && n >= 3) n else n - 1
        val out = ArrayList<Offset>()
        val seg = ArrayList<Int>()
        fun at(i: Int): Offset =
            if (closed && n >= 3) points[Math.floorMod(i, n)] else points[i.coerceIn(0, n - 1)]
        for (s in 0 until segCount) {
            if (smooth && n >= 3) {
                for (k in 0 until SUBDIV) {
                    out.add(catmull(at(s - 1), at(s), at(s + 1), at(s + 2), k / SUBDIV.toFloat()))
                    seg.add(s)
                }
            } else {
                out.add(at(s))
                seg.add(s)
            }
        }
        out.add(if (closed && n >= 3) points[0] else points[n - 1])
        seg.add(segCount - 1)
        return Dense(out, seg)
    }

    /** ความยาวสะสมของเส้นหนาแน่น (index เดียวกับ pts) */
    private fun cumulative(pts: List<Offset>): FloatArray {
        val c = FloatArray(pts.size)
        for (i in 1 until pts.size) c[i] = c[i - 1] + hypot(pts[i].x - pts[i - 1].x, pts[i].y - pts[i - 1].y)
        return c
    }

    fun ease(e: PathEase, t: Float): Float {
        val x = t.coerceIn(0f, 1f)
        return when (e) {
            PathEase.LINEAR -> x
            PathEase.EASE_IN -> x * x
            PathEase.EASE_OUT -> 1f - (1f - x) * (1f - x)
            PathEase.EASE_BOTH -> x * x * (3f - 2f * x)
        }
    }

    /** n ตำแหน่ง (1 จุดต่อ 1 เฟรม) ตามเส้นและจังหวะ; เส้นปิดวง = ไม่นับจุดปลายซ้ำกับจุดเริ่ม เพื่อให้วนต่อเนื่อง */
    fun sample(path: MotionPath, n: Int): List<PathSample> {
        if (n <= 0 || path.points.isEmpty()) return emptyList()
        val d = dense(path.points, path.smooth, path.closed)
        val pts = d.pts
        if (pts.size < 2) return List(n) { PathSample(pts[0], 0f) }
        val cum = cumulative(pts)
        val total = cum.last()
        if (total <= 1e-3f) return List(n) { PathSample(pts[0], 0f) }
        val loop = path.closed && path.points.size >= 3
        val out = ArrayList<PathSample>(n)
        var idx = 0
        for (k in 0 until n) {
            val t = when {
                n == 1 -> 0f
                loop -> k / n.toFloat()
                else -> k / (n - 1).toFloat()
            }
            val target = ease(path.ease, t) * total
            while (idx < pts.size - 2 && cum[idx + 1] < target) idx++
            val segLen = cum[idx + 1] - cum[idx]
            val f = if (segLen <= 1e-6f) 0f else ((target - cum[idx]) / segLen).coerceIn(0f, 1f)
            val a = pts[idx]
            val b = pts[idx + 1]
            val pos = Offset(a.x + (b.x - a.x) * f, a.y + (b.y - a.y) * f)
            // ทิศ: ใช้ช่วงสั้นรอบจุดนี้ ไม่ใช้แค่ช่วงเดียว (กันทิศกระตุกตรงรอยต่อของเส้นตรงต่อจุด)
            val i0 = max(0, idx - 1)
            val i1 = min(pts.size - 1, idx + 2)
            val dir = Offset(pts[i1].x - pts[i0].x, pts[i1].y - pts[i0].y)
            val heading = Math.toDegrees(atan2(dir.y.toDouble(), dir.x.toDouble())).toFloat()
            out.add(PathSample(pos, heading))
        }
        return out
    }

    /** ระยะจากจุด p ถึงเส้นหนาแน่น (หน่วยพิกัดฉาก) พร้อมเลขช่วงควบคุมที่ใกล้ที่สุด */
    fun nearestSegment(d: Dense, p: Offset): Pair<Float, Int>? {
        if (d.pts.size < 2) return null
        var best = Float.MAX_VALUE
        var bestSeg = 0
        for (i in 0 until d.pts.size - 1) {
            val a = d.pts[i]
            val b = d.pts[i + 1]
            val abx = b.x - a.x
            val aby = b.y - a.y
            val len2 = abx * abx + aby * aby
            val t = if (len2 <= 1e-9f) 0f else (((p.x - a.x) * abx + (p.y - a.y) * aby) / len2).coerceIn(0f, 1f)
            val dist = hypot(p.x - (a.x + abx * t), p.y - (a.y + aby * t))
            if (dist < best) {
                best = dist
                bestSeg = d.seg[i]
            }
        }
        return best to bestSeg
    }

    // ---------- วาดอิสระ: ทำให้เรียบ ----------

    /** ความยาวรวมของเส้นหักมุม */
    fun length(pts: List<Offset>): Float {
        var s = 0f
        for (i in 1 until pts.size) s += hypot(pts[i].x - pts[i - 1].x, pts[i].y - pts[i - 1].y)
        return s
    }

    /** เฉลี่ยจุดข้างเคียง (หน้าต่าง 2*r+1) ลดมือสั่น ปลายทั้งสองข้างคงที่ */
    private fun smoothPoints(raw: List<Offset>, r: Int): List<Offset> {
        if (raw.size < 3 || r <= 0) return raw
        val out = ArrayList<Offset>(raw.size)
        for (i in raw.indices) {
            if (i == 0 || i == raw.lastIndex) {
                out.add(raw[i])
                continue
            }
            val k = min(r, min(i, raw.lastIndex - i))
            var sx = 0f
            var sy = 0f
            for (j in i - k..i + k) {
                sx += raw[j].x
                sy += raw[j].y
            }
            val c = (2 * k + 1).toFloat()
            out.add(Offset(sx / c, sy / c))
        }
        return out
    }

    private fun rdp(pts: List<Offset>, eps: Float): List<Offset> {
        if (pts.size < 3) return pts
        val keep = BooleanArray(pts.size)
        keep[0] = true
        keep[pts.lastIndex] = true
        val stack = ArrayDeque<IntArray>()
        stack.addLast(intArrayOf(0, pts.lastIndex))
        while (stack.isNotEmpty()) {
            val (s, e) = stack.removeLast()
            var worst = 0f
            var wi = -1
            val a = pts[s]
            val b = pts[e]
            val abx = b.x - a.x
            val aby = b.y - a.y
            val len = hypot(abx, aby)
            for (i in s + 1 until e) {
                val dist = if (len <= 1e-6f) hypot(pts[i].x - a.x, pts[i].y - a.y)
                else kotlin.math.abs((pts[i].x - a.x) * aby - (pts[i].y - a.y) * abx) / len
                if (dist > worst) {
                    worst = dist
                    wi = i
                }
            }
            if (wi != -1 && worst > eps) {
                keep[wi] = true
                stack.addLast(intArrayOf(s, wi))
                stack.addLast(intArrayOf(wi, e))
            }
        }
        return pts.filterIndexed { i, _ -> keep[i] }
    }

    /**
     * เส้นที่ลากด้วยนิ้ว (จุดถี่ๆ) -> จุดควบคุมไม่กี่จุดให้ลากแก้ต่อได้
     * epsWorld = ความคลาดเคลื่อนที่ยอมได้ในหน่วยพิกัดฉาก (ส่งค่าจากพิกเซลหน้าจอ / ซูม)
     */
    fun simplifyStroke(raw: List<Offset>, epsWorld: Float, maxPoints: Int = 14): List<Offset> {
        if (raw.size < 2) return raw
        var pts = smoothPoints(raw, 3)
        var eps = epsWorld
        var out = rdp(pts, eps)
        var guard = 0
        while (out.size > maxPoints && guard < 12) { // จุดเยอะเกินไปลากแก้ยาก: ขยับความคลาดเคลื่อนขึ้นทีละนิด
            eps *= 1.4f
            out = rdp(pts, eps)
            guard++
        }
        if (out.size == 2 && pts.size > 6) { // เส้นโค้งเบาๆ ที่เหลือแค่ 2 จุด: เติมจุดกลางไว้ให้ดัดโค้งได้
            val mid = pts[pts.size / 2]
            out = listOf(out[0], mid, out[1])
        }
        return out
    }
}
