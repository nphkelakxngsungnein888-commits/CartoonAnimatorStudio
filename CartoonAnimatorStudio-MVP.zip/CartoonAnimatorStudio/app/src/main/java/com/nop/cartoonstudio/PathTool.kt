package com.nop.cartoonstudio

import androidx.compose.ui.geometry.Offset
import kotlin.math.atan2
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min

/** ตำแหน่ง + ทิศ (องศา) ของตัวละครบนเส้นทางในเฟรมหนึ่ง */
data class PathSample(val pos: Offset, val heading: Float)

/**
 * คณิตศาสตร์ของเส้นทาง (ไม่แตะ Compose state/โครงกระดูก จึงทดสอบแยกได้)
 * พิกัดทั้งหมดเป็นพิกัดฉาก (world) ไม่ใช่พิกัดหน้าจอ
 */
object PathMath {
    private const val SUBDIV = 16 // จำนวนช่วงย่อยต่อ 1 ช่วงของเส้นโค้ง

    /** เส้นหนาแน่น: จุดบนเส้นเรียงตามลำดับ + เลขช่วงควบคุม (segment) ที่จุดนั้นอยู่ */
    class Dense(val pts: List<Offset>, val seg: List<Int>)

    private fun catmull(p0: Offset, p1: Offset, p2: Offset, p3: Offset, t: Float): Offset {
        val t2 = t * t
        val t3 = t2 * t
        fun c(a: Float, b: Float, c: Float, d: Float): Float =
            0.5f * ((2f * b) + (-a + c) * t + (2f * a - 5f * b + 4f * c - d) * t2 + (-a + 3f * b - 3f * c + d) * t3)
        return Offset(c(p0.x, p1.x, p2.x, p3.x), c(p0.y, p1.y, p2.y, p3.y))
    }

    /** เส้นหนาแน่นจากจุดควบคุม: smooth = เส้นโค้งเนียนผ่านทุกจุด, ไม่ใช่ = เส้นตรงต่อจุด, closed = ต่อปลายกลับจุดเริ่ม */
    fun dense(points: List<Offset>, smooth: Boolean, closed: Boolean): Dense {
        val n = points.size
        if (n == 0) return Dense(emptyList(), emptyList())
        if (n == 1) return Dense(listOf(points[0]), listOf(0))
        val segCount = if (closed && n >= 3) n else n - 1
        val out = ArrayList<Offset>()
        val seg = ArrayList<Int>()
        fun at(i: Int): Offset =
            if (closed && n >= 3) points[Math.floorMod(i, n)] else points[i.coerceIn(0, n - 1)]
        for (s in 0 until segCount) {
            if (smooth && n >= 3) {
                for (k in 0 until SUBDIV) {
                    out.add(catmull(at(s - 1), at(s), at(s + 1), at(s + 2), k / SUBDIV.toFloat()))
                    seg.add(s)
                }
            } else {
                out.add(at(s))
                seg.add(s)
            }
        }
        out.add(if (closed && n >= 3) points[0] else points[n - 1])
        seg.add(segCount - 1)
        return Dense(out, seg)
    }

    /** ความยาวสะสมของเส้นหนาแน่น (index เดียวกับ pts) */
    fun cumulative(pts: List<Offset>): FloatArray {
        val c = FloatArray(pts.size)
        for (i in 1 until pts.size) c[i] = c[i - 1] + hypot(pts[i].x - pts[i - 1].x, pts[i].y - pts[i - 1].y)
        return c
    }

    /** เส้นปิดวง (ต้องมีอย่างน้อย 3 จุดควบคุม) */
    fun isLoop(path: MotionPath): Boolean = path.closed && path.points.size >= 3

    /** ตำแหน่งบนเส้น (สัดส่วน 0..1) ของเฟรมต่างๆ เมื่อห่างเท่ากัน; เส้นปิดวง = ไม่นับจุดปลายซ้ำกับจุดเริ่ม เพื่อให้วนต่อเนื่อง */
    fun uniformT(n: Int, loop: Boolean): List<Float> = List(n) { k ->
        when {
            n == 1 -> 0f
            loop -> k / n.toFloat()
            else -> k / (n - 1).toFloat()
        }
    }

    /** ตำแหน่งบนเส้นของแต่ละเฟรมที่ใช้จริง: ใช้ค่าที่ผู้ใช้ลากไว้ (frameT) ถ้าจำนวนตรงกับจำนวนเฟรม ไม่งั้นห่างเท่ากัน */
    fun framesT(path: MotionPath, n: Int): List<Float> =
        if (path.frameT.size == n) path.frameT else uniformT(n, isLoop(path))

    /** n ตำแหน่ง (1 จุดต่อ 1 เฟรม) ตามเส้น */
    fun sample(path: MotionPath, n: Int): List<PathSample> {
        if (n <= 0 || path.points.isEmpty()) return emptyList()
        val d = dense(path.points, path.smooth, path.closed)
        val pts = d.pts
        if (pts.size < 2) return List(n) { PathSample(pts[0], 0f) }
        val cum = cumulative(pts)
        val total = cum.last()
        if (total <= 1e-3f) return List(n) { PathSample(pts[0], 0f) }
        val ts = framesT(path, n)
        val out = ArrayList<PathSample>(n)
        for (k in 0 until n) {
            val target = ts[k].coerceIn(0f, 1f) * total
            var idx = 0 // เฟรมที่ผู้ใช้ลากย้ายแล้วอาจไม่เรียงตามลำดับเสมอไป จึงค้นจากต้นเส้นทุกครั้ง
            while (idx < pts.size - 2 && cum[idx + 1] < target) idx++
            val segLen = cum[idx + 1] - cum[idx]
            val f = if (segLen <= 1e-6f) 0f else ((target - cum[idx]) / segLen).coerceIn(0f, 1f)
            val a = pts[idx]
            val b = pts[idx + 1]
            val pos = Offset(a.x + (b.x - a.x) * f, a.y + (b.y - a.y) * f)
            // ทิศ: ใช้ช่วงสั้นรอบจุดนี้ ไม่ใช้แค่ช่วงเดียว (กันทิศกระตุกตรงรอยต่อของเส้นตรงต่อจุด)
            val i0 = max(0, idx - 1)
            val i1 = min(pts.size - 1, idx + 2)
            val dir = Offset(pts[i1].x - pts[i0].x, pts[i1].y - pts[i0].y)
            val heading = Math.toDegrees(atan2(dir.y.toDouble(), dir.x.toDouble())).toFloat()
            out.add(PathSample(pos, heading))
        }
        return out
    }

    // ---------- เล่น/ส่งออก: เดินตามเส้นโค้งจริงระหว่างเฟรม ----------

    /** เส้นที่เตรียมไว้สำหรับเล่น: เส้นหนาแน่น + ความยาวสะสม + ตำแหน่งของแต่ละเฟรมบนเส้น (ค่าเดียวกับที่ใช้ตอนฝังตำแหน่ง) */
    class Playback(
        val start: Int,
        val end: Int,
        val ts: List<Float>,
        val loop: Boolean,
        val pts: List<Offset>,
        val cum: FloatArray,
    )

    /** เตรียมเส้นสำหรับเล่น; คืน null ถ้าเส้นใช้ไม่ได้ (เงื่อนไขเดียวกับ bakePath/sample: ต้องมี 2 จุดขึ้นไปและเส้นไม่สั้นเป็นศูนย์) */
    fun prepare(path: MotionPath, frameCount: Int): Playback? {
        if (frameCount <= 0 || path.points.size < 2) return null
        val start = path.startFrame.coerceIn(0, frameCount - 1)
        val end = path.endFrame.coerceIn(start, frameCount - 1)
        val n = end - start + 1
        val d = dense(path.points, path.smooth, path.closed)
        if (d.pts.size < 2) return null
        val cum = cumulative(d.pts)
        if (cum.last() <= 1e-3f) return null
        return Playback(start, end, framesT(path, n), isLoop(path), d.pts, cum)
    }

    /** จุดบนเส้นที่สัดส่วนความยาว u (เส้นปิดวง: u เกิน 1 วนกลับต้นเส้น) */
    private fun pointAt(pb: Playback, u: Float): Offset {
        val total = pb.cum.last()
        val uu = if (pb.loop && u > 1f) u - 1f else u
        val target = uu.coerceIn(0f, 1f) * total
        var idx = 0
        while (idx < pb.pts.size - 2 && pb.cum[idx + 1] < target) idx++
        val segLen = pb.cum[idx + 1] - pb.cum[idx]
        val f = if (segLen <= 1e-6f) 0f else ((target - pb.cum[idx]) / segLen).coerceIn(0f, 1f)
        val a = pb.pts[idx]
        val b = pb.pts[idx + 1]
        return Offset(a.x + (b.x - a.x) * f, a.y + (b.y - a.y) * f)
    }

    /**
     * ส่วนที่ต้องบวกเพิ่มกับตำแหน่ง (dx,dy) ที่ได้จากการเฉลี่ยเส้นตรงระหว่างสองเฟรม เพื่อให้ตัวละครอยู่บนเส้นโค้งจริง
     * = (จุดบนเส้นที่ตำแหน่งนี้) - (จุดบนเส้นตรงระหว่างจุดเฟรมสองจุด) จึงเป็นศูนย์พอดีที่เฟรมจริง
     * และตำแหน่งที่ผู้ใช้ขยับเองในเฟรมก็ยังคงอยู่ (บวกเฉพาะส่วนโค้งเพิ่ม)
     * position = ตำแหน่งเล่น (เฟรมแบบทศนิยม) loopN = จำนวนเฟรมที่วนเล่น (ตัวเดียวกับที่ Project.interpolated ใช้)
     * คืน null = ไม่ต้องแก้ (นอกช่วงของเส้น หรือสองเฟรมที่ติดกันไม่ได้อยู่บนเส้นเดียวกัน)
     */
    fun curveCorrection(pb: Playback, position: Float, loopN: Int): Offset? {
        if (loopN <= 0) return null
        val base = Math.floor(position.toDouble()).toInt()
        val t = position - base
        if (t <= 0f) return null
        val a = Math.floorMod(base, loopN)
        val b = Math.floorMod(base + 1, loopN)
        if (a < pb.start || a > pb.end) return null
        val ua = pb.ts[a - pb.start]
        val ub = when {
            b == a + 1 && b <= pb.end -> pb.ts[b - pb.start]
            pb.loop && a == pb.end && b == pb.start -> pb.ts[0] + 1f // เส้นปิดวง: ช่วงสุดท้ายวิ่งต่อจนครบรอบกลับจุดเริ่ม
            else -> return null
        }
        val pa = pointAt(pb, ua)
        val pbPt = pointAt(pb, ub)
        val cur = pointAt(pb, ua + (ub - ua) * t)
        val chordX = pa.x + (pbPt.x - pa.x) * t
        val chordY = pa.y + (pbPt.y - pa.y) * t
        return Offset(cur.x - chordX, cur.y - chordY)
    }

    /**
     * จุดบนเส้นที่ใกล้ p ที่สุด โดยจำกัดอยู่ในช่วงความยาว lo..hi (สัดส่วน 0..1) คืนสัดส่วนความยาวของจุดนั้น
     * ใช้ตอนลากจุดเฟรม: ลากได้ตามเส้นเท่านั้น และไม่ข้ามเฟรมข้างเคียง
     */
    fun projectInRange(d: Dense, p: Offset, lo: Float, hi: Float): Float {
        if (d.pts.size < 2) return lo
        val cum = cumulative(d.pts)
        val total = cum.last()
        if (total <= 1e-3f) return lo
        val loA = lo.coerceIn(0f, 1f) * total
        val hiA = hi.coerceIn(0f, 1f) * total
        var best = Float.MAX_VALUE
        var bestA = loA
        for (i in 0 until d.pts.size - 1) {
            val segStart = cum[i]
            val segEnd = cum[i + 1]
            if (segEnd < loA || segStart > hiA) continue
            val a = d.pts[i]
            val b = d.pts[i + 1]
            val abx = b.x - a.x
            val aby = b.y - a.y
            val segLen = segEnd - segStart
            val len2 = abx * abx + aby * aby
            val tRaw = if (len2 <= 1e-9f) 0f else ((p.x - a.x) * abx + (p.y - a.y) * aby) / len2
            val tLo = if (segLen <= 1e-6f) 0f else ((loA - segStart) / segLen).coerceIn(0f, 1f)
            val tHi = if (segLen <= 1e-6f) 1f else ((hiA - segStart) / segLen).coerceIn(0f, 1f)
            val t = tRaw.coerceIn(min(tLo, tHi), max(tLo, tHi))
            val dist = hypot(p.x - (a.x + abx * t), p.y - (a.y + aby * t))
            if (dist < best) {
                best = dist
                bestA = segStart + segLen * t
            }
        }
        return (bestA / total).coerceIn(lo, hi)
    }

    /** ระยะจากจุด p ถึงเส้นหนาแน่น (หน่วยพิกัดฉาก) พร้อมเลขช่วงควบคุมที่ใกล้ที่สุด */
    fun nearestSegment(d: Dense, p: Offset): Pair<Float, Int>? {
        if (d.pts.size < 2) return null
        var best = Float.MAX_VALUE
        var bestSeg = 0
        for (i in 0 until d.pts.size - 1) {
            val a = d.pts[i]
            val b = d.pts[i + 1]
            val abx = b.x - a.x
            val aby = b.y - a.y
            val len2 = abx * abx + aby * aby
            val t = if (len2 <= 1e-9f) 0f else (((p.x - a.x) * abx + (p.y - a.y) * aby) / len2).coerceIn(0f, 1f)
            val dist = hypot(p.x - (a.x + abx * t), p.y - (a.y + aby * t))
            if (dist < best) {
                best = dist
                bestSeg = d.seg[i]
            }
        }
        return best to bestSeg
    }

    // ---------- วาดอิสระ: ทำให้เรียบ ----------

    /** ความยาวรวมของเส้นหักมุม */
    fun length(pts: List<Offset>): Float {
        var s = 0f
        for (i in 1 until pts.size) s += hypot(pts[i].x - pts[i - 1].x, pts[i].y - pts[i - 1].y)
        return s
    }

    /** เฉลี่ยจุดข้างเคียง (หน้าต่าง 2*r+1) ลดมือสั่น ปลายทั้งสองข้างคงที่ */
    private fun smoothPoints(raw: List<Offset>, r: Int): List<Offset> {
        if (raw.size < 3 || r <= 0) return raw
        val out = ArrayList<Offset>(raw.size)
        for (i in raw.indices) {
            if (i == 0 || i == raw.lastIndex) {
                out.add(raw[i])
                continue
            }
            val k = min(r, min(i, raw.lastIndex - i))
            var sx = 0f
            var sy = 0f
            for (j in i - k..i + k) {
                sx += raw[j].x
                sy += raw[j].y
            }
            val c = (2 * k + 1).toFloat()
            out.add(Offset(sx / c, sy / c))
        }
        return out
    }

    private fun rdp(pts: List<Offset>, eps: Float): List<Offset> {
        if (pts.size < 3) return pts
        val keep = BooleanArray(pts.size)
        keep[0] = true
        keep[pts.lastIndex] = true
        val stack = ArrayDeque<IntArray>()
        stack.addLast(intArrayOf(0, pts.lastIndex))
        while (stack.isNotEmpty()) {
            val (s, e) = stack.removeLast()
            var worst = 0f
            var wi = -1
            val a = pts[s]
            val b = pts[e]
            val abx = b.x - a.x
            val aby = b.y - a.y
            val len = hypot(abx, aby)
            for (i in s + 1 until e) {
                val dist = if (len <= 1e-6f) hypot(pts[i].x - a.x, pts[i].y - a.y)
                else kotlin.math.abs((pts[i].x - a.x) * aby - (pts[i].y - a.y) * abx) / len
                if (dist > worst) {
                    worst = dist
                    wi = i
                }
            }
            if (wi != -1 && worst > eps) {
                keep[wi] = true
                stack.addLast(intArrayOf(s, wi))
                stack.addLast(intArrayOf(wi, e))
            }
        }
        return pts.filterIndexed { i, _ -> keep[i] }
    }

    /**
     * เส้นที่ลากด้วยนิ้ว (จุดถี่ๆ) -> จุดควบคุมไม่กี่จุดให้ลากแก้ต่อได้
     * epsWorld = ความคลาดเคลื่อนที่ยอมได้ในหน่วยพิกัดฉาก (ส่งค่าจากพิกเซลหน้าจอ / ซูม)
     */
    fun simplifyStroke(raw: List<Offset>, epsWorld: Float, maxPoints: Int = 14): List<Offset> {
        if (raw.size < 2) return raw
        var pts = smoothPoints(raw, 3)
        var eps = epsWorld
        var out = rdp(pts, eps)
        var guard = 0
        while (out.size > maxPoints && guard < 12) { // จุดเยอะเกินไปลากแก้ยาก: ขยับความคลาดเคลื่อนขึ้นทีละนิด
            eps *= 1.4f
            out = rdp(pts, eps)
            guard++
        }
        if (out.size == 2 && pts.size > 6) { // เส้นโค้งเบาๆ ที่เหลือแค่ 2 จุด: เติมจุดกลางไว้ให้ดัดโค้งได้
            val mid = pts[pts.size / 2]
            out = listOf(out[0], mid, out[1])
        }
        return out
    }
}

/**
 * ตัวช่วยตอนเล่น/ส่งออก: แก้ท่าของชิ้นรากของตัวละครที่มีเส้นทาง ให้ตำแหน่งระหว่างเฟรมเดินตามเส้นโค้งจริง
 * (ไม่แตะท่าอื่น: มุมหมุน ปั้น พลิก ยังเฉลี่ยตามเดิม) ใช้แทน lerpPose ที่เฉลี่ยตำแหน่งเป็นเส้นตรงระหว่างจุดเฟรม
 */
class PathFollow(paths: List<MotionPath>, parts: List<Part>, frameCount: Int) {
    private class Entry(val pb: PathMath.Playback, val rootIds: Set<Int>) {
        var lastPos = Float.NaN
        var lastLoopN = -1
        var lastCorr: Offset? = null
    }

    private val entries: List<Entry> = paths.mapNotNull { path ->
        val pb = PathMath.prepare(path, frameCount) ?: return@mapNotNull null
        val roots = parts.filter { it.parentId == null && !it.isDetachedItem && it.characterId == path.characterId }.map { it.id }.toSet()
        if (roots.isEmpty()) null else Entry(pb, roots)
    }

    /** ท่าที่ตำแหน่งเล่น position ของชิ้น id: pose = ค่าที่เฉลี่ยตามเดิมแล้ว (lerpPose) */
    fun adjust(id: Int, pose: Pose, position: Float, loopN: Int): Pose {
        for (e in entries) {
            if (id !in e.rootIds) continue
            if (e.lastPos != position || e.lastLoopN != loopN) {
                e.lastCorr = PathMath.curveCorrection(e.pb, position, loopN)
                e.lastPos = position
                e.lastLoopN = loopN
            }
            val c = e.lastCorr ?: return pose
            return pose.copy(dx = pose.dx + c.x, dy = pose.dy + c.y)
        }
        return pose
    }
}
