package com.nop.cartoonstudio

import android.graphics.Bitmap
import android.graphics.Matrix
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.unit.IntSize
import androidx.lifecycle.ViewModel
import kotlin.math.atan2
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

/** ชิ้นส่วนของตัวละครที่คัดลอกไว้ (oldId = id เดิมในฉาก ใช้โยงพ่อ-ลูกและท่าทางตอนวาง) */
class ClipPart(
    val oldId: Int, val parentOldId: Int?, val name: String, val bitmap: Bitmap,
    val x: Float, val y: Float, val pivotX: Float, val pivotY: Float, val restRotation: Float, val boneLength: Float,
    val hasTip: Boolean, val tipX: Float, val tipY: Float, val scale: Float, val flipX: Boolean, val visible: Boolean,
    val mirrorH: Boolean, val mirrorV: Boolean, val charScale: Float,
)

/** ตัวละครที่คัดลอก: ชิ้นส่วนทั้งหมด + ท่าทางของแต่ละเฟรม (id เดิม -> ท่า) */
class CharacterClip(val name: String, val parts: List<ClipPart>, val frames: List<Map<Int, Pose>>) {
    var pasteCount = 0 // วางครั้งที่เท่าไหร่ ใช้เลื่อนตำแหน่งไม่ให้ซ้อนกัน
}

enum class Mode { RIG, ANIMATE }
enum class Tool { MOVE, JOINT, ROTATE, CHAR_ROTATE, CHAR_SCALE } // CHAR_* = หมุน/ขยายทั้งตัวละคร
private enum class DragTarget { EDIT, PAN, TIP, MAIN, CHAR }

class EditorViewModel : ViewModel() {
    val project = Project()
    val skeleton = Skeleton() // ระบบกระดูกใหม่ (รอบที่ 1: สร้าง/เลือก/ลบกระดูก ยังไม่เชื่อมกับภาพ)
    var boneEditorOpen by mutableStateOf(false)
    var restoring by mutableStateOf(true) // true จนกว่าจะอ่านงานที่เซฟอัตโนมัติไว้เสร็จ (ห้ามเขียนทับ autosave ก่อนหน้านั้น)

    var mode by mutableStateOf(Mode.ANIMATE) // แอปเหลือแต่โหมดแอนิเมต
    var tool by mutableStateOf(Tool.MOVE)
    var selectedId by mutableStateOf<Int?>(null)
    var currentFrame by mutableIntStateOf(0)
    var playhead by mutableFloatStateOf(0f)
    var playing by mutableStateOf(false)
    var loop by mutableStateOf(true)
    var fps by mutableIntStateOf(12)
    var videoHeight by mutableIntStateOf(720) // ขนาดวิดีโอ (px) ตั้งในเมนูตั้งค่า: กรอบเส้นประสีฟ้าและค่าเริ่มต้นตอนส่งออกวิดีโอใช้ค่านี้
    var videoWidth by mutableIntStateOf(720)
    var zoom by mutableFloatStateOf(1f)
    var pan by mutableStateOf(Offset.Zero)
    var canvasSize by mutableStateOf(IntSize.Zero)
    var message by mutableStateOf<String?>(null)
    var selectedCharacterId by mutableStateOf<Int?>(null) // ตัวละครที่เลือกในแถบด้านซ้าย: เมนูพลิก/หมุน/ขยาย/ลบ/คัดลอกใช้กับตัวนี้
    var characterClipboard by mutableStateOf<CharacterClip?>(null) // ตัวละครที่คัดลอกไว้ (รวมท่าทางทุกเฟรม) รอกดวาง
    /** ขนาดของตัวละครที่กำลังใช้งาน (1 = 100% ตอนโหลด) */
    val charScale: Float get() {
        val cid = activeCharacterId() ?: return 1f
        return project.parts.firstOrNull { it.characterId == cid }?.charScale ?: 1f
    }
    var mainDragging by mutableStateOf(false) // กำลังลากจุดหลัก (ย้ายทั้งตัว)
    var onionOpacity by mutableFloatStateOf(0.3f) // ความเข้มของเงาเฟรมก่อนหน้า (0 = ปิด)

    private var viewInitialized = false
    private var lastAngle = 0f
    private var dragTarget = DragTarget.PAN
    private var dragRootId: Int? = null

    val selected: Part? get() = project.part(selectedId)

    private val center: Offset get() = Offset(canvasSize.width / 2f, canvasSize.height / 2f)

    // ---------- มุมมอง (view) ----------
    fun onCanvasSize(size: IntSize) {
        canvasSize = size
        if (!viewInitialized && size.width > 0 && size.height > 0) {
            zoom = min(size.width, size.height) * 0.92f / Exporter.WORLD_WINDOW
            pan = Offset.Zero
            viewInitialized = true
        }
    }

    /** ใช้ตอนกู้งานที่เซฟไว้: ตั้งมุมมองเดิม และกัน onCanvasSize ไม่ให้รีเซ็ตซูม/เลื่อนทับ */
    fun restoreView(z: Float, p: Offset) {
        zoom = z
        pan = p
        viewInitialized = true
    }

    fun toWorld(p: Offset): Offset = (p - center - pan) / zoom
    fun toScreen(w: Offset): Offset = center + pan + w * zoom

    fun onTransform(centroid: Offset, panChange: Offset, zoomChange: Float) {
        if (tool == Tool.CHAR_SCALE) { // ใช้ 2 นิ้วถ่าง/หุบ = ขยาย/ย่อตัวละคร
            scaleCharacter(zoomChange)
            pan += panChange
            return
        }
        val newZoom = (zoom * zoomChange).coerceIn(0.1f, 20f)
        val w = (centroid - center - pan) / zoom
        pan = centroid - center - w * newZoom + panChange
        zoom = newZoom
    }

    // ---------- ท่า (pose) ปัจจุบัน ----------
    fun poseOf(): (Int) -> Pose = when {
        mode == Mode.RIG -> { _ -> Pose() }
        playing -> { id -> project.interpolated(playhead, id, if (loop) project.loopCount() else project.frameCount) }
        else -> { id -> project.poseAt(currentFrame, id) }
    }

    private fun updatePose(id: Int, f: (Pose) -> Pose) {
        val map = project.frames[currentFrame]
        map[id] = f(map[id] ?: Pose())
    }

    // ---------- การสัมผัส ----------
    fun onDown(pos: Offset) {
        val w = toWorld(pos)
        mainDragging = false
        val main = nearestMain(pos) // จุดหลัก = ข้อต่อรากของตัวละคร: ลากเพื่อย้ายทั้งตัว
        if (tool == Tool.CHAR_ROTATE || tool == Tool.CHAR_SCALE) {
            if (main != null) {
                startMain(main.first)
            } else if (tool == Tool.CHAR_ROTATE) {
                dragTarget = DragTarget.CHAR // ลากนิ้วรอบจุดหลัก = หมุนทั้งตัวละคร
                lastAngle = angleToMain(w)
            } else {
                dragTarget = DragTarget.PAN // ขยายตัวละครใช้ 2 นิ้ว ส่วน 1 นิ้วเลื่อนมุมมอง
            }
            return
        }
        val cur = selected
        if (cur != null && nearTip(cur, pos)) { // แตะที่จุดต่อของภาพที่เลือกอยู่
            dragTarget = DragTarget.TIP
            lastAngle = angleTo(cur, w)
            return
        }
        val tip = nearestTip(pos)
        if (main != null && (tip == null || main.second <= tip.second)) {
            startMain(main.first) // แตะจุดหลัก: ไม่เปลี่ยนกระดูกที่เลือก แค่ลากย้ายทั้งตัว
            return
        }
        if (tip != null) { // แตะปลายกระดูก: เลือกกระดูกนั้น แล้วลาก = หมุนรอบจุดโคน
            pick(tip.first)
            dragTarget = DragTarget.TIP
            lastAngle = angleTo(tip.first, w)
            return
        }
        val hit = hitTest(project.parts, poseOf(), w.x, w.y)
        if (hit != null) {
            pick(hit)
            dragTarget = DragTarget.EDIT
        } else if (tool == Tool.ROTATE && mode == Mode.ANIMATE && selected != null) {
            dragTarget = DragTarget.EDIT
        } else {
            dragTarget = DragTarget.PAN
        }
        selected?.let { lastAngle = angleTo(it, w) }
    }

    private fun rootParts(): List<Part> = project.parts.filter { it.parentId == null }

    private fun startMain(root: Part) {
        dragRootId = root.id
        dragTarget = DragTarget.MAIN
        mainDragging = true
    }

    /** จุดหลัก = ข้อต่อของชิ้นราก (เช่น จุดล่างสุดของลำตัว) คืนชิ้นรากที่ใกล้นิ้วที่สุดพร้อมระยะ */
    private fun nearestMain(pos: Offset): Pair<Part, Float>? {
        var best: Part? = null
        var bestD = 64f
        for (r in rootParts()) {
            val d = (toScreen(jointWorld(r, poseOf())) - pos).getDistance()
            if (d < bestD) { bestD = d; best = r }
        }
        return best?.let { it to bestD }
    }

    /**
     * แบบเดียวกับตอนดูตัวอย่าง: แตะ/ลากที่ "ปลายกระดูก" = เลือกกระดูกเส้นนั้น แล้วลากเพื่อหมุนรอบจุดโคน (ลูกๆ ตามไป)
     * ปลายกระดูก = จุดที่ห่างจากข้อต่อไปตามความยาวกระดูก (ตรงกับข้อต่อของกระดูกลูก หรือปลายมือสำหรับกระดูกสุดท้าย)
     */
    private fun nearestTip(pos: Offset): Pair<Part, Float>? {
        val joints = computeJointMatrices(project.parts, poseOf())
        var best: Part? = null
        var bestD = 64f // ระยะแตะ (พิกเซลหน้าจอ)
        for (p in project.parts) {
            if (p.boneLength <= 0f) continue
            val j = joints[p.id] ?: continue
            val tp = floatArrayOf(p.boneLength, 0f)
            j.mapPoints(tp)
            val d = (toScreen(Offset(tp[0], tp[1])) - pos).getDistance()
            if (d < bestD) { bestD = d; best = p }
        }
        return best?.let { it to bestD }
    }

    /** เลือกชิ้นส่วน (ถ้าเมนูตัวละครเปิดอยู่ จะย้ายไปเมนูของตัวละครที่ชิ้นนั้นอยู่ด้วย) */
    private fun pick(p: Part) {
        selectedId = p.id
        if (selectedCharacterId != null && p.characterId != 0) selectedCharacterId = p.characterId
    }

    /** ตัวละครที่เครื่องมือหมุน/ขยาย/พลิก/คัดลอกใช้กับ: ตัวที่เลือกในแถบด้านซ้าย ไม่งั้นตัวของชิ้นที่เลือก ไม่งั้นตัวแรก */
    fun activeCharacterId(): Int? {
        val sel = selectedCharacterId
        if (sel != null && project.parts.any { it.characterId == sel }) return sel
        selected?.let { return it.characterId }
        return project.parts.firstOrNull()?.characterId
    }

    private fun activeRoots(): List<Part> {
        val cid = activeCharacterId() ?: return emptyList()
        return rootParts().filter { it.characterId == cid }
    }

    /** +1 = ชิ้นนี้อยู่ในกรอบปกติ, -1 = อยู่ในกรอบที่ถูกพลิกแบบกระจก (การหมุนจะกลับทิศ ต้องกลับเครื่องหมายมุมที่ลาก) */
    private fun handedness(part: Part): Float {
        val m = computeJointMatrices(project.parts) { Pose() }[part.id] ?: return 1f
        val v = FloatArray(9)
        m.getValues(v)
        val det = v[Matrix.MSCALE_X] * v[Matrix.MSCALE_Y] - v[Matrix.MSKEW_X] * v[Matrix.MSKEW_Y]
        return if (det < 0f) -1f else 1f
    }

    private fun angleToMain(w: Offset): Float {
        val first = activeRoots().firstOrNull() ?: return 0f
        val j = jointWorld(first, poseOf())
        return Math.toDegrees(atan2((w.y - j.y).toDouble(), (w.x - j.x).toDouble())).toFloat()
    }

    /** หมุนตัวละครที่เลือกรอบจุดหลัก (หมุนชิ้นรากในเฟรมปัจจุบัน ลูกๆ ตามไปเอง) */
    private fun rotateCharacter(w: Offset) {
        val roots = activeRoots()
        val first = roots.firstOrNull() ?: return
        val a = angleToMain(w)
        var d = a - lastAngle
        while (d > 180f) d -= 360f
        while (d < -180f) d += 360f
        lastAngle = a
        d *= handedness(first)
        for (r in roots) updatePose(r.id) { it.copy(rotation = it.rotation + d) }
    }

    /** มุมที่หมุนตัวละครที่เลือกในเฟรมปัจจุบัน (องศา) ไว้แสดงเป็นตัวเลข */
    fun characterAngle(): Float {
        val first = activeRoots().firstOrNull() ?: return 0f
        var r = (poseOf()(first.id).rotation * handedness(first)) % 360f
        if (r > 180f) r -= 360f
        if (r <= -180f) r += 360f
        return r
    }

    /** ขยาย/ย่อตัวละครที่เลือกรอบจุดหลัก (ภาพ ความยาวกระดูก และตำแหน่งข้อต่อของลูกทุกชิ้นคูณเท่ากัน) ตัวอื่นไม่เปลี่ยน */
    fun scaleCharacter(factor: Float) {
        val cid = activeCharacterId() ?: return
        val ps = project.parts.filter { it.characterId == cid }
        if (ps.isEmpty()) return
        val current = ps.first().charScale
        val target = (current * factor).coerceIn(0.1f, 10f)
        val k = target / current
        if (k == 1f) return
        for (p in ps) {
            p.scale *= k
            p.boneLength *= k
            if (p.parentId != null) {
                p.x *= k
                p.y *= k
            }
            p.charScale = target
        }
    }

    /**
     * ลากจุดหลัก = ย้ายทั้งตัวละคร: ชิ้นรากทุกชิ้น (parent = ไม่มี) ขยับด้วยกัน
     * ตัวละครที่เซฟจากหน้าแก้ไขกระดูกอาจมีกระดูกที่ออกจากจุดราก (0,0) หลายเส้น (เช่น ขาซ้าย/ขวา/ลำตัว)
     * ซึ่งทุกเส้นเริ่มที่จุดเดียวกัน ถ้าขยับแค่ชิ้นเดียวจุดเริ่มต้นจะแยกออกจากกัน
     */
    private fun moveMain(delta: Offset) {
        val dragRoot = project.part(dragRootId) ?: return
        val v = delta / zoom
        // ย้ายเฉพาะตัวละครที่ลาก (ชิ้นรากทั้งหมดของตัวละครเดียวกัน) ตัวละครอื่นในฉากอยู่กับที่
        for (root in rootParts().filter { it.characterId == dragRoot.characterId }) {
            if (mode == Mode.RIG) {
                root.x += v.x
                root.y += v.y
            } else {
                updatePose(root.id) { it.copy(dx = it.dx + v.x, dy = it.dy + v.y) }
            }
        }
    }

    fun onUp() {
        mainDragging = false
    }

    fun onDrag(pos: Offset, delta: Offset) {
        when (dragTarget) {
            DragTarget.PAN -> {
                pan += delta
                return
            }
            DragTarget.MAIN -> {
                if (!playing) moveMain(delta)
                return
            }
            DragTarget.CHAR -> {
                if (!playing) rotateCharacter(toWorld(pos))
                return
            }
            else -> {}
        }
        val part = selected ?: return
        if (playing) return
        val w = toWorld(pos)
        if (dragTarget == DragTarget.TIP) {
            rotateToward(part, w) // ลากปุ่มเขียว: หมุนเฉพาะภาพรอบปุ่มแดง ปุ่มทั้งสองอยู่กับที่
            return
        }
        val poseFn = poseOf()
        when (tool) {
            Tool.MOVE -> {
                val v = toParentVector(part, poseFn, delta / zoom)
                if (mode == Mode.RIG) {
                    part.x += v.x
                    part.y += v.y
                } else if (part.parentId != null) {
                    rotateToward(part, w) // ชิ้นที่มี parent: ลากแล้วหมุนรอบข้อต่อ (ไม่หลุดจาก parent)
                } else {
                    updatePose(part.id) { it.copy(dx = it.dx + v.x, dy = it.dy + v.y) }
                }
            }
            Tool.JOINT -> if (mode == Mode.RIG) moveJoint(part, w)
            Tool.ROTATE -> if (mode == Mode.ANIMATE) rotateToward(part, w)
            Tool.CHAR_ROTATE, Tool.CHAR_SCALE -> {}
        }
    }

    fun addTip(part: Part) {
        val h = part.bitmap.height.toFloat()
        part.tipX = part.pivotX
        part.tipY = if (part.pivotY <= h / 2f) h else 0f // ค่าเริ่มต้น: ขอบด้านตรงข้ามข้อต่อ ลากปรับได้
        part.hasTip = true
    }

    fun removeTip(part: Part) {
        part.hasTip = false
    }

    private fun nearTip(part: Part, pos: Offset): Boolean {
        if (!part.hasTip) return false
        val j = jointWorld(part, poseOf())
        return (toScreen(Offset(j.x, j.y + tipLength(part))) - pos).getDistance() < 56f
    }

    private fun rotateToward(part: Part, w: Offset) {
        val a = angleTo(part, w)
        var d = a - lastAngle
        while (d > 180f) d -= 360f
        while (d < -180f) d += 360f
        lastAngle = a
        d *= handedness(part) // ตัวละครที่พลิกแบบกระจกอยู่ หมุนทิศตรงข้าม
        if (mode == Mode.RIG) {
            part.restRotation += d // โหมดโครง: หมุนภาพรอบข้อต่อเป็นมุมพื้นฐาน ชิ้นลูกตามไปด้วย
        } else {
            updatePose(part.id) { it.copy(rotation = it.rotation + d) }
        }
    }

    private fun jointWorld(part: Part, poseFn: (Int) -> Pose): Offset {
        val m = computeJointMatrices(project.parts, poseFn)[part.id] ?: return Offset.Zero
        val pt = floatArrayOf(0f, 0f)
        m.mapPoints(pt)
        return Offset(pt[0], pt[1])
    }

    private fun angleTo(part: Part, w: Offset): Float {
        val j = jointWorld(part, poseOf())
        return Math.toDegrees(atan2((w.y - j.y).toDouble(), (w.x - j.x).toDouble())).toFloat()
    }

    private fun toParentVector(part: Part, poseFn: (Int) -> Pose, v: Offset): Offset {
        val joints = computeJointMatrices(project.parts, poseFn)
        val pm = part.parentId?.let { joints[it] } ?: return v
        val inv = Matrix()
        if (!pm.invert(inv)) return v
        val arr = floatArrayOf(v.x, v.y)
        inv.mapVectors(arr)
        return Offset(arr[0], arr[1])
    }

    /** ย้ายข้อต่อของชิ้นส่วนไปยังจุดที่แตะ โดยภาพและลูกๆ ไม่ขยับ (เฉพาะโหมดโครง) */
    private fun moveJoint(part: Part, w: Offset) {
        val joints = computeJointMatrices(project.parts) { Pose() }
        val myJoint = joints[part.id] ?: return
        val dm = drawMatrix(part, myJoint)
        val inv = Matrix()
        if (!dm.invert(inv)) return
        val pt = floatArrayOf(w.x, w.y)
        inv.mapPoints(pt)
        val newPx = pt[0].coerceIn(0f, part.bitmap.width.toFloat())
        val newPy = pt[1].coerceIn(0f, part.bitmap.height.toFloat())

        val target = floatArrayOf(newPx, newPy)
        dm.mapPoints(target) // จุดใหม่บนภาพ -> พิกัดโลก (ใช้ matrix เดิม ภาพจึงไม่ขยับ)
        val pm = part.parentId?.let { joints[it] } ?: Matrix()
        val pinv = Matrix()
        if (!pm.invert(pinv)) return
        pinv.mapPoints(target)

        val dx = target[0] - part.x
        val dy = target[1] - part.y
        part.pivotX = newPx
        part.pivotY = newPy
        part.x = target[0]
        part.y = target[1]
        val rad = Math.toRadians(part.restRotation.toDouble())
        val cs = Math.cos(rad).toFloat()
        val sn = Math.sin(rad).toFloat()
        for (c in project.children(part.id)) { // ชดเชยให้ลูกอยู่ที่เดิมในโลก (แปลงเข้ากรอบที่หมุนแล้วของชิ้นนี้)
            c.x -= dx * cs + dy * sn
            c.y -= -dx * sn + dy * cs
        }
    }

    // ---------- คำสั่ง ----------
    @JvmName("applyMode")
    fun setMode(m: Mode) {
        mode = m
        playing = false
        tool = when (m) {
            Mode.RIG -> if (tool == Tool.ROTATE) Tool.MOVE else tool
            Mode.ANIMATE -> if (tool == Tool.JOINT) Tool.ROTATE else tool
        }
    }

    fun addImported(name: String, bmp: Bitmap) {
        val part = project.addPart(name, bmp)
        val maxSide = max(bmp.width, bmp.height).toFloat()
        part.scale = if (maxSide > 300f) 300f / maxSide else 1f // คงสัดส่วนเดิม (ย่อแบบ uniform)
        val c = toWorld(center)
        part.x = c.x
        part.y = c.y
        selectedId = part.id
    }

    /** โหลดตัวละครที่แปลงจากกระดูกแล้ว เพิ่มเข้าฉากแอนิเมต (มีได้หลายตัว) */
    fun loadCharacter(built: List<BuiltPart>, name: String) {
        val cid = project.newCharacterId() // เพิ่มเข้าฉาก ไม่ล้างตัวเดิม
        val partIdOf = HashMap<Int, Int>() // id กระดูก -> id ชิ้นส่วน
        for (bp in built) { // ใส่พ่อ-ลูกรอบสอง เพราะลำดับชั้นอาจให้ลูกอยู่ก่อนพ่อในลิสต์
            val part = project.addPart(bp.name, bp.bitmap, null)
            part.pivotX = bp.pivotX
            part.pivotY = bp.pivotY
            part.scale = bp.scale
            part.x = bp.x
            part.y = bp.y
            part.restRotation = bp.restRotation
            part.boneLength = bp.boneLength
            part.characterId = cid
            part.characterName = name
            partIdOf[bp.boneId] = part.id
        }
        for (bp in built) {
            val parentPartId = bp.parentBoneId?.let { partIdOf[it] } ?: continue
            project.part(partIdOf[bp.boneId])?.parentId = parentPartId
        }
        selectedId = partIdOf.values.firstOrNull()
    }

    fun deleteCharacter(characterId: Int) {
        if (selected?.characterId == characterId) selectedId = null
        if (selectedCharacterId == characterId) closeCharacterMenu()
        project.removeCharacter(characterId)
    }

    // ---------- เมนูตัวละคร (แถบเลเยอร์ด้านซ้าย) ----------
    /** แตะตัวละครในแถบซ้าย: เปิดเมนูของตัวนั้น แตะซ้ำ = ปิดเมนู */
    fun toggleCharacterMenu(cid: Int) {
        if (selectedCharacterId == cid) closeCharacterMenu() else selectedCharacterId = cid
    }

    fun closeCharacterMenu() {
        selectedCharacterId = null
        if (tool == Tool.CHAR_ROTATE || tool == Tool.CHAR_SCALE) tool = Tool.MOVE
    }

    /** เปิด/ปิดเครื่องมือหมุนหรือขยายตัวละครที่เลือก (กดซ้ำ = กลับโหมดปกติ) */
    fun toggleCharTool(t: Tool) {
        tool = if (tool == t) Tool.MOVE else t
    }

    /** พลิกตัวละครที่เลือกแบบกระจก (ทุกเฟรม) รอบจุดหลัก: horizontal = ซ้าย-ขวา, ไม่ใช่ = ขึ้น-ลง */
    fun flipCharacter(horizontal: Boolean) {
        if (playing) return
        val cid = activeCharacterId() ?: return
        for (p in project.parts) {
            if (p.characterId != cid) continue
            if (horizontal) p.mirrorH = !p.mirrorH else p.mirrorV = !p.mirrorV
        }
    }

    /** คัดลอกตัวละครที่เลือก (ภาพ โครงกระดูก ขนาด การพลิก และท่าทางทุกเฟรม) ไว้รอกดวาง */
    fun copyCharacter() {
        val cid = activeCharacterId() ?: return
        val ps = project.parts.filter { it.characterId == cid }
        if (ps.isEmpty()) return
        val ids = ps.map { it.id }.toSet()
        val cps = ps.map { p ->
            ClipPart(
                p.id, p.parentId?.takeIf { it in ids }, p.name, p.bitmap, p.x, p.y, p.pivotX, p.pivotY,
                p.restRotation, p.boneLength, p.hasTip, p.tipX, p.tipY, p.scale, p.flipX, p.visible,
                p.mirrorH, p.mirrorV, p.charScale,
            )
        }
        val frames: List<Map<Int, Pose>> = project.frames.map { f ->
            ids.mapNotNull { id -> f[id]?.let { id to it } }.toMap()
        }
        val name = ps.first().characterName.ifBlank { "ตัวละคร" }
        characterClipboard = CharacterClip(name, cps, frames)
        message = "คัดลอกตัวละคร \"$name\" แล้ว (รวมท่าทางทุกเฟรม) กดปุ่มวางที่มุมขวาบน"
    }

    /** วางตัวละครที่คัดลอกไว้เป็นตัวใหม่ (เลื่อนตำแหน่งเล็กน้อยไม่ให้ซ้อนทับ) พร้อมท่าทางในเฟรมที่มีอยู่ */
    fun pasteCharacter() {
        if (playing) return
        val clip = characterClipboard ?: return
        val cid = project.newCharacterId()
        val offset = 40f * (++clip.pasteCount)
        val idMap = HashMap<Int, Int>()
        val newName = if (clip.name.endsWith(" (สำเนา)")) clip.name else clip.name + " (สำเนา)"
        for (cp in clip.parts) {
            val part = project.addPart(cp.name, cp.bitmap, null)
            part.x = cp.x
            part.y = cp.y
            part.pivotX = cp.pivotX
            part.pivotY = cp.pivotY
            part.restRotation = cp.restRotation
            part.boneLength = cp.boneLength
            part.hasTip = cp.hasTip
            part.tipX = cp.tipX
            part.tipY = cp.tipY
            part.scale = cp.scale
            part.flipX = cp.flipX
            part.visible = cp.visible
            part.mirrorH = cp.mirrorH
            part.mirrorV = cp.mirrorV
            part.charScale = cp.charScale
            part.characterId = cid
            part.characterName = newName
            if (cp.parentOldId == null) {
                part.x += offset
                part.y += offset
            }
            idMap[cp.oldId] = part.id
        }
        for (cp in clip.parts) {
            val parentNew = cp.parentOldId?.let { idMap[it] } ?: continue
            project.part(idMap[cp.oldId])?.parentId = parentNew
        }
        for (i in 0 until minOf(clip.frames.size, project.frameCount)) {
            for ((oldId, pose) in clip.frames[i]) idMap[oldId]?.let { project.frames[i][it] = pose }
        }
        selectedCharacterId = cid
        selectedId = idMap[clip.parts.first().oldId]
        message = "วางตัวละคร \"$newName\" แล้ว"
    }

    fun addDemo() {
        DemoCharacter.build(project)
        selectedId = project.parts.firstOrNull()?.id
    }

    fun deleteSelected() {
        val s = selected ?: return
        project.removeWithDescendants(s.id)
        selectedId = null
    }

    fun clearProject() {
        playing = false
        project.clear()
        selectedId = null
        currentFrame = 0
        playhead = 0f
    }

    /** เปลี่ยน parent โดยคงตำแหน่งข้อต่อในโลกเดิม */
    fun setParent(part: Part, newParentId: Int?) {
        if (newParentId == part.id) return
        if (newParentId != null && newParentId in project.descendants(part.id)) {
            message = "ตั้ง parent (ชิ้นแม่) เป็นลูกหลานของตัวเองไม่ได้"
            return
        }
        val joints = computeJointMatrices(project.parts) { Pose() }
        val mine = joints[part.id] ?: return
        val pt = floatArrayOf(0f, 0f)
        mine.mapPoints(pt)
        val npm = newParentId?.let { joints[it] } ?: Matrix()
        val inv = Matrix()
        if (!npm.invert(inv)) return
        inv.mapPoints(pt)
        val oldAcc = accumulatedRest(part.parentId)
        part.parentId = newParentId
        part.x = pt[0]
        part.y = pt[1]
        part.restRotation += oldAcc - accumulatedRest(newParentId) // คงทิศทางภาพในโลกไว้เหมือนเดิม
    }

    private fun accumulatedRest(id: Int?): Float {
        var sum = 0f
        var cur = project.part(id)
        var guard = 0
        while (cur != null && guard++ < 64) {
            sum += cur.restRotation
            cur = project.part(cur.parentId)
        }
        return sum
    }

    fun copyFromPreviousFrame() {
        if (currentFrame == 0) {
            message = "เฟรมแรกไม่มีเฟรมก่อนหน้า"
            return
        }
        val dst = project.frames[currentFrame]
        dst.clear()
        dst.putAll(project.frames[currentFrame - 1])
    }

    /** เพิ่มเฟรมท้ายสุด คัดลอกท่าจากเฟรมท้ายเดิม แล้วย้ายไปอยู่ที่เฟรมใหม่ */
    fun addFrame() {
        if (playing) return
        project.addFrameFrom(project.frameCount - 1)
        currentFrame = project.frameCount - 1
        playhead = currentFrame.toFloat()
    }

    /** ลบเฟรมปัจจุบัน เฟรมหลังจากนี้เลื่อนขึ้นมาแทน (ต้องเหลืออย่างน้อย 1 เฟรม) */
    fun deleteCurrentFrame() {
        if (playing) return
        if (!project.removeFrame(currentFrame)) {
            message = "ต้องมีอย่างน้อย 1 เฟรม"
            return
        }
        currentFrame = currentFrame.coerceAtMost(project.frameCount - 1)
        playhead = currentFrame.toFloat()
    }

    fun clearFrame() = project.frames[currentFrame].clear()

    var frameClipboard by mutableStateOf<Map<Int, Pose>?>(null) // ท่าของเฟรมที่คัดลอกไว้ (id ชิ้นส่วน -> ท่า)
    var frameClipboardFrom by mutableIntStateOf(0) // เลขเฟรม (เริ่มที่ 1) ที่คัดลอกมา

    /** คัดลอกท่าของเฟรม index ไว้ (ยังไม่เพิ่มอะไรจนกว่าจะกดวาง) */
    fun copyFrame(index: Int) {
        val f = project.frames.getOrNull(index) ?: return
        frameClipboard = f.toMap()
        frameClipboardFrom = index + 1
    }

    /** วางเฟรมที่คัดลอกไว้: เพิ่มเป็นเฟรมใหม่ต่อจากเฟรม index แล้วไปอยู่ที่เฟรมนั้น (ท่าของชิ้นที่ถูกลบไปแล้วจะไม่ถูกใส่) */
    fun pasteFrameAfter(index: Int) {
        if (playing) return
        val clip = frameClipboard ?: return
        val alive = project.parts.map { it.id }.toSet()
        project.insertFrameAt(index + 1, clip.filterKeys { it in alive })
        currentFrame = (index + 1).coerceAtMost(project.frameCount - 1)
        playhead = currentFrame.toFloat()
    }

    /** ลบเฟรมที่ index (ต้องเหลืออย่างน้อย 1 เฟรม) เฟรมหลังจากนั้นเลื่อนขึ้นมาแทน */
    fun deleteFrame(index: Int) {
        if (playing) return
        if (!project.removeFrame(index)) {
            message = "ต้องมีอย่างน้อย 1 เฟรม"
            return
        }
        currentFrame = if (index < currentFrame) currentFrame - 1 else currentFrame.coerceAtMost(project.frameCount - 1)
        playhead = currentFrame.toFloat()
    }

    /**
     * ลบหลายเฟรมพร้อมกัน (indices = เลขเฟรมเริ่มที่ 0) เฟรมหลังจากนั้นเลื่อนขึ้นมาแทน
     * ถ้าเลือกครบทุกเฟรม = ลบทั้งหมด (เหลือ 1 เฟรมว่าง) คืนจำนวนเฟรมที่ถูกลบ
     */
    fun deleteFrames(indices: Set<Int>): Int {
        if (playing) return 0
        val valid = indices.filter { it in project.frames.indices }.toSortedSet()
        if (valid.isEmpty()) return 0
        if (valid.size >= project.frameCount) return deleteAllFrames()
        val oldCurrent = currentFrame
        for (i in valid.reversed()) project.removeFrame(i) // ลบจากท้ายมาหน้า เลขเฟรมที่ยังไม่ลบจึงไม่เพี้ยน
        val before = valid.count { it < oldCurrent }
        currentFrame = (oldCurrent - before).coerceIn(0, project.frameCount - 1)
        playhead = currentFrame.toFloat()
        return valid.size
    }

    /** ลบเฟรมทั้งหมด เหลือ 1 เฟรมว่าง (ตัวละครและกระดูกไม่หาย) คืนจำนวนเฟรมที่มีก่อนลบ */
    fun deleteAllFrames(): Int {
        if (playing) return 0
        val n = project.frameCount
        project.resetFrames()
        currentFrame = 0
        playhead = 0f
        return n
    }

    // ---------- งาน (โปรเจกต์) ----------
    var projectName by mutableStateOf("") // ชื่องานที่เซฟ/โหลดล่าสุด ใช้เป็นชื่อเริ่มต้นตอนกดเซฟงาน

    /** เริ่มงานใหม่: ล้างตัวละครในฉาก เฟรม ช่วงความเร็ว และโครงกระดูก (ตัวละครที่เซฟไว้ในแอปและงานที่เซฟไว้ไม่หาย) */
    fun newProject() {
        playing = false
        project.clear()
        skeleton.replaceWith(Skeleton())
        selectedId = null
        currentFrame = 0
        playhead = 0f
        selectedCharacterId = null
        if (tool == Tool.CHAR_ROTATE || tool == Tool.CHAR_SCALE) tool = Tool.MOVE
        frameClipboard = null
        frameClipboardFrom = 0
        boneEditorOpen = false
        projectName = ""
    }

    fun resetSelectedPose() {
        selectedId?.let { project.frames[currentFrame].remove(it) }
    }

    // ---------- เล่นแอนิเมชัน ----------
    fun togglePlay() {
        if (mode != Mode.ANIMATE) return
        if (playing) {
            playing = false
            currentFrame = playhead.roundToInt().mod(project.frameCount)
        } else {
            playhead = currentFrame.toFloat()
            playing = true
        }
    }

    fun stop() {
        playing = false
        currentFrame = 0
        playhead = 0f
    }

    fun tick(dtSeconds: Float) {
        if (!playing) return
        val n = if (loop) project.loopCount() else project.frameCount
        var p = playhead
        if (p >= n) p = 0f
        // กันเฟรมสะดุด (เช่นเครื่องหน่วงชั่วขณะ) ไม่ให้ข้ามเฟรมหรือกระโดดตอนวนกลับ
        var left = dtSeconds.coerceIn(0f, 0.25f)
        var guard = 0
        // เดินทีละเฟรมตามความเร็วของเฟรมนั้น (อยู่ในช่วงที่ตั้งความเร็วเองใช้ค่าของช่วง ไม่งั้นใช้ fps ปกติ)
        while (left > 0f && guard++ < 1000) {
            val idx = p.toInt().coerceIn(0, n - 1)
            val f = project.fpsAt(idx, fps).toFloat()
            val toNext = (idx + 1 - p) / f // เวลา (วินาที) ที่เหลือก่อนถึงเฟรมถัดไป
            if (left < toNext) {
                p += left * f
                left = 0f
            } else {
                left -= toNext
                p = (idx + 1).toFloat()
            }
            if (loop) {
                if (p >= n) p -= n
            } else if (p >= n - 1) {
                p = (n - 1).toFloat()
                playing = false
                break
            }
        }
        playhead = p
        currentFrame = p.toInt().coerceIn(0, n - 1)
    }
}
