package com.nop.cartoonstudio

import android.graphics.Bitmap
import android.graphics.Matrix
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.unit.IntSize
import androidx.lifecycle.ViewModel
import kotlin.math.atan2
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

enum class Mode { RIG, ANIMATE }
enum class Tool { MOVE, JOINT, ROTATE }
private enum class DragTarget { EDIT, PAN, TIP }

class EditorViewModel : ViewModel() {
    val project = Project()

    var mode by mutableStateOf(Mode.RIG)
    var tool by mutableStateOf(Tool.MOVE)
    var selectedId by mutableStateOf<Int?>(null)
    var currentFrame by mutableIntStateOf(0)
    var playhead by mutableFloatStateOf(0f)
    var playing by mutableStateOf(false)
    var loop by mutableStateOf(true)
    var fps by mutableIntStateOf(12)
    var zoom by mutableFloatStateOf(1f)
    var pan by mutableStateOf(Offset.Zero)
    var canvasSize by mutableStateOf(IntSize.Zero)
    var message by mutableStateOf<String?>(null)

    private var viewInitialized = false
    private var lastAngle = 0f
    private var dragTarget = DragTarget.PAN

    val selected: Part? get() = project.part(selectedId)

    private val center: Offset get() = Offset(canvasSize.width / 2f, canvasSize.height / 2f)

    // ---------- มุมมอง (view) ----------
    fun onCanvasSize(size: IntSize) {
        canvasSize = size
        if (!viewInitialized && size.width > 0 && size.height > 0) {
            zoom = min(size.width, size.height) * 0.92f / Exporter.WORLD_WINDOW
            pan = Offset.Zero
            viewInitialized = true
        }
    }

    fun toWorld(p: Offset): Offset = (p - center - pan) / zoom
    fun toScreen(w: Offset): Offset = center + pan + w * zoom

    fun onTransform(centroid: Offset, panChange: Offset, zoomChange: Float) {
        val newZoom = (zoom * zoomChange).coerceIn(0.1f, 20f)
        val w = (centroid - center - pan) / zoom
        pan = centroid - center - w * newZoom + panChange
        zoom = newZoom
    }

    // ---------- ท่า (pose) ปัจจุบัน ----------
    fun poseOf(): (Int) -> Pose = when {
        mode == Mode.RIG -> { _ -> Pose() }
        playing -> { id -> project.interpolated(playhead, id) }
        else -> { id -> project.poseAt(currentFrame, id) }
    }

    private fun updatePose(id: Int, f: (Pose) -> Pose) {
        val map = project.frames[currentFrame]
        map[id] = f(map[id] ?: Pose())
    }

    // ---------- การสัมผัส ----------
    fun onDown(pos: Offset) {
        val w = toWorld(pos)
        val cur = selected
        if (cur != null && nearTip(cur, pos)) { // แตะที่จุดต่อของภาพที่เลือกอยู่
            dragTarget = DragTarget.TIP
            lastAngle = angleTo(cur, w)
            return
        }
        val hit = hitTest(project.parts, poseOf(), w.x, w.y)
        if (hit != null) {
            selectedId = hit.id
            dragTarget = DragTarget.EDIT
        } else if (tool == Tool.ROTATE && mode == Mode.ANIMATE && selected != null) {
            dragTarget = DragTarget.EDIT
        } else {
            dragTarget = DragTarget.PAN
        }
        selected?.let { lastAngle = angleTo(it, w) }
    }

    fun onDrag(pos: Offset, delta: Offset) {
        if (dragTarget == DragTarget.PAN) {
            pan += delta
            return
        }
        val part = selected ?: return
        if (playing) return
        val w = toWorld(pos)
        if (dragTarget == DragTarget.TIP) {
            rotateToward(part, w) // ลากปุ่มเขียว: หมุนเฉพาะภาพรอบปุ่มแดง ปุ่มทั้งสองอยู่กับที่
            return
        }
        val poseFn = poseOf()
        when (tool) {
            Tool.MOVE -> {
                val v = toParentVector(part, poseFn, delta / zoom)
                if (mode == Mode.RIG) {
                    part.x += v.x
                    part.y += v.y
                } else if (part.parentId != null) {
                    rotateToward(part, w) // ชิ้นที่มี parent: ลากแล้วหมุนรอบข้อต่อ (ไม่หลุดจาก parent)
                } else {
                    updatePose(part.id) { it.copy(dx = it.dx + v.x, dy = it.dy + v.y) }
                }
            }
            Tool.JOINT -> if (mode == Mode.RIG) moveJoint(part, w)
            Tool.ROTATE -> if (mode == Mode.ANIMATE) rotateToward(part, w)
        }
    }

    fun addTip(part: Part) {
        val h = part.bitmap.height.toFloat()
        part.tipX = part.pivotX
        part.tipY = if (part.pivotY <= h / 2f) h else 0f // ค่าเริ่มต้น: ขอบด้านตรงข้ามข้อต่อ ลากปรับได้
        part.hasTip = true
    }

    fun removeTip(part: Part) {
        part.hasTip = false
    }

    private fun nearTip(part: Part, pos: Offset): Boolean {
        if (!part.hasTip) return false
        val j = jointWorld(part, poseOf())
        return (toScreen(Offset(j.x, j.y + tipLength(part))) - pos).getDistance() < 56f
    }

    private fun rotateToward(part: Part, w: Offset) {
        val a = angleTo(part, w)
        var d = a - lastAngle
        while (d > 180f) d -= 360f
        while (d < -180f) d += 360f
        lastAngle = a
        if (mode == Mode.RIG) {
            part.restRotation += d // โหมดโครง: หมุนภาพรอบข้อต่อเป็นมุมพื้นฐาน ชิ้นลูกตามไปด้วย
        } else {
            updatePose(part.id) { it.copy(rotation = it.rotation + d) }
        }
    }

    private fun jointWorld(part: Part, poseFn: (Int) -> Pose): Offset {
        val m = computeJointMatrices(project.parts, poseFn)[part.id] ?: return Offset.Zero
        val pt = floatArrayOf(0f, 0f)
        m.mapPoints(pt)
        return Offset(pt[0], pt[1])
    }

    private fun angleTo(part: Part, w: Offset): Float {
        val j = jointWorld(part, poseOf())
        return Math.toDegrees(atan2((w.y - j.y).toDouble(), (w.x - j.x).toDouble())).toFloat()
    }

    private fun toParentVector(part: Part, poseFn: (Int) -> Pose, v: Offset): Offset {
        val joints = computeJointMatrices(project.parts, poseFn)
        val pm = part.parentId?.let { joints[it] } ?: return v
        val inv = Matrix()
        if (!pm.invert(inv)) return v
        val arr = floatArrayOf(v.x, v.y)
        inv.mapVectors(arr)
        return Offset(arr[0], arr[1])
    }

    /** ย้ายข้อต่อของชิ้นส่วนไปยังจุดที่แตะ โดยภาพและลูกๆ ไม่ขยับ (เฉพาะโหมดโครง) */
    private fun moveJoint(part: Part, w: Offset) {
        val joints = computeJointMatrices(project.parts) { Pose() }
        val myJoint = joints[part.id] ?: return
        val dm = drawMatrix(part, myJoint)
        val inv = Matrix()
        if (!dm.invert(inv)) return
        val pt = floatArrayOf(w.x, w.y)
        inv.mapPoints(pt)
        val newPx = pt[0].coerceIn(0f, part.bitmap.width.toFloat())
        val newPy = pt[1].coerceIn(0f, part.bitmap.height.toFloat())

        val target = floatArrayOf(newPx, newPy)
        dm.mapPoints(target) // จุดใหม่บนภาพ -> พิกัดโลก (ใช้ matrix เดิม ภาพจึงไม่ขยับ)
        val pm = part.parentId?.let { joints[it] } ?: Matrix()
        val pinv = Matrix()
        if (!pm.invert(pinv)) return
        pinv.mapPoints(target)

        val dx = target[0] - part.x
        val dy = target[1] - part.y
        part.pivotX = newPx
        part.pivotY = newPy
        part.x = target[0]
        part.y = target[1]
        val rad = Math.toRadians(part.restRotation.toDouble())
        val cs = Math.cos(rad).toFloat()
        val sn = Math.sin(rad).toFloat()
        for (c in project.children(part.id)) { // ชดเชยให้ลูกอยู่ที่เดิมในโลก (แปลงเข้ากรอบที่หมุนแล้วของชิ้นนี้)
            c.x -= dx * cs + dy * sn
            c.y -= -dx * sn + dy * cs
        }
    }

    // ---------- คำสั่ง ----------
    @JvmName("applyMode")
    fun setMode(m: Mode) {
        mode = m
        playing = false
        tool = when (m) {
            Mode.RIG -> if (tool == Tool.ROTATE) Tool.MOVE else tool
            Mode.ANIMATE -> if (tool == Tool.JOINT) Tool.ROTATE else tool
        }
    }

    fun addImported(name: String, bmp: Bitmap) {
        val part = project.addPart(name, bmp)
        val maxSide = max(bmp.width, bmp.height).toFloat()
        part.scale = if (maxSide > 300f) 300f / maxSide else 1f // คงสัดส่วนเดิม (ย่อแบบ uniform)
        val c = toWorld(center)
        part.x = c.x
        part.y = c.y
        selectedId = part.id
    }

    fun addDemo() {
        DemoCharacter.build(project)
        selectedId = project.parts.firstOrNull()?.id
    }

    fun deleteSelected() {
        val s = selected ?: return
        project.removeWithDescendants(s.id)
        selectedId = null
    }

    fun clearProject() {
        playing = false
        project.clear()
        selectedId = null
        currentFrame = 0
        playhead = 0f
    }

    /** เปลี่ยน parent โดยคงตำแหน่งข้อต่อในโลกเดิม */
    fun setParent(part: Part, newParentId: Int?) {
        if (newParentId == part.id) return
        if (newParentId != null && newParentId in project.descendants(part.id)) {
            message = "ตั้ง parent (ชิ้นแม่) เป็นลูกหลานของตัวเองไม่ได้"
            return
        }
        val joints = computeJointMatrices(project.parts) { Pose() }
        val mine = joints[part.id] ?: return
        val pt = floatArrayOf(0f, 0f)
        mine.mapPoints(pt)
        val npm = newParentId?.let { joints[it] } ?: Matrix()
        val inv = Matrix()
        if (!npm.invert(inv)) return
        inv.mapPoints(pt)
        val oldAcc = accumulatedRest(part.parentId)
        part.parentId = newParentId
        part.x = pt[0]
        part.y = pt[1]
        part.restRotation += oldAcc - accumulatedRest(newParentId) // คงทิศทางภาพในโลกไว้เหมือนเดิม
    }

    private fun accumulatedRest(id: Int?): Float {
        var sum = 0f
        var cur = project.part(id)
        var guard = 0
        while (cur != null && guard++ < 64) {
            sum += cur.restRotation
            cur = project.part(cur.parentId)
        }
        return sum
    }

    fun copyFromPreviousFrame() {
        if (currentFrame == 0) {
            message = "เฟรมแรกไม่มีเฟรมก่อนหน้า"
            return
        }
        val dst = project.frames[currentFrame]
        dst.clear()
        dst.putAll(project.frames[currentFrame - 1])
    }

    fun clearFrame() = project.frames[currentFrame].clear()

    fun resetSelectedPose() {
        selectedId?.let { project.frames[currentFrame].remove(it) }
    }

    // ---------- เล่นแอนิเมชัน ----------
    fun togglePlay() {
        if (mode != Mode.ANIMATE) return
        if (playing) {
            playing = false
            currentFrame = playhead.roundToInt().mod(project.frameCount)
        } else {
            playhead = currentFrame.toFloat()
            playing = true
        }
    }

    fun stop() {
        playing = false
        currentFrame = 0
        playhead = 0f
    }

    fun tick(dtSeconds: Float) {
        if (!playing) return
        val n = project.frameCount
        var p = playhead + dtSeconds * fps
        if (loop) {
            while (p >= n) p -= n
        } else if (p >= n - 1) {
            p = (n - 1).toFloat()
            playing = false
        }
        playhead = p
        currentFrame = p.toInt().coerceIn(0, n - 1)
    }
}
