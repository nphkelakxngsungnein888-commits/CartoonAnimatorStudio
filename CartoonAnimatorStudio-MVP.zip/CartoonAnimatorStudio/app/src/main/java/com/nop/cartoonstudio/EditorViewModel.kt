package com.nop.cartoonstudio

import android.graphics.Bitmap
import android.graphics.Matrix
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.unit.IntSize
import androidx.lifecycle.ViewModel
import kotlin.math.atan2
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

/** ชิ้นส่วนของตัวละครที่คัดลอกไว้ (oldId = id เดิมในฉาก ใช้โยงพ่อ-ลูกและท่าทางตอนวาง) */
class ClipPart(
    val oldId: Int, val parentOldId: Int?, val name: String, val bitmap: Bitmap,
    val x: Float, val y: Float, val pivotX: Float, val pivotY: Float, val restRotation: Float, val boneLength: Float,
    val hasTip: Boolean, val tipX: Float, val tipY: Float, val scale: Float, val flipX: Boolean, val visible: Boolean,
    val mirrorH: Boolean, val mirrorV: Boolean, val charScale: Float,
    val role: BoneRole = BoneRole.NORMAL, val homeRest: Float = 0f, val freed: Boolean = false,
    val appearFrom: Int = 0, val appearTo: Int = -1, val charAlpha: Float = 1f,
)

/** ตัวละครที่คัดลอก: ชิ้นส่วนทั้งหมด + ท่าทางของแต่ละเฟรม (id เดิม -> ท่า) */
class CharacterClip(val name: String, val parts: List<ClipPart>, val frames: List<Map<Int, Pose>>) {
    var pasteCount = 0 // วางครั้งที่เท่าไหร่ ใช้เลื่อนตำแหน่งไม่ให้ซ้อนกัน
}

enum class Mode { RIG, ANIMATE }
enum class Tool { MOVE, JOINT, ROTATE, CHAR_ROTATE, CHAR_SCALE } // CHAR_* = หมุน/ขยายทั้งตัวละคร
private enum class DragTarget { EDIT, PAN, TIP, MAIN, CHAR }

const val HAND_RING_PX = 22f // รัศมีวงเขียวรอบจุดปลายกระดูกมือที่เลือก (พิกเซลหน้าจอ): จุดโคนของสิ่งของเข้ามาในวง = ติด
private enum class PathTouch { NONE, HANDLE, DOT, STROKE, LINE, TAP, PAN } // นิ้วที่แตะอยู่ในโหมดเส้นทางกำลังทำอะไร

/** วิธีวาดเส้นทาง: FREE = ลากนิ้วเป็นเส้นเดียว (แอปทำให้เรียบ), POINTS = แตะวางจุดทีละจุด, LINE = กดจุดหนึ่งแล้วลากไปอีกจุดเป็นเส้นตรง */
enum class PathDrawMode { FREE, POINTS, LINE }

/** เส้นที่รอให้ผู้ใช้ยืนยันก่อนใช้: overwrite = ช่วงนั้นมีการย้ายตำแหน่งไว้แล้ว, framesShort = ช่วงเฟรมสั้นเกินไป */
class PathPrompt(val path: MotionPath, val overwrite: Boolean, val framesShort: Boolean)

private const val MAX_UNDO = 50 // เก็บย้อนหลังสูงสุดกี่ก้าว

/** สถานะของชิ้นส่วนหนึ่งชิ้นตอนถ่ายภาพ (part = ตัวชิ้นส่วนเดิม ใช้ตัวเดิมกลับมาตอนย้อน) */
private data class PartState(
    val part: Part, val name: String, val parentId: Int?, val x: Float, val y: Float,
    val pivotX: Float, val pivotY: Float, val restRotation: Float, val boneLength: Float,
    val hasTip: Boolean, val tipX: Float, val tipY: Float, val scale: Float, val flipX: Boolean,
    val visible: Boolean, val characterId: Int, val characterName: String,
    val mirrorH: Boolean, val mirrorV: Boolean, val charScale: Float,
    val appearFrom: Int, val appearTo: Int, val charAlpha: Float,
)

/** ภาพถ่ายสถานะงาน: ชิ้นส่วน (ตามลำดับวาด) + ท่าทุกเฟรม + ช่วงความเร็ว */
private data class EditState(
    val parts: List<PartState>, val frames: List<Map<Int, Pose>>, val speed: List<SpeedRange>,
    val paths: List<MotionPath>,
)

class EditorViewModel : ViewModel() {
    val project = Project()
    val skeleton = Skeleton() // ระบบกระดูกใหม่ (รอบที่ 1: สร้าง/เลือก/ลบกระดูก ยังไม่เชื่อมกับภาพ)
    var boneEditorOpen by mutableStateOf(false)
    var restoring by mutableStateOf(true) // true จนกว่าจะอ่านงานที่เซฟอัตโนมัติไว้เสร็จ (ห้ามเขียนทับ autosave ก่อนหน้านั้น)

    var mode by mutableStateOf(Mode.ANIMATE) // แอปเหลือแต่โหมดแอนิเมต
    var tool by mutableStateOf(Tool.MOVE)
    var selectedId by mutableStateOf<Int?>(null)
    var currentFrame by mutableIntStateOf(0)
    var playhead by mutableFloatStateOf(0f)
    var playing by mutableStateOf(false)
    var loop by mutableStateOf(true)
    var fps by mutableFloatStateOf(12f)
    var videoHeight by mutableIntStateOf(720) // ขนาดวิดีโอ (px) ตั้งในเมนูตั้งค่า: กรอบเส้นประสีฟ้าและค่าเริ่มต้นตอนส่งออกวิดีโอใช้ค่านี้
    var videoWidth by mutableIntStateOf(720)
    var zoom by mutableFloatStateOf(1f)
    var pan by mutableStateOf(Offset.Zero)
    var canvasSize by mutableStateOf(IntSize.Zero)
    var message by mutableStateOf<String?>(null)
    var selectedCharacterId by mutableStateOf<Int?>(null) // ตัวละครที่เลือกในแถบด้านซ้าย: เมนูพลิก/หมุน/ขยาย/ลบ/คัดลอกใช้กับตัวนี้
    var characterClipboard by mutableStateOf<CharacterClip?>(null) // ตัวละครที่คัดลอกไว้ (รวมท่าทางทุกเฟรม) รอกดวาง
    /** ขนาดของตัวละครที่กำลังใช้งาน (1 = 100% ตอนโหลด) */
    val charScale: Float get() {
        val cid = activeCharacterId() ?: return 1f
        return project.parts.firstOrNull { it.characterId == cid }?.charScale ?: 1f
    }
    /** ความจางของตัวละครที่กำลังใช้งาน (1 = ทึบปกติ) */
    val charAlpha: Float get() {
        val cid = activeCharacterId() ?: return 1f
        return project.parts.firstOrNull { it.characterId == cid }?.charAlpha ?: 1f
    }
    private var alphaBefore: EditState? = null // สถานะตอนเริ่มเลื่อนแถบความจาง: เลื่อน 1 ครั้ง = 1 ก้าวย้อนกลับ

    /** เริ่มเลื่อนแถบความจาง (เรียกก่อน setCharacterAlpha ทุกครั้ง ซ้ำได้ นับแค่ครั้งแรก) */
    fun beginAlphaEdit() {
        if (alphaBefore == null) alphaBefore = capture()
    }

    fun setCharacterAlpha(a: Float) {
        val cid = activeCharacterId() ?: return
        val v = a.coerceIn(0.1f, 1f)
        for (p in project.parts) if (p.characterId == cid) p.charAlpha = v
    }

    fun endAlphaEdit() {
        alphaBefore?.let { commit(it) }
        alphaBefore = null
    }

    var mainDragging by mutableStateOf(false) // กำลังลากจุดหลัก (ย้ายทั้งตัว)
    var hoverHandId by mutableStateOf<Int?>(null) // ตอนลากสิ่งของ: มือที่อยู่ใกล้พอจะดูดติด (ไว้ไฮไลต์)

    /** กำลังลากจุดโคนของสิ่งของที่ยังไม่ติดมือ (ไว้แสดงวงเป้าหมายที่ปลายมือ) */
    val draggingItemMain: Boolean
        get() = mainDragging && project.part(dragRootId)?.let { it.role == BoneRole.ITEM && it.parentId == null } == true
    var onionOpacity by mutableFloatStateOf(0.3f) // ความเข้มของเงาเฟรมก่อนหน้า (0 = ปิด)

    private var viewInitialized = false
    private var lastAngle = 0f
    private var dragTarget = DragTarget.PAN
    private var dragRootId: Int? = null

    val selected: Part? get() = project.part(selectedId)

    // ---------- ย้อนกลับ / ทำซ้ำ (Undo / Redo) ----------
    // เก็บ "ภาพถ่ายสถานะ" ก่อนแก้ทุกครั้ง (ภาพ bitmap ใช้ร่วมกัน ไม่ถูกคัดลอก จึงไม่กินหน่วยความจำเพิ่ม)
    private val undoStack = ArrayDeque<EditState>()
    private val redoStack = ArrayDeque<EditState>()
    var undoSize by mutableIntStateOf(0) // ไว้ให้ปุ่มบนจอรู้ว่าย้อนได้ไหม
        private set
    var redoSize by mutableIntStateOf(0)
        private set
    val canUndo: Boolean get() = undoSize > 0
    val canRedo: Boolean get() = redoSize > 0
    private var dragBefore: EditState? = null // สถานะตอนเริ่มลาก: ลาก 1 ครั้ง = 1 ก้าว
    private var recDepth = 0 // กันนับซ้ำเมื่อคำสั่งหนึ่งเรียกอีกคำสั่งหนึ่ง

    private fun capture(): EditState = EditState(
        project.parts.map {
            PartState(
                it, it.name, it.parentId, it.x, it.y, it.pivotX, it.pivotY, it.restRotation, it.boneLength,
                it.hasTip, it.tipX, it.tipY, it.scale, it.flipX, it.visible, it.characterId, it.characterName,
                it.mirrorH, it.mirrorV, it.charScale, it.appearFrom, it.appearTo, it.charAlpha,
            )
        },
        project.snapshotFrames(),
        project.speedRanges.toList(),
        project.paths.toList(),
    )

    private fun commit(before: EditState) {
        if (capture() == before) return // ไม่มีอะไรเปลี่ยน (เช่น แค่แตะ) ไม่นับเป็นก้าว
        undoStack.addLast(before)
        while (undoStack.size > MAX_UNDO) undoStack.removeFirst()
        redoStack.clear()
        syncHistory()
    }

    /** ครอบการแก้งาน: จบแล้วถ้าสถานะเปลี่ยนจึงบันทึกเป็น 1 ก้าวให้ย้อนได้ (ซ้อนกันได้ นับเฉพาะชั้นนอกสุด) */
    private inline fun <T> recorded(block: () -> T): T {
        val before = if (recDepth == 0) capture() else null
        recDepth++
        try {
            return block()
        } finally {
            recDepth--
            if (before != null) commit(before)
        }
    }

    private fun syncHistory() {
        undoSize = undoStack.size
        redoSize = redoStack.size
    }

    /** ล้างประวัติ (ใช้ตอนเปิดงานใหม่/โหลดงาน เพราะสถานะเก่าใช้ไม่ได้แล้ว) */
    fun clearHistory() {
        undoStack.clear()
        redoStack.clear()
        dragBefore = null
        syncHistory()
    }

    fun undo() {
        val target = undoStack.removeLastOrNull() ?: return
        redoStack.addLast(capture())
        dragBefore = null
        restoreState(target)
        syncHistory()
    }

    fun redo() {
        val target = redoStack.removeLastOrNull() ?: return
        undoStack.addLast(capture())
        dragBefore = null
        restoreState(target)
        syncHistory()
    }

    private fun restoreState(s: EditState) {
        playing = false
        for (ps in s.parts) {
            val p = ps.part
            p.name = ps.name
            p.parentId = ps.parentId
            p.x = ps.x
            p.y = ps.y
            p.pivotX = ps.pivotX
            p.pivotY = ps.pivotY
            p.restRotation = ps.restRotation
            p.boneLength = ps.boneLength
            p.hasTip = ps.hasTip
            p.tipX = ps.tipX
            p.tipY = ps.tipY
            p.scale = ps.scale
            p.flipX = ps.flipX
            p.visible = ps.visible
            p.characterId = ps.characterId
            p.characterName = ps.characterName
            p.mirrorH = ps.mirrorH
            p.mirrorV = ps.mirrorV
            p.charScale = ps.charScale
            p.appearFrom = ps.appearFrom
            p.appearTo = ps.appearTo
            p.charAlpha = ps.charAlpha
        }
        project.parts.clear()
        project.parts.addAll(s.parts.map { it.part })
        project.frames.clear()
        for (f in s.frames) project.frames.add(mutableStateMapOf<Int, Pose>().also { it.putAll(f) })
        project.speedRanges.clear()
        project.speedRanges.addAll(s.speed)
        project.paths.clear()
        project.paths.addAll(s.paths)
        pathSel = null // เลขจุดดัดโค้งที่เลือกไว้ใช้ไม่ได้แล้วหลังย้อนกลับ/ทำซ้ำ
        currentFrame = currentFrame.coerceIn(0, project.frameCount - 1)
        playhead = currentFrame.toFloat()
        if (selectedId != null && project.part(selectedId) == null) selectedId = null
        val cid = selectedCharacterId
        if (cid != null && project.parts.none { it.characterId == cid }) closeCharacterMenu()
        if (pathMode && selectedCharacterId == null) closePathMode() // ตัวละครของเส้นทางที่กำลังแก้หายไป (เช่น ย้อนกลับ)
    }

    /** ตั้งช่วงความเร็วเฟรม (ย้อนกลับได้) */
    fun addSpeedRange(fromN: Int, toN: Int, fps: Float) {
        recorded { project.addSpeedRange(fromN, toN, fps) }
    }

    /** รีเซ็ตช่วงความเร็วเฟรมกลับเป็นความเร็วปกติ (ย้อนกลับได้) */
    fun removeSpeedRange(r: SpeedRange) {
        recorded { project.speedRanges.remove(r) }
    }

    private val center: Offset get() = Offset(canvasSize.width / 2f, canvasSize.height / 2f)

    // ---------- มุมมอง (view) ----------
    fun onCanvasSize(size: IntSize) {
        canvasSize = size
        if (!viewInitialized && size.width > 0 && size.height > 0) {
            zoom = min(size.width, size.height) * 0.92f / Exporter.WORLD_WINDOW
            pan = Offset.Zero
            viewInitialized = true
        }
    }

    /** ใช้ตอนกู้งานที่เซฟไว้: ตั้งมุมมองเดิม และกัน onCanvasSize ไม่ให้รีเซ็ตซูม/เลื่อนทับ */
    fun restoreView(z: Float, p: Offset) {
        zoom = z
        pan = p
        viewInitialized = true
    }

    fun toWorld(p: Offset): Offset = (p - center - pan) / zoom
    fun toScreen(w: Offset): Offset = center + pan + w * zoom

    fun onTransform(centroid: Offset, panChange: Offset, zoomChange: Float) {
        if (pathMode) { // นิ้วที่ 2 มา = ซูม/เลื่อนจอ: ทิ้งเส้นที่กำลังลากค้างไว้
            if (pathTouch == PathTouch.STROKE || pathTouch == PathTouch.LINE) pathDraft.clear()
            pathTouch = PathTouch.NONE
            pathDot = null
        }
        if (tool == Tool.CHAR_SCALE) { // ใช้ 2 นิ้วถ่าง/หุบ = ขยาย/ย่อตัวละคร
            scaleCharacter(zoomChange)
            pan += panChange
            return
        }
        val newZoom = (zoom * zoomChange).coerceIn(0.1f, 20f)
        val w = (centroid - center - pan) / zoom
        pan = centroid - center - w * newZoom + panChange
        zoom = newZoom
    }

    // ---------- ท่า (pose) ปัจจุบัน ----------
    fun poseOf(): (Int) -> Pose = when {
        mode == Mode.RIG -> { _ -> Pose() }
        playing -> {
            val follow = PathFollow(project.paths.toList(), project.parts.toList(), project.frameCount) // ตำแหน่งระหว่างเฟรมเดินตามเส้นโค้งจริง ไม่ใช่เส้นตรงระหว่างจุดเฟรม
            ({ id: Int ->
                val ln = if (loop) project.loopCount() else project.frameCount
                follow.adjust(id, project.interpolated(playhead, id, ln), playhead, ln)
            })
        }
        else -> { id -> project.poseAt(currentFrame, id) }
    }

    private fun updatePose(id: Int, f: (Pose) -> Pose) {
        val map = project.frames[currentFrame]
        map[id] = f(map[id] ?: Pose())
    }

    // ---------- การสัมผัส ----------
    fun onDown(pos: Offset) {
        dragBefore = capture() // ภาพถ่ายก่อนเริ่มแก้ (ถ้านิ้วปล่อยแล้วไม่มีอะไรเปลี่ยนจะไม่นับเป็นก้าว)
        hoverHandId = null
        if (pathMode) {
            pathDown(pos)
            return
        }
        val w = toWorld(pos)
        mainDragging = false
        val main = nearestMain(pos) // จุดหลัก = ข้อต่อรากของตัวละคร: ลากเพื่อย้ายทั้งตัว
        if (tool == Tool.CHAR_ROTATE || tool == Tool.CHAR_SCALE) {
            if (main != null) {
                startMain(main.first)
            } else if (tool == Tool.CHAR_ROTATE) {
                dragTarget = DragTarget.CHAR // ลากนิ้วรอบจุดหลัก = หมุนทั้งตัวละคร
                lastAngle = angleToMain(w)
            } else {
                dragTarget = DragTarget.PAN // ขยายตัวละครใช้ 2 นิ้ว ส่วน 1 นิ้วเลื่อนมุมมอง
            }
            return
        }
        val cur = selected
        if (cur != null && nearTip(cur, pos)) { // แตะที่จุดต่อของภาพที่เลือกอยู่
            dragTarget = DragTarget.TIP
            lastAngle = angleTo(cur, w)
            return
        }
        val tip = nearestTip(pos)
        if (main != null && (tip == null || main.second <= tip.second)) {
            startMain(main.first) // แตะจุดหลัก: ไม่เปลี่ยนกระดูกที่เลือก แค่ลากย้ายทั้งตัว
            return
        }
        if (tip != null) { // แตะปลายกระดูก: เลือกกระดูกนั้น แล้วลาก = หมุนรอบจุดโคน
            pick(tip.first)
            dragTarget = DragTarget.TIP
            lastAngle = angleTo(tip.first, w)
            return
        }
        val hit = hitTest(project.parts, poseOf(), w.x, w.y, if (playing) playhead else currentFrame.toFloat())
        if (hit != null) {
            pick(hit)
            dragTarget = DragTarget.EDIT
        } else if (tool == Tool.ROTATE && mode == Mode.ANIMATE && selected != null) {
            dragTarget = DragTarget.EDIT
        } else {
            dragTarget = DragTarget.PAN
        }
        selected?.let { lastAngle = angleTo(it, w) }
    }

    private fun rootParts(): List<Part> = project.parts.filter { it.parentId == null && it.role != BoneRole.ITEM }

    /**
     * ชิ้นที่เส้นทางพาเคลื่อนที่: ชิ้นรากปกติของตัวละคร (สิ่งของที่ถอดแล้วอยู่ที่เดิม ไม่เดินตามเส้น)
     * ตัวละครที่มีแต่สิ่งของ (ไม่มีชิ้นรากปกติเลย) ใช้สิ่งของที่ไม่ได้ติดมือเป็นตัวเคลื่อนที่แทน ไม่งั้นวาดเส้นแล้วไม่มีอะไรเกิดขึ้น
     */
    private fun pathRoots(cid: Int): List<Part> =
        rootParts().filter { it.characterId == cid }.ifEmpty { project.parts.filter { it.characterId == cid && it.isDetachedItem } }

    /** สิ่งของที่ไม่ได้ถือมืออยู่ในเฟรมปัจจุบัน (ยังไม่ติด หรือถอดแล้ว): อยู่ในโลก ลากย้ายเฉพาะชิ้นนั้นได้ */
    private fun freeItems(): List<Part> = project.parts.filter { it.role == BoneRole.ITEM && project.poseAt(currentFrame, it.id).hold <= 0 }

    /** สิ่งของชิ้นนี้ถูกถืออยู่ในเฟรมปัจจุบันไหม */
    fun isHeld(item: Part): Boolean = item.role == BoneRole.ITEM && project.poseAt(currentFrame, item.id).hold > 0

    private fun startMain(root: Part) {
        dragRootId = root.id
        dragTarget = DragTarget.MAIN
        mainDragging = true
        if (root.role == BoneRole.ITEM && root.parentId == null && selected?.role != BoneRole.HAND) {
            message = "แตะปลายกระดูกมือที่จะติดก่อน (จะมีวงเขียว) แล้วลากสิ่งของมาวางในวง"
        }
    }

    /** จุดหลัก = ข้อต่อของชิ้นราก (เช่น จุดล่างสุดของลำตัว) คืนชิ้นรากที่ใกล้นิ้วที่สุดพร้อมระยะ */
    private fun nearestMain(pos: Offset): Pair<Part, Float>? {
        var best: Part? = null
        var bestD = 64f
        for (r in rootParts() + freeItems()) {
            if (!r.shownAt(currentFrame.toFloat())) continue // ตัวละครที่ไม่แสดงในเฟรมนี้ แตะไม่ติด
            val d = (toScreen(jointWorld(r, poseOf())) - pos).getDistance()
            if (d < bestD) { bestD = d; best = r }
        }
        return best?.let { it to bestD }
    }

    /**
     * แบบเดียวกับตอนดูตัวอย่าง: แตะ/ลากที่ "ปลายกระดูก" = เลือกกระดูกเส้นนั้น แล้วลากเพื่อหมุนรอบจุดโคน (ลูกๆ ตามไป)
     * ปลายกระดูก = จุดที่ห่างจากข้อต่อไปตามความยาวกระดูก (ตรงกับข้อต่อของกระดูกลูก หรือปลายมือสำหรับกระดูกสุดท้าย)
     */
    private fun nearestTip(pos: Offset): Pair<Part, Float>? {
        val joints = computeJointMatrices(project.parts, poseOf())
        var best: Part? = null
        var bestD = 64f // ระยะแตะ (พิกเซลหน้าจอ)
        for (p in project.parts) {
            if (p.boneLength <= 0f) continue
            if (!p.shownAt(currentFrame.toFloat())) continue // ตัวละครที่ไม่แสดงในเฟรมนี้ แตะไม่ติด
            val j = joints[p.id] ?: continue
            val tp = floatArrayOf(p.boneLength, 0f)
            j.mapPoints(tp)
            val d = (toScreen(Offset(tp[0], tp[1])) - pos).getDistance()
            if (d < bestD) { bestD = d; best = p }
        }
        return best?.let { it to bestD }
    }

    /** เลือกชิ้นส่วน (ถ้าเมนูตัวละครเปิดอยู่ จะย้ายไปเมนูของตัวละครที่ชิ้นนั้นอยู่ด้วย) */
    private fun pick(p: Part) {
        selectedId = p.id
        if (selectedCharacterId != null && p.characterId != 0) selectedCharacterId = p.characterId
    }

    /** ตัวละครที่เครื่องมือหมุน/ขยาย/พลิก/คัดลอกใช้กับ: ตัวที่เลือกในแถบด้านซ้าย ไม่งั้นตัวของชิ้นที่เลือก ไม่งั้นตัวแรก */
    fun activeCharacterId(): Int? {
        val sel = selectedCharacterId
        if (sel != null && project.parts.any { it.characterId == sel }) return sel
        selected?.let { return it.characterId }
        return project.parts.firstOrNull()?.characterId
    }

    private fun activeRoots(): List<Part> {
        val cid = activeCharacterId() ?: return emptyList()
        return rootParts().filter { it.characterId == cid }
    }

    /** +1 = ชิ้นนี้อยู่ในกรอบปกติ, -1 = อยู่ในกรอบที่ถูกพลิกแบบกระจก (การหมุนจะกลับทิศ ต้องกลับเครื่องหมายมุมที่ลาก) */
    private fun handedness(part: Part): Float {
        val m = computeJointMatrices(project.parts) { Pose() }[part.id] ?: return 1f
        val v = FloatArray(9)
        m.getValues(v)
        val det = v[Matrix.MSCALE_X] * v[Matrix.MSCALE_Y] - v[Matrix.MSKEW_X] * v[Matrix.MSKEW_Y]
        return if (det < 0f) -1f else 1f
    }

    private fun angleToMain(w: Offset): Float {
        val first = activeRoots().firstOrNull() ?: return 0f
        val j = jointWorld(first, poseOf())
        return Math.toDegrees(atan2((w.y - j.y).toDouble(), (w.x - j.x).toDouble())).toFloat()
    }

    /** หมุนตัวละครที่เลือกรอบจุดหลัก (หมุนชิ้นรากในเฟรมปัจจุบัน ลูกๆ ตามไปเอง) */
    private fun rotateCharacter(w: Offset) {
        val roots = activeRoots()
        val first = roots.firstOrNull() ?: return
        val a = angleToMain(w)
        var d = a - lastAngle
        while (d > 180f) d -= 360f
        while (d < -180f) d += 360f
        lastAngle = a
        d *= handedness(first)
        for (r in roots) updatePose(r.id) { it.copy(rotation = it.rotation + d) }
    }

    /** มุมที่หมุนตัวละครที่เลือกในเฟรมปัจจุบัน (องศา) ไว้แสดงเป็นตัวเลข */
    fun characterAngle(): Float {
        val first = activeRoots().firstOrNull() ?: return 0f
        var r = (poseOf()(first.id).rotation * handedness(first)) % 360f
        if (r > 180f) r -= 360f
        if (r <= -180f) r += 360f
        return r
    }

    /** ขยาย/ย่อตัวละครที่เลือกรอบจุดหลัก (ภาพ ความยาวกระดูก และตำแหน่งข้อต่อของลูกทุกชิ้นคูณเท่ากัน) ตัวอื่นไม่เปลี่ยน */
    fun scaleCharacter(factor: Float) {
        val cid = activeCharacterId() ?: return
        val ps = project.parts.filter { it.characterId == cid }
        if (ps.isEmpty()) return
        val current = ps.first().charScale
        val target = (current * factor).coerceIn(0.1f, 10f)
        val k = target / current
        if (k == 1f) return
        for (p in ps) {
            p.scale *= k
            p.boneLength *= k
            if (p.parentId != null) {
                p.x *= k
                p.y *= k
            }
            p.charScale = target
        }
    }

    /**
     * ลากจุดหลัก = ย้ายทั้งตัวละคร: ชิ้นรากทุกชิ้น (parent = ไม่มี) ขยับด้วยกัน
     * ตัวละครที่เซฟจากหน้าแก้ไขกระดูกอาจมีกระดูกที่ออกจากจุดราก (0,0) หลายเส้น (เช่น ขาซ้าย/ขวา/ลำตัว)
     * ซึ่งทุกเส้นเริ่มที่จุดเดียวกัน ถ้าขยับแค่ชิ้นเดียวจุดเริ่มต้นจะแยกออกจากกัน
     */
    private fun moveMain(delta: Offset) {
        val dragRoot = project.part(dragRootId) ?: return
        val v = delta / zoom
        // ย้ายเฉพาะตัวละครที่ลาก (ชิ้นรากทั้งหมดของตัวละครเดียวกัน) ตัวละครอื่นในฉากอยู่กับที่
        // สิ่งของที่ถอดออกจากมือแล้วเป็นอิสระ: ลากจุดของมัน = ย้ายเฉพาะของชิ้นนั้น ส่วนลากตัวละครไม่พาของที่ถอดแล้วไปด้วย
        val moving = if (dragRoot.isDetachedItem) listOf(dragRoot)
        else rootParts().filter { it.characterId == dragRoot.characterId && !it.isDetachedItem }
        for (root in moving) {
            if (mode == Mode.RIG) {
                root.x += v.x
                root.y += v.y
            } else {
                updatePose(root.id) { it.copy(dx = it.dx + v.x, dy = it.dy + v.y) }
            }
        }
        updateHover(dragRoot)
    }

    /**
     * ลากสิ่งของ (ชิ้นรากที่ตั้งเป็น "สิ่งของ") ให้จุดโคนเข้าไปในวงเขียวรอบ "จุดปลาย" ของกระดูกมือที่เลือกอยู่ = ไฮไลต์วง
     * ปล่อยนิ้วแล้วติดทันที วงเป็นวงกลมรัศมี HAND_RING_PX พิกเซลหน้าจอ ไม่เกี่ยวกับจุดหลัก (ข้อต่อราก)
     */
    private fun updateHover(root: Part) {
        hoverHandId = null
        if (mode != Mode.ANIMATE || root.role != BoneRole.ITEM || root.parentId != null) return
        val hand = selected?.takeIf { it.role == BoneRole.HAND && it.boneLength > 0f && canAttachItem(root, it) } ?: return
        val joints = computeJointMatrices(project.parts, poseOf())
        val rj = joints[root.id] ?: return
        val hj = joints[hand.id] ?: return
        val rp = floatArrayOf(0f, 0f)
        rj.mapPoints(rp)
        val tp = floatArrayOf(hand.boneLength, 0f)
        hj.mapPoints(tp)
        val item = toScreen(Offset(rp[0], rp[1]))
        val tip = toScreen(Offset(tp[0], tp[1]))
        if ((item - tip).getDistance() <= HAND_RING_PX) hoverHandId = hand.id
    }

    fun onUp() {
        val hid = hoverHandId
        hoverHandId = null
        val dragged = if (mainDragging) project.part(dragRootId) else null
        mainDragging = false
        if (hid != null && dragged != null && !pathMode && !playing) { // ปล่อยนิ้วใกล้ปลายมือ = ติด (รวมกับการลากเป็นก้าวย้อนกลับเดียว)
            val hand = project.part(hid)
            if (hand != null && canAttachItem(dragged, hand)) attachItemCore(dragged, hand)
        }
        if (pathMode) pathUp() // แก้เส้นทางจบ 1 ครั้ง = 1 ก้าวย้อนกลับ (ผ่าน dragBefore ด้านล่าง)
        dragBefore?.let { commit(it) } // ลาก/หมุน/ย่อขยายจบ 1 ครั้ง = 1 ก้าว
        dragBefore = null
    }

    fun onDrag(pos: Offset, delta: Offset) {
        if (pathMode) {
            pathDrag(pos, delta)
            return
        }
        when (dragTarget) {
            DragTarget.PAN -> {
                pan += delta
                return
            }
            DragTarget.MAIN -> {
                if (!playing) moveMain(delta)
                return
            }
            DragTarget.CHAR -> {
                if (!playing) rotateCharacter(toWorld(pos))
                return
            }
            else -> {}
        }
        val part = selected ?: return
        if (playing) return
        val w = toWorld(pos)
        if (dragTarget == DragTarget.TIP) {
            rotateToward(part, w) // ลากปุ่มเขียว: หมุนเฉพาะภาพรอบปุ่มแดง ปุ่มทั้งสองอยู่กับที่
            return
        }
        val poseFn = poseOf()
        when (tool) {
            Tool.MOVE -> {
                val v = toParentVector(part, poseFn, delta / zoom)
                if (mode == Mode.RIG) {
                    part.x += v.x
                    part.y += v.y
                } else if (part.parentId != null || isHeld(part)) {
                    rotateToward(part, w) // ชิ้นที่มี parent (หรือสิ่งของที่ถืออยู่): ลากแล้วหมุนรอบข้อต่อ (ไม่หลุดจาก parent)
                } else {
                    updatePose(part.id) { it.copy(dx = it.dx + v.x, dy = it.dy + v.y) }
                }
            }
            Tool.JOINT -> if (mode == Mode.RIG) moveJoint(part, w)
            Tool.ROTATE -> if (mode == Mode.ANIMATE) rotateToward(part, w)
            Tool.CHAR_ROTATE, Tool.CHAR_SCALE -> {}
        }
    }

    fun addTip(part: Part) {
        val h = part.bitmap.height.toFloat()
        part.tipX = part.pivotX
        part.tipY = if (part.pivotY <= h / 2f) h else 0f // ค่าเริ่มต้น: ขอบด้านตรงข้ามข้อต่อ ลากปรับได้
        part.hasTip = true
    }

    fun removeTip(part: Part) {
        part.hasTip = false
    }

    private fun nearTip(part: Part, pos: Offset): Boolean {
        if (!part.hasTip) return false
        val j = jointWorld(part, poseOf())
        return (toScreen(Offset(j.x, j.y + tipLength(part))) - pos).getDistance() < 56f
    }

    private fun rotateToward(part: Part, w: Offset) {
        val a = angleTo(part, w)
        var d = a - lastAngle
        while (d > 180f) d -= 360f
        while (d < -180f) d += 360f
        lastAngle = a
        d *= handedness(part) // ตัวละครที่พลิกแบบกระจกอยู่ หมุนทิศตรงข้าม
        if (mode == Mode.RIG) {
            part.restRotation += d // โหมดโครง: หมุนภาพรอบข้อต่อเป็นมุมพื้นฐาน ชิ้นลูกตามไปด้วย
        } else {
            updatePose(part.id) { it.copy(rotation = it.rotation + d) }
        }
    }

    private fun jointWorld(part: Part, poseFn: (Int) -> Pose): Offset {
        val m = computeJointMatrices(project.parts, poseFn)[part.id] ?: return Offset.Zero
        val pt = floatArrayOf(0f, 0f)
        m.mapPoints(pt)
        return Offset(pt[0], pt[1])
    }

    private fun angleTo(part: Part, w: Offset): Float {
        val j = jointWorld(part, poseOf())
        return Math.toDegrees(atan2((w.y - j.y).toDouble(), (w.x - j.x).toDouble())).toFloat()
    }

    private fun toParentVector(part: Part, poseFn: (Int) -> Pose, v: Offset): Offset {
        val joints = computeJointMatrices(project.parts, poseFn)
        val pm = part.parentId?.let { joints[it] } ?: return v
        val inv = Matrix()
        if (!pm.invert(inv)) return v
        val arr = floatArrayOf(v.x, v.y)
        inv.mapVectors(arr)
        return Offset(arr[0], arr[1])
    }

    /** ย้ายข้อต่อของชิ้นส่วนไปยังจุดที่แตะ โดยภาพและลูกๆ ไม่ขยับ (เฉพาะโหมดโครง) */
    private fun moveJoint(part: Part, w: Offset) {
        val joints = computeJointMatrices(project.parts) { Pose() }
        val myJoint = joints[part.id] ?: return
        val dm = drawMatrix(part, myJoint)
        val inv = Matrix()
        if (!dm.invert(inv)) return
        val pt = floatArrayOf(w.x, w.y)
        inv.mapPoints(pt)
        val newPx = pt[0].coerceIn(0f, part.bitmap.width.toFloat())
        val newPy = pt[1].coerceIn(0f, part.bitmap.height.toFloat())

        val target = floatArrayOf(newPx, newPy)
        dm.mapPoints(target) // จุดใหม่บนภาพ -> พิกัดโลก (ใช้ matrix เดิม ภาพจึงไม่ขยับ)
        val pm = part.parentId?.let { joints[it] } ?: Matrix()
        val pinv = Matrix()
        if (!pm.invert(pinv)) return
        pinv.mapPoints(target)

        val dx = target[0] - part.x
        val dy = target[1] - part.y
        part.pivotX = newPx
        part.pivotY = newPy
        part.x = target[0]
        part.y = target[1]
        val rad = Math.toRadians(part.restRotation.toDouble())
        val cs = Math.cos(rad).toFloat()
        val sn = Math.sin(rad).toFloat()
        for (c in project.children(part.id)) { // ชดเชยให้ลูกอยู่ที่เดิมในโลก (แปลงเข้ากรอบที่หมุนแล้วของชิ้นนี้)
            c.x -= dx * cs + dy * sn
            c.y -= -dx * sn + dy * cs
        }
    }

    // ---------- คำสั่ง ----------
    @JvmName("applyMode")
    fun setMode(m: Mode) {
        mode = m
        playing = false
        tool = when (m) {
            Mode.RIG -> if (tool == Tool.ROTATE) Tool.MOVE else tool
            Mode.ANIMATE -> if (tool == Tool.JOINT) Tool.ROTATE else tool
        }
    }

    fun addImported(name: String, bmp: Bitmap) = recorded {
        val part = project.addPart(name, bmp)
        val maxSide = max(bmp.width, bmp.height).toFloat()
        part.scale = if (maxSide > 300f) 300f / maxSide else 1f // คงสัดส่วนเดิม (ย่อแบบ uniform)
        val c = toWorld(center)
        part.x = c.x
        part.y = c.y
        selectedId = part.id
    }

    /** โหลดตัวละครที่แปลงจากกระดูกแล้ว เพิ่มเข้าฉากแอนิเมต (มีได้หลายตัว) */
    fun loadCharacter(built: List<BuiltPart>, name: String, appearFrom: Int = 0, appearTo: Int = -1) = recorded {
        val cid = project.newCharacterId() // เพิ่มเข้าฉาก ไม่ล้างตัวเดิม
        val partIdOf = HashMap<Int, Int>() // id กระดูก -> id ชิ้นส่วน
        for (bp in built) { // ใส่พ่อ-ลูกรอบสอง เพราะลำดับชั้นอาจให้ลูกอยู่ก่อนพ่อในลิสต์
            val part = project.addPart(bp.name, bp.bitmap, null)
            part.pivotX = bp.pivotX
            part.pivotY = bp.pivotY
            part.scale = bp.scale
            part.x = bp.x
            part.y = bp.y
            part.restRotation = bp.restRotation
            part.boneLength = bp.boneLength
            part.role = bp.role
            part.homeRest = bp.homeRest
            part.characterId = cid
            part.characterName = name
            part.appearFrom = appearFrom // แสดงเฉพาะช่วงเฟรมที่เลือกตอนเพิ่ม (appearTo = -1 = ไปจนจบ)
            part.appearTo = appearTo
            partIdOf[bp.boneId] = part.id
        }
        for (bp in built) {
            if (bp.role == BoneRole.ITEM) continue // สิ่งของไม่ติดมือตั้งแต่โหลด: ติดได้ในหน้าแอนิเมตเท่านั้น (สถานะถือรายเฟรมอยู่ใน Pose)
            val parentPartId = bp.parentBoneId?.let { partIdOf[it] } ?: continue
            project.part(partIdOf[bp.boneId])?.parentId = parentPartId
        }
        selectedId = partIdOf.values.firstOrNull()
    }

    fun deleteCharacter(characterId: Int) = recorded {
        val ids = project.parts.filter { it.characterId == characterId }.map { it.id }.toSet()
        // สิ่งของของตัวละครอื่นที่ติดมือตัวละครนี้อยู่: ถอดออกมาอยู่ที่เดิมก่อน ไม่ให้ค้างอ้างถึงมือที่ถูกลบ
        for (q in project.parts.filter { it.characterId != characterId && it.role == BoneRole.ITEM }) {
            for (f in 0 until project.frameCount) {
                if (project.poseAt(f, q.id).hold in ids) project.frames[f][q.id] = worldFreePose(q, f) // ค้างอยู่ที่ตำแหน่งในเฟรมนั้น ไม่ให้ชี้มือที่ถูกลบ
            }
        }
        if (selected?.characterId == characterId) selectedId = null
        if (selectedCharacterId == characterId) closeCharacterMenu()
        project.removeCharacter(characterId)
    }

    // ---------- ถือของ: ถอด / ติดสิ่งของกับมือ (ทั้งอนิเมชัน) ----------
    /** สิ่งของทั้งหมดของตัวละคร (ที่ตั้งเป็น "สิ่งของ" ในหน้าจัดกระดูก) */
    fun itemsOf(cid: Int): List<Part> = project.parts.filter { it.characterId == cid && it.role == BoneRole.ITEM }

    /** มือทั้งหมดของตัวละคร (ที่ตั้งเป็น "มือ" ในหน้าจัดกระดูก) */
    fun handsOf(cid: Int): List<Part> = project.parts.filter { it.characterId == cid && it.role == BoneRole.HAND }

    /**
     * ท่าของสิ่งของที่ถอดอิสระ ณ เฟรม f: ตำแหน่ง/มุม/การพลิกจริงในโลกตอนที่ยังถืออยู่ในเฟรมนั้น (เก็บเป็นท่าในพิกัดโลก hold = HOLD_FREE)
     * ใช้ได้เมื่อของถูกถืออยู่ในเฟรม f เท่านั้น
     */
    private fun worldFreePose(item: Part, f: Int): Pose {
        var top: Part? = project.part(project.poseAt(f, item.id).hold) // ชิ้นรากของสายที่ของติดอยู่ (ใช้ดูการพลิกทั้งตัวละคร)
        var guard = 0
        while (guard++ < 64) {
            val up = project.part(top?.parentId) ?: break
            top = up
        }
        val m = computeJointMatrices(project.parts) { id -> project.poseAt(f, id) }[item.id] ?: Matrix()
        val v = FloatArray(9)
        m.getValues(v)
        val tp = top?.let { project.poseAt(f, it.id) } ?: Pose()
        val fh = (top?.mirrorH ?: false) != tp.flipH
        val fv = (top?.mirrorV ?: false) != tp.flipV
        val sx = if (fh) -1f else 1f
        val sy = if (fv) -1f else 1f
        val phi = Math.toDegrees(atan2((sy * v[Matrix.MSKEW_Y]).toDouble(), (sx * v[Matrix.MSCALE_X]).toDouble())).toFloat()
        return Pose(
            rotation = phi, dx = v[Matrix.MTRANS_X], dy = v[Matrix.MTRANS_Y],
            flipH = item.mirrorH != fh, flipV = item.mirrorV != fv, hold = HOLD_FREE,
        )
    }

    /**
     * ถอดสิ่งของออกจากมือ ตั้งแต่เฟรมปัจจุบันไปจนจบ: ของหลุดมือแล้วค้างอยู่ตรงตำแหน่งที่เห็นในเฟรมปัจจุบัน
     * เฟรมก่อนหน้าไม่ถูกแตะ (ยังถืออยู่ตามเดิม) ใช้ได้เมื่อของถูกถืออยู่ในเฟรมปัจจุบันเท่านั้น
     */
    fun detachItem(itemId: Int) {
        if (playing) return
        val item = project.part(itemId) ?: return
        if (!isHeld(item)) return
        recorded {
            val frozen = worldFreePose(item, currentFrame)
            for (f in currentFrame until project.frameCount) project.frames[f][item.id] = frozen
            message = "ถอด \"${item.name}\" ออกจากมือตั้งแต่เฟรม ${currentFrame + 1} เป็นต้นไป (เฟรมก่อนหน้ายังถืออยู่)"
        }
    }

    /** มือทั้งหมดในฉาก (ทุกตัวละคร) */
    fun allHands(): List<Part> = project.parts.filter { it.role == BoneRole.HAND }

    /** สิ่งของของตัวละครอื่นที่ติดมืออยู่กับตัวละคร cid (ไว้ให้ถอดได้จากเมนูของเจ้าของมือ) */
    fun heldFromOthers(cid: Int): List<Part> = project.parts.filter { q ->
        q.characterId != cid && q.role == BoneRole.ITEM &&
            project.poseAt(currentFrame, q.id).hold.let { h -> h > 0 && project.part(h)?.characterId == cid }
    }

    /** ชื่อมือสำหรับแสดงในรายการเลือก: "ตัวละคร › มือ" */
    fun handLabel(h: Part): String = if (h.characterName.isNotBlank()) "${h.characterName} › ${h.name}" else h.name

    /** สิ่งของที่ถอดอยู่ติดกับมือ hand ได้ไหม (มือกับของอยู่คนละตัวละครก็ได้ แต่มือต้องไม่ใช่ลูกหลานของของชิ้นนั้น กันติดวน) */
    fun canAttachItem(item: Part, hand: Part): Boolean =
        item.role == BoneRole.ITEM && hand.role == BoneRole.HAND && item.parentId == null &&
            item.id != hand.id && hand.id !in project.descendants(item.id)

    /** เอาสิ่งของไปติดที่ปลายมือ (ทั้งอนิเมชัน) ย้อนกลับได้ */
    fun attachItem(itemId: Int, handId: Int) {
        if (playing) return
        val item = project.part(itemId) ?: return
        val hand = project.part(handId) ?: return
        if (!canAttachItem(item, hand)) return
        recorded { attachItemCore(item, hand) }
    }

    /**
     * ตัวทำงานจริงของการติด (ไม่บันทึกก้าวย้อนกลับเอง ให้ผู้เรียกครอบ): ถือมือ hand ตั้งแต่เฟรมปัจจุบันไปจนจบ
     * เฟรมก่อนหน้าไม่ถูกแตะ (ของยังเป็นสิ่งของอิสระตามเดิม) ท่าของของในเฟรมที่ติดถูกตั้งใหม่ให้อยู่ที่ปลายมือ
     */
    private fun attachItemCore(item: Part, hand: Part) {
        val held = Pose(hold = hand.id)
        for (f in currentFrame until project.frameCount) project.frames[f][item.id] = held
        message = "ติด \"${item.name}\" กับ \"${handLabel(hand)}\" ตั้งแต่เฟรม ${currentFrame + 1} เป็นต้นไป"
    }

    // ---------- เมนูตัวละคร (แถบเลเยอร์ด้านซ้าย) ----------
    /** แตะตัวละครในแถบซ้าย: เปิดเมนูของตัวนั้น แตะซ้ำ = ปิดเมนู */
    fun toggleCharacterMenu(cid: Int) {
        if (selectedCharacterId == cid) closeCharacterMenu() else selectedCharacterId = cid
    }

    fun closeCharacterMenu() {
        selectedCharacterId = null
        if (tool == Tool.CHAR_ROTATE || tool == Tool.CHAR_SCALE) tool = Tool.MOVE
    }

    // ---------- เส้นทางเคลื่อนที่ (วาดเส้น แล้วแอปวางตัวละครตามเส้นให้ทุกเฟรม) ----------
    // เส้นยังแก้ได้ทีหลัง: ทุกครั้งที่เส้นหรือค่าตั้งเปลี่ยน แอปคำนวณตำแหน่งใหม่แล้วเขียน dx/dy ลง Pose ของชิ้นรากในช่วงเฟรมนั้น
    // (ท่าแขนขาไม่ถูกแตะ) เครื่องเล่น/ตัวส่งออก/เซฟเดิมจึงอ่าน Pose เหมือนเดิม
    var pathMode by mutableStateOf(false)
        private set
    var pathDrawMode by mutableStateOf(PathDrawMode.FREE)
    val pathDraft = mutableStateListOf<Offset>() // จุดที่กำลังวาด/วางอยู่ (พิกัดฉาก) ก่อนกลายเป็นเส้น
    var pathPrompt by mutableStateOf<PathPrompt?>(null)
        private set
    var pathHandle by mutableStateOf<Int?>(null) // จุดจับที่กำลังลากอยู่
        private set
    var pathGrab by mutableStateOf(false) // โหมดจับเฟรม: ลากจุดขาวเล็กๆ ของแต่ละเฟรมไปตามเส้นเท่านั้น
        private set
    var pathDot by mutableStateOf<Int?>(null) // จุดเฟรม (ลำดับในช่วง) ที่กำลังลากอยู่
        private set
    var pathSel by mutableStateOf<Int?>(null) // จุดดัดโค้งที่แตะเลือกไว้ (ไว้กดปุ่มลบจุด)
        private set
    private var pathTouch = PathTouch.NONE
    private var pathTapStart = Offset.Zero
    private var pathTapMoved = false

    /** เส้นทางของตัวละครที่เลือกอยู่ */
    fun activePath(): MotionPath? = project.pathOf(activeCharacterId())

    fun openPathMode() {
        if (activeCharacterId() == null) return
        playing = false
        tool = Tool.MOVE
        pathDraft.clear()
        pathPrompt = null
        pathHandle = null
        pathDot = null
        pathGrab = false
        pathSel = null
        pathTouch = PathTouch.NONE
        pathMode = true
    }

    fun closePathMode() {
        pathMode = false
        pathDraft.clear()
        pathPrompt = null
        pathHandle = null
        pathDot = null
        pathGrab = false
        pathSel = null
        pathTouch = PathTouch.NONE
    }

    /** เลือกวิธีวาด (ปิดโหมดจับเฟรมให้ เพราะสองโหมดนี้ใช้นิ้วลากเหมือนกัน) */
    fun selectPathDrawMode(m: PathDrawMode) {
        pathDrawMode = m
        pathGrab = false
        pathDraft.clear()
    }

    /** เปิด/ปิดโหมดจับเฟรม (ต้องมีเส้นก่อน) */
    fun togglePathGrab() {
        if (activePath() == null) return
        pathGrab = !pathGrab
        pathDraft.clear()
        pathSel = null
    }

    /** จุดดัดโค้งที่เลือกอยู่ (null = ไม่ได้เลือก หรือเส้นเปลี่ยนจนเลขจุดไม่มีแล้ว เช่น หลังย้อนกลับ) */
    fun selectedPathPoint(): Int? {
        val path = activePath() ?: return null
        return pathSel?.takeIf { it in path.points.indices }
    }

    /** ลบจุดดัดโค้งที่เลือก (ต้องเหลืออย่างน้อย 2 จุด) ย้อนกลับได้ */
    fun deleteSelectedPathPoint() {
        val i = selectedPathPoint() ?: return
        val path = activePath() ?: return
        if (path.points.size <= 2) {
            message = "ต้องเหลืออย่างน้อย 2 จุด"
            return
        }
        pathSel = null
        editPath { p -> p.copy(points = p.points.toMutableList().also { it.removeAt(i) }) }
    }

    private fun normDeg(a: Float): Float {
        var d = a
        while (d > 180f) d -= 360f
        while (d < -180f) d += 360f
        return d
    }

    /**
     * ฝังตำแหน่ง (และมุม ถ้าเปิด "หันตามทิศเดิน") ตามเส้นลงทุกเฟรมในช่วง คืนเส้นที่อัปเดตสถานะแล้ว
     * ตำแหน่ง = ย้ายจุดหลักของชิ้นรากแรกไปอยู่บนเส้นพอดี ชิ้นรากอื่นของตัวละครเดียวกันเลื่อนตามเท่ากัน
     */
    private fun bakePath(path: MotionPath): MotionPath {
        if (path.points.size < 2) return path
        val roots = pathRoots(path.characterId)
        val first = roots.firstOrNull() ?: return path
        val start = path.startFrame.coerceIn(0, project.frameCount - 1)
        val end = path.endFrame.coerceIn(start, project.frameCount - 1)
        val n = end - start + 1
        val samples = PathMath.sample(path, n)
        if (samples.size != n) return path
        val hand = handedness(first)
        val resetHeading = !path.followHeading && path.headingWritten
        var unwrapped = 0f
        var prevHeading = samples[0].heading
        for (k in 0 until n) {
            val i = start + k
            val s = samples[k]
            unwrapped += normDeg(s.heading - prevHeading) // ต่อมุมให้ต่อเนื่อง ไม่ให้กระโดด 360° ตอนข้ามเส้น ±180°
            prevHeading = s.heading
            if (first.isDetachedItem && project.poseAt(i, first.id).hold > 0) continue // ของที่ติดมืออยู่ในเฟรมนี้ ตามมือ ไม่ตามเส้น
            val j0 = jointWorld(first) { id ->
                val p = project.poseAt(i, id)
                if (id == first.id) p.copy(dx = 0f, dy = 0f) else p
            }
            val dx = s.pos.x - j0.x
            val dy = s.pos.y - j0.y
            val map = project.frames[i]
            for (r in roots) {
                var np = (map[r.id] ?: Pose()).copy(dx = dx, dy = dy)
                if (path.followHeading) np = np.copy(rotation = path.baseRotation + unwrapped * hand)
                else if (resetHeading) np = np.copy(rotation = path.baseRotation)
                map[r.id] = np
            }
        }
        val keepT = if (path.frameT.size == n) path.frameT else emptyList() // จำนวนเฟรมเปลี่ยน = กลับไปห่างเท่ากัน
        return path.copy(startFrame = start, endFrame = end, headingWritten = path.followHeading, frameT = keepT)
    }

    /** ใช้เส้นนี้ (แทนของเดิมของตัวละครเดียวกัน) แล้วฝังตำแหน่ง: ไม่บันทึกย้อนกลับเอง ผู้เรียกเป็นคนครอบ */
    private fun applyPath(path: MotionPath) {
        project.putPath(bakePath(path))
    }

    private fun editPath(f: (MotionPath) -> MotionPath) {
        val p = activePath() ?: return
        recorded { applyPath(f(p)) }
    }

    fun setPathRange(start: Int, end: Int) {
        val p = activePath() ?: return
        recorded {
            val s = start.coerceIn(0, project.frameCount - 1)
            var e = end.coerceAtLeast(s)
            if (e >= project.frameCount) { // กด + ที่เฟรมสุดท้าย = เพิ่มเฟรมให้ (ทีละ 1)
                project.addFrameFrom(project.frameCount - 1)
                e = project.frameCount - 1
            }
            applyPath(p.copy(startFrame = s, endFrame = e, frameT = emptyList()))
        }
    }

    /** จัดเฟรมให้ห่างเท่ากันบนเส้นอีกครั้ง (ล้างตำแหน่งเฟรมที่ลากไว้) */
    fun resetPathFrameSpacing() = editPath { it.copy(frameT = emptyList()) }
    fun togglePathHeading() = editPath { it.copy(followHeading = !it.followHeading) }
    fun togglePathClosed() = editPath { it.copy(closed = !it.closed, frameT = emptyList()) } // ปิดวง/เปิดวงเปลี่ยนวิธีนับตำแหน่งเฟรม จึงเริ่มห่างเท่ากันใหม่
    fun togglePathSmooth() = editPath { it.copy(smooth = !it.smooth) }

    /** ลบเส้นทาง: ตำแหน่งที่ฝังไว้ในเฟรมยังอยู่ตามเดิม (ย้อนกลับได้) */
    fun clearPath() {
        val cid = activeCharacterId() ?: return
        recorded { project.paths.removeAll { it.characterId == cid } }
        pathDraft.clear()
        pathGrab = false
        pathSel = null
    }

    fun confirmPathPrompt() {
        val pr = pathPrompt ?: return
        pathPrompt = null
        recorded {
            var path = pr.path
            if (pr.framesShort) { // เพิ่มเฟรมให้พอสำหรับเคลื่อนที่ (รวม 12 เฟรมนับจากเฟรมเริ่ม)
                val want = path.startFrame + 11
                while (project.frameCount <= want) project.addFrameFrom(project.frameCount - 1)
                path = path.copy(endFrame = want)
            }
            applyPath(path)
        }
    }

    fun cancelPathPrompt() {
        pathPrompt = null
    }

    /** จุดควบคุมชุดใหม่ (จากการวาดหรือแตะวางจุด): ถ้ามีเส้นอยู่แล้วเปลี่ยนเฉพาะรูปเส้น ค่าตั้งเดิมคงไว้ */
    private fun submitPoints(pts: List<Offset>, smooth: Boolean = true) {
        pathSel = null
        val cid = activeCharacterId() ?: return
        val existing = project.pathOf(cid)
        if (existing != null) {
            applyPath(existing.copy(points = pts))
            return
        }
        val roots = pathRoots(cid)
        val first = roots.firstOrNull() ?: return
        val start = currentFrame.coerceIn(0, project.frameCount - 1)
        val end = project.frameCount - 1
        val path = MotionPath(
            characterId = cid, points = pts, smooth = smooth, startFrame = start, endFrame = end,
            baseRotation = project.poseAt(start, first.id).rotation,
        )
        val overwrite = (start..end).any { i ->
            roots.any { r ->
                val p = project.poseAt(i, r.id)
                p.dx != 0f || p.dy != 0f
            }
        }
        val short = end - start + 1 < 2
        if (overwrite || short) pathPrompt = PathPrompt(path, overwrite, short) else applyPath(path)
    }

    private fun pathDown(pos: Offset) {
        pathTapStart = pos
        pathTapMoved = false
        pathHandle = null
        if (playing) {
            pathTouch = PathTouch.PAN
            return
        }
        val path = activePath()
        if (pathGrab && path != null) { // โหมดจับเฟรม: แตะใกล้จุดเฟรม = ลากจุดนั้นไปตามเส้น ที่ว่าง = เลื่อนจอ
            val n = path.endFrame - path.startFrame + 1
            val samples = PathMath.sample(path, n)
            var best = -1
            var bestD = 48f
            for (k in movableDots(path, n)) {
                if (k >= samples.size) continue
                val d = (toScreen(samples[k].pos) - pos).getDistance()
                if (d < bestD) { bestD = d; best = k }
            }
            if (best >= 0) {
                pathDot = best
                pathTouch = PathTouch.DOT
                currentFrame = (path.startFrame + best).coerceIn(0, project.frameCount - 1) // ไปที่เฟรมนั้น เห็นตัวละครขยับตามนิ้ว
            } else {
                pathTouch = PathTouch.PAN
            }
            return
        }
        if (path != null) { // แตะใกล้จุดจับ = ลากจุดนั้นเพื่อดัดโค้ง
            var best = -1
            var bestD = 48f
            path.points.forEachIndexed { i, p ->
                val d = (toScreen(p) - pos).getDistance()
                if (d < bestD) { bestD = d; best = i }
            }
            if (best >= 0) {
                pathHandle = best
                pathSel = best
                pathTouch = PathTouch.HANDLE
                return
            }
        }
        pathSel = null
        when (pathDrawMode) {
            PathDrawMode.FREE -> {
                pathDraft.clear()
                pathDraft.add(toWorld(pos))
                pathTouch = PathTouch.STROKE
            }
            PathDrawMode.LINE -> { // กดจุดแรก แล้วลากไปจุดที่สอง
                pathDraft.clear()
                pathDraft.add(toWorld(pos))
                pathTouch = PathTouch.LINE
            }
            PathDrawMode.POINTS -> pathTouch = PathTouch.TAP
        }
    }

    /** ลำดับเฟรมในช่วงที่จุดเฟรมลากได้: เส้นเปิด = ไม่รวมเฟรมแรก/สุดท้าย (อยู่ปลายเส้น), เส้นปิดวง = ไม่รวมเฟรมแรก */
    private fun movableDots(path: MotionPath, n: Int): IntRange =
        if (PathMath.isLoop(path)) 1 until n else 1 until (n - 1)

    private fun pathDrag(pos: Offset, delta: Offset) {
        when (pathTouch) {
            PathTouch.HANDLE -> {
                val i = pathHandle ?: return
                val path = activePath() ?: return
                if (i !in path.points.indices) return
                val pts = path.points.toMutableList()
                pts[i] = toWorld(pos)
                applyPath(path.copy(points = pts)) // ตำแหน่งในเฟรมขยับตามทันทีระหว่างลาก
            }
            PathTouch.DOT -> {
                val k = pathDot ?: return
                val path = activePath() ?: return
                val n = path.endFrame - path.startFrame + 1
                if (k !in movableDots(path, n)) return
                val ts = PathMath.framesT(path, n)
                val lo = ts[k - 1]
                val hi = if (k + 1 < n) ts[k + 1] else 1f // ลากไปได้ไม่เกินเฟรมข้างเคียง (ลำดับเฟรมไม่สลับกัน)
                val u = PathMath.projectInRange(PathMath.dense(path.points, path.smooth, path.closed), toWorld(pos), lo, hi)
                val nt = ts.toMutableList()
                nt[k] = u
                applyPath(path.copy(frameT = nt)) // ฝังตำแหน่งใหม่ทันที ตัวละครขยับตามนิ้ว
            }
            PathTouch.LINE -> {
                val w = toWorld(pos)
                if (pathDraft.size >= 2) pathDraft[1] = w else pathDraft.add(w)
            }
            PathTouch.STROKE -> {
                val w = toWorld(pos)
                val last = pathDraft.lastOrNull()
                if (last == null || (w - last).getDistance() * zoom >= 3f) pathDraft.add(w)
            }
            PathTouch.TAP -> {
                if ((pos - pathTapStart).getDistance() > 14f) pathTapMoved = true
                if (pathTapMoved) pan += delta // ลากบนที่ว่างในโหมดแตะวางจุด = เลื่อนจอ
            }
            PathTouch.PAN -> pan += delta
            PathTouch.NONE -> {}
        }
    }

    private fun pathUp() {
        when (pathTouch) {
            PathTouch.STROKE -> {
                val raw = pathDraft.toList()
                pathDraft.clear()
                if (raw.size >= 2 && PathMath.length(raw) * zoom >= 40f) { // สั้นกว่านี้ถือว่าแค่แตะ ไม่ใช่เส้น
                    submitPoints(PathMath.simplifyStroke(raw, 6f / zoom))
                }
            }
            PathTouch.LINE -> {
                val a = pathDraft.getOrNull(0)
                val b = pathDraft.getOrNull(1)
                pathDraft.clear()
                if (a != null && b != null && (b - a).getDistance() * zoom >= 24f) { // สั้นกว่านี้ถือว่าแค่แตะ
                    submitPoints(listOf(a, b), smooth = false)
                }
            }
            PathTouch.TAP -> if (!pathTapMoved) pathTap(toWorld(pathTapStart))
            else -> {}
        }
        pathTouch = PathTouch.NONE
        pathHandle = null
        pathDot = null
    }

    /** แตะวางจุด: ยังไม่มีเส้น = สะสมจุด (ครบ 2 จุดเริ่มเป็นเส้น), มีเส้นแล้ว = แตะใกล้เส้นแทรกจุดตรงนั้น ไม่งั้นต่อท้ายเส้น */
    private fun pathTap(w: Offset) {
        val path = activePath()
        if (path == null) {
            pathDraft.add(w)
            if (pathDraft.size >= 2) {
                val pts = pathDraft.toList()
                pathDraft.clear()
                submitPoints(pts)
            }
            return
        }
        pathSel = null // แทรก/ต่อจุด เลขจุดเลื่อน
        val d = PathMath.dense(path.points, path.smooth, path.closed)
        val near = PathMath.nearestSegment(d, w)
        val pts = path.points.toMutableList()
        if (near != null && near.first * zoom < 28f) pts.add((near.second + 1).coerceIn(1, pts.size), w) else pts.add(w)
        applyPath(path.copy(points = pts))
    }

    /** เปิด/ปิดเครื่องมือหมุนหรือขยายตัวละครที่เลือก (กดซ้ำ = กลับโหมดปกติ) */
    fun toggleCharTool(t: Tool) {
        tool = if (tool == t) Tool.MOVE else t
    }

    /**
     * พลิกตัวละครที่เลือกแบบกระจกรอบจุดหลัก: horizontal = ซ้าย-ขวา, ไม่ใช่ = ขึ้น-ลง
     * allFrames = false (ค่าเริ่มต้น): พลิกเฉพาะเฟรมที่เปิดอยู่ (เก็บใน Pose ของชิ้นราก)
     * allFrames = true: พลิกทุกเฟรมพร้อมกัน (เก็บใน Part เหมือนเดิม)
     */
    fun flipCharacter(horizontal: Boolean, allFrames: Boolean = false) {
        if (playing) return
        val cid = activeCharacterId() ?: return
        recorded {
            for (p in project.parts) {
                if (p.characterId != cid) continue
                if (allFrames) {
                    if (horizontal) p.mirrorH = !p.mirrorH else p.mirrorV = !p.mirrorV
                } else if (p.parentId == null && !p.isDetachedItem) {
                    updatePose(p.id) { if (horizontal) it.copy(flipH = !it.flipH) else it.copy(flipV = !it.flipV) }
                }
            }
        }
    }

    /** คัดลอกตัวละครที่เลือก (ภาพ โครงกระดูก ขนาด การพลิก และท่าทางทุกเฟรม) ไว้รอกดวาง */
    fun copyCharacter() {
        val cid = activeCharacterId() ?: return
        val ps = project.parts.filter { it.characterId == cid }
        if (ps.isEmpty()) return
        val ids = ps.map { it.id }.toSet()
        if (ps.any { p -> p.parentId?.let { it !in ids } == true }) { // ของที่ติดมือของตัวละครอื่นอยู่: สำเนาจะตำแหน่งเพี้ยน
            message = "ถอดสิ่งของออกจากมือก่อนคัดลอกตัวละคร"
            return
        }
        val cps = ps.map { p ->
            ClipPart(
                p.id, p.parentId?.takeIf { it in ids }, p.name, p.bitmap, p.x, p.y, p.pivotX, p.pivotY,
                p.restRotation, p.boneLength, p.hasTip, p.tipX, p.tipY, p.scale, p.flipX, p.visible,
                p.mirrorH, p.mirrorV, p.charScale, p.role, p.homeRest, p.freed, p.appearFrom, p.appearTo, p.charAlpha,
            )
        }
        val frames: List<Map<Int, Pose>> = project.frames.map { f ->
            ids.mapNotNull { id -> f[id]?.let { id to it } }.toMap()
        }
        val name = ps.first().characterName.ifBlank { "ตัวละคร" }
        characterClipboard = CharacterClip(name, cps, frames)
        message = "คัดลอกตัวละคร \"$name\" แล้ว (รวมท่าทางทุกเฟรม) กดปุ่มวางที่มุมขวาบน"
    }

    /** วางตัวละครที่คัดลอกไว้เป็นตัวใหม่ (เลื่อนตำแหน่งเล็กน้อยไม่ให้ซ้อนทับ) พร้อมท่าทางในเฟรมที่มีอยู่ */
    fun pasteCharacter() {
        if (playing) return
        val clip = characterClipboard ?: return
        recorded { pasteCharacterInner(clip) }
    }

    private fun pasteCharacterInner(clip: CharacterClip) {
        val cid = project.newCharacterId()
        val offset = 40f * (++clip.pasteCount)
        val idMap = HashMap<Int, Int>()
        val newName = if (clip.name.endsWith(" (สำเนา)")) clip.name else clip.name + " (สำเนา)"
        for (cp in clip.parts) {
            val part = project.addPart(cp.name, cp.bitmap, null)
            part.x = cp.x
            part.y = cp.y
            part.pivotX = cp.pivotX
            part.pivotY = cp.pivotY
            part.restRotation = cp.restRotation
            part.boneLength = cp.boneLength
            part.hasTip = cp.hasTip
            part.tipX = cp.tipX
            part.tipY = cp.tipY
            part.scale = cp.scale
            part.flipX = cp.flipX
            part.visible = cp.visible
            part.mirrorH = cp.mirrorH
            part.mirrorV = cp.mirrorV
            part.charScale = cp.charScale
            part.role = cp.role
            part.homeRest = cp.homeRest
            part.freed = cp.freed
            part.appearFrom = cp.appearFrom
            part.appearTo = cp.appearTo
            part.charAlpha = cp.charAlpha
            part.characterId = cid
            part.characterName = newName
            if (cp.parentOldId == null) {
                part.x += offset
                part.y += offset
            }
            idMap[cp.oldId] = part.id
        }
        for (cp in clip.parts) {
            val parentNew = cp.parentOldId?.let { idMap[it] } ?: continue
            project.part(idMap[cp.oldId])?.parentId = parentNew
        }
        for (i in 0 until minOf(clip.frames.size, project.frameCount)) {
            for ((oldId, pose) in clip.frames[i]) idMap[oldId]?.let { newId ->
                // สิ่งของที่ถือมือของตัวละครที่คัดลอก: ชี้ไปที่มือของสำเนา (มือของตัวอื่น = ยังไม่ติด)
                project.frames[i][newId] = if (pose.hold > 0) pose.copy(hold = idMap[pose.hold] ?: HOLD_NONE) else pose
            }
        }
        selectedCharacterId = cid
        selectedId = idMap[clip.parts.first().oldId]
        message = "วางตัวละคร \"$newName\" แล้ว"
    }

    fun addDemo() = recorded {
        DemoCharacter.build(project)
        selectedId = project.parts.firstOrNull()?.id
    }

    fun deleteSelected() {
        val s = selected ?: return
        recorded {
            project.removeWithDescendants(s.id)
            selectedId = null
        }
    }

    fun clearProject() = recorded {
        playing = false
        project.clear()
        selectedId = null
        currentFrame = 0
        playhead = 0f
    }

    /** เปลี่ยน parent โดยคงตำแหน่งข้อต่อในโลกเดิม */
    fun setParent(part: Part, newParentId: Int?) = recorded {
        setParentInner(part, newParentId)
    }

    private fun setParentInner(part: Part, newParentId: Int?) {
        if (newParentId == part.id) return
        if (newParentId != null && newParentId in project.descendants(part.id)) {
            message = "ตั้ง parent (ชิ้นแม่) เป็นลูกหลานของตัวเองไม่ได้"
            return
        }
        val joints = computeJointMatrices(project.parts) { Pose() }
        val mine = joints[part.id] ?: return
        val pt = floatArrayOf(0f, 0f)
        mine.mapPoints(pt)
        val npm = newParentId?.let { joints[it] } ?: Matrix()
        val inv = Matrix()
        if (!npm.invert(inv)) return
        inv.mapPoints(pt)
        val oldAcc = accumulatedRest(part.parentId)
        part.parentId = newParentId
        part.x = pt[0]
        part.y = pt[1]
        part.restRotation += oldAcc - accumulatedRest(newParentId) // คงทิศทางภาพในโลกไว้เหมือนเดิม
    }

    private fun accumulatedRest(id: Int?): Float {
        var sum = 0f
        var cur = project.part(id)
        var guard = 0
        while (cur != null && guard++ < 64) {
            sum += cur.restRotation
            cur = project.part(cur.parentId)
        }
        return sum
    }

    fun copyFromPreviousFrame() {
        if (currentFrame == 0) {
            message = "เฟรมแรกไม่มีเฟรมก่อนหน้า"
            return
        }
        recorded {
            val dst = project.frames[currentFrame]
            dst.clear()
            dst.putAll(project.frames[currentFrame - 1])
        }
    }

    /** เพิ่มเฟรมท้ายสุด คัดลอกท่าจากเฟรมท้ายเดิม แล้วย้ายไปอยู่ที่เฟรมใหม่ */
    fun addFrame() {
        if (playing) return
        recorded {
            project.addFrameFrom(project.frameCount - 1)
            currentFrame = project.frameCount - 1
            playhead = currentFrame.toFloat()
        }
    }

    /** ลบเฟรมปัจจุบัน เฟรมหลังจากนี้เลื่อนขึ้นมาแทน (ต้องเหลืออย่างน้อย 1 เฟรม) */
    fun deleteCurrentFrame() {
        if (playing) return
        recorded {
            if (!project.removeFrame(currentFrame)) {
                message = "ต้องมีอย่างน้อย 1 เฟรม"
                return
            }
            currentFrame = currentFrame.coerceAtMost(project.frameCount - 1)
            playhead = currentFrame.toFloat()
        }
    }

    /** ล้างท่าของเฟรมนี้ (สถานะถือ/ถอดของสิ่งของไม่ถูกล้าง: ติด/ถอดแก้ได้ที่ปุ่มติด/ถอดเท่านั้น) */
    fun clearFrame() = recorded {
        val map = project.frames[currentFrame]
        val keep = map.filter { (id, _) -> project.part(id)?.role == BoneRole.ITEM }
        map.clear()
        map.putAll(keep)
    }

    var frameClipboard by mutableStateOf<Map<Int, Pose>?>(null) // ท่าของเฟรมที่คัดลอกไว้ (id ชิ้นส่วน -> ท่า)
    var frameClipboardFrom by mutableIntStateOf(0) // เลขเฟรม (เริ่มที่ 1) ที่คัดลอกมา

    /** คัดลอกท่าของเฟรม index ไว้ (ยังไม่เพิ่มอะไรจนกว่าจะกดวาง) */
    fun copyFrame(index: Int) {
        val f = project.frames.getOrNull(index) ?: return
        frameClipboard = f.toMap()
        frameClipboardFrom = index + 1
    }

    /** วางเฟรมที่คัดลอกไว้: เพิ่มเป็นเฟรมใหม่ต่อจากเฟรม index แล้วไปอยู่ที่เฟรมนั้น (ท่าของชิ้นที่ถูกลบไปแล้วจะไม่ถูกใส่) */
    fun pasteFrameAfter(index: Int) {
        if (playing) return
        val clip = frameClipboard ?: return
        val alive = project.parts.map { it.id }.toSet()
        recorded {
            project.insertFrameAt(index + 1, clip.filterKeys { it in alive })
            currentFrame = (index + 1).coerceAtMost(project.frameCount - 1)
            playhead = currentFrame.toFloat()
        }
    }

    /** ลบเฟรมที่ index (ต้องเหลืออย่างน้อย 1 เฟรม) เฟรมหลังจากนั้นเลื่อนขึ้นมาแทน */
    fun deleteFrame(index: Int) {
        if (playing) return
        recorded {
            if (!project.removeFrame(index)) {
                message = "ต้องมีอย่างน้อย 1 เฟรม"
                return
            }
            currentFrame = if (index < currentFrame) currentFrame - 1 else currentFrame.coerceAtMost(project.frameCount - 1)
            playhead = currentFrame.toFloat()
        }
    }

    /**
     * ลบหลายเฟรมพร้อมกัน (indices = เลขเฟรมเริ่มที่ 0) เฟรมหลังจากนั้นเลื่อนขึ้นมาแทน
     * ถ้าเลือกครบทุกเฟรม = ลบทั้งหมด (เหลือ 1 เฟรมว่าง) คืนจำนวนเฟรมที่ถูกลบ
     */
    fun deleteFrames(indices: Set<Int>): Int {
        if (playing) return 0
        val valid = indices.filter { it in project.frames.indices }.toSortedSet()
        if (valid.isEmpty()) return 0
        return recorded {
            if (valid.size >= project.frameCount) return@recorded deleteAllFrames()
            val oldCurrent = currentFrame
            for (i in valid.reversed()) project.removeFrame(i) // ลบจากท้ายมาหน้า เลขเฟรมที่ยังไม่ลบจึงไม่เพี้ยน
            val before = valid.count { it < oldCurrent }
            currentFrame = (oldCurrent - before).coerceIn(0, project.frameCount - 1)
            playhead = currentFrame.toFloat()
            valid.size
        }
    }

    /** ลบเฟรมทั้งหมด เหลือ 1 เฟรมว่าง (ตัวละครและกระดูกไม่หาย) คืนจำนวนเฟรมที่มีก่อนลบ */
    fun deleteAllFrames(): Int {
        if (playing) return 0
        return recorded {
            val n = project.frameCount
            project.resetFrames()
            currentFrame = 0
            playhead = 0f
            n
        }
    }

    // ---------- งาน (โปรเจกต์) ----------
    var projectName by mutableStateOf("") // ชื่องานที่เซฟ/โหลดล่าสุด ใช้เป็นชื่อเริ่มต้นตอนกดเซฟงาน

    /** เริ่มงานใหม่: ล้างตัวละครในฉาก เฟรม ช่วงความเร็ว และโครงกระดูก (ตัวละครที่เซฟไว้ในแอปและงานที่เซฟไว้ไม่หาย) */
    fun newProject() {
        clearHistory() // งานใหม่ = ประวัติย้อนกลับของงานเก่าใช้ไม่ได้
        playing = false
        project.clear()
        skeleton.replaceWith(Skeleton())
        selectedId = null
        currentFrame = 0
        playhead = 0f
        selectedCharacterId = null
        if (tool == Tool.CHAR_ROTATE || tool == Tool.CHAR_SCALE) tool = Tool.MOVE
        frameClipboard = null
        frameClipboardFrom = 0
        boneEditorOpen = false
        projectName = ""
    }

    fun resetSelectedPose() = recorded {
        selectedId?.let { id ->
            if (project.part(id)?.role != BoneRole.ITEM) project.frames[currentFrame].remove(id) // สิ่งของ: สถานะติด/ถอดอยู่ในท่า ไม่รีเซ็ตด้วยปุ่มนี้
        }
        Unit
    }

    // ---------- เล่นแอนิเมชัน ----------
    fun togglePlay() {
        if (mode != Mode.ANIMATE) return
        if (playing) {
            playing = false
            currentFrame = playhead.roundToInt().mod(project.frameCount)
        } else {
            playhead = currentFrame.toFloat()
            playing = true
        }
    }

    fun stop() {
        playing = false
        currentFrame = 0
        playhead = 0f
    }

    fun tick(dtSeconds: Float) {
        if (!playing) return
        val n = if (loop) project.loopCount() else project.frameCount
        var p = playhead
        if (p >= n) p = 0f
        // กันเฟรมสะดุด (เช่นเครื่องหน่วงชั่วขณะ) ไม่ให้ข้ามเฟรมหรือกระโดดตอนวนกลับ
        var left = dtSeconds.coerceIn(0f, 0.25f)
        var guard = 0
        // เดินทีละเฟรมตามความเร็วของเฟรมนั้น (อยู่ในช่วงที่ตั้งความเร็วเองใช้ค่าของช่วง ไม่งั้นใช้ fps ปกติ)
        while (left > 0f && guard++ < 1000) {
            val idx = p.toInt().coerceIn(0, n - 1)
            val f = project.fpsAt(idx, fps).toFloat()
            val toNext = (idx + 1 - p) / f // เวลา (วินาที) ที่เหลือก่อนถึงเฟรมถัดไป
            if (left < toNext) {
                p += left * f
                left = 0f
            } else {
                left -= toNext
                p = (idx + 1).toFloat()
            }
            if (loop) {
                if (p >= n) p -= n
            } else if (p >= n - 1) {
                p = (n - 1).toFloat()
                playing = false
                break
            }
        }
        playhead = p
        currentFrame = p.toInt().coerceIn(0, n - 1)
    }
}
