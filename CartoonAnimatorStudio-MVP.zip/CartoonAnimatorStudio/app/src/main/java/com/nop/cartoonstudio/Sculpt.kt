package com.nop.cartoonstudio

import kotlin.math.ceil
import kotlin.math.hypot

/**
 * ปั้นภาพอิสระ (mesh deform) ระยะ 0
 *
 * ภาพของชิ้นส่วนถูกแบ่งเป็นตารางจุด (cols x rows ช่อง) แล้วเก็บ "ออฟเซ็ต" ของแต่ละจุดเป็นหน่วยพิกเซลของ bitmap
 * ออฟเซ็ต 0 = รูปเดิม วาดด้วย Canvas.drawBitmapMesh
 *
 * SculptGrid เป็นวัตถุ immutable: ห้ามแก้ค่าใน off หลังสร้าง (สร้างอันใหม่ทุกครั้งที่แก้)
 * เหตุผล: Pose เป็น data class และระบบ undo เปรียบเทียบสถานะด้วย == จึงต้องมี equals ตามค่า
 * และท่าที่ถูกคัดลอกระหว่างเฟรมใช้วัตถุเดียวกันร่วมกันได้โดยไม่กิน RAM เพิ่ม
 *
 * ไฟล์นี้ไม่พึ่ง Android (ทดสอบบน JVM ได้)
 */
class SculptGrid(val cols: Int, val rows: Int, val off: FloatArray) {
    init {
        require(off.size == (cols + 1) * (rows + 1) * 2) { "ขนาดออฟเซ็ตไม่ตรงกับตาราง" }
    }

    fun isZero(): Boolean = off.all { it == 0f }

    override fun equals(other: Any?): Boolean =
        this === other || (other is SculptGrid && cols == other.cols && rows == other.rows && off.contentEquals(other.off))

    override fun hashCode(): Int = 31 * (31 * cols + rows) + off.contentHashCode()

    companion object {
        fun zero(cols: Int, rows: Int) = SculptGrid(cols, rows, FloatArray((cols + 1) * (rows + 1) * 2))
    }
}

object Sculpt {
    /** ขนาดช่องตาข่ายโดยประมาณ (พิกเซลของ bitmap) */
    private const val CELL = 48f

    /** ค่าความปลอดภัยกันตาข่ายพับ (ทดสอบด้วยสคริปต์: 1.0 พับ, 0.7 ไม่พับ; ใช้ 0.5 เผื่อไว้) */
    private const val SAFETY = 0.5f

    /** จำนวนช่องของตารางสำหรับ bitmap ขนาด w x h (ผลลัพธ์ = cols, rows) */
    fun gridDims(w: Int, h: Int): Pair<Int, Int> =
        Pair(ceil(w / CELL).toInt().coerceIn(4, 24), ceil(h / CELL).toInt().coerceIn(4, 24))

    /** ตำแหน่งจุดตาข่ายทั้งหมด (พื้นฐาน + ออฟเซ็ต) รูปแบบ [x0,y0,x1,y1,...] สำหรับ drawBitmapMesh ส่งอาร์เรย์ใหม่ทุกครั้ง */
    fun verts(w: Int, h: Int, g: SculptGrid): FloatArray {
        val out = FloatArray(g.off.size)
        var n = 0
        for (j in 0..g.rows) for (i in 0..g.cols) {
            out[2 * n] = i * w.toFloat() / g.cols + g.off[2 * n]
            out[2 * n + 1] = j * h.toFloat() / g.rows + g.off[2 * n + 1]
            n++
        }
        return out
    }

    /**
     * น้ำหนักของแต่ละจุดต่อพู่กัน (คำนวณครั้งเดียวตอนวางนิ้ว)
     * (cx,cy) = จุดนิ้วในพิกัดตาข่าย (พิกเซล bitmap) ใช้ตำแหน่งจุดที่ปั้นแล้ว ให้ตรงกับภาพที่เห็นบนจอ
     * pinR > 0 = ตรึงข้อต่อ: น้ำหนักค่อยๆ ลดเป็น 0 ที่จุดหมุน (pivotX,pivotY)
     */
    fun brushWeights(
        w: Int, h: Int, g: SculptGrid,
        cx: Float, cy: Float, radius: Float,
        pivotX: Float, pivotY: Float, pinR: Float,
    ): FloatArray {
        val out = FloatArray((g.cols + 1) * (g.rows + 1))
        var n = 0
        for (j in 0..g.rows) for (i in 0..g.cols) {
            val vx = i * w.toFloat() / g.cols + g.off[2 * n]
            val vy = j * h.toFloat() / g.rows + g.off[2 * n + 1]
            val k = 1f - (hypot(vx - cx, vy - cy) / radius).coerceAtMost(1f)
            var wt = k * k * (3f - 2f * k) // smoothstep: 1 กลางพู่กัน, 0 ที่ขอบ
            if (pinR > 0f) {
                val u = (hypot(vx - pivotX, vy - pivotY) / pinR).coerceAtMost(1f)
                wt *= u * u * (3f - 2f * u)
            }
            out[n++] = wt
        }
        return out
    }

    /** ระยะลากรวมสูงสุดต่อ 1 สโตรกที่ยังไม่ทำให้ตาข่ายพับ (ประมาณจากความชันสูงสุดของน้ำหนัก) */
    fun maxStep(radius: Float, pinR: Float): Float {
        val slope = 1.5f / radius + (if (pinR > 0f) 1.5f / pinR else 0f)
        return SAFETY / slope
    }

    /**
     * ดึงตาข่าย: start = ตาข่ายตอนวางนิ้ว, (dx,dy) = ระยะที่นิ้วลากรวมตั้งแต่วางนิ้ว (พิกเซล bitmap)
     * คำนวณจาก start ทุกครั้ง (ไม่สะสมทีละเฟรม) จึงไม่ลอยเพี้ยนและ 1 สโตรก = 1 ก้าว undo
     */
    fun applyGrab(start: SculptGrid, wts: FloatArray, dx: Float, dy: Float, maxStep: Float): SculptGrid {
        val m = hypot(dx, dy)
        val s = if (m > maxStep && m > 0f) maxStep / m else 1f
        val o = start.off.copyOf()
        for (v in wts.indices) {
            o[2 * v] += wts[v] * dx * s
            o[2 * v + 1] += wts[v] * dy * s
        }
        return SculptGrid(start.cols, start.rows, o)
    }

    /** ค่ากลางระหว่างสองท่า (null = ไม่ปั้น = ออฟเซ็ตศูนย์) */
    fun lerp(a: SculptGrid?, b: SculptGrid?, t: Float): SculptGrid? {
        if (a == null && b == null) return null
        if (a != null && b != null && (a.cols != b.cols || a.rows != b.rows)) return if (t < 0.5f) a else b
        val ref = (a ?: b)!!
        val ao = a?.off
        val bo = b?.off
        return SculptGrid(ref.cols, ref.rows, FloatArray(ref.off.size) { i ->
            val x = if (ao != null) ao[i] else 0f
            val y = if (bo != null) bo[i] else 0f
            x + (y - x) * t
        })
    }
}
