package com.nop.cartoonstudio

import kotlin.math.abs
import kotlin.math.ceil
import kotlin.math.cos
import kotlin.math.hypot
import kotlin.math.pow
import kotlin.math.sin

/**
 * ปั้นภาพอิสระ (mesh deform) ระยะ 0
 *
 * ภาพของชิ้นส่วนถูกแบ่งเป็นตารางจุด (cols x rows ช่อง) แล้วเก็บ "ออฟเซ็ต" ของแต่ละจุดเป็นหน่วยพิกเซลของ bitmap
 * ออฟเซ็ต 0 = รูปเดิม วาดด้วย Canvas.drawBitmapMesh
 *
 * SculptGrid เป็นวัตถุ immutable: ห้ามแก้ค่าใน off หลังสร้าง (สร้างอันใหม่ทุกครั้งที่แก้)
 * เหตุผล: Pose เป็น data class และระบบ undo เปรียบเทียบสถานะด้วย == จึงต้องมี equals ตามค่า
 * และท่าที่ถูกคัดลอกระหว่างเฟรมใช้วัตถุเดียวกันร่วมกันได้โดยไม่กิน RAM เพิ่ม
 *
 * ไฟล์นี้ไม่พึ่ง Android (ทดสอบบน JVM ได้)
 */
class SculptGrid(
    val cols: Int, val rows: Int, val off: FloatArray,
    /** ตำแหน่งเส้นตาข่ายตั้งต้น (สัดส่วน 0..1 ของความกว้าง/สูง ยาว cols+1 / rows+1) null = เว้นระยะเท่ากัน (ตาข่ายถี่ตามจุด = หมุดข้อต่อ) */
    val xs: FloatArray? = null, val ys: FloatArray? = null,
    /** มุมงอ (องศา) ของหมุดข้อต่อ เรียงตามลำดับหมุดของคลิป null/สั้นกว่า = 0 */
    val pinAngles: FloatArray? = null,
) {
    init {
        require(off.size == (cols + 1) * (rows + 1) * 2) { "ขนาดออฟเซ็ตไม่ตรงกับตาราง" }
        require(xs == null || xs.size == cols + 1) { "จำนวนเส้นตาข่ายแนวตั้งไม่ตรง" }
        require(ys == null || ys.size == rows + 1) { "จำนวนเส้นตาข่ายแนวนอนไม่ตรง" }
    }

    /** ไม่มีการบิดเลย: ออฟเซ็ตเป็นศูนย์ และมุมงอของหมุดเป็นศูนย์ทั้งหมด */
    fun isZero(): Boolean = off.all { it == 0f } && (pinAngles == null || pinAngles.all { it == 0f })

    /** ตำแหน่ง x ตั้งต้นของเส้นตาข่ายที่ i (พิกเซล bitmap กว้าง w) */
    fun restX(i: Int, w: Int): Float = if (xs == null) i * w.toFloat() / cols else xs[i] * w
    fun restY(j: Int, h: Int): Float = if (ys == null) j * h.toFloat() / rows else ys[j] * h

    /** สำเนาที่เปลี่ยนเฉพาะออฟเซ็ต (คงรูปแบบตาข่ายและมุมงอของหมุดไว้) */
    fun withOff(o: FloatArray) = SculptGrid(cols, rows, o, xs, ys, pinAngles)

    /** มุมงอของหมุดลำดับที่ i (0 ถ้าไม่มี) */
    fun angleOf(i: Int): Float = pinAngles?.getOrNull(i) ?: 0f

    /** ตาข่ายรูปแบบเดียวกันไหม (จำนวนช่องและตำแหน่งเส้นตรงกัน) */
    fun sameLayout(o: SculptGrid): Boolean =
        cols == o.cols && rows == o.rows &&
            (if (xs == null) o.xs == null else o.xs != null && xs.contentEquals(o.xs)) &&
            (if (ys == null) o.ys == null else o.ys != null && ys.contentEquals(o.ys))

    override fun equals(other: Any?): Boolean =
        this === other || (other is SculptGrid && sameLayout(other) && off.contentEquals(other.off) &&
            (pinAngles ?: FloatArray(0)).let { a -> (other.pinAngles ?: FloatArray(0)).let { b -> trimmedEquals(a, b) } })

    override fun hashCode(): Int {
        var h = 31 * (31 * cols + rows) + off.contentHashCode()
        h = 31 * h + (xs?.contentHashCode() ?: 0)
        h = 31 * h + (ys?.contentHashCode() ?: 0)
        var last = (pinAngles?.size ?: 0) - 1
        while (last >= 0 && pinAngles!![last] == 0f) last--
        for (k in 0..last) h = 31 * h + (pinAngles!![k] + 0f).hashCode()
        return h
    }

    companion object {
        fun zero(cols: Int, rows: Int, xs: FloatArray? = null, ys: FloatArray? = null) =
            SculptGrid(cols, rows, FloatArray((cols + 1) * (rows + 1) * 2), xs, ys)

        /** เทียบมุมงอสองชุด: ตัดศูนย์ท้ายแถวออกก่อน (ยาวไม่เท่ากันแต่ค่าเท่ากัน = เท่ากัน) */
        private fun trimmedEquals(a: FloatArray, b: FloatArray): Boolean {
            val n = maxOf(a.size, b.size)
            for (k in 0 until n) if ((a.getOrNull(k) ?: 0f) != (b.getOrNull(k) ?: 0f)) return false
            return true
        }
    }
}

object Sculpt {
    /** ขนาดช่องตาข่ายโดยประมาณ (พิกเซลของ bitmap) */
    private const val CELL = 48f

    /** ค่าความปลอดภัยกันตาข่ายพับ (ทดสอบด้วยสคริปต์: 1.0 พับ, 0.7 ไม่พับ; ใช้ 0.5 เผื่อไว้) */
    private const val SAFETY = 0.5f

    /** จำนวนช่องของตารางสำหรับ bitmap ขนาด w x h (ผลลัพธ์ = cols, rows) */
    fun gridDims(w: Int, h: Int): Pair<Int, Int> =
        Pair(ceil(w / CELL).toInt().coerceIn(4, 24), ceil(h / CELL).toInt().coerceIn(4, 24))

    /** จำนวนช่องสูงสุดต่อด้านตอนวาดตาข่ายถี่ตามจุด (แปลงเป็นตาข่ายเว้นระยะเท่ากันที่ละเอียดขึ้น) */
    private const val DRAW_GRID_MAX = 96

    /**
     * วาดภาพผ่านตาข่าย (ใช้แทน drawBitmapMesh ตรง ๆ)
     * สาเหตุ: drawBitmapMesh แมปพื้นผิวแบบเว้นระยะเท่ากันเสมอ แต่ตาข่ายถี่ตามจุด (xs/ys ไม่เท่ากัน) วางจุดไม่เท่ากัน
     * ภาพทั้งภาพจึงถูกดึงเข้าหาหมุดทันทีที่งอหมุด (ดูเหมือนภาพย่อ) → แปลงเป็นตาข่ายเว้นระยะเท่ากัน (ละเอียดขึ้น 3 เท่า) ก่อนวาด
     * ตาข่ายปกติ (xs/ys เป็น null) วาดเหมือนเดิมทุกอย่าง
     */
    fun drawMesh(canvas: android.graphics.Canvas, bmp: android.graphics.Bitmap, g: SculptGrid, paint: android.graphics.Paint?) {
        val d = if (g.xs == null && g.ys == null) g
        else resample(g, minOf(g.cols * 3, DRAW_GRID_MAX), minOf(g.rows * 3, DRAW_GRID_MAX))
        canvas.drawBitmapMesh(bmp, d.cols, d.rows, verts(bmp.width, bmp.height, d), 0, null, 0, paint)
    }

    /** ตำแหน่งจุดตาข่ายทั้งหมด (พื้นฐาน + ออฟเซ็ต) รูปแบบ [x0,y0,x1,y1,...] สำหรับ drawBitmapMesh ส่งอาร์เรย์ใหม่ทุกครั้ง */
    fun verts(w: Int, h: Int, g: SculptGrid): FloatArray {
        val out = FloatArray(g.off.size)
        var n = 0
        for (j in 0..g.rows) for (i in 0..g.cols) {
            out[2 * n] = g.restX(i, w) + g.off[2 * n]
            out[2 * n + 1] = g.restY(j, h) + g.off[2 * n + 1]
            n++
        }
        return out
    }

    /**
     * น้ำหนักของแต่ละจุดต่อพู่กัน (คำนวณครั้งเดียวตอนวางนิ้ว)
     * (cx,cy) = จุดนิ้วในพิกัดตาข่าย (พิกเซล bitmap) ใช้ตำแหน่งจุดที่ปั้นแล้ว ให้ตรงกับภาพที่เห็นบนจอ
     * pinR > 0 = ตรึงข้อต่อ: น้ำหนักค่อยๆ ลดเป็น 0 ที่จุดหมุน (pivotX,pivotY)
     */
    fun brushWeights(
        w: Int, h: Int, g: SculptGrid,
        cx: Float, cy: Float, radius: Float,
        pivotX: Float, pivotY: Float, pinR: Float,
    ): FloatArray {
        val out = FloatArray((g.cols + 1) * (g.rows + 1))
        var n = 0
        for (j in 0..g.rows) for (i in 0..g.cols) {
            val vx = g.restX(i, w) + g.off[2 * n]
            val vy = g.restY(j, h) + g.off[2 * n + 1]
            val k = 1f - (hypot(vx - cx, vy - cy) / radius).coerceAtMost(1f)
            var wt = k * k * (3f - 2f * k) // smoothstep: 1 กลางพู่กัน, 0 ที่ขอบ
            if (pinR > 0f) {
                val u = (hypot(vx - pivotX, vy - pivotY) / pinR).coerceAtMost(1f)
                wt *= u * u * (3f - 2f * u)
            }
            out[n++] = wt
        }
        return out
    }

    /** ระยะลากรวมสูงสุดต่อ 1 สโตรกที่ยังไม่ทำให้ตาข่ายพับ (ประมาณจากความชันสูงสุดของน้ำหนัก) */
    fun maxStep(radius: Float, pinR: Float): Float {
        val slope = 1.5f / radius + (if (pinR > 0f) 1.5f / pinR else 0f)
        return SAFETY / slope
    }

    /**
     * ดึงตาข่าย: start = ตาข่ายตอนวางนิ้ว, (dx,dy) = ระยะที่นิ้วลากรวมตั้งแต่วางนิ้ว (พิกเซล bitmap)
     * คำนวณจาก start ทุกครั้ง (ไม่สะสมทีละเฟรม) จึงไม่ลอยเพี้ยนและ 1 สโตรก = 1 ก้าว undo
     */
    fun applyGrab(start: SculptGrid, wts: FloatArray, dx: Float, dy: Float, maxStep: Float): SculptGrid {
        val m = hypot(dx, dy)
        val s = if (m > maxStep && m > 0f) maxStep / m else 1f
        val o = start.off.copyOf()
        for (v in wts.indices) {
            o[2 * v] += wts[v] * dx * s
            o[2 * v + 1] += wts[v] * dy * s
        }
        return start.withOff(o)
    }

    /** ค่ากลางระหว่างสองท่า (null = ไม่ปั้น = ออฟเซ็ตศูนย์) มุมงอของหมุดข้อต่อก็ผสมเป็นเส้นตรงเช่นกัน (ตาข่ายสร้างใหม่จากมุมทุกเฟรม แขนจึงไม่หดระหว่างท่า) */
    fun lerp(a: SculptGrid?, b: SculptGrid?, t: Float): SculptGrid? {
        if (a == null && b == null) return null
        if (a != null && b != null && !a.sameLayout(b)) return if (t < 0.5f) a else b
        val ref = (a ?: b)!!
        val ao = a?.off
        val bo = b?.off
        val na = maxOf(a?.pinAngles?.size ?: 0, b?.pinAngles?.size ?: 0)
        val angles = if (na == 0) null else FloatArray(na) { k ->
            val x = a?.angleOf(k) ?: 0f
            val y = b?.angleOf(k) ?: 0f
            x + (y - x) * t
        }
        return SculptGrid(ref.cols, ref.rows, FloatArray(ref.off.size) { i ->
            val x = if (ao != null) ao[i] else 0f
            val y = if (bo != null) bo[i] else 0f
            x + (y - x) * t
        }, ref.xs, ref.ys, angles)
    }

    // ───────────── ขนาดช่องตาข่ายที่ตั้งเองได้ / Mesh Warp / Twist ─────────────

    /** ช่วงขนาดช่องตาข่าย (พิกเซลของ bitmap) ที่ให้ผู้ใช้ตั้งได้ */
    const val CELL_MIN = 16f
    const val CELL_MAX = 128f

    /** จำนวนช่องสูงสุดต่อด้านเมื่อผู้ใช้ตั้งขนาดช่องเอง (ไฟล์โปรเจกต์รับได้ไม่เกิน 64 ต่อด้าน) */
    private const val GRID_MAX = 40

    /** จำนวนช่องตามขนาดช่องที่ผู้ใช้ตั้ง (พิกเซลของ bitmap); cell = null = อัตโนมัติ ใช้ค่าเดิมของแอป (gridDims สองพารามิเตอร์) */
    fun gridDims(w: Int, h: Int, cell: Float?): Pair<Int, Int> {
        if (cell == null) return gridDims(w, h)
        val c = cell.coerceIn(CELL_MIN, CELL_MAX)
        return Pair(ceil(w / c).toInt().coerceIn(4, GRID_MAX), ceil(h / c).toInt().coerceIn(4, GRID_MAX))
    }

    /** ตำแหน่งเศษส่วนของ u (0..1) บนแนวเส้นตาข่าย: จำนวนเต็ม = ตรงเส้น (breaks = null → เว้นระยะเท่ากัน) */
    private fun fracIndex(breaks: FloatArray?, n: Int, u: Float): Float {
        if (breaks == null) return u * n
        var k = 0
        while (k < n - 1 && breaks[k + 1] < u) k++
        val span = breaks[k + 1] - breaks[k]
        return k + if (span > 1e-6f) ((u - breaks[k]) / span).coerceIn(0f, 1f) else 0f
    }

    private fun sameBreaks(a: FloatArray?, b: FloatArray?): Boolean = if (a == null) b == null else b != null && a.contentEquals(b)

    /**
     * แปลงตารางเป็นจำนวนช่อง/รูปแบบเส้นตาข่ายใหม่ (สุ่มค่าออฟเซ็ตแบบ bilinear ตามตำแหน่งตั้งต้นของแต่ละจุด) ใช้ตอนเปลี่ยนความละเอียดตาข่าย
     * หรือย้ายหมุดข้อต่อ (ตาข่ายถี่ตามจุดเปลี่ยนที่) xs / ys ใหม่ = null → เว้นระยะเท่ากัน
     * เป็นการประมาณ: รายละเอียดที่ละเอียดกว่าตารางเดิมไม่กลับมา และตารางที่ถี่ลงจะไม่ทำให้ท่าเดิมเปลี่ยนรูป · มุมงอของหมุดคงเดิม
     */
    fun resample(g: SculptGrid, cols: Int, rows: Int, xs: FloatArray? = null, ys: FloatArray? = null): SculptGrid {
        if (g.cols == cols && g.rows == rows && sameBreaks(g.xs, xs) && sameBreaks(g.ys, ys)) return g
        val out = FloatArray((cols + 1) * (rows + 1) * 2)
        val ow = g.cols + 1
        var n = 0
        for (j in 0..rows) for (i in 0..cols) {
            val fx = fracIndex(g.xs, g.cols, xs?.get(i) ?: (i.toFloat() / cols))
            val fy = fracIndex(g.ys, g.rows, ys?.get(j) ?: (j.toFloat() / rows))
            val x0 = fx.toInt().coerceIn(0, g.cols - 1)
            val y0 = fy.toInt().coerceIn(0, g.rows - 1)
            val tx = fx - x0
            val ty = fy - y0
            for (k in 0..1) {
                val a = g.off[2 * (y0 * ow + x0) + k]
                val b = g.off[2 * (y0 * ow + x0 + 1) + k]
                val c = g.off[2 * ((y0 + 1) * ow + x0) + k]
                val d = g.off[2 * ((y0 + 1) * ow + x0 + 1) + k]
                out[2 * n + k] = (a * (1f - tx) + b * tx) * (1f - ty) + (c * (1f - tx) + d * tx) * ty
            }
            n++
        }
        return SculptGrid(cols, rows, out, xs, ys, g.pinAngles)
    }

    /**
     * ตารางใหม่ (lat: ตาข่ายเว้นระยะเท่ากันวางทับกรอบภาพ ออฟเซ็ต = ระยะที่ถูกดึง) ซ้อนบนท่าที่เห็นอยู่ตอนเริ่ม (e0)
     * จุดของ e0 แต่ละจุดถูกย้ายตามสนามระยะของ lat (interpolate แบบ bilinear ที่ตำแหน่งของจุดนั้น; นอกกรอบใช้ค่าขอบ)
     * คืนตาข่ายรูปแบบเดียวกับ e0 (ออฟเซ็ตตำแหน่งที่เห็น ไม่มีมุมหมุด) · lat ศูนย์ = e0 เดิม
     */
    fun compose(e0: SculptGrid, lat: SculptGrid, w: Int, h: Int): SculptGrid {
        val out = FloatArray(e0.off.size)
        val lw = lat.cols + 1
        var n = 0
        for (j in 0..e0.rows) for (i in 0..e0.cols) {
            val px = e0.restX(i, w) + e0.off[2 * n]
            val py = e0.restY(j, h) + e0.off[2 * n + 1]
            val fx = (px / w * lat.cols).coerceIn(0f, lat.cols.toFloat())
            val fy = (py / h * lat.rows).coerceIn(0f, lat.rows.toFloat())
            val x0 = fx.toInt().coerceIn(0, lat.cols - 1)
            val y0 = fy.toInt().coerceIn(0, lat.rows - 1)
            val tx = fx - x0
            val ty = fy - y0
            for (k in 0..1) {
                val a = lat.off[2 * (y0 * lw + x0) + k]
                val b = lat.off[2 * (y0 * lw + x0 + 1) + k]
                val c = lat.off[2 * ((y0 + 1) * lw + x0) + k]
                val d = lat.off[2 * ((y0 + 1) * lw + x0 + 1) + k]
                out[2 * n + k] = e0.off[2 * n + k] + (a * (1f - tx) + b * tx) * (1f - ty) + (c * (1f - tx) + d * tx) * ty
            }
            n++
        }
        return SculptGrid(e0.cols, e0.rows, out, e0.xs, e0.ys)
    }

    /** จำกัดระยะลากของจุดบิดต่อหนึ่งสโตรกไม่เกินครึ่งรัศมี (กันตาข่ายพับ) */
    fun capMove(ax: Float, ay: Float, radius: Float): Pair<Float, Float> {
        val m = hypot(ax, ay)
        val cap = 0.5f * maxOf(radius, 1f)
        return if (m > cap && m > 0f) Pair(ax * cap / m, ay * cap / m) else Pair(ax, ay)
    }

    /**
     * ห่วงบิด (วงกลม): ภาพในวงกลมศูนย์กลาง (cx, cy) รัศมี r ขยับตาม (ax, ay) แรงสูงสุดที่ศูนย์กลาง ลดลงนุ่ม ๆ จนเป็นศูนย์ที่ขอบวง
     * น้ำหนัก = (1 − (ระยะ/r)²)² : ต่อเนื่องที่ขอบ ไม่มีรอยหัก · คืนตาข่ายใหม่จาก st
     */
    fun applyRing(bw: Int, bh: Int, st: SculptGrid, cx: Float, cy: Float, r: Float, ax: Float, ay: Float): SculptGrid {
        val rr2 = maxOf(r, 1f) * maxOf(r, 1f)
        val out = st.off.copyOf()
        var n = 0
        for (j in 0..st.rows) for (i in 0..st.cols) {
            val dx = st.restX(i, bw) + st.off[2 * n] - cx
            val dy = st.restY(j, bh) + st.off[2 * n + 1] - cy
            val t2 = (dx * dx + dy * dy) / rr2
            if (t2 < 1f) {
                val w = (1f - t2) * (1f - t2)
                out[2 * n] += ax * w
                out[2 * n + 1] += ay * w
            }
            n++
        }
        return SculptGrid(st.cols, st.rows, out, st.xs, st.ys, st.pinAngles)
    }

    /** น้ำหนักของห่วง (cx, cy, r) ที่จุด (x, y): 1 ที่ศูนย์กลาง → 0 ที่ขอบวง/นอกวง (สูตรเดียวกับ applyRing) */
    fun ringWeight(cx: Float, cy: Float, r: Float, x: Float, y: Float): Float {
        val rr = maxOf(r, 1f)
        val t2 = ((x - cx) * (x - cx) + (y - cy) * (y - cy)) / (rr * rr)
        return if (t2 < 1f) (1f - t2) * (1f - t2) else 0f
    }

    /**
     * ย้อนกลับของ samplePos: จุดบนจอ (vx, vy) มาจากจุดไหนของภาพตั้งต้น — หาช่องตาข่ายที่ครอบจุดนั้น แล้วแก้สมการ bilinear (Newton)
     * ใช้วางหมุดตอนภาพงอ/ปั้นอยู่ · ถ้าไม่เจอช่อง (จุดอยู่นอกภาพ) ใช้วนซ้ำแก้ทีละน้อยแทน
     */
    fun restPoint(g: SculptGrid, bw: Int, bh: Int, vx: Float, vy: Float): Pair<Float, Float> {
        val lw = g.cols + 1
        for (j in 0 until g.rows) for (i in 0 until g.cols) {
            val a = j * lw + i
            val c = a + lw
            val x00 = g.restX(i, bw) + g.off[2 * a]
            val y00 = g.restY(j, bh) + g.off[2 * a + 1]
            val x10 = g.restX(i + 1, bw) + g.off[2 * (a + 1)]
            val y10 = g.restY(j, bh) + g.off[2 * (a + 1) + 1]
            val x01 = g.restX(i, bw) + g.off[2 * c]
            val y01 = g.restY(j + 1, bh) + g.off[2 * c + 1]
            val x11 = g.restX(i + 1, bw) + g.off[2 * (c + 1)]
            val y11 = g.restY(j + 1, bh) + g.off[2 * (c + 1) + 1]
            if (vx < minOf(minOf(x00, x10), minOf(x01, x11)) - 0.5f || vx > maxOf(maxOf(x00, x10), maxOf(x01, x11)) + 0.5f) continue
            if (vy < minOf(minOf(y00, y10), minOf(y01, y11)) - 0.5f || vy > maxOf(maxOf(y00, y10), maxOf(y01, y11)) + 0.5f) continue
            var u = 0.5f
            var v = 0.5f
            for (it in 0 until 8) {
                val fx = (1f - u) * (1f - v) * x00 + u * (1f - v) * x10 + (1f - u) * v * x01 + u * v * x11 - vx
                val fy = (1f - u) * (1f - v) * y00 + u * (1f - v) * y10 + (1f - u) * v * y01 + u * v * y11 - vy
                val dxu = (1f - v) * (x10 - x00) + v * (x11 - x01)
                val dxv = (1f - u) * (x01 - x00) + u * (x11 - x10)
                val dyu = (1f - v) * (y10 - y00) + v * (y11 - y01)
                val dyv = (1f - u) * (y01 - y00) + u * (y11 - y10)
                val det = dxu * dyv - dxv * dyu
                if (abs(det) < 1e-6f) break
                u = (u - (fx * dyv - fy * dxv) / det).coerceIn(-0.5f, 1.5f)
                v = (v - (dxu * fy - dyu * fx) / det).coerceIn(-0.5f, 1.5f)
            }
            if (u >= -0.002f && u <= 1.002f && v >= -0.002f && v <= 1.002f) {
                val uu = u.coerceIn(0f, 1f)
                val vv = v.coerceIn(0f, 1f)
                return Pair((1f - uu) * g.restX(i, bw) + uu * g.restX(i + 1, bw), (1f - vv) * g.restY(j, bh) + vv * g.restY(j + 1, bh))
            }
        }
        var rx = vx.coerceIn(0f, bw.toFloat())
        var ry = vy.coerceIn(0f, bh.toFloat())
        repeat(25) {
            val (px, py) = samplePos(g, bw, bh, rx, ry)
            rx = (rx - 0.6f * (px - vx)).coerceIn(0f, bw.toFloat())
            ry = (ry - 0.6f * (py - vy)).coerceIn(0f, bh.toFloat())
        }
        return Pair(rx, ry)
    }

    /** ตำแหน่งที่เห็นของจุด (x, y) ของภาพตั้งต้น บนตาข่าย g (interpolate bilinear ในช่องที่จุดนั้นอยู่) */
    fun samplePos(g: SculptGrid, bw: Int, bh: Int, x: Float, y: Float): Pair<Float, Float> {
        var i = 0
        while (i < g.cols - 1 && g.restX(i + 1, bw) <= x) i++
        var j = 0
        while (j < g.rows - 1 && g.restY(j + 1, bh) <= y) j++
        val x0 = g.restX(i, bw)
        val x1 = g.restX(i + 1, bw)
        val y0 = g.restY(j, bh)
        val y1 = g.restY(j + 1, bh)
        val tx = if (x1 > x0) ((x - x0) / (x1 - x0)).coerceIn(0f, 1f) else 0f
        val ty = if (y1 > y0) ((y - y0) / (y1 - y0)).coerceIn(0f, 1f) else 0f
        val lw = g.cols + 1
        fun px(ii: Int, jj: Int) = g.restX(ii, bw) + g.off[2 * (jj * lw + ii)]
        fun py(ii: Int, jj: Int) = g.restY(jj, bh) + g.off[2 * (jj * lw + ii) + 1]
        val ax = px(i, j) * (1f - tx) + px(i + 1, j) * tx
        val bx = px(i, j + 1) * (1f - tx) + px(i + 1, j + 1) * tx
        val ay = py(i, j) * (1f - tx) + py(i + 1, j) * tx
        val by = py(i, j + 1) * (1f - tx) + py(i + 1, j + 1) * tx
        return Pair(ax * (1f - ty) + bx * ty, ay * (1f - ty) + by * ty)
    }

    /** สองท่าเหมือนกันไหม (ตาข่ายรูปแบบเดียวกัน ออฟเซ็ตและมุมหมุดต่างกันไม่เกิน tol) — null เทียบกับ null เท่านั้น; ใช้เช็คว่าท่าบนจอยังเป็นท่าที่เพิ่งบิดเองอยู่ */
    fun approxEquals(a: SculptGrid?, b: SculptGrid?, tol: Float = 0.01f): Boolean {
        if (a == null || b == null) return a == null && b == null
        if (!a.sameLayout(b)) return false
        for (i in a.off.indices) if (abs(a.off[i] - b.off[i]) > tol) return false
        val n = maxOf(a.pinAngles?.size ?: 0, b.pinAngles?.size ?: 0)
        for (k in 0 until n) if (abs(a.angleOf(k) - b.angleOf(k)) > tol) return false
        return true
    }

    /** ช่องตาข่ายที่ใหญ่ที่สุด (พิกเซล bitmap) ตารางเว้นระยะเท่ากัน = max(w/cols, h/rows) เหมือนเดิม */
    fun cellMaxPx(w: Int, h: Int, g: SculptGrid): Float {
        var m = 0f
        for (i in 0 until g.cols) m = maxOf(m, g.restX(i + 1, w) - g.restX(i, w))
        for (j in 0 until g.rows) m = maxOf(m, g.restY(j + 1, h) - g.restY(j, h))
        return m
    }

    /** ช่องตาข่ายที่เล็กที่สุด (พิกเซล bitmap) ใช้คิดขีดจำกัดความปลอดภัยของ Mesh Warp บนตาข่ายถี่ตามจุด */
    fun cellMinPx(w: Int, h: Int, g: SculptGrid): Float {
        var m = Float.MAX_VALUE
        for (i in 0 until g.cols) m = minOf(m, g.restX(i + 1, w) - g.restX(i, w))
        for (j in 0 until g.rows) m = minOf(m, g.restY(j + 1, h) - g.restY(j, h))
        return m
    }

    /** จำนวนช่องที่ตาข่ายพับ (มุมใดมุมหนึ่งของช่องกลับด้าน) ตอนนี้ ใช้เตือนผู้ใช้เมื่อหมุดงอเกินที่ตาข่ายรับได้ */
    fun foldCount(w: Int, h: Int, g: SculptGrid): Int {
        val v = verts(w, h, g)
        val rw = g.cols + 1
        var bad = 0
        for (j in 0 until g.rows) for (i in 0 until g.cols) {
            val a = j * rw + i
            val b = a + 1
            val d = a + rw
            val c = d + 1
            // มุมซ้ายบน/ขวาบน/ขวาล่าง/ซ้ายล่าง: ทุกมุมต้องวนทิศเดียวกับตอนไม่บิด (cross > 0 ในพิกัดที่ y ชี้ลง)
            fun cr(p: Int, q: Int, r: Int): Float =
                (v[2 * q] - v[2 * p]) * (v[2 * r + 1] - v[2 * p + 1]) - (v[2 * q + 1] - v[2 * p + 1]) * (v[2 * r] - v[2 * p])
            if (cr(a, b, d) <= 0f || cr(b, c, a) <= 0f || cr(c, d, b) <= 0f || cr(d, a, c) <= 0f) bad++
        }
        return bad
    }

    /** จุดตาข่ายที่ถูกเลือกโดย Mesh Warp: ตำแหน่งในตาราง (i, j) และระยะจากนิ้ว (พิกเซล bitmap) */
    class VertexHit(val i: Int, val j: Int, val dist: Float)

    /** จุดตาข่ายที่ใกล้ (px, py) ที่สุด (พิกัด bitmap ใช้ตำแหน่งของจุดที่บิดแล้ว ตรงกับที่เห็นบนจอ) */
    fun nearestVertex(w: Int, h: Int, g: SculptGrid, px: Float, py: Float): VertexHit {
        var bi = 0
        var bj = 0
        var bd = Float.MAX_VALUE
        var n = 0
        for (j in 0..g.rows) for (i in 0..g.cols) {
            val vx = g.restX(i, w) + g.off[2 * n]
            val vy = g.restY(j, h) + g.off[2 * n + 1]
            val d = hypot(vx - px, vy - py)
            if (d < bd) { bd = d; bi = i; bj = j }
            n++
        }
        return VertexHit(bi, bj, bd)
    }

    /** น้ำหนักแบบ Mesh Warp: จุด (vi, vj) = 1 แล้วลดลงตามระยะ (นับเป็นช่อง) จนเป็น 0 ที่ระยะ rings+1 ช่อง; rings = 0 ขยับจุดเดียว */
    fun ringWeights(g: SculptGrid, vi: Int, vj: Int, rings: Int): FloatArray {
        val out = FloatArray((g.cols + 1) * (g.rows + 1))
        var n = 0
        for (j in 0..g.rows) for (i in 0..g.cols) {
            val k = 1f - (hypot((i - vi).toFloat(), (j - vj).toFloat()) / (rings + 1)).coerceAtMost(1f)
            out[n++] = k * k * (3f - 2f * k)
        }
        return out
    }

    /**
     * ระยะลากรวมสูงสุดต่อ 1 สโตรกของ Mesh Warp ที่ตาข่ายยังไม่พับ
     * ทดสอบด้วยสคริปต์จำลอง: ไม่พับจนถึงราว 0.575 x (rings+1) x ขนาดช่องเล็กสุด (ช่องจัตุรัส/ไม่จัตุรัส rings 0–6) ใช้ 0.4 เผื่อไว้
     */
    fun maxStepRings(cellMin: Float, rings: Int): Float = 0.4f * (rings + 1) * cellMin

    /**
     * มุมบิด Twist สูงสุด (เรเดียน) ที่ตาข่ายยังไม่พับ ตามรัศมีและขนาดช่องใหญ่สุด
     * ทดสอบด้วยสคริปต์จำลอง (รัศมี/ช่อง = 2–48) มุมที่ไม่พับจริงมากกว่าค่านี้ทุกกรณี: ยิ่งรัศมีใหญ่/ช่องถี่ ยิ่งบิดได้มาก
     */
    fun maxTwist(radius: Float, cellMax: Float): Float {
        val rc = (radius / cellMax).coerceAtLeast(1f)
        return rc.pow(0.37f)
    }

    /**
     * Twist: หมุนจุดตาข่ายรอบ (cx, cy) ด้วยมุม angle (เรเดียน, บวก = ตามเข็มบนจอ) ที่กลางพู่กัน ลดเป็น 0 ที่ขอบรัศมี
     * คำนวณจาก start ทุกครั้ง (ไม่สะสม) เหมือน applyGrab
     */
    fun applyTwist(w: Int, h: Int, start: SculptGrid, cx: Float, cy: Float, radius: Float, angle: Float): SculptGrid {
        val o = start.off.copyOf()
        var n = 0
        for (j in 0..start.rows) for (i in 0..start.cols) {
            val vx = start.restX(i, w) + start.off[2 * n]
            val vy = start.restY(j, h) + start.off[2 * n + 1]
            val dx = vx - cx
            val dy = vy - cy
            val k = 1f - (hypot(dx, dy) / radius).coerceAtMost(1f)
            val a = angle * (k * k * (3f - 2f * k))
            if (a != 0f) {
                val c = cos(a)
                val s = sin(a)
                o[2 * n] += cx + dx * c - dy * s - vx
                o[2 * n + 1] += cy + dx * s + dy * c - vy
            }
            n++
        }
        return start.withOff(o)
    }
}
