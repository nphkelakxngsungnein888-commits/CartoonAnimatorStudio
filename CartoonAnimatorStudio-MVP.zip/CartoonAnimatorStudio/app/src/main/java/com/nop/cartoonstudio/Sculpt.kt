package com.nop.cartoonstudio

import kotlin.math.ceil
import kotlin.math.cos
import kotlin.math.hypot
import kotlin.math.pow
import kotlin.math.sin

/**
 * ปั้นภาพอิสระ (mesh deform) ระยะ 0
 *
 * ภาพของชิ้นส่วนถูกแบ่งเป็นตารางจุด (cols x rows ช่อง) แล้วเก็บ "ออฟเซ็ต" ของแต่ละจุดเป็นหน่วยพิกเซลของ bitmap
 * ออฟเซ็ต 0 = รูปเดิม วาดด้วย Canvas.drawBitmapMesh
 *
 * SculptGrid เป็นวัตถุ immutable: ห้ามแก้ค่าใน off หลังสร้าง (สร้างอันใหม่ทุกครั้งที่แก้)
 * เหตุผล: Pose เป็น data class และระบบ undo เปรียบเทียบสถานะด้วย == จึงต้องมี equals ตามค่า
 * และท่าที่ถูกคัดลอกระหว่างเฟรมใช้วัตถุเดียวกันร่วมกันได้โดยไม่กิน RAM เพิ่ม
 *
 * ไฟล์นี้ไม่พึ่ง Android (ทดสอบบน JVM ได้)
 */
class SculptGrid(val cols: Int, val rows: Int, val off: FloatArray) {
    init {
        require(off.size == (cols + 1) * (rows + 1) * 2) { "ขนาดออฟเซ็ตไม่ตรงกับตาราง" }
    }

    fun isZero(): Boolean = off.all { it == 0f }

    override fun equals(other: Any?): Boolean =
        this === other || (other is SculptGrid && cols == other.cols && rows == other.rows && off.contentEquals(other.off))

    override fun hashCode(): Int = 31 * (31 * cols + rows) + off.contentHashCode()

    companion object {
        fun zero(cols: Int, rows: Int) = SculptGrid(cols, rows, FloatArray((cols + 1) * (rows + 1) * 2))
    }
}

object Sculpt {
    /** ขนาดช่องตาข่ายโดยประมาณ (พิกเซลของ bitmap) */
    private const val CELL = 48f

    /** ค่าความปลอดภัยกันตาข่ายพับ (ทดสอบด้วยสคริปต์: 1.0 พับ, 0.7 ไม่พับ; ใช้ 0.5 เผื่อไว้) */
    private const val SAFETY = 0.5f

    /** จำนวนช่องของตารางสำหรับ bitmap ขนาด w x h (ผลลัพธ์ = cols, rows) */
    fun gridDims(w: Int, h: Int): Pair<Int, Int> =
        Pair(ceil(w / CELL).toInt().coerceIn(4, 24), ceil(h / CELL).toInt().coerceIn(4, 24))

    /** ตำแหน่งจุดตาข่ายทั้งหมด (พื้นฐาน + ออฟเซ็ต) รูปแบบ [x0,y0,x1,y1,...] สำหรับ drawBitmapMesh ส่งอาร์เรย์ใหม่ทุกครั้ง */
    fun verts(w: Int, h: Int, g: SculptGrid): FloatArray {
        val out = FloatArray(g.off.size)
        var n = 0
        for (j in 0..g.rows) for (i in 0..g.cols) {
            out[2 * n] = i * w.toFloat() / g.cols + g.off[2 * n]
            out[2 * n + 1] = j * h.toFloat() / g.rows + g.off[2 * n + 1]
            n++
        }
        return out
    }

    /**
     * น้ำหนักของแต่ละจุดต่อพู่กัน (คำนวณครั้งเดียวตอนวางนิ้ว)
     * (cx,cy) = จุดนิ้วในพิกัดตาข่าย (พิกเซล bitmap) ใช้ตำแหน่งจุดที่ปั้นแล้ว ให้ตรงกับภาพที่เห็นบนจอ
     * pinR > 0 = ตรึงข้อต่อ: น้ำหนักค่อยๆ ลดเป็น 0 ที่จุดหมุน (pivotX,pivotY)
     */
    fun brushWeights(
        w: Int, h: Int, g: SculptGrid,
        cx: Float, cy: Float, radius: Float,
        pivotX: Float, pivotY: Float, pinR: Float,
    ): FloatArray {
        val out = FloatArray((g.cols + 1) * (g.rows + 1))
        var n = 0
        for (j in 0..g.rows) for (i in 0..g.cols) {
            val vx = i * w.toFloat() / g.cols + g.off[2 * n]
            val vy = j * h.toFloat() / g.rows + g.off[2 * n + 1]
            val k = 1f - (hypot(vx - cx, vy - cy) / radius).coerceAtMost(1f)
            var wt = k * k * (3f - 2f * k) // smoothstep: 1 กลางพู่กัน, 0 ที่ขอบ
            if (pinR > 0f) {
                val u = (hypot(vx - pivotX, vy - pivotY) / pinR).coerceAtMost(1f)
                wt *= u * u * (3f - 2f * u)
            }
            out[n++] = wt
        }
        return out
    }

    /** ระยะลากรวมสูงสุดต่อ 1 สโตรกที่ยังไม่ทำให้ตาข่ายพับ (ประมาณจากความชันสูงสุดของน้ำหนัก) */
    fun maxStep(radius: Float, pinR: Float): Float {
        val slope = 1.5f / radius + (if (pinR > 0f) 1.5f / pinR else 0f)
        return SAFETY / slope
    }

    /**
     * ดึงตาข่าย: start = ตาข่ายตอนวางนิ้ว, (dx,dy) = ระยะที่นิ้วลากรวมตั้งแต่วางนิ้ว (พิกเซล bitmap)
     * คำนวณจาก start ทุกครั้ง (ไม่สะสมทีละเฟรม) จึงไม่ลอยเพี้ยนและ 1 สโตรก = 1 ก้าว undo
     */
    fun applyGrab(start: SculptGrid, wts: FloatArray, dx: Float, dy: Float, maxStep: Float): SculptGrid {
        val m = hypot(dx, dy)
        val s = if (m > maxStep && m > 0f) maxStep / m else 1f
        val o = start.off.copyOf()
        for (v in wts.indices) {
            o[2 * v] += wts[v] * dx * s
            o[2 * v + 1] += wts[v] * dy * s
        }
        return SculptGrid(start.cols, start.rows, o)
    }

    /** ค่ากลางระหว่างสองท่า (null = ไม่ปั้น = ออฟเซ็ตศูนย์) */
    fun lerp(a: SculptGrid?, b: SculptGrid?, t: Float): SculptGrid? {
        if (a == null && b == null) return null
        if (a != null && b != null && (a.cols != b.cols || a.rows != b.rows)) return if (t < 0.5f) a else b
        val ref = (a ?: b)!!
        val ao = a?.off
        val bo = b?.off
        return SculptGrid(ref.cols, ref.rows, FloatArray(ref.off.size) { i ->
            val x = if (ao != null) ao[i] else 0f
            val y = if (bo != null) bo[i] else 0f
            x + (y - x) * t
        })
    }

    // ───────────── ขนาดช่องตาข่ายที่ตั้งเองได้ / Mesh Warp / Twist ─────────────

    /** ช่วงขนาดช่องตาข่าย (พิกเซลของ bitmap) ที่ให้ผู้ใช้ตั้งได้ */
    const val CELL_MIN = 16f
    const val CELL_MAX = 128f

    /** จำนวนช่องสูงสุดต่อด้านเมื่อผู้ใช้ตั้งขนาดช่องเอง (ไฟล์โปรเจกต์รับได้ไม่เกิน 64 ต่อด้าน) */
    private const val GRID_MAX = 40

    /** จำนวนช่องตามขนาดช่องที่ผู้ใช้ตั้ง (พิกเซลของ bitmap); cell = null = อัตโนมัติ ใช้ค่าเดิมของแอป (gridDims สองพารามิเตอร์) */
    fun gridDims(w: Int, h: Int, cell: Float?): Pair<Int, Int> {
        if (cell == null) return gridDims(w, h)
        val c = cell.coerceIn(CELL_MIN, CELL_MAX)
        return Pair(ceil(w / c).toInt().coerceIn(4, GRID_MAX), ceil(h / c).toInt().coerceIn(4, GRID_MAX))
    }

    /**
     * แปลงตารางเป็นจำนวนช่องใหม่ (สุ่มค่าออฟเซ็ตแบบ bilinear) ใช้ตอนเปลี่ยนความละเอียดตาข่ายของคลิปที่บิดไว้แล้ว
     * เป็นการประมาณ: รายละเอียดที่ละเอียดกว่าตารางเดิมไม่กลับมา และตารางที่ถี่ลงจะไม่ทำให้ท่าเดิมเปลี่ยนรูป
     */
    fun resample(g: SculptGrid, cols: Int, rows: Int): SculptGrid {
        if (g.cols == cols && g.rows == rows) return g
        val out = FloatArray((cols + 1) * (rows + 1) * 2)
        val ow = g.cols + 1
        var n = 0
        for (j in 0..rows) for (i in 0..cols) {
            val fx = i.toFloat() / cols * g.cols
            val fy = j.toFloat() / rows * g.rows
            val x0 = fx.toInt().coerceIn(0, g.cols - 1)
            val y0 = fy.toInt().coerceIn(0, g.rows - 1)
            val tx = fx - x0
            val ty = fy - y0
            for (k in 0..1) {
                val a = g.off[2 * (y0 * ow + x0) + k]
                val b = g.off[2 * (y0 * ow + x0 + 1) + k]
                val c = g.off[2 * ((y0 + 1) * ow + x0) + k]
                val d = g.off[2 * ((y0 + 1) * ow + x0 + 1) + k]
                out[2 * n + k] = (a * (1f - tx) + b * tx) * (1f - ty) + (c * (1f - tx) + d * tx) * ty
            }
            n++
        }
        return SculptGrid(cols, rows, out)
    }

    /** จุดตาข่ายที่ถูกเลือกโดย Mesh Warp: ตำแหน่งในตาราง (i, j) และระยะจากนิ้ว (พิกเซล bitmap) */
    class VertexHit(val i: Int, val j: Int, val dist: Float)

    /** จุดตาข่ายที่ใกล้ (px, py) ที่สุด (พิกัด bitmap ใช้ตำแหน่งของจุดที่บิดแล้ว ตรงกับที่เห็นบนจอ) */
    fun nearestVertex(w: Int, h: Int, g: SculptGrid, px: Float, py: Float): VertexHit {
        var bi = 0
        var bj = 0
        var bd = Float.MAX_VALUE
        var n = 0
        for (j in 0..g.rows) for (i in 0..g.cols) {
            val vx = i * w.toFloat() / g.cols + g.off[2 * n]
            val vy = j * h.toFloat() / g.rows + g.off[2 * n + 1]
            val d = hypot(vx - px, vy - py)
            if (d < bd) { bd = d; bi = i; bj = j }
            n++
        }
        return VertexHit(bi, bj, bd)
    }

    /** น้ำหนักแบบ Mesh Warp: จุด (vi, vj) = 1 แล้วลดลงตามระยะ (นับเป็นช่อง) จนเป็น 0 ที่ระยะ rings+1 ช่อง; rings = 0 ขยับจุดเดียว */
    fun ringWeights(g: SculptGrid, vi: Int, vj: Int, rings: Int): FloatArray {
        val out = FloatArray((g.cols + 1) * (g.rows + 1))
        var n = 0
        for (j in 0..g.rows) for (i in 0..g.cols) {
            val k = 1f - (hypot((i - vi).toFloat(), (j - vj).toFloat()) / (rings + 1)).coerceAtMost(1f)
            out[n++] = k * k * (3f - 2f * k)
        }
        return out
    }

    /**
     * ระยะลากรวมสูงสุดต่อ 1 สโตรกของ Mesh Warp ที่ตาข่ายยังไม่พับ
     * ทดสอบด้วยสคริปต์จำลอง: ไม่พับจนถึงราว 0.575 x (rings+1) x ขนาดช่องเล็กสุด (ช่องจัตุรัส/ไม่จัตุรัส rings 0–6) ใช้ 0.4 เผื่อไว้
     */
    fun maxStepRings(cellMin: Float, rings: Int): Float = 0.4f * (rings + 1) * cellMin

    /**
     * มุมบิด Twist สูงสุด (เรเดียน) ที่ตาข่ายยังไม่พับ ตามรัศมีและขนาดช่องใหญ่สุด
     * ทดสอบด้วยสคริปต์จำลอง (รัศมี/ช่อง = 2–48) มุมที่ไม่พับจริงมากกว่าค่านี้ทุกกรณี: ยิ่งรัศมีใหญ่/ช่องถี่ ยิ่งบิดได้มาก
     */
    fun maxTwist(radius: Float, cellMax: Float): Float {
        val rc = (radius / cellMax).coerceAtLeast(1f)
        return rc.pow(0.37f)
    }

    /**
     * Twist: หมุนจุดตาข่ายรอบ (cx, cy) ด้วยมุม angle (เรเดียน, บวก = ตามเข็มบนจอ) ที่กลางพู่กัน ลดเป็น 0 ที่ขอบรัศมี
     * คำนวณจาก start ทุกครั้ง (ไม่สะสม) เหมือน applyGrab
     */
    fun applyTwist(w: Int, h: Int, start: SculptGrid, cx: Float, cy: Float, radius: Float, angle: Float): SculptGrid {
        val o = start.off.copyOf()
        var n = 0
        for (j in 0..start.rows) for (i in 0..start.cols) {
            val vx = i * w.toFloat() / start.cols + start.off[2 * n]
            val vy = j * h.toFloat() / start.rows + start.off[2 * n + 1]
            val dx = vx - cx
            val dy = vy - cy
            val k = 1f - (hypot(dx, dy) / radius).coerceAtMost(1f)
            val a = angle * (k * k * (3f - 2f * k))
            if (a != 0f) {
                val c = cos(a)
                val s = sin(a)
                o[2 * n] += cx + dx * c - dy * s - vx
                o[2 * n + 1] += cy + dx * s + dy * c - vy
            }
            n++
        }
        return SculptGrid(start.cols, start.rows, o)
    }
}
