package com.nop.cartoonstudio

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Typeface
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectDragGesturesAfterLongPress
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.snapshots.SnapshotStateList
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.zIndex
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.roundToInt

object ImageStudioPrefs {
    private const val FILE = "image_studio_settings"
    private const val ENABLED = "enabled"
    private const val ASK = "ask_before_start"
    fun enabled(context: Context) = context.getSharedPreferences(FILE, Context.MODE_PRIVATE).getBoolean(ENABLED, true)
    fun setEnabled(context: Context, value: Boolean) { context.getSharedPreferences(FILE, Context.MODE_PRIVATE).edit().putBoolean(ENABLED, value).apply() }
    fun ask(context: Context) = context.getSharedPreferences(FILE, Context.MODE_PRIVATE).getBoolean(ASK, true)
    fun setAsk(context: Context, value: Boolean) { context.getSharedPreferences(FILE, Context.MODE_PRIVATE).edit().putBoolean(ASK, value).apply() }
}

// ───────────────────────── ค่าคงที่และสี ─────────────────────────

/** ความยาว Timeline สูงสุด = 100 วินาที (ตรงกับขีดจำกัด 3000 เฟรมของการส่งออก MP4 ที่ 30 fps) */
private const val MAX_TIMELINE_SEC = 1_000_000f // ไม่จำกัดตามจริง (ค่ากันตัวเลขล้นเท่านั้น ≈ 11 วัน)
private const val MAX_TIMELINE_PX = 150_000f // ความกว้าง Timeline สูงสุดที่ Compose วาดได้อย่างปลอดภัย (เกินนี้แอปล้ม): ยาวกว่านี้ระบบลดซูมให้เอง
private const val MIN_CLIP_SEC = 0.5f
private const val OUT_SIZE = 720
private const val OVERLAY_ID = 900001

/** เครื่องมือในโหมดบิดภาพ: ดึงด้วยพู่กัน · Mesh Warp (ลากจุดตาข่ายทีละจุด) · Twist (บิดวนรอบจุด) · PIN (หมุดข้อต่ออัจฉริยะ: งอข้อต่อด้วยมุม ตาข่ายถี่ตามจุด) */
private enum class SculptTool { GRAB, MESH, TWIST, PIN }

private object StudioColors {
    val Bg = Color(0xFF0B0E13)
    val Panel = Color(0xFF151A22)
    val Panel2 = Color(0xFF1E2530)
    val Line = Color(0xFF2B3442)
    val Ink = Color(0xFFEAF0F8)
    val Sub = Color(0xFF8E9BB0)
    val Accent = Color(0xFF5CC8FF)
    val AccentDim = Color(0xFF1D3A52)
    val Ok = Color(0xFF5AD6A0)
    val Warn = Color(0xFFFFB86B)
    val Danger = Color(0xFFFF6B7A)
    val PlayRed = Color(0xFFFF5C7A)
    val LaneBg = Color(0xFF10151C)
    val LaneActive = Color(0xFF14202C)
    val LaneTints = listOf(
        Color(0xFF5CC8FF), Color(0xFF9D8CFF), Color(0xFF5AD6A0), Color(0xFFFFB86B),
        Color(0xFFFF7FA8), Color(0xFFB5E86B),
    )
}

private fun laneTint(laneId: Int): Color = StudioColors.LaneTints[abs(laneId - 1) % StudioColors.LaneTints.size]

// ───────────────────────── โมเดลข้อมูลในหน้าแก้ไข ─────────────────────────

private data class StudioKeyframe(
    val time: Float, val x: Float, val y: Float, val scale: Float, val rotation: Float, val opacity: Float,
    val sculpt: SculptGrid? = null, // ท่าบิดภาพ (ตาข่าย) ณ จุดนี้ null = ไม่บิด
)

/**
 * คลิปภาพหนึ่งคลิปบน Timeline
 * x, y = ตำแหน่งในหน่วย "โลก" (ด้านสั้นของเฟรม = 600 หน่วย) ใช้หน่วยเดียวกับตัวส่งออกวิดีโอ จึงเห็นอย่างไรก็ได้อย่างนั้น
 * layerId = แทร็ก (เลขมาก = อยู่บนสุด)
 */
private data class StudioImage(
    val id: Int, val file: File, val bitmap: Bitmap, val duration: Float = 3f,
    val x: Float = 0f, val y: Float = 0f, val scale: Float = 1f,
    val rotation: Float = 0f, val opacity: Float = 1f, val visible: Boolean = true,
    val startTime: Float = 0f, val keyframes: List<StudioKeyframe> = emptyList(),
    val name: String = "", val locked: Boolean = false, val layerId: Int = 1,
    val sculpt: SculptGrid? = null, // ท่าบิดภาพของคลิปที่ไม่มี Keyframe (ใช้ตลอดคลิป)
    val sizeLocked: Boolean = false, // ล็อกขนาด: ย่อ/ขยายด้วยสองนิ้วไม่ได้ (เลื่อน/หมุนยังได้)
    val videoLength: Float = 0f, // > 0 = คลิปวิดีโอ: ความยาวไฟล์ต้นฉบับ (วินาที) · bitmap = ภาพปก (ขนาดเดียวกับทุกเฟรม)
    val videoOffset: Float = 0f, // จุดเริ่มเล่นในไฟล์วิดีโอ (วินาที) เปลี่ยนเมื่อตัดหัว/แบ่งคลิป
    val rig: PinRig = PinRig(), // หมุดข้อต่ออัจฉริยะของคลิป (มุมงอของแต่ละหมุดเก็บในท่าบิด sculpt ของแต่ละ Keyframe)
)

/** ภาพที่เลือกมาแล้วแต่ยังรอผ่านหน้าตัดภาพ (ตัดพื้นหลังให้โปร่งใส) ก่อนเข้าโปรเจกต์ */
private class PendingImport(val uri: android.net.Uri, val name: String, val bitmap: Bitmap)

private fun clipEnd(c: StudioImage) = c.startTime + c.duration
private fun isVideoClip(c: StudioImage) = c.videoLength > 0f
/** เวลาในไฟล์วิดีโอ (วินาที) ของคลิปวิดีโอ ณ เวลาบนไทม์ไลน์ t (ค้างเฟรมสุดท้ายถ้าเกินความยาวไฟล์) */
private fun videoLocalTime(c: StudioImage, t: Float) = (c.videoOffset + (t - c.startTime)).coerceIn(0f, maxOf(0f, c.videoLength - 0.05f))
private fun isActiveAt(c: StudioImage, t: Float) = c.visible && t >= c.startTime && t < c.startTime + c.duration
private fun clipLabel(c: StudioImage) = c.name.ifBlank { (if (isVideoClip(c)) "วิดีโอ " else "ภาพ ") + c.id }

/**
 * จำนวนช่องตาข่ายของคลิป: ถ้าคลิป/Keyframe ไหนมีท่าบิดอยู่แล้วใช้ขนาดเดียวกัน (ท่าที่ขนาดตารางต่างกันจะกระโดดแทนที่จะค่อย ๆ เปลี่ยน)
 * ถ้ายังไม่เคยบิด = ตามขนาดช่อง cell ที่ตั้ง (null = อัตโนมัติ ค่าเดิมของแอป)
 */
private fun clipGridDims(c: StudioImage, cell: Float?): Pair<Int, Int> {
    val g = c.sculpt ?: c.keyframes.firstNotNullOfOrNull { it.sculpt }
    return if (g != null) Pair(g.cols, g.rows) else Sculpt.gridDims(c.bitmap.width, c.bitmap.height, cell)
}

/** ตาข่ายที่ใช้วาดและส่งออกจริง: ท่าบิดของคลิป + การงอตามมุมของหมุดข้อต่อ (ไม่มีหมุด = ท่าเดิม) ใช้เหมือนกันทั้งหน้าจอและตอนส่งออก */
private fun renderGrid(c: StudioImage, g: SculptGrid?): SculptGrid? = JointPins.effective(c.rig, c.bitmap.width, c.bitmap.height, g)

/** ท่านี้มีหมุดข้อต่อที่งออยู่ไหม (งออยู่ = ตำแหน่งที่เห็นไม่ตรงกับตาข่ายตั้งต้น ปั้นด้วยมือ/วางหมุดใหม่ตอนนั้นไม่ได้) */
private fun hasPinAngle(g: SculptGrid?): Boolean = g?.pinAngles?.any { it != 0f } == true

/** ลำดับการซ้อน: แทร็กสูงอยู่บน; แทร็กเดียวกันคลิปที่เริ่มทีหลังอยู่บน (ใช้เหมือนกันทั้งหน้าจอและตอนส่งออก) */
private fun stackOrder(list: List<StudioImage>): List<StudioImage> =
    list.sortedWith(compareBy<StudioImage>({ it.layerId }, { it.startTime }))

private fun f1(v: Float): String = String.format(java.util.Locale.US, "%.1f", v)

private fun fmtClock(t: Float): String {
    val tenths = (t.coerceAtLeast(0f) * 10f).roundToInt()
    return String.format(java.util.Locale.US, "%d:%02d.%d", tenths / 600, (tenths / 10) % 60, tenths % 10)
}

private fun safeCoerce(v: Float, lo: Float, hi: Float): Float = if (hi < lo) lo else v.coerceIn(lo, hi)

/** ขนาด "พอดีเฟรม" ของภาพ (หน่วยโลกต่อพิกเซลของภาพ) ใช้เหมือนกันทั้ง Canvas และตอนส่งออก */
private fun fitScale(bw: Int, bh: Int): Float =
    minOf(Exporter.WORLD_WINDOW / bw.coerceAtLeast(1), Exporter.WORLD_WINDOW / bh.coerceAtLeast(1))

private fun laneIsFree(images: List<StudioImage>, laneId: Int, start: Float, dur: Float, ignoreId: Int): Boolean =
    images.none { it.id != ignoreId && it.layerId == laneId && start < clipEnd(it) - 0.001f && start + dur > it.startTime + 0.001f }

private fun studioPoseAt(image: StudioImage, absoluteTime: Float): StudioKeyframe {
    val local = (absoluteTime - image.startTime).coerceIn(0f, image.duration)
    val points = image.keyframes.sortedBy { it.time }
    if (points.isEmpty()) return StudioKeyframe(local, image.x, image.y, image.scale, image.rotation, image.opacity, image.sculpt)
    if (local <= points.first().time) return points.first()
    if (local >= points.last().time) return points.last()
    val rightIndex = points.indexOfFirst { it.time >= local }
    val a = points[rightIndex - 1]; val b = points[rightIndex]
    val span = (b.time - a.time).coerceAtLeast(0.0001f)
    val f = ((local - a.time) / span).coerceIn(0f, 1f)
    fun mix(x: Float, y: Float) = x + (y - x) * f
    return StudioKeyframe(local, mix(a.x, b.x), mix(a.y, b.y), mix(a.scale, b.scale), mix(a.rotation, b.rotation), mix(a.opacity, b.opacity), Sculpt.lerp(a.sculpt, b.sculpt, f))
}

/** แตะที่พิกัดโลก (wx, wy) โดนภาพนี้ไหม (คิดตามตำแหน่ง/ขนาด/มุมหมุน ณ เวลาปัจจุบัน) */
private fun hitsClip(c: StudioImage, pose: StudioKeyframe, wx: Float, wy: Float): Boolean {
    val fit = fitScale(c.bitmap.width, c.bitmap.height)
    val hw = c.bitmap.width * fit / 2f
    val hh = c.bitmap.height * fit / 2f
    val rad = Math.toRadians(pose.rotation.toDouble())
    val cs = kotlin.math.cos(rad).toFloat()
    val sn = kotlin.math.sin(rad).toFloat()
    val qx = wx - pose.x
    val qy = wy - pose.y
    val sc = pose.scale.coerceAtLeast(0.05f)
    val ux = (qx * cs + qy * sn) / sc
    val uy = (-qx * sn + qy * cs) / sc
    return abs(ux) <= hw && abs(uy) <= hh
}

/** พิกัดโลก (wx, wy) -> พิกัดพิกเซลของ bitmap ของคลิป (ตามตำแหน่ง/ขนาด/มุมหมุน ณ ท่านี้) ใช้กับพู่กันบิดภาพ */
private fun worldToBitmap(c: StudioImage, pose: StudioKeyframe, wx: Float, wy: Float): Pair<Float, Float> {
    val fit = fitScale(c.bitmap.width, c.bitmap.height)
    val rad = Math.toRadians(pose.rotation.toDouble())
    val cs = kotlin.math.cos(rad).toFloat()
    val sn = kotlin.math.sin(rad).toFloat()
    val qx = wx - pose.x
    val qy = wy - pose.y
    val sc = pose.scale.coerceAtLeast(0.05f)
    val ux = (qx * cs + qy * sn) / sc
    val uy = (-qx * sn + qy * cs) / sc
    return Pair(ux / fit + c.bitmap.width / 2f, uy / fit + c.bitmap.height / 2f)
}

private fun presetKeyframes(duration: Float, preset: String): List<StudioKeyframe> {
    val pan = preset != "หมุนเบาๆ"
    val rot = preset != "เลื่อนภาพ"
    return listOf(
        StudioKeyframe(0f, if (pan) -40f else 0f, 0f, 1.08f, if (rot) -3f else 0f, 1f),
        StudioKeyframe(duration, if (pan) 40f else 0f, 0f, 1.08f, if (rot) 3f else 0f, 1f),
    )
}

// ───────────────────────── หน้ารายการโปรเจกต์ ─────────────────────────

@Composable
fun ImageStudioScreen(onBack: () -> Unit) {
    val context = LocalContext.current
    val projects = remember { mutableStateListOf<ImageStudioProject>() }
    var activeProjectId by remember { mutableStateOf<String?>(null) }
    var showCreate by remember { mutableStateOf(false) }
    var newName by remember { mutableStateOf("โปรเจกต์รูปภาพ") }
    var message by remember { mutableStateOf<String?>(null) }

    fun refreshProjects() {
        projects.clear()
        projects.addAll(ImageStudioProjectStore.list(context))
    }
    LaunchedEffect(Unit) { refreshProjects() }

    val activeId = activeProjectId
    if (activeId != null) {
        ImageStudioEditorScreen(projectId = activeId, onBack = { activeProjectId = null; refreshProjects() })
        return
    }

    val c = StudioColors
    Column(Modifier.fillMaxSize().background(c.Bg).systemBarsPadding().padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            ToolChip("‹ กลับ", onClick = onBack)
            Spacer(Modifier.width(10.dp))
            Text("Image Studio", color = c.Ink, fontSize = 20.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
        }
        Text("โปรเจกต์รูปภาพ", color = c.Ink, fontSize = 26.sp, fontWeight = FontWeight.Bold)
        Text("เปิดงานล่าสุดหรือสร้างโปรเจกต์ใหม่เพื่อเริ่มตัดต่อภาพและวิดีโอ", color = c.Sub, fontSize = 13.sp)
        Button(
            onClick = { newName = "โปรเจกต์รูปภาพ"; showCreate = true },
            modifier = Modifier.fillMaxWidth().height(50.dp),
            shape = RoundedCornerShape(14.dp),
            colors = ButtonDefaults.buttonColors(containerColor = c.Accent, contentColor = Color(0xFF06141F)),
        ) { Text("＋ สร้างโปรเจกต์ใหม่", fontWeight = FontWeight.Bold) }
        if (projects.isEmpty()) {
            Box(Modifier.weight(1f).fillMaxWidth(), contentAlignment = Alignment.Center) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text("🎞", fontSize = 44.sp)
                    Spacer(Modifier.height(8.dp))
                    Text("ยังไม่มีโปรเจกต์\nกดสร้างโปรเจกต์ใหม่เพื่อเริ่มต้น", color = c.Sub, fontSize = 14.sp)
                }
            }
        } else {
            Text("โปรเจกต์ล่าสุด", color = c.Ink, fontSize = 16.sp, fontWeight = FontWeight.SemiBold)
            LazyColumn(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                items(projects, key = { it.id }) { project ->
                    Row(
                        Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp)).background(c.Panel).padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp),
                    ) {
                        Column(Modifier.weight(1f)) {
                            Text(project.name, color = c.Ink, fontSize = 16.sp, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                            Text("${project.imageCount} ภาพ · แก้ไข ${java.text.DateFormat.getDateTimeInstance().format(java.util.Date(project.updatedAt))}", color = c.Sub, fontSize = 12.sp)
                        }
                        ToolChip("เปิด", onClick = { activeProjectId = project.id }, highlight = true)
                        ToolChip("ลบ", onClick = { ImageStudioProjectStore.delete(context, project.id); refreshProjects() }, danger = true)
                    }
                }
            }
        }
        message?.let { Text(it, color = c.Danger) }
    }
    if (showCreate) {
        AlertDialog(
            onDismissRequest = { showCreate = false },
            containerColor = c.Panel, titleContentColor = c.Ink, textContentColor = c.Ink,
            title = { Text("สร้างโปรเจกต์ใหม่") },
            text = { OutlinedTextField(value = newName, onValueChange = { newName = it }, label = { Text("ชื่อโปรเจกต์") }, singleLine = true, colors = studioFieldColors()) },
            confirmButton = { TextButton(onClick = {
                runCatching { ImageStudioProjectStore.create(context, newName) }
                    .onSuccess { project -> refreshProjects(); showCreate = false; activeProjectId = project.id }
                    .onFailure { message = "สร้างโปรเจกต์ไม่สำเร็จ: ${it.message}" }
            }) { Text("สร้าง", color = c.Accent) } },
            dismissButton = { TextButton(onClick = { showCreate = false }) { Text("ยกเลิก", color = c.Sub) } },
        )
    }
}

@Composable
private fun studioFieldColors() = OutlinedTextFieldDefaults.colors(
    focusedTextColor = StudioColors.Ink, unfocusedTextColor = StudioColors.Ink,
    focusedBorderColor = StudioColors.Accent, unfocusedBorderColor = StudioColors.Line,
    focusedLabelColor = StudioColors.Accent, unfocusedLabelColor = StudioColors.Sub,
    cursorColor = StudioColors.Accent,
)

@Composable
private fun ToolChip(
    label: String, onClick: () -> Unit, enabled: Boolean = true, highlight: Boolean = false, danger: Boolean = false,
) {
    val c = StudioColors
    val bg = when { !enabled -> c.Panel2.copy(alpha = 0.5f); highlight -> c.Accent; else -> c.Panel2 }
    val fg = when { !enabled -> c.Sub.copy(alpha = 0.5f); highlight -> Color(0xFF06141F); danger -> c.Danger; else -> c.Ink }
    Box(
        Modifier.clip(RoundedCornerShape(50)).background(bg).clickable(enabled = enabled, onClick = onClick).padding(horizontal = 12.dp, vertical = 8.dp),
        contentAlignment = Alignment.Center,
    ) { Text(label, color = fg, fontSize = 13.sp, maxLines = 1, fontWeight = if (highlight) FontWeight.Bold else FontWeight.Normal) }
}

// ───────────────────────── หน้าแก้ไข ─────────────────────────

@Composable
private fun ImageStudioEditorScreen(projectId: String, onBack: () -> Unit) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val c = StudioColors
    val images = remember { mutableStateListOf<StudioImage>() }
    val layerIds = remember { mutableStateListOf<Int>() }
    var selectedId by remember { mutableIntStateOf(-1) }
    var activeLayerId by remember { mutableIntStateOf(1) }
    var playhead by remember { mutableFloatStateOf(0f) }
    var animationMode by remember { mutableStateOf(false) }
    var motionPreset by remember { mutableStateOf("เลื่อนภาพ") }
    var busy by remember { mutableStateOf(false) }
    var exportProgress by remember { mutableFloatStateOf(0f) }
    var previewPlaying by remember { mutableStateOf(false) }
    var status by remember { mutableStateOf<String?>(null) }
    var loadingProject by remember { mutableStateOf(true) }
    var projectLoaded by remember { mutableStateOf(false) }
    var timelineZoom by remember { mutableFloatStateOf(1f) }
    var showProps by remember { mutableStateOf(false) }
    var showExtras by remember { mutableStateOf(false) }
    var showClearConfirm by remember { mutableStateOf(false) }
    var sculptMode by remember { mutableStateOf(false) }
    val pendingImports = remember { mutableStateListOf<PendingImport>() }
    var editClipId by remember { mutableIntStateOf(-1) }
    var lastAssignedId by remember { mutableIntStateOf(0) }
    var brushFrac by remember { mutableFloatStateOf(0.25f) } // รัศมีพู่กัน = สัดส่วนของด้านยาวของภาพ
    var sculptTool by remember { mutableStateOf(SculptTool.GRAB) }
    var selectedPinId by remember { mutableIntStateOf(0) } // หมุดข้อต่อที่เลือกอยู่ (0 = ยังไม่เลือก) ใช้กับเครื่องมือ PIN
    var pinPlacing by remember { mutableStateOf(false) } // กำลังรอแตะบนภาพเพื่อวางหมุดใหม่
    var pinShowMesh by remember { mutableStateOf(true) } // แสดงเส้นตาข่ายตอนใช้เครื่องมือหมุด
    var meshRings by remember { mutableIntStateOf(1) } // Mesh Warp: จำนวนวงจุดข้างเคียงที่ถูกดึงตาม (0 = จุดเดียว)
    var twistDeg by remember { mutableFloatStateOf(90f) } // Twist: มุมสูงสุดที่ลากไกล 1 รัศมี (องศา)
    var meshCell by remember { mutableStateOf<Float?>(null) } // ขนาดช่องตาข่าย (px ของ bitmap) null = อัตโนมัติ (ไม่บันทึกลงโปรเจกต์ ท่าที่บิดแล้วเก็บขนาดตารางของตัวเอง)
    var videoW by remember { mutableIntStateOf(OUT_SIZE) } // ขนาดวิดีโอที่ส่งออก (px) ตั้งที่ปุ่ม "แก้ไข" บันทึกในโปรเจกต์
    var videoH by remember { mutableIntStateOf(OUT_SIZE) }
    var showVideoSize by remember { mutableStateOf(false) }
    var videoFps by remember { mutableIntStateOf(30) } // เฟรมต่อวินาทีของ MP4 ที่ส่งออก (1–60) ตั้งที่ปุ่ม fps ข้างปุ่มส่งออก บันทึกในโปรเจกต์
    var showFpsDialog by remember { mutableStateOf(false) }
    var busyImport by remember { mutableStateOf(false) } // กำลังคัดลอกวิดีโอเข้ามา/ดึงเสียง

    var overlayText by remember { mutableStateOf("") }
    var overlaySticker by remember { mutableStateOf("") }
    var overlayStart by remember { mutableFloatStateOf(0f) }
    var overlayDuration by remember { mutableFloatStateOf(5f) }
    var audioFile by remember { mutableStateOf<File?>(null) }
    var audioStart by remember { mutableFloatStateOf(0f) }
    var audioVolume by remember { mutableFloatStateOf(1f) }

    val timelineEnd = (images.maxOfOrNull { clipEnd(it) } ?: 1f).coerceAtLeast(1f)
    val current = images.firstOrNull { it.id == selectedId }

    // ── ตัวช่วยแก้คลิป ──
    fun indexOfClip(id: Int) = images.indexOfFirst { it.id == id }
    fun selectClip(id: Int) {
        val i = indexOfClip(id)
        if (i >= 0) { selectedId = id; activeLayerId = images[i].layerId } else selectedId = -1
    }
    fun updateClip(id: Int, block: (StudioImage) -> StudioImage) {
        val i = indexOfClip(id)
        if (i >= 0) images[i] = block(images[i])
    }
    fun newTopLane(): Int {
        val id = (layerIds.maxOrNull() ?: 0) + 1
        val all = (layerIds + id).sorted()
        layerIds.clear(); layerIds.addAll(all)
        return id
    }
    fun placeNewClip(duration: Float): Triple<Int, Float, Float> {
        val lane = if (activeLayerId in layerIds) activeLayerId else (layerIds.lastOrNull() ?: 1)
        val start = images.filter { it.layerId == lane }.maxOfOrNull { clipEnd(it) } ?: 0f
        return if (start + MIN_CLIP_SEC <= MAX_TIMELINE_SEC) Triple(lane, start, minOf(duration, MAX_TIMELINE_SEC - start))
        else Triple(newTopLane(), 0f, duration)
    }

    fun saveNow() {
        if (!projectLoaded) return
        runCatching {
            ImageStudioProjectStore.save(
                context, projectId,
                images.map { ImageStudioImageRecord(it.id, it.file.name, it.duration, it.x, it.y, it.scale, it.rotation, it.opacity, it.visible, it.startTime, it.keyframes.map { k -> ImageStudioKeyframeRecord(k.time, k.x, k.y, k.scale, k.rotation, k.opacity, k.sculpt) }, it.name, it.locked, it.layerId, it.sculpt, it.sizeLocked, it.videoLength, it.videoOffset, it.rig) },
                animationMode, motionPreset, layerIds.toList(), videoW, videoH, videoFps,
            )
        }.onFailure { status = "บันทึกอัตโนมัติไม่สำเร็จ: ${it.message}" }
    }
    fun leave() {
        if (busy) return
        previewPlaying = false
        saveNow()
        onBack()
    }
    BackHandler { leave() }

    fun transformClip(id: Int, dx: Float, dy: Float, zoom: Float, rot: Float) {
        val i = indexOfClip(id)
        if (i < 0) return
        val item = images[i]
        if (item.locked || !isActiveAt(item, playhead)) return
        val pose = studioPoseAt(item, playhead)
        val nx = (pose.x + dx).coerceIn(-1500f, 1500f)
        val ny = (pose.y + dy).coerceIn(-1500f, 1500f)
        val ns = if (item.sizeLocked) pose.scale else (pose.scale * zoom).coerceIn(0.1f, 8f)
        val nr = pose.rotation + rot
        if (item.keyframes.isEmpty()) {
            images[i] = item.copy(x = nx, y = ny, scale = ns, rotation = nr)
        } else {
            val t = (playhead - item.startTime).coerceIn(0f, item.duration)
            val key = StudioKeyframe(t, nx, ny, ns, nr, pose.opacity, pose.sculpt)
            images[i] = item.copy(keyframes = (item.keyframes.filterNot { abs(it.time - t) < 0.03f } + key).sortedBy { it.time })
        }
    }

    /** บันทึกท่าบิดภาพ: ไม่มี Keyframe = บิดทั้งคลิป · มี Keyframe = บันทึกที่จุดเวลาปัจจุบัน (สร้างจุดใหม่ถ้ายังไม่มี) */
    fun sculptClip(id: Int, grid: SculptGrid?) {
        val i = indexOfClip(id)
        if (i < 0) return
        val item = images[i]
        if (item.locked || !isActiveAt(item, playhead)) return
        if (item.keyframes.isEmpty()) { images[i] = item.copy(sculpt = grid); return }
        val pose = studioPoseAt(item, playhead)
        val t = (playhead - item.startTime).coerceIn(0f, item.duration)
        val key = StudioKeyframe(t, pose.x, pose.y, pose.scale, pose.rotation, pose.opacity, grid)
        images[i] = item.copy(keyframes = (item.keyframes.filterNot { abs(it.time - t) < 0.03f } + key).sortedBy { it.time })
    }

    /** เปลี่ยนความละเอียดตาข่ายของคลิปตามขนาดช่องที่ตั้ง: แปลงท่าบิดทั้งคลิปและทุก Keyframe เป็นจำนวนช่องใหม่ (ทุกท่าขนาดตรงกัน) */
    fun regridClip(id: Int) {
        val i = indexOfClip(id)
        if (i < 0) return
        val item = images[i]
        if (item.locked) return
        val (dc, dr) = Sculpt.gridDims(item.bitmap.width, item.bitmap.height, meshCell)
        fun rg(g: SculptGrid?): SculptGrid? = JointPins.relayout(item.rig, item.bitmap.width, item.bitmap.height, g, dc, dr) // ตาข่ายถี่ตามหมุดคงอยู่หลังเปลี่ยนความละเอียด
        images[i] = item.copy(sculpt = rg(item.sculpt), keyframes = item.keyframes.map { k -> k.copy(sculpt = rg(k.sculpt)) })
        status = "ปรับตาข่ายเป็น $dc×$dr ช่องแล้ว"
    }

    // ── หมุดข้อต่ออัจฉริยะ (Adaptive Mesh Smart Joint Pin) ──
    /** บีบมุมงอของทุกหมุดในทุกท่าให้อยู่ในช่วงที่ตาข่ายไม่พับ (เรียกหลังเปลี่ยนความนุ่ม/ช่วงมุม) */
    fun clampPinAngles(item: StudioImage): StudioImage {
        fun cg(g: SculptGrid?): SculptGrid? {
            val src = g ?: return null
            val pa = src.pinAngles ?: return src
            var changed = false
            val a = FloatArray(pa.size) { k ->
                val pin = item.rig.pins.getOrNull(k)
                val v = pa[k]
                val nv = if (pin == null) v else JointPins.clampAngle(pin, v)
                if (nv != v) changed = true
                nv
            }
            return if (changed) SculptGrid(src.cols, src.rows, src.off, src.xs, src.ys, a) else src
        }
        return item.copy(sculpt = cg(item.sculpt), keyframes = item.keyframes.map { it.copy(sculpt = cg(it.sculpt)) })
    }

    /** แปลงท่าทั้งหมดของคลิปให้เข้ากับรูปแบบตาข่ายถี่ตามหมุดตอนนี้ (ตำแหน่งเส้นตาข่ายตามหมุด จำนวนช่องเท่าเดิม) */
    fun relayoutItem(item: StudioImage): StudioImage {
        val (dc, dr) = clipGridDims(item, meshCell)
        val bw = item.bitmap.width
        val bh = item.bitmap.height
        fun rl(g: SculptGrid?): SculptGrid? = JointPins.relayout(item.rig, bw, bh, g, dc, dr)
        return item.copy(sculpt = rl(item.sculpt), keyframes = item.keyframes.map { k -> k.copy(sculpt = rl(k.sculpt)) })
    }

    fun updateRig(id: Int, relayout: Boolean, block: (PinRig) -> PinRig) {
        val i = indexOfClip(id)
        if (i < 0) return
        val item = images[i]
        if (item.locked) return
        var next = clampPinAngles(item.copy(rig = block(item.rig)))
        if (relayout) next = relayoutItem(next)
        images[i] = next
    }

    fun updatePin(id: Int, pinId: Int, relayout: Boolean, block: (JointPin) -> JointPin) {
        updateRig(id, relayout) { r -> r.copy(pins = r.pins.map { if (it.id == pinId) block(it) else it }) }
    }

    fun addPin(id: Int, x: Float, y: Float, dir: Float?) {
        val i = indexOfClip(id)
        if (i < 0) return
        val item = images[i]
        if (item.locked) return
        pinPlacing = false
        if (item.rig.pins.size >= JointPins.MAX_PINS) { status = "ใส่หมุดได้สูงสุด ${JointPins.MAX_PINS} ตัวต่อคลิป"; return }
        val bw = item.bitmap.width
        val bh = item.bitmap.height
        val pin = JointPins.newPin(item.rig, bw, bh, x.coerceIn(0f, bw.toFloat()), y.coerceIn(0f, bh.toFloat()), dir)
        updateRig(id, true) { it.copy(pins = it.pins + pin) }
        selectedPinId = pin.id
        status = "วางหมุดแล้ว · ลากปลายสีเขียวเพื่องอข้อต่อ · ลากจุดแดงเพื่อย้ายหมุด"
    }

    fun movePin(id: Int, pinId: Int, x: Float, y: Float, commit: Boolean) {
        val item = images.firstOrNull { it.id == id } ?: return
        val bw = item.bitmap.width.toFloat()
        val bh = item.bitmap.height.toFloat()
        updatePin(id, pinId, commit) { it.copy(x = x.coerceIn(0f, bw), y = y.coerceIn(0f, bh)) }
    }

    fun deletePin(id: Int, pinId: Int) {
        val i = indexOfClip(id)
        if (i < 0) return
        val item = images[i]
        if (item.locked) return
        val k = JointPins.indexOfId(item.rig.pins, pinId)
        if (k < 0) return
        val removed = item.copy(
            rig = JointPins.removePin(item.rig, k),
            sculpt = JointPins.dropAngle(item.sculpt, k),
            keyframes = item.keyframes.map { it.copy(sculpt = JointPins.dropAngle(it.sculpt, k)) },
        )
        images[i] = relayoutItem(removed)
        selectedPinId = 0
        status = "ลบหมุดแล้ว"
    }

    /** ตั้งมุมงอของหมุดลำดับ k ในท่า ณ เส้นแดง: มี Keyframe = บันทึกที่จุดเวลานี้ (เหมือนการบิดภาพ) ไม่มี = ใช้ทั้งคลิป */
    fun setPinAngle(id: Int, k: Int, deg: Float) {
        val i = indexOfClip(id)
        if (i < 0) return
        val item = images[i]
        if (item.locked || !isActiveAt(item, playhead)) return
        val pin = item.rig.pins.getOrNull(k) ?: return
        val pose = studioPoseAt(item, playhead)
        val (dc, dr) = clipGridDims(item, meshCell)
        sculptClip(id, JointPins.withAngle(item.rig, item.bitmap.width, item.bitmap.height, pose.sculpt, dc, dr, k, JointPins.clampAngle(pin, deg)))
    }

    fun resetPinAngles(id: Int) {
        val i = indexOfClip(id)
        if (i < 0) return
        val item = images[i]
        if (item.locked || !isActiveAt(item, playhead)) return
        val pose = studioPoseAt(item, playhead)
        if (hasPinAngle(pose.sculpt)) sculptClip(id, JointPins.clearAngles(pose.sculpt))
    }

    fun duplicateClip(id: Int) {
        val src = images.firstOrNull { it.id == id } ?: return
        if (images.size >= 30) { status = "เพิ่มได้สูงสุด 30 ภาพต่อหนึ่งงาน"; return }
        runCatching {
            val nextId = (images.maxOfOrNull { it.id } ?: 0) + 1
            val isVid = isVideoClip(src) // วิดีโอ: ใช้ไฟล์และภาพปกเดียวกัน (ไม่คัดลอกไฟล์ใหญ่ซ้ำ)
            val file = if (isVid) src.file else src.file.inputStream().use { ImageStudioProjectStore.importImage(context, projectId, nextId, "copy.${src.file.extension.ifBlank { "img" }}", it) }
            val bmp = if (isVid) src.bitmap else src.bitmap.copy(Bitmap.Config.ARGB_8888, false) ?: throw IllegalStateException("คัดลอกภาพไม่ได้")
            var lane = src.layerId
            var start = clipEnd(src)
            if (start + src.duration > MAX_TIMELINE_SEC || !laneIsFree(images, lane, start, src.duration, -1)) { lane = newTopLane(); start = src.startTime }
            images.add(src.copy(id = nextId, file = file, bitmap = bmp, startTime = start, layerId = lane, name = clipLabel(src) + " (สำเนา)"))
            selectClip(nextId)
            status = "ทำซ้ำคลิปแล้ว"
        }.onFailure { status = "ทำซ้ำไม่สำเร็จ: ${it.message}" }
    }

    fun splitClip(id: Int) {
        val i = indexOfClip(id)
        if (i < 0) return
        val src = images[i]
        val cut = playhead
        if (cut <= src.startTime + MIN_CLIP_SEC || cut >= clipEnd(src) - MIN_CLIP_SEC) { status = "เลื่อนเส้นเวลาไปกลางคลิปก่อนแบ่ง"; return }
        if (images.size >= 30) { status = "เพิ่มได้สูงสุด 30 ภาพต่อหนึ่งงาน"; return }
        runCatching {
            val nextId = (images.maxOfOrNull { it.id } ?: 0) + 1
            val isVid = isVideoClip(src)
            val file = if (isVid) src.file else src.file.inputStream().use { ImageStudioProjectStore.importImage(context, projectId, nextId, "part.${src.file.extension.ifBlank { "img" }}", it) }
            val bmp = if (isVid) src.bitmap else src.bitmap.copy(Bitmap.Config.ARGB_8888, false) ?: throw IllegalStateException("คัดลอกภาพไม่ได้")
            val d1 = cut - src.startTime
            val d2 = src.duration - d1
            val pose = studioPoseAt(src, cut)
            val hasKeys = src.keyframes.isNotEmpty()
            val keysA = if (hasKeys) src.keyframes.filter { it.time < d1 - 0.01f } + StudioKeyframe(d1, pose.x, pose.y, pose.scale, pose.rotation, pose.opacity, pose.sculpt) else emptyList()
            val keysB = if (hasKeys) listOf(StudioKeyframe(0f, pose.x, pose.y, pose.scale, pose.rotation, pose.opacity, pose.sculpt)) + src.keyframes.filter { it.time > d1 + 0.01f }.map { it.copy(time = it.time - d1) } else emptyList()
            images[i] = src.copy(duration = d1, keyframes = keysA)
            images.add(src.copy(id = nextId, file = file, bitmap = bmp, startTime = cut, duration = d2, keyframes = keysB, name = clipLabel(src) + " (ต่อ)",
                videoOffset = if (isVid) src.videoOffset + d1 else 0f)) // วิดีโอ: ท่อนหลังเล่นต่อจากจุดที่แบ่ง
            selectClip(nextId)
            status = "แบ่งคลิปที่ ${f1(cut)} วินาทีแล้ว"
        }.onFailure { status = "แบ่งคลิปไม่สำเร็จ: ${it.message}" }
    }

    fun deleteClip(id: Int) {
        val i = indexOfClip(id)
        if (i < 0) return
        images.removeAt(i)
        selectedId = images.getOrNull(i.coerceAtMost(images.lastIndex))?.id ?: -1
        status = "ลบคลิปแล้ว"
    }

    // ── เสียง / ข้อความ ──
    val audioPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) scope.launch {
            runCatching { withContext(Dispatchers.IO) { AudioStore.importFrom(context, uri) { } } }
                .onSuccess { imported -> audioFile = File(AudioStore.dir(context), imported.file); status = "เพิ่มแทร็กเสียงแล้ว" }
                .onFailure { status = "เพิ่มเสียงไม่สำเร็จ: ${it.message}" }
        }
    }
    LaunchedEffect(projectId) {
        val prefs = context.getSharedPreferences("image_studio_extra_$projectId", Context.MODE_PRIVATE)
        overlayText = prefs.getString("overlayText", "") ?: ""
        overlaySticker = prefs.getString("overlaySticker", "") ?: ""
        overlayStart = prefs.getFloat("overlayStart", 0f)
        overlayDuration = prefs.getFloat("overlayDuration", 5f)
        audioStart = prefs.getFloat("audioStart", 0f)
        audioVolume = prefs.getFloat("audioVolume", 1f)
        audioFile = prefs.getString("audioPath", null)?.let(::File)?.takeIf { it.isFile }
    }
    LaunchedEffect(overlayText, overlaySticker, overlayStart, overlayDuration, audioFile, audioStart, audioVolume) {
        context.getSharedPreferences("image_studio_extra_$projectId", Context.MODE_PRIVATE).edit()
            .putString("overlayText", overlayText).putString("overlaySticker", overlaySticker)
            .putFloat("overlayStart", overlayStart).putFloat("overlayDuration", overlayDuration)
            .putString("audioPath", audioFile?.absolutePath).putFloat("audioStart", audioStart)
            .putFloat("audioVolume", audioVolume).apply()
    }

    // ── โหลดโปรเจกต์ ──
    LaunchedEffect(projectId) {
        loadingProject = true
        runCatching { ImageStudioProjectStore.loadImages(context, projectId) }
            .onSuccess { loaded ->
                images.clear()
                loaded.forEach { (record, bitmap) ->
                    images.add(StudioImage(
                        record.id, File(context.filesDir, "image_studio/projects/$projectId/images/${record.fileName}"), bitmap,
                        record.duration, record.x, record.y, record.scale, record.rotation, record.opacity, record.visible, record.startTime,
                        record.keyframes.map { StudioKeyframe(it.time, it.x, it.y, it.scale, it.rotation, it.opacity, it.sculpt) },
                        record.name, record.locked, record.layerId, record.sculpt, record.sizeLocked,
                        videoLength = record.videoLength, videoOffset = record.videoOffset, rig = record.rig,
                    ))
                }
                selectedId = images.firstOrNull()?.id ?: -1
                activeLayerId = images.firstOrNull()?.layerId ?: 1
                val ids = (ImageStudioProjectStore.loadLayerIds(context, projectId) + loaded.map { it.first.layerId } + 1).distinct().sorted()
                layerIds.clear(); layerIds.addAll(ids)
                val settings = ImageStudioProjectStore.loadSettings(context, projectId)
                animationMode = settings.first
                motionPreset = settings.second
                val vs = ImageStudioProjectStore.loadVideoSize(context, projectId)
                videoW = vs.first; videoH = vs.second
                videoFps = ImageStudioProjectStore.loadVideoFps(context, projectId)
                projectLoaded = true
            }
            .onFailure { status = "เปิดโปรเจกต์ไม่สำเร็จ: ${it.message}"; projectLoaded = false }
        loadingProject = false
    }

    // ── บันทึกอัตโนมัติ ──
    val saveKey = images.joinToString("|") { "${it.id}:${it.duration}:${it.x}:${it.y}:${it.scale}:${it.rotation}:${it.opacity}:${it.visible}:${it.startTime}:${it.keyframes}:${it.name}:${it.locked}:${it.layerId}:${it.sculpt}:${it.sizeLocked}:${it.videoLength}:${it.videoOffset}:${it.rig}:${it.file.name}" }
    LaunchedEffect(saveKey, layerIds.toList(), animationMode, motionPreset, loadingProject, videoW, videoH, videoFps) {
        if (!loadingProject && projectLoaded) {
            delay(650)
            saveNow()
        }
    }

    // ── ข้อความสถานะหายเองหลัง 3.5 วินาที ──
    LaunchedEffect(status) {
        val shown = status
        if (shown != null) { delay(3500); if (status == shown) status = null }
    }

    // ── เล่นตัวอย่าง ──
    LaunchedEffect(previewPlaying) {
        if (!previewPlaying) return@LaunchedEffect
        var last = withFrameNanos { it }
        while (true) {
            val now = withFrameNanos { it }
            val dt = (now - last) / 1_000_000_000f
            last = now
            val end = images.maxOfOrNull { clipEnd(it) } ?: 0f
            if (end <= 0f) { previewPlaying = false; break }
            var next = playhead + dt
            if (next >= end) next = 0f
            playhead = next
        }
    }

    // ── เพิ่มภาพ: เลือกไฟล์ -> หน้าตัดภาพ (ตัดพื้นหลังให้โปร่งใส) -> เข้าโปรเจกต์ ──
    fun addClip(nextId: Int, file: File, bmp: Bitmap) {
        val (lane, start, dur) = placeNewClip(3f)
        if (lane !in layerIds) layerIds.add(lane)
        images.add(StudioImage(
            nextId, file, bmp, duration = dur, startTime = start, name = "ภาพ $nextId", layerId = lane,
            keyframes = if (animationMode) presetKeyframes(dur, motionPreset) else emptyList(),
        ))
        selectClip(nextId)
        playhead = start
    }

    fun finishImport(job: PendingImport, result: Bitmap) {
        if (pendingImports.isNotEmpty()) pendingImports.removeAt(0)
        val nextId = maxOf(images.maxOfOrNull { it.id } ?: 0, lastAssignedId) + 1
        lastAssignedId = nextId
        scope.launch {
            val r = withContext(Dispatchers.IO) {
                runCatching {
                    val file: File
                    val bmp: Bitmap
                    if (result === job.bitmap) {
                        // ไม่ได้แก้ภาพ: นำเข้าไฟล์ต้นฉบับเหมือนเดิม
                        val input = context.contentResolver.openInputStream(job.uri) ?: throw IllegalArgumentException("อ่านไฟล์ภาพไม่ได้")
                        file = ImageStudioProjectStore.importImage(context, projectId, nextId, job.name, input)
                        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
                        BitmapFactory.decodeFile(file.absolutePath, bounds)
                        if (bounds.outWidth <= 0 || bounds.outHeight <= 0) throw IllegalArgumentException("ไฟล์ภาพไม่ถูกต้อง")
                        var sample = 1
                        while (max(bounds.outWidth, bounds.outHeight) / sample > 1600) sample *= 2
                        val opts = BitmapFactory.Options().apply { inSampleSize = sample; inPreferredConfig = Bitmap.Config.ARGB_8888 }
                        bmp = BitmapFactory.decodeFile(file.absolutePath, opts) ?: throw IllegalArgumentException("อ่านไฟล์ภาพไม่ได้")
                    } else {
                        // ภาพที่ตัด/ลบแล้ว: ตัดขอบโปร่งใส ย่อถ้าใหญ่ แล้วเก็บเป็น PNG เพื่อคงความโปร่งใส
                        val cut = ImageImport.limitSize(ImageImport.trimTransparent(result), 1600)
                        val bytes = java.io.ByteArrayOutputStream().also { cut.compress(Bitmap.CompressFormat.PNG, 100, it) }.toByteArray()
                        file = ImageStudioProjectStore.importImage(context, projectId, nextId, "cutout.png", java.io.ByteArrayInputStream(bytes))
                        bmp = cut
                    }
                    Pair(file, bmp)
                }
            }
            r.onSuccess { (file, bmp) -> addClip(nextId, file, bmp) }
                .onFailure { status = "เปิดรูปภาพไม่สำเร็จ: ${it.message}" }
        }
    }

    /** แก้ไขภาพของคลิปที่มีอยู่: ผลที่ได้แทนที่ภาพเดิมบนผืนผ้าใบขนาดเดิม (ตำแหน่ง/ขนาด/การบิดของคลิปจึงไม่เปลี่ยน) เก็บเป็น PNG */
    fun finishEdit(clip: StudioImage, out: Bitmap, left: Int, top: Int) {
        editClipId = -1
        val w = clip.bitmap.width
        val h = clip.bitmap.height
        scope.launch {
            val r = withContext(Dispatchers.IO) {
                runCatching {
                    val full = if (out.width == w && out.height == h && left == 0 && top == 0) out
                    else Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888).also { Canvas(it).drawBitmap(out, left.toFloat(), top.toFloat(), null) }
                    val bytes = java.io.ByteArrayOutputStream().also { full.compress(Bitmap.CompressFormat.PNG, 100, it) }.toByteArray()
                    val file = ImageStudioProjectStore.importImage(context, projectId, clip.id, "edit.png", java.io.ByteArrayInputStream(bytes))
                    Pair(file, full)
                }
            }
            r.onSuccess { (file, full) ->
                updateClip(clip.id) { it.copy(file = file, bitmap = full) }
                status = "แก้ไขภาพแล้ว"
            }.onFailure { status = "บันทึกภาพที่แก้ไม่สำเร็จ: ${it.message}" }
        }
    }

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { uris ->
        scope.launch {
            uris.forEach { uri ->
                if (images.size + pendingImports.size >= 30) { status = "เพิ่มได้สูงสุด 30 ภาพต่อหนึ่งงาน"; return@forEach }
                val r = withContext(Dispatchers.IO) { runCatching { ImageImport.decode(context, uri) } }
                r.onSuccess { pendingImports.add(PendingImport(uri, uri.lastPathSegment ?: "image.png", it)) }
                    .onFailure { status = "เปิดรูปภาพไม่สำเร็จ: ${it.message}" }
            }
        }
    }

    // ── เพิ่มวิดีโอ: คัดลอกไฟล์เข้าโปรเจกต์ -> อ่านความยาว/ภาพปก -> วางเป็นคลิปบน Timeline ──
    val videoPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            if (images.size + pendingImports.size >= 30) { status = "เพิ่มได้สูงสุด 30 คลิปต่อหนึ่งงาน"; return@rememberLauncherForActivityResult }
            val nextId = maxOf(images.maxOfOrNull { it.id } ?: 0, lastAssignedId) + 1
            lastAssignedId = nextId
            busyImport = true
            status = "กำลังนำเข้าวิดีโอ…"
            scope.launch {
                val r = withContext(Dispatchers.IO) {
                    runCatching {
                        val input = context.contentResolver.openInputStream(uri) ?: throw IllegalArgumentException("อ่านไฟล์วิดีโอไม่ได้")
                        val file = ImageStudioProjectStore.importImage(context, projectId, nextId, "clip.mp4", input)
                        try {
                            val info = VideoFrames.probe(file)
                            Triple(file, info.poster, info.durationSec)
                        } catch (t: Throwable) { file.delete(); throw t }
                    }
                }
                busyImport = false
                r.onSuccess { (file, poster, len) ->
                    val (lane, start, dur) = placeNewClip(minOf(len, MAX_TIMELINE_SEC))
                    if (lane !in layerIds) layerIds.add(lane)
                    images.add(StudioImage(
                        nextId, file, poster, duration = dur, startTime = start, name = "วิดีโอ $nextId", layerId = lane,
                        videoLength = len,
                    ))
                    selectClip(nextId)
                    playhead = start
                    status = "เพิ่มวิดีโอแล้ว (${f1(len)} วินาที)"
                }.onFailure { status = "เพิ่มวิดีโอไม่สำเร็จ: ${it.message ?: it.javaClass.simpleName}" }
            }
        }
    }

    /** ดึงเสียงของคลิปวิดีโอมาเป็นแทร็กเสียงของงาน (แทนแทร็กเสียงเดิม ถ้ามี) เริ่มพร้อมภาพของคลิป */
    fun useVideoAudio(clip: StudioImage) {
        val st = clip.startTime - clip.videoOffset
        if (st < 0f) { status = "คลิปนี้ถูกตัดหัวไว้มากกว่าตำแหน่งบน Timeline จึงจัดเสียงให้ตรงภาพไม่ได้"; return }
        busyImport = true
        status = "กำลังดึงเสียงจากวิดีโอ…"
        scope.launch {
            runCatching { withContext(Dispatchers.IO) { AudioStore.importFrom(context, android.net.Uri.fromFile(clip.file)) { } } }
                .onSuccess { imported ->
                    audioFile = File(AudioStore.dir(context), imported.file)
                    audioStart = st
                    status = "ใช้เสียงของวิดีโอเป็นแทร็กเสียงแล้ว"
                }
                .onFailure { status = "ดึงเสียงไม่สำเร็จ: ${it.message ?: it.javaClass.simpleName}" }
            busyImport = false
        }
    }

    // ── ส่งออก MP4 ──
    fun startExport() {
        if (images.isEmpty() || busy) return
        previewPlaying = false
        busy = true; exportProgress = 0f; status = "กำลังเตรียมวิดีโอ..."
        val snapshot = images.toList()
        val exportOverlayText = overlayText
        val exportOverlaySticker = overlaySticker
        val exportOverlayStart = overlayStart
        val exportOverlayDuration = overlayDuration
        val exportAudio = audioFile
        val exportAudioStart = audioStart
        val exportAudioVolume = audioVolume
        val exportW = videoW
        val exportH = videoH
        val exportFps = videoFps
        scope.launch {
            val result = withContext(Dispatchers.IO) {
                runCatching {
                    val fps = exportFps // เฟรมต่อวินาทีที่ผู้ใช้ตั้ง (ค่าเริ่มต้น 30)
                    // ความยาววิดีโอ = ปลายคลิปที่อยู่ไกลที่สุดบน Timeline (ตรงกับที่เห็น)
                    val durationSec = snapshot.maxOf { clipEnd(it) }.coerceAtLeast(MIN_CLIP_SEC)
                    val frameCount = (durationSec * fps).roundToInt().coerceAtLeast(1)
                    Exporter.validateVideo(exportW, exportH, 1, frameCount, maxFrames = Long.MAX_VALUE)?.let { throw IllegalArgumentException(it) }
                    val ordered = stackOrder(snapshot) // ล่าง → บน (แทร็กสูงอยู่บน) เหมือนบนหน้าจอ
                    // ช่วงเฟรมที่คลิปแสดง: ใช้ตัวเลขเดียวกันทั้งตอนตั้ง Part และตอนสร้างท่าของแต่ละเฟรม
                    val ranges = HashMap<Int, IntRange>()
                    ordered.forEach { item ->
                        val a = (item.startTime * fps).roundToInt().coerceIn(0, frameCount - 1)
                        val b = (((item.startTime + item.duration) * fps).roundToInt() - 1).coerceIn(a, frameCount - 1)
                        ranges[item.id] = a..b
                    }
                    val parts = ordered.mapIndexed { index, item ->
                        val r = ranges.getValue(item.id)
                        Part(item.id, clipLabel(item), item.bitmap).apply {
                            pivotX = bitmap.width / 2f; pivotY = bitmap.height / 2f
                            scale = fitScale(bitmap.width, bitmap.height) // พอดีเฟรมเหมือนบน Canvas
                            visible = item.visible
                            characterId = item.id
                            characterName = "ภาพ ${index + 1}"
                            charAlpha = 1f
                            appearFrom = r.first
                            appearTo = r.last
                        }
                    }.toMutableList()

                    // คลิปวิดีโอ: ก่อนวาดแต่ละเฟรม สลับภาพของชิ้นส่วนเป็นเฟรมของเวลานั้น (ขนาดเท่าภาพปกเสมอ)
                    val videoJobs = ordered.mapIndexedNotNull { idx, item ->
                        if (isVideoClip(item)) Triple(item, parts[idx], VideoReader(item.file, item.videoLength)) else null
                    }
                    val frameHook: (Float) -> Unit = { pos ->
                        val t = pos / fps
                        for ((item, part, reader) in videoJobs) {
                            if (!item.visible) continue
                            val rg = ranges.getValue(item.id)
                            if (pos < rg.first - 0.001f || pos > rg.last + 0.001f) continue
                            val frame = runCatching { reader.frame(videoLocalTime(item, t), item.bitmap.width, item.bitmap.height, exact = true) }.getOrNull() ?: continue
                            val old = part.bitmap
                            part.bitmap = frame
                            if (old !== item.bitmap) old.recycle() // ภาพปกยังใช้บนจอ ห้าม recycle
                        }
                    }

                    val hasOverlay = exportOverlayText.isNotBlank() || exportOverlaySticker.isNotBlank()
                    val oa = (exportOverlayStart * fps).roundToInt().coerceIn(0, frameCount - 1)
                    val ob = (((exportOverlayStart + exportOverlayDuration) * fps).roundToInt() - 1).coerceIn(oa, frameCount - 1)
                    val overlayBitmap = if (hasOverlay) Bitmap.createBitmap(OUT_SIZE, OUT_SIZE, Bitmap.Config.ARGB_8888).also { bitmap ->
                        val canvas = Canvas(bitmap)
                        val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                            color = android.graphics.Color.WHITE; textSize = 46f
                            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
                            textAlign = Paint.Align.CENTER; setShadowLayer(4f, 2f, 2f, android.graphics.Color.BLACK)
                        }
                        while (paint.measureText(exportOverlayText) > OUT_SIZE - 60f && paint.textSize > 16f) paint.textSize -= 2f
                        val both = exportOverlaySticker.isNotBlank() && exportOverlayText.isNotBlank()
                        if (exportOverlaySticker.isNotBlank()) canvas.drawText(exportOverlaySticker, OUT_SIZE / 2f, if (both) 340f else 382f, paint)
                        if (exportOverlayText.isNotBlank()) canvas.drawText(exportOverlayText, OUT_SIZE / 2f, if (both) 410f else 382f, paint)
                    } else null
                    if (overlayBitmap != null) parts.add(Part(OVERLAY_ID, "ข้อความ/สติกเกอร์", overlayBitmap).apply {
                        scale = Exporter.WORLD_WINDOW / OUT_SIZE
                        appearFrom = oa; appearTo = ob
                    })

                    // สร้างท่าของแต่ละเฟรมตอนที่ตัวเข้ารหัสขอ (ไม่สร้างล่วงหน้าทั้งหมด: วิดีโอยาวหลายนาทีจะกินหน่วยความจำมาก)
                    val frames: List<Map<Int, Pose>> = object : AbstractList<Map<Int, Pose>>() {
                      override val size: Int get() = frameCount
                      override fun get(index: Int): Map<Int, Pose> {
                        val f = index
                        val t = f / fps.toFloat()
                        val map = HashMap<Int, Pose>()
                        ordered.forEach { item ->
                            if (item.visible && f in ranges.getValue(item.id)) {
                                val p = studioPoseAt(item, t)
                                map[item.id] = Pose(rotation = p.rotation, dx = p.x, dy = p.y, sculpt = renderGrid(item, p.sculpt), scale = p.scale, alpha = p.opacity)
                            }
                        }
                        if (overlayBitmap != null && f in oa..ob) map[OVERLAY_ID] = Pose()
                        return map
                      }
                    }
                    val outW = Exporter.videoSize(exportW) // ปัดเป็นพหุคูณของ 16 เหมือนที่กรอบบนผืนผ้าใบคำนวณ
                    val outH = Exporter.videoSize(exportH)
                    val tmp = File(context.cacheDir, "image_studio_${System.currentTimeMillis()}.mp4")
                    try {
                        Exporter.encodeVideo(parts, frames, outW, outH, fps.toFloat(), 1, android.graphics.Color.BLACK, tmp,
                            fpsAt = { fps.toFloat() }, loopN = frameCount,
                            onProgress = { done, total -> exportProgress = done.toFloat() / total.coerceAtLeast(1) },
                            frameHook = if (videoJobs.isEmpty()) null else frameHook, outFps = fps)
                    } finally {
                        videoJobs.forEach { it.third.close() }
                    }
                    var outputVideo = tmp
                    val sound = exportAudio
                    if (sound != null && sound.isFile && exportAudioVolume > 0f) {
                        val aac = AudioExport.encodeAac(listOf(AudioPlaySpec(sound, exportAudioStart, 0f, (durationSec - exportAudioStart).coerceAtLeast(0f), exportAudioVolume)), durationSec.toDouble(), 1) { }
                        val muxed = File(context.cacheDir, "image_studio_mux_${System.currentTimeMillis()}.mp4")
                        AudioExport.muxVideoAudio(tmp, aac, muxed)
                        outputVideo = muxed
                    }
                    val saved = Exporter.saveVideo(context, outputVideo, "image_video_${System.currentTimeMillis()}")
                    tmp.delete(); if (outputVideo != tmp) outputVideo.delete(); overlayBitmap?.recycle()
                    saved
                }
            }
            busy = false
            status = result.fold({ "บันทึกวิดีโอสำเร็จ: $it" }, { "สร้างวิดีโอไม่สำเร็จ: ${it.message ?: it.javaClass.simpleName}" })
        }
    }

    // ───────────── หน้าตัดภาพเต็มจอ: ใช้หน้าเดียวกับตอนสร้างตัวละคร (บ่วง / ดัดโค้ง / ยางลบ / จอย) ─────────────
    val importJob = pendingImports.firstOrNull()
    if (importJob != null) {
        key(importJob) {
            ImageCropScreen(
                bitmap = importJob.bitmap,
                onConfirm = { cropped, _, _ -> finishImport(importJob, cropped) },
                onCancel = { if (pendingImports.isNotEmpty()) pendingImports.removeAt(0) },
            )
        }
        return
    }
    val editTarget = images.firstOrNull { it.id == editClipId }
    if (editTarget != null) {
        key(editTarget.id) {
            ImageCropScreen(
                bitmap = editTarget.bitmap,
                onConfirm = { out, left, top -> finishEdit(editTarget, out, left, top) },
                onCancel = { editClipId = -1 },
                allowAddImage = true, // เพิ่มรูปซ้อนได้ (ไว้ลบแล้วเปลี่ยนส่วนที่ลบ) เหมือนหน้าแก้ไขภาพของตัวละคร
            )
        }
        return
    }

    // ───────────── หน้าจอ ─────────────
    Column(
        Modifier.fillMaxSize().background(c.Bg).systemBarsPadding().padding(horizontal = 10.dp, vertical = 8.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp),
    ) {
        // หัวเรื่อง
        Row(
            Modifier.fillMaxWidth().background(c.Panel, RoundedCornerShape(16.dp)).padding(horizontal = 6.dp, vertical = 4.dp),
            verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp),
        ) {
            Box(Modifier.size(38.dp).clip(CircleShape).clickable(enabled = !busy, onClick = { leave() }), contentAlignment = Alignment.Center) {
                Text("‹", color = c.Ink, fontSize = 26.sp)
            }
            Column(Modifier.weight(1f)) {
                Text("Image Studio", color = c.Ink, fontSize = 16.sp, fontWeight = FontWeight.Bold)
                Text(
                    if (loadingProject) "กำลังเปิดโปรเจกต์…" else "${images.size} คลิป · ${layerIds.size} แทร็ก · ${fmtClock(timelineEnd)}",
                    color = c.Sub, fontSize = 11.sp, maxLines = 1,
                )
            }
            Button(
                onClick = { showVideoSize = true },
                enabled = !busy && !loadingProject,
                shape = RoundedCornerShape(12.dp),
                contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp),
                colors = ButtonDefaults.buttonColors(containerColor = c.Panel2, contentColor = c.Ink, disabledContainerColor = c.Panel2, disabledContentColor = c.Sub),
            ) { Text("แก้ไข", fontWeight = FontWeight.Bold, fontSize = 13.sp) }
            Column( // ปุ่มตั้งค่าเฟรมต่อวินาที (fps) ข้างปุ่มส่งออก
                Modifier.clip(RoundedCornerShape(12.dp)).background(c.Panel2)
                    .border(1.dp, c.Line, RoundedCornerShape(12.dp))
                    .clickable(enabled = !busy && !loadingProject) { showFpsDialog = true }
                    .padding(horizontal = 11.dp, vertical = 5.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
            ) {
                Text("$videoFps", color = if (busy || loadingProject) c.Sub else c.Accent, fontSize = 16.sp, fontWeight = FontWeight.Bold, lineHeight = 17.sp)
                Text("fps", color = c.Sub, fontSize = 9.sp, lineHeight = 10.sp)
            }
            Button(
                onClick = { startExport() },
                enabled = images.isNotEmpty() && !busy && !loadingProject,
                shape = RoundedCornerShape(12.dp),
                contentPadding = PaddingValues(horizontal = 14.dp, vertical = 6.dp),
                colors = ButtonDefaults.buttonColors(containerColor = c.Accent, contentColor = Color(0xFF06141F), disabledContainerColor = c.Panel2, disabledContentColor = c.Sub),
            ) { Text(if (busy) "กำลังสร้าง…" else "ส่งออก MP4", fontWeight = FontWeight.Bold, fontSize = 13.sp) }
        }
        if (loadingProject) LinearProgressIndicator(Modifier.fillMaxWidth(), color = c.Accent)
        if (busy) LinearProgressIndicator(progress = { exportProgress }, modifier = Modifier.fillMaxWidth(), color = c.Ok)

        if (images.isEmpty() && !loadingProject) {
            Box(Modifier.weight(1f).fillMaxWidth().background(c.Panel, RoundedCornerShape(18.dp)), contentAlignment = Alignment.Center) {
                Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text("🖼", fontSize = 46.sp)
                    Text("ยังไม่มีรูปภาพหรือวิดีโอ", color = c.Ink, fontSize = 18.sp, fontWeight = FontWeight.Bold)
                    Text("เพิ่มรูปภาพหรือวิดีโอแล้วจัดเวลา/แทร็กบน Timeline ได้เลย", color = c.Sub, fontSize = 13.sp)
                    Button(
                        onClick = { picker.launch(arrayOf("image/*")) },
                        shape = RoundedCornerShape(14.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = c.Accent, contentColor = Color(0xFF06141F)),
                    ) { Text("＋ เพิ่มรูปภาพ", fontWeight = FontWeight.Bold) }
                    Button(
                        onClick = { videoPicker.launch(arrayOf("video/*")) },
                        enabled = !busyImport,
                        shape = RoundedCornerShape(14.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = c.Panel2, contentColor = c.Ink),
                    ) { Text("＋ เพิ่มวิดีโอ", fontWeight = FontWeight.Bold) }
                }
            }
        } else {
            // Canvas
            Box(Modifier.weight(1f).fillMaxWidth().background(c.Panel, RoundedCornerShape(18.dp)).padding(8.dp)) {
                StudioCanvas(
                    images = images, playhead = playhead, selectedId = selectedId,
                    overlayText = overlayText, overlaySticker = overlaySticker, overlayStart = overlayStart, overlayDuration = overlayDuration,
                    onSelect = { id -> if (id < 0) selectedId = -1 else selectClip(id) },
                    onTransform = { id, dx, dy, zoom, rot -> transformClip(id, dx, dy, zoom, rot) },
                    sculptMode = sculptMode && current != null, brushFrac = brushFrac,
                    sculptTool = sculptTool, meshCell = meshCell, meshRings = meshRings, twistDeg = twistDeg, videoW = videoW, videoH = videoH,
                    onSculpt = { id, g -> sculptClip(id, g) },
                    pinSelectedId = selectedPinId, pinPlacing = pinPlacing && sculptTool == SculptTool.PIN, pinShowMesh = pinShowMesh,
                    onPinSelect = { selectedPinId = it },
                    onPinAdd = { id, x, y, dir -> addPin(id, x, y, dir) },
                    onPinMove = { id, pinId, x, y, commit -> movePin(id, pinId, x, y, commit) },
                    onPinAngle = { id, k, deg -> setPinAngle(id, k, deg) },
                    onNotice = { status = it },
                    modifier = Modifier.fillMaxSize(),
                )
            }

            // แถบเครื่องมือ
            Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.CenterVertically) {
                ToolChip(if (previewPlaying) "Ⅱ หยุด" else "▶ เล่น", onClick = { previewPlaying = !previewPlaying }, enabled = images.isNotEmpty() && !busy, highlight = true)
                ToolChip("＋ ภาพ", onClick = { picker.launch(arrayOf("image/*")) }, enabled = !busy && !loadingProject && !busyImport)
                ToolChip("＋ วิดีโอ", onClick = { videoPicker.launch(arrayOf("video/*")) }, enabled = !busy && !loadingProject && !busyImport)
                ToolChip("🔊 เสียงวิดีโอ", onClick = { current?.let { useVideoAudio(it) } }, enabled = current != null && isVideoClip(current) && !busy && !busyImport)
                ToolChip("✎ แก้ไขภาพ", onClick = { current?.let { previewPlaying = false; editClipId = it.id } }, enabled = current != null && !isVideoClip(current) && !busy)
                ToolChip("✂ แบ่ง", onClick = { current?.let { splitClip(it.id) } }, enabled = current != null && !busy)
                ToolChip("⧉ ทำซ้ำ", onClick = { current?.let { duplicateClip(it.id) } }, enabled = current != null && !busy)
                ToolChip(if (current?.locked == true) "🔓 ปลดล็อก" else "🔒 ล็อก", onClick = { current?.let { cl -> updateClip(cl.id) { it.copy(locked = !it.locked) } } }, enabled = current != null)
                ToolChip(if (current?.visible == false) "แสดง" else "ซ่อน", onClick = { current?.let { cl -> updateClip(cl.id) { it.copy(visible = !it.visible) } } }, enabled = current != null)
                ToolChip("⚙ ปรับแต่ง", onClick = { showProps = true }, enabled = current != null)
                ToolChip(if (sculptMode) "✋ จบการบิด" else "✋ บิดภาพ", highlight = sculptMode, enabled = current != null, onClick = {
                    sculptMode = !sculptMode
                    pinPlacing = false
                    if (sculptMode) { previewPlaying = false; status = "ลากบนภาพเพื่อดึง/บิด · ถ้ามี ◆ หลายจุด แต่ละจุดจำท่าบิดของตัวเอง" }
                })
                ToolChip(if (current?.sizeLocked == true) "📏 ปลดล็อกขนาด" else "📏 ล็อกขนาด", highlight = current?.sizeLocked == true, enabled = current != null,
                    onClick = { current?.let { cl -> updateClip(cl.id) { it.copy(sizeLocked = !it.sizeLocked) } } })
                ToolChip("🗑 ลบ", onClick = { current?.let { deleteClip(it.id) } }, enabled = current != null && !busy, danger = true)
                ToolChip("Ｔ ข้อความ", onClick = { showExtras = true }, enabled = !busy)
                ToolChip("♫ เสียง", onClick = { if (audioFile == null) audioPicker.launch(arrayOf("audio/*")) else showExtras = true }, enabled = !busy)
                ToolChip("ล้างทั้งหมด", onClick = { showClearConfirm = true }, enabled = images.isNotEmpty() && !busy, danger = true)
            }

            if (sculptMode && current != null) {
                SculptPanel(
                    clip = current, tool = sculptTool, onTool = { sculptTool = it; pinPlacing = false },
                    brushFrac = brushFrac, onBrush = { brushFrac = it },
                    meshRings = meshRings, onRings = { meshRings = it },
                    twistDeg = twistDeg, onTwist = { twistDeg = it },
                    meshCell = meshCell, onCell = { meshCell = it },
                    onApplyGrid = { regridClip(current.id) },
                    onReset = { sculptClip(current.id, null) },
                    pinContent = {
                        PinSection(
                            clip = current, grid = studioPoseAt(current, playhead).sculpt,
                            selectedPinId = selectedPinId, placing = pinPlacing, showMesh = pinShowMesh,
                            onPlacing = { on -> pinPlacing = on; if (on) status = "แตะที่ข้อต่อบนภาพ (ลากต่อไปทางส่วนที่จะขยับเพื่อตั้งทิศได้เลย)" },
                            onSelect = { selectedPinId = it },
                            onEdit = { pid, relayout, block -> updatePin(current.id, pid, relayout, block) },
                            onAngle = { k, deg -> setPinAngle(current.id, k, deg) },
                            onDelete = { pid -> deletePin(current.id, pid) },
                            onRig = { relayout, block -> updateRig(current.id, relayout, block) },
                            onShowMesh = { pinShowMesh = it },
                            onResetAngles = { resetPinAngles(current.id) },
                        )
                    },
                )
            }

            // Timeline
            StudioTimeline(
                images = images, layerIds = layerIds, selectedId = selectedId, activeLayerId = activeLayerId,
                playhead = playhead, zoom = timelineZoom, timelineEnd = timelineEnd, playing = previewPlaying,
                overlayLabel = (overlaySticker + " " + overlayText).trim(), overlayStart = overlayStart, overlayDuration = overlayDuration,
                audioName = audioFile?.name, audioStart = audioStart,
                onSeek = { playhead = it },
                onSelect = { selectClip(it) },
                onActiveLane = { activeLayerId = it },
                onNewTopLane = { newTopLane() },
                onOverlayChange = { s, d -> overlayStart = s; overlayDuration = d },
                onAudioStart = { audioStart = it },
                onZoom = { timelineZoom = it.coerceIn(0.5f, 4f) },
                onAddLane = { activeLayerId = newTopLane(); status = "เพิ่มแทร็กใหม่แล้ว" },
                onAddKeyframe = {
                    val cl = current
                    if (cl == null) status = "เลือกคลิปก่อน"
                    else if (playhead < cl.startTime || playhead > clipEnd(cl)) status = "เลื่อนเส้นแดงให้อยู่ในคลิปที่เลือกก่อน"
                    else {
                        val lt = (playhead - cl.startTime).coerceIn(0f, cl.duration)
                        val pose = studioPoseAt(cl, playhead)
                        val key = StudioKeyframe(lt, pose.x, pose.y, pose.scale, pose.rotation, pose.opacity, pose.sculpt)
                        updateClip(cl.id) { it.copy(keyframes = (it.keyframes.filterNot { k -> abs(k.time - lt) < 0.05f } + key).sortedBy { k -> k.time }) }
                        status = "บันทึก Keyframe ที่ ${f1(lt)} วินาทีแล้ว"
                    }
                },
                onDeleteKeyframe = {
                    val cl = current
                    if (cl == null) status = "เลือกคลิปก่อน"
                    else {
                        val lt = (playhead - cl.startTime).coerceIn(0f, cl.duration)
                        val nearest = cl.keyframes.minByOrNull { abs(it.time - lt) }
                        if (nearest != null && abs(nearest.time - lt) <= 0.25f) {
                            updateClip(cl.id) { it.copy(keyframes = it.keyframes - nearest) }
                            status = "ลบ Keyframe แล้ว"
                        } else status = "ไม่มี Keyframe ใกล้เส้นแดง (ห่างเกิน 0.25 วิ)"
                    }
                },
                modifier = Modifier.fillMaxWidth(),
            )
        }
        status?.let { Text(it, color = c.Accent, fontSize = 12.sp) }
    }

    // ───────────── กล่องโต้ตอบ ─────────────
    if (showClearConfirm) {
        AlertDialog(
            onDismissRequest = { showClearConfirm = false },
            containerColor = c.Panel, titleContentColor = c.Ink, textContentColor = c.Sub,
            title = { Text("ล้างทั้งหมด?") },
            text = { Text("คลิปและแทร็กทั้งหมดในโปรเจกต์นี้จะถูกลบ") },
            confirmButton = { TextButton(onClick = {
                previewPlaying = false; images.clear(); layerIds.clear(); layerIds.add(1); activeLayerId = 1; selectedId = -1; playhead = 0f
                showClearConfirm = false
            }) { Text("ล้างทั้งหมด", color = c.Danger) } },
            dismissButton = { TextButton(onClick = { showClearConfirm = false }) { Text("ยกเลิก", color = c.Sub) } },
        )
    }
    if (showProps && current != null) {
        ClipPropertiesDialog(
            clip = current, playhead = playhead, animationMode = animationMode, motionPreset = motionPreset,
            onUpdate = { block -> updateClip(current.id, block) },
            onAnimationMode = { animationMode = it },
            onPreset = { motionPreset = it },
            onStatus = { status = it },
            onDismiss = { showProps = false },
        )
    }
    if (showFpsDialog) {
        FpsDialog(
            fps = videoFps, durationSec = timelineEnd,
            onApply = { f -> videoFps = f; showFpsDialog = false; status = "ตั้งค่าเป็น $f เฟรมต่อวินาทีแล้ว" },
            onDismiss = { showFpsDialog = false },
        )
    }
    if (showVideoSize) {
        VideoSizeDialog(
            width = videoW, height = videoH,
            onApply = { w, h -> videoW = w; videoH = h; showVideoSize = false; status = "ตั้งขนาดวิดีโอเป็น สูง ${Exporter.videoSize(h)} × กว้าง ${Exporter.videoSize(w)} px" },
            onDismiss = { showVideoSize = false },
        )
    }
    if (showExtras) {
        ExtrasDialog(
            overlayText = overlayText, overlaySticker = overlaySticker, audioName = audioFile?.name, audioVolume = audioVolume,
            onText = { overlayText = it }, onSticker = { overlaySticker = it },
            onClearOverlay = { overlaySticker = ""; overlayText = "" },
            onVolume = { audioVolume = it },
            onPickAudio = { audioPicker.launch(arrayOf("audio/*")) },
            onRemoveAudio = { audioFile = null },
            onDismiss = { showExtras = false },
        )
    }
}

// ───────────────────────── Canvas ─────────────────────────

@Composable
private fun StudioCanvas(
    images: List<StudioImage>, playhead: Float, selectedId: Int,
    overlayText: String, overlaySticker: String, overlayStart: Float, overlayDuration: Float,
    onSelect: (Int) -> Unit, onTransform: (Int, Float, Float, Float, Float) -> Unit,
    sculptMode: Boolean, brushFrac: Float, onSculpt: (Int, SculptGrid) -> Unit,
    sculptTool: SculptTool, meshCell: Float?, meshRings: Int, twistDeg: Float, videoW: Int, videoH: Int,
    pinSelectedId: Int, pinPlacing: Boolean, pinShowMesh: Boolean,
    onPinSelect: (Int) -> Unit, onPinAdd: (Int, Float, Float, Float?) -> Unit,
    onPinMove: (Int, Int, Float, Float, Boolean) -> Unit, onPinAngle: (Int, Int, Float) -> Unit,
    onNotice: (String) -> Unit,
    modifier: Modifier = Modifier,
) {
    val c = StudioColors
    val density = LocalDensity.current
    val meshPaint = remember { Paint(Paint.FILTER_BITMAP_FLAG) }
    val brushFracNow by rememberUpdatedState(brushFrac)
    val onSculptNow by rememberUpdatedState(onSculpt)
    val playheadNow by rememberUpdatedState(playhead)
    val selectedNow by rememberUpdatedState(selectedId)
    val imagesNow by rememberUpdatedState(images)
    val onSelectNow by rememberUpdatedState(onSelect)
    val onTransformNow by rememberUpdatedState(onTransform)
    val toolNow by rememberUpdatedState(sculptTool)
    val meshCellNow by rememberUpdatedState(meshCell)
    val ringsNow by rememberUpdatedState(meshRings)
    val twistDegNow by rememberUpdatedState(twistDeg)
    val pinSelectedNow by rememberUpdatedState(pinSelectedId)
    val pinPlacingNow by rememberUpdatedState(pinPlacing)
    val onPinSelectNow by rememberUpdatedState(onPinSelect)
    val onPinAddNow by rememberUpdatedState(onPinAdd)
    val onPinMoveNow by rememberUpdatedState(onPinMove)
    val onPinAngleNow by rememberUpdatedState(onPinAngle)
    val onNoticeNow by rememberUpdatedState(onNotice)
    var pinPreview by remember { mutableStateOf<List<Float>?>(null) } // เส้นทิศขณะลากวางหมุด: [เริ่ม x, เริ่ม y, ปลาย x, ปลาย y] (พิกเซล bitmap)
    // คลิปวิดีโอ: เธรดอ่านเฟรมตามเวลาของเส้นแดง (ข้ามเฟรมที่ไม่ทัน ไม่ค้างตอนเล่น) เก็บเฟรมล่าสุดของแต่ละคลิป
    val videoReaders = remember { HashMap<String, VideoReader>() }
    val videoFrames = remember { mutableStateMapOf<Int, Pair<Int, Bitmap>>() } // id คลิป -> (ตราเวลา, เฟรมล่าสุด)
    DisposableEffect(Unit) { onDispose { synchronized(videoReaders) { videoReaders.values.forEach { it.close() }; videoReaders.clear() } } }
    LaunchedEffect(Unit) {
        while (true) {
            var worked = false
            val t = playheadNow
            for (vc in imagesNow) {
                if (!isVideoClip(vc) || !isActiveAt(vc, t)) continue
                val local = videoLocalTime(vc, t)
                val stamp = (local * 20f).roundToInt() * 31 + vc.file.absolutePath.hashCode()
                if (videoFrames[vc.id]?.first == stamp) continue
                val k = minOf(1f, VideoFrames.PREVIEW_SIDE.toFloat() / maxOf(vc.bitmap.width, vc.bitmap.height))
                val fw = maxOf(1, (vc.bitmap.width * k).roundToInt())
                val fh = maxOf(1, (vc.bitmap.height * k).roundToInt())
                val bmp = withContext(Dispatchers.IO) {
                    runCatching {
                        val rd = synchronized(videoReaders) { videoReaders.getOrPut(vc.file.absolutePath) { VideoReader(vc.file, vc.videoLength) } }
                        rd.frame(local, fw, fh, exact = true)
                    }.getOrNull()
                }
                videoFrames[vc.id] = stamp to (bmp ?: videoFrames[vc.id]?.second ?: vc.bitmap)
                worked = true
            }
            delay(if (worked) 8L else 30L)
        }
    }
    val downPos = remember { floatArrayOf(0f, 0f) } // ตำแหน่งที่นิ้ววางลงจริง (detectDragGestures ส่งตำแหน่งหลังพ้นระยะ slop มาให้ ใช้เลือกจุด Mesh Warp ไม่แม่น)
    var sculptRing by remember { mutableStateOf<Triple<Float, Float, Float>?>(null) } // วงรัศมีพู่กัน (กลาง x, y และรัศมี เป็นพิกเซล bitmap) ขณะลาก
    var meshPick by remember { mutableStateOf<Pair<Int, Int>?>(null) } // จุดตาข่ายที่ Mesh Warp กำลังลาก (i, j)

    BoxWithConstraints(modifier, contentAlignment = Alignment.Center) {
        // กรอบเฟรม = สัดส่วนเดียวกับวิดีโอที่ส่งออก (ตั้งขนาดที่ปุ่ม "แก้ไข") ส่วนที่เกินเฟรมจะไม่ปรากฏในวิดีโอ
        val (frameWW, frameWH) = Exporter.frameWorldSize(videoW, videoH) // ขนาดเฟรมหน่วยโลก (กว้าง, สูง) ด้านสั้น = 600
        val aspect = frameWW / frameWH
        val boxW: Dp
        val boxH: Dp
        if (maxWidth / maxHeight > aspect) { boxH = maxHeight; boxW = maxHeight * aspect } else { boxW = maxWidth; boxH = maxWidth / aspect }
        val boxWPx = with(density) { boxW.toPx() }
        val boxHPx = with(density) { boxH.toPx() }
        val unit = boxWPx / frameWW // พิกเซลต่อหน่วยโลก
        val sqPx = Exporter.WORLD_WINDOW * unit // ช่องจัตุรัส 600 หน่วยโลกที่ใช้ "พอดีเฟรม" ของภาพ (เหมือนตอนส่งออก)
        val sqDp = with(density) { sqPx.toDp() }
        val unitNow by rememberUpdatedState(unit)
        val boxWNow by rememberUpdatedState(boxWPx)
        val boxHNow by rememberUpdatedState(boxHPx)

        Box(
            Modifier.size(boxW, boxH).clip(RoundedCornerShape(12.dp)).background(Color.Black)
                .border(1.dp, c.Line, RoundedCornerShape(12.dp))
                .pointerInput(Unit) {
                    detectTapGestures { off ->
                        val wx = (off.x - boxWNow / 2f) / unitNow
                        val wy = (off.y - boxHNow / 2f) / unitNow
                        val t = playheadNow
                        val hit = stackOrder(imagesNow).asReversed().firstOrNull { isActiveAt(it, t) && hitsClip(it, studioPoseAt(it, t), wx, wy) }
                        onSelectNow(hit?.id ?: -1)
                    }
                }
                .pointerInput(Unit) {
                    awaitEachGesture {
                        val down = awaitFirstDown(requireUnconsumed = false)
                        downPos[0] = down.position.x; downPos[1] = down.position.y
                    }
                }
                .pointerInput(sculptMode) {
                    if (sculptMode) {
                        // โหมดบิดภาพ: นิ้วเดียวลาก (คำนวณจากท่าตอนวางนิ้วทุกครั้ง ไม่สะสมเพี้ยน)
                        //   ดึง = ดึงตาข่ายรอบนิ้ว · Mesh Warp = ลากจุดตาข่ายที่ใกล้นิ้ว · Twist = บิดวนรอบจุดที่แตะ (ลากซ้าย/ขวากำหนดมุม)
                        var sStart: SculptGrid? = null
                        var sWts: FloatArray? = null
                        var sStep = 0f; var sAccX = 0f; var sAccY = 0f; var sId = -1
                        var twCx = 0f; var twCy = 0f; var twR = 1f; var twLimit = 0f
                        // ระยะลากบนจอ (px) -> ระยะในพิกัด bitmap ของคลิป (หักมุมหมุน/ขนาดของคลิป)
                        fun toBitmapDelta(clip: StudioImage, dx: Float, dy: Float): Pair<Float, Float> {
                            val pose = studioPoseAt(clip, playheadNow)
                            val fit = fitScale(clip.bitmap.width, clip.bitmap.height)
                            val rad = Math.toRadians(pose.rotation.toDouble())
                            val cs = kotlin.math.cos(rad).toFloat()
                            val sn = kotlin.math.sin(rad).toFloat()
                            val sc = pose.scale.coerceAtLeast(0.05f)
                            val wdx = dx / unitNow
                            val wdy = dy / unitNow
                            return Pair(((wdx * cs + wdy * sn) / sc) / fit, ((-wdx * sn + wdy * cs) / sc) / fit)
                        }
                        detectDragGestures(
                            onDragStart = { off ->
                                sStart = null; sculptRing = null; meshPick = null
                                val clip = imagesNow.firstOrNull { it.id == selectedNow }
                                if (clip != null && !clip.locked && isActiveAt(clip, playheadNow)) {
                                    val tool = toolNow
                                    val pose = studioPoseAt(clip, playheadNow)
                                    val bw = clip.bitmap.width; val bh = clip.bitmap.height
                                    val (dc, dr) = clipGridDims(clip, meshCellNow)
                                    val g0 = pose.sculpt ?: JointPins.zeroGrid(clip.rig, bw, bh, dc, dr)
                                    val blocked = toolNow != SculptTool.PIN && hasPinAngle(g0) // หมุดข้อต่องออยู่: ตำแหน่งที่เห็นไม่ตรงตาข่ายตั้งต้น
                                    if (blocked) onNoticeNow("ตั้งมุมหมุดข้อต่อเป็น 0 ก่อนจึงจะปั้นด้วยมือได้ (ปุ่ม รีเซ็ตมุม ในแผงหมุด)")
                                    // Mesh Warp / Twist ใช้ตำแหน่งที่นิ้ววางจริง · ดึง ใช้ตำแหน่งเดิม (หลังพ้น slop) เหมือนเดิม
                                    val p = if (tool == SculptTool.GRAB) off else Offset(downPos[0], downPos[1])
                                    val (bpx, bpy) = worldToBitmap(clip, pose, (p.x - boxWNow / 2f) / unitNow, (p.y - boxHNow / 2f) / unitNow)
                                    val cellMax = Sculpt.cellMaxPx(bw, bh, g0) // ตาข่ายถี่ตามหมุด: ช่องไม่เท่ากัน ใช้ช่องที่ใหญ่/เล็กที่สุดตามจริง
                                    val cellMin = Sculpt.cellMinPx(bw, bh, g0)
                                    val radius = brushFracNow * maxOf(bw, bh) // ดึง: รัศมีเดิมเป๊ะ (ไม่เปลี่ยนพฤติกรรมเดิม)
                                    sAccX = 0f; sAccY = 0f; sId = clip.id
                                    if (blocked) { /* งอหมุดอยู่: ไม่ปั้น */ } else when (tool) {
                                        SculptTool.GRAB -> {
                                            sWts = Sculpt.brushWeights(bw, bh, g0, bpx, bpy, radius, 0f, 0f, 0f)
                                            sStep = Sculpt.maxStep(radius, 0f)
                                            sculptRing = Triple(bpx, bpy, radius)
                                            sStart = g0
                                        }
                                        SculptTool.MESH -> {
                                            val hit = Sculpt.nearestVertex(bw, bh, g0, bpx, bpy)
                                            if (hit.dist <= 1.5f * cellMax) { // แตะไกลจากทุกจุดเกินไป = ไม่ทำอะไร
                                                sWts = Sculpt.ringWeights(g0, hit.i, hit.j, ringsNow)
                                                sStep = Sculpt.maxStepRings(cellMin, ringsNow)
                                                meshPick = Pair(hit.i, hit.j)
                                                // ชดเชยระยะ slop ที่นิ้วเลื่อนไปก่อน onDragStart ให้จุดอยู่ใต้นิ้ว
                                                val (ix, iy) = toBitmapDelta(clip, off.x - p.x, off.y - p.y)
                                                sAccX = ix; sAccY = iy
                                                sStart = g0
                                            }
                                        }
                                        SculptTool.TWIST -> {
                                            // รัศมีต่ำสุด 2 ช่อง: เล็กกว่านั้นแทบไม่มีจุดตาข่ายอยู่ในพู่กัน (ไม่ขยับ)
                                            twCx = bpx; twCy = bpy; twR = maxOf(radius, 2f * cellMax)
                                            twLimit = Sculpt.maxTwist(twR, cellMax)
                                            sculptRing = Triple(bpx, bpy, twR)
                                            sStart = g0
                                        }
                                        SculptTool.PIN -> { /* เครื่องมือหมุดมีตัวจัดการท่าทางของตัวเอง (ด้านล่าง) */ }
                                    }
                                }
                            },
                            onDragEnd = { sStart = null; sculptRing = null; meshPick = null },
                            onDragCancel = { sStart = null; sculptRing = null; meshPick = null },
                            onDrag = { change, drag ->
                                val st = sStart
                                val clip = imagesNow.firstOrNull { it.id == sId }
                                if (st != null && clip != null) {
                                    change.consume()
                                    val (ax, ay) = toBitmapDelta(clip, drag.x, drag.y)
                                    sAccX += ax; sAccY += ay
                                    if (toolNow == SculptTool.TWIST) {
                                        // ลากไกล 1 รัศมี = มุมเต็ม (twistDeg) แต่ไม่เกินมุมที่ตาข่ายไม่พับ
                                        val frac = (sAccX / twR).coerceIn(-1f, 1f)
                                        val ang = frac * minOf(Math.toRadians(twistDegNow.toDouble()).toFloat(), twLimit)
                                        onSculptNow(sId, Sculpt.applyTwist(clip.bitmap.width, clip.bitmap.height, st, twCx, twCy, twR, ang))
                                    } else {
                                        val w = sWts
                                        if (w != null) onSculptNow(sId, Sculpt.applyGrab(st, w, sAccX, sAccY, sStep))
                                    }
                                }
                            },
                        )
                    } else {
                        detectTransformGestures { _, pan, zoom, rotation ->
                            // rotation ของ Compose เป็นองศาอยู่แล้ว
                            onTransformNow(selectedNow, pan.x / unitNow, pan.y / unitNow, zoom, rotation)
                        }
                    }
                }
                .pointerInput(sculptMode && sculptTool == SculptTool.PIN) {
                    if (sculptMode && sculptTool == SculptTool.PIN) {
                        // เครื่องมือหมุดข้อต่อ (ตัวจัดการอยู่ชั้นในสุด จึงได้รับเหตุการณ์ก่อน; ถ้าไม่ได้แตะหมุด/ไม่ได้วางหมุด จะไม่ดูดเหตุการณ์ ให้แตะเลือกคลิปได้ตามปกติ)
                        //   วางหมุด = แตะที่ข้อต่อ (ลากต่อไปทางส่วนที่จะขยับเพื่อตั้งทิศ) · ลากจุดแดง = ย้ายหมุด · ลากปลายสีเขียว = งอข้อต่อ
                        awaitEachGesture {
                            val down = awaitFirstDown(requireUnconsumed = false)
                            val clip = imagesNow.firstOrNull { it.id == selectedNow }
                            if (clip == null || clip.locked || !isActiveAt(clip, playheadNow)) return@awaitEachGesture
                            val pose = studioPoseAt(clip, playheadNow)
                            val bw = clip.bitmap.width
                            val bh = clip.bitmap.height
                            val rig = clip.rig
                            val g = pose.sculpt
                            fun toBmp(pt: Offset): Pair<Float, Float> =
                                worldToBitmap(clip, pose, (pt.x - boxWNow / 2f) / unitNow, (pt.y - boxHNow / 2f) / unitNow)
                            val bmpPerPx = 1f / (fitScale(bw, bh) * unitNow * pose.scale.coerceAtLeast(0.05f))
                            val hitR = 24.dp.toPx() * bmpPerPx
                            val (sx, sy) = toBmp(down.position)

                            if (pinPlacingNow) {
                                down.consume()
                                if (hasPinAngle(g)) {
                                    onNoticeNow("ตั้งมุมหมุดเป็น 0 ก่อนจึงจะวางหมุดใหม่ได้ (ปุ่ม รีเซ็ตมุม)")
                                    while (true) {
                                        val ev = awaitPointerEvent()
                                        val ch = ev.changes.firstOrNull { it.id == down.id } ?: break
                                        ch.consume()
                                        if (!ch.pressed) break
                                    }
                                    return@awaitEachGesture
                                }
                                var ex = sx
                                var ey = sy
                                while (true) {
                                    val ev = awaitPointerEvent()
                                    val ch = ev.changes.firstOrNull { it.id == down.id } ?: break
                                    val (mx, my) = toBmp(ch.position)
                                    ex = mx; ey = my
                                    pinPreview = listOf(sx, sy, ex, ey)
                                    ch.consume()
                                    if (!ch.pressed) break
                                }
                                pinPreview = null
                                val far = kotlin.math.hypot(ex - sx, ey - sy) > 18f * bmpPerPx
                                onPinAddNow(clip.id, sx, sy, if (far) Math.toDegrees(kotlin.math.atan2(ey - sy, ex - sx).toDouble()).toFloat() else null)
                                return@awaitEachGesture
                            }

                            // หาหมุดที่แตะ: ปลายสีเขียว (งอ) ก่อน แล้วจึงจุดแดง (ย้าย); หมุดที่เลือกอยู่มาก่อน
                            val order = rig.pins.indices.sortedBy { if (rig.pins[it].id == pinSelectedNow) 0 else 1 }
                            var hitKind = 0
                            var hitIdx = -1
                            var bestD = Float.MAX_VALUE
                            for (k in order) {
                                val (hx, hy) = JointPins.handlePosition(rig, g, k, bw, bh)
                                val d = kotlin.math.hypot(hx - sx, hy - sy)
                                if (d <= hitR && d < bestD) { bestD = d; hitKind = 1; hitIdx = k }
                            }
                            if (hitIdx < 0) for (k in order) {
                                val (px, py) = JointPins.pinPosition(rig, g, k)
                                val d = kotlin.math.hypot(px - sx, py - sy)
                                if (d <= hitR * 1.1f && d < bestD) { bestD = d; hitKind = 2; hitIdx = k }
                            }
                            if (hitIdx < 0) return@awaitEachGesture
                            val pin = rig.pins[hitIdx]
                            down.consume()
                            onPinSelectNow(pin.id)
                            if (hitKind == 1) {
                                while (true) {
                                    val ev = awaitPointerEvent()
                                    val ch = ev.changes.firstOrNull { it.id == down.id } ?: break
                                    val (mx, my) = toBmp(ch.position)
                                    onPinAngleNow(clip.id, hitIdx, JointPins.angleToward(rig, g, hitIdx, bw, bh, mx, my))
                                    ch.consume()
                                    if (!ch.pressed) break
                                }
                            } else {
                                val movable = JointPins.ancestorsOf(rig.pins, hitIdx).all { (g?.angleOf(it) ?: 0f) == 0f }
                                if (!movable) onNoticeNow("หมุดนี้ติดกับหมุดแม่ที่กำลังงออยู่ ตั้งมุมแม่เป็น 0 ก่อนจึงย้ายได้ (หรือพิมพ์ X/Y ในตั้งค่าละเอียด)")
                                val (ppx, ppy) = JointPins.pinPosition(rig, g, hitIdx)
                                val offX = ppx - sx
                                val offY = ppy - sy
                                var lastX = pin.x
                                var lastY = pin.y
                                var moved = false
                                while (true) {
                                    val ev = awaitPointerEvent()
                                    val ch = ev.changes.firstOrNull { it.id == down.id } ?: break
                                    if (movable) {
                                        val (mx, my) = toBmp(ch.position)
                                        lastX = mx + offX; lastY = my + offY
                                        onPinMoveNow(clip.id, pin.id, lastX, lastY, false)
                                        moved = true
                                    }
                                    ch.consume()
                                    if (!ch.pressed) break
                                }
                                if (moved) onPinMoveNow(clip.id, pin.id, lastX, lastY, true) // ปล่อยนิ้ว: จัดตาข่ายถี่ใหม่ให้ตรงตำแหน่งหมุด
                            }
                        }
                    }
                },
            contentAlignment = Alignment.Center,
        ) {
            // ภาพแสดงเฉพาะช่วงเวลาของคลิป และซ้อนกันตามลำดับแทร็ก
            stackOrder(images).forEach { layer ->
                if (isActiveAt(layer, playhead)) {
                    key(layer.id) {
                        val pose = studioPoseAt(layer, playhead)
                        val g = renderGrid(layer, pose.sculpt)
                        val shown = if (isVideoClip(layer)) videoFrames[layer.id]?.second ?: layer.bitmap else layer.bitmap
                        if (g == null || g.isZero()) {
                            Image(
                                shown.asImageBitmap(), null,
                                Modifier.requiredSize(sqDp).graphicsLayer(
                                    translationX = pose.x * unit, translationY = pose.y * unit,
                                    scaleX = pose.scale, scaleY = pose.scale, rotationZ = pose.rotation,
                                    alpha = pose.opacity.coerceIn(0f, 1f),
                                ),
                                contentScale = ContentScale.Fit,
                            )
                        } else {
                            // คลิปที่บิดแล้ว: วาดผ่านตาข่าย ตำแหน่ง/ขนาดเดียวกับ Image ปกติ (พอดีเฟรมกึ่งกลาง)
                            androidx.compose.foundation.Canvas(
                                Modifier.requiredSize(sqDp).graphicsLayer(
                                    translationX = pose.x * unit, translationY = pose.y * unit,
                                    scaleX = pose.scale, scaleY = pose.scale, rotationZ = pose.rotation,
                                    alpha = pose.opacity.coerceIn(0f, 1f),
                                ),
                            ) {
                                val bw = layer.bitmap.width
                                val bh = layer.bitmap.height
                                val fitPx = minOf(size.width / bw, size.height / bh)
                                val nc = drawContext.canvas.nativeCanvas
                                nc.save()
                                nc.translate(size.width / 2f, size.height / 2f)
                                nc.scale(fitPx, fitPx)
                                nc.translate(-bw / 2f, -bh / 2f)
                                nc.drawBitmapMesh(shown, g.cols, g.rows, Sculpt.verts(bw, bh, g), 0, null, 0, meshPaint)
                                nc.restore()
                            }
                        }
                    }
                }
            }
            // กรอบเลือก + จุดหมุน (เฉพาะคลิปที่เลือกและกำลังแสดงอยู่ ณ เวลานี้)
            val sel = images.firstOrNull { it.id == selectedId }
            if (sel != null && isActiveAt(sel, playhead)) {
                val pose = studioPoseAt(sel, playhead)
                val fitPx = minOf(sqPx / sel.bitmap.width, sqPx / sel.bitmap.height)
                val frameW = with(density) { (sel.bitmap.width * fitPx).toDp() }
                val frameH = with(density) { (sel.bitmap.height * fitPx).toDp() }
                val frameColor = if (sel.locked) c.Warn else c.Accent
                Box(
                    Modifier.requiredSize(frameW, frameH).graphicsLayer(
                        translationX = pose.x * unit, translationY = pose.y * unit,
                        scaleX = pose.scale, scaleY = pose.scale, rotationZ = pose.rotation,
                    ).border(1.5.dp, frameColor),
                ) {
                    if (sel.locked) {
                        Text("🔒", fontSize = 14.sp, modifier = Modifier.align(Alignment.TopStart).padding(4.dp))
                    } else if (!sculptMode) {
                        Box(
                            Modifier.align(Alignment.TopCenter).offset(y = 6.dp).size(30.dp).clip(CircleShape)
                                .background(c.AccentDim).border(1.dp, c.Accent, CircleShape)
                                .pointerInput(sel.id) {
                                    detectDragGestures { change, drag ->
                                        change.consume()
                                        onTransformNow(sel.id, 0f, 0f, 1f, drag.x * 0.6f)
                                    }
                                },
                            contentAlignment = Alignment.Center,
                        ) { Text("↻", color = Color.White, fontSize = 15.sp) }
                    }
                    if (sculptMode && !sel.locked) { // เส้นตาข่ายให้เห็นว่าบิดอยู่ตรงไหน
                        androidx.compose.foundation.Canvas(Modifier.fillMaxSize()) {
                            val bw = sel.bitmap.width
                            val bh = sel.bitmap.height
                            val (dc, dr) = clipGridDims(sel, meshCell)
                            val g0 = pose.sculpt ?: JointPins.zeroGrid(sel.rig, bw, bh, dc, dr)
                            val g = renderGrid(sel, g0) ?: g0 // เส้นตาข่ายตามที่เห็น (งอตามหมุดแล้ว)
                            val v = Sculpt.verts(bw, bh, g)
                            val pinTool = sculptTool == SculptTool.PIN
                            val col = if (pinTool && !pinShowMesh) Color.Transparent else Color(if (pinTool) 0x66FFFFFF else 0x99FFFFFF)
                            val rowW = g.cols + 1
                            for (j in 0..g.rows) for (i in 0 until g.cols) {
                                val a = j * rowW + i
                                val b = a + 1
                                drawLine(col, Offset(v[2 * a] * fitPx, v[2 * a + 1] * fitPx), Offset(v[2 * b] * fitPx, v[2 * b + 1] * fitPx), 1f)
                            }
                            for (i in 0..g.cols) for (j in 0 until g.rows) {
                                val a = j * rowW + i
                                val b = a + rowW
                                drawLine(col, Offset(v[2 * a] * fitPx, v[2 * a + 1] * fitPx), Offset(v[2 * b] * fitPx, v[2 * b + 1] * fitPx), 1f)
                            }
                            if (sculptTool == SculptTool.MESH) { // จุดควบคุมให้แตะลาก (จุดที่กำลังลากเป็นสีส้ม)
                                var n = 0
                                for (j in 0..g.rows) for (i in 0..g.cols) {
                                    val picked = meshPick?.let { it.first == i && it.second == j } == true
                                    drawCircle(if (picked) c.Warn else c.Accent, if (picked) 7f else 4f, Offset(v[2 * n] * fitPx, v[2 * n + 1] * fitPx))
                                    n++
                                }
                            }
                            sculptRing?.let { (rx, ry, rr) ->
                                drawCircle(c.Warn.copy(alpha = 0.8f), rr * fitPx, Offset(rx * fitPx, ry * fitPx), style = Stroke(width = 2f))
                            }
                            if (pinTool) drawPinGizmos(sel, g0, bw, bh, fitPx, 1f / pose.scale.coerceAtLeast(0.05f), pinSelectedId, pinPreview)
                        }
                    }
                }
            }
            // ค่ามุมหมุน (องศา) และขนาด (% ของขนาดพอดีเฟรม) ของคลิปที่เลือก
            if (sel != null && isActiveAt(sel, playhead)) {
                val p = studioPoseAt(sel, playhead)
                val deg = ((p.rotation % 360f) + 540f) % 360f - 180f
                Text(
                    "↻ ${f1(deg)}°   ⤢ ${(p.scale * 100f).roundToInt()}%" + (if (sel.sizeLocked) " 🔒" else ""),
                    color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.SemiBold,
                    modifier = Modifier.align(Alignment.TopCenter).padding(top = 6.dp)
                        .background(Color(0xAA000000), RoundedCornerShape(8.dp)).padding(horizontal = 8.dp, vertical = 3.dp),
                )
            }
            // ข้อความ/สติกเกอร์
            if ((overlayText.isNotBlank() || overlaySticker.isNotBlank()) && playhead >= overlayStart && playhead < overlayStart + overlayDuration) {
                val textSp = with(density) { (sqPx * 46f / OUT_SIZE).toSp() }
                Column(Modifier.align(Alignment.Center), horizontalAlignment = Alignment.CenterHorizontally) {
                    if (overlaySticker.isNotBlank()) Text(overlaySticker, fontSize = textSp)
                    if (overlayText.isNotBlank()) Text(overlayText, color = Color.White, fontSize = textSp, fontWeight = FontWeight.Bold, maxLines = 1)
                }
            }
        }
    }
}

/**
 * วาดหมุดข้อต่อบนภาพ: จุดแดง = หมุด (ย้ายได้) · เส้น/ปลายเขียว = ทิศส่วนที่ขยับ (ลากปลายเพื่องอ)
 * หมุดที่เลือก: เส้นเขียวจาง = ขอบส่วนที่ขยับเต็มที่ · เส้นส้ม = ขอบส่วนที่นิ่ง (ระหว่างสองเส้นคือช่วงโค้งนุ่ม) วงฟ้า = รัศมีตาข่ายถี่ วงส้ม = ระยะส่งผล
 * ทุกตำแหน่งคิดตามการงอของหมุดแม่ จึงตรงกับที่เห็น
 */
private fun DrawScope.drawPinGizmos(clip: StudioImage, g: SculptGrid?, bw: Int, bh: Int, fit: Float, uiScale: Float, selectedId: Int, preview: List<Float>?) {
    val rig = clip.rig
    val col = StudioColors
    val dp = density * uiScale // ขนาดบนจอคงที่แม้คลิปถูกย่อ/ขยาย (กรอบนี้ถูกสเกลตามคลิป)
    val label = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = android.graphics.Color.WHITE; textSize = 10f * dp; textAlign = Paint.Align.CENTER; typeface = Typeface.DEFAULT_BOLD
    }
    rig.pins.forEachIndexed { k, pin ->
        val sel = pin.id == selectedId
        val (px, py) = JointPins.pinPosition(rig, g, k)
        val (hx, hy) = JointPins.handlePosition(rig, g, k, bw, bh)
        val p0 = Offset(px * fit, py * fit)
        val p1 = Offset(hx * fit, hy * fit)
        if (sel) {
            val anc = JointPins.ancestorsOf(rig.pins, k)
            val len = JointPins.handleLength(pin, bw, bh)
            val psi = pin.soft.coerceIn(JointPins.SOFT_MIN, JointPins.SOFT_MAX)
            for (side in listOf(-1f, 1f)) {
                for ((edge, colour) in listOf((90f - psi) to col.Ok, (90f + psi) to col.Warn)) {
                    val a = Math.toRadians((pin.dirDeg + side * edge).toDouble())
                    val (ex, ey) = JointPins.forward(rig, g, pin.x + (kotlin.math.cos(a) * len).toFloat(), pin.y + (kotlin.math.sin(a) * len).toFloat(), anc)
                    drawLine(colour.copy(alpha = 0.55f), p0, Offset(ex * fit, ey * fit), strokeWidth = 1.5f * dp)
                }
            }
            if (rig.adaptive) drawCircle(col.Accent.copy(alpha = 0.45f), JointPins.meshRadiusOf(pin, bw, bh) * fit, p0, style = Stroke(width = 1f * dp))
            if (pin.reach > 0f) drawCircle(col.Warn.copy(alpha = 0.45f), pin.reach * fit, p0, style = Stroke(width = 1f * dp))
        }
        drawLine(col.Ok, p0, p1, strokeWidth = (if (sel) 3.5f else 2f) * dp)
        drawCircle(col.Ok, (if (sel) 9f else 6.5f) * dp, p1)
        drawCircle(Color.White, (if (sel) 9f else 6.5f) * dp, p1, style = Stroke(width = 1.5f * dp))
        drawCircle(col.Danger, (if (sel) 11f else 9f) * dp, p0)
        drawCircle(Color.White, (if (sel) 11f else 9f) * dp, p0, style = Stroke(width = (if (sel) 2.5f else 1.5f) * dp))
        drawContext.canvas.nativeCanvas.drawText((k + 1).toString(), p0.x, p0.y + label.textSize * 0.35f, label)
    }
    preview?.let { l ->
        if (l.size >= 4) {
            drawLine(col.Ok, Offset(l[0] * fit, l[1] * fit), Offset(l[2] * fit, l[3] * fit), strokeWidth = 3f * dp)
            drawCircle(col.Danger, 10f * dp, Offset(l[0] * fit, l[1] * fit))
            drawCircle(col.Ok, 7f * dp, Offset(l[2] * fit, l[3] * fit))
        }
    }
}

// ───────────────────────── แผงเครื่องมือบิดภาพ / ขนาดวิดีโอ ─────────────────────────

private fun fmtSculptNum(v: Float, decimal: Boolean): String =
    if (!decimal || v == v.toInt().toFloat()) v.toInt().toString() else String.format(java.util.Locale.US, "%.1f", v)

/**
 * ช่องกรอกตัวเลขเล็ก ๆ: ใช้ค่าใหม่ทันทีที่พิมพ์ถูกช่วง lo..hi (พิมพ์ยังไม่ครบ/นอกช่วง = กรอบแดง และยังใช้ค่าเดิมอยู่)
 * ค่าที่เปลี่ยนจากข้างนอก (เช่นเลื่อนสไลเดอร์) จะอัปเดตข้อความในช่อง แต่ไม่ทับสิ่งที่กำลังพิมพ์ (เช่น "1." ก่อนพิมพ์ทศนิยม)
 */
@Composable
private fun SculptNumField(label: String, value: Float, lo: Float, hi: Float, decimal: Boolean, width: Dp, onValid: (Float) -> Unit) {
    val c = StudioColors
    var text by remember { mutableStateOf(fmtSculptNum(value, decimal)) }
    val tol = if (decimal) 0.06f else 0.6f
    LaunchedEffect(value) {
        val now = text.replace(',', '.').toFloatOrNull()
        if (now == null || abs(now - value) > tol) text = fmtSculptNum(value, decimal)
    }
    val parsed = text.replace(',', '.').toFloatOrNull()
    val ok = parsed != null && parsed >= lo && parsed <= hi
    Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
        Text(label, color = c.Sub, fontSize = 10.sp, maxLines = 1)
        BasicTextField(
            value = text,
            onValueChange = { raw ->
                val t = raw.filter { ch -> ch.isDigit() || (decimal && (ch == '.' || ch == ',')) }.take(6)
                text = t
                val n = t.replace(',', '.').toFloatOrNull()
                if (n != null && n >= lo && n <= hi) onValid(n)
            },
            singleLine = true,
            textStyle = TextStyle(color = c.Ink, fontSize = 14.sp),
            cursorBrush = SolidColor(c.Accent),
            keyboardOptions = KeyboardOptions(keyboardType = if (decimal) KeyboardType.Decimal else KeyboardType.Number),
            modifier = Modifier.width(width)
                .background(c.Panel2, RoundedCornerShape(10.dp))
                .border(1.dp, if (ok) c.Line else c.Danger, RoundedCornerShape(10.dp))
                .padding(horizontal = 10.dp, vertical = 7.dp),
        )
    }
}

/** ช่องกรอกตัวเลขที่ติดลบได้ (มุมงอ ฯลฯ): ทำงานเหมือน SculptNumField แต่พิมพ์ "-" นำหน้าได้ */
@Composable
private fun SignedNumField(label: String, value: Float, lo: Float, hi: Float, width: Dp, onValid: (Float) -> Unit) {
    val c = StudioColors
    var text by remember { mutableStateOf(fmtSculptNum(value, true)) }
    LaunchedEffect(value) {
        val now = text.replace(',', '.').toFloatOrNull()
        if (now == null || abs(now - value) > 0.06f) text = fmtSculptNum(value, true)
    }
    val parsed = text.replace(',', '.').toFloatOrNull()
    val ok = parsed != null && parsed >= lo && parsed <= hi
    Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
        Text(label, color = c.Sub, fontSize = 10.sp, maxLines = 1)
        BasicTextField(
            value = text,
            onValueChange = { raw ->
                val t = raw.filterIndexed { idx, ch -> ch.isDigit() || ch == '.' || ch == ',' || (ch == '-' && idx == 0) }.take(7)
                text = t
                val n = t.replace(',', '.').toFloatOrNull()
                if (n != null && n >= lo && n <= hi) onValid(n)
            },
            singleLine = true,
            textStyle = TextStyle(color = c.Ink, fontSize = 14.sp),
            cursorBrush = SolidColor(c.Accent),
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Text),
            modifier = Modifier.width(width)
                .background(c.Panel2, RoundedCornerShape(10.dp))
                .border(1.dp, if (ok) c.Line else c.Danger, RoundedCornerShape(10.dp))
                .padding(horizontal = 10.dp, vertical = 7.dp),
        )
    }
}

/** ป้ายสั้น ๆ คั่นกลุ่มในแผงหมุด */
@Composable
private fun PinHeading(text: String) {
    Text(text, color = StudioColors.Accent, fontSize = 11.sp, fontWeight = FontWeight.Bold)
}

/**
 * แผงหมุดข้อต่ออัจฉริยะ (ในโหมดบิดภาพ > 📍 หมุดข้อต่อ)
 * ส่วนหลัก: เลือก/วางหมุด · มุมงอ (พิมพ์ / เลื่อน / ปุ่มเพิ่มลด) · ทิศ · ความนุ่ม
 * ตั้งค่าละเอียด (พับเก็บได้): ชื่อ · ตำแหน่ง X/Y · ระยะส่งผล · จำกัดมุม · ติดกับหมุดแม่ · ตาข่ายถี่ตามจุด (เปิด/ปิด ความถี่ รัศมี) · แสดงเส้นตาข่าย
 */
@Composable
private fun PinSection(
    clip: StudioImage, grid: SculptGrid?, selectedPinId: Int, placing: Boolean, showMesh: Boolean,
    onPlacing: (Boolean) -> Unit, onSelect: (Int) -> Unit,
    onEdit: (Int, Boolean, (JointPin) -> JointPin) -> Unit,
    onAngle: (Int, Float) -> Unit, onDelete: (Int) -> Unit,
    onRig: (Boolean, (PinRig) -> PinRig) -> Unit,
    onShowMesh: (Boolean) -> Unit, onResetAngles: () -> Unit,
) {
    val c = StudioColors
    val rig = clip.rig
    val pins = rig.pins
    val bw = clip.bitmap.width
    val bh = clip.bitmap.height
    val maxSide = maxOf(bw, bh).toFloat()
    val k = pins.indexOfFirst { it.id == selectedPinId }.let { if (it >= 0) it else if (pins.isNotEmpty()) 0 else -1 }
    var expanded by remember { mutableStateOf(false) }
    fun pinLabel(p: JointPin, idx: Int): String = "${idx + 1}" + if (p.name.isNotBlank()) " ${p.name}" else ""

    Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.CenterVertically) {
        ToolChip(
            if (placing) "แตะที่ข้อต่อบนภาพ…" else "＋ วางหมุด", highlight = placing,
            enabled = !clip.locked && (placing || pins.size < JointPins.MAX_PINS), onClick = { onPlacing(!placing) },
        )
        pins.forEachIndexed { idx, p -> ToolChip("📍 " + pinLabel(p, idx), highlight = idx == k, onClick = { onSelect(p.id); onPlacing(false) }) }
    }

    if (k < 0) {
        Text(
            "วิธีใช้: กด ＋ วางหมุด แล้วแตะที่ข้อต่อบนภาพ (เช่น ข้อศอก เข่า คอ) — ลากต่อไปทางส่วนที่จะขยับเพื่อตั้งทิศได้เลย\n" +
                "จากนั้นลากปลายสีเขียวเพื่องอข้อต่อ หรือพิมพ์มุมในแผงนี้ · ใส่ได้สูงสุด ${JointPins.MAX_PINS} หมุดต่อคลิป · ทุกหมุดทำงานกับท่าบิดและ ◆ Keyframe",
            color = c.Sub, fontSize = 11.sp,
        )
        return
    }

    val pin = pins[k]
    key(pin.id) {
        val a = grid?.angleOf(k) ?: 0f
        val lo = JointPins.minAngle(pin)
        val hi = JointPins.maxAngle(pin)
        val eff = JointPins.effective(rig, bw, bh, grid)
        val folds = if (eff != null) Sculpt.foldCount(bw, bh, eff) else 0
        val canEdit = !clip.locked

        PinHeadingAngle(a, lo, hi, canEdit, onAngle = { v -> onAngle(k, v) }, onReset = onResetAngles)

        if (folds > 0) {
            Text("⚠ ตาข่ายพับ $folds ช่อง — ลดมุมงอ เพิ่ม ‘ความนุ่ม’ หรือย้ายหมุดที่โซนซ้อนกันให้ห่างกัน", color = c.Warn, fontSize = 11.sp)
        } else {
            Text("งอได้ ${lo.roundToInt()}° ถึง +${hi.roundToInt()}° โดยตาข่ายไม่พับ (เพิ่ม ‘ความนุ่ม’ จะงอได้มากขึ้น) · บวก = ตามเข็มบนจอ", color = c.Sub, fontSize = 11.sp)
        }

        PinHeading("ทิศส่วนที่ขยับ (ปลายสีเขียว)")
        Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.Bottom) {
            listOf("→" to 0f, "↘" to 45f, "↓" to 90f, "↙" to 135f, "←" to 180f, "↖" to 225f, "↑" to 270f, "↗" to 315f).forEach { (arrow, deg) ->
                val on = abs(((pin.dirDeg - deg + 540f) % 360f) - 180f) < 1f
                ToolChip(arrow, highlight = on, enabled = canEdit, onClick = { onEdit(pin.id, false) { p -> p.copy(dirDeg = deg) } })
            }
            SculptNumField("ทิศ (°) 0=ขวา 90=ลง", pin.dirDeg, 0f, 360f, true, 150.dp) { v -> onEdit(pin.id, false) { p -> p.copy(dirDeg = v % 360f) } }
        }

        PinHeading("ความนุ่มของข้อต่อ")
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.Bottom, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            SculptNumField("ความนุ่ม (° ${JointPins.SOFT_MIN.roundToInt()}–${JointPins.SOFT_MAX.roundToInt()})", pin.soft, JointPins.SOFT_MIN, JointPins.SOFT_MAX, true, 120.dp) { v ->
                onEdit(pin.id, false) { p -> p.copy(soft = v) }
            }
            Slider(
                value = pin.soft.coerceIn(JointPins.SOFT_MIN, JointPins.SOFT_MAX), onValueChange = { v -> onEdit(pin.id, false) { p -> p.copy(soft = v) } },
                valueRange = JointPins.SOFT_MIN..JointPins.SOFT_MAX, enabled = canEdit, modifier = Modifier.weight(1f),
                colors = SliderDefaults.colors(thumbColor = c.Accent, activeTrackColor = c.Accent, inactiveTrackColor = c.Line),
            )
        }
        Text("น้อย = หักคม (ข้อศอกแข็ง) · มาก = โค้งนุ่ม (หาง งวง คอ) · ยิ่งนุ่มยิ่งงอได้มาก", color = c.Sub, fontSize = 11.sp)

        Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.CenterVertically) {
            ToolChip(if (expanded) "▲ ซ่อนตั้งค่าละเอียด" else "⚙ ตั้งค่าละเอียด", highlight = expanded, onClick = { expanded = !expanded })
            ToolChip("🗑 ลบหมุดนี้", danger = true, enabled = canEdit, onClick = { onDelete(pin.id) })
        }

        if (expanded) {
            PinHeading("หมุดนี้")
            Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.Bottom) {
                var nameText by remember { mutableStateOf(pin.name) }
                Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
                    Text("ชื่อ", color = c.Sub, fontSize = 10.sp)
                    BasicTextField(
                        value = nameText,
                        onValueChange = { raw -> val t = raw.take(12); nameText = t; onEdit(pin.id, false) { p -> p.copy(name = t) } },
                        singleLine = true, enabled = canEdit,
                        textStyle = TextStyle(color = c.Ink, fontSize = 14.sp), cursorBrush = SolidColor(c.Accent),
                        modifier = Modifier.width(120.dp).background(c.Panel2, RoundedCornerShape(10.dp)).border(1.dp, c.Line, RoundedCornerShape(10.dp)).padding(horizontal = 10.dp, vertical = 7.dp),
                    )
                }
                SculptNumField("ตำแหน่ง X (px)", pin.x, 0f, bw.toFloat(), false, 110.dp) { v -> onEdit(pin.id, true) { p -> p.copy(x = v) } }
                SculptNumField("ตำแหน่ง Y (px)", pin.y, 0f, bh.toFloat(), false, 110.dp) { v -> onEdit(pin.id, true) { p -> p.copy(y = v) } }
            }
            Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.Bottom) {
                SculptNumField("ระยะส่งผล px (0 = ทั้งภาพ)", pin.reach, 0f, maxSide * 2f, false, 170.dp) { v -> onEdit(pin.id, false) { p -> p.copy(reach = v) } }
                SignedNumField("จำกัดมุมต่ำสุด (°)", pin.minDeg, -180f, 0f, 150.dp) { v -> onEdit(pin.id, false) { p -> p.copy(minDeg = v) } }
                SignedNumField("จำกัดมุมสูงสุด (°)", pin.maxDeg, 0f, 180f, 150.dp) { v -> onEdit(pin.id, false) { p -> p.copy(maxDeg = v) } }
            }
            Text("ระยะส่งผล: ส่วนที่ไกลจากหมุดเกินนี้จะไม่ขยับตาม (ตั้งให้ ≥ ความยาวแขน/ขา) · จำกัดมุม: เช่น ข้อศอกงอได้ทางเดียว ต่ำสุด 0 สูงสุด 120", color = c.Sub, fontSize = 11.sp)

            PinHeading("ติดกับหมุดแม่ (ส่วนของหมุดแม่พาหมุดนี้ไปด้วย เช่น ไหล่ → ศอก → ข้อมือ)")
            Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.CenterVertically) {
                ToolChip("ไม่ติด", highlight = pin.parentId == 0, enabled = canEdit, onClick = { onEdit(pin.id, false) { p -> p.copy(parentId = 0) } })
                pins.forEachIndexed { idx, other ->
                    if (idx != k && !JointPins.isDescendant(pins, idx, k)) {
                        ToolChip(pinLabel(other, idx), highlight = pin.parentId == other.id, enabled = canEdit, onClick = { onEdit(pin.id, false) { p -> p.copy(parentId = other.id) } })
                    }
                }
            }

            PinHeading("ตาข่ายถี่ตามจุด (Adaptive Mesh)")
            Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.Bottom) {
                ToolChip(if (rig.adaptive) "ถี่ตามจุด: เปิด" else "ถี่ตามจุด: ปิด", highlight = rig.adaptive, enabled = canEdit, onClick = { onRig(true) { r -> r.copy(adaptive = !r.adaptive) } })
                SculptNumField("ความถี่รอบหมุด (0–${JointPins.DENSITY_MAX.roundToInt()})", rig.density, 0f, JointPins.DENSITY_MAX, true, 150.dp) { v -> onRig(true) { r -> r.copy(density = v) } }
                SculptNumField("รัศมีตาข่ายถี่ (px)", JointPins.meshRadiusOf(pin, bw, bh), 10f, maxSide, false, 140.dp) { v -> onEdit(pin.id, true) { p -> p.copy(meshRadius = v) } }
                ToolChip("รัศมีอัตโนมัติ", enabled = canEdit && pin.meshRadius > 0f, onClick = { onEdit(pin.id, true) { p -> p.copy(meshRadius = 0f) } })
            }
            Text("ตาข่ายถี่ขึ้นรอบหมุด (ข้อต่อโค้งกลม ไม่เป็นเหลี่ยม) ที่อื่นห่างลง โดยจำนวนช่องรวมเท่าเดิม · วงฟ้าบนภาพ = รัศมีตาข่ายถี่", color = c.Sub, fontSize = 11.sp)

            Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.CenterVertically) {
                ToolChip(if (showMesh) "เส้นตาข่าย: แสดง" else "เส้นตาข่าย: ซ่อน", highlight = showMesh, onClick = { onShowMesh(!showMesh) })
            }
        }

        Text(
            "ลากจุดแดง = ย้ายหมุด · ลากปลายสีเขียว = งอข้อต่อ · เส้นเขียวจาง/ส้ม = ขอบช่วงโค้ง · ถ้ามี ◆ หลายจุด แต่ละจุดจำมุมของตัวเอง (เล่นแล้วค่อย ๆ งอระหว่างจุด)",
            color = c.Sub, fontSize = 11.sp,
        )
    }
}

/** แถวมุมงอ: ช่องพิมพ์ + ปุ่มเพิ่ม/ลด + รีเซ็ต + แถบเลื่อน */
@Composable
private fun PinHeadingAngle(angle: Float, lo: Float, hi: Float, enabled: Boolean, onAngle: (Float) -> Unit, onReset: () -> Unit) {
    val c = StudioColors
    Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.Bottom) {
        SignedNumField("มุมงอ (°)", angle, lo, hi, 100.dp) { v -> onAngle(v) }
        listOf(-5f, -1f, 1f, 5f).forEach { d ->
            ToolChip(if (d > 0) "+${d.roundToInt()}" else "${d.roundToInt()}", enabled = enabled, onClick = { onAngle((angle + d).coerceIn(lo, hi)) })
        }
        ToolChip("รีเซ็ตมุม", enabled = enabled, onClick = onReset)
    }
    if (hi > lo) {
        Slider(
            value = angle.coerceIn(lo, hi), onValueChange = { v -> onAngle(v) }, valueRange = lo..hi, enabled = enabled,
            colors = SliderDefaults.colors(thumbColor = c.Accent, activeTrackColor = c.Accent, inactiveTrackColor = c.Line),
        )
    }
}

/** แผงโหมดบิดภาพ: เลือกเครื่องมือ (ดึง / Mesh Warp / Twist) + ช่องกรอกค่า รัศมี · วงข้างเคียง · มุมบิด · ขนาดช่องตาข่าย */
@Composable
private fun SculptPanel(
    clip: StudioImage, tool: SculptTool, onTool: (SculptTool) -> Unit,
    brushFrac: Float, onBrush: (Float) -> Unit,
    meshRings: Int, onRings: (Int) -> Unit,
    twistDeg: Float, onTwist: (Float) -> Unit,
    meshCell: Float?, onCell: (Float?) -> Unit,
    onApplyGrid: () -> Unit, onReset: () -> Unit,
    pinContent: @Composable () -> Unit,
) {
    val c = StudioColors
    val bw = clip.bitmap.width
    val bh = clip.bitmap.height
    val (gc, gr) = clipGridDims(clip, meshCell) // ตารางที่คลิปใช้อยู่จริง
    val (pc, pr) = Sculpt.gridDims(bw, bh, meshCell) // ตารางที่จะได้ตามขนาดช่องที่ตั้ง
    val layoutGrid = JointPins.zeroGrid(clip.rig, bw, bh, gc, gr) // ตาข่ายถี่ตามหมุด: ช่องไม่เท่ากัน
    val cellMax = Sculpt.cellMaxPx(bw, bh, layoutGrid)
    val cellMin = Sculpt.cellMinPx(bw, bh, layoutGrid)
    val twistRadius = maxOf(brushFrac * maxOf(bw, bh), 2f * cellMax) // Twist ใช้รัศมีอย่างน้อย 2 ช่อง
    val limitDeg = Math.toDegrees(Sculpt.maxTwist(twistRadius, cellMax).toDouble()).toFloat()
    val twistOver = tool == SculptTool.TWIST && twistDeg > limitDeg
    Column(
        Modifier.fillMaxWidth().heightIn(max = if (tool == SculptTool.PIN) 270.dp else 190.dp).background(c.Panel, RoundedCornerShape(14.dp)).verticalScroll(rememberScrollState()).padding(8.dp),
        verticalArrangement = Arrangement.spacedBy(6.dp),
    ) {
        Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.CenterVertically) {
            ToolChip("✋ ดึง", onClick = { onTool(SculptTool.GRAB) }, highlight = tool == SculptTool.GRAB)
            ToolChip("▦ Mesh Warp", onClick = { onTool(SculptTool.MESH) }, highlight = tool == SculptTool.MESH)
            ToolChip("🌀 Twist", onClick = { onTool(SculptTool.TWIST) }, highlight = tool == SculptTool.TWIST)
            ToolChip("📍 หมุดข้อต่อ", onClick = { onTool(SculptTool.PIN) }, highlight = tool == SculptTool.PIN)
            ToolChip("รีเซ็ตการบิด", enabled = !clip.locked, onClick = onReset)
        }
        if (tool == SculptTool.PIN) {
            pinContent()
        } else {
        if (tool == SculptTool.MESH) {
            SculptNumField("วงข้างเคียงที่ถูกดึงตาม (0–6)", meshRings.toFloat(), 0f, 6f, false, 190.dp) { onRings(it.roundToInt()) }
        } else {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.Bottom, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                SculptNumField("รัศมี (% ของด้านยาว)", brushFrac * 100f, 5f, 100f, true, 130.dp) { onBrush(it / 100f) }
                Slider(
                    value = brushFrac.coerceIn(0.05f, 1f), onValueChange = { onBrush(it) }, valueRange = 0.05f..1f, modifier = Modifier.weight(1f),
                    colors = SliderDefaults.colors(thumbColor = c.Accent, activeTrackColor = c.Accent, inactiveTrackColor = c.Line),
                )
            }
        }
        Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.Bottom) {
            if (tool == SculptTool.TWIST) SculptNumField("มุมสูงสุด (°)", twistDeg, 1f, 720f, true, 100.dp) { onTwist(it) }
            SculptNumField("ขนาดช่องตาข่าย (px)", meshCell ?: cellMax, Sculpt.CELL_MIN, Sculpt.CELL_MAX, false, 140.dp) { onCell(it) }
            ToolChip("อัตโนมัติ", enabled = meshCell != null, onClick = { onCell(null) })
            if (pc != gc || pr != gr) ToolChip("ใช้กับคลิปนี้ → $pc×$pr", highlight = true, enabled = !clip.locked, onClick = onApplyGrid)
        }
        val hint = when (tool) {
            SculptTool.GRAB -> "ลากบนภาพเพื่อดึง"
            SculptTool.MESH -> "แตะลากจุดตาข่าย (จุดฟ้า) ครั้งละไม่เกิน ≈ ${(Sculpt.maxStepRings(cellMin, meshRings)).roundToInt()} px ลากซ้ำเพื่อไปต่อ"
            SculptTool.TWIST -> "แตะจุดศูนย์กลางแล้วลากซ้าย/ขวา (ลากไกล 1 รัศมี = มุมเต็ม) · มุมที่ตาข่ายไม่พับ ≈ ${limitDeg.roundToInt()}°" +
                if (twistOver) " → มุมที่ตั้งไว้จะถูกลดให้เหลือเท่านี้ (เพิ่มรัศมี หรือลดขนาดช่อง จะบิดได้มากขึ้น)" else ""
            SculptTool.PIN -> ""
        }
        Text(
            "$hint\nตาข่ายคลิปนี้ $gc×$gr ช่อง (≈ ${cellMax.roundToInt()} px/ช่อง)" + if (tool == SculptTool.TWIST) " · Twist ใช้รัศมีอย่างน้อย 2 ช่อง" else "",
            color = if (twistOver) c.Warn else c.Sub, fontSize = 11.sp,
        )
        }
    }
}

/** ตั้งเฟรมต่อวินาที (fps) ของ MP4 ที่ส่งออก 1–60: พิมพ์เลข / เลื่อนแถบ / เลือกค่ายอดนิยม · บอกจำนวนเฟรมรวมและผลต่อเวลาส่งออก */
@Composable
private fun FpsDialog(fps: Int, durationSec: Float, onApply: (Int) -> Unit, onDismiss: () -> Unit) {
    val c = StudioColors
    var text by remember { mutableStateOf(fps.toString()) }
    val v = text.toIntOrNull()
    val rangeOk = v != null && v >= 1
    val dur = durationSec.coerceAtLeast(MIN_CLIP_SEC)
    val total = if (rangeOk) (dur * v!!).roundToInt() else 0
    val ok = rangeOk
    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = c.Panel, titleContentColor = c.Ink, textContentColor = c.Ink,
        title = { Text("เฟรมต่อวินาที (FPS)") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(14.dp)) {
                OutlinedTextField(
                    value = text, onValueChange = { raw -> text = raw.filter { ch -> ch.isDigit() }.take(4) },
                    label = { Text("เฟรมต่อวินาที") }, suffix = { Text("fps") }, singleLine = true, isError = !rangeOk,
                    textStyle = TextStyle(fontSize = 26.sp, fontWeight = FontWeight.Bold, color = c.Ink),
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), colors = studioFieldColors(),
                    modifier = Modifier.fillMaxWidth(),
                )
                Slider(
                    value = (v ?: fps).coerceIn(1, 60).toFloat(), onValueChange = { text = it.roundToInt().toString() },
                    valueRange = 1f..60f, steps = 58,
                    colors = SliderDefaults.colors(thumbColor = c.Accent, activeTrackColor = c.Accent, inactiveTrackColor = c.Panel2),
                )
                Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    listOf(12, 15, 24, 30, 48, 60).forEach { p -> ToolChip("$p", highlight = v == p, onClick = { text = p.toString() }) }
                }
                Column(
                    Modifier.fillMaxWidth().background(c.Panel2, RoundedCornerShape(14.dp)).padding(12.dp),
                    verticalArrangement = Arrangement.spacedBy(4.dp),
                ) {
                    if (rangeOk) {
                        Text("1 วินาที = $v เฟรม", color = c.Ink, fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
                        Text("งานนี้ยาว ${f1(dur)} วินาที → รวม $total เฟรม", color = c.Sub, fontSize = 12.sp)
                        if (v!! > 60) Text("เกิน 60: เครื่องบางรุ่นเข้ารหัสไม่ได้ ถ้าส่งออกไม่สำเร็จให้ลดค่าลง", color = c.Warn, fontSize = 12.sp)
                        if (total > 36000) Text("งานยาวมาก ส่งออกอาจใช้เวลานานและกินพื้นที่เครื่อง", color = c.Warn, fontSize = 12.sp)
                        if (v != 30) Text(
                            "ส่งออกใช้เวลาราว ${String.format(java.util.Locale.US, "%.1f", v!! / 30f)}× ของ 30 fps",
                            color = c.Sub, fontSize = 12.sp,
                        )
                        Text("สูงขึ้น = ลื่นขึ้น แต่ส่งออกช้าลงและไฟล์ใหญ่ขึ้น · 24 = แนวหนัง · 30 = ทั่วไป · 60 = ลื่นมาก", color = c.Sub, fontSize = 11.sp)
                    } else {
                        Text("ใส่ตัวเลขตั้งแต่ 1 ขึ้นไป", color = c.Danger, fontSize = 13.sp)
                    }
                }
            }
        },
        confirmButton = { TextButton(enabled = ok, onClick = { onApply(v!!) }) { Text("ตกลง", color = if (ok) c.Accent else c.Sub) } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("ยกเลิก", color = c.Sub) } },
    )
}

/** ตั้งขนาดวิดีโอ [ความสูง] × [ความกว้าง] (px): ผืนผ้าใบเปลี่ยนสัดส่วนตามทันที และเป็นขนาดตอนส่งออก MP4 (บันทึกในโปรเจกต์) */
@Composable
private fun VideoSizeDialog(width: Int, height: Int, onApply: (Int, Int) -> Unit, onDismiss: () -> Unit) {
    val c = StudioColors
    var hText by remember { mutableStateOf(height.toString()) }
    var wText by remember { mutableStateOf(width.toString()) }
    val h = hText.toIntOrNull()
    val w = wText.toIntOrNull()
    val hOk = h != null && h in 64..1920
    val wOk = w != null && w in 64..1920
    val presets = listOf(
        Triple("แนวตั้ง 9:16", 1280, 720), Triple("แนวนอน 16:9", 720, 1280), Triple("จัตุรัส 1:1", 720, 720), Triple("แนวตั้ง 4:5", 900, 720),
    )
    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = c.Panel, titleContentColor = c.Ink, textContentColor = c.Ink,
        title = { Text("ขนาดวิดีโอ") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = hText, onValueChange = { raw -> hText = raw.filter { ch -> ch.isDigit() }.take(4) },
                        label = { Text("สูง") }, suffix = { Text("px") }, singleLine = true, isError = !hOk,
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), colors = studioFieldColors(), modifier = Modifier.weight(1f),
                    )
                    Text("×", color = c.Ink, fontSize = 20.sp)
                    OutlinedTextField(
                        value = wText, onValueChange = { raw -> wText = raw.filter { ch -> ch.isDigit() }.take(4) },
                        label = { Text("กว้าง") }, suffix = { Text("px") }, singleLine = true, isError = !wOk,
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), colors = studioFieldColors(), modifier = Modifier.weight(1f),
                    )
                }
                Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    presets.forEach { (label, ph, pw) -> ToolChip(label, onClick = { hText = ph.toString(); wText = pw.toString() }) }
                }
                Text(
                    if (hOk && wOk) "ส่งออกจริง สูง ${Exporter.videoSize(h!!)} × กว้าง ${Exporter.videoSize(w!!)} px (ปัดเป็นพหุคูณของ 16) · ใส่ได้ 64–1920"
                    else "ใส่ตัวเลข 64–1920 ทั้งสองช่อง",
                    color = if (hOk && wOk) c.Sub else c.Danger, fontSize = 12.sp,
                )
            }
        },
        confirmButton = { TextButton(enabled = hOk && wOk, onClick = { onApply(w!!, h!!) }) { Text("ตกลง", color = if (hOk && wOk) c.Accent else c.Sub) } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("ยกเลิก", color = c.Sub) } },
    )
}

// ───────────────────────── Timeline (ตัวจัดการเลเยอร์) ─────────────────────────

@Composable
private fun StudioTimeline(
    images: SnapshotStateList<StudioImage>,
    layerIds: SnapshotStateList<Int>,
    selectedId: Int,
    activeLayerId: Int,
    playhead: Float,
    zoom: Float,
    timelineEnd: Float,
    playing: Boolean,
    overlayLabel: String,
    overlayStart: Float,
    overlayDuration: Float,
    audioName: String?,
    audioStart: Float,
    onSeek: (Float) -> Unit,
    onSelect: (Int) -> Unit,
    onActiveLane: (Int) -> Unit,
    onNewTopLane: () -> Int,
    onOverlayChange: (Float, Float) -> Unit,
    onAudioStart: (Float) -> Unit,
    onZoom: (Float) -> Unit,
    onAddLane: () -> Unit,
    onAddKeyframe: () -> Unit,
    onDeleteKeyframe: () -> Unit,
    modifier: Modifier = Modifier,
) {
    val c = StudioColors
    val density = LocalDensity.current
    val selectedClip = images.firstOrNull { it.id == selectedId }
    val hScroll = rememberScrollState()
    val vScroll = rememberScrollState()
    val rawPps = with(density) { 56.dp.toPx() } * zoom // พิกเซลต่อวินาทีตามซูม
    val laneH = 50.dp
    val laneGap = 4.dp
    val rowH = laneH + laneGap
    val extraH = 30.dp
    val headerW = 46.dp
    val displayLanes = layerIds.sortedDescending() // แถวบนสุด = แทร็กสูงสุด = อยู่บนสุดของภาพ
    val hasOverlay = overlayLabel.isNotBlank()
    val hasAudio = audioName != null
    val extraRows = (if (hasOverlay) 1 else 0) + (if (hasAudio) 1 else 0)
    val lanesHeight = rowH * displayLanes.size + (extraH + laneGap) * extraRows
    val totalSec = (timelineEnd + 6f).coerceAtLeast(12f).coerceAtMost(MAX_TIMELINE_SEC + 6f)
    val pps = minOf(rawPps, MAX_TIMELINE_PX / totalSec) // งานยาวมาก: จำกัดความกว้างรวมไม่ให้เกินที่วาดได้ (ลดซูมอัตโนมัติ)
    val contentWidth = with(density) { (totalSec * pps).toDp() }
    var viewportPx by remember { mutableIntStateOf(0) }
    val timelineEndNow by rememberUpdatedState(timelineEnd)
    val overlayStartNow by rememberUpdatedState(overlayStart)
    val overlayDurationNow by rememberUpdatedState(overlayDuration)
    val audioStartNow by rememberUpdatedState(audioStart)
    val playheadNow by rememberUpdatedState(playhead)
    val labelPaint = remember(density) {
        Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xFF8E9BB0.toInt(); textSize = with(density) { 10.sp.toPx() } }
    }

    // ตอนเล่น เลื่อน Timeline ตามเส้นเวลา
    LaunchedEffect(playhead, playing) {
        if (playing && viewportPx > 0) {
            val x = playhead * pps
            if (x < hScroll.value || x > hScroll.value + viewportPx - 48f) hScroll.scrollTo((x - viewportPx * 0.2f).toInt().coerceAtLeast(0))
        }
    }

    Column(modifier.background(c.Panel, RoundedCornerShape(16.dp)).padding(8.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
        Row(Modifier.horizontalScroll(rememberScrollState()), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            Text("TIMELINE", color = c.Ink, fontSize = 12.sp, fontWeight = FontWeight.Bold)
            Text("${fmtClock(playhead)} / ${fmtClock(timelineEnd)}", color = c.Accent, fontSize = 12.sp)
            ToolChip("◆＋", highlight = true, enabled = selectedClip != null, onClick = onAddKeyframe)
            ToolChip("◆−", enabled = selectedClip != null && selectedClip.keyframes.isNotEmpty(), onClick = onDeleteKeyframe)
            ToolChip("−", onClick = { onZoom(zoom / 1.25f) })
            Text("${f1(zoom)}×", color = c.Sub, fontSize = 11.sp)
            ToolChip("＋", onClick = { onZoom(zoom * 1.25f) })
            ToolChip("＋ แทร็ก", onClick = onAddLane)
        }

        // ไม้บรรทัดเวลา (แตะ/ลากเพื่อเลื่อนเส้นเวลา)
        Row(verticalAlignment = Alignment.CenterVertically) {
            Spacer(Modifier.width(headerW))
            Box(Modifier.weight(1f).height(24.dp).clip(RoundedCornerShape(6.dp)).background(c.Panel2).horizontalScroll(hScroll, enabled = false)) {
                Box(
                    Modifier.width(contentWidth).fillMaxHeight()
                        .pointerInput(pps) { detectTapGestures { off -> onSeek((off.x / pps).coerceIn(0f, timelineEndNow)) } }
                        .pointerInput(pps) { detectHorizontalDragGestures { change, _ -> change.consume(); onSeek((change.position.x / pps).coerceIn(0f, timelineEndNow)) } },
                ) {
                    androidx.compose.foundation.Canvas(Modifier.fillMaxSize()) {
                        val step = listOf(0.5f, 1f, 2f, 5f, 10f, 20f, 30f).firstOrNull { it * pps >= 64f } ?: 60f
                        var t = 0f
                        while (t <= totalSec) {
                            val x = t * pps
                            drawLine(c.Line, Offset(x, size.height * 0.55f), Offset(x, size.height), 1f)
                            val label = if (t == t.toInt().toFloat()) "${t.toInt()}s" else "${f1(t)}s"
                            drawContext.canvas.nativeCanvas.drawText(label, x + 4f, size.height * 0.5f, labelPaint)
                            t += step
                        }
                    }
                    Box(Modifier.offset(x = with(density) { (playhead * pps).toDp() } - 1.dp).width(2.dp).fillMaxHeight().background(c.PlayRed))
                }
            }
        }

        // แถวแทร็ก
        Row(Modifier.fillMaxWidth().heightIn(max = 230.dp).verticalScroll(vScroll)) {
            Column(Modifier.width(headerW), verticalArrangement = Arrangement.spacedBy(laneGap)) {
                displayLanes.forEachIndexed { row, laneId ->
                    val laneClips = images.filter { it.layerId == laneId }
                    val allHidden = laneClips.isNotEmpty() && laneClips.none { it.visible }
                    Box(
                        Modifier.width(headerW).height(laneH).clip(RoundedCornerShape(8.dp))
                            .background(if (laneId == activeLayerId) c.AccentDim else c.Panel2)
                            .clickable { onActiveLane(laneId) },
                        contentAlignment = Alignment.Center,
                    ) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text("V${displayLanes.size - row}", color = laneTint(laneId), fontSize = 12.sp, fontWeight = FontWeight.Bold)
                            if (laneClips.isEmpty()) {
                                if (displayLanes.size > 1) Text("✕", color = c.Danger, fontSize = 13.sp, modifier = Modifier.clickable { layerIds.remove(laneId) }.padding(horizontal = 6.dp))
                            } else {
                                Text(if (allHidden) "🚫" else "👁", fontSize = 13.sp, modifier = Modifier.clickable {
                                    laneClips.forEach { lc -> val i = images.indexOfFirst { it.id == lc.id }; if (i >= 0) images[i] = images[i].copy(visible = allHidden) }
                                }.padding(horizontal = 6.dp))
                            }
                        }
                    }
                }
                if (hasOverlay) ExtraHeader("T", extraH)
                if (hasAudio) ExtraHeader("♫", extraH)
            }
            Box(Modifier.weight(1f).onSizeChanged { viewportPx = it.width }.horizontalScroll(hScroll)) {
                Box(
                    Modifier.width(contentWidth).height(lanesHeight)
                        .pointerInput(pps) { detectTapGestures { off -> onSeek((off.x / pps).coerceIn(0f, timelineEndNow)) } },
                ) {
                    displayLanes.forEachIndexed { row, laneId ->
                        Box(Modifier.offset(y = rowH * row).fillMaxWidth().height(laneH).background(if (laneId == activeLayerId) c.LaneActive else c.LaneBg, RoundedCornerShape(8.dp)))
                    }
                    images.forEach { clip ->
                        key(clip.id) {
                            val row = displayLanes.indexOf(clip.layerId)
                            if (row >= 0) {
                                TimelineClip(
                                    clip = clip, row = row, pps = pps, laneH = laneH, rowH = rowH,
                                    selected = clip.id == selectedId, tint = laneTint(clip.layerId),
                                    images = images, layerIds = layerIds, playhead = { playheadNow },
                                    onSelect = onSelect, onSeek = onSeek, onNewTopLane = onNewTopLane,
                                )
                            }
                        }
                    }
                    // แถวข้อความ/สติกเกอร์ และเสียง (ลากซ้าย–ขวาเพื่อเปลี่ยนเวลา)
                    var extraIndex = 0
                    if (hasOverlay) {
                        val y = rowH * displayLanes.size + (extraH + laneGap) * extraIndex
                        extraIndex++
                        Box(
                            Modifier.offset(x = with(density) { (overlayStart * pps).toDp() }, y = y)
                                .width(with(density) { (overlayDuration * pps).toDp() }).height(extraH)
                                .clip(RoundedCornerShape(8.dp)).background(c.Warn.copy(alpha = 0.85f))
                                .pointerInput(pps) {
                                    detectHorizontalDragGestures { change, amount ->
                                        change.consume()
                                        val s = safeCoerce(overlayStartNow + amount / pps, 0f, MAX_TIMELINE_SEC - overlayDurationNow)
                                        onOverlayChange(s, overlayDurationNow)
                                    }
                                },
                            contentAlignment = Alignment.CenterStart,
                        ) {
                            Text(overlayLabel, color = Color(0xFF2A1800), fontSize = 11.sp, maxLines = 1, overflow = TextOverflow.Clip, modifier = Modifier.padding(start = 8.dp, end = 16.dp))
                            Box(
                                Modifier.align(Alignment.CenterEnd).width(14.dp).fillMaxHeight().background(Color.Black.copy(alpha = 0.2f))
                                    .pointerInput(pps) {
                                        detectHorizontalDragGestures { change, amount ->
                                            change.consume()
                                            val d = safeCoerce(overlayDurationNow + amount / pps, MIN_CLIP_SEC, MAX_TIMELINE_SEC - overlayStartNow)
                                            onOverlayChange(overlayStartNow, d)
                                        }
                                    },
                                contentAlignment = Alignment.Center,
                            ) { Box(Modifier.width(3.dp).height(16.dp).background(Color.White.copy(alpha = 0.85f), RoundedCornerShape(2.dp))) }
                        }
                    }
                    if (hasAudio) {
                        val y = rowH * displayLanes.size + (extraH + laneGap) * extraIndex
                        val audioLen = maxOf(1f, timelineEnd - audioStart)
                        Box(
                            Modifier.offset(x = with(density) { (audioStart * pps).toDp() }, y = y)
                                .width(with(density) { (audioLen * pps).toDp() }).height(extraH)
                                .clip(RoundedCornerShape(8.dp)).background(c.Ok.copy(alpha = 0.75f))
                                .pointerInput(pps) {
                                    detectHorizontalDragGestures { change, amount ->
                                        change.consume()
                                        onAudioStart(safeCoerce(audioStartNow + amount / pps, 0f, MAX_TIMELINE_SEC))
                                    }
                                },
                            contentAlignment = Alignment.CenterStart,
                        ) { Text("♫ ${audioName ?: ""}", color = Color(0xFF042316), fontSize = 11.sp, maxLines = 1, overflow = TextOverflow.Clip, modifier = Modifier.padding(horizontal = 8.dp)) }
                    }
                    // เส้นเวลา
                    Box(Modifier.zIndex(5f).offset(x = with(density) { (playhead * pps).toDp() } - 1.dp).width(2.dp).fillMaxHeight().background(c.PlayRed))
                }
            }
        }
        Text(
            "แตะเพื่อเลือก · กดค้างแล้วลากซ้าย–ขวาเปลี่ยนเวลา · ลากขึ้น–ลงย้ายแทร็ก · ลากขอบคลิปปรับระยะเวลา · คลิปที่ทับกันซ้อนตามแทร็ก (V สูงอยู่บน)",
            color = c.Sub, fontSize = 10.sp, lineHeight = 13.sp,
        )
    }
}

@Composable
private fun ExtraHeader(label: String, height: Dp) {
    Box(Modifier.width(46.dp).height(height).clip(RoundedCornerShape(8.dp)).background(StudioColors.Panel2), contentAlignment = Alignment.Center) {
        Text(label, color = StudioColors.Sub, fontSize = 13.sp, fontWeight = FontWeight.Bold)
    }
}

@Composable
private fun TimelineClip(
    clip: StudioImage, row: Int, pps: Float, laneH: Dp, rowH: Dp, selected: Boolean, tint: Color,
    images: SnapshotStateList<StudioImage>, layerIds: SnapshotStateList<Int>,
    playhead: () -> Float, onSelect: (Int) -> Unit, onSeek: (Float) -> Unit, onNewTopLane: () -> Int,
) {
    val density = LocalDensity.current
    val latest by rememberUpdatedState(clip)
    val latestRow by rememberUpdatedState(row)
    val latestPps by rememberUpdatedState(pps)
    val latestPlayhead by rememberUpdatedState(playhead)
    var dragging by remember { mutableStateOf(false) }
    val rowPx = with(density) { rowH.toPx() }
    val snapPx = with(density) { 10.dp.toPx() }

    // แม่เหล็ก: ดูดเข้าหาจุดเริ่ม/จบของคลิปอื่น, เส้นเวลา, และจุด 0
    fun magnet(t: Float, ignoreId: Int): Float? {
        val thresh = snapPx / latestPps
        var best: Float? = null
        var bestDist = Float.MAX_VALUE
        fun consider(target: Float) { val d = abs(target - t); if (d < thresh && d < bestDist) { best = target; bestDist = d } }
        consider(0f); consider(latestPlayhead())
        images.forEach { if (it.id != ignoreId) { consider(it.startTime); consider(clipEnd(it)) } }
        return best
    }
    fun roundTenth(t: Float) = (t * 10f).roundToInt() / 10f
    fun setClip(id: Int, block: (StudioImage) -> StudioImage) {
        val i = images.indexOfFirst { it.id == id }
        if (i >= 0) images[i] = block(images[i])
    }

    val widthDp = with(density) { (clip.duration * pps).toDp() }
    val color = if (selected) tint else tint.copy(alpha = 0.7f)
    Box(
        Modifier.offset(x = with(density) { (clip.startTime * pps).toDp() }, y = rowH * row)
            .width(widthDp).height(laneH)
            .zIndex(if (dragging) 3f else if (selected) 1f else 0f)
            .clip(RoundedCornerShape(10.dp))
            .background(color.copy(alpha = 0.35f))
            .border(if (selected) 2.dp else 1.dp, if (selected) Color.White else color, RoundedCornerShape(10.dp))
            .pointerInput(clip.id) { detectTapGestures(onTap = { onSelect(latest.id) }) }
            // กดค้างแล้วลาก: ซ้าย–ขวา = เปลี่ยนเวลา · ขึ้น–ลง = ย้ายแทร็ก
            .pointerInput(clip.id) {
                var startAt = 0f
                var startRow = 0
                var dx = 0f
                var dy = 0f
                var blocked = false
                val created = mutableSetOf<Int>()
                fun finishDrop() {
                    dragging = false
                    val cur = latest
                    // คลิปทับกันในแทร็กเดียวกันไม่ได้: ย้ายไปแทร็กว่างที่ใกล้ที่สุด (ไม่มีก็สร้างแทร็กใหม่ด้านบน)
                    if (!laneIsFree(images, cur.layerId, cur.startTime, cur.duration, cur.id)) {
                        val ids = layerIds.sortedDescending()
                        val rowNow = ids.indexOf(cur.layerId)
                        val order = ids.indices.sortedBy { abs(it - rowNow) * 2 + if (it > rowNow) 1 else 0 }
                        val free = order.map { ids[it] }.firstOrNull { laneIsFree(images, it, cur.startTime, cur.duration, cur.id) }
                        val lane = free ?: onNewTopLane()
                        setClip(cur.id) { it.copy(layerId = lane) }
                    }
                    created.forEach { id -> if (images.none { it.layerId == id } && layerIds.size > 1) layerIds.remove(id) }
                    created.clear()
                }
                detectDragGesturesAfterLongPress(
                    onDragStart = {
                        val cur = latest
                        blocked = cur.locked
                        startAt = cur.startTime
                        startRow = latestRow
                        dx = 0f; dy = 0f
                        created.clear()
                        dragging = true
                        onSelect(cur.id)
                    },
                    onDrag = { change, amount ->
                        change.consume()
                        if (!blocked) {
                            dx += amount.x; dy += amount.y
                            val cur = latest
                            val maxStart = (MAX_TIMELINE_SEC - cur.duration).coerceAtLeast(0f)
                            val raw = safeCoerce(startAt + dx / latestPps, 0f, maxStart)
                            val ms = magnet(raw, cur.id)
                            val me = magnet(raw + cur.duration, cur.id)
                            val newStart = safeCoerce(
                                when { ms != null -> ms; me != null -> me - cur.duration; else -> roundTenth(raw) }, 0f, maxStart,
                            )
                            val shift = (dy / rowPx).roundToInt()
                            if (startRow + shift < 0) { created.add(onNewTopLane()); startRow += 1 }
                            val targetRow = startRow + shift
                            val ids = layerIds.sortedDescending()
                            val laneId = ids[targetRow.coerceIn(0, ids.lastIndex)]
                            setClip(cur.id) { it.copy(startTime = newStart, layerId = laneId) }
                        }
                    },
                    onDragEnd = { finishDrop() },
                    onDragCancel = { finishDrop() },
                )
            },
    ) {
        Image(
            clip.bitmap.asImageBitmap(), null,
            Modifier.fillMaxSize().graphicsLayer(alpha = if (clip.visible) 0.65f else 0.2f),
            contentScale = ContentScale.Crop,
        )
        Box(Modifier.align(Alignment.BottomCenter).fillMaxWidth().height(20.dp).background(Brush.verticalGradient(listOf(Color.Transparent, Color(0xCC000000)))))
        Text(
            "${if (clip.locked) "🔒 " else ""}${if (!clip.visible) "🚫 " else ""}${clipLabel(clip)} · ${f1(clip.duration)}s",
            color = Color.White, fontSize = 10.sp, maxLines = 1, overflow = TextOverflow.Clip,
            modifier = Modifier.align(Alignment.BottomStart).padding(start = 16.dp, end = 16.dp, bottom = 2.dp),
        )
        // ขอบซ้าย: ปรับจุดเริ่ม (จุดจบคงเดิม)
        Box(
            Modifier.align(Alignment.CenterStart).width(14.dp).fillMaxHeight().background(Color.Black.copy(alpha = 0.3f))
                .pointerInput(clip.id) {
                    var baseStart = 0f
                    var baseEnd = 0f
                    var baseKeys: List<StudioKeyframe> = emptyList()
                    var baseOffset = 0f
                    var acc = 0f
                    var blocked = false
                    detectHorizontalDragGestures(
                        onDragStart = {
                            val cur = latest
                            baseStart = cur.startTime; baseEnd = clipEnd(cur); baseKeys = cur.keyframes; baseOffset = cur.videoOffset
                            acc = 0f; blocked = cur.locked
                            onSelect(cur.id)
                        },
                        onHorizontalDrag = { change, amount ->
                            change.consume()
                            acc += amount
                            if (!blocked) {
                                val cur = latest
                                val prevEnd = images.filter { it.id != cur.id && it.layerId == cur.layerId && clipEnd(it) <= baseStart + 0.01f }.maxOfOrNull { clipEnd(it) } ?: 0f
                                val raw = baseStart + acc / latestPps
                                val snapped = magnet(raw, cur.id) ?: roundTenth(raw)
                                val minStart = if (isVideoClip(cur)) maxOf(prevEnd, baseStart - baseOffset) else prevEnd // วิดีโอ: ขยายซ้ายได้ไม่เกินหัวไฟล์
                                val ns = safeCoerce(snapped, minStart, baseEnd - MIN_CLIP_SEC)
                                val nd = baseEnd - ns
                                val shift = ns - baseStart
                                setClip(cur.id) { it.copy(startTime = ns, duration = nd, keyframes = baseKeys.map { k -> k.copy(time = (k.time - shift).coerceIn(0f, nd)) },
                                    videoOffset = if (isVideoClip(it)) (baseOffset + shift).coerceAtLeast(0f) else it.videoOffset) }
                            }
                        },
                    )
                },
            contentAlignment = Alignment.Center,
        ) { Box(Modifier.width(3.dp).height(22.dp).background(Color.White.copy(alpha = 0.85f), RoundedCornerShape(2.dp))) }
        // ขอบขวา: ปรับระยะเวลา
        Box(
            Modifier.align(Alignment.CenterEnd).width(14.dp).fillMaxHeight().background(Color.Black.copy(alpha = 0.3f))
                .pointerInput(clip.id) {
                    var baseDuration = 0f
                    var acc = 0f
                    var blocked = false
                    detectHorizontalDragGestures(
                        onDragStart = {
                            val cur = latest
                            baseDuration = cur.duration; acc = 0f; blocked = cur.locked
                            onSelect(cur.id)
                        },
                        onHorizontalDrag = { change, amount ->
                            change.consume()
                            acc += amount
                            if (!blocked) {
                                val cur = latest
                                val nextStart = images.filter { it.id != cur.id && it.layerId == cur.layerId && it.startTime >= cur.startTime + 0.01f }.minOfOrNull { it.startTime } ?: MAX_TIMELINE_SEC
                                val srcEnd = if (isVideoClip(cur)) cur.startTime + (cur.videoLength - cur.videoOffset) else Float.MAX_VALUE // วิดีโอ: ยืดเกินความยาวไฟล์ไม่ได้
                                val maxEnd = minOf(nextStart, MAX_TIMELINE_SEC, srcEnd)
                                val raw = cur.startTime + baseDuration + acc / latestPps
                                val snapped = magnet(raw, cur.id) ?: roundTenth(raw)
                                val end = safeCoerce(snapped, cur.startTime + MIN_CLIP_SEC, maxEnd)
                                setClip(cur.id) { it.copy(duration = end - cur.startTime) }
                            }
                        },
                    )
                },
            contentAlignment = Alignment.Center,
        ) { Box(Modifier.width(3.dp).height(22.dp).background(Color.White.copy(alpha = 0.85f), RoundedCornerShape(2.dp))) }
        // จุด Keyframe (◆): แตะเพื่อเลือกคลิปและเลื่อนเส้นเวลาไปที่จุดนั้น · จุดที่เส้นเวลาอยู่ตอนนี้เป็นสีฟ้า
        clip.keyframes.forEach { k ->
            val halfPx = with(density) { 15.dp.toPx() }
            val xPx = safeCoerce(k.time * pps, halfPx, clip.duration * pps - halfPx)
            val atPlayhead = selected && abs(k.time - (latestPlayhead() - clip.startTime)) < 0.05f
            Box(
                Modifier.align(Alignment.TopStart)
                    .offset(x = with(density) { (xPx - halfPx).toDp() })
                    .size(30.dp)
                    .pointerInput(clip.id, k.time) {
                        detectTapGestures(onTap = { onSelect(latest.id); onSeek(latest.startTime + k.time) })
                    },
                contentAlignment = Alignment.Center,
            ) {
                Box(
                    Modifier.size(20.dp).graphicsLayer(rotationZ = 45f)
                        .background(if (atPlayhead) StudioColors.Accent else StudioColors.Warn)
                        .border(1.5.dp, Color(0xFF1A1200)),
                )
            }
        }
    }
}

// ───────────────────────── ตัวอย่างการเคลื่อนไหวของสไตล์ที่เลือก ─────────────────────────

/** กรอบเล็กเล่นวนซ้ำ: ใช้ค่าจาก presetKeyframes และวิธีวาดเดียวกับ Canvas หลัก (หน่วยโลก 600 ต่อด้านสั้นของเฟรม) */
@Composable
private fun MotionPreview(bitmap: Bitmap, preset: String) {
    val c = StudioColors
    val density = LocalDensity.current
    val period = 2f
    var t by remember { mutableFloatStateOf(0f) }
    LaunchedEffect(Unit) {
        var last = withFrameNanos { it }
        while (true) {
            val now = withFrameNanos { it }
            t = (t + (now - last) / 1_000_000_000f) % period
            last = now
        }
    }
    val keys = remember(preset) { presetKeyframes(period, preset) }
    val a = keys.first()
    val b = keys.last()
    val f = (t / period).coerceIn(0f, 1f)
    val side = 140.dp
    val unit = with(density) { side.toPx() } / Exporter.WORLD_WINDOW
    Box(Modifier.size(side).clip(RoundedCornerShape(12.dp)).background(Color.Black).border(1.dp, c.Line, RoundedCornerShape(12.dp))) {
        Image(
            bitmap.asImageBitmap(), null,
            Modifier.fillMaxSize().graphicsLayer(
                translationX = (a.x + (b.x - a.x) * f) * unit, translationY = (a.y + (b.y - a.y) * f) * unit,
                scaleX = a.scale + (b.scale - a.scale) * f, scaleY = a.scale + (b.scale - a.scale) * f,
                rotationZ = a.rotation + (b.rotation - a.rotation) * f,
            ),
            contentScale = ContentScale.Fit,
        )
    }
}

// ───────────────────────── กล่องโต้ตอบ: ปรับแต่งคลิป ─────────────────────────

@Composable
private fun ClipPropertiesDialog(
    clip: StudioImage, playhead: Float, animationMode: Boolean, motionPreset: String,
    onUpdate: ((StudioImage) -> StudioImage) -> Unit,
    onAnimationMode: (Boolean) -> Unit, onPreset: (String) -> Unit,
    onStatus: (String) -> Unit, onDismiss: () -> Unit,
) {
    val c = StudioColors
    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = c.Panel, titleContentColor = c.Ink, textContentColor = c.Ink,
        title = { Text("ปรับแต่งคลิป") },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(value = clip.name, onValueChange = { v -> onUpdate { it.copy(name = v) } }, label = { Text("ชื่อคลิป") }, singleLine = true, colors = studioFieldColors())
                Text("เริ่ม ${f1(clip.startTime)} วิ · ยาว ${f1(clip.duration)} วิ · จบ ${f1(clipEnd(clip))} วิ", color = c.Sub, fontSize = 12.sp)
                Text("ความทึบ ${(clip.opacity * 100).toInt()}%", color = c.Ink, fontSize = 13.sp)
                Slider(
                    value = clip.opacity, onValueChange = { v -> onUpdate { it.copy(opacity = v) } }, valueRange = 0f..1f,
                    colors = SliderDefaults.colors(thumbColor = c.Accent, activeTrackColor = c.Accent, inactiveTrackColor = c.Line),
                )
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    ToolChip("รีเซ็ตตำแหน่ง/ขนาด", onClick = { onUpdate { it.copy(x = 0f, y = 0f, scale = 1f, rotation = 0f, opacity = 1f, keyframes = emptyList()) } }, enabled = !clip.locked)
                }
                Spacer(Modifier.height(2.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text("โหมดภาพเคลื่อนไหว", color = c.Ink, fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
                        Text("ภาพที่เพิ่มใหม่จะได้ Keyframe ตามสไตล์ที่เลือกอัตโนมัติ", color = c.Sub, fontSize = 11.sp)
                    }
                    Switch(checked = animationMode, onCheckedChange = onAnimationMode)
                }
                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    listOf("เลื่อนภาพ", "หมุนเบาๆ", "เลื่อนและหมุน").forEach { preset ->
                        ToolChip(preset, highlight = motionPreset == preset, onClick = { onPreset(preset) })
                    }
                }
                Text("ตัวอย่าง: $motionPreset (วนซ้ำทุก 2 วินาที)", color = c.Sub, fontSize = 11.sp)
                Box(Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) { MotionPreview(clip.bitmap, motionPreset) }
                ToolChip("ใส่การเคลื่อนไหวให้คลิปนี้", enabled = !clip.locked, onClick = {
                    onUpdate { it.copy(keyframes = presetKeyframes(it.duration, motionPreset).map { k -> k.copy(sculpt = it.sculpt) }) }
                    onStatus("ใส่การเคลื่อนไหว \"$motionPreset\" แล้ว")
                })
            }
        },
        confirmButton = { TextButton(onClick = onDismiss) { Text("เสร็จสิ้น", color = c.Accent) } },
    )
}

// ───────────────────────── กล่องโต้ตอบ: ข้อความ/สติกเกอร์/เสียง ─────────────────────────

@Composable
private fun ExtrasDialog(
    overlayText: String, overlaySticker: String, audioName: String?, audioVolume: Float,
    onText: (String) -> Unit, onSticker: (String) -> Unit, onClearOverlay: () -> Unit,
    onVolume: (Float) -> Unit, onPickAudio: () -> Unit, onRemoveAudio: () -> Unit, onDismiss: () -> Unit,
) {
    val c = StudioColors
    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = c.Panel, titleContentColor = c.Ink, textContentColor = c.Ink,
        title = { Text("ข้อความ สติกเกอร์ และเสียง") },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(value = overlayText, onValueChange = onText, label = { Text("ข้อความบนภาพ") }, singleLine = true, colors = studioFieldColors())
                Text("สติกเกอร์", color = c.Sub, fontSize = 12.sp)
                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    listOf("⭐", "❤️", "✨", "🔥", "🌟").forEach { s -> ToolChip(s, highlight = overlaySticker == s, onClick = { onSticker(s) }) }
                }
                ToolChip("ล้างข้อความ/สติกเกอร์", danger = true, onClick = onClearOverlay)
                Text("ลากแถบสีส้ม (T) บน Timeline เพื่อกำหนดเวลา และลากขอบขวาเพื่อปรับความยาว", color = c.Sub, fontSize = 11.sp)
                Spacer(Modifier.height(4.dp))
                Text("เสียง", color = c.Ink, fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
                if (audioName != null) {
                    Text("♫ $audioName", color = c.Ok, fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    Text("ระดับเสียง ${(audioVolume * 100).toInt()}%", color = c.Ink, fontSize = 13.sp)
                    Slider(value = audioVolume, onValueChange = onVolume, valueRange = 0f..1f, colors = SliderDefaults.colors(thumbColor = c.Ok, activeTrackColor = c.Ok, inactiveTrackColor = c.Line))
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        ToolChip("เปลี่ยนไฟล์เสียง", onClick = onPickAudio)
                        ToolChip("ลบเสียง", danger = true, onClick = onRemoveAudio)
                    }
                    Text("ลากแถบสีเขียว (♫) บน Timeline เพื่อกำหนดเวลาเริ่มเสียง", color = c.Sub, fontSize = 11.sp)
                } else {
                    ToolChip("＋ เพิ่มไฟล์เสียง", onClick = onPickAudio, highlight = true)
                }
            }
        },
        confirmButton = { TextButton(onClick = onDismiss) { Text("เสร็จสิ้น", color = c.Accent) } },
    )
}

// ───────────────────────── ตั้งค่า ─────────────────────────

@Composable
fun ImageStudioSettings(onOpen: () -> Unit) {
    val context = LocalContext.current
    var enabled by remember { mutableStateOf(ImageStudioPrefs.enabled(context)) }
    var ask by remember { mutableStateOf(ImageStudioPrefs.ask(context)) }
    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Text("โหมดรูปภาพ", style = MaterialTheme.typography.titleSmall, color = MaterialTheme.colorScheme.primary)
        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text("เปิดใช้งานโหมดรูปภาพ")
                Text("สร้างวิดีโอและแอนิเมชันจากภาพนิ่ง", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            Switch(checked = enabled, onCheckedChange = { enabled = it; ImageStudioPrefs.setEnabled(context, it) })
        }
        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text("ถามก่อนเริ่มทำ")
                Text("แสดงหน้าต่างยืนยันก่อนเข้าโหมด", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            Switch(checked = ask, onCheckedChange = { ask = it; ImageStudioPrefs.setAsk(context, it) }, enabled = enabled)
        }
        OutlinedButton(onClick = onOpen, enabled = enabled, modifier = Modifier.fillMaxWidth()) { Text("เปิดโหมดรูปภาพ") }
    }
}
