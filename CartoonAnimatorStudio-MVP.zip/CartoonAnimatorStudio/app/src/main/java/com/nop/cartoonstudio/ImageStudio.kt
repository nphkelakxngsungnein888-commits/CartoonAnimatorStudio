package com.nop.cartoonstudio

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import kotlin.math.max
import kotlin.math.min

object ImageStudioPrefs {
    private const val FILE = "image_studio_settings"
    private const val ENABLED = "enabled"
    private const val ASK = "ask_before_start"
    fun enabled(context: Context) = context.getSharedPreferences(FILE, Context.MODE_PRIVATE).getBoolean(ENABLED, true)
    fun setEnabled(context: Context, value: Boolean) { context.getSharedPreferences(FILE, Context.MODE_PRIVATE).edit().putBoolean(ENABLED, value).apply() }
    fun ask(context: Context) = context.getSharedPreferences(FILE, Context.MODE_PRIVATE).getBoolean(ASK, true)
    fun setAsk(context: Context, value: Boolean) { context.getSharedPreferences(FILE, Context.MODE_PRIVATE).edit().putBoolean(ASK, value).apply() }
}

private data class StudioKeyframe(
    val time: Float, val x: Float, val y: Float, val scale: Float, val rotation: Float, val opacity: Float,
)

private data class StudioImage(
    val id: Int, val file: File, val bitmap: Bitmap, val duration: Float = 3f,
    val x: Float = 0f, val y: Float = 0f, val scale: Float = 1f,
    val rotation: Float = 0f, val opacity: Float = 1f, val visible: Boolean = true,
    val startTime: Float = 0f, val keyframes: List<StudioKeyframe> = emptyList(),
)

@Composable
fun ImageStudioScreen(onBack: () -> Unit) {
    val context = LocalContext.current
    val projects = remember { mutableStateListOf<ImageStudioProject>() }
    var activeProjectId by remember { mutableStateOf<String?>(null) }
    var showCreate by remember { mutableStateOf(false) }
    var newName by remember { mutableStateOf("โปรเจกต์รูปภาพ") }
    var message by remember { mutableStateOf<String?>(null) }

    fun refreshProjects() {
        projects.clear()
        projects.addAll(ImageStudioProjectStore.list(context))
    }
    LaunchedEffect(Unit) { refreshProjects() }

    val activeId = activeProjectId
    if (activeId != null) {
        ImageStudioEditorScreen(projectId = activeId, onBack = { activeProjectId = null; refreshProjects() })
        return
    }

    Column(Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background).systemBarsPadding().padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            TextButton(onClick = onBack) { Text("‹ กลับ") }
            Text("Image Studio", style = MaterialTheme.typography.titleLarge, modifier = Modifier.weight(1f))
        }
        Text("โปรเจกต์รูปภาพ", style = MaterialTheme.typography.headlineSmall)
        Text("เปิดงานล่าสุดหรือสร้างโปรเจกต์ใหม่เพื่อเริ่มตัดต่อภาพและวิดีโอ", style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Button(onClick = { newName = "โปรเจกต์รูปภาพ"; showCreate = true }, modifier = Modifier.fillMaxWidth()) { Text("＋ สร้างโปรเจกต์ใหม่") }
        if (projects.isEmpty()) {
            Box(Modifier.weight(1f).fillMaxWidth(), contentAlignment = Alignment.Center) {
                Text("ยังไม่มีโปรเจกต์\nกดสร้างโปรเจกต์ใหม่เพื่อเริ่มต้น", color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        } else {
            Text("โปรเจกต์ล่าสุด", style = MaterialTheme.typography.titleMedium)
            LazyColumn(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                itemsIndexed(projects, key = { _, item -> item.id }) { _, project ->
                    Card(Modifier.fillMaxWidth()) {
                        Row(Modifier.fillMaxWidth().padding(12.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                            Column(Modifier.weight(1f)) {
                                Text(project.name, style = MaterialTheme.typography.titleMedium)
                                Text("${project.imageCount} ภาพ · แก้ไข ${java.text.DateFormat.getDateTimeInstance().format(java.util.Date(project.updatedAt))}", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                            TextButton(onClick = { activeProjectId = project.id }) { Text("เปิด") }
                            TextButton(onClick = { ImageStudioProjectStore.delete(context, project.id); refreshProjects() }) { Text("ลบ") }
                        }
                    }
                }
            }
        }
        message?.let { Text(it, color = MaterialTheme.colorScheme.error) }
    }
    if (showCreate) {
        AlertDialog(
            onDismissRequest = { showCreate = false },
            title = { Text("สร้างโปรเจกต์ใหม่") },
            text = { OutlinedTextField(value = newName, onValueChange = { newName = it }, label = { Text("ชื่อโปรเจกต์") }, singleLine = true) },
            confirmButton = { TextButton(onClick = {
                runCatching { ImageStudioProjectStore.create(context, newName) }
                    .onSuccess { project -> refreshProjects(); showCreate = false; activeProjectId = project.id }
                    .onFailure { message = "สร้างโปรเจกต์ไม่สำเร็จ: ${it.message}" }
            }) { Text("สร้าง") } },
            dismissButton = { TextButton(onClick = { showCreate = false }) { Text("ยกเลิก") } },
        )
    }
}

@Composable
private fun ImageStudioEditorScreen(projectId: String, onBack: () -> Unit) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val images = remember { mutableStateListOf<StudioImage>() }
    var selected by remember { mutableIntStateOf(0) }
    var playhead by remember { mutableFloatStateOf(0f) }
    var animationMode by remember { mutableStateOf(false) }
    var motionPreset by remember { mutableStateOf("เลื่อนภาพ") }
    var busy by remember { mutableStateOf(false) }
    var previewPlaying by remember { mutableStateOf(false) }
    var status by remember { mutableStateOf<String?>(null) }
    var loadingProject by remember { mutableStateOf(true) }
    var projectLoaded by remember { mutableStateOf(false) }
    LaunchedEffect(projectId) {
        loadingProject = true
        runCatching { ImageStudioProjectStore.loadImages(context, projectId) }
            .onSuccess { loaded ->
                images.forEach { if (!it.bitmap.isRecycled) it.bitmap.recycle() }
                images.clear()
                loaded.forEach { (record, bitmap) -> images.add(StudioImage(record.id, File(context.filesDir, "image_studio/projects/$projectId/images/${record.fileName}"), bitmap, record.duration, record.x, record.y, record.scale, record.rotation, record.opacity, record.visible, record.startTime, record.keyframes.map { StudioKeyframe(it.time, it.x, it.y, it.scale, it.rotation, it.opacity) })) }
                val settings = ImageStudioProjectStore.loadSettings(context, projectId)
                animationMode = settings.first
                motionPreset = settings.second
                projectLoaded = true
            }
            .onFailure { status = "เปิดโปรเจกต์ไม่สำเร็จ: ${it.message}"; projectLoaded = false }
        loadingProject = false
    }
    LaunchedEffect(images.map { it.id }.joinToString(","), images.map { "${it.duration}:${it.x}:${it.y}:${it.scale}:${it.rotation}:${it.opacity}:${it.visible}:${it.startTime}:${it.keyframes}" }.joinToString(","), animationMode, motionPreset, loadingProject) {
        if (!loadingProject && projectLoaded) {
            delay(650)
            runCatching { ImageStudioProjectStore.save(context, projectId, images.map { ImageStudioImageRecord(it.id, it.file.name, it.duration, it.x, it.y, it.scale, it.rotation, it.opacity, it.visible, it.startTime, it.keyframes.map { k -> ImageStudioKeyframeRecord(k.time, k.x, k.y, k.scale, k.rotation, k.opacity) }) }, animationMode, motionPreset) }
                .onFailure { status = "บันทึกอัตโนมัติไม่สำเร็จ: ${it.message}" }
        }
    }
    LaunchedEffect(previewPlaying, images.map { "${it.startTime}:${it.duration}" }.joinToString(",")) {
        while (previewPlaying && images.isNotEmpty()) {
            val end = (images.maxOfOrNull { it.startTime + it.duration } ?: 1f).coerceAtLeast(1f)
            delay(100L)
            playhead += 0.1f
            if (playhead > end) playhead = 0f
            val active = images.indexOfLast { playhead >= it.startTime && playhead < it.startTime + it.duration }
            if (active >= 0) selected = active
        }
    }
    val previewTransition = rememberInfiniteTransition(label = "image-preview")
    val previewMotion by previewTransition.animateFloat(
        initialValue = -1f, targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(1800), RepeatMode.Reverse), label = "preview-motion",
    )
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { uris ->
        uris.forEach { uri ->
            if (images.size >= 30) { status = "เพิ่มได้สูงสุด 30 ภาพต่อหนึ่งงาน"; return@forEach }
            runCatching {
                val input = context.contentResolver.openInputStream(uri)
                    ?: throw IllegalArgumentException("อ่านไฟล์ภาพไม่ได้")
                val nextId = (images.maxOfOrNull { it.id } ?: 0) + 1
                val file = ImageStudioProjectStore.importImage(context, projectId, nextId, uri.lastPathSegment ?: "image.png", input)
                val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
                BitmapFactory.decodeFile(file.absolutePath, bounds)
                if (bounds.outWidth <= 0 || bounds.outHeight <= 0) throw IllegalArgumentException("ไฟล์ภาพไม่ถูกต้อง")
                var sample = 1
                while (max(bounds.outWidth, bounds.outHeight) / sample > 1600) sample *= 2
                val opts = BitmapFactory.Options().apply { inSampleSize = sample; inPreferredConfig = Bitmap.Config.ARGB_8888 }
                val bmp = BitmapFactory.decodeFile(file.absolutePath, opts) ?: throw IllegalArgumentException("อ่านไฟล์ภาพไม่ได้")
                images.add(StudioImage(nextId, file, bmp, startTime = images.maxOfOrNull { it.startTime + it.duration } ?: 0f))
            }.onFailure { status = "เปิดรูปภาพไม่สำเร็จ: ${it.message}" }
        }
    }

    Column(Modifier.fillMaxSize().background(androidx.compose.ui.graphics.Color(0xFF101318)).systemBarsPadding().padding(horizontal = 10.dp, vertical = 8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        // Compact studio header: navigation, project workspace identity, and render status.
        Row(Modifier.fillMaxWidth().background(androidx.compose.ui.graphics.Color(0xFF1B2028), RoundedCornerShape(14.dp)).padding(horizontal = 8.dp, vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
            TextButton(onClick = onBack, enabled = !busy) { Text("‹ โปรเจกต์", color = androidx.compose.ui.graphics.Color(0xFFE4EAF3)) }
            Column(Modifier.weight(1f)) {
                Text("IMAGE STUDIO", style = MaterialTheme.typography.titleSmall, color = androidx.compose.ui.graphics.Color(0xFFF2F5FA))
                Text("EDITOR WORKSPACE", style = MaterialTheme.typography.labelSmall, color = androidx.compose.ui.graphics.Color(0xFF91A0B5))
            }
            if (busy) CircularProgressIndicator(Modifier.size(22.dp), strokeWidth = 2.dp)
            else Text("●", color = androidx.compose.ui.graphics.Color(0xFF5AD6A0), modifier = Modifier.padding(horizontal = 10.dp))
        }
        if (loadingProject) { LinearProgressIndicator(Modifier.fillMaxWidth()) }
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            FilterChip(selected = !animationMode, onClick = { animationMode = false }, label = { Text("วิดีโอจากภาพ") })
            FilterChip(selected = animationMode, onClick = { animationMode = true }, label = { Text("ภาพเคลื่อนไหว") })
        }
        if (animationMode) {
            Text("โหมดภาพเคลื่อนไหว: สร้างการเคลื่อนภาพแบบ Keyframe อัตโนมัติจากภาพนิ่ง", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                listOf("เลื่อนภาพ", "หมุนเบาๆ", "เลื่อนและหมุน").forEach { preset ->
                    FilterChip(selected = motionPreset == preset, onClick = { motionPreset = preset }, label = { Text(preset) })
                }
            }
        } else Text("รวมภาพหลายภาพ เรียงลำดับ และกำหนดเวลาของแต่ละภาพ", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
            Button(onClick = { picker.launch(arrayOf("image/*")) }, enabled = !busy && !loadingProject) { Text("＋ เพิ่มสื่อ") }
            OutlinedButton(onClick = { previewPlaying = !previewPlaying }, enabled = images.isNotEmpty() && !busy) { Text(if (previewPlaying) "Ⅱ หยุด" else "▶ เล่น") }
            OutlinedButton(onClick = { previewPlaying = false; images.forEach { it.bitmap.recycle() }; images.clear(); selected = 0 }, enabled = images.isNotEmpty() && !busy) { Text("ล้างทั้งหมด") }
        }
        if (images.isEmpty()) {
            Box(Modifier.weight(1f).fillMaxWidth(), contentAlignment = Alignment.Center) {
                Text("ยังไม่มีรูปภาพ\nกด ‘เพิ่มรูปภาพ’ เพื่อเริ่มต้น", color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        } else {
            val current = images.getOrNull(selected.coerceIn(0, images.lastIndex))
            current?.let { currentImage ->
                val animatedPose = studioPoseAt(currentImage, playhead)
                Box(
                    Modifier.fillMaxWidth().weight(1f).background(androidx.compose.ui.graphics.Color(0xFF202733), RoundedCornerShape(18.dp)).padding(10.dp),
                    contentAlignment = Alignment.Center,
                ) {
                    Box(Modifier.fillMaxSize().background(androidx.compose.ui.graphics.Color(0xFF11161D), RoundedCornerShape(12.dp)).padding(8.dp), contentAlignment = Alignment.Center) {
                    if (currentImage.visible) Image(
                        currentImage.bitmap.asImageBitmap(), null,
                        Modifier.fillMaxSize().graphicsLayer(
                            translationX = animatedPose.x + if (animationMode && motionPreset != "หมุนเบาๆ" && currentImage.keyframes.isEmpty()) previewMotion * 18f else 0f,
                            translationY = animatedPose.y + if (animationMode && motionPreset == "เลื่อนและหมุน" && currentImage.keyframes.isEmpty()) previewMotion * 8f else 0f,
                            scaleX = animatedPose.scale, scaleY = animatedPose.scale,
                            rotationZ = animatedPose.rotation + if (animationMode && motionPreset != "เลื่อนภาพ" && currentImage.keyframes.isEmpty()) previewMotion * 3f else 0f,
                            alpha = animatedPose.opacity,
                        ), contentScale = androidx.compose.ui.layout.ContentScale.Fit,
                    ) else Text("เลเยอร์นี้ถูกซ่อน", color = androidx.compose.ui.graphics.Color(0xFFB8C4D4))
                    }
                }
                Text("CANVAS  ·  ภาพที่ ${selected + 1} / ${images.size} · ${currentImage.bitmap.width} × ${currentImage.bitmap.height} px", style = MaterialTheme.typography.bodySmall, color = androidx.compose.ui.graphics.Color(0xFFB8C4D4))
        if (images.isNotEmpty()) {
            val timelineEnd = (images.maxOfOrNull { it.startTime + it.duration } ?: 1f).coerceAtLeast(1f)
            Card(Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = androidx.compose.ui.graphics.Color(0xFF1B2028))) {
                Column(Modifier.fillMaxWidth().padding(10.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("TIMELINE  ·  ${images.size} TRACKS", style = MaterialTheme.typography.titleSmall, color = androidx.compose.ui.graphics.Color(0xFFF2F5FA), modifier = Modifier.weight(1f))
                        Text("${"%.1f".format(playhead)} / ${"%.1f".format(timelineEnd)} วิ", style = MaterialTheme.typography.bodySmall)
                    }
                    Slider(value = playhead.coerceIn(0f, timelineEnd), onValueChange = { value ->
                        playhead = value
                        val active = images.indexOfLast { value >= it.startTime && value <= it.startTime + it.duration }
                        if (active >= 0) selected = active
                    }, valueRange = 0f..timelineEnd)
                    images.forEachIndexed { index, track ->
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            Text("${if (selected == index) "●" else "○"} T${index + 1}", modifier = Modifier.width(38.dp), style = MaterialTheme.typography.bodySmall)
                            Column(Modifier.weight(1f)) {
                                Text("${"%.1f".format(track.startTime)}s — ${"%.1f".format(track.startTime + track.duration)}s", style = MaterialTheme.typography.labelSmall)
                                Box(Modifier.fillMaxWidth().height(10.dp).background(MaterialTheme.colorScheme.surfaceVariant, RoundedCornerShape(5.dp))) {
                                    val left = (track.startTime / timelineEnd).coerceIn(0f, 1f)
                                    val width = (track.duration / timelineEnd).coerceIn(0f, 1f - left)
                                    Row(Modifier.fillMaxWidth()) {
                                        Spacer(Modifier.weight(left.coerceAtLeast(0.001f)))
                                        Box(Modifier.weight(width.coerceAtLeast(0.001f)).fillMaxHeight().background(if (selected == index) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.secondary, RoundedCornerShape(5.dp)))
                                        Spacer(Modifier.weight((1f - left - width).coerceAtLeast(0.001f)))
                                    }
                                }
                            }
                            TextButton(onClick = { images[index] = track.copy(startTime = (track.startTime - 0.5f).coerceAtLeast(0f)) }) { Text("−") }
                            TextButton(onClick = { images[index] = track.copy(startTime = (track.startTime + 0.5f).coerceAtMost(600f)) }) { Text("＋") }
                        }
                    }
                    Text("แต่ละแทร็กปรับเวลาเริ่มต้นและระยะเวลาแยกกันได้ · เลือกแทร็กเพื่อแก้ไขภาพ", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
        }
            Card(Modifier.fillMaxWidth()) {
                Column(Modifier.fillMaxWidth().padding(10.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("คุณสมบัติเลเยอร์ · ภาพ ${selected + 1}", style = MaterialTheme.typography.titleSmall, modifier = Modifier.weight(1f))
                        TextButton(onClick = { images[selected] = currentImage.copy(x = 0f, y = 0f, scale = 1f, rotation = 0f, opacity = 1f) }) { Text("รีเซ็ต") }
                        TextButton(onClick = { images[selected] = currentImage.copy(visible = !currentImage.visible) }) { Text(if (currentImage.visible) "ซ่อน" else "แสดง") }
                    }
                    Text("ขนาด ${(currentImage.scale * 100).toInt()}%", style = MaterialTheme.typography.bodySmall)
                    Slider(value = currentImage.scale, onValueChange = { images[selected] = currentImage.copy(scale = it) }, valueRange = 0.2f..3f)
                    Text("หมุน ${currentImage.rotation.toInt()}°", style = MaterialTheme.typography.bodySmall)
                    Slider(value = currentImage.rotation, onValueChange = { images[selected] = currentImage.copy(rotation = it) }, valueRange = -180f..180f)
                    Text("ตำแหน่งแนวนอน ${currentImage.x.toInt()} px", style = MaterialTheme.typography.bodySmall)
                    Slider(value = currentImage.x, onValueChange = { images[selected] = currentImage.copy(x = it) }, valueRange = -400f..400f)
                    Text("ตำแหน่งแนวตั้ง ${currentImage.y.toInt()} px", style = MaterialTheme.typography.bodySmall)
                    Slider(value = currentImage.y, onValueChange = { images[selected] = currentImage.copy(y = it) }, valueRange = -400f..400f)
                    Text("ความทึบ ${(currentImage.opacity * 100).toInt()}%", style = MaterialTheme.typography.bodySmall)
                    Slider(value = currentImage.opacity, onValueChange = { images[selected] = currentImage.copy(opacity = it) }, valueRange = 0f..1f)
                    Divider()
                    Text("Keyframe · เวลา ${"%.1f".format((playhead - currentImage.startTime).coerceAtLeast(0f))} วิ", style = MaterialTheme.typography.titleSmall)
                    Text("บันทึกตำแหน่ง ขนาด มุมหมุน และความโปร่งใส ณ เวลาปัจจุบัน", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Button(onClick = {
                            val t = (playhead - currentImage.startTime).coerceIn(0f, currentImage.duration)
                            val key = StudioKeyframe(t, currentImage.x, currentImage.y, currentImage.scale, currentImage.rotation, currentImage.opacity)
                            images[selected] = currentImage.copy(keyframes = (currentImage.keyframes.filterNot { kotlin.math.abs(it.time - t) < 0.05f } + key).sortedBy { it.time })
                            status = "บันทึก Keyframe ที่ ${"%.1f".format(t)} วินาทีแล้ว"
                        }) { Text("＋ เพิ่ม/อัปเดต") }
                        OutlinedButton(onClick = {
                            val t = (playhead - currentImage.startTime).coerceAtLeast(0f)
                            val nearest = currentImage.keyframes.minByOrNull { kotlin.math.abs(it.time - t) }
                            if (nearest != null && kotlin.math.abs(nearest.time - t) <= 0.25f) {
                                images[selected] = currentImage.copy(keyframes = currentImage.keyframes - nearest)
                                status = "ลบ Keyframe แล้ว"
                            } else status = "ไม่มี Keyframe ใกล้ตำแหน่งเวลานี้"
                        }, enabled = currentImage.keyframes.isNotEmpty()) { Text("ลบจุดนี้") }
                    }
                    Text("${currentImage.keyframes.size} จุด · ${currentImage.keyframes.joinToString { "%.1fs".format(it.time) }}", style = MaterialTheme.typography.bodySmall)
                }
            }
            }
            Text("เลเยอร์ · แตะรายการเพื่อเลือกและใช้ปุ่มลูกศรจัดลำดับ", style = MaterialTheme.typography.titleSmall)
            LazyColumn(Modifier.weight(0.85f), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                itemsIndexed(images, key = { _, item -> item.id }) { index, item ->
                    Row(Modifier.fillMaxWidth().background(if (selected == index) MaterialTheme.colorScheme.secondaryContainer else MaterialTheme.colorScheme.surfaceVariant, RoundedCornerShape(12.dp)).padding(8.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Image(item.bitmap.asImageBitmap(), null, Modifier.size(58.dp), contentScale = androidx.compose.ui.layout.ContentScale.Crop)
                        Column(Modifier.weight(1f)) {
                            TextButton(onClick = { selected = index; playhead = item.startTime }) { Text("${if (selected == index) "● " else ""}เลเยอร์ ${index + 1}${if (!item.visible) " · ซ่อน" else ""}") }
                            Text("${item.bitmap.width} × ${item.bitmap.height}", style = MaterialTheme.typography.bodySmall)
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text("เวลา", style = MaterialTheme.typography.bodySmall)
                                TextButton(onClick = { images[index] = item.copy(duration = (item.duration - 0.5f).coerceAtLeast(0.5f)) }) { Text("−") }
                                Text("${item.duration} วิ")
                                TextButton(onClick = { images[index] = item.copy(duration = (item.duration + 0.5f).coerceAtMost(30f)) }) { Text("＋") }
                            }
                        }
                        Column {
                            TextButton(onClick = { if (index > 0) { val v = images.removeAt(index); images.add(index - 1, v); selected = index - 1 } }, enabled = index > 0) { Text("↑") }
                            TextButton(onClick = { if (index < images.lastIndex) { val v = images.removeAt(index); images.add(index + 1, v); selected = index + 1 } }, enabled = index < images.lastIndex) { Text("↓") }
                        }
                        TextButton(onClick = { images.removeAt(index).also { it.bitmap.recycle() }; selected = selected.coerceAtMost((images.size - 1).coerceAtLeast(0)) }) { Text("ลบ") }
                    }
                }
            }
        }
        if (images.isNotEmpty()) {
            OutlinedButton(onClick = { previewPlaying = !previewPlaying }, enabled = !busy, modifier = Modifier.fillMaxWidth()) {
                Text(if (previewPlaying) "หยุดตัวอย่าง" else "▶ เล่นตัวอย่าง")
            }
        }
        status?.let { Text(it, color = MaterialTheme.colorScheme.primary, style = MaterialTheme.typography.bodySmall) }
        Button(onClick = {
            if (images.isEmpty() || busy) return@Button
            busy = true; status = "กำลังเตรียมวิดีโอ..."
            val snapshot = images.toList()
            scope.launch {
                val result = withContext(Dispatchers.IO) {
                    runCatching {
                        val frameCount = snapshot.size * (if (animationMode) 2 else 1)
                        val parts = snapshot.mapIndexed { index, item ->
                            Part(item.id, "ภาพ ${index + 1}", item.bitmap).apply {
                                pivotX = bitmap.width / 2f; pivotY = bitmap.height / 2f
                                x = item.x; y = item.y
                                scale = min(520f / bitmap.width, 520f / bitmap.height) * item.scale
                                visible = item.visible
                                characterId = item.id
                                characterName = "ภาพ ${index + 1}"
                                charAlpha = item.opacity
                                appearFrom = index * (if (animationMode) 2 else 1)
                                appearTo = appearFrom + (if (animationMode) 1 else 0)
                            }
                        }
                        val frames = (0 until frameCount).map { frame ->
                            val slide = if (animationMode) frame / 2 else frame
                            val phase = if (animationMode && frame % 2 == 1) 1f else 0f
                            val p = parts[slide]
                            val shift = if (animationMode) (if (phase == 0f) -24f else 24f) else 0f
                            val rotation = if (animationMode && motionPreset != "เลื่อนภาพ" && phase == 1f) 3f else 0f
                            mapOf(p.id to Pose(rotation = p.restRotation + snapshot[slide].rotation + rotation, dx = if (motionPreset == "หมุนเบาๆ") 0f else shift, dy = if (motionPreset == "เลื่อนและหมุน") shift * 0.35f else 0f))
                        }
                        val fpsTable = snapshot.flatMap { item -> if (animationMode) listOf(2f / item.duration, 2f / item.duration) else listOf(1f / item.duration) }
                        val totalFrames = Exporter.videoPlayheads(frameCount) { fpsTable[it] }.size
                        val err = Exporter.validateVideo(720, 720, 1, totalFrames)
                        if (err != null) throw IllegalArgumentException(err)
                        val tmp = File(context.cacheDir, "image_studio_${System.currentTimeMillis()}.mp4")
                        Exporter.encodeVideo(parts, frames, Exporter.videoSize(720), Exporter.videoSize(720), 30f, 1, android.graphics.Color.BLACK, tmp,
                            fpsAt = { fpsTable[it] }, loopN = frameCount, onProgress = { _, _ -> })
                        val saved = Exporter.saveVideo(context, tmp, "image_video_${System.currentTimeMillis()}")
                        tmp.delete()
                        saved
                    }
                }
                busy = false
                status = result.fold({ "บันทึกวิดีโอสำเร็จ: $it" }, { "สร้างวิดีโอไม่สำเร็จ: ${it.message ?: it.javaClass.simpleName}" })
            }
        }, enabled = images.isNotEmpty() && !busy && !loadingProject, modifier = Modifier.fillMaxWidth()) { Text(if (busy) "กำลังสร้าง..." else "▶ สร้างและบันทึก MP4") }
    }
}


private fun studioPoseAt(image: StudioImage, absoluteTime: Float): StudioKeyframe {
    val local = (absoluteTime - image.startTime).coerceIn(0f, image.duration)
    val points = image.keyframes.sortedBy { it.time }
    if (points.isEmpty()) return StudioKeyframe(local, image.x, image.y, image.scale, image.rotation, image.opacity)
    if (local <= points.first().time) return points.first()
    if (local >= points.last().time) return points.last()
    val rightIndex = points.indexOfFirst { it.time >= local }
    val a = points[rightIndex - 1]; val b = points[rightIndex]
    val span = (b.time - a.time).coerceAtLeast(0.0001f)
    val f = ((local - a.time) / span).coerceIn(0f, 1f)
    fun mix(x: Float, y: Float) = x + (y - x) * f
    return StudioKeyframe(local, mix(a.x,b.x), mix(a.y,b.y), mix(a.scale,b.scale), mix(a.rotation,b.rotation), mix(a.opacity,b.opacity))
}

@Composable
fun ImageStudioSettings(onOpen: () -> Unit) {
    val context = LocalContext.current
    var enabled by remember { mutableStateOf(ImageStudioPrefs.enabled(context)) }
    var ask by remember { mutableStateOf(ImageStudioPrefs.ask(context)) }
    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Text("โหมดรูปภาพ", style = MaterialTheme.typography.titleSmall, color = MaterialTheme.colorScheme.primary)
        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text("เปิดใช้งานโหมดรูปภาพ")
                Text("สร้างวิดีโอและแอนิเมชันจากภาพนิ่ง", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            Switch(checked = enabled, onCheckedChange = { enabled = it; ImageStudioPrefs.setEnabled(context, it) })
        }
        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text("ถามก่อนเริ่มทำ")
                Text("แสดงหน้าต่างยืนยันก่อนเข้าโหมด", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            Switch(checked = ask, onCheckedChange = { ask = it; ImageStudioPrefs.setAsk(context, it) }, enabled = enabled)
        }
        OutlinedButton(onClick = onOpen, enabled = enabled, modifier = Modifier.fillMaxWidth()) { Text("เปิดโหมดรูปภาพ") }
    }
}
