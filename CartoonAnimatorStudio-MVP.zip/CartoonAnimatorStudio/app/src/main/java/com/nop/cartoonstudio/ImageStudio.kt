package com.nop.cartoonstudio

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import kotlin.math.max
import kotlin.math.min

object ImageStudioPrefs {
    private const val FILE = "image_studio_settings"
    private const val ENABLED = "enabled"
    private const val ASK = "ask_before_start"
    fun enabled(context: Context) = context.getSharedPreferences(FILE, Context.MODE_PRIVATE).getBoolean(ENABLED, true)
    fun setEnabled(context: Context, value: Boolean) { context.getSharedPreferences(FILE, Context.MODE_PRIVATE).edit().putBoolean(ENABLED, value).apply() }
    fun ask(context: Context) = context.getSharedPreferences(FILE, Context.MODE_PRIVATE).getBoolean(ASK, true)
    fun setAsk(context: Context, value: Boolean) { context.getSharedPreferences(FILE, Context.MODE_PRIVATE).edit().putBoolean(ASK, value).apply() }
}

private data class StudioImage(val id: Int, val uri: Uri, val bitmap: Bitmap, val duration: Float = 3f)

@Composable
fun ImageStudioScreen(onBack: () -> Unit) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val images = remember { mutableStateListOf<StudioImage>() }
    var selected by remember { mutableIntStateOf(0) }
    var animationMode by remember { mutableStateOf(false) }
    var motionPreset by remember { mutableStateOf("เลื่อนภาพ") }
    var busy by remember { mutableStateOf(false) }
    var previewPlaying by remember { mutableStateOf(false) }
    var status by remember { mutableStateOf<String?>(null) }
    LaunchedEffect(previewPlaying, images.size, selected) {
        while (previewPlaying && images.isNotEmpty()) {
            delay((images[selected.coerceIn(0, images.lastIndex)].duration * 1000f).toLong().coerceAtLeast(500L))
            selected = (selected + 1) % images.size
        }
    }
    val previewTransition = rememberInfiniteTransition(label = "image-preview")
    val previewMotion by previewTransition.animateFloat(
        initialValue = -1f, targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(1800), RepeatMode.Reverse), label = "preview-motion",
    )
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { uris ->
        uris.forEach { uri ->
            if (images.size >= 30) { status = "เพิ่มได้สูงสุด 30 ภาพต่อหนึ่งงาน"; return@forEach }
            runCatching {
                val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
                context.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }
                if (bounds.outWidth <= 0 || bounds.outHeight <= 0) throw IllegalArgumentException("ไฟล์ภาพไม่ถูกต้อง")
                var sample = 1
                while (max(bounds.outWidth, bounds.outHeight) / sample > 1600) sample *= 2
                val opts = BitmapFactory.Options().apply { inSampleSize = sample; inPreferredConfig = Bitmap.Config.ARGB_8888 }
                val bmp = context.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, opts) }
                    ?: throw IllegalArgumentException("อ่านไฟล์ภาพไม่ได้")
                images.add(StudioImage((images.maxOfOrNull { it.id } ?: 0) + 1, uri, bmp))
            }.onFailure { status = "เปิดรูปภาพไม่สำเร็จ: ${it.message}" }
        }
    }

    Column(Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background).systemBarsPadding().padding(12.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            TextButton(onClick = onBack, enabled = !busy) { Text("‹ กลับ") }
            Text("Image Studio", style = MaterialTheme.typography.titleLarge, modifier = Modifier.weight(1f))
            if (busy) CircularProgressIndicator(Modifier.size(24.dp), strokeWidth = 2.dp)
        }
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            FilterChip(selected = !animationMode, onClick = { animationMode = false }, label = { Text("วิดีโอจากภาพ") })
            FilterChip(selected = animationMode, onClick = { animationMode = true }, label = { Text("ภาพเคลื่อนไหว") })
        }
        if (animationMode) {
            Text("โหมดภาพเคลื่อนไหว: สร้างการเคลื่อนภาพแบบ Keyframe อัตโนมัติจากภาพนิ่ง", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                listOf("เลื่อนภาพ", "หมุนเบาๆ", "เลื่อนและหมุน").forEach { preset ->
                    FilterChip(selected = motionPreset == preset, onClick = { motionPreset = preset }, label = { Text(preset) })
                }
            }
        } else Text("รวมภาพหลายภาพ เรียงลำดับ และกำหนดเวลาของแต่ละภาพ", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button(onClick = { picker.launch(arrayOf("image/*")) }, enabled = !busy) { Text("＋ เพิ่มรูปภาพ") }
            OutlinedButton(onClick = { previewPlaying = false; images.forEach { it.bitmap.recycle() }; images.clear(); selected = 0 }, enabled = images.isNotEmpty() && !busy) { Text("ล้างทั้งหมด") }
        }
        if (images.isEmpty()) {
            Box(Modifier.weight(1f).fillMaxWidth(), contentAlignment = Alignment.Center) {
                Text("ยังไม่มีรูปภาพ\nกด ‘เพิ่มรูปภาพ’ เพื่อเริ่มต้น", color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        } else {
            val current = images.getOrNull(selected.coerceIn(0, images.lastIndex))
            if (current != null) {
                Image(
                    current.bitmap.asImageBitmap(), null,
                    Modifier.fillMaxWidth().weight(1f).graphicsLayer(
                        translationX = if (animationMode && motionPreset != "หมุนเบาๆ") previewMotion * 18f else 0f,
                        translationY = if (animationMode && motionPreset == "เลื่อนและหมุน") previewMotion * 8f else 0f,
                        rotationZ = if (animationMode && motionPreset != "เลื่อนภาพ") previewMotion * 3f else 0f,
                    ),
                    contentScale = androidx.compose.ui.layout.ContentScale.Fit,
                )
                Text("ภาพที่ ${selected + 1} / ${images.size} · ${current.bitmap.width} × ${current.bitmap.height} px", style = MaterialTheme.typography.bodySmall)
            }
            LazyColumn(Modifier.weight(0.85f), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                itemsIndexed(images, key = { _, item -> item.id }) { index, item ->
                    Row(Modifier.fillMaxWidth().background(MaterialTheme.colorScheme.surfaceVariant, RoundedCornerShape(12.dp)).padding(8.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Image(item.bitmap.asImageBitmap(), null, Modifier.size(58.dp), contentScale = androidx.compose.ui.layout.ContentScale.Crop)
                        Column(Modifier.weight(1f)) {
                            Text("ภาพ ${index + 1}", style = MaterialTheme.typography.titleSmall)
                            Text("${item.bitmap.width} × ${item.bitmap.height}", style = MaterialTheme.typography.bodySmall)
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text("เวลา", style = MaterialTheme.typography.bodySmall)
                                TextButton(onClick = { images[index] = item.copy(duration = (item.duration - 0.5f).coerceAtLeast(0.5f)) }) { Text("−") }
                                Text("${item.duration} วิ")
                                TextButton(onClick = { images[index] = item.copy(duration = (item.duration + 0.5f).coerceAtMost(30f)) }) { Text("＋") }
                            }
                        }
                        Column {
                            TextButton(onClick = { if (index > 0) { val v = images.removeAt(index); images.add(index - 1, v); selected = index - 1 } }, enabled = index > 0) { Text("↑") }
                            TextButton(onClick = { if (index < images.lastIndex) { val v = images.removeAt(index); images.add(index + 1, v); selected = index + 1 } }, enabled = index < images.lastIndex) { Text("↓") }
                        }
                        TextButton(onClick = { images.removeAt(index).bitmap.recycle(); selected = selected.coerceAtMost((images.size - 1).coerceAtLeast(0)) }) { Text("ลบ") }
                    }
                }
            }
        }
        if (images.isNotEmpty()) {
            OutlinedButton(onClick = { previewPlaying = !previewPlaying }, enabled = !busy, modifier = Modifier.fillMaxWidth()) {
                Text(if (previewPlaying) "หยุดตัวอย่าง" else "▶ เล่นตัวอย่าง")
            }
        }
        status?.let { Text(it, color = MaterialTheme.colorScheme.primary, style = MaterialTheme.typography.bodySmall) }
        Button(onClick = {
            if (images.isEmpty() || busy) return@Button
            busy = true; status = "กำลังเตรียมวิดีโอ..."
            val snapshot = images.toList()
            scope.launch {
                val result = withContext(Dispatchers.IO) {
                    runCatching {
                        val frameCount = snapshot.size * (if (animationMode) 2 else 1)
                        val parts = snapshot.mapIndexed { index, item ->
                            Part(item.id, "ภาพ ${index + 1}", item.bitmap).apply {
                                pivotX = bitmap.width / 2f; pivotY = bitmap.height / 2f
                                x = 0f; y = 0f
                                scale = min(520f / bitmap.width, 520f / bitmap.height)
                                appearFrom = index * (if (animationMode) 2 else 1)
                                appearTo = appearFrom + (if (animationMode) 1 else 0)
                            }
                        }
                        val frames = (0 until frameCount).map { frame ->
                            val slide = if (animationMode) frame / 2 else frame
                            val phase = if (animationMode && frame % 2 == 1) 1f else 0f
                            val p = parts[slide]
                            val shift = if (animationMode) (if (phase == 0f) -24f else 24f) else 0f
                            val rotation = if (animationMode && motionPreset != "เลื่อนภาพ" && phase == 1f) 3f else 0f
                            mapOf(p.id to Pose(rotation = rotation, dx = if (motionPreset == "หมุนเบาๆ") 0f else shift, dy = if (motionPreset == "เลื่อนและหมุน") shift * 0.35f else 0f))
                        }
                        val fpsTable = snapshot.flatMap { item -> if (animationMode) listOf(2f / item.duration, 2f / item.duration) else listOf(1f / item.duration) }
                        val totalFrames = Exporter.videoPlayheads(frameCount) { fpsTable[it] }.size
                        val err = Exporter.validateVideo(720, 720, 1, totalFrames)
                        if (err != null) throw IllegalArgumentException(err)
                        val tmp = File(context.cacheDir, "image_studio_${System.currentTimeMillis()}.mp4")
                        Exporter.encodeVideo(parts, frames, Exporter.videoSize(720), Exporter.videoSize(720), 30f, 1, android.graphics.Color.BLACK, tmp,
                            fpsAt = { fpsTable[it] }, loopN = frameCount, onProgress = { _, _ -> })
                        val saved = Exporter.saveVideo(context, tmp, "image_video_${System.currentTimeMillis()}")
                        tmp.delete()
                        saved
                    }
                }
                busy = false
                status = result.fold({ "บันทึกวิดีโอสำเร็จ: $it" }, { "สร้างวิดีโอไม่สำเร็จ: ${it.message ?: it.javaClass.simpleName}" })
            }
        }, enabled = images.isNotEmpty() && !busy, modifier = Modifier.fillMaxWidth()) { Text(if (busy) "กำลังสร้าง..." else "▶ สร้างและบันทึก MP4") }
    }
}

@Composable
fun ImageStudioSettings(onOpen: () -> Unit) {
    val context = LocalContext.current
    var enabled by remember { mutableStateOf(ImageStudioPrefs.enabled(context)) }
    var ask by remember { mutableStateOf(ImageStudioPrefs.ask(context)) }
    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Text("โหมดรูปภาพ", style = MaterialTheme.typography.titleSmall, color = MaterialTheme.colorScheme.primary)
        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text("เปิดใช้งานโหมดรูปภาพ")
                Text("สร้างวิดีโอและแอนิเมชันจากภาพนิ่ง", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            Switch(checked = enabled, onCheckedChange = { enabled = it; ImageStudioPrefs.setEnabled(context, it) })
        }
        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text("ถามก่อนเริ่มทำ")
                Text("แสดงหน้าต่างยืนยันก่อนเข้าโหมด", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            Switch(checked = ask, onCheckedChange = { ask = it; ImageStudioPrefs.setAsk(context, it) }, enabled = enabled)
        }
        OutlinedButton(onClick = onOpen, enabled = enabled, modifier = Modifier.fillMaxWidth()) { Text("เปิดโหมดรูปภาพ") }
    }
}
