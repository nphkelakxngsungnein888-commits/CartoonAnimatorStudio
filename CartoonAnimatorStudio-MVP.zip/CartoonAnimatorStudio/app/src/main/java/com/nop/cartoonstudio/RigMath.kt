package com.nop.cartoonstudio

import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Matrix
import android.graphics.Paint

/**
 * เมทริกซ์ข้อต่อ (joint matrix) ของทุกชิ้นส่วน
 * J(part) = J(parent) * T(x+dx, y+dy) * R(restRotation + rotation)
 * ลูกจึงขยับตามพ่อแม่เสมอ (parent-child)
 */
fun computeJointMatrices(parts: List<Part>, poseOf: (Int) -> Pose): Map<Int, Matrix> {
    val byId = parts.associateBy { it.id }
    val cache = HashMap<Int, Matrix>()

    fun resolve(p: Part, depth: Int): Matrix {
        cache[p.id]?.let { return it }
        val m = Matrix()
        val parent = p.parentId?.let { byId[it] }
        if (parent != null && depth < 64) m.set(resolve(parent, depth + 1)) // กันวงวน
        val pose = poseOf(p.id)
        m.preTranslate(p.x + pose.dx, p.y + pose.dy)
        m.preRotate(p.restRotation + pose.rotation)
        cache[p.id] = m
        return m
    }

    for (p in parts) resolve(p, 0)
    return cache
}

/** เมทริกซ์วาดภาพของชิ้นส่วน: J * S * T(-pivot) (หมุน/พลิก/ย่อขยายรอบข้อต่อ) */
fun drawMatrix(p: Part, joint: Matrix): Matrix {
    val m = Matrix(joint)
    m.preScale(if (p.flipX) -p.scale else p.scale, p.scale)
    m.preTranslate(-p.pivotX, -p.pivotY)
    return m
}

/** วาดทั้งฉากลง canvas (ใช้ร่วมกันทั้งหน้าจอแก้ไขและตอนส่งออก) */
fun drawScene(canvas: Canvas, parts: List<Part>, poseOf: (Int) -> Pose, paint: Paint) {
    val joints = computeJointMatrices(parts, poseOf)
    for (p in parts) {
        if (!p.visible) continue
        val j = joints[p.id] ?: continue
        canvas.drawBitmap(p.bitmap, drawMatrix(p, j), paint)
    }
}

/** หาชิ้นส่วนที่ถูกแตะ (เริ่มจากชั้นบนสุด, ข้ามพิกเซลโปร่งใส) พิกัดเป็นพิกัดโลก */
fun hitTest(parts: List<Part>, poseOf: (Int) -> Pose, wx: Float, wy: Float): Part? {
    val joints = computeJointMatrices(parts, poseOf)
    for (i in parts.indices.reversed()) {
        val p = parts[i]
        if (!p.visible) continue
        val j = joints[p.id] ?: continue
        val inv = Matrix()
        if (!drawMatrix(p, j).invert(inv)) continue
        val pt = floatArrayOf(wx, wy)
        inv.mapPoints(pt)
        val ix = pt[0].toInt()
        val iy = pt[1].toInt()
        if (pt[0] < 0f || pt[1] < 0f || ix >= p.bitmap.width || iy >= p.bitmap.height) continue
        if (Color.alpha(p.bitmap.getPixel(ix, iy)) > 16) return p
    }
    return null
}
