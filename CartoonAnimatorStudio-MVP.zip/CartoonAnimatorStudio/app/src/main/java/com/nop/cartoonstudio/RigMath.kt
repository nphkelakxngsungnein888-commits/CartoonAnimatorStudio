package com.nop.cartoonstudio

import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Matrix
import android.graphics.Paint
import kotlin.math.atan2
import kotlin.math.hypot
import kotlin.math.max

/**
 * เมทริกซ์ข้อต่อ (joint matrix) ของทุกชิ้นส่วน
 * J(part) = J(parent) * T(x+dx, y+dy) * [F] * R(restRotation + rotation)
 * F = พลิกแบบกระจกทั้งตัวละคร (มีเฉพาะชิ้นราก; ลูกๆ ได้ผลพลิกผ่าน J(parent))
 * ลูกจึงขยับตามพ่อแม่เสมอ (parent-child)
 */
fun computeJointMatrices(parts: List<Part>, poseOf: (Int) -> Pose): Map<Int, Matrix> {
    val byId = parts.associateBy { it.id }
    val cache = HashMap<Int, Matrix>()

    fun resolve(p: Part, depth: Int): Matrix {
        cache[p.id]?.let { return it }
        val m = Matrix()
        val pose = poseOf(p.id)
        if (p.role == BoneRole.ITEM && pose.hold != HOLD_NONE) {
            // สิ่งของที่ถูกติด/ถอดแล้วในเฟรมนี้: สถานะอยู่ใน Pose (รายเฟรม) ไม่ได้อ่านจาก parentId
            val hand = if (pose.hold > 0) byId[pose.hold] else null
            if (hand != null && depth < 64) { // ถืออยู่: ตามปลายมือ (ท่าของของเป็นค่าสัมพัทธ์จากมือ)
                m.set(resolve(hand, depth + 1))
                m.preTranslate(hand.boneLength + pose.dx, pose.dy)
                m.preRotate(heldRestRotation(p, hand, byId) + pose.rotation)
                val from = pose.from
                if (from != null && pose.blend < 1f) { // กำลังบินเข้ามือ: เฉลี่ยตำแหน่ง/มุมระหว่างท่าอิสระกับปลายมือ
                    blendTowardHand(itemFreeMatrix(p, from), m, pose.blend)?.let { m.set(it) }
                }
            } else { // ถอดแล้ว: ท่าเป็นค่าในพิกัดโลก (ไม่ตามมือ/ตัวละคร)
                m.preTranslate(pose.dx, pose.dy)
                val fh = p.mirrorH != pose.flipH
                val fv = p.mirrorV != pose.flipV
                if (fh || fv) m.preScale(if (fh) -1f else 1f, if (fv) -1f else 1f)
                m.preRotate(pose.rotation)
            }
            cache[p.id] = m
            return m
        }
        val parent = p.parentId?.let { byId[it] }
        if (parent != null && depth < 64) m.set(resolve(parent, depth + 1)) // กันวงวน
        m.preTranslate(p.x + pose.dx, p.y + pose.dy)
        val fh = p.mirrorH != pose.flipH // ค่าระดับตัวละคร (ทุกเฟรม) สลับด้วยค่าเฉพาะเฟรม
        val fv = p.mirrorV != pose.flipV
        if (parent == null && (fh || fv)) m.preScale(if (fh) -1f else 1f, if (fv) -1f else 1f)
        m.preRotate(p.restRotation + pose.rotation)
        cache[p.id] = m
        return m
    }

    for (p in parts) resolve(p, 0)
    return cache
}

/** เมทริกซ์ของสิ่งของตอนไม่ได้ถือมือ (ยังไม่ติด = ตำแหน่งตอนโหลด + ท่า, ถอดแล้ว = ท่าในพิกัดโลก) */
private fun itemFreeMatrix(p: Part, pose: Pose): Matrix {
    val m = Matrix()
    val world = pose.hold == HOLD_FREE
    m.preTranslate(if (world) pose.dx else p.x + pose.dx, if (world) pose.dy else p.y + pose.dy)
    val fh = p.mirrorH != pose.flipH
    val fv = p.mirrorV != pose.flipV
    if (fh || fv) m.preScale(if (fh) -1f else 1f, if (fv) -1f else 1f)
    m.preRotate(if (world) pose.rotation else p.restRotation + pose.rotation)
    return m
}

/** ค่ากลางระหว่างเมทริกซ์อิสระ f กับเมทริกซ์ที่ปลายมือ h (ตำแหน่งเฉลี่ยตรง มุมเฉลี่ยทางสั้น) คืน null ถ้ามีการพลิกกระจก (ไม่เฉลี่ย ใช้ h) */
private fun blendTowardHand(f: Matrix, h: Matrix, t: Float): Matrix? {
    val fv = FloatArray(9)
    val hv = FloatArray(9)
    f.getValues(fv)
    h.getValues(hv)
    fun det(v: FloatArray) = v[Matrix.MSCALE_X] * v[Matrix.MSCALE_Y] - v[Matrix.MSKEW_X] * v[Matrix.MSKEW_Y]
    if (det(fv) <= 0f || det(hv) <= 0f) return null
    val fa = Math.toDegrees(atan2(fv[Matrix.MSKEW_Y].toDouble(), fv[Matrix.MSCALE_X].toDouble())).toFloat()
    val ha = Math.toDegrees(atan2(hv[Matrix.MSKEW_Y].toDouble(), hv[Matrix.MSCALE_X].toDouble())).toFloat()
    var d = ha - fa
    while (d > 180f) d -= 360f
    while (d < -180f) d += 360f
    val out = Matrix()
    out.setTranslate(
        fv[Matrix.MTRANS_X] + (hv[Matrix.MTRANS_X] - fv[Matrix.MTRANS_X]) * t,
        fv[Matrix.MTRANS_Y] + (hv[Matrix.MTRANS_Y] - fv[Matrix.MTRANS_Y]) * t,
    )
    out.preRotate(fa + d * t)
    return out
}

/** มุมพื้นฐานของสิ่งของตอนถือ: คงมุมจริงของของไว้ (มุมพื้นฐานจริง homeRest ลบมุมพื้นฐานรวมของสายมือ) */
fun heldRestRotation(item: Part, hand: Part, byId: Map<Int, Part>): Float {
    var chainRest = 0f
    var cur: Part? = hand
    var guard = 0
    while (cur != null && guard++ < 64) {
        chainRest += cur.restRotation
        cur = cur.parentId?.let { byId[it] }
    }
    return item.homeRest - chainRest
}

/** ระยะ (หน่วยโลก) จากข้อต่อลงมาถึงปุ่มเขียว: ปุ่มเขียวอยู่ใต้ปุ่มแดงในแนวตั้งเสมอ ไม่หมุนตามภาพ */
fun tipLength(p: Part): Float = max(hypot(p.tipX - p.pivotX, p.tipY - p.pivotY) * p.scale, 40f)

/** เมทริกซ์วาดภาพของชิ้นส่วน: J * S * T(-pivot) (หมุน/พลิก/ย่อขยายรอบข้อต่อ) */
fun drawMatrix(p: Part, joint: Matrix): Matrix {
    val m = Matrix(joint)
    m.preScale(if (p.flipX) -p.scale else p.scale, p.scale)
    m.preTranslate(-p.pivotX, -p.pivotY)
    return m
}

/** วาดทั้งฉากลง canvas (ใช้ร่วมกันทั้งหน้าจอแก้ไขและตอนส่งออก) */
fun drawScene(canvas: Canvas, parts: List<Part>, poseOf: (Int) -> Pose, paint: Paint) {
    val joints = computeJointMatrices(parts, poseOf)
    for (p in parts) {
        if (!p.visible) continue
        val j = joints[p.id] ?: continue
        val g = poseOf(p.id).sculpt
        if (g == null || g.isZero()) {
            canvas.drawBitmap(p.bitmap, drawMatrix(p, j), paint)
        } else { // ชิ้นที่ปั้นแล้ว: วาดผ่านตาข่าย (จุดอยู่ในพิกัด bitmap ผ่าน drawMatrix เดียวกับภาพปกติ)
            canvas.save()
            canvas.concat(drawMatrix(p, j))
            canvas.drawBitmapMesh(p.bitmap, g.cols, g.rows, Sculpt.verts(p.bitmap.width, p.bitmap.height, g), 0, null, 0, paint)
            canvas.restore()
        }
    }
}

/** หาชิ้นส่วนที่ถูกแตะ (เริ่มจากชั้นบนสุด, ข้ามพิกเซลโปร่งใส) พิกัดเป็นพิกัดโลก */
fun hitTest(parts: List<Part>, poseOf: (Int) -> Pose, wx: Float, wy: Float): Part? {
    val joints = computeJointMatrices(parts, poseOf)
    for (i in parts.indices.reversed()) {
        val p = parts[i]
        if (!p.visible) continue
        val j = joints[p.id] ?: continue
        val inv = Matrix()
        if (!drawMatrix(p, j).invert(inv)) continue
        val pt = floatArrayOf(wx, wy)
        inv.mapPoints(pt)
        val ix = pt[0].toInt()
        val iy = pt[1].toInt()
        if (pt[0] < 0f || pt[1] < 0f || ix >= p.bitmap.width || iy >= p.bitmap.height) continue
        if (Color.alpha(p.bitmap.getPixel(ix, iy)) > 16) return p
    }
    return null
}
