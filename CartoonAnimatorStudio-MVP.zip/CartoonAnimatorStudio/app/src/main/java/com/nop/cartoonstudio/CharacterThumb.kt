package com.nop.cartoonstudio

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Paint
import kotlin.math.max

/**
 * ภาพย่อของตัวละครตัวเดียว (ท่าตั้งต้น ไม่รวมท่าในเฟรม) สำหรับแถบตัวละครด้านซ้าย
 * parts = ชิ้นส่วนของตัวละครนั้นเท่านั้น ย่อให้พอดีช่อง size x size พิกเซล คืน null ถ้าไม่มีอะไรให้วาด
 * ผลการพลิกซ้าย-ขวา/ขึ้น-ลงของตัวละครแสดงในภาพย่อด้วย
 */
fun characterThumbnail(parts: List<Part>, size: Int): Bitmap? {
    val visible = parts.filter { it.visible }
    if (visible.isEmpty()) return null
    val rest: (Int) -> Pose = { Pose() }
    val joints = computeJointMatrices(parts, rest)

    var minX = Float.MAX_VALUE
    var minY = Float.MAX_VALUE
    var maxX = -Float.MAX_VALUE
    var maxY = -Float.MAX_VALUE
    for (p in visible) {
        val j = joints[p.id] ?: continue
        val w = p.bitmap.width.toFloat()
        val h = p.bitmap.height.toFloat()
        val pts = floatArrayOf(0f, 0f, w, 0f, 0f, h, w, h)
        drawMatrix(p, j).mapPoints(pts)
        for (i in 0 until 4) {
            val x = pts[2 * i]
            val y = pts[2 * i + 1]
            if (x < minX) minX = x
            if (x > maxX) maxX = x
            if (y < minY) minY = y
            if (y > maxY) maxY = y
        }
    }
    if (minX >= maxX || minY >= maxY) return null

    val s = (size - 8f) / max(maxX - minX, maxY - minY)
    val bmp = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)
    val canvas = Canvas(bmp)
    canvas.translate(size / 2f, size / 2f)
    canvas.scale(s, s)
    canvas.translate(-(minX + maxX) / 2f, -(minY + maxY) / 2f)
    drawScene(canvas, parts, rest, Paint(Paint.FILTER_BITMAP_FLAG or Paint.ANTI_ALIAS_FLAG))
    return bmp
}
