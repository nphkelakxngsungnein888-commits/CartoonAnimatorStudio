package com.nop.cartoonstudio

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Paint
import kotlin.math.max
import kotlin.math.min

/**
 * ภาพย่อของตัวละครตัวเดียว (ท่าตั้งต้น ไม่รวมท่าในเฟรม) สำหรับแถบตัวละครด้านซ้าย
 * parts = ชิ้นส่วนของตัวละครนั้นเท่านั้น ย่อให้พอดีช่อง size x size พิกเซล คืน null ถ้าไม่มีอะไรให้วาด
 * ผลการพลิกซ้าย-ขวา/ขึ้น-ลงของตัวละครแสดงในภาพย่อด้วย
 */
fun characterThumbnail(parts: List<Part>, size: Int): Bitmap? {
    val visible = parts.filter { it.visible }
    if (visible.isEmpty()) return null
    val rest: (Int) -> Pose = { Pose() }
    val joints = computeJointMatrices(parts, rest)

    var minX = Float.MAX_VALUE
    var minY = Float.MAX_VALUE
    var maxX = -Float.MAX_VALUE
    var maxY = -Float.MAX_VALUE
    for (p in visible) {
        val j = joints[p.id] ?: continue
        val w = p.bitmap.width.toFloat()
        val h = p.bitmap.height.toFloat()
        val pts = floatArrayOf(0f, 0f, w, 0f, 0f, h, w, h)
        drawMatrix(p, j).mapPoints(pts)
        for (i in 0 until 4) {
            val x = pts[2 * i]
            val y = pts[2 * i + 1]
            if (x < minX) minX = x
            if (x > maxX) maxX = x
            if (y < minY) minY = y
            if (y > maxY) maxY = y
        }
    }
    if (minX >= maxX || minY >= maxY) return null

    val s = (size - 8f) / max(maxX - minX, maxY - minY)
    val bmp = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)
    val canvas = Canvas(bmp)
    canvas.translate(size / 2f, size / 2f)
    canvas.scale(s, s)
    canvas.translate(-(minX + maxX) / 2f, -(minY + maxY) / 2f)
    drawScene(canvas, parts, rest, Paint(Paint.FILTER_BITMAP_FLAG or Paint.ANTI_ALIAS_FLAG))
    return bmp
}

/**
 * ภาพย่อของ "เฟรมหนึ่ง" ตามที่จะเห็นในวิดีโอ: วาดเฉพาะส่วนที่อยู่ในกรอบส่งออก (worldW x worldH หน่วยโลก กึ่งกลางที่ (0,0))
 * poses = ท่าของเฟรมนั้น (id ชิ้นส่วน -> ท่า) position = เลขเฟรม (เริ่มที่ 0) ไว้เช็กช่วงเฟรมที่ตัวละครแสดง
 * พื้นหลังโปร่งใส (ผู้เรียกใส่สีพื้นเอง) ควรเรียกใน Dispatchers.Default
 */
fun frameThumbnail(parts: List<Part>, poses: Map<Int, Pose>, position: Int, worldW: Float, worldH: Float, w: Int, h: Int): Bitmap {
    val bmp = Bitmap.createBitmap(w.coerceAtLeast(1), h.coerceAtLeast(1), Bitmap.Config.ARGB_8888)
    val canvas = Canvas(bmp)
    val s = min(w / worldW, h / worldH)
    canvas.translate(w / 2f, h / 2f)
    canvas.scale(s, s)
    drawScene(canvas, parts, { id -> poses[id] ?: Pose() }, Paint(Paint.FILTER_BITMAP_FLAG or Paint.ANTI_ALIAS_FLAG), position.toFloat())
    return bmp
}

/** ลายเซ็นของท่าในเฟรมหนึ่ง (รวมการปั้น) ไว้เช็กว่าภาพย่อของเฟรมต้องวาดใหม่ไหม: เรียงลำดับไม่มีผล */
fun poseMapSignature(poses: Map<Int, Pose>): Int {
    var sum = 0
    for ((id, p) in poses) {
        var h = id
        h = h * 31 + p.rotation.hashCode()
        h = h * 31 + p.dx.hashCode()
        h = h * 31 + p.dy.hashCode()
        h = h * 31 + (if (p.flipH) 1 else 0)
        h = h * 31 + (if (p.flipV) 1 else 0)
        h = h * 31 + p.hold
        p.sculpt?.let { g -> h = h * 31 + g.cols * 7 + g.rows + g.off.contentHashCode() }
        sum += h
    }
    return sum * 31 + poses.size
}

/** ลายเซ็นของชิ้นส่วนทั้งหมดในฉาก (ตำแหน่ง ขนาด ช่วงเฟรมที่แสดง ความจาง ภาพ ฯลฯ) ลำดับวาดมีผล */
fun partsSignature(parts: List<Part>): Int {
    var h = 17
    for (p in parts) {
        h = h * 31 + p.id
        h = h * 31 + (p.parentId ?: -1)
        h = h * 31 + p.x.hashCode()
        h = h * 31 + p.y.hashCode()
        h = h * 31 + p.pivotX.hashCode()
        h = h * 31 + p.pivotY.hashCode()
        h = h * 31 + p.restRotation.hashCode()
        h = h * 31 + p.scale.hashCode()
        h = h * 31 + p.charScale.hashCode()
        h = h * 31 + (if (p.flipX) 1 else 0)
        h = h * 31 + (if (p.visible) 1 else 0)
        h = h * 31 + (if (p.mirrorH) 1 else 0)
        h = h * 31 + (if (p.mirrorV) 1 else 0)
        h = h * 31 + p.role.ordinal
        h = h * 31 + p.characterId
        h = h * 31 + p.appearFrom
        h = h * 31 + p.appearTo
        h = h * 31 + p.charAlpha.hashCode()
        h = h * 31 + System.identityHashCode(p.bitmap)
    }
    return h
}
