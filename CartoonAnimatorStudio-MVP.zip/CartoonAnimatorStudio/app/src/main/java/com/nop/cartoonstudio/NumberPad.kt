package com.nop.cartoonstudio

import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.RowScope
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Density
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties

/** ขนาดแผงตัวเลขแบบเล็ก เทียบกับขนาดเดิม (0.30 = 30%) ย่อทั้งปุ่ม ตัวเลข และช่องว่างพร้อมกัน */
const val NUMBER_PAD_SCALE = 0.30f

/** ตัวเลขสำหรับแสดง: ตัดศูนย์ท้ายทศนิยมทิ้ง (24.0 -> 24, 2.50 -> 2.5) */
internal fun padFmt(v: Float): String =
    runCatching { java.math.BigDecimal(v.toString()).stripTrailingZeros().toPlainString() }.getOrDefault(v.toString())

/**
 * แผงตัวเลขแบบเล็กวางทับหน้าจอ (ไม่ใช่กล่องโต้ตอบ จึงยังเห็นภาพและช่องที่กำลังใส่ค่าอยู่)
 * วางไว้มุมซ้ายล่างเหนือช่องที่ใส่ค่า ขนาด NUMBER_PAD_SCALE ของแผงเดิม
 * แตะที่แผงไม่ทะลุลงไปโดนหน้าจอด้านหลัง
 */
@Composable
fun CompactNumberPad(
    title: String,
    unit: String,
    initial: Float,
    onDismiss: () -> Unit,
    onOk: (Float) -> Unit,
    modifier: Modifier = Modifier,
) {
    val base = LocalDensity.current
    val small = remember(base.density, base.fontScale) { Density(base.density * NUMBER_PAD_SCALE, base.fontScale) }
    CompositionLocalProvider(LocalDensity provides small) {
        Box(modifier.pointerInput(Unit) { detectTapGestures { } }) {
            NumberPadBody(title, unit, initial, onDismiss, onOk, Modifier.width(340.dp))
        }
    }
}

/** แผงตัวเลขเต็มขนาดในกล่องโต้ตอบกลางจอ (ใช้ในหน้าตั้งค่าที่ไม่มีที่ว่างมุมซ้ายล่าง) */
@Composable
fun NumberPadDialog(title: String, unit: String, initial: Float, onDismiss: () -> Unit, onOk: (Float) -> Unit) {
    Dialog(onDismissRequest = onDismiss, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        NumberPadBody(title, unit, initial, onDismiss, onOk, Modifier.fillMaxWidth(0.88f).widthIn(max = 340.dp))
    }
}

/** แผงตัวเลขของแอป (ไม่ใช้แป้นพิมพ์ระบบ): 123 / 456 / 789 / ลบ 0 . ตกลง รองรับจุดทศนิยม */
@Composable
private fun NumberPadBody(
    title: String,
    unit: String,
    initial: Float,
    onDismiss: () -> Unit,
    onOk: (Float) -> Unit,
    modifier: Modifier,
) {
    val context = LocalContext.current
    var s by remember { mutableStateOf(padFmt(initial)) }
    var fresh by remember { mutableStateOf(true) } // แตะเลขแรก = แทนที่ค่าเดิมทั้งหมด

    fun digit(d: String) {
        if (fresh) {
            s = d
            fresh = false
        } else if (s == "0") {
            s = d
        } else if (s.length < 9) {
            s += d
        }
    }

    fun dot() {
        if (fresh) {
            s = "0."
            fresh = false
        } else if (!s.contains('.') && s.length < 9) {
            s = if (s.isEmpty()) "0." else "$s."
        }
    }

    fun back() {
        fresh = false
        s = s.dropLast(1)
    }

    fun ok() {
        val v = s.toFloatOrNull()
        if (v == null || v <= 0f) {
            Toast.makeText(context, "ใส่ตัวเลขที่มากกว่า 0", Toast.LENGTH_SHORT).show()
        } else {
            onOk(v)
        }
    }

    val shape = RoundedCornerShape(26.dp)
    Column(
        modifier
            .clip(shape)
            .background(Brush.verticalGradient(listOf(Color(0xFF242434), Palette.Panel)))
            .border(1.dp, Palette.Accent.copy(alpha = 0.55f), shape)
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp),
    ) {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Text(title, Modifier.weight(1f), color = Color(0xFFC9C4D4), fontSize = 15.sp)
            Box(
                Modifier
                    .clip(RoundedCornerShape(50))
                    .background(Color(0xFF33333F))
                    .clickable(onClick = onDismiss)
                    .padding(horizontal = 12.dp, vertical = 4.dp),
            ) { Text("✕", color = Color(0xFFC9C4D4), fontSize = 14.sp) }
        }
        Row(
            Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(16.dp))
                .background(Palette.Bg)
                .border(1.dp, Palette.Accent, RoundedCornerShape(16.dp))
                .padding(horizontal = 16.dp, vertical = 14.dp),
            horizontalArrangement = Arrangement.End,
            verticalAlignment = Alignment.Bottom,
        ) {
            Text(s.ifEmpty { "0" }, color = Color.White, fontSize = 36.sp, fontWeight = FontWeight.Bold, maxLines = 1)
            Text("  $unit", color = Color(0xFF9E9AB0), fontSize = 16.sp, modifier = Modifier.padding(bottom = 6.dp))
        }
        val keyBg = Palette.PanelHigh
        val keyFg = Color.White
        for (row in listOf(listOf("1", "2", "3"), listOf("4", "5", "6"), listOf("7", "8", "9"))) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                for (k in row) PadKey(k, keyBg, keyFg) { digit(k) }
            }
        }
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            PadKey("ลบ", Color(0xFF4A2630), Color(0xFFFF8A80)) { back() }
            PadKey("0", keyBg, keyFg) { digit("0") }
            PadKey(".", keyBg, keyFg) { dot() }
            PadKey("ตกลง", Palette.Accent, Color(0xFF2A1A66)) { ok() }
        }
    }
}

@Composable
private fun RowScope.PadKey(label: String, bg: Color, fg: Color, onClick: () -> Unit) {
    Box(
        Modifier
            .weight(1f)
            .height(60.dp)
            .clip(RoundedCornerShape(18.dp))
            .background(bg)
            .clickable(onClick = onClick),
        contentAlignment = Alignment.Center,
    ) { Text(label, color = fg, fontSize = if (label.length > 1) 17.sp else 26.sp, fontWeight = FontWeight.Medium) }
}
