package com.nop.cartoonstudio

import android.content.Context
import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.RowScope
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Density
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.IntRect
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Popup
import androidx.compose.ui.window.PopupPositionProvider
import androidx.compose.ui.window.PopupProperties
import kotlin.math.roundToInt

/** ขนาดแผงตัวเลขที่ "50%" เทียบกับแผงเดิมเต็มขนาด (0.90 = ใหญ่กว่าแผงเล็กเดิม 0.30 อยู่ 3 เท่า) ขนาดจริง = ค่านี้ × (ค่าที่ตั้ง ÷ 50) */
const val NUMBER_PAD_SCALE = 0.90f

/** ขนาดเต็ม (scale 1.0) ของแผงตัวเลขเป็น dp ใช้คำนวณว่าพอดีกับจอไหม: กว้าง 340 / สูงประมาณ 430 */
private const val PAD_FULL_W_DP = 340f
private const val PAD_FULL_H_DP = 430f

/**
 * ค่าตั้งของแผงตัวเลขลอย: ขนาด (10–100, 50 = ขนาดตั้งต้น) · ปักหมุด (จำตำแหน่งที่ลากไปวาง) · ตำแหน่งที่ลากไป
 * ตำแหน่ง dx/dy นับจากจุดตั้งต้น (กลางล่างของหน้าต่าง) เป็นพิกเซล
 */
object PadPrefs {
    const val SIZE_MIN = 10f
    const val SIZE_MAX = 100f
    const val SIZE_DEFAULT = 50f

    private const val PREFS = "ui_prefs"
    private const val KEY_SIZE = "pad_size"
    private const val KEY_PIN = "pad_pinned"
    private const val KEY_DX = "pad_dx"
    private const val KEY_DY = "pad_dy"

    var size by mutableFloatStateOf(SIZE_DEFAULT)
        private set
    var pinned by mutableStateOf(false)
        private set

    /** เลขนับการเคลื่อนที่ (เปลี่ยนทุกครั้งที่ลาก/รีเซ็ต เพื่อให้หน้าต่างลอยคำนวณตำแหน่งใหม่) */
    var tick by mutableIntStateOf(0)
        private set

    /** ตำแหน่งที่ลากไป (ไม่ใช่ state: ตัวคำนวณตำแหน่งของหน้าต่างลอยเป็นคนตัดค่าให้อยู่ในจอแล้วเขียนกลับ) */
    @Volatile var dx = 0f
    @Volatile var dy = 0f

    fun sanitizeSize(v: Float): Float = if (v.isNaN()) SIZE_DEFAULT else v.roundToInt().toFloat().coerceIn(SIZE_MIN, SIZE_MAX)

    /** สเกลจริงของแผง (เทียบแผงเดิมเต็มขนาด) */
    fun scale(): Float = NUMBER_PAD_SCALE * size / SIZE_DEFAULT

    fun load(context: Context) {
        try {
            val p = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            size = sanitizeSize(p.getFloat(KEY_SIZE, SIZE_DEFAULT))
            pinned = p.getBoolean(KEY_PIN, false)
            if (pinned) {
                dx = p.getFloat(KEY_DX, 0f)
                dy = p.getFloat(KEY_DY, 0f)
            }
        } catch (_: Throwable) {
            size = SIZE_DEFAULT
        }
    }

    private fun edit(context: Context, block: android.content.SharedPreferences.Editor.() -> Unit) {
        try {
            context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().apply(block).apply()
        } catch (_: Throwable) {
            // เก็บไม่สำเร็จ: ใช้ค่านี้ในรอบนี้ได้ (แค่ไม่จำข้ามการเปิดแอป)
        }
    }

    fun setSize(context: Context, v: Float) {
        size = sanitizeSize(v)
        edit(context) { putFloat(KEY_SIZE, size) }
    }

    fun setPinned(context: Context, on: Boolean) {
        pinned = on
        edit(context) {
            putBoolean(KEY_PIN, on)
            putFloat(KEY_DX, dx)
            putFloat(KEY_DY, dy)
        }
    }

    fun dragBy(ddx: Float, ddy: Float) {
        dx += ddx
        dy += ddy
        tick++
    }

    fun resetPos() {
        dx = 0f
        dy = 0f
        tick++
    }

    /** เรียกตอนปิดแผง: ถ้าปักหมุดไว้ก็จำตำแหน่งล่าสุด */
    fun savePosIfPinned(context: Context) {
        if (pinned) edit(context) { putFloat(KEY_DX, dx); putFloat(KEY_DY, dy) }
    }
}

/** ตัวเลขสำหรับแสดง: ตัดศูนย์ท้ายทศนิยมทิ้ง (24.0 -> 24, 2.50 -> 2.5) */
internal fun padFmt(v: Float): String =
    runCatching { java.math.BigDecimal(v.toString()).stripTrailingZeros().toPlainString() }.getOrDefault(v.toString())

/**
 * แผงตัวเลขแบบเล็กวางทับหน้าจอ (ไม่ใช่กล่องโต้ตอบ จึงยังเห็นภาพและช่องที่กำลังใส่ค่าอยู่)
 * ขนาดตามที่ตั้งใน PadPrefs ย่อลงอัตโนมัติถ้าพื้นที่ไม่พอ · แตะที่แผงไม่ทะลุลงไปโดนหน้าจอด้านหลัง
 */
@Composable
fun CompactNumberPad(
    title: String,
    unit: String,
    initial: Float,
    onDismiss: () -> Unit,
    onOk: (Float) -> Unit,
    modifier: Modifier = Modifier,
    allowDot: Boolean = true,
    allowZero: Boolean = false,
    allowSign: Boolean = false,
    maxWidthDp: Float = Float.MAX_VALUE, // พื้นที่ที่วางได้ (dp) ถ้าจอแคบ/เตี้ย (เช่นแนวนอน) แผงจะย่อเองให้พอดี ไม่ล้นจอ
    maxHeightDp: Float = Float.MAX_VALUE,
) {
    val base = LocalDensity.current
    val fit = minOf(PadPrefs.scale(), maxWidthDp / PAD_FULL_W_DP, maxHeightDp / PAD_FULL_H_DP).coerceAtLeast(0.15f)
    val small = remember(base.density, base.fontScale, fit) { Density(base.density * fit, base.fontScale) }
    CompositionLocalProvider(LocalDensity provides small) {
        Box(modifier.pointerInput(Unit) { detectTapGestures { } }) {
            NumberPadBody(title, unit, initial, onDismiss, onOk, Modifier.width(340.dp), allowDot, allowZero, allowSign)
        }
    }
}

/**
 * แผงตัวเลขแบบลอย: ลอยกลางล่างของหน้าต่าง ทับได้ทุกหน้า รวมถึงในกล่องโต้ตอบ (ใช้ Popup ที่ไม่บล็อกการแตะข้างนอก
 * จึงไม่มีฉากหลังมืดและยังเห็น/แตะช่องด้านหลังได้) · ลากที่แถบหัวแผงเพื่อย้ายได้ · ปุ่ม −/＋ ปรับขนาด · 📌 ปักหมุดให้จำตำแหน่ง · ↺ กลับกลางล่าง
 * ทุกช่องใส่ตัวเลขของแอปใช้แผงนี้ ไม่เรียกแป้นพิมพ์ระบบ
 */
@Composable
fun FloatingPad(
    title: String,
    unit: String,
    initial: Float,
    onDismiss: () -> Unit,
    onOk: (Float) -> Unit,
    allowDot: Boolean = true,
    allowZero: Boolean = false,
    allowSign: Boolean = false,
) {
    val context = LocalContext.current
    val margin = with(LocalDensity.current) { 16.dp.roundToPx() }
    var ready by remember { mutableStateOf(false) }
    DisposableEffect(Unit) {
        if (!PadPrefs.pinned) PadPrefs.resetPos() // ไม่ได้ปักหมุด: เปิดทีไรก็อยู่กลางล่าง
        ready = true
        onDispose { PadPrefs.savePosIfPinned(context) }
    }
    if (!ready) return
    val tick = PadPrefs.tick
    val pos = remember(margin, tick) {
        object : PopupPositionProvider {
            override fun calculatePosition(anchorBounds: IntRect, windowSize: IntSize, layoutDirection: LayoutDirection, popupContentSize: IntSize): IntOffset {
                val baseX = (windowSize.width - popupContentSize.width) / 2f
                val baseY = (windowSize.height - popupContentSize.height - margin).toFloat()
                val maxX = (windowSize.width - popupContentSize.width).toFloat().coerceAtLeast(0f)
                val maxY = (windowSize.height - popupContentSize.height).toFloat().coerceAtLeast(0f)
                val x = (baseX + PadPrefs.dx).coerceIn(0f, maxX)
                val y = (baseY + PadPrefs.dy).coerceIn(0f, maxY)
                PadPrefs.dx = x - baseX // ตัดค่าที่ลากเลยขอบแล้วเขียนกลับ นิ้วกลับทิศแล้วแผงตามทันที ไม่ค้าง
                PadPrefs.dy = y - baseY
                return IntOffset(x.roundToInt(), y.roundToInt())
            }
        }
    }
    Popup(popupPositionProvider = pos, properties = PopupProperties(focusable = false, dismissOnClickOutside = false, dismissOnBackPress = false)) {
        BoxWithConstraints {
            CompactNumberPad(
                title = title, unit = unit, initial = initial, onDismiss = onDismiss, onOk = onOk,
                allowDot = allowDot, allowZero = allowZero, allowSign = allowSign,
                maxWidthDp = maxWidth.value - 20f, maxHeightDp = maxHeight.value - 40f,
            )
        }
    }
}

/** เดิมเป็นกล่องโต้ตอบกลางจอ ตอนนี้เป็นแผงลอยเหมือนทุกช่อง (คงชื่อไว้ให้โค้ดเดิมเรียกได้) */
@Composable
fun NumberPadDialog(title: String, unit: String, initial: Float, onDismiss: () -> Unit, onOk: (Float) -> Unit) =
    FloatingPad(title, unit, initial, onDismiss, onOk)

/**
 * ช่องแสดงค่าตัวเลข: หน้าตาเป็นช่องกรอกปกติ แต่แตะแล้วขึ้นแผงตัวเลขลอย (ไม่เรียกแป้นพิมพ์ระบบ)
 * ค่าที่ตกลงจะส่งกลับเป็นข้อความ (เช่น "1080", "12.5") ให้ตัวจัดการเดิมของแต่ละช่องกรองต่อ
 */
@Composable
fun PadField(
    value: String,
    onValueChange: (String) -> Unit,
    label: String,
    modifier: Modifier = Modifier,
    unit: String = "",
    enabled: Boolean = true,
    isError: Boolean = false,
    allowDot: Boolean = false,
    allowZero: Boolean = false,
) {
    var show by remember { mutableStateOf(false) }
    Box(modifier) {
        OutlinedTextField(
            value = value,
            onValueChange = {},
            readOnly = true,
            enabled = enabled,
            isError = isError,
            singleLine = true,
            label = { Text(label) },
            trailingIcon = { Text("✎", color = Color(0xFF9E9AB0)) },
            modifier = Modifier.fillMaxWidth(),
        )
        Box(Modifier.matchParentSize().clickable(enabled = enabled) { show = true }) // แตะทั้งช่อง = เปิดแผง
    }
    if (show) {
        FloatingPad(
            title = label,
            unit = unit,
            initial = value.trim().toFloatOrNull() ?: 0f,
            allowDot = allowDot,
            allowZero = allowZero,
            onDismiss = { show = false },
            onOk = { v -> onValueChange(padFmt(v)); show = false },
        )
    }
}

/** แถบหัวแผง: ลากเพื่อย้ายแผง + ปุ่มลดขนาด / เพิ่มขนาด / ปักหมุด / กลับกลางล่าง / ปิด */
@Composable
private fun PadHeader(title: String, onDismiss: () -> Unit) {
    val context = LocalContext.current
    val view = LocalView.current
    Row(
        Modifier
            .fillMaxWidth()
            .pointerInput(Unit) {
                // ลากแผง: แผงเป็นหน้าต่างลอยที่ขยับตามนิ้ว พิกัดในหน้าต่างจึงเพี้ยนเมื่อหน้าต่างขยับ
                // เลยแปลงเป็นพิกัดบนจอ (ตำแหน่งหน้าต่างบนจอ + ตำแหน่งนิ้วในหน้าต่าง) ก่อนหาระยะที่นิ้วเลื่อน
                val loc = IntArray(2)
                fun screen(p: Offset): Offset {
                    view.getLocationOnScreen(loc)
                    return Offset(loc[0] + p.x, loc[1] + p.y)
                }
                awaitEachGesture {
                    val down = awaitFirstDown(requireUnconsumed = true)
                    var last = screen(down.position)
                    while (true) {
                        val ev = awaitPointerEvent()
                        val ch = ev.changes.firstOrNull { it.id == down.id } ?: break
                        if (!ch.pressed) break
                        val cur = screen(ch.position)
                        PadPrefs.dragBy(cur.x - last.x, cur.y - last.y)
                        last = cur
                        ch.consume()
                    }
                }
            },
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(6.dp),
    ) {
        Text("⠿", color = Palette.Accent, fontSize = 22.sp, modifier = Modifier.padding(end = 2.dp)) // ที่จับลาก
        Text(title, Modifier.weight(1f), color = Color(0xFFC9C4D4), fontSize = 15.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
        HeadBtn("−", false) { PadPrefs.setSize(context, PadPrefs.size - 10f) }
        HeadBtn("＋", false) { PadPrefs.setSize(context, PadPrefs.size + 10f) }
        HeadBtn("📌", PadPrefs.pinned) { PadPrefs.setPinned(context, !PadPrefs.pinned) }
        HeadBtn("↺", false) { PadPrefs.resetPos() }
        HeadBtn("✕", false, onClick = onDismiss)
    }
}

@Composable
private fun HeadBtn(label: String, active: Boolean, onClick: () -> Unit) {
    Box(
        Modifier
            .size(30.dp)
            .clip(CircleShape)
            .background(if (active) Palette.Accent else Color(0xFF33333F))
            .border(1.dp, if (active) Palette.Accent else Color(0xFF454556), CircleShape)
            .clickable(onClick = onClick),
        contentAlignment = Alignment.Center,
    ) { Text(label, color = if (active) Color(0xFF2A1A66) else Color(0xFFC9C4D4), fontSize = 14.sp) }
}

/** แผงตัวเลขของแอป (ไม่ใช้แป้นพิมพ์ระบบ): 123 / 456 / 789 / ลบ 0 . ตกลง รองรับจุดทศนิยม */
@Composable
private fun NumberPadBody(
    title: String,
    unit: String,
    initial: Float,
    onDismiss: () -> Unit,
    onOk: (Float) -> Unit,
    modifier: Modifier,
    allowDot: Boolean = true,
    allowZero: Boolean = false,
    allowSign: Boolean = false,
) {
    val context = LocalContext.current
    var s by remember { mutableStateOf(padFmt(initial)) }
    var fresh by remember { mutableStateOf(true) } // แตะเลขแรก = แทนที่ค่าเดิมทั้งหมด

    fun digit(d: String) {
        if (fresh) {
            s = d
            fresh = false
        } else if (s == "0") {
            s = d
        } else if (s.length < 9) {
            s += d
        }
    }

    fun dot() {
        if (fresh) {
            s = "0."
            fresh = false
        } else if (allowDot && !s.contains('.') && s.length < 9) {
            s = if (s.isEmpty()) "0." else "$s."
        }
    }

    fun back() {
        fresh = false
        s = s.dropLast(1)
    }

    fun sign() {
        fresh = false
        s = if (s.startsWith("-")) s.drop(1) else "-$s"
    }

    fun ok() {
        val v = s.toFloatOrNull()
        if (v == null || !v.isFinite()) {
            Toast.makeText(context, "ใส่ตัวเลขให้ถูกต้อง", Toast.LENGTH_SHORT).show()
        } else if (!allowZero && !allowSign && v <= 0f) {
            Toast.makeText(context, "ใส่ตัวเลขที่มากกว่า 0", Toast.LENGTH_SHORT).show()
        } else {
            onOk(v)
        }
    }

    val shape = RoundedCornerShape(26.dp)
    Column(
        modifier
            .shadow(18.dp, shape, ambientColor = Palette.Accent, spotColor = Palette.Accent)
            .clip(shape)
            .background(Brush.verticalGradient(listOf(Color(0xF52A2A3E), Color(0xF5191923))))
            .border(1.dp, Brush.verticalGradient(listOf(Palette.Accent.copy(alpha = 0.8f), Palette.Accent.copy(alpha = 0.25f))), shape)
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp),
    ) {
        PadHeader(title, onDismiss)
        Row(
            Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(16.dp))
                .background(Palette.Bg)
                .border(1.dp, Palette.Accent, RoundedCornerShape(16.dp))
                .padding(horizontal = 16.dp, vertical = 14.dp),
            horizontalArrangement = Arrangement.End,
            verticalAlignment = Alignment.Bottom,
        ) {
            Text(s.ifEmpty { "0" }, color = Color.White, fontSize = 36.sp, fontWeight = FontWeight.Bold, maxLines = 1)
            Text("  $unit", color = Color(0xFF9E9AB0), fontSize = 16.sp, modifier = Modifier.padding(bottom = 6.dp))
        }
        val keyBg = Palette.PanelHigh
        val keyFg = Color.White
        for (row in listOf(listOf("1", "2", "3"), listOf("4", "5", "6"), listOf("7", "8", "9"))) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                for (k in row) PadKey(k, keyBg, keyFg) { digit(k) }
            }
        }
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            if (allowSign) PadKey("±", keyBg, keyFg) { sign() }
            PadKey("ลบ", Color(0xFF4A2630), Color(0xFFFF8A80)) { back() }
            PadKey("0", keyBg, keyFg) { digit("0") }
            PadKey(".", keyBg, if (allowDot) keyFg else Color(0xFF55525F)) { dot() } // ช่องที่รับเฉพาะจำนวนเต็ม: ปุ่มจุดจางและกดไม่ติด
            PadKey("ตกลง", Palette.Accent, Color(0xFF2A1A66)) { ok() }
        }
    }
}

@Composable
private fun RowScope.PadKey(label: String, bg: Color, fg: Color, onClick: () -> Unit) {
    val shape = RoundedCornerShape(18.dp)
    Box(
        Modifier
            .weight(1f)
            .height(60.dp)
            .clip(shape)
            .background(bg)
            .border(1.dp, Color(0x22FFFFFF), shape)
            .clickable(onClick = onClick),
        contentAlignment = Alignment.Center,
    ) { Text(label, color = fg, fontSize = if (label.length > 1) 17.sp else 26.sp, fontWeight = FontWeight.Medium) }
}
