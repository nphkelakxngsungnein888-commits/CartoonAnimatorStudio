package com.nop.cartoonstudio

import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.RowScope
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Density
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.IntRect
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.window.Popup
import androidx.compose.ui.window.PopupPositionProvider
import androidx.compose.ui.window.PopupProperties

/** ขนาดแผงตัวเลขแบบลอย เทียบกับขนาดเดิม (0.90 = 90%) ใหญ่กว่าเดิม (0.30) 3 เท่า ปรับทั้งปุ่ม ตัวเลข และช่องว่างพร้อมกัน */
const val NUMBER_PAD_SCALE = 0.90f

/** ขนาดเต็ม (scale 1.0) ของแผงตัวเลขเป็น dp ใช้คำนวณว่าพอดีกับจอไหม: กว้าง 340 / สูงประมาณ 430 */
private const val PAD_FULL_W_DP = 340f
private const val PAD_FULL_H_DP = 430f

/** ตัวเลขสำหรับแสดง: ตัดศูนย์ท้ายทศนิยมทิ้ง (24.0 -> 24, 2.50 -> 2.5) */
internal fun padFmt(v: Float): String =
    runCatching { java.math.BigDecimal(v.toString()).stripTrailingZeros().toPlainString() }.getOrDefault(v.toString())

/**
 * แผงตัวเลขแบบเล็กวางทับหน้าจอ (ไม่ใช่กล่องโต้ตอบ จึงยังเห็นภาพและช่องที่กำลังใส่ค่าอยู่)
 * วางไว้กลางจอด้านล่าง ขนาด NUMBER_PAD_SCALE ของแผงเดิม (ย่อลงอัตโนมัติถ้าจอไม่พอ)
 * แตะที่แผงไม่ทะลุลงไปโดนหน้าจอด้านหลัง
 */
@Composable
fun CompactNumberPad(
    title: String,
    unit: String,
    initial: Float,
    onDismiss: () -> Unit,
    onOk: (Float) -> Unit,
    modifier: Modifier = Modifier,
    allowDot: Boolean = true,
    allowZero: Boolean = false,
    allowSign: Boolean = false,
    maxWidthDp: Float = Float.MAX_VALUE, // พื้นที่ที่วางได้ (dp) ถ้าจอแคบ/เตี้ย (เช่นแนวนอน) แผงจะย่อเองให้พอดี ไม่ล้นจอ
    maxHeightDp: Float = Float.MAX_VALUE,
) {
    val base = LocalDensity.current
    val fit = minOf(NUMBER_PAD_SCALE, maxWidthDp / PAD_FULL_W_DP, maxHeightDp / PAD_FULL_H_DP).coerceAtLeast(0.3f)
    val small = remember(base.density, base.fontScale, fit) { Density(base.density * fit, base.fontScale) }
    CompositionLocalProvider(LocalDensity provides small) {
        Box(modifier.pointerInput(Unit) { detectTapGestures { } }) {
            NumberPadBody(title, unit, initial, onDismiss, onOk, Modifier.width(340.dp), allowDot, allowZero, allowSign)
        }
    }
}

/**
 * แผงตัวเลขแบบลอย: ลอยกลางล่างของหน้าต่าง ทับได้ทุกหน้า รวมถึงในกล่องโต้ตอบ (ใช้ Popup ที่ไม่บล็อกการแตะข้างนอก
 * จึงไม่มีฉากหลังมืดและยังเห็น/แตะช่องด้านหลังได้) ย่อเองถ้าจอไม่พอ · ทุกช่องใส่ตัวเลขของแอปใช้แผงนี้ ไม่เรียกแป้นพิมพ์ระบบ
 */
@Composable
fun FloatingPad(
    title: String,
    unit: String,
    initial: Float,
    onDismiss: () -> Unit,
    onOk: (Float) -> Unit,
    allowDot: Boolean = true,
    allowZero: Boolean = false,
    allowSign: Boolean = false,
) {
    val margin = with(LocalDensity.current) { 16.dp.roundToPx() }
    val pos = remember(margin) {
        object : PopupPositionProvider {
            override fun calculatePosition(anchorBounds: IntRect, windowSize: IntSize, layoutDirection: LayoutDirection, popupContentSize: IntSize) =
                IntOffset((windowSize.width - popupContentSize.width) / 2, (windowSize.height - popupContentSize.height - margin).coerceAtLeast(0))
        }
    }
    Popup(popupPositionProvider = pos, properties = PopupProperties(focusable = false, dismissOnClickOutside = false, dismissOnBackPress = false)) {
        BoxWithConstraints {
            CompactNumberPad(
                title = title, unit = unit, initial = initial, onDismiss = onDismiss, onOk = onOk,
                allowDot = allowDot, allowZero = allowZero, allowSign = allowSign,
                maxWidthDp = maxWidth.value - 20f, maxHeightDp = maxHeight.value - 40f,
            )
        }
    }
}

/** เดิมเป็นกล่องโต้ตอบกลางจอ ตอนนี้เป็นแผงลอยเหมือนทุกช่อง (คงชื่อไว้ให้โค้ดเดิมเรียกได้) */
@Composable
fun NumberPadDialog(title: String, unit: String, initial: Float, onDismiss: () -> Unit, onOk: (Float) -> Unit) =
    FloatingPad(title, unit, initial, onDismiss, onOk)

/**
 * ช่องแสดงค่าตัวเลข: หน้าตาเป็นช่องกรอกปกติ แต่แตะแล้วขึ้นแผงตัวเลขลอย (ไม่เรียกแป้นพิมพ์ระบบ)
 * ค่าที่ตกลงจะส่งกลับเป็นข้อความ (เช่น "1080", "12.5") ให้ตัวจัดการเดิมของแต่ละช่องกรองต่อ
 */
@Composable
fun PadField(
    value: String,
    onValueChange: (String) -> Unit,
    label: String,
    modifier: Modifier = Modifier,
    unit: String = "",
    enabled: Boolean = true,
    isError: Boolean = false,
    allowDot: Boolean = false,
    allowZero: Boolean = false,
) {
    var show by remember { mutableStateOf(false) }
    Box(modifier) {
        OutlinedTextField(
            value = value,
            onValueChange = {},
            readOnly = true,
            enabled = enabled,
            isError = isError,
            singleLine = true,
            label = { Text(label) },
            trailingIcon = { Text("✎", color = Color(0xFF9E9AB0)) },
            modifier = Modifier.fillMaxWidth(),
        )
        Box(Modifier.matchParentSize().clickable(enabled = enabled) { show = true }) // แตะทั้งช่อง = เปิดแผง
    }
    if (show) {
        FloatingPad(
            title = label,
            unit = unit,
            initial = value.trim().toFloatOrNull() ?: 0f,
            allowDot = allowDot,
            allowZero = allowZero,
            onDismiss = { show = false },
            onOk = { v -> onValueChange(padFmt(v)); show = false },
        )
    }
}

/** แผงตัวเลขของแอป (ไม่ใช้แป้นพิมพ์ระบบ): 123 / 456 / 789 / ลบ 0 . ตกลง รองรับจุดทศนิยม */
@Composable
private fun NumberPadBody(
    title: String,
    unit: String,
    initial: Float,
    onDismiss: () -> Unit,
    onOk: (Float) -> Unit,
    modifier: Modifier,
    allowDot: Boolean = true,
    allowZero: Boolean = false,
    allowSign: Boolean = false,
) {
    val context = LocalContext.current
    var s by remember { mutableStateOf(padFmt(initial)) }
    var fresh by remember { mutableStateOf(true) } // แตะเลขแรก = แทนที่ค่าเดิมทั้งหมด

    fun digit(d: String) {
        if (fresh) {
            s = d
            fresh = false
        } else if (s == "0") {
            s = d
        } else if (s.length < 9) {
            s += d
        }
    }

    fun dot() {
        if (fresh) {
            s = "0."
            fresh = false
        } else if (allowDot && !s.contains('.') && s.length < 9) {
            s = if (s.isEmpty()) "0." else "$s."
        }
    }

    fun back() {
        fresh = false
        s = s.dropLast(1)
    }

    fun sign() {
        fresh = false
        s = if (s.startsWith("-")) s.drop(1) else "-$s"
    }

    fun ok() {
        val v = s.toFloatOrNull()
        if (v == null || !v.isFinite()) {
            Toast.makeText(context, "ใส่ตัวเลขให้ถูกต้อง", Toast.LENGTH_SHORT).show()
        } else if (!allowZero && !allowSign && v <= 0f) {
            Toast.makeText(context, "ใส่ตัวเลขที่มากกว่า 0", Toast.LENGTH_SHORT).show()
        } else {
            onOk(v)
        }
    }

    val shape = RoundedCornerShape(26.dp)
    Column(
        modifier
            .clip(shape)
            .background(Brush.verticalGradient(listOf(Color(0xFF242434), Palette.Panel)))
            .border(1.dp, Palette.Accent.copy(alpha = 0.55f), shape)
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp),
    ) {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Text(title, Modifier.weight(1f), color = Color(0xFFC9C4D4), fontSize = 15.sp)
            Box(
                Modifier
                    .clip(RoundedCornerShape(50))
                    .background(Color(0xFF33333F))
                    .clickable(onClick = onDismiss)
                    .padding(horizontal = 12.dp, vertical = 4.dp),
            ) { Text("✕", color = Color(0xFFC9C4D4), fontSize = 14.sp) }
        }
        Row(
            Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(16.dp))
                .background(Palette.Bg)
                .border(1.dp, Palette.Accent, RoundedCornerShape(16.dp))
                .padding(horizontal = 16.dp, vertical = 14.dp),
            horizontalArrangement = Arrangement.End,
            verticalAlignment = Alignment.Bottom,
        ) {
            Text(s.ifEmpty { "0" }, color = Color.White, fontSize = 36.sp, fontWeight = FontWeight.Bold, maxLines = 1)
            Text("  $unit", color = Color(0xFF9E9AB0), fontSize = 16.sp, modifier = Modifier.padding(bottom = 6.dp))
        }
        val keyBg = Palette.PanelHigh
        val keyFg = Color.White
        for (row in listOf(listOf("1", "2", "3"), listOf("4", "5", "6"), listOf("7", "8", "9"))) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                for (k in row) PadKey(k, keyBg, keyFg) { digit(k) }
            }
        }
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            if (allowSign) PadKey("±", keyBg, keyFg) { sign() }
            PadKey("ลบ", Color(0xFF4A2630), Color(0xFFFF8A80)) { back() }
            PadKey("0", keyBg, keyFg) { digit("0") }
            PadKey(".", keyBg, if (allowDot) keyFg else Color(0xFF55525F)) { dot() } // ช่องที่รับเฉพาะจำนวนเต็ม: ปุ่มจุดจางและกดไม่ติด
            PadKey("ตกลง", Palette.Accent, Color(0xFF2A1A66)) { ok() }
        }
    }
}

@Composable
private fun RowScope.PadKey(label: String, bg: Color, fg: Color, onClick: () -> Unit) {
    Box(
        Modifier
            .weight(1f)
            .height(60.dp)
            .clip(RoundedCornerShape(18.dp))
            .background(bg)
            .clickable(onClick = onClick),
        contentAlignment = Alignment.Center,
    ) { Text(label, color = fg, fontSize = if (label.length > 1) 17.sp else 26.sp, fontWeight = FontWeight.Medium) }
}
