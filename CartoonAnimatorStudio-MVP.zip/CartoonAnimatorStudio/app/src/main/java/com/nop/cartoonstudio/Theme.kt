package com.nop.cartoonstudio

import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp

/** สีกลางของแอป (ใช้ร่วมกันทุกหน้าให้โทนเดียวกัน) */
object Palette {
    val Bg = Color(0xFF121218)        // พื้นหลังหลัก
    val Panel = Color(0xFF1C1C26)     // แถบ/แผงเครื่องมือ
    val PanelHigh = Color(0xFF272734) // การ์ด/รายการในแผง
    val Stroke = Color(0xFF3A3A4A)    // เส้นขอบบาง
    val Accent = Color(0xFFB69DFF)    // ม่วงหลัก
}

private val AppColorScheme = darkColorScheme(
    primary = Palette.Accent,
    onPrimary = Color(0xFF2A1A66),
    primaryContainer = Color(0xFF42338A),
    onPrimaryContainer = Color(0xFFE9E0FF),
    secondary = Color(0xFF4FC3F7),
    onSecondary = Color(0xFF00344A),
    secondaryContainer = Color(0xFF3B3360),
    onSecondaryContainer = Color(0xFFE9E0FF),
    background = Palette.Bg,
    onBackground = Color(0xFFE7E3EE),
    surface = Palette.Panel,
    onSurface = Color(0xFFE7E3EE),
    surfaceVariant = Palette.PanelHigh,
    onSurfaceVariant = Color(0xFFC9C4D4),
    outline = Color(0xFF6B6A7C),
)

@Composable
fun CartoonTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = AppColorScheme,
        shapes = Shapes(
            small = RoundedCornerShape(10.dp),
            medium = RoundedCornerShape(16.dp),
            large = RoundedCornerShape(22.dp),
        ),
        content = content,
    )
}
