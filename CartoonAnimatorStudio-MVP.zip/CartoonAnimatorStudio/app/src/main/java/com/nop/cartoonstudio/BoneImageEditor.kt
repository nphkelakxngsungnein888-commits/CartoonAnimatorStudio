package com.nop.cartoonstudio

import android.graphics.Matrix
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.FilterChip
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.drawIntoCanvas
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlin.math.atan2
import kotlin.math.max
import kotlin.math.min
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

private enum class ImgTool { MOVE, SCALE, ROTATE }

private fun viewScaleOf(width: Float, boneLength: Float): Float = min(1f, width * 0.8f / max(boneLength, 1f))

/** เมทริกซ์วาดภาพในหน้าใส่ภาพ: กระดูกอยู่แนวนอนกลางจอ (โคนซ้าย ปลายขวา) */
private fun editorMatrix(img: BoneImage, boneLength: Float, vs: Float, cx: Float, cy: Float): Matrix {
    val m = Matrix()
    m.postTranslate(-img.bitmap.width / 2f, -img.bitmap.height / 2f)
    m.postScale(img.scale, img.scale)
    m.postRotate(img.rotation)
    m.postTranslate(img.x - boneLength / 2f, img.y)
    m.postScale(vs, vs)
    m.postTranslate(cx, cy)
    return m
}

/**
 * หน้าใส่ภาพให้กระดูก 1 เส้น (รอบที่ 2)
 * - กระดูกแสดงเป็นเส้นขาวแนวนอน (โคนซ้าย ปลายขวา) ภาพไม่มีกรอบ
 * - "เพิ่มภาพ" แล้วเลือกโหมด ย้าย / ขยาย / หมุน ลากนิ้วบนจอเพื่อปรับภาพที่เลือกอยู่
 * - "เสร็จ" กลับหน้ากระดูก (ภาพถูกเก็บไว้กับกระดูกเส้นนี้ตลอด)
 */
@Composable
fun BoneImageEditor(bone: Bone, onDone: () -> Unit) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var tool by remember { mutableStateOf(ImgTool.MOVE) }
    var activeIdx by remember { mutableIntStateOf(0) }
    var canvasSize by remember { mutableStateOf(IntSize.Zero) }
    val paint = remember {
        android.graphics.Paint(android.graphics.Paint.FILTER_BITMAP_FLAG or android.graphics.Paint.ANTI_ALIAS_FLAG)
    }

    BackHandler(onBack = onDone)

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri ->
        if (uri != null) {
            scope.launch {
                val r = runCatching { withContext(Dispatchers.IO) { ImageImport.decode(context, uri) } }
                r.onSuccess { bmp ->
                    val img = BoneImage(bmp)
                    val maxSide = max(bmp.width, bmp.height).toFloat()
                    img.scale = if (maxSide > 300f) 300f / maxSide else 1f
                    img.x = bone.length / 2f // วางกึ่งกลางเส้นกระดูก
                    bone.images.add(img)
                    activeIdx = bone.images.size - 1
                }.onFailure {
                    Toast.makeText(context, "นำเข้าไม่สำเร็จ: ${it.message ?: it.javaClass.simpleName}", Toast.LENGTH_LONG).show()
                }
            }
        }
    }

    Column(
        Modifier
            .fillMaxSize()
            .systemBarsPadding()
            .background(Color(0xFF3A3A44))
            .pointerInput(Unit) { detectTapGestures { } }, // กันการสัมผัสทะลุไปหน้าจัดกระดูกที่อยู่ด้านล่าง
    ) {
        Box(Modifier.weight(1f).fillMaxWidth()) {
            Canvas(
                Modifier
                    .fillMaxSize()
                    .onSizeChanged { canvasSize = it }
                    .pointerInput(bone) {
                        detectDragGestures { change, drag ->
                            change.consume()
                            val img = bone.images.getOrNull(activeIdx) ?: return@detectDragGestures
                            val vs = viewScaleOf(canvasSize.width.toFloat(), bone.length)
                            val c = Offset(
                                canvasSize.width / 2f + (img.x - bone.length / 2f) * vs,
                                canvasSize.height / 2f + img.y * vs,
                            ) // ตำแหน่งกึ่งกลางภาพบนจอ
                            val pos = change.position
                            val prev = pos - drag
                            when (tool) {
                                ImgTool.MOVE -> {
                                    img.x += drag.x / vs
                                    img.y += drag.y / vs
                                }
                                ImgTool.SCALE -> {
                                    val d0 = (prev - c).getDistance()
                                    val d1 = (pos - c).getDistance()
                                    if (d0 > 8f) img.scale = (img.scale * d1 / d0).coerceIn(0.05f, 20f)
                                }
                                ImgTool.ROTATE -> {
                                    val a1 = atan2(pos.y - c.y, pos.x - c.x)
                                    val a0 = atan2(prev.y - c.y, prev.x - c.x)
                                    val d = Math.toDegrees((a1 - a0).toDouble()).toFloat()
                                    img.rotation = normalizeAngle(img.rotation + normalizeAngle(d))
                                }
                            }
                        }
                    },
            ) {
                val l = max(bone.length, 1f)
                val vs = viewScaleOf(this.size.width, bone.length)
                val cx = this.size.width / 2f
                val cy = this.size.height / 2f
                drawIntoCanvas { c ->
                    for (img in bone.images) c.nativeCanvas.drawBitmap(img.bitmap, editorMatrix(img, l, vs, cx, cy), paint)
                }
                val a = Offset(cx - l * vs / 2f, cy)
                val b = Offset(cx + l * vs / 2f, cy)
                drawLine(Color.White, a, b, strokeWidth = 4f)
                drawCircle(Color.White, radius = 9f, center = a)
                drawCircle(Color.White, radius = 9f, center = b)
            }

            val hint = if (bone.images.isEmpty()) {
                "กด \"เพิ่มภาพ\" เพื่อใส่ภาพให้กระดูกเส้นนี้"
            } else {
                when (tool) {
                    ImgTool.MOVE -> "ย้าย: ลากนิ้วเพื่อเลื่อนภาพ"
                    ImgTool.SCALE -> "ขยาย: ลากเข้า/ออกจากกลางภาพ"
                    ImgTool.ROTATE -> "หมุน: ลากวนรอบกลางภาพ"
                }
            }
            Box(
                Modifier
                    .align(Alignment.TopCenter)
                    .padding(8.dp)
                    .clip(RoundedCornerShape(12.dp))
                    .background(Color(0xFFFFD600))
                    .padding(horizontal = 12.dp, vertical = 6.dp),
            ) { Text(hint, color = Color.Black, fontSize = 13.sp) }
        }

        // รูปย่อของภาพในกระดูกเส้นนี้ (แตะเพื่อเลือกภาพที่จะปรับ)
        Row(
            Modifier.fillMaxWidth().background(Palette.Panel).horizontalScroll(rememberScrollState()).padding(horizontal = 8.dp, vertical = 6.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            bone.images.forEachIndexed { i, img ->
                val on = i == activeIdx
                Image(
                    bitmap = img.bitmap.asImageBitmap(),
                    contentDescription = null,
                    modifier = Modifier
                        .size(56.dp)
                        .clip(RoundedCornerShape(10.dp))
                        .border(if (on) 3.dp else 1.dp, if (on) Color(0xFF00E676) else Color.Gray, RoundedCornerShape(10.dp))
                        .clickable { activeIdx = i }
                        .padding(2.dp),
                )
            }
        }

        // ปุ่มควบคุม
        Row(
            Modifier.fillMaxWidth().background(Palette.Panel).horizontalScroll(rememberScrollState()).padding(horizontal = 8.dp, vertical = 6.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            OutlinedButton(
                onClick = { picker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)) },
                modifier = Modifier.heightIn(min = 48.dp),
            ) { Text("เพิ่มภาพ") }
            FilterChip(
                selected = tool == ImgTool.MOVE,
                onClick = { tool = ImgTool.MOVE },
                label = { Text("ย้าย") },
                modifier = Modifier.heightIn(min = 48.dp),
            )
            FilterChip(
                selected = tool == ImgTool.SCALE,
                onClick = { tool = ImgTool.SCALE },
                label = { Text("ขยาย") },
                modifier = Modifier.heightIn(min = 48.dp),
            )
            FilterChip(
                selected = tool == ImgTool.ROTATE,
                onClick = { tool = ImgTool.ROTATE },
                label = { Text("หมุน") },
                modifier = Modifier.heightIn(min = 48.dp),
            )
            OutlinedButton(
                onClick = {
                    if (activeIdx in bone.images.indices) {
                        bone.images.removeAt(activeIdx)
                        activeIdx = max(activeIdx - 1, 0)
                    }
                },
                enabled = bone.images.isNotEmpty(),
                modifier = Modifier.heightIn(min = 48.dp),
            ) { Text("ลบภาพ") }
            Button(onClick = onDone, modifier = Modifier.heightIn(min = 48.dp)) { Text("เสร็จ ✓") }
        }
    }
}
