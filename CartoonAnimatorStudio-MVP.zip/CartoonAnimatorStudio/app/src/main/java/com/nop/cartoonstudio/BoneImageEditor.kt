package com.nop.cartoonstudio

import android.graphics.Bitmap
import android.graphics.Matrix
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.FilterChip
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.drawIntoCanvas
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

private enum class ImgTool { MOVE, SCALE, ROTATE }

private const val FIT_GRAB_RADIUS = 110f // นิ้วอยู่ใกล้จุดหัว/ท้ายไม่เกินเท่านี้ (พิกเซล) = จับจุดนั้นลากได้

private fun viewScaleOf(width: Float, boneLength: Float): Float = min(1f, width * 0.8f / max(boneLength, 1f))

/** เมทริกซ์วาดภาพในหน้าใส่ภาพ: กระดูกอยู่แนวนอนกลางจอ (โคนซ้าย ปลายขวา) */
private fun editorMatrix(img: BoneImage, boneLength: Float, vs: Float, cx: Float, cy: Float): Matrix {
    val m = Matrix()
    m.postTranslate(-img.bitmap.width / 2f, -img.bitmap.height / 2f)
    m.postScale(img.scale, img.scale)
    m.postRotate(img.rotation)
    m.postTranslate(img.x - boneLength / 2f, img.y)
    m.postScale(vs, vs)
    m.postTranslate(cx, cy)
    return m
}

/**
 * พลิกภาพแบบกลับฝั่ง (กระจก) ไม่ใช่การหมุน: สร้างบิตแมปที่กลับด้านใหม่ แล้วกลับมุมหมุนของภาพ
 * เพื่อให้ผลที่เห็นบนจอเป็นการกลับซ้าย-ขวา (หรือบน-ล่าง) จริง แม้ภาพถูกหมุนไว้ก่อนแล้ว; ตำแหน่งกึ่งกลางและขนาดคงเดิม
 */
private fun flipImage(img: BoneImage, horizontal: Boolean) {
    val m = Matrix()
    if (horizontal) m.preScale(-1f, 1f) else m.preScale(1f, -1f)
    val src = img.bitmap
    img.bitmap = Bitmap.createBitmap(src, 0, 0, src.width, src.height, m, false)
    img.rotation = normalizeAngle(-img.rotation)
}

/** ค่าเดิมของภาพก่อนกด "ปรับพอดีกระดูก" ไว้ให้ "เลิกปรับ" */
private class FitUndo(val img: BoneImage, val x: Float, val y: Float, val rotation: Float, val scale: Float)

/**
 * วางภาพให้พอดีกระดูก: head = จุดหัวภาพ (ไปอยู่ที่โคนกระดูก), tail = จุดท้ายภาพ (ไปอยู่ที่ปลายกระดูก) เป็นพิกัดพิกเซลของภาพ
 * ปรับขนาดให้ระยะหัว-ท้ายเท่าความยาวกระดูก หมุนให้แนวหัว-ท้ายขนานกระดูก และเลื่อนให้หัวภาพตรงโคนกระดูก
 * คืนข้อความบอกสาเหตุถ้าทำไม่ได้ (ภาพไม่ถูกแตะต้อง) คืน null ถ้าสำเร็จ
 */
private fun fitImageToBone(img: BoneImage, bone: Bone, head: Offset, tail: Offset): String? {
    val dx = tail.x - head.x
    val dy = tail.y - head.y
    val d = hypot(dx, dy)
    if (d < 4f) return "จุดหัวกับท้ายใกล้กันเกินไป แตะใหม่ให้ห่างกันกว่านี้"
    val s = bone.length / d
    if (s < 0.05f || s > 20f) return "ภาพเล็กหรือใหญ่เกินกว่าจะปรับให้เท่ากระดูกได้ (ปรับได้ 0.05–20 เท่า)"
    // แนวหัว->ท้ายในภาพทำมุม theta; ต้องหมุนภาพ -theta ให้ชี้ไปตามแกนกระดูก (ขวา)
    val theta = Math.toDegrees(atan2(dy.toDouble(), dx.toDouble())).toFloat()
    val r = normalizeAngle(-theta)
    val rad = Math.toRadians(r.toDouble())
    val hx0 = (head.x - img.bitmap.width / 2f) * s
    val hy0 = (head.y - img.bitmap.height / 2f) * s
    val hx = (hx0 * cos(rad) - hy0 * sin(rad)).toFloat() // ตำแหน่งหัวภาพหลังขยาย+หมุน เทียบกึ่งกลางภาพ
    val hy = (hx0 * sin(rad) + hy0 * cos(rad)).toFloat()
    img.scale = s
    img.rotation = r
    img.x = -hx // ให้หัวภาพตรงโคนกระดูก (0,0) ในกรอบของกระดูก
    img.y = -hy
    return null
}

/**
 * หน้าใส่ภาพให้กระดูก 1 เส้น (รอบที่ 2)
 * - กระดูกแสดงเป็นเส้นขาวแนวนอน (โคนซ้าย ปลายขวา) ภาพไม่มีกรอบ
 * - "เพิ่มภาพ" แล้วเลือกโหมด ย้าย / ขยาย / หมุน ลากนิ้วบนจอเพื่อปรับภาพที่เลือกอยู่
 * - "เสร็จ" กลับหน้ากระดูก (ภาพถูกเก็บไว้กับกระดูกเส้นนี้ตลอด)
 */
@Composable
fun BoneImageEditor(skeleton: Skeleton, bone: Bone, onDone: () -> Unit) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var tool by remember { mutableStateOf(ImgTool.MOVE) }
    var activeIdx by remember { mutableIntStateOf(0) }
    var canvasSize by remember { mutableStateOf(IntSize.Zero) }
    val paint = remember {
        android.graphics.Paint(android.graphics.Paint.FILTER_BITMAP_FLAG or android.graphics.Paint.ANTI_ALIAS_FLAG)
    }
    val ghostPaint = remember { // ภาพของกระดูกเส้นอื่น แสดงจางๆ เป็นแนวอ้างอิง
        android.graphics.Paint(android.graphics.Paint.FILTER_BITMAP_FLAG or android.graphics.Paint.ANTI_ALIAS_FLAG).apply { alpha = 80 }
    }

    BackHandler(onBack = onDone)

    var pendingBitmap by remember { mutableStateOf<Bitmap?>(null) } // ภาพที่เพิ่งเลือก รอตัดภาพ/ยืนยัน

    fun addImage(bmp: Bitmap) {
        val img = BoneImage(bmp)
        val maxSide = max(bmp.width, bmp.height).toFloat()
        img.scale = if (maxSide > 300f) 300f / maxSide else 1f
        img.x = bone.length / 2f // วางกึ่งกลางเส้นกระดูก
        bone.images.add(img)
        activeIdx = bone.images.size - 1
    }

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri ->
        if (uri != null) {
            scope.launch {
                val r = runCatching { withContext(Dispatchers.IO) { ImageImport.trimTransparent(ImageImport.decode(context, uri)) } }
                r.onSuccess { bmp ->
                    pendingBitmap = bmp // เปิดหน้าตัดภาพ (วาดบ่วง) ก่อนนำเข้า
                }.onFailure {
                    Toast.makeText(context, "นำเข้าไม่สำเร็จ: ${it.message ?: it.javaClass.simpleName}", Toast.LENGTH_LONG).show()
                }
            }
        }
    }

    var fitStep by remember { mutableIntStateOf(0) } // ปรับพอดีกระดูก: 0 = ปิด, 1 = รอแตะหัวภาพ, 2 = รอแตะท้ายภาพ, 3 = แตะครบ 2 จุดแล้ว ลากจุดปรับตำแหน่งได้ แล้วกด "ตกลง"
    var fitHead by remember { mutableStateOf<Offset?>(null) } // จุดหัวที่แตะ (พิกัดพิกเซลของภาพ)
    var fitTail by remember { mutableStateOf<Offset?>(null) } // จุดท้ายที่แตะ (พิกัดพิกเซลของภาพ)
    var fitUndo by remember { mutableStateOf<FitUndo?>(null) }

    fun onFitTap(pos: Offset) {
        val img = bone.images.getOrNull(activeIdx) ?: return
        val vs = viewScaleOf(canvasSize.width.toFloat(), bone.length)
        val m = editorMatrix(img, max(bone.length, 1f), vs, canvasSize.width / 2f, canvasSize.height / 2f)
        val inv = Matrix()
        if (!m.invert(inv)) return
        val pt = floatArrayOf(pos.x, pos.y)
        inv.mapPoints(pt) // จุดที่แตะบนจอ -> พิกเซลของภาพ (คิดการขยาย/หมุน/ตำแหน่งของภาพแล้ว)
        val local = Offset(pt[0], pt[1])
        if (fitStep == 1) {
            fitHead = local
            fitStep = 2
        } else if (fitStep == 2) {
            fitTail = local
            fitStep = 3 // แตะครบ 2 จุดแล้ว: ยังไม่ปรับภาพ ให้ลากจุดไปวางให้ตรงก่อน แล้วกด "ตกลง"
        }
    }

    /** ปุ่ม "ตกลง": ปรับภาพให้พอดีกระดูกตามตำแหน่งจุดหัว/ท้ายที่ลากวางไว้ (ถ้าทำไม่ได้ แจ้งสาเหตุและอยู่ในโหมดลากจุดต่อ) */
    fun onFitConfirm() {
        val img = bone.images.getOrNull(activeIdx) ?: return
        val head = fitHead ?: return
        val tail = fitTail ?: return
        val before = FitUndo(img, img.x, img.y, img.rotation, img.scale)
        val err = fitImageToBone(img, bone, head, tail)
        if (err != null) {
            Toast.makeText(context, err, Toast.LENGTH_LONG).show()
        } else {
            fitUndo = before
            fitStep = 0
            fitHead = null
            fitTail = null
        }
    }

    Box(Modifier.fillMaxSize()) {
        Column(
            Modifier
                .fillMaxSize()
                .systemBarsPadding()
                .background(Color(0xFF3A3A44))
                .pointerInput(Unit) { detectTapGestures { } }, // กันการสัมผัสทะลุไปหน้าจัดกระดูกที่อยู่ด้านล่าง
        ) {
            Box(Modifier.weight(1f).fillMaxWidth()) {
                Canvas(
                    Modifier
                        .fillMaxSize()
                        .onSizeChanged { canvasSize = it }
                        .pointerInput(bone, tool, fitStep) {
                            if (fitStep == 3) {
                                // แตะครบ 2 จุดแล้ว: ลากจุดหัว/ท้ายไปวาง (ภาพยังไม่ขยับจนกว่าจะกด "ตกลง" จึงใช้เมทริกซ์เดิมแปลงตำแหน่งนิ้ว <-> พิกเซลของภาพได้ตลอด)
                                var grab = 0 // 0 = ไม่ได้จับจุดไหน, 1 = จับจุดหัว, 2 = จับจุดท้าย
                                var grabGap = Offset.Zero // ระยะจากนิ้วถึงจุด ตอนเริ่มลาก (กันจุดกระโดดมาอยู่ใต้นิ้ว)
                                detectDragGestures(
                                    onDragStart = { start ->
                                        grab = 0
                                        val img = bone.images.getOrNull(activeIdx)
                                        val h = fitHead
                                        val t = fitTail
                                        if (img != null && h != null && t != null) {
                                            val m = Matrix()
                                            val vs0 = viewScaleOf(canvasSize.width.toFloat(), bone.length)
                                            m.set(editorMatrix(img, max(bone.length, 1f), vs0, canvasSize.width / 2f, canvasSize.height / 2f))
                                            val pts = floatArrayOf(h.x, h.y, t.x, t.y)
                                            m.mapPoints(pts)
                                            val dh = hypot(pts[0] - start.x, pts[1] - start.y)
                                            val dt = hypot(pts[2] - start.x, pts[3] - start.y)
                                            if (min(dh, dt) <= FIT_GRAB_RADIUS) {
                                                if (dh <= dt) {
                                                    grab = 1
                                                    grabGap = Offset(pts[0] - start.x, pts[1] - start.y)
                                                } else {
                                                    grab = 2
                                                    grabGap = Offset(pts[2] - start.x, pts[3] - start.y)
                                                }
                                            }
                                        }
                                    },
                                    onDragEnd = { grab = 0 },
                                    onDragCancel = { grab = 0 },
                                ) { change, _ ->
                                    change.consume()
                                    val img = bone.images.getOrNull(activeIdx) ?: return@detectDragGestures
                                    if (grab == 0) return@detectDragGestures
                                    val vs0 = viewScaleOf(canvasSize.width.toFloat(), bone.length)
                                    val m = editorMatrix(img, max(bone.length, 1f), vs0, canvasSize.width / 2f, canvasSize.height / 2f)
                                    val inv = Matrix()
                                    if (!m.invert(inv)) return@detectDragGestures
                                    val pt = floatArrayOf(change.position.x + grabGap.x, change.position.y + grabGap.y)
                                    inv.mapPoints(pt)
                                    if (grab == 1) fitHead = Offset(pt[0], pt[1]) else fitTail = Offset(pt[0], pt[1])
                                }
                            } else if (fitStep != 0) {
                                detectTapGestures { pos -> onFitTap(pos) } // โหมดปรับพอดีกระดูก: แตะหัว แล้วแตะท้ายภาพ
                            } else if (tool == ImgTool.SCALE) {
                                // ขยาย: ใช้ 2 นิ้ว ถ่างออก = ใหญ่ขึ้น หุบเข้า = เล็กลง (นิ้วเดียวไม่ทำอะไรในโหมดนี้)
                                detectTransformGestures { _, _, zoom, _ ->
                                    val img = bone.images.getOrNull(activeIdx) ?: return@detectTransformGestures
                                    img.scale = (img.scale * zoom).coerceIn(0.05f, 20f)
                                }
                            } else detectDragGestures { change, drag ->
                                change.consume()
                                val img = bone.images.getOrNull(activeIdx) ?: return@detectDragGestures
                                val vs = viewScaleOf(canvasSize.width.toFloat(), bone.length)
                                val c = Offset(
                                    canvasSize.width / 2f + (img.x - bone.length / 2f) * vs,
                                    canvasSize.height / 2f + img.y * vs,
                                ) // ตำแหน่งกึ่งกลางภาพบนจอ
                                val pos = change.position
                                val prev = pos - drag
                                when (tool) {
                                    ImgTool.MOVE -> {
                                        img.x += drag.x / vs
                                        img.y += drag.y / vs
                                    }
                                    ImgTool.SCALE -> Unit // ใช้ท่า 2 นิ้วด้านบนแทน
                                    ImgTool.ROTATE -> {
                                        val a1 = atan2(pos.y - c.y, pos.x - c.x)
                                        val a0 = atan2(prev.y - c.y, prev.x - c.x)
                                        val d = Math.toDegrees((a1 - a0).toDouble()).toFloat()
                                        img.rotation = normalizeAngle(img.rotation + normalizeAngle(d))
                                    }
                                }
                            }
                        },
                ) {
                    val l = max(bone.length, 1f)
                    val vs = viewScaleOf(this.size.width, bone.length)
                    val cx = this.size.width / 2f
                    val cy = this.size.height / 2f
                    // กระดูกเส้นอื่น (จาง): แปลงพิกัดโลก -> หน้านี้ โดยให้โคนกระดูกที่แก้อยู่ไปที่ซ้ายกลางจอ และหมุนให้กระดูกที่แก้อยู่ชี้ไปทางขวา
                    val editBase = skeleton.baseOf(bone)
                    val editAngle = skeleton.worldAngle(bone)
                    fun worldToEditor(m: Matrix) {
                        m.postTranslate(-editBase.x, -editBase.y)
                        m.postRotate(editAngle)
                        m.postScale(vs, vs)
                        m.postTranslate(cx - l * vs / 2f, cy)
                    }
                    drawIntoCanvas { c ->
                        for (ob in skeleton.bones) {
                            if (ob.id == bone.id) continue
                            val ob0 = skeleton.baseOf(ob)
                            val oAng = skeleton.worldAngle(ob)
                            for (img in ob.images) {
                                val m = boneImageMatrix(img, ob0, oAng)
                                worldToEditor(m)
                                c.nativeCanvas.drawBitmap(img.bitmap, m, ghostPaint)
                            }
                        }
                    }
                    for (ob in skeleton.bones) {
                        if (ob.id == bone.id) continue
                        val p0 = skeleton.baseOf(ob)
                        val p1 = skeleton.tipOf(ob)
                        val pts = floatArrayOf(p0.x, p0.y, p1.x, p1.y)
                        val m = Matrix()
                        worldToEditor(m)
                        m.mapPoints(pts)
                        val ga = Offset(pts[0], pts[1])
                        val gb = Offset(pts[2], pts[3])
                        drawLine(Color(0x4D29B6F6), ga, gb, strokeWidth = 4f)
                        drawCircle(Color(0x4D29B6F6), radius = 7f, center = gb)
                    }
                    drawIntoCanvas { c ->
                        for (img in bone.images) c.nativeCanvas.drawBitmap(img.bitmap, editorMatrix(img, l, vs, cx, cy), paint)
                    }
                    val fh = fitHead
                    val fimg = bone.images.getOrNull(activeIdx)
                    val ft = fitTail
                    if (fitStep >= 2 && fh != null && fimg != null) { // จุดหัวที่แตะไว้ (เขียว)
                        val hp = floatArrayOf(fh.x, fh.y)
                        val em = editorMatrix(fimg, l, vs, cx, cy)
                        em.mapPoints(hp)
                        if (fitStep == 3 && ft != null) { // ลากจุดได้: เส้นเชื่อมหัว-ท้าย + จุดท้าย (ส้ม) + จุดใหญ่ขึ้นให้จับง่าย
                            val tp = floatArrayOf(ft.x, ft.y)
                            em.mapPoints(tp)
                            drawLine(Color(0x99FFFFFF), Offset(hp[0], hp[1]), Offset(tp[0], tp[1]), strokeWidth = 2f)
                            // จุดเล็กเรียบๆ: วงรัศมีจางๆ + ขอบขาวบาง + แกนสี (เขียว = หัว, แดง = ท้าย) พื้นที่แตะจับยังกว้างเท่าเดิม (มองไม่เห็น)
                            drawCircle(Color(0x4400E676), radius = 15f, center = Offset(hp[0], hp[1]))
                            drawCircle(Color.White, radius = 8f, center = Offset(hp[0], hp[1]))
                            drawCircle(Color(0xFF00E676), radius = 6f, center = Offset(hp[0], hp[1]))
                            drawCircle(Color(0x44FF5252), radius = 15f, center = Offset(tp[0], tp[1]))
                            drawCircle(Color.White, radius = 8f, center = Offset(tp[0], tp[1]))
                            drawCircle(Color(0xFFFF5252), radius = 6f, center = Offset(tp[0], tp[1]))
                        } else {
                            drawCircle(Color.White, radius = 14f, center = Offset(hp[0], hp[1]))
                            drawCircle(Color(0xFF00E676), radius = 10f, center = Offset(hp[0], hp[1]))
                        }
                    }
                    val a = Offset(cx - l * vs / 2f, cy)
                    val b = Offset(cx + l * vs / 2f, cy)
                    drawLine(Color.White, a, b, strokeWidth = 4f)
                    drawCircle(Color.White, radius = 9f, center = a)
                    drawCircle(Color.White, radius = 9f, center = b)
                }

                val hint = if (fitStep == 1) {
                    "ปรับพอดีกระดูก: แตะที่ \"หัว\" ของภาพ (ปลายที่จะไปอยู่ตรงโคนกระดูก)"
                } else if (fitStep == 2) {
                    "แตะที่ \"ท้าย\" ของภาพ (ปลายที่จะไปอยู่ตรงปลายกระดูก)"
                } else if (fitStep == 3) {
                    "ลากจุดเขียว (หัว) และจุดแดง (ท้าย) ไปวางให้ตรง แล้วกด \"ตกลง\""
                } else if (bone.images.isEmpty()) {
                    "กด \"เพิ่มภาพ\" เพื่อใส่ภาพให้กระดูกเส้นนี้"
                } else {
                    when (tool) {
                        ImgTool.MOVE -> "ย้าย: ลากนิ้วเพื่อเลื่อนภาพ"
                        ImgTool.SCALE -> "ขยาย: ใช้ 2 นิ้ว ถ่างออก = ใหญ่ หุบเข้า = เล็ก"
                        ImgTool.ROTATE -> "หมุน: ลากวนรอบกลางภาพ"
                    }
                }
                Box(
                    Modifier
                        .align(Alignment.TopCenter)
                        .padding(8.dp)
                        .clip(RoundedCornerShape(12.dp))
                        .background(Color(0xFFFFD600))
                        .padding(horizontal = 12.dp, vertical = 6.dp),
                ) { Text(hint, color = Color.Black, fontSize = 13.sp) }
                if (fitStep == 3) { // ปุ่มตกลงวางบนพื้นที่ภาพ (แถบปุ่มด้านล่างเลื่อนได้ ปุ่มอาจอยู่นอกจอ)
                    Button(
                        onClick = { onFitConfirm() },
                        modifier = Modifier.align(Alignment.BottomCenter).padding(10.dp).heightIn(min = 36.dp),
                        shape = RoundedCornerShape(18.dp),
                        contentPadding = PaddingValues(horizontal = 22.dp, vertical = 4.dp),
                    ) { Text("ตกลง ✓", fontSize = 14.sp) }
                }
            }

            // รูปย่อของภาพในกระดูกเส้นนี้ (แตะเพื่อเลือกภาพที่จะปรับ)
            Row(
                Modifier.fillMaxWidth().background(Palette.Panel).horizontalScroll(rememberScrollState()).padding(horizontal = 8.dp, vertical = 6.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                bone.images.forEachIndexed { i, img ->
                    val on = i == activeIdx
                    Image(
                        bitmap = img.bitmap.asImageBitmap(),
                        contentDescription = null,
                        modifier = Modifier
                            .size(56.dp)
                            .clip(RoundedCornerShape(10.dp))
                            .border(if (on) 3.dp else 1.dp, if (on) Color(0xFF00E676) else Color.Gray, RoundedCornerShape(10.dp))
                            .clickable { activeIdx = i; fitStep = 0; fitHead = null; fitTail = null } // เปลี่ยนภาพ = ยกเลิกการปรับที่ค้างอยู่ (จุดที่แตะเป็นของภาพเดิม)
                            .padding(2.dp),
                    )
                }
            }

            // ปุ่มควบคุม
            Row(
                Modifier.fillMaxWidth().background(Palette.Panel).horizontalScroll(rememberScrollState()).padding(horizontal = 8.dp, vertical = 6.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                OutlinedButton(
                    onClick = { picker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)) },
                    modifier = Modifier.heightIn(min = 48.dp),
                ) { Text("เพิ่มภาพ") }
                FilterChip(
                    selected = tool == ImgTool.MOVE,
                    onClick = { tool = ImgTool.MOVE },
                    label = { Text("ย้าย") },
                    modifier = Modifier.heightIn(min = 48.dp),
                )
                FilterChip(
                    selected = tool == ImgTool.SCALE,
                    onClick = { tool = ImgTool.SCALE },
                    label = { Text("ขยาย") },
                    modifier = Modifier.heightIn(min = 48.dp),
                )
                FilterChip(
                    selected = tool == ImgTool.ROTATE,
                    onClick = { tool = ImgTool.ROTATE },
                    label = { Text("หมุน") },
                    modifier = Modifier.heightIn(min = 48.dp),
                )
                if (fitStep == 0) {
                    OutlinedButton(
                        onClick = { fitStep = 1; fitHead = null; fitTail = null },
                        enabled = bone.images.isNotEmpty(),
                        modifier = Modifier.heightIn(min = 48.dp),
                    ) { Text("ปรับพอดีกระดูก") }
                } else {
                    OutlinedButton(
                        onClick = { fitStep = 0; fitHead = null; fitTail = null },
                        modifier = Modifier.heightIn(min = 48.dp),
                    ) { Text("ยกเลิกการปรับ") }
                }
                val undo = fitUndo
                if (undo != null && fitStep == 0 && undo.img in bone.images) {
                    OutlinedButton(
                        onClick = {
                            undo.img.x = undo.x
                            undo.img.y = undo.y
                            undo.img.rotation = undo.rotation
                            undo.img.scale = undo.scale
                            fitUndo = null
                        },
                        modifier = Modifier.heightIn(min = 48.dp),
                    ) { Text("เลิกปรับ") }
                }
                OutlinedButton(
                    onClick = { bone.images.getOrNull(activeIdx)?.let { flipImage(it, horizontal = true) } },
                    enabled = bone.images.isNotEmpty(),
                    modifier = Modifier.heightIn(min = 48.dp),
                ) { Text("พลิกแนวนอน") }
                OutlinedButton(
                    onClick = { bone.images.getOrNull(activeIdx)?.let { flipImage(it, horizontal = false) } },
                    enabled = bone.images.isNotEmpty(),
                    modifier = Modifier.heightIn(min = 48.dp),
                ) { Text("พลิกแนวตั้ง") }
                OutlinedButton(
                    onClick = {
                        if (activeIdx in bone.images.indices) {
                            bone.images.removeAt(activeIdx)
                            activeIdx = max(activeIdx - 1, 0)
                        }
                    },
                    enabled = bone.images.isNotEmpty(),
                    modifier = Modifier.heightIn(min = 48.dp),
                ) { Text("ลบภาพ") }
                Button(onClick = onDone, modifier = Modifier.heightIn(min = 48.dp)) { Text("เสร็จ ✓") }
            }
        }

        val cropSrc = pendingBitmap
        if (cropSrc != null) {
            ImageCropScreen(
                bitmap = cropSrc,
                onConfirm = { cropped ->
                    pendingBitmap = null
                    scope.launch {
                        // ตัดขอบโปร่งใสอีกรอบ (ผลตัดบ่วงยังมีขอบว่าง) แล้วย่อถ้าใหญ่เกิน ก่อนนำเข้า
                        val r = runCatching { withContext(Dispatchers.Default) { ImageImport.prepare(cropped) } }
                        addImage(r.getOrDefault(cropped))
                    }
                },
                onCancel = { pendingBitmap = null },
            )
        }
    }
}
