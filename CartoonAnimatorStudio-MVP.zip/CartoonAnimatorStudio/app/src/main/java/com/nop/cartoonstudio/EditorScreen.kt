package com.nop.cartoonstudio

import android.graphics.Bitmap
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.gestures.calculateCentroid
import androidx.compose.foundation.gestures.calculatePan
import androidx.compose.foundation.gestures.calculateZoom
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.runtime.withFrameNanos
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.drawIntoCanvas
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

private val FPS_STEPS = listOf(6, 8, 10, 12, 15, 24)

@Composable
fun EditorScreen(vm: EditorViewModel) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var showExport by remember { mutableStateOf(false) }
    var showClear by remember { mutableStateOf(false) }
    var updating by remember { mutableStateOf(false) }
    val paint = remember {
        android.graphics.Paint(android.graphics.Paint.FILTER_BITMAP_FLAG or android.graphics.Paint.ANTI_ALIAS_FLAG)
    }

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.PickMultipleVisualMedia(20)) { uris ->
        if (uris.isNotEmpty()) {
            scope.launch {
                for (uri in uris) {
                    val result = runCatching { withContext(Dispatchers.IO) { ImageImport.decode(context, uri) } }
                    result.onSuccess { bmp ->
                        vm.addImported("ชิ้นส่วน ${vm.project.parts.size + 1}", bmp)
                        if (!bmp.hasAlpha()) vm.message = "ภาพนี้ไม่มีความโปร่งใส (ไม่ใช่ PNG โปร่งใส)"
                    }.onFailure {
                        vm.message = "นำเข้าไม่สำเร็จ: ${it.message ?: it.javaClass.simpleName}"
                    }
                }
            }
        }
    }

    LaunchedEffect(vm.message) {
        val m = vm.message
        if (m != null) {
            Toast.makeText(context, m, Toast.LENGTH_LONG).show()
            vm.message = null
        }
    }

    LaunchedEffect(vm.playing) {
        if (vm.playing) {
            var last = withFrameNanos { it }
            while (vm.playing) {
                val now = withFrameNanos { it }
                vm.tick((now - last) / 1_000_000_000f)
                last = now
            }
        }
    }

    Column(Modifier.fillMaxSize().systemBarsPadding()) {
        // แถบบน
        Row(
            Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 4.dp),
            verticalAlignment = androidx.compose.ui.Alignment.CenterVertically,
        ) {
            Text("Cartoon Animator Studio", Modifier.weight(1f), style = MaterialTheme.typography.titleMedium)
            OutlinedButton(
                onClick = { vm.boneEditorOpen = true },
                modifier = Modifier.padding(end = 8.dp).heightIn(min = 48.dp),
            ) { Text("กระดูก") }
            OutlinedButton(
                enabled = !updating,
                onClick = {
                    scope.launch {
                        updating = true
                        val r = runCatching { withContext(Dispatchers.IO) { AppUpdater.download(context) } }
                        updating = false
                        r.onSuccess { f ->
                            if (!AppUpdater.install(context, f)) {
                                vm.message = "อนุญาตให้แอปนี้ติดตั้งแอป แล้วกด \"อัปเดตแอป\" อีกครั้ง"
                            }
                        }.onFailure { vm.message = "อัปเดตไม่สำเร็จ: ${it.message ?: it.javaClass.simpleName}" }
                    }
                },
                modifier = Modifier.padding(end = 8.dp).heightIn(min = 48.dp),
            ) { Text(if (updating) "กำลังโหลด..." else "อัปเดตแอป") }
            Button(onClick = { showExport = true }, modifier = Modifier.heightIn(min = 48.dp)) { Text("ส่งออก") }
        }

        // โหมด
        Row(Modifier.padding(horizontal = 8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            // เอาแท็บ "โครง/ข้อต่อ (Rig)" ออกแล้ว (จะใช้ระบบกระดูกแทน); กด "แอนิเมต" ซ้ำเพื่อกลับสู่โหมดเดิมที่ใช้นำเข้า/จัดภาพ
            Chip("แอนิเมต (Animate)", vm.mode == Mode.ANIMATE) {
                vm.setMode(if (vm.mode == Mode.ANIMATE) Mode.RIG else Mode.ANIMATE)
            }
        }

        // ผืนผ้าใบ
        Box(Modifier.weight(1f).fillMaxWidth()) {
            Canvas(
                Modifier
                    .fillMaxSize()
                    .onSizeChanged { vm.onCanvasSize(it) }
                    .pointerInput(Unit) {
                        awaitEachGesture {
                            val down = awaitFirstDown(requireUnconsumed = false)
                            vm.onDown(down.position)
                            var multi = false
                            do {
                                val event = awaitPointerEvent()
                                val pressed = event.changes.filter { it.pressed }
                                if (pressed.size >= 2) {
                                    multi = true
                                    vm.onTransform(event.calculateCentroid(), event.calculatePan(), event.calculateZoom())
                                    event.changes.forEach { it.consume() }
                                } else if (pressed.size == 1 && !multi) {
                                    val c = pressed[0]
                                    val d = c.position - c.previousPosition
                                    if (d != Offset.Zero) vm.onDrag(c.position, d)
                                    c.consume()
                                }
                            } while (event.changes.any { it.pressed })
                        }
                    },
            ) {
                drawRect(Color(0xFF1B1D22))
                drawGuides(vm)
                drawIntoCanvas { canvas ->
                    val nc = canvas.nativeCanvas
                    nc.save()
                    nc.translate(vm.canvasSize.width / 2f + vm.pan.x, vm.canvasSize.height / 2f + vm.pan.y)
                    nc.scale(vm.zoom, vm.zoom)
                    drawScene(nc, vm.project.parts, vm.poseOf(), paint)
                    nc.restore()
                }
                drawOverlay(vm)
            }
        }

        // แผงล่าง
        Column(
            Modifier.fillMaxWidth().heightIn(max = 260.dp).verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.spacedBy(6.dp),
        ) {
            Row(
                Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()).padding(horizontal = 8.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                Chip("ย้าย", vm.tool == Tool.MOVE) { vm.tool = Tool.MOVE }
                if (vm.mode == Mode.RIG) {
                    Chip("ตั้งข้อต่อ", vm.tool == Tool.JOINT) { vm.tool = Tool.JOINT }
                } else {
                    Chip("หมุน", vm.tool == Tool.ROTATE) { vm.tool = Tool.ROTATE }
                }
                Button(
                    onClick = {
                        picker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
                    },
                    modifier = Modifier.heightIn(min = 48.dp),
                ) { Text("นำเข้า PNG") }
                OutlinedButton(onClick = { vm.addDemo() }, modifier = Modifier.heightIn(min = 48.dp)) { Text("ตัวละครทดสอบ") }
                OutlinedButton(onClick = { showClear = true }, modifier = Modifier.heightIn(min = 48.dp)) { Text("ล้างทั้งหมด") }
            }

            // เลเยอร์
            LazyRow(
                Modifier.fillMaxWidth().padding(horizontal = 8.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                items(vm.project.parts, key = { it.id }) { part ->
                    Chip(part.name, part.id == vm.selectedId) { vm.selectedId = part.id }
                }
            }

            PartControls(vm)
            Timeline(vm)
        }
    }

    if (showClear) {
        AlertDialog(
            onDismissRequest = { showClear = false },
            title = { Text("ล้างโปรเจกต์?") },
            text = { Text("ชิ้นส่วนและท่าทั้งหมดจะถูกลบ (ยังไม่มีระบบบันทึกในเวอร์ชันนี้)") },
            confirmButton = { TextButton(onClick = { vm.clearProject(); showClear = false }) { Text("ล้าง") } },
            dismissButton = { TextButton(onClick = { showClear = false }) { Text("ยกเลิก") } },
        )
    }
    if (showExport) ExportDialog(vm) { showExport = false }
}

@Composable
private fun Chip(label: String, selected: Boolean, enabled: Boolean = true, onClick: () -> Unit) {
    FilterChip(
        selected = selected,
        onClick = onClick,
        enabled = enabled,
        label = { Text(label) },
        modifier = Modifier.heightIn(min = 48.dp),
    )
}

@Composable
private fun PartControls(vm: EditorViewModel) {
    var menu by remember { mutableStateOf(false) }
    val sel = vm.selected
    if (sel == null) {
        Text(
            "แตะชิ้นส่วนบนผืนผ้าใบ หรือเลือกจากรายการเลเยอร์",
            Modifier.padding(horizontal = 12.dp),
            style = MaterialTheme.typography.bodySmall,
        )
        return
    }
    val rig = vm.mode == Mode.RIG
    val parentName = vm.project.part(sel.parentId)?.name ?: "ไม่มี (ราก)"
    Row(
        Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()).padding(horizontal = 8.dp),
        horizontalArrangement = Arrangement.spacedBy(8.dp),
        verticalAlignment = androidx.compose.ui.Alignment.CenterVertically,
    ) {
        Box {
            OutlinedButton(onClick = { menu = true }, enabled = rig, modifier = Modifier.heightIn(min = 48.dp)) {
                Text("ชิ้นแม่ (parent): $parentName")
            }
            DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
                DropdownMenuItem(text = { Text("ไม่มี (ราก)") }, onClick = { vm.setParent(sel, null); menu = false })
                val blocked = vm.project.descendants(sel.id)
                for (p in vm.project.parts) {
                    if (p.id != sel.id && p.id !in blocked) {
                        DropdownMenuItem(text = { Text(p.name) }, onClick = { vm.setParent(sel, p.id); menu = false })
                    }
                }
            }
        }
        OutlinedButton(
            onClick = { if (sel.hasTip) vm.removeTip(sel) else vm.addTip(sel) },
            enabled = rig,
            modifier = Modifier.heightIn(min = 48.dp),
        ) { Text(if (sel.hasTip) "ลบจุดต่อ" else "เพิ่มจุดต่อ") }
        OutlinedButton(
            onClick = { sel.scale = (sel.scale * 0.9f).coerceIn(0.05f, 20f) },
            enabled = rig,
            modifier = Modifier.heightIn(min = 48.dp),
        ) { Text("ย่อ −") }
        OutlinedButton(
            onClick = { sel.scale = (sel.scale * 1.1f).coerceIn(0.05f, 20f) },
            enabled = rig,
            modifier = Modifier.heightIn(min = 48.dp),
        ) { Text("ขยาย +") }
        Chip("พลิกซ้าย-ขวา", sel.flipX, enabled = rig) { sel.flipX = !sel.flipX }
        OutlinedButton(onClick = { vm.deleteSelected() }, enabled = rig, modifier = Modifier.heightIn(min = 48.dp)) {
            Text("ลบ")
        }
    }
}

@Composable
private fun Timeline(vm: EditorViewModel) {
    if (vm.mode != Mode.ANIMATE) {
        Text(
            "สลับไปโหมดแอนิเมตเพื่อใช้ไทม์ไลน์",
            Modifier.padding(horizontal = 12.dp, vertical = 4.dp),
            style = MaterialTheme.typography.bodySmall,
        )
        return
    }
    LazyRow(
        Modifier.fillMaxWidth().padding(horizontal = 8.dp),
        horizontalArrangement = Arrangement.spacedBy(8.dp),
    ) {
        items(vm.project.frameCount) { i ->
            Chip("${i + 1}", vm.currentFrame == i) {
                if (!vm.playing) {
                    vm.currentFrame = i
                    vm.playhead = i.toFloat()
                }
            }
        }
    }
    Row(
        Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()).padding(horizontal = 8.dp),
        horizontalArrangement = Arrangement.spacedBy(8.dp),
    ) {
        Button(onClick = { vm.togglePlay() }, modifier = Modifier.heightIn(min = 48.dp)) {
            Text(if (vm.playing) "⏸ พัก" else "▶ เล่น")
        }
        OutlinedButton(onClick = { vm.stop() }, modifier = Modifier.heightIn(min = 48.dp)) { Text("⏹ หยุด") }
        Chip("วนซ้ำ", vm.loop) { vm.loop = !vm.loop }
        OutlinedButton(
            onClick = { vm.fps = FPS_STEPS[(FPS_STEPS.indexOf(vm.fps) + 1) % FPS_STEPS.size] },
            modifier = Modifier.heightIn(min = 48.dp),
        ) { Text("${vm.fps} fps") }
    }
    Row(
        Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()).padding(horizontal = 8.dp),
        horizontalArrangement = Arrangement.spacedBy(8.dp),
    ) {
        OutlinedButton(onClick = { vm.copyFromPreviousFrame() }, enabled = !vm.playing, modifier = Modifier.heightIn(min = 48.dp)) {
            Text("คัดลอกจากเฟรมก่อน")
        }
        OutlinedButton(onClick = { vm.resetSelectedPose() }, enabled = !vm.playing, modifier = Modifier.heightIn(min = 48.dp)) {
            Text("รีเซ็ตท่าชิ้นนี้")
        }
        OutlinedButton(onClick = { vm.clearFrame() }, enabled = !vm.playing, modifier = Modifier.heightIn(min = 48.dp)) {
            Text("ล้างเฟรมนี้")
        }
    }
}

@Composable
private fun ExportDialog(vm: EditorViewModel, onDismiss: () -> Unit) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var w by remember { mutableStateOf("256") }
    var h by remember { mutableStateOf("256") }
    var cols by remember { mutableStateOf("5") }
    var preview by remember { mutableStateOf<Bitmap?>(null) }
    var error by remember { mutableStateOf<String?>(null) }
    var busy by remember { mutableStateOf(false) }

    fun generate(onDone: (Bitmap) -> Unit) {
        val fw = w.toIntOrNull()
        val fh = h.toIntOrNull()
        val c = cols.toIntOrNull()
        val err = Exporter.validate(fw, fh, c, vm.project.frameCount)
        if (err != null) {
            error = err
            return
        }
        if (vm.project.parts.isEmpty()) {
            error = "ยังไม่มีชิ้นส่วนให้ส่งออก"
            return
        }
        error = null
        busy = true
        val parts = vm.project.parts.toList()
        val frames = vm.project.snapshotFrames()
        scope.launch {
            val result = runCatching {
                withContext(Dispatchers.Default) { Exporter.buildSheet(parts, frames, fw!!, fh!!, c!!) }
            }
            busy = false
            result.onSuccess {
                preview = it
                onDone(it)
            }.onFailure {
                error = "สร้างสไปรต์ชีตไม่สำเร็จ: ${it.message ?: it.javaClass.simpleName}"
            }
        }
    }

    AlertDialog(
        onDismissRequest = { if (!busy) onDismiss() },
        title = { Text("ส่งออก Sprite Sheet (PNG โปร่งใส)") },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(w, { w = it; preview = null }, label = { Text("กว้างต่อเฟรม (px)") }, singleLine = true)
                OutlinedTextField(h, { h = it; preview = null }, label = { Text("สูงต่อเฟรม (px)") }, singleLine = true)
                OutlinedTextField(cols, { cols = it; preview = null }, label = { Text("จำนวนคอลัมน์") }, singleLine = true)
                Text(
                    "จำนวนแถวคำนวณอัตโนมัติจาก 10 เฟรม ÷ คอลัมน์",
                    style = MaterialTheme.typography.bodySmall,
                )
                error?.let { Text(it, color = MaterialTheme.colorScheme.error) }
                preview?.let {
                    Image(
                        bitmap = it.asImageBitmap(),
                        contentDescription = "ตัวอย่างสไปรต์ชีต",
                        contentScale = ContentScale.Fit,
                        modifier = Modifier.fillMaxWidth().heightIn(max = 200.dp).background(Color(0xFF555555)),
                    )
                }
                if (busy) Text("กำลังประมวลผล...")
            }
        },
        confirmButton = {
            Row {
                TextButton(enabled = !busy, onClick = { generate { } }) { Text("ดูตัวอย่าง") }
                TextButton(enabled = !busy, onClick = {
                    generate { bmp ->
                        scope.launch {
                            busy = true
                            val saved = runCatching {
                                withContext(Dispatchers.IO) {
                                    Exporter.savePng(context, bmp, "spritesheet_${System.currentTimeMillis()}")
                                }
                            }
                            busy = false
                            saved.onSuccess {
                                vm.message = "บันทึกแล้ว: $it"
                                onDismiss()
                            }.onFailure {
                                error = "บันทึกไม่สำเร็จ: ${it.message ?: it.javaClass.simpleName}"
                            }
                        }
                    }
                }) { Text("บันทึก") }
            }
        },
        dismissButton = { TextButton(enabled = !busy, onClick = onDismiss) { Text("ปิด") } },
    )
}

private fun DrawScope.drawGuides(vm: EditorViewModel) {
    val grid = Color(0xFF2A2D34)
    val axis = Color(0xFF3B404A)
    for (k in -10..10) {
        val c = if (k == 0) axis else grid
        drawLine(c, vm.toScreen(Offset(k * 100f, -1000f)), vm.toScreen(Offset(k * 100f, 1000f)), 1.5f)
        drawLine(c, vm.toScreen(Offset(-1000f, k * 100f)), vm.toScreen(Offset(1000f, k * 100f)), 1.5f)
    }
    // กรอบส่งออก: สิ่งที่อยู่ในกรอบนี้คือสิ่งที่จะอยู่ในแต่ละเฟรมของสไปรต์ชีต
    val half = Exporter.WORLD_WINDOW / 2f
    drawRect(
        Color(0xFF4FC3F7),
        topLeft = vm.toScreen(Offset(-half, -half)),
        size = Size(Exporter.WORLD_WINDOW * vm.zoom, Exporter.WORLD_WINDOW * vm.zoom),
        style = Stroke(width = 2f, pathEffect = PathEffect.dashPathEffect(floatArrayOf(14f, 10f))),
    )
}

private fun DrawScope.drawOverlay(vm: EditorViewModel) {
    val parts = vm.project.parts
    val poseFn = vm.poseOf()
    val joints = computeJointMatrices(parts, poseFn)
    val sel = vm.selected
    val screenPos = HashMap<Int, Offset>()
    for (p in parts) {
        val j = joints[p.id] ?: continue
        val pt = floatArrayOf(0f, 0f)
        j.mapPoints(pt)
        screenPos[p.id] = vm.toScreen(Offset(pt[0], pt[1]))
    }
    for (p in parts) { // กระดูก = เส้นเชื่อมข้อต่อ parent -> ข้อต่อลูก
        val pid = p.parentId ?: continue
        val a = screenPos[pid] ?: continue
        val b = screenPos[p.id] ?: continue
        drawLine(Color(0x88FFFFFF), a, b, 3f)
    }
    for (p in parts) { // จุดต่อ (ปลายกระดูก): เส้นจากข้อต่อไปยังจุดปลาย แล้วจุดเขียวให้จับลาก
        if (!p.hasTip) continue
        val a = screenPos[p.id] ?: continue
        val b = Offset(a.x, a.y + tipLength(p) * vm.zoom) // ปุ่มเขียวอยู่ใต้ปุ่มแดงในแนวตั้งเสมอ
        drawLine(Color(0xFF4FC3F7), a, b, 4f)
        drawCircle(Color(0xFF69F0AE), if (p.id == sel?.id) 16f else 10f, b)
    }
    for (p in parts) {
        val s = screenPos[p.id] ?: continue
        val isSel = p.id == sel?.id
        drawCircle(if (isSel) Color(0xFFFF5252) else Color(0xFFFFD54F), if (isSel) 10f else 6f, s)
    }
    if (sel != null) {
        val j = joints[sel.id] ?: return
        val m = drawMatrix(sel, j)
        val bw = sel.bitmap.width.toFloat()
        val bh = sel.bitmap.height.toFloat()
        val pts = floatArrayOf(0f, 0f, bw, 0f, bw, bh, 0f, bh)
        m.mapPoints(pts)
        for (i in 0 until 4) {
            val n = (i + 1) % 4
            drawLine(
                Color(0xFF4FC3F7),
                vm.toScreen(Offset(pts[i * 2], pts[i * 2 + 1])),
                vm.toScreen(Offset(pts[n * 2], pts[n * 2 + 1])),
                2f,
            )
        }
    }
}
