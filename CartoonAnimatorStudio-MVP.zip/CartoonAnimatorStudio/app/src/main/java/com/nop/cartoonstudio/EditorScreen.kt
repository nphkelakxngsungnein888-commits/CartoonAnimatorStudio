package com.nop.cartoonstudio

import android.graphics.Bitmap
import android.widget.Toast
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.gestures.calculateCentroid
import androidx.compose.foundation.gestures.calculatePan
import androidx.compose.foundation.gestures.calculateZoom
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Slider
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.runtime.withFrameNanos
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.drawIntoCanvas
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlin.math.roundToInt

private val FPS_STEPS = listOf(6, 8, 10, 12, 15, 24)

@Composable
fun EditorScreen(vm: EditorViewModel) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var showExport by remember { mutableStateOf(false) }
    var showLoad by remember { mutableStateOf(false) }
    var updating by remember { mutableStateOf(false) }
    var showSettings by remember { mutableStateOf(false) }
    val paint = remember {
        android.graphics.Paint(android.graphics.Paint.FILTER_BITMAP_FLAG or android.graphics.Paint.ANTI_ALIAS_FLAG)
    }

    LaunchedEffect(vm.message) {
        val m = vm.message
        if (m != null) {
            Toast.makeText(context, m, Toast.LENGTH_LONG).show()
            vm.message = null
        }
    }

    LaunchedEffect(vm.playing) {
        if (vm.playing) {
            var last = withFrameNanos { it }
            while (vm.playing) {
                val now = withFrameNanos { it }
                vm.tick((now - last) / 1_000_000_000f)
                last = now
            }
        }
    }

    fun startUpdate() {
        scope.launch {
            updating = true
            val r = runCatching { withContext(Dispatchers.IO) { AppUpdater.download(context) } }
            updating = false
            r.onSuccess { f ->
                if (!AppUpdater.install(context, f)) {
                    vm.message = "อนุญาตให้แอปนี้ติดตั้งแอป แล้วกด \"อัปเดตแอป\" อีกครั้ง"
                }
            }.onFailure { vm.message = "อัปเดตไม่สำเร็จ: ${it.message ?: it.javaClass.simpleName}" }
        }
    }

    Column(Modifier.fillMaxSize().systemBarsPadding().background(Palette.Bg)) {
        // แถบบน: ชื่อแอป + ตั้งค่า + ส่งออก
        Row(
            Modifier.fillMaxWidth().background(Palette.Panel).padding(horizontal = 14.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            Text(
                "Cartoon Animator Studio",
                Modifier.weight(1f),
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.primary,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
            )
            Box(
                Modifier
                    .size(44.dp)
                    .clip(CircleShape)
                    .background(Palette.PanelHigh)
                    .border(1.dp, Palette.Stroke, CircleShape)
                    .clickable { showSettings = true },
                contentAlignment = Alignment.Center,
            ) { Text("⚙", fontSize = 22.sp, color = Color(0xFFE7E3EE)) }
            PillButton("ส่งออก", onClick = { showExport = true }, style = PillStyle.PRIMARY)
        }

        // ผืนผ้าใบ
        Box(
            Modifier
                .weight(1f)
                .fillMaxWidth()
                .padding(horizontal = 10.dp, vertical = 8.dp)
                .clip(RoundedCornerShape(18.dp))
                .border(1.dp, Palette.Stroke, RoundedCornerShape(18.dp)),
        ) {
            Canvas(
                Modifier
                    .fillMaxSize()
                    .onSizeChanged { vm.onCanvasSize(it) }
                    .pointerInput(Unit) {
                        awaitEachGesture {
                            val down = awaitFirstDown(requireUnconsumed = false)
                            vm.onDown(down.position)
                            var multi = false
                            do {
                                val event = awaitPointerEvent()
                                val pressed = event.changes.filter { it.pressed }
                                if (pressed.size >= 2) {
                                    multi = true
                                    vm.onTransform(event.calculateCentroid(), event.calculatePan(), event.calculateZoom())
                                    event.changes.forEach { it.consume() }
                                } else if (pressed.size == 1 && !multi) {
                                    val c = pressed[0]
                                    val d = c.position - c.previousPosition
                                    if (d != Offset.Zero) vm.onDrag(c.position, d)
                                    c.consume()
                                }
                            } while (event.changes.any { it.pressed })
                            vm.onUp()
                        }
                    },
            ) {
                drawRect(Color(0xFF1B1D22))
                drawGuides(vm)
                drawIntoCanvas { canvas ->
                    val nc = canvas.nativeCanvas
                    nc.save()
                    nc.translate(vm.canvasSize.width / 2f + vm.pan.x, vm.canvasSize.height / 2f + vm.pan.y)
                    nc.scale(vm.zoom, vm.zoom)
                    val onion = vm.onionOpacity
                    if (!vm.playing && vm.currentFrame > 0 && onion > 0.01f) { // เงาลางๆ ของเฟรมก่อนหน้า
                        val prev = vm.currentFrame - 1
                        nc.saveLayerAlpha(null, (onion * 255f).roundToInt().coerceIn(0, 255))
                        drawScene(nc, vm.project.parts, { id -> vm.project.poseAt(prev, id) }, paint)
                        nc.restore()
                    }
                    drawScene(nc, vm.project.parts, vm.poseOf(), paint)
                    nc.restore()
                }
                drawOverlay(vm)
            }
            if (vm.project.parts.isNotEmpty() && (vm.tool == Tool.CHAR_SCALE || vm.tool == Tool.CHAR_ROTATE)) {
                Surface(
                    color = Color(0xCC000000),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.align(Alignment.TopStart).padding(10.dp),
                ) {
                    Text(
                        if (vm.tool == Tool.CHAR_SCALE) {
                            "ขนาด ${(vm.charScale * 100f).roundToInt()}%\nใช้ 2 นิ้วถ่างออก = ใหญ่ขึ้น หุบเข้า = เล็กลง"
                        } else {
                            "มุม ${vm.characterAngle().roundToInt()}°\nลากนิ้วรอบจุดหลัก = หมุนตัวละคร"
                        },
                        Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
                        color = Color.White,
                        style = MaterialTheme.typography.bodySmall,
                    )
                }
            }
            if (vm.project.parts.isEmpty()) {
                Text(
                    "ยังไม่มีตัวละคร\nกด \"โหลดตัวละคร\" ด้านล่างเพื่อเริ่ม",
                    Modifier.align(Alignment.Center).padding(24.dp),
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    textAlign = TextAlign.Center,
                )
            }
        }

        // แผงล่าง: เหลือแต่เครื่องมือแอนิเมต + โหลดตัวละคร
        Surface(
            color = Palette.Panel,
            shape = RoundedCornerShape(topStart = 22.dp, topEnd = 22.dp),
            modifier = Modifier.fillMaxWidth(),
        ) {
            Column(
                Modifier.heightIn(max = 290.dp).verticalScroll(rememberScrollState()).padding(top = 12.dp, bottom = 10.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                Row(
                    Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()).padding(horizontal = 12.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    PillButton("📂 โหลดตัวละคร", onClick = { showLoad = true }, style = PillStyle.TONAL)
                    // กดซ้ำ = กลับโหมดปกติ (เดิมกลับด้วยปุ่ม "ย้าย" ซึ่งเอาออกแล้ว)
                    Chip("หมุนตัวละคร", vm.tool == Tool.CHAR_ROTATE) {
                        vm.tool = if (vm.tool == Tool.CHAR_ROTATE) Tool.MOVE else Tool.CHAR_ROTATE
                    }
                    Chip("ขยายตัวละคร", vm.tool == Tool.CHAR_SCALE) {
                        vm.tool = if (vm.tool == Tool.CHAR_SCALE) Tool.MOVE else Tool.CHAR_SCALE
                    }
                }

                if (vm.project.parts.isNotEmpty()) {
                    // เลเยอร์ (ไว้เลือกชิ้นที่แตะยาก)
                    LazyRow(
                        Modifier.fillMaxWidth().padding(horizontal = 12.dp),
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                    ) {
                        items(vm.project.parts, key = { it.id }) { part ->
                            Chip(part.name, part.id == vm.selectedId) { vm.selectedId = part.id }
                        }
                    }
                    val sel = vm.selected
                    Text(
                        if (sel == null) "แตะชิ้นส่วนบนผืนผ้าใบ หรือเลือกจากรายการเลเยอร์" else "เลือกอยู่: ${sel.name}",
                        Modifier.padding(horizontal = 14.dp),
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
                Timeline(vm)
            }
        }
    }

    if (showSettings) {
        SettingsDialog(
            vm,
            updating = updating,
            onOpenBones = { showSettings = false; vm.boneEditorOpen = true },
            onUpdate = { startUpdate() },
        ) { showSettings = false }
    }
    if (showLoad) LoadCharacterDialog(vm) { showLoad = false }
    if (showExport) ExportDialog(vm) { showExport = false }
}

private enum class PillStyle { PRIMARY, TONAL, OUTLINE, DANGER }

private val TonalBg = Color(0xFF42338A)
private val TonalFg = Color(0xFFE9E0FF)
private val NormalFg = Color(0xFFE7E3EE)

/** ปุ่มทรงแคปซูลของแอป: PRIMARY = ม่วงทึบ, TONAL = ม่วงเข้ม, OUTLINE = พื้นเทาขอบบาง, DANGER = ตัวอักษรแดงอ่อน */
@Composable
private fun PillButton(
    label: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    enabled: Boolean = true,
    style: PillStyle = PillStyle.OUTLINE,
) {
    val shape = RoundedCornerShape(50)
    val bg = when (style) {
        PillStyle.PRIMARY -> Palette.Accent
        PillStyle.TONAL -> TonalBg
        else -> Palette.PanelHigh
    }
    val fg = when (style) {
        PillStyle.PRIMARY -> Color(0xFF2A1A66)
        PillStyle.TONAL -> TonalFg
        PillStyle.DANGER -> Color(0xFFFF8A80)
        PillStyle.OUTLINE -> NormalFg
    }
    val edge = when (style) {
        PillStyle.PRIMARY -> Palette.Accent
        PillStyle.TONAL -> Color(0xFF6B58C9)
        else -> Palette.Stroke
    }
    Box(
        modifier
            .heightIn(min = 44.dp)
            .alpha(if (enabled) 1f else 0.38f)
            .clip(shape)
            .background(bg)
            .border(1.dp, edge, shape)
            .clickable(enabled = enabled, onClick = onClick)
            .padding(horizontal = 18.dp, vertical = 8.dp),
        contentAlignment = Alignment.Center,
    ) { Text(label, color = fg, fontWeight = FontWeight.Medium, textAlign = TextAlign.Center) }
}

/** ชิปเลือก/สลับ (ใช้กับเครื่องมือ, วนซ้ำ, ชื่อชิ้นส่วน) */
@Composable
private fun Chip(label: String, selected: Boolean, enabled: Boolean = true, onClick: () -> Unit) {
    val shape = RoundedCornerShape(50)
    Box(
        Modifier
            .heightIn(min = 44.dp)
            .alpha(if (enabled) 1f else 0.38f)
            .clip(shape)
            .background(if (selected) TonalBg else Palette.PanelHigh)
            .border(1.dp, if (selected) Palette.Accent else Palette.Stroke, shape)
            .clickable(enabled = enabled, onClick = onClick)
            .padding(horizontal = 16.dp, vertical = 8.dp),
        contentAlignment = Alignment.Center,
    ) {
        Text(
            label,
            color = if (selected) TonalFg else Color(0xFFC9C4D4),
            fontWeight = if (selected) FontWeight.Bold else FontWeight.Normal,
        )
    }
}

/** ปุ่มเลขเฟรม (วงกลม) */
@Composable
private fun FrameChip(number: Int, selected: Boolean, onClick: () -> Unit) {
    Box(
        Modifier
            .size(44.dp)
            .clip(CircleShape)
            .background(if (selected) TonalBg else Palette.PanelHigh)
            .border(if (selected) 2.dp else 1.dp, if (selected) Palette.Accent else Palette.Stroke, CircleShape)
            .clickable(onClick = onClick),
        contentAlignment = Alignment.Center,
    ) {
        Text(
            "$number",
            color = if (selected) TonalFg else Color(0xFFC9C4D4),
            fontWeight = if (selected) FontWeight.Bold else FontWeight.Normal,
        )
    }
}

/** ปุ่ม + ท้ายแถวเฟรม: เพิ่มเฟรมใหม่ (คัดลอกท่าจากเฟรมท้ายสุด) */
@Composable
private fun AddFrameButton(enabled: Boolean, onClick: () -> Unit) {
    Box(
        Modifier
            .size(44.dp)
            .alpha(if (enabled) 1f else 0.38f)
            .clip(CircleShape)
            .background(Palette.Accent)
            .clickable(enabled = enabled, onClick = onClick),
        contentAlignment = Alignment.Center,
    ) { Text("+", color = Color(0xFF2A1A66), fontSize = 26.sp, fontWeight = FontWeight.Bold) }
}

/** เมนูตั้งค่า: กระดูก / อัปเดตแอป / ความจางของเงาเฟรมที่แล้ว */
@Composable
private fun SettingsDialog(
    vm: EditorViewModel,
    updating: Boolean,
    onOpenBones: () -> Unit,
    onUpdate: () -> Unit,
    onDismiss: () -> Unit,
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("ตั้งค่า") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                PillButton("กระดูก (สร้าง/แก้ไขตัวละคร)", onClick = onOpenBones, modifier = Modifier.fillMaxWidth(), style = PillStyle.TONAL)
                PillButton(
                    if (updating) "กำลังโหลด..." else "อัปเดตแอป",
                    onClick = onUpdate,
                    modifier = Modifier.fillMaxWidth(),
                    enabled = !updating,
                )
                Column {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("ความจางของเฟรมที่แล้ว", Modifier.weight(1f))
                        Text("${(vm.onionOpacity * 100f).roundToInt()}%", color = MaterialTheme.colorScheme.primary)
                    }
                    Slider(
                        value = vm.onionOpacity,
                        onValueChange = { vm.onionOpacity = it },
                        valueRange = 0f..1f,
                    )
                    Text(
                        "เงาลางๆ ของเฟรมก่อนหน้าบนผืนผ้าใบ (0% = ปิด)",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
            }
        },
        confirmButton = { TextButton(onClick = onDismiss) { Text("ปิด") } },
    )
}

/** รายการตัวละครที่เซฟไว้ในแอป (เซฟจากเมนูกระดูก) แตะเพื่อโหลดเข้าฉากแอนิเมต */
@Composable
private fun LoadCharacterDialog(vm: EditorViewModel, onDismiss: () -> Unit) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var saved by remember { mutableStateOf<List<SavedCharacter>?>(null) }
    var busy by remember { mutableStateOf(false) }
    var pending by remember { mutableStateOf<String?>(null) } // ชื่อที่รอยืนยันการแทนที่

    LaunchedEffect(Unit) {
        saved = runCatching { withContext(Dispatchers.IO) { CharacterStore.list(context) } }.getOrDefault(emptyList())
    }

    fun load(name: String) {
        busy = true
        scope.launch {
            val r = runCatching {
                withContext(Dispatchers.IO) { CharacterToParts.prepare(CharacterStore.load(context, name)) }
            }
            busy = false
            r.onSuccess { built ->
                vm.loadCharacter(built)
                vm.message = "โหลดตัวละคร \"$name\" แล้ว"
                onDismiss()
            }.onFailure {
                vm.message = "โหลดไม่สำเร็จ: ${it.message ?: it.javaClass.simpleName}"
            }
        }
    }

    AlertDialog(
        onDismissRequest = { if (!busy) onDismiss() },
        title = { Text("โหลดตัวละคร") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                val list = saved
                when {
                    list == null -> Text("กำลังอ่านรายการ...")
                    list.isEmpty() -> Text(
                        "ยังไม่มีตัวละครที่บันทึกไว้\nไปที่เมนู \"กระดูก\" สร้างตัวละคร แล้วกด \"เซฟตัวละคร\"",
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                    else -> LazyColumn(
                        Modifier.heightIn(max = 320.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp),
                    ) {
                        items(list, key = { it.name }) { c ->
                            CharacterRow(c, enabled = !busy) {
                                if (vm.project.parts.isEmpty()) load(c.name) else pending = c.name
                            }
                        }
                    }
                }
                if (busy) Text("กำลังโหลด...", color = MaterialTheme.colorScheme.primary)
            }
        },
        confirmButton = { TextButton(enabled = !busy, onClick = onDismiss) { Text("ปิด") } },
    )

    pending?.let { name ->
        AlertDialog(
            onDismissRequest = { pending = null },
            title = { Text("แทนที่ตัวละครปัจจุบัน?") },
            text = { Text("การโหลด \"$name\" จะแทนที่ตัวละครและท่าแอนิเมตทั้งหมดที่มีอยู่ตอนนี้") },
            confirmButton = { TextButton(onClick = { pending = null; load(name) }) { Text("โหลดเลย") } },
            dismissButton = { TextButton(onClick = { pending = null }) { Text("ยกเลิก") } },
        )
    }
}

@Composable
private fun CharacterRow(c: SavedCharacter, enabled: Boolean, onClick: () -> Unit) {
    val date = remember(c.savedAt) {
        java.text.DateFormat.getDateTimeInstance(java.text.DateFormat.MEDIUM, java.text.DateFormat.SHORT)
            .format(java.util.Date(c.savedAt))
    }
    Row(
        Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(14.dp))
            .background(Palette.PanelHigh)
            .clickable(enabled = enabled, onClick = onClick)
            .padding(horizontal = 14.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Column(Modifier.weight(1f)) {
            Text(c.name, maxLines = 1, overflow = TextOverflow.Ellipsis, fontWeight = FontWeight.Bold)
            Text(date, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        Text("โหลด", color = MaterialTheme.colorScheme.primary)
    }
}

@Composable
private fun Timeline(vm: EditorViewModel) {
    val listState = rememberLazyListState()
    LaunchedEffect(vm.project.frameCount) { listState.animateScrollToItem(vm.project.frameCount) } // เลื่อนไปที่ปุ่ม + เมื่อเพิ่มเฟรม
    if (vm.mode != Mode.ANIMATE) {
        Text(
            "สลับไปโหมดแอนิเมตเพื่อใช้ไทม์ไลน์",
            Modifier.padding(horizontal = 12.dp, vertical = 4.dp),
            style = MaterialTheme.typography.bodySmall,
        )
        return
    }
    LazyRow(
        Modifier.fillMaxWidth().padding(horizontal = 8.dp),
        state = listState,
        horizontalArrangement = Arrangement.spacedBy(8.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        items(vm.project.frameCount) { i ->
            FrameChip(i + 1, vm.currentFrame == i) {
                if (!vm.playing) {
                    vm.currentFrame = i
                    vm.playhead = i.toFloat()
                }
            }
        }
        item { AddFrameButton(enabled = !vm.playing) { vm.addFrame() } }
    }
    Row(
        Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()).padding(horizontal = 8.dp),
        horizontalArrangement = Arrangement.spacedBy(8.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        PillButton(if (vm.playing) "⏸ พัก" else "▶ เล่น", onClick = { vm.togglePlay() }, style = PillStyle.PRIMARY)
        PillButton("⏹ หยุด", onClick = { vm.stop() })
        Chip("วนซ้ำ", vm.loop) { vm.loop = !vm.loop }
        PillButton("${vm.fps} fps", onClick = { vm.fps = FPS_STEPS[(FPS_STEPS.indexOf(vm.fps) + 1) % FPS_STEPS.size] })
    }
    Row(
        Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()).padding(horizontal = 8.dp),
        horizontalArrangement = Arrangement.spacedBy(8.dp),
    ) {
        PillButton("คัดลอกจากเฟรมก่อน", onClick = { vm.copyFromPreviousFrame() }, enabled = !vm.playing)
        PillButton("รีเซ็ตท่าชิ้นนี้", onClick = { vm.resetSelectedPose() }, enabled = !vm.playing)
        PillButton("ล้างเฟรมนี้", onClick = { vm.clearFrame() }, enabled = !vm.playing, style = PillStyle.DANGER)
    }
}

@Composable
private fun ExportDialog(vm: EditorViewModel, onDismiss: () -> Unit) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var w by remember { mutableStateOf("256") }
    var h by remember { mutableStateOf("256") }
    var cols by remember { mutableStateOf(minOf(5, vm.project.frameCount).toString()) } // คอลัมน์ต้องไม่เกินจำนวนเฟรม
    var preview by remember { mutableStateOf<Bitmap?>(null) }
    var error by remember { mutableStateOf<String?>(null) }
    var busy by remember { mutableStateOf(false) }

    fun generate(onDone: (Bitmap) -> Unit) {
        val fw = w.toIntOrNull()
        val fh = h.toIntOrNull()
        val c = cols.toIntOrNull()
        val err = Exporter.validate(fw, fh, c, vm.project.frameCount)
        if (err != null) {
            error = err
            return
        }
        if (vm.project.parts.isEmpty()) {
            error = "ยังไม่มีชิ้นส่วนให้ส่งออก"
            return
        }
        error = null
        busy = true
        val parts = vm.project.parts.toList()
        val frames = vm.project.snapshotFrames()
        scope.launch {
            val result = runCatching {
                withContext(Dispatchers.Default) { Exporter.buildSheet(parts, frames, fw!!, fh!!, c!!) }
            }
            busy = false
            result.onSuccess {
                preview = it
                onDone(it)
            }.onFailure {
                error = "สร้างสไปรต์ชีตไม่สำเร็จ: ${it.message ?: it.javaClass.simpleName}"
            }
        }
    }

    AlertDialog(
        onDismissRequest = { if (!busy) onDismiss() },
        title = { Text("ส่งออก Sprite Sheet (PNG โปร่งใส)") },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(w, { w = it; preview = null }, label = { Text("กว้างต่อเฟรม (px)") }, singleLine = true)
                OutlinedTextField(h, { h = it; preview = null }, label = { Text("สูงต่อเฟรม (px)") }, singleLine = true)
                OutlinedTextField(cols, { cols = it; preview = null }, label = { Text("จำนวนคอลัมน์") }, singleLine = true)
                Text(
                    "จำนวนแถวคำนวณอัตโนมัติจาก ${vm.project.frameCount} เฟรม ÷ คอลัมน์",
                    style = MaterialTheme.typography.bodySmall,
                )
                error?.let { Text(it, color = MaterialTheme.colorScheme.error) }
                preview?.let {
                    Image(
                        bitmap = it.asImageBitmap(),
                        contentDescription = "ตัวอย่างสไปรต์ชีต",
                        contentScale = ContentScale.Fit,
                        modifier = Modifier.fillMaxWidth().heightIn(max = 200.dp).background(Color(0xFF555555)),
                    )
                }
                if (busy) Text("กำลังประมวลผล...")
            }
        },
        confirmButton = {
            Row {
                TextButton(enabled = !busy, onClick = { generate { } }) { Text("ดูตัวอย่าง") }
                TextButton(enabled = !busy, onClick = {
                    generate { bmp ->
                        scope.launch {
                            busy = true
                            val saved = runCatching {
                                withContext(Dispatchers.IO) {
                                    Exporter.savePng(context, bmp, "spritesheet_${System.currentTimeMillis()}")
                                }
                            }
                            busy = false
                            saved.onSuccess {
                                vm.message = "บันทึกแล้ว: $it"
                                onDismiss()
                            }.onFailure {
                                error = "บันทึกไม่สำเร็จ: ${it.message ?: it.javaClass.simpleName}"
                            }
                        }
                    }
                }) { Text("บันทึก") }
            }
        },
        dismissButton = { TextButton(enabled = !busy, onClick = onDismiss) { Text("ปิด") } },
    )
}

private fun DrawScope.drawGuides(vm: EditorViewModel) {
    val grid = Color(0xFF2A2D34)
    val axis = Color(0xFF3B404A)
    for (k in -10..10) {
        val c = if (k == 0) axis else grid
        drawLine(c, vm.toScreen(Offset(k * 100f, -1000f)), vm.toScreen(Offset(k * 100f, 1000f)), 1.5f)
        drawLine(c, vm.toScreen(Offset(-1000f, k * 100f)), vm.toScreen(Offset(1000f, k * 100f)), 1.5f)
    }
    // กรอบส่งออก: สิ่งที่อยู่ในกรอบนี้คือสิ่งที่จะอยู่ในแต่ละเฟรมของสไปรต์ชีต
    val half = Exporter.WORLD_WINDOW / 2f
    drawRect(
        Color(0xFF4FC3F7),
        topLeft = vm.toScreen(Offset(-half, -half)),
        size = Size(Exporter.WORLD_WINDOW * vm.zoom, Exporter.WORLD_WINDOW * vm.zoom),
        style = Stroke(width = 2f, pathEffect = PathEffect.dashPathEffect(floatArrayOf(14f, 10f))),
    )
}

private fun DrawScope.drawOverlay(vm: EditorViewModel) {
    val parts = vm.project.parts
    val poseFn = vm.poseOf()
    val joints = computeJointMatrices(parts, poseFn)
    val sel = vm.selected
    val screenPos = HashMap<Int, Offset>()
    for (p in parts) {
        val j = joints[p.id] ?: continue
        val pt = floatArrayOf(0f, 0f)
        j.mapPoints(pt)
        screenPos[p.id] = vm.toScreen(Offset(pt[0], pt[1]))
    }
    for (p in parts) { // กระดูก = เส้นเชื่อมข้อต่อ parent -> ข้อต่อลูก
        val pid = p.parentId ?: continue
        val a = screenPos[pid] ?: continue
        val b = screenPos[p.id] ?: continue
        drawLine(Color(0x88FFFFFF), a, b, 3f)
    }
    for (p in parts) { // ปลายของกระดูกที่ไม่มีลูก (เช่น มือ): วาดตามทิศจริงของกระดูก ให้เหมือนหน้าแก้ไขกระดูก
        if (p.boneLength <= 0f || parts.any { it.parentId == p.id }) continue
        val a = screenPos[p.id] ?: continue
        val j = joints[p.id] ?: continue
        val pt = floatArrayOf(p.boneLength, 0f)
        j.mapPoints(pt)
        val b = vm.toScreen(Offset(pt[0], pt[1]))
        drawLine(Color(0x88FFFFFF), a, b, 3f)
        drawCircle(Color(0xFFFFD54F), 6f, b)
    }
    for (p in parts) { // จุดต่อ (ปลายกระดูก): เส้นจากข้อต่อไปยังจุดปลาย แล้วจุดเขียวให้จับลาก
        if (!p.hasTip) continue
        val a = screenPos[p.id] ?: continue
        val b = Offset(a.x, a.y + tipLength(p) * vm.zoom) // ปุ่มเขียวอยู่ใต้ปุ่มแดงในแนวตั้งเสมอ
        drawLine(Color(0xFF4FC3F7), a, b, 4f)
        drawCircle(Color(0xFF69F0AE), if (p.id == sel?.id) 16f else 10f, b)
    }
    for (p in parts) {
        val s = screenPos[p.id] ?: continue
        val isSel = p.id == sel?.id && p.boneLength <= 0f // ชิ้นที่มาจากกระดูก: จุดแดงอยู่ที่ปลายกระดูก (ด้านล่าง)
        drawCircle(if (isSel) Color(0xFFFF5252) else Color(0xFFFFD54F), if (isSel) 10f else 6f, s)
    }
    for (r in parts) { // จุดหลัก (ข้อต่อราก): ลากเพื่อย้ายทั้งตัวละคร
        if (r.parentId != null) continue
        val s = screenPos[r.id] ?: continue
        if (vm.mainDragging) drawCircle(Color(0xFFFF5252), 10f, s)
        drawCircle(Color(0xAAFFFFFF), 16f, s, style = Stroke(width = 2.5f))
    }
    if (sel != null && sel.boneLength > 0f) { // กระดูกที่เลือก: จุดแดงที่ปลายกระดูก (จุดที่แตะลากได้)
        val j = joints[sel.id]
        if (j != null) {
            val tp = floatArrayOf(sel.boneLength, 0f)
            j.mapPoints(tp)
            drawCircle(Color(0xFFFF5252), 10f, vm.toScreen(Offset(tp[0], tp[1])))
        }
    }
}
