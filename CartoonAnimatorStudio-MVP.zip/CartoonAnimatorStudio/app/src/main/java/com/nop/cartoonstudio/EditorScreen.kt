package com.nop.cartoonstudio

import android.graphics.Bitmap
import android.content.Intent
import android.widget.Toast
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.calculateCentroid
import androidx.compose.foundation.gestures.calculatePan
import androidx.compose.foundation.gestures.calculateZoom
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Slider
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.runtime.withFrameNanos
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.drawIntoCanvas
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.core.content.ContextCompat
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlin.math.cos
import kotlin.math.roundToInt
import kotlin.math.sin

@Composable
fun EditorScreen(vm: EditorViewModel) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var showExport by remember { mutableStateOf(false) }
    var showLoad by remember { mutableStateOf(false) }
    var deleteCharId by remember { mutableStateOf<Int?>(null) }
    var updating by remember { mutableStateOf(false) }
    var newVersionAsk by remember { mutableStateOf(false) } // เปิดแอปแล้วเจอเวอร์ชันใหม่: ถามว่าจะอัปเดตเลยไหม
    var showSettings by remember { mutableStateOf(false) }
    var showNewConfirm by remember { mutableStateOf(false) }
    var showSaveProject by remember { mutableStateOf(false) }
    var showLoadProject by remember { mutableStateOf(false) }
    var showFrameEdit by remember { mutableStateOf(false) }
    val paint = remember {
        android.graphics.Paint(android.graphics.Paint.FILTER_BITMAP_FLAG or android.graphics.Paint.ANTI_ALIAS_FLAG)
    }

    LaunchedEffect(vm.message) {
        val m = vm.message
        if (m != null) {
            Toast.makeText(context, m, Toast.LENGTH_LONG).show()
            vm.message = null
        }
    }

    // ผลส่งออกวิดีโอ (งานรันใน ExportService จึงอาจเสร็จตอนอยู่นอกแอป): รับไปแสดงเมื่อกลับมา
    LaunchedEffect(ExportJob.doneMessage) {
        ExportJob.doneMessage?.let {
            vm.message = it
            ExportJob.doneMessage = null
            showExport = false
        }
    }
    LaunchedEffect(ExportJob.error) {
        ExportJob.error?.let {
            vm.message = it
            ExportJob.error = null
        }
    }

    LaunchedEffect(vm.playing) {
        if (vm.playing) {
            var last = withFrameNanos { it }
            while (vm.playing) {
                val now = withFrameNanos { it }
                vm.tick((now - last) / 1_000_000_000f)
                last = now
            }
        }
    }

    fun startUpdate() {
        scope.launch {
            updating = true
            val r = runCatching { withContext(Dispatchers.IO) { AppUpdater.download(context) } }
            updating = false
            r.onSuccess { f ->
                if (!AppUpdater.install(context, f)) {
                    vm.message = "อนุญาตให้แอปนี้ติดตั้งแอป แล้วกด \"อัปเดตแอป\" อีกครั้ง"
                }
            }.onFailure { vm.message = "อัปเดตไม่สำเร็จ: ${it.message ?: it.javaClass.simpleName}" }
        }
    }

    LaunchedEffect(Unit) { // เปิดแอปครั้งแรก: เช็กเงียบๆ ว่ามีเวอร์ชันใหม่ไหม (เช็กไม่ได้ = ไม่แจ้งอะไร)
        if (withContext(Dispatchers.IO) { AppUpdater.hasNewer(context) }) newVersionAsk = true
    }
    if (newVersionAsk) {
        AlertDialog(
            onDismissRequest = { newVersionAsk = false },
            title = { Text("มีเวอร์ชันใหม่") },
            text = { Text("มีแอปเวอร์ชันใหม่บน GitHub อัปเดตเลยไหม (งานที่ทำไว้เซฟอัตโนมัติอยู่แล้ว)") },
            confirmButton = { TextButton(onClick = { newVersionAsk = false; startUpdate() }) { Text("อัปเดต") } },
            dismissButton = { TextButton(onClick = { newVersionAsk = false }) { Text("ไว้ก่อน") } },
        )
    }

    Column(Modifier.fillMaxSize().systemBarsPadding().background(Palette.Bg)) {
        // แถบบน: ชื่อแอป + ตั้งค่า + ส่งออก
        Row(
            Modifier.fillMaxWidth().background(Palette.Panel).padding(horizontal = 14.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            Text(
                "Cartoon Animator Studio",
                Modifier.weight(1f),
                style = MaterialTheme.typography.titleSmall,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.primary,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
            )
            if (vm.characterClipboard != null) { // คัดลอกตัวละครไว้แล้ว: ปุ่มวางอยู่ซ้ายของปุ่ม +
                CircleIconButton("📋", 20, accent = true, enabled = !vm.playing) { vm.pasteCharacter() }
            }
            CircleIconButton("+", 28) { showLoad = true } // โหลดตัวละครเข้าฉาก
            CircleIconButton("⚙", 22) { showSettings = true }
            PillButton("ส่งออก", onClick = { showExport = true }, style = PillStyle.PRIMARY)
        }

        // ผืนผ้าใบ
        Box(
            Modifier
                .weight(1f)
                .fillMaxWidth()
                .padding(horizontal = 10.dp, vertical = 8.dp)
                .clip(RoundedCornerShape(18.dp))
                .border(1.dp, Palette.Stroke, RoundedCornerShape(18.dp)),
        ) {
            Canvas(
                Modifier
                    .fillMaxSize()
                    .onSizeChanged { vm.onCanvasSize(it) }
                    .pointerInput(Unit) {
                        awaitEachGesture {
                            val down = awaitFirstDown(requireUnconsumed = false)
                            vm.onDown(down.position)
                            var multi = false
                            do {
                                val event = awaitPointerEvent()
                                val pressed = event.changes.filter { it.pressed }
                                if (pressed.size >= 2) {
                                    multi = true
                                    vm.onTransform(event.calculateCentroid(), event.calculatePan(), event.calculateZoom())
                                    event.changes.forEach { it.consume() }
                                } else if (pressed.size == 1 && !multi) {
                                    val c = pressed[0]
                                    val d = c.position - c.previousPosition
                                    if (d != Offset.Zero) vm.onDrag(c.position, d)
                                    c.consume()
                                }
                            } while (event.changes.any { it.pressed })
                            vm.onUp()
                        }
                    },
            ) {
                drawRect(Color(0xFF1B1D22))
                drawGuides(vm)
                drawIntoCanvas { canvas ->
                    val nc = canvas.nativeCanvas
                    nc.save()
                    nc.translate(vm.canvasSize.width / 2f + vm.pan.x, vm.canvasSize.height / 2f + vm.pan.y)
                    nc.scale(vm.zoom, vm.zoom)
                    val onion = vm.onionOpacity
                    if (!vm.playing && vm.currentFrame > 0 && onion > 0.01f) { // เงาลางๆ ของเฟรมก่อนหน้า
                        val prev = vm.currentFrame - 1
                        nc.saveLayerAlpha(null, (onion * 255f).roundToInt().coerceIn(0, 255))
                        drawScene(nc, vm.project.parts, { id -> vm.project.poseAt(prev, id) }, paint, prev.toFloat())
                        nc.restore()
                    }
                    if (vm.pathMode && !vm.playing) { // เงาตัวละครจางๆ ที่เฟรมเริ่มกับเฟรมจบของเส้นทาง
                        val pa = vm.activePath()
                        if (pa != null) {
                            val mine = vm.project.parts.filter { it.characterId == pa.characterId }
                            for (f in listOf(pa.startFrame, pa.endFrame).distinct()) {
                                if (f == vm.currentFrame || f !in 0 until vm.project.frameCount) continue
                                nc.saveLayerAlpha(null, 85)
                                drawScene(nc, mine, { id -> vm.project.poseAt(f, id) }, paint, f.toFloat())
                                nc.restore()
                            }
                        }
                    }
                    drawScene(nc, vm.project.parts, vm.poseOf(), paint, if (vm.playing) vm.playhead else vm.currentFrame.toFloat())
                    nc.restore()
                }
                if (vm.pathMode) drawPathOverlay(vm) else drawOverlay(vm)
            }
            if (!vm.playing && vm.project.parts.isNotEmpty() && (vm.tool == Tool.CHAR_SCALE || vm.tool == Tool.CHAR_ROTATE)) {
                Surface(
                    color = Color(0xCC000000),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.align(Alignment.BottomCenter).padding(10.dp),
                ) {
                    Text(
                        if (vm.tool == Tool.CHAR_SCALE) {
                            "ขนาด ${(vm.charScale * 100f).roundToInt()}%\nใช้ 2 นิ้วถ่างออก = ใหญ่ขึ้น หุบเข้า = เล็กลง"
                        } else {
                            "มุม ${vm.characterAngle().roundToInt()}°\nลากนิ้วรอบจุดหลัก = หมุนตัวละคร"
                        },
                        Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
                        color = Color.White,
                        style = MaterialTheme.typography.bodySmall,
                        textAlign = TextAlign.Center,
                    )
                }
            }
            if (vm.pathMode && !vm.playing) {
                val hasPath = vm.activePath() != null
                val hint = when {
                    vm.pathGrab && hasPath -> "◉  ลากจุดขาวเล็กๆ ไปตามเส้นเพื่อปรับตำแหน่งแต่ละเฟรม"
                    vm.pathDrawMode == PathDrawMode.LINE && !hasPath -> "╱  กดจุดแรก แล้วลากไปอีกจุด จะเป็นเส้นตรงอัตโนมัติ"
                    vm.pathDrawMode == PathDrawMode.LINE -> "ลากจุดขาวเพื่อดัดโค้ง · กดแล้วลากบนที่ว่างเพื่อวาดเส้นตรงใหม่"
                    vm.pathDrawMode == PathDrawMode.FREE && !hasPath -> "✍  ลากนิ้ววาดเส้นทาง"
                    vm.pathDrawMode == PathDrawMode.FREE -> "ลากจุดขาวเพื่อดัดโค้ง · ลากบนที่ว่างเพื่อวาดเส้นใหม่"
                    !hasPath && vm.pathDraft.isEmpty() -> "◎  แตะวางจุดเริ่มต้น"
                    !hasPath -> "◎  แตะวางจุดถัดไป"
                    else -> "ลากจุดขาวเพื่อดัดโค้ง · แตะใกล้เส้นเพื่อแทรกจุด · แตะที่ว่างเพื่อต่อท้าย"
                }
                Surface(
                    color = Color(0xCC000000),
                    shape = RoundedCornerShape(50),
                    modifier = Modifier.align(Alignment.TopCenter).padding(10.dp),
                ) {
                    Text(
                        hint,
                        Modifier.padding(horizontal = 16.dp, vertical = 8.dp),
                        color = Color.White,
                        style = MaterialTheme.typography.bodySmall,
                        textAlign = TextAlign.Center,
                    )
                }
            }
            if (vm.project.parts.isEmpty()) {
                Text(
                    "ยังไม่มีตัวละคร\nกดปุ่ม + มุมขวาบนเพื่อโหลดตัวละคร",
                    Modifier.align(Alignment.Center).padding(24.dp),
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    textAlign = TextAlign.Center,
                )
            }
            // แถบตัวละครด้านซ้าย (เหมือนแถบเลเยอร์) + เมนูของตัวที่เลือก ซ่อนตอนเล่นเพื่อให้เห็นภาพชัด
            val chars = vm.project.characters()
            if (!vm.playing && chars.isNotEmpty() && !vm.pathMode) {
                Row(
                    Modifier.align(Alignment.TopStart).padding(8.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalAlignment = Alignment.Top,
                ) {
                    CharacterLayerPanel(vm, chars)
                    val sel = chars.firstOrNull { it.first == vm.selectedCharacterId }
                    if (sel != null) {
                        CharacterMenu(vm, sel.second.ifBlank { "ตัวละคร" }, onDelete = { deleteCharId = sel.first })
                    }
                }
            }
        }

        // แผงล่าง: แก้ไขเฟรม + เส้นเวลา (โหลด/ลบ/หมุน/ขยายตัวละครย้ายไปอยู่ที่ปุ่ม + และแถบตัวละครด้านซ้าย)
        Surface(
            color = Palette.Panel,
            shape = RoundedCornerShape(topStart = 22.dp, topEnd = 22.dp),
            modifier = Modifier.fillMaxWidth(),
        ) {
            Column(
                Modifier.heightIn(max = if (vm.pathMode) 400.dp else 290.dp).verticalScroll(rememberScrollState()).padding(top = 10.dp, bottom = 12.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp),
            ) {
                // หัวแผง: ป้ายบอกเฟรมที่เลือก + ปุ่มแก้ไขเฟรม
                Row(
                    Modifier.fillMaxWidth().padding(horizontal = 14.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Text(
                        "เฟรม ${vm.currentFrame + 1} / ${vm.project.frameCount}",
                        Modifier.weight(1f),
                        color = Color(0xFFC9C4D4),
                        fontWeight = FontWeight.Bold,
                    )
                    // ย้อนกลับ / ทำซ้ำ (ลาก 1 ครั้ง = 1 ก้าว เก็บย้อนหลังสูงสุด 50 ก้าว) จางลงเมื่อไม่มีให้ย้อน
                    RoundIconButton("ย้อนกลับ", selected = false, enabled = vm.canUndo && !vm.playing, onClick = { vm.undo() }) { color ->
                        drawUndoRedoIcon(color, redo = false)
                    }
                    RoundIconButton("ทำซ้ำ", selected = false, enabled = vm.canRedo && !vm.playing, onClick = { vm.redo() }) { color ->
                        drawUndoRedoIcon(color, redo = true)
                    }
                    // เปิดหน้าต่างตั้งความเร็วเล่นเฉพาะช่วงเฟรม (ไฮไลต์เมื่อเฟรมที่เลือกอยู่ในช่วงที่ตั้งความเร็วไว้)
                    Chip("แก้ไขเฟรม", vm.project.rangeAt(vm.currentFrame) != null, enabled = !vm.playing) { showFrameEdit = true }
                }

                if (vm.pathMode) PathBar(vm)
                Timeline(vm)
            }
        }
    }

    if (showSettings) {
        SettingsDialog(
            vm,
            updating = updating,
            onOpenBones = { showSettings = false; vm.boneEditorOpen = true },
            onUpdate = { startUpdate() },
            onNewProject = { showSettings = false; showNewConfirm = true },
            onSaveProject = { showSettings = false; showSaveProject = true },
            onLoadProject = { showSettings = false; showLoadProject = true },
        ) { showSettings = false }
    }
    if (showNewConfirm) {
        NewProjectDialog(
            vm,
            onSaveFirst = { showNewConfirm = false; showSaveProject = true },
        ) { showNewConfirm = false }
    }
    if (showSaveProject) SaveProjectDialog(vm) { showSaveProject = false }
    if (showLoadProject) LoadProjectDialog(vm) { showLoadProject = false }
    if (showLoad) LoadCharacterDialog(vm) { showLoad = false }
    deleteCharId?.let { cid ->
        val name = vm.project.characters().firstOrNull { it.first == cid }?.second?.ifBlank { "ตัวละคร" } ?: "ตัวละคร"
        AlertDialog(
            onDismissRequest = { deleteCharId = null },
            title = { Text("ลบตัวละคร?") },
            text = { Text("ต้องการลบ \"$name\" ออกจากฉากใช่ไหม ท่าทางของตัวละครนี้ในทุกเฟรมจะหายไปด้วย ตัวละครอื่นไม่ถูกลบ") },
            confirmButton = {
                PillButton("ลบตัวละคร", style = PillStyle.DANGER, onClick = {
                    vm.deleteCharacter(cid)
                    vm.message = "ลบตัวละคร \"$name\" แล้ว"
                    deleteCharId = null
                })
            },
            dismissButton = { PillButton("ยกเลิก", onClick = { deleteCharId = null }) },
        )
    }
    if (showFrameEdit) FrameSpeedDialog(vm) { showFrameEdit = false }
    vm.pathPrompt?.let { PathPromptDialog(vm, it) }
    if (showExport || ExportJob.running) ExportDialog(vm) { showExport = false }
}

/** ปุ่มกลมบนแถบบน (รูปทรงเดียวกับปุ่มตั้งค่า) */
@Composable
private fun CircleIconButton(label: String, fontSp: Int, accent: Boolean = false, enabled: Boolean = true, onClick: () -> Unit) {
    Box(
        Modifier
            .size(44.dp)
            .alpha(if (enabled) 1f else 0.38f)
            .clip(CircleShape)
            .background(if (accent) TonalBg else Palette.PanelHigh)
            .border(1.dp, if (accent) Palette.Accent else Palette.Stroke, CircleShape)
            .clickable(enabled = enabled, onClick = onClick),
        contentAlignment = Alignment.Center,
    ) { Text(label, fontSize = fontSp.sp, color = if (accent) TonalFg else Color(0xFFE7E3EE)) }
}

private val PanelGlass = Color(0xE61C1C26)

/** แถบตัวละครด้านซ้าย: ตัวละครแต่ละตัวเป็นช่อง รูปย่อ + "ตัวละคร N" เรียงลงมา แตะเพื่อเปิด/ปิดเมนูของตัวนั้น */
@Composable
private fun CharacterLayerPanel(vm: EditorViewModel, chars: List<Pair<Int, String>>) {
    val shape = RoundedCornerShape(18.dp)
    Column(
        Modifier
            .width(74.dp)
            .clip(shape)
            .background(PanelGlass)
            .border(1.dp, Palette.Stroke, shape)
            .pointerInput(Unit) { detectTapGestures { } } // กันนิ้วที่แตะพื้นที่แถบทะลุไปลากผืนผ้าใบ
            .verticalScroll(rememberScrollState())
            .padding(6.dp),
        verticalArrangement = Arrangement.spacedBy(6.dp),
    ) {
        chars.forEachIndexed { index, c ->
            val cid = c.first
            val selected = vm.selectedCharacterId == cid
            val mine = vm.project.parts.filter { it.characterId == cid }
            val flipH = mine.firstOrNull()?.mirrorH ?: false
            val flipV = mine.firstOrNull()?.mirrorV ?: false
            val thumb = remember(cid, mine.size, flipH, flipV) { characterThumbnail(mine, 112) }
            val shapeItem = RoundedCornerShape(14.dp)
            Column(
                Modifier
                    .fillMaxWidth()
                    .clip(shapeItem)
                    .background(if (selected) TonalBg else Palette.PanelHigh)
                    .border(if (selected) 2.dp else 1.dp, if (selected) Palette.Accent else Palette.Stroke, shapeItem)
                    .clickable { vm.toggleCharacterMenu(cid) }
                    .padding(vertical = 5.dp, horizontal = 3.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(2.dp),
            ) {
                Box(Modifier.size(52.dp), contentAlignment = Alignment.Center) {
                    if (thumb != null) {
                        Image(thumb.asImageBitmap(), contentDescription = null, modifier = Modifier.fillMaxSize(), contentScale = ContentScale.Fit)
                    } else {
                        Text("?", color = NormalFg)
                    }
                }
                Text(
                    "ตัวละคร ${index + 1}",
                    fontSize = 10.sp,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                    color = if (selected) TonalFg else NormalFg,
                    fontWeight = if (selected) FontWeight.Bold else FontWeight.Normal,
                )
            }
        }
    }
}

/** เมนูของตัวละครที่เลือก (เรียงลงมาทางซ้าย): พลิกซ้ายขวา / พลิกขึ้นลง / หมุน / ขยาย / ลบ / คัดลอก */
@Composable
private fun CharacterMenu(vm: EditorViewModel, name: String, onDelete: () -> Unit) {
    val shape = RoundedCornerShape(18.dp)
    Column(
        Modifier
            .width(138.dp)
            .clip(shape)
            .background(PanelGlass)
            .border(1.dp, Palette.Stroke, shape)
            .pointerInput(Unit) { detectTapGestures { } }
            .verticalScroll(rememberScrollState())
            .padding(8.dp),
        verticalArrangement = Arrangement.spacedBy(6.dp),
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(name, Modifier.weight(1f), fontWeight = FontWeight.Bold, color = Palette.Accent, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Text(
                "✕",
                Modifier.clip(CircleShape).clickable { vm.closeCharacterMenu() }.padding(horizontal = 8.dp, vertical = 2.dp),
                color = NormalFg,
            )
        }
        // ถือของ: สิ่งของติดอยู่ = ปุ่มถอด, ถอดแล้ว = ปุ่มติด (เลือกมือของตัวละครไหนในฉากก็ได้) อยู่บนสุดของเมนูจะได้ไม่ต้องเลื่อนหา
        val cid = vm.activeCharacterId()
        val ownItems = if (cid != null) vm.itemsOf(cid) else emptyList()
        val items = if (cid != null) (ownItems + vm.heldFromOthers(cid)).distinctBy { it.id } else emptyList()
        val hands = if (cid != null) vm.handsOf(cid) else emptyList()
        val sceneHands = vm.allHands()
        var pickItemId by remember { mutableStateOf<Int?>(null) } // สิ่งของที่กำลังเลือกมือจะติด (มีหลายมือ)
        if (items.isNotEmpty() || hands.isNotEmpty()) {
            Text("ถือของ", fontSize = 11.sp, color = Palette.Accent, modifier = Modifier.padding(start = 6.dp, top = 4.dp))
            for (item in items) {
                if (vm.isHeld(item)) {
                    CharacterMenuItem("🖐", "ถอด ${item.name}") { vm.detachItem(item.id) }
                } else {
                    val able = sceneHands.filter { h -> vm.canAttachItem(item, h) }
                    CharacterMenuItem("🤝", "ติด ${item.name}") {
                        when {
                            sceneHands.isEmpty() -> vm.message = "ยังไม่มีมือในฉาก (ตั้งกระดูกเป็น \"มือ\" ในหน้าจัดกระดูก แล้วโหลดเข้าฉาก)"
                            able.size == 1 -> vm.attachItem(item.id, able[0].id)
                            able.isEmpty() -> vm.message = "ติดกับมือนี้ไม่ได้"
                            else -> pickItemId = item.id
                        }
                        Unit
                    }
                }
            }
        }
        CharacterMenuItem("↔", "พลิกซ้ายขวา") { vm.flipCharacter(horizontal = true) } // เฉพาะเฟรมนี้
        CharacterMenuItem("↕", "พลิกขึ้นลง") { vm.flipCharacter(horizontal = false) } // เฉพาะเฟรมนี้
        CharacterMenuItem("↔", "ทุกเฟรม") { vm.flipCharacter(horizontal = true, allFrames = true) }
        CharacterMenuItem("↕", "ทุกเฟรม") { vm.flipCharacter(horizontal = false, allFrames = true) }
        CharacterMenuItem("⟳", "หมุนตัวละคร", active = vm.tool == Tool.CHAR_ROTATE) { vm.toggleCharTool(Tool.CHAR_ROTATE) }
        CharacterMenuItem("⤢", "ขยายตัวละคร", active = vm.tool == Tool.CHAR_SCALE) { vm.toggleCharTool(Tool.CHAR_SCALE) }
        val fade = vm.charAlpha
        val fadeShape = RoundedCornerShape(16.dp)
        Column(Modifier.fillMaxWidth().clip(fadeShape).background(Palette.PanelHigh).border(1.dp, Palette.Stroke, fadeShape).padding(horizontal = 12.dp, vertical = 4.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("💧 ความจาง", Modifier.weight(1f), fontSize = 13.sp, color = NormalFg)
                Text("${(fade * 100f).roundToInt()}%", fontSize = 12.sp, color = MaterialTheme.colorScheme.primary)
            }
            Slider(
                value = fade,
                onValueChange = { vm.beginAlphaEdit(); vm.setCharacterAlpha(it) },
                onValueChangeFinished = { vm.endAlphaEdit() },
                valueRange = 0.1f..1f,
            )
        }
        CharacterMenuItem("〰", "เส้นทาง", active = vm.activePath() != null) { vm.openPathMode() } // วาดเส้นให้ตัวละครเดินตาม
        CharacterMenuItem("🗑", "ลบตัวละคร", danger = true, onClick = onDelete)
        CharacterMenuItem("📋", "คัดลอกตัวละคร") { vm.copyCharacter() }

        val pickItem = vm.project.part(pickItemId)
        if (pickItem != null) {
            val able = sceneHands.filter { h -> vm.canAttachItem(pickItem, h) }
            AlertDialog(
                onDismissRequest = { pickItemId = null },
                title = { Text("ติด \"${pickItem.name}\" กับมือไหน") },
                text = {
                    Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                        for (h in able) {
                            TextButton(onClick = {
                                vm.attachItem(pickItem.id, h.id)
                                pickItemId = null
                            }) { Text("🖐 ${vm.handLabel(h)}") }
                        }
                    }
                },
                confirmButton = {},
                dismissButton = { TextButton(onClick = { pickItemId = null }) { Text("ยกเลิก") } },
            )
        }
    }
}

@Composable
private fun CharacterMenuItem(icon: String, label: String, active: Boolean = false, danger: Boolean = false, onClick: () -> Unit) {
    val shape = RoundedCornerShape(50)
    Row(
        Modifier
            .fillMaxWidth()
            .heightIn(min = 40.dp)
            .clip(shape)
            .background(if (active) TonalBg else Palette.PanelHigh)
            .border(1.dp, if (active) Palette.Accent else Palette.Stroke, shape)
            .clickable(onClick = onClick)
            .padding(horizontal = 12.dp, vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(8.dp),
    ) {
        Text(icon, fontSize = 16.sp, color = if (danger) Color(0xFFFF8A80) else if (active) TonalFg else NormalFg)
        Text(
            label,
            fontSize = 13.sp,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
            color = if (danger) Color(0xFFFF8A80) else if (active) TonalFg else NormalFg,
            fontWeight = if (active) FontWeight.Bold else FontWeight.Normal,
        )
    }
}

private enum class PillStyle { PRIMARY, TONAL, OUTLINE, DANGER }

private val TonalBg = Color(0xFF42338A)
private val TonalFg = Color(0xFFE9E0FF)
private val NormalFg = Color(0xFFE7E3EE)

/** ปุ่มทรงแคปซูลของแอป: PRIMARY = ม่วงทึบ, TONAL = ม่วงเข้ม, OUTLINE = พื้นเทาขอบบาง, DANGER = ตัวอักษรแดงอ่อน */
@Composable
private fun PillButton(
    label: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    enabled: Boolean = true,
    style: PillStyle = PillStyle.OUTLINE,
) {
    val shape = RoundedCornerShape(50)
    val bg = when (style) {
        PillStyle.PRIMARY -> Palette.Accent
        PillStyle.TONAL -> TonalBg
        else -> Palette.PanelHigh
    }
    val fg = when (style) {
        PillStyle.PRIMARY -> Color(0xFF2A1A66)
        PillStyle.TONAL -> TonalFg
        PillStyle.DANGER -> Color(0xFFFF8A80)
        PillStyle.OUTLINE -> NormalFg
    }
    val edge = when (style) {
        PillStyle.PRIMARY -> Palette.Accent
        PillStyle.TONAL -> Color(0xFF6B58C9)
        else -> Palette.Stroke
    }
    Box(
        modifier
            .heightIn(min = 44.dp)
            .alpha(if (enabled) 1f else 0.38f)
            .clip(shape)
            .background(bg)
            .border(1.dp, edge, shape)
            .clickable(enabled = enabled, onClick = onClick)
            .padding(horizontal = 18.dp, vertical = 8.dp),
        contentAlignment = Alignment.Center,
    ) { Text(label, color = fg, fontWeight = FontWeight.Medium, textAlign = TextAlign.Center) }
}

/** ชิปเลือก/สลับ (ใช้กับเครื่องมือ, วนซ้ำ, ชื่อชิ้นส่วน) */
@Composable
private fun Chip(label: String, selected: Boolean, enabled: Boolean = true, onClick: () -> Unit) {
    val shape = RoundedCornerShape(50)
    Box(
        Modifier
            .heightIn(min = 44.dp)
            .alpha(if (enabled) 1f else 0.38f)
            .clip(shape)
            .background(if (selected) TonalBg else Palette.PanelHigh)
            .border(1.dp, if (selected) Palette.Accent else Palette.Stroke, shape)
            .clickable(enabled = enabled, onClick = onClick)
            .padding(horizontal = 16.dp, vertical = 8.dp),
        contentAlignment = Alignment.Center,
    ) {
        Text(
            label,
            color = if (selected) TonalFg else Color(0xFFC9C4D4),
            fontWeight = if (selected) FontWeight.Bold else FontWeight.Normal,
        )
    }
}

/** ปุ่มเลขเฟรม (วงกลม) */
@Composable
private fun FrameChip(number: Int, selected: Boolean, custom: Boolean = false, onClick: () -> Unit) {
    Box(
        Modifier
            .size(44.dp)
            .clip(CircleShape)
            .background(if (selected) TonalBg else if (custom) Color(0xFF223545) else Palette.PanelHigh)
            .border(
                if (selected || custom) 2.dp else 1.dp,
                if (selected) Palette.Accent else if (custom) Color(0xFF4FC3F7) else Palette.Stroke,
                CircleShape,
            )
            .clickable(onClick = onClick),
        contentAlignment = Alignment.Center,
    ) {
        Text(
            "$number",
            color = if (selected) TonalFg else Color(0xFFC9C4D4),
            fontWeight = if (selected) FontWeight.Bold else FontWeight.Normal,
        )
    }
}

/** ปุ่ม + ท้ายแถวเฟรม: เพิ่มเฟรมใหม่ (คัดลอกท่าจากเฟรมท้ายสุด) */
@Composable
private fun AddFrameButton(enabled: Boolean, onClick: () -> Unit) {
    Box(
        Modifier
            .size(44.dp)
            .alpha(if (enabled) 1f else 0.38f)
            .clip(CircleShape)
            .background(Palette.Accent)
            .clickable(enabled = enabled, onClick = onClick),
        contentAlignment = Alignment.Center,
    ) { Text("+", color = Color(0xFF2A1A66), fontSize = 26.sp, fontWeight = FontWeight.Bold) }
}

/** เมนูตั้งค่า: งาน (ใหม่/เซฟ/โหลด) / กระดูก / อัปเดตแอป / ขนาดวิดีโอ / ความจางของเงาเฟรมที่แล้ว */
@Composable
private fun SettingsDialog(
    vm: EditorViewModel,
    updating: Boolean,
    onOpenBones: () -> Unit,
    onUpdate: () -> Unit,
    onNewProject: () -> Unit,
    onSaveProject: () -> Unit,
    onLoadProject: () -> Unit,
    onDismiss: () -> Unit,
) {
    val card = RoundedCornerShape(16.dp)
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("ตั้งค่า") },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(14.dp)) {
                SettingsSection("งาน") {
                    SettingsAction("🆕", "เริ่มงานใหม่", "ล้างฉากเพื่อเริ่มโปรเจกต์ใหม่", onClick = onNewProject)
                    SettingsAction("💾", "เซฟงาน", "บันทึกงานนี้เก็บไว้ในแอปตั้งชื่อได้", onClick = onSaveProject)
                    SettingsAction("📂", "โหลดงาน", "เปิดงานที่เซฟไว้มาแก้ไขต่อ หรือลบเซฟ", onClick = onLoadProject)
                }
                SettingsSection("เครื่องมือ") {
                    SettingsAction("🦴", "กระดูก", "สร้าง/แก้ไขตัวละคร", onClick = onOpenBones)
                    SettingsAction(
                        "⬇️",
                        if (updating) "กำลังโหลด..." else "อัปเดตแอป",
                        "ดาวน์โหลดเวอร์ชันล่าสุดมาติดตั้งทับ",
                        enabled = !updating,
                        onClick = onUpdate,
                    )
                }
                UiScaleSetting() // ขนาดปุ่มและ UI ทั้งแอป (สไลเดอร์ + รีเซ็ต)
                VideoSizeSetting(vm)
                Column(
                    Modifier
                        .fillMaxWidth()
                        .clip(card)
                        .background(Palette.PanelHigh)
                        .border(1.dp, Palette.Stroke, card)
                        .padding(12.dp),
                    verticalArrangement = Arrangement.spacedBy(4.dp),
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("ความจางของเฟรมที่แล้ว", Modifier.weight(1f), fontWeight = FontWeight.Bold, color = Palette.Accent)
                        Text("${(vm.onionOpacity * 100f).roundToInt()}%", color = MaterialTheme.colorScheme.primary)
                    }
                    Slider(
                        value = vm.onionOpacity,
                        onValueChange = { vm.onionOpacity = it },
                        valueRange = 0f..1f,
                    )
                    Text(
                        "เงาลางๆ ของเฟรมก่อนหน้าบนผืนผ้าใบ (0% = ปิด)",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
            }
        },
        confirmButton = { TextButton(onClick = onDismiss) { Text("ปิด") } },
    )
}

/** หัวข้อ + กลุ่มปุ่มในเมนูตั้งค่า */
@Composable
private fun SettingsSection(title: String, content: @Composable () -> Unit) {
    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Text(title, fontWeight = FontWeight.Bold, color = Palette.Accent)
        content()
    }
}

/** แถวปุ่มในเมนูตั้งค่า: ไอคอน + ชื่อ + คำอธิบายสั้นๆ */
@Composable
private fun SettingsAction(icon: String, title: String, desc: String, enabled: Boolean = true, onClick: () -> Unit) {
    val shape = RoundedCornerShape(16.dp)
    Row(
        Modifier
            .fillMaxWidth()
            .alpha(if (enabled) 1f else 0.38f)
            .clip(shape)
            .background(Palette.PanelHigh)
            .border(1.dp, Palette.Stroke, shape)
            .clickable(enabled = enabled, onClick = onClick)
            .padding(horizontal = 14.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        Text(icon, fontSize = 24.sp)
        Column(Modifier.weight(1f)) {
            Text(title, fontWeight = FontWeight.Bold, color = NormalFg)
            Text(desc, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        Text("›", fontSize = 22.sp, color = Palette.Accent)
    }
}

/** ยืนยันเริ่มงานใหม่ (ล้างทุกอย่างในฉากและโครงกระดูก) มีทางเลือก "เซฟก่อน" */
@Composable
private fun NewProjectDialog(vm: EditorViewModel, onSaveFirst: () -> Unit, onDismiss: () -> Unit) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("เริ่มงานใหม่?") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("ตัวละคร เฟรม และโครงกระดูกในงานนี้จะถูกล้างทั้งหมด ย้อนกลับไม่ได้")
                Text(
                    "ตัวละครที่เซฟไว้ในเมนูกระดูก และงานที่เซฟไว้แล้วไม่หาย · ถ้ายังไม่ได้เซฟ แนะนำให้กด \"เซฟก่อน\"",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
        },
        confirmButton = {
            PillButton("เริ่มงานใหม่", style = PillStyle.DANGER, onClick = {
                vm.newProject()
                vm.message = "เริ่มงานใหม่แล้ว"
                onDismiss()
            })
        },
        dismissButton = {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                PillButton("เซฟก่อน", style = PillStyle.TONAL, onClick = onSaveFirst)
                PillButton("ยกเลิก", onClick = onDismiss)
            }
        },
    )
}

/** เซฟงาน: ตั้งชื่อ แล้วบันทึกลงที่เก็บของแอป (ชื่อซ้ำ = เซฟทับงานเดิมชื่อนั้น) */
@Composable
private fun SaveProjectDialog(vm: EditorViewModel, onDismiss: () -> Unit) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var name by remember { mutableStateOf(vm.projectName) }
    var existing by remember { mutableStateOf<List<SavedProject>>(emptyList()) }
    var busy by remember { mutableStateOf(false) }

    LaunchedEffect(Unit) {
        existing = runCatching { withContext(Dispatchers.IO) { ProjectStore.list(context) } }.getOrDefault(emptyList())
    }
    val clean = ProjectStore.cleanName(name)
    val overwrite = clean.isNotEmpty() && existing.any { it.name == clean }
    val empty = vm.project.parts.isEmpty() && vm.skeleton.bones.isEmpty()

    fun save() {
        if (clean.isEmpty() || busy) return
        busy = true
        val snap = AutoSave.capture(vm) // จับข้อมูลบน main thread แล้วค่อยเขียนไฟล์ใน IO
        val parts = vm.project.parts.size
        val frames = vm.project.frameCount
        scope.launch {
            val r = runCatching { withContext(Dispatchers.IO) { ProjectStore.save(context, clean, snap, parts, frames) } }
            busy = false
            r.onSuccess {
                vm.projectName = it
                vm.message = "เซฟงาน \"$it\" แล้ว ($parts ชิ้นส่วน, $frames เฟรม)"
                onDismiss()
            }.onFailure {
                vm.message = "เซฟงานไม่สำเร็จ: ${it.message ?: it.javaClass.simpleName}"
            }
        }
    }

    AlertDialog(
        onDismissRequest = { if (!busy) onDismiss() },
        title = { Text("เซฟงาน") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                OutlinedTextField(
                    value = name,
                    onValueChange = { name = it.take(40) },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true,
                    label = { Text("ชื่องาน") },
                )
                when {
                    empty -> Text(
                        "ตอนนี้ยังไม่มีตัวละครหรือกระดูกในงาน",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                    overwrite -> Box(Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp)).background(Color(0x33FF8A80)).padding(10.dp)) {
                        Text("มีงานชื่อนี้อยู่แล้ว จะเซฟทับงานเดิม", style = MaterialTheme.typography.bodySmall, color = Color(0xFFFF8A80))
                    }
                    else -> Text(
                        "บันทึกตัวละครในฉาก เฟรม/ท่า โครงกระดูก และค่าตั้งต่างๆ ไว้ในแอป (เปิดจาก ตั้งค่า > โหลดงาน)",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
                if (busy) Text("กำลังบันทึก...", color = MaterialTheme.colorScheme.primary)
            }
        },
        confirmButton = {
            PillButton(if (overwrite) "เซฟทับ" else "เซฟ", style = PillStyle.PRIMARY, enabled = clean.isNotEmpty() && !busy, onClick = { save() })
        },
        dismissButton = { PillButton("ยกเลิก", enabled = !busy, onClick = onDismiss) },
    )
}

/** รายการงานที่เซฟไว้ทั้งหมด: โหลดมาแก้ไขต่อ หรือลบเซฟ (ทั้งสองอย่างมีหน้าต่างยืนยัน) */
@Composable
private fun LoadProjectDialog(vm: EditorViewModel, onDismiss: () -> Unit) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var saved by remember { mutableStateOf<List<SavedProject>?>(null) }
    var busy by remember { mutableStateOf(false) }
    var pendingLoad by remember { mutableStateOf<String?>(null) }
    var pendingDelete by remember { mutableStateOf<String?>(null) }

    LaunchedEffect(Unit) {
        saved = runCatching { withContext(Dispatchers.IO) { ProjectStore.list(context) } }.getOrDefault(emptyList())
    }

    fun load(name: String) {
        busy = true
        scope.launch {
            val r = runCatching { withContext(Dispatchers.IO) { ProjectStore.read(context, name) } }
            r.onSuccess { restored ->
                try {
                    vm.playing = false
                    AutoSave.apply(vm, restored) // ต้องทำบน main thread
                    vm.boneEditorOpen = false
                    vm.frameClipboard = null
                    vm.projectName = name
                    vm.message = "โหลดงาน \"$name\" แล้ว (${restored.parts.size} ชิ้นส่วน, ${restored.frames.size} เฟรม)"
                    busy = false
                    onDismiss()
                } catch (e: Throwable) {
                    busy = false
                    vm.message = "โหลดไม่สำเร็จ: ${e.message ?: e.javaClass.simpleName}"
                }
            }.onFailure {
                busy = false
                vm.message = "โหลดไม่สำเร็จ: ${it.message ?: it.javaClass.simpleName}"
            }
        }
    }

    fun delete(name: String) {
        busy = true
        scope.launch {
            val r = runCatching { withContext(Dispatchers.IO) { ProjectStore.delete(context, name) } }
            busy = false
            r.onSuccess {
                saved = saved?.filter { it.name != name }
                vm.message = "ลบเซฟ \"$name\" แล้ว"
            }.onFailure {
                vm.message = "ลบเซฟไม่สำเร็จ: ${it.message ?: it.javaClass.simpleName}"
            }
        }
    }

    AlertDialog(
        onDismissRequest = { if (!busy) onDismiss() },
        title = { Text("โหลดงาน") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                val list = saved
                when {
                    list == null -> Text("กำลังอ่านรายการ...")
                    list.isEmpty() -> Text(
                        "ยังไม่มีงานที่เซฟไว้\nไปที่ ตั้งค่า > เซฟงาน เพื่อบันทึกงานนี้",
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                    else -> {
                        Text(
                            "งานที่เซฟไว้ ${list.size} งาน · โหลดแล้วงานปัจจุบันจะถูกแทนที่",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                        LazyColumn(Modifier.heightIn(max = 360.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            items(list, key = { it.name }) { p ->
                                ProjectRow(
                                    p,
                                    enabled = !busy,
                                    onLoad = { pendingLoad = p.name },
                                    onDelete = { pendingDelete = p.name },
                                )
                            }
                        }
                    }
                }
                if (busy) Text("กรุณารอสักครู่...", color = MaterialTheme.colorScheme.primary)
            }
        },
        confirmButton = { TextButton(enabled = !busy, onClick = onDismiss) { Text("ปิด") } },
    )

    pendingLoad?.let { name ->
        AlertDialog(
            onDismissRequest = { pendingLoad = null },
            title = { Text("โหลดงาน?") },
            text = { Text("โหลด \"$name\" มาแก้ไข งานปัจจุบันที่ยังไม่ได้เซฟจะถูกแทนที่") },
            confirmButton = {
                PillButton("โหลด", style = PillStyle.PRIMARY, onClick = { pendingLoad = null; load(name) })
            },
            dismissButton = { PillButton("ยกเลิก", onClick = { pendingLoad = null }) },
        )
    }
    pendingDelete?.let { name ->
        AlertDialog(
            onDismissRequest = { pendingDelete = null },
            title = { Text("ลบเซฟ?") },
            text = { Text("ลบงาน \"$name\" ที่เซฟไว้ ย้อนกลับไม่ได้ (งานที่เปิดอยู่ตอนนี้ไม่ถูกแตะ)") },
            confirmButton = {
                PillButton("ลบเซฟ", style = PillStyle.DANGER, onClick = { pendingDelete = null; delete(name) })
            },
            dismissButton = { PillButton("ยกเลิก", onClick = { pendingDelete = null }) },
        )
    }
}

/** การ์ดงานที่เซฟไว้: ชื่อ + วันเวลา + จำนวนชิ้นส่วน/เฟรม + ปุ่มโหลด / ลบเซฟ */
@Composable
private fun ProjectRow(p: SavedProject, enabled: Boolean, onLoad: () -> Unit, onDelete: () -> Unit) {
    val shape = RoundedCornerShape(16.dp)
    val date = remember(p.savedAt) {
        java.text.DateFormat.getDateTimeInstance(java.text.DateFormat.MEDIUM, java.text.DateFormat.SHORT)
            .format(java.util.Date(p.savedAt))
    }
    Column(
        Modifier
            .fillMaxWidth()
            .clip(shape)
            .background(Palette.PanelHigh)
            .border(1.dp, Palette.Stroke, shape)
            .padding(12.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp),
    ) {
        Text(p.name, maxLines = 1, overflow = TextOverflow.Ellipsis, fontWeight = FontWeight.Bold, color = Palette.Accent)
        Text(
            "${p.parts} ชิ้นส่วน · ${p.frames} เฟรม\n$date",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            PillButton("โหลด", enabled = enabled, style = PillStyle.PRIMARY, modifier = Modifier.weight(1f), onClick = onLoad)
            PillButton("ลบเซฟ", enabled = enabled, style = PillStyle.DANGER, modifier = Modifier.weight(1f), onClick = onDelete)
        }
    }
}

/** ตั้งขนาดวิดีโอ [ความสูง] × [ความยาว] (px): เปลี่ยนแล้วเส้นประสีฟ้าบนผืนผ้าใบเปลี่ยนตามทันที และเป็นค่าเริ่มต้นตอนส่งออกวิดีโอ */
@Composable
private fun VideoSizeSetting(vm: EditorViewModel) {
    val shape = RoundedCornerShape(16.dp)
    Column(
        Modifier
            .fillMaxWidth()
            .clip(shape)
            .background(Palette.PanelHigh)
            .border(1.dp, Palette.Stroke, shape)
            .padding(12.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp),
    ) {
        Text("ขนาดวิดีโอ", fontWeight = FontWeight.Bold, color = Palette.Accent)
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            SizeField("ความสูง", vm.videoHeight, Modifier.weight(1f)) { vm.videoHeight = it }
            Text("×", fontSize = 20.sp, color = NormalFg)
            SizeField("ความยาว", vm.videoWidth, Modifier.weight(1f)) { vm.videoWidth = it }
        }
        Text(
            "หน่วย px ใส่ได้ 64–1920 · เส้นประสีฟ้าบนผืนผ้าใบเปลี่ยนตามทันที · ตอนส่งออกจะปัดเป็นพหุคูณของ 16",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
    }
}

/** ช่องใส่ขนาด (px) ใช้ค่าใหม่ทันทีที่พิมพ์ถูกช่วง 64–1920 (พิมพ์ยังไม่ครบ/นอกช่วง = ขึ้นสีแดงและยังใช้ค่าเดิมอยู่) */
@Composable
private fun SizeField(label: String, value: Int, modifier: Modifier, onValid: (Int) -> Unit) {
    var text by remember(value) { mutableStateOf(value.toString()) }
    OutlinedTextField(
        value = text,
        onValueChange = { raw ->
            val digits = raw.filter { it.isDigit() }.take(4)
            text = digits
            val n = digits.toIntOrNull()
            if (n != null && n in 64..1920) onValid(n)
        },
        modifier = modifier,
        label = { Text(label) },
        singleLine = true,
        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
        isError = text.toIntOrNull()?.let { it !in 64..1920 } ?: true,
    )
}

/**
 * แก้ไขเฟรม: ตั้งความเร็วเล่นเฉพาะช่วงเฟรม "จากเฟรมที่เลือก ถึง เลขที่ใส่" ช่วงนั้นเล่นตามความเร็วที่ใส่แทนความเร็วปกติ
 * ตั้งทับช่วงที่มีอยู่แล้วไม่ได้ (ต้องรีเซ็ตช่วงเดิมก่อน) · รีเซ็ต = ล้างช่วงที่เฟรมที่เลือกอยู่ให้กลับไปใช้ความเร็วปกติ
 */
@Composable
private fun FrameSpeedDialog(vm: EditorViewModel, onDismiss: () -> Unit) {
    val project = vm.project
    val from = remember { vm.currentFrame } // เฟรมที่เลือกตอนเปิดหน้าต่าง (เริ่มที่ 0)
    val fromN = from + 1
    var toText by remember { mutableStateOf("") }
    var fpsText by remember { mutableStateOf(fmtFps(vm.fps)) }
    val here = project.rangeAt(from)
    val toN = toText.toIntOrNull()
    val fpsN = fpsText.toFloatOrNull()
    val error = project.speedRangeError(fromN, toN, fpsN)
    val showError = error != null && (toText.isNotEmpty() || here != null)
    val card = RoundedCornerShape(14.dp)
    val pill = RoundedCornerShape(50)
    val dim = MaterialTheme.colorScheme.onSurfaceVariant
    var pickDelete by remember { mutableStateOf(false) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("แก้ไขเฟรม") },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Text("จัดการเฟรม $fromN", fontWeight = FontWeight.Bold, color = Palette.Accent)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    PillButton("คัดลอกเฟรม", onClick = {
                        vm.copyFrame(from)
                        vm.message = "คัดลอกเฟรม $fromN แล้ว (เลือกเฟรมที่ต้องการ แล้วกด แก้ไขเฟรม > วางเฟรม)"
                        onDismiss()
                    })
                    PillButton("วางเฟรม", enabled = vm.frameClipboard != null, onClick = {
                        vm.pasteFrameAfter(from)
                        vm.message = "วางเฟรม ${vm.frameClipboardFrom} ต่อจากเฟรม $fromN แล้ว (เป็นเฟรม ${fromN + 1})"
                        onDismiss()
                    })
                }
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    PillButton("ล้างเฟรม", style = PillStyle.DANGER, onClick = {
                        vm.clearFrame()
                        vm.message = "ล้างท่าของเฟรม $fromN แล้ว"
                        onDismiss()
                    })
                    PillButton("ลบเฟรม", enabled = project.frameCount > 1, style = PillStyle.DANGER, onClick = { pickDelete = true })
                }
                if (vm.frameClipboard != null) {
                    Text("คัดลอกไว้: เฟรม ${vm.frameClipboardFrom}", style = MaterialTheme.typography.bodySmall, color = dim)
                }
                Text(
                    "ช่วงเฟรมที่ตั้งไว้จะเล่นตามความเร็วที่ใส่ แทนความเร็วปกติ (${fmtFps(vm.fps)} fps)",
                    style = MaterialTheme.typography.bodySmall,
                    color = dim,
                )
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    Box(
                        Modifier
                            .clip(pill)
                            .background(TonalBg)
                            .border(1.dp, Palette.Accent, pill)
                            .padding(horizontal = 16.dp, vertical = 12.dp),
                        contentAlignment = Alignment.Center,
                    ) { Text("เฟรม $fromN", color = TonalFg, fontWeight = FontWeight.Bold) }
                    Text("ถึง", color = NormalFg)
                    OutlinedTextField(
                        value = toText,
                        onValueChange = { toText = it.filter { c -> c.isDigit() }.take(4) },
                        modifier = Modifier.weight(1f),
                        singleLine = true,
                        label = { Text("เลขเฟรม") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    )
                }
                OutlinedTextField(
                    value = fpsText,
                    onValueChange = { fpsText = cleanFpsText(it) },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true,
                    label = { Text("ความเร็ว (fps)") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                    isError = fpsN?.let { it !in FPS_MIN..FPS_MAX } ?: true,
                )
                if (error == null && toN != null && fpsN != null) {
                    val n = toN - fromN + 1
                    val secs = String.format(java.util.Locale.US, "%.2f", n.toFloat() / fpsN)
                    Text(
                        "เฟรม $fromN–$toN · $n เฟรม · ใช้เวลา $secs วินาที",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.primary,
                    )
                } else if (error != null && showError) {
                    Box(Modifier.fillMaxWidth().clip(card).background(Color(0x33FF8A80)).padding(10.dp)) {
                        Text(error, style = MaterialTheme.typography.bodySmall, color = Color(0xFFFF8A80))
                    }
                }
                if (project.speedRanges.isNotEmpty()) {
                    Text("ช่วงที่ตั้งความเร็วไว้แล้ว", fontWeight = FontWeight.Bold, color = Palette.Accent)
                    for (r in project.speedRanges.sortedBy { it.start }) {
                        val mine = r == here
                        Row(
                            Modifier
                                .fillMaxWidth()
                                .clip(card)
                                .background(if (mine) TonalBg else Palette.PanelHigh)
                                .border(1.dp, if (mine) Palette.Accent else Palette.Stroke, card)
                                .padding(horizontal = 12.dp, vertical = 8.dp),
                            verticalAlignment = Alignment.CenterVertically,
                        ) {
                            Text("เฟรม ${r.start + 1}–${r.end + 1}", Modifier.weight(1f), color = if (mine) TonalFg else NormalFg)
                            Text("${fmtFps(r.fps)} fps", color = Palette.Accent, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        },
        confirmButton = {
            PillButton("ตกลง", enabled = error == null, style = PillStyle.PRIMARY, onClick = {
                val t = toN
                val f = fpsN
                if (error == null && t != null && f != null) {
                    vm.addSpeedRange(fromN, t, f)
                    vm.message = "ตั้งความเร็วเฟรม $fromN–$t = ${fmtFps(f)} fps แล้ว"
                    onDismiss()
                }
            })
        },
        dismissButton = {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                PillButton("รีเซ็ต", enabled = here != null, style = PillStyle.DANGER, onClick = {
                    here?.let {
                        vm.removeSpeedRange(it)
                        vm.message = "รีเซ็ตเฟรม ${it.start + 1}–${it.end + 1} กลับเป็นความเร็วปกติ (${fmtFps(vm.fps)} fps) แล้ว"
                        onDismiss()
                    }
                })
                PillButton("ปิด", onClick = onDismiss)
            }
        },
    )
    if (pickDelete) {
        DeleteFramePicker(vm, initial = from, onCancel = { pickDelete = false }, onDeleted = { pickDelete = false; onDismiss() })
    }
}

/**
 * เลือกเฟรมที่จะลบ: แตะเลขเฟรมเพื่อเลือก/ยกเลิก (เลือกได้หลายเฟรม) แล้วกด "ลบที่เลือก"
 * มีปุ่ม เลือกทั้งหมด / ล้างที่เลือก และ "ลบทั้งหมด" (เหลือ 1 เฟรมว่าง; ตัวละครและกระดูกไม่หาย)
 */
@Composable
private fun DeleteFramePicker(vm: EditorViewModel, initial: Int, onCancel: () -> Unit, onDeleted: () -> Unit) {
    var picked by remember { mutableStateOf(setOf(initial)) }
    var confirmAll by remember { mutableStateOf(false) }
    val total = vm.project.frameCount
    val count = picked.count { it in 0 until total }

    AlertDialog(
        onDismissRequest = onCancel,
        title = { Text("ลบเฟรม") },
        text = {
            Column(
                Modifier.heightIn(max = 380.dp).verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                Text(
                    "แตะเลขเฟรมที่จะลบ เลือกได้หลายเฟรม (เฟรมหลังจากนั้นเลื่อนขึ้นมาแทน ย้อนกลับไม่ได้)",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    PillButton("เลือกทั้งหมด", modifier = Modifier.weight(1f), onClick = { picked = (0 until total).toSet() })
                    PillButton("ล้างที่เลือก", modifier = Modifier.weight(1f), enabled = picked.isNotEmpty(), onClick = { picked = emptySet() })
                }
                for (row in (0 until total).chunked(5)) {
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        for (i in row) {
                            FrameChip(i + 1, i in picked, custom = vm.project.rangeAt(i) != null) {
                                picked = if (i in picked) picked - i else picked + i
                            }
                        }
                    }
                }
                Text("เลือกอยู่ $count จาก $total เฟรม", color = MaterialTheme.colorScheme.primary)
                PillButton("ลบทั้งหมด", style = PillStyle.DANGER, modifier = Modifier.fillMaxWidth(), onClick = { confirmAll = true })
            }
        },
        confirmButton = {
            PillButton("ลบที่เลือก ($count)", style = PillStyle.DANGER, enabled = count > 0, onClick = {
                val sel = picked.filter { it in 0 until total }.sorted()
                val n = vm.deleteFrames(sel.toSet())
                vm.message = when {
                    n <= 0 -> "ลบไม่ได้"
                    n >= total -> "ลบเฟรมทั้งหมดแล้ว (เหลือ 1 เฟรมว่าง)"
                    else -> "ลบ $n เฟรมแล้ว (เฟรม ${sel.joinToString(", ") { (it + 1).toString() }})"
                }
                onDeleted()
            })
        },
        dismissButton = { PillButton("ยกเลิก", onClick = onCancel) },
    )

    if (confirmAll) {
        AlertDialog(
            onDismissRequest = { confirmAll = false },
            title = { Text("ลบเฟรมทั้งหมด?") },
            text = { Text("ท่าและช่วงความเร็วของทุกเฟรมจะถูกลบ เหลือ 1 เฟรมว่าง (ตัวละครและกระดูกไม่หาย) ย้อนกลับไม่ได้") },
            confirmButton = {
                PillButton("ลบทั้งหมด", style = PillStyle.DANGER, onClick = {
                    vm.deleteAllFrames()
                    vm.message = "ลบเฟรมทั้งหมดแล้ว (เหลือ 1 เฟรมว่าง)"
                    confirmAll = false
                    onDeleted()
                })
            },
            dismissButton = { PillButton("ยกเลิก", onClick = { confirmAll = false }) },
        )
    }
}

/** รายการตัวละครที่เซฟไว้ในแอป (เซฟจากเมนูกระดูก) แตะเพื่อโหลดเข้าฉากแอนิเมต */
@Composable
private fun LoadCharacterDialog(vm: EditorViewModel, onDismiss: () -> Unit) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var saved by remember { mutableStateOf<List<SavedCharacter>?>(null) }
    var busy by remember { mutableStateOf(false) }
    var pending by remember { mutableStateOf<String?>(null) } // ตัวละครที่เลือกแล้ว รอเลือกช่วงเฟรมที่จะแสดง
    val from = remember { vm.currentFrame } // เฟรมที่เปิดอยู่ตอนกดโหลด (เริ่มที่ 0): ตัวละครเริ่มแสดงจากเฟรมนี้

    LaunchedEffect(Unit) {
        saved = runCatching { withContext(Dispatchers.IO) { CharacterStore.list(context) } }.getOrDefault(emptyList())
    }

    fun load(name: String, to: Int) { // to = เฟรมสุดท้ายที่แสดง (เริ่มที่ 0) หรือ -1 = จนจบ
        busy = true
        scope.launch {
            val r = runCatching {
                withContext(Dispatchers.IO) { CharacterToParts.prepare(CharacterStore.load(context, name)) }
            }
            busy = false
            r.onSuccess { built ->
                vm.loadCharacter(built, name, from, to)
                vm.message = when {
                    from == 0 && to < 0 -> "เพิ่มตัวละคร \"$name\" เข้าฉากแล้ว"
                    to < 0 -> "เพิ่มตัวละคร \"$name\" แล้ว แสดงตั้งแต่เฟรม ${from + 1} จนจบ"
                    else -> "เพิ่มตัวละคร \"$name\" แล้ว แสดงเฟรม ${from + 1}–${to + 1}"
                }
                onDismiss()
            }.onFailure {
                vm.message = "โหลดไม่สำเร็จ: ${it.message ?: it.javaClass.simpleName}"
            }
        }
    }

    pending?.let { name ->
        CharacterRangeDialog(
            name = name, from = from, total = vm.project.frameCount, busy = busy,
            onConfirm = { to -> load(name, to) },
            onBack = { pending = null },
        )
        return
    }

    AlertDialog(
        onDismissRequest = { if (!busy) onDismiss() },
        title = { Text("โหลดตัวละคร") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                val list = saved
                when {
                    list == null -> Text("กำลังอ่านรายการ...")
                    list.isEmpty() -> Text(
                        "ยังไม่มีตัวละครที่บันทึกไว้\nไปที่เมนู \"กระดูก\" สร้างตัวละคร แล้วกด \"เซฟตัวละคร\"",
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                    else -> LazyColumn(
                        Modifier.heightIn(max = 320.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp),
                    ) {
                        items(list, key = { it.name }) { c ->
                            CharacterRow(c, enabled = !busy, actionLabel = "เลือก") {
                                pending = c.name
                            }
                        }
                    }
                }
                if (busy) Text("กำลังโหลด...", color = MaterialTheme.colorScheme.primary)
            }
        },
        confirmButton = { TextButton(enabled = !busy, onClick = onDismiss) { Text("ปิด") } },
    )

}

/**
 * เลือกช่วงเฟรมที่ตัวละครจะแสดง หลังเลือกตัวละครจากรายการ: เริ่มที่เฟรมที่เปิดอยู่ ถึง "จนจบ" หรือเฟรมที่เลือก
 * (แตะช่องเฟรมในแถบด้านล่าง หรือพิมพ์เลขเฟรมก็ได้) เฟรมนอกช่วงจะไม่มีตัวละครนี้
 */
@Composable
private fun CharacterRangeDialog(name: String, from: Int, total: Int, busy: Boolean, onConfirm: (Int) -> Unit, onBack: () -> Unit) {
    val fromN = from + 1
    var toEnd by remember { mutableStateOf(true) }
    var toText by remember { mutableStateOf("") }
    val toN = toText.toIntOrNull()
    val error = when {
        toEnd -> null
        toN == null -> "ใส่เลขเฟรมที่จะให้ตัวละครแสดงถึง"
        toN < fromN -> "เลขเฟรมต้องไม่น้อยกว่า $fromN"
        toN > total -> "มีแค่ $total เฟรม"
        else -> null
    }
    val endN = if (toEnd) total else (toN ?: fromN).coerceIn(fromN, total)
    val card = RoundedCornerShape(14.dp)
    val pill = RoundedCornerShape(50)
    val dim = MaterialTheme.colorScheme.onSurfaceVariant
    val strip = rememberLazyListState()
    LaunchedEffect(Unit) { strip.scrollToItem((from - 1).coerceAtLeast(0)) } // เลื่อนแถบเฟรมให้เห็นเฟรมเริ่มต้น

    AlertDialog(
        onDismissRequest = { if (!busy) onBack() },
        title = { Text("เพิ่มตัวละคร") },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Box(Modifier.fillMaxWidth().clip(card).background(Palette.PanelHigh).border(1.dp, Palette.Stroke, card).padding(12.dp)) {
                    Text(name, fontWeight = FontWeight.Bold, color = Palette.Accent, maxLines = 1, overflow = TextOverflow.Ellipsis)
                }
                Text("ให้ตัวละครแสดงในเฟรมไหนบ้าง (เฟรมนอกช่วงจะไม่มีตัวละครนี้)", style = MaterialTheme.typography.bodySmall, color = dim)
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    Box(
                        Modifier.clip(pill).background(TonalBg).border(1.dp, Palette.Accent, pill).padding(horizontal = 16.dp, vertical = 12.dp),
                        contentAlignment = Alignment.Center,
                    ) { Text("เฟรม $fromN", color = TonalFg, fontWeight = FontWeight.Bold) }
                    Text("ถึง", color = NormalFg)
                }
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Chip("จนจบ", selected = toEnd, enabled = !busy) { toEnd = true }
                    Chip("เลือกเฟรม", selected = !toEnd, enabled = !busy) { toEnd = false }
                }
                if (!toEnd) {
                    OutlinedTextField(
                        value = toText,
                        onValueChange = { toText = it.filter { c -> c.isDigit() }.take(4) },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true,
                        enabled = !busy,
                        label = { Text("ถึงเฟรมที่ (1–$total)") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        isError = error != null && toText.isNotEmpty(),
                    )
                }
                // แถบเฟรม: ช่วงที่ตัวละครแสดงเป็นสีม่วง (แตะเฟรมไหนก็ได้ที่อยู่หลังเฟรมเริ่ม เพื่อกำหนดเฟรมจบ)
                LazyRow(state = strip, horizontalArrangement = Arrangement.spacedBy(6.dp), modifier = Modifier.fillMaxWidth()) {
                    items(count = total) { i ->
                        val n = i + 1
                        val inRange = n in fromN..endN
                        val cell = RoundedCornerShape(10.dp)
                        Box(
                            Modifier
                                .size(38.dp)
                                .alpha(if (n < fromN) 0.35f else 1f)
                                .clip(cell)
                                .background(if (inRange) TonalBg else Palette.PanelHigh)
                                .border(1.dp, if (inRange) Palette.Accent else Palette.Stroke, cell)
                                .clickable(enabled = !busy && n >= fromN) { toEnd = false; toText = n.toString() },
                            contentAlignment = Alignment.Center,
                        ) { Text("$n", color = if (inRange) TonalFg else NormalFg, fontSize = 13.sp, fontWeight = if (inRange) FontWeight.Bold else FontWeight.Normal) }
                    }
                }
                if (error != null && !toEnd && toText.isNotEmpty()) {
                    Box(Modifier.fillMaxWidth().clip(card).background(Color(0x33FF8A80)).padding(10.dp)) {
                        Text(error, style = MaterialTheme.typography.bodySmall, color = Color(0xFFFF8A80))
                    }
                } else if (error == null) {
                    val n = endN - fromN + 1
                    val head = if (toEnd) "แสดงตั้งแต่เฟรม $fromN จนจบ (รวมเฟรมที่เพิ่มทีหลัง)" else "แสดงเฟรม $fromN–$endN · $n เฟรม"
                    Text(head, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.primary)
                    if (from > 0) Text("เฟรม 1–$from จะไม่มีตัวละครนี้", style = MaterialTheme.typography.bodySmall, color = dim)
                }
                if (busy) Text("กำลังโหลด...", color = MaterialTheme.colorScheme.primary)
            }
        },
        confirmButton = {
            PillButton("เพิ่มตัวละคร", enabled = error == null && !busy, style = PillStyle.PRIMARY, onClick = {
                val t = toN
                if (toEnd) onConfirm(-1) else if (t != null) onConfirm(t - 1)
            })
        },
        dismissButton = { PillButton("ย้อนกลับ", enabled = !busy, onClick = onBack) },
    )
}

@Composable
private fun CharacterRow(c: SavedCharacter, enabled: Boolean, actionLabel: String = "โหลด", onClick: () -> Unit) {
    val date = remember(c.savedAt) {
        java.text.DateFormat.getDateTimeInstance(java.text.DateFormat.MEDIUM, java.text.DateFormat.SHORT)
            .format(java.util.Date(c.savedAt))
    }
    Row(
        Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(14.dp))
            .background(Palette.PanelHigh)
            .clickable(enabled = enabled, onClick = onClick)
            .padding(horizontal = 14.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Column(Modifier.weight(1f)) {
            Text(c.name, maxLines = 1, overflow = TextOverflow.Ellipsis, fontWeight = FontWeight.Bold)
            Text(date, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        Text(actionLabel, color = MaterialTheme.colorScheme.primary)
    }
}

@Composable
private fun Timeline(vm: EditorViewModel) {
    val listState = rememberLazyListState()
    LaunchedEffect(vm.project.frameCount) { listState.animateScrollToItem(vm.project.frameCount) } // เลื่อนไปที่ปุ่ม + เมื่อเพิ่มเฟรม
    if (vm.mode != Mode.ANIMATE) {
        Text(
            "สลับไปโหมดแอนิเมตเพื่อใช้ไทม์ไลน์",
            Modifier.padding(horizontal = 12.dp, vertical = 4.dp),
            style = MaterialTheme.typography.bodySmall,
        )
        return
    }
    LazyRow(
        Modifier.fillMaxWidth(),
        state = listState,
        contentPadding = PaddingValues(horizontal = 12.dp),
        horizontalArrangement = Arrangement.spacedBy(8.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        items(vm.project.frameCount) { i ->
            FrameChip(i + 1, vm.currentFrame == i, custom = vm.project.rangeAt(i) != null) {
                if (!vm.playing) {
                    vm.currentFrame = i
                    vm.playhead = i.toFloat()
                }
            }
        }
        item { AddFrameButton(enabled = !vm.playing) { vm.addFrame() } }
    }
    PanelDivider()
    // แถวควบคุมการเล่น: เล่น/พัก (กว้างสุด) · หยุด · วนซ้ำ · ความเร็ว (พอดีจอ ไม่ต้องเลื่อน)
    Row(
        Modifier.fillMaxWidth().padding(horizontal = 12.dp),
        horizontalArrangement = Arrangement.spacedBy(8.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        PillButton(
            if (vm.playing) "⏸ พัก" else "▶ เล่น",
            onClick = { vm.togglePlay() },
            modifier = Modifier.weight(1f),
            style = PillStyle.PRIMARY,
        )
        RoundIconButton("หยุด", selected = false, onClick = { vm.stop() }) { color ->
            val side = size.minDimension * 0.34f
            drawRoundRect(
                color,
                topLeft = Offset(center.x - side / 2f, center.y - side / 2f),
                size = Size(side, side),
                cornerRadius = CornerRadius(side * 0.18f),
            )
        }
        RoundIconButton("วนซ้ำ", selected = vm.loop, onClick = { vm.loop = !vm.loop }) { color ->
            // ลูกศรวนกลับ: ส่วนโค้งเกือบเต็มวง + หัวลูกศรสามเหลี่ยมที่ปลายโค้ง
            val r = size.minDimension * 0.26f
            val startDeg = -50f
            val sweepDeg = 280f
            drawArc(
                color,
                startAngle = startDeg,
                sweepAngle = sweepDeg,
                useCenter = false,
                topLeft = Offset(center.x - r, center.y - r),
                size = Size(r * 2f, r * 2f),
                style = Stroke(width = size.minDimension * 0.085f, cap = StrokeCap.Round),
            )
            val th = Math.toRadians((startDeg + sweepDeg).toDouble())
            val px = center.x + r * cos(th).toFloat()
            val py = center.y + r * sin(th).toFloat()
            val tx = (-sin(th)).toFloat() // ทิศการเดินของโค้ด (ตามเข็ม)
            val ty = cos(th).toFloat()
            val nx = cos(th).toFloat() // ทิศตั้งฉากกับโค้ด (ออกจากศูนย์กลาง)
            val ny = sin(th).toFloat()
            val head = size.minDimension * 0.17f
            val arrow = Path().apply {
                moveTo(px + tx * head * 0.9f, py + ty * head * 0.9f)
                lineTo(px - tx * head * 0.2f + nx * head * 0.8f, py - ty * head * 0.2f + ny * head * 0.8f)
                lineTo(px - tx * head * 0.2f - nx * head * 0.8f, py - ty * head * 0.2f - ny * head * 0.8f)
                close()
            }
            drawPath(arrow, color)
        }
        FpsField(vm)
    }
}

/** เส้นคั่นบางๆ ระหว่างส่วนในแผงล่าง */
@Composable
private fun PanelDivider() {
    Box(Modifier.fillMaxWidth().padding(horizontal = 14.dp).height(1.dp).background(Palette.Stroke))
}

/** ปุ่มไอคอนกลม 44dp (วาดไอคอนเองด้วย Canvas ไม่พึ่งอีโมจิ/ฟอนต์) selected = ไฮไลต์เป็นสีม่วง */
@Composable
private fun RoundIconButton(
    description: String,
    selected: Boolean,
    onClick: () -> Unit,
    enabled: Boolean = true,
    icon: androidx.compose.ui.graphics.drawscope.DrawScope.(Color) -> Unit,
) {
    val fg = if (selected) Palette.Accent else Color(0xFFE7E3EE)
    Box(
        Modifier
            .size(44.dp)
            .alpha(if (enabled) 1f else 0.38f)
            .clip(CircleShape)
            .background(if (selected) TonalBg else Palette.PanelHigh)
            .border(1.dp, if (selected) Palette.Accent else Palette.Stroke, CircleShape)
            .clickable(enabled = enabled, onClick = onClick)
            .semantics { contentDescription = description },
        contentAlignment = Alignment.Center,
    ) {
        Canvas(Modifier.size(44.dp)) { icon(fg) }
    }
}

/** ไอคอนลูกศรวนกลับ: redo = false ย้อนกลับ (↶), redo = true ทำซ้ำ (↷) วาดด้วย Canvas สไตล์เดียวกับปุ่มวนซ้ำ */
private fun DrawScope.drawUndoRedoIcon(color: Color, redo: Boolean) {
    val r = size.minDimension * 0.24f
    val sx = if (redo) -1f else 1f // redo = กลับด้านซ้าย-ขวา
    val startDeg = 200.0 // ปลายลูกศรอยู่ด้านซ้ายบนของวง (กลับด้านเมื่อ redo)
    val sweep = 250f
    drawArc(
        color,
        startAngle = if (redo) (180f - startDeg.toFloat()) else startDeg.toFloat(),
        sweepAngle = if (redo) -sweep else sweep,
        useCenter = false,
        topLeft = Offset(center.x - r, center.y - r),
        size = Size(r * 2f, r * 2f),
        style = Stroke(width = size.minDimension * 0.085f, cap = StrokeCap.Round),
    )
    val th = Math.toRadians(startDeg)
    val px = center.x + sx * r * cos(th).toFloat()
    val py = center.y + r * sin(th).toFloat()
    val dx = sx * sin(th).toFloat() // ทิศหัวลูกศร = ย้อนกลับไปทางที่เส้นโค้งเริ่ม
    val dy = -cos(th).toFloat()
    val nx = -dy
    val ny = dx
    val head = size.minDimension * 0.17f
    val arrow = Path().apply {
        moveTo(px + dx * head * 0.9f, py + dy * head * 0.9f)
        lineTo(px - dx * head * 0.2f + nx * head * 0.8f, py - dy * head * 0.2f + ny * head * 0.8f)
        lineTo(px - dx * head * 0.2f - nx * head * 0.8f, py - dy * head * 0.2f - ny * head * 0.8f)
        close()
    }
    drawPath(arrow, color)
}

/** ช่องใส่ความเร็วเฟรม (fps) ใส่เลขทศนิยมได้ 0.1–240 เปลี่ยนค่าทันทีที่พิมพ์ถูกช่วง (กล่องกะทัดรัด ขอบแดงเมื่อค่าไม่ถูกช่วง) */
@Composable
private fun FpsField(vm: EditorViewModel) {
    var text by remember { mutableStateOf(fmtFps(vm.fps)) }
    // ค่าเปลี่ยนจากข้างนอก (ย้อนกลับ/โหลดไฟล์) ค่อยอัปเดตข้อความ; ระหว่างพิมพ์ (เช่น "7." ที่ยังไม่จบ) ห้ามรีเซ็ต ไม่งั้นจุดหาย
    LaunchedEffect(vm.fps) { if (text.toFloatOrNull() != vm.fps) text = fmtFps(vm.fps) }
    val invalid = text.toFloatOrNull()?.let { it !in FPS_MIN..FPS_MAX } ?: true
    val shape = RoundedCornerShape(22.dp)
    val muted = Color(0xFFC9C4D4)
    Column(
        Modifier
            .heightIn(min = 44.dp)
            .clip(shape)
            .background(Palette.PanelHigh)
            .border(1.dp, if (invalid) Color(0xFFFF8A80) else Palette.Stroke, shape)
            .padding(horizontal = 12.dp, vertical = 3.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center,
    ) {
        Text("ความเร็ว", color = muted, fontSize = 11.sp)
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(3.dp)) {
            BasicTextField(
                value = text,
                onValueChange = { raw ->
                    val clean = cleanFpsText(raw)
                    text = clean
                    val n = clean.toFloatOrNull()
                    if (n != null && n in FPS_MIN..FPS_MAX) vm.fps = n
                },
                singleLine = true,
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                textStyle = TextStyle(
                    color = if (invalid) Color(0xFFFF8A80) else Color(0xFFE7E3EE),
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Bold,
                    textAlign = TextAlign.Center,
                ),
                cursorBrush = SolidColor(Palette.Accent),
                modifier = Modifier.width(52.dp), // กว้างขึ้นให้พอดีเลขทศนิยม เช่น 12.5
            )
            Text("fps", color = muted, fontSize = 11.sp)
        }
    }
}

private enum class ExportKind { IMAGE, VIDEO, ANIM }

/** ส่งออก: เลือกก่อนว่าจะเป็นรูป (Sprite Sheet) ภาพเคลื่อนไหว (GIF / APNG โปร่งใสได้) หรือวิดีโอ (MP4) */
@Composable
private fun ExportDialog(vm: EditorViewModel, onDismiss: () -> Unit) {
    var kind by remember { mutableStateOf<ExportKind?>(null) }
    // มีงานค้างอยู่ = โชว์ความคืบหน้าของงานนั้นเลย (วิดีโอ หรือ ภาพเคลื่อนไหว)
    val shown = if (ExportJob.running) (if (ExportJob.format == ExportFormat.MP4) ExportKind.VIDEO else ExportKind.ANIM) else kind
    when (shown) {
        ExportKind.IMAGE -> ImageExportDialog(vm, onDismiss)
        ExportKind.VIDEO -> VideoExportDialog(vm, onDismiss)
        ExportKind.ANIM -> AnimExportDialog(vm, onDismiss)
        null -> AlertDialog(
            onDismissRequest = onDismiss,
            title = { Text("ส่งออกเป็น") },
            text = {
                Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    ExportChoiceCard("🖼", "รูป", "Sprite Sheet (PNG พื้นหลังโปร่งใส) รวมทุกเฟรมในรูปเดียว") { kind = ExportKind.IMAGE }
                    ExportChoiceCard("✨", "ภาพเคลื่อนไหว", "GIF หรือ PNG เคลื่อนไหว (APNG) เลือกพื้นหลังโปร่งใส/ไม่มีพื้นหลังได้") { kind = ExportKind.ANIM }
                    ExportChoiceCard("🎬", "วิดีโอ", "ไฟล์ MP4 เล่นแอนิเมชันตามความเร็วเฟรม (เลือกสีพื้นหลังได้)") { kind = ExportKind.VIDEO }
                }
            },
            confirmButton = { TextButton(onClick = onDismiss) { Text("ยกเลิก") } },
        )
    }
}

@Composable
private fun ExportChoiceCard(icon: String, title: String, desc: String, onClick: () -> Unit) {
    val shape = RoundedCornerShape(16.dp)
    Row(
        Modifier
            .fillMaxWidth()
            .clip(shape)
            .background(Palette.PanelHigh)
            .border(1.dp, Palette.Stroke, shape)
            .clickable(onClick = onClick)
            .padding(14.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(14.dp),
    ) {
        Text(icon, fontSize = 30.sp)
        Column(Modifier.weight(1f)) {
            Text(title, fontWeight = FontWeight.Bold, color = Palette.Accent)
            Text(desc, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}

// ---------- ส่งออกภาพเคลื่อนไหว (GIF / APNG) ----------

/** ลายตารางหมากรุกบอกว่า "โปร่งใส" (เหมือนโปรแกรมแต่งภาพ) */
@Composable
private fun Checkerboard(modifier: Modifier = Modifier, cell: Float = 16f) {
    Canvas(modifier) {
        val light = Color(0xFF4A4A56)
        val dark = Color(0xFF34343E)
        drawRect(light)
        var row = 0
        var y = 0f
        while (y < size.height) {
            var col = 0
            var x = 0f
            while (x < size.width) {
                if ((row + col) % 2 == 1) {
                    drawRect(dark, Offset(x, y), Size(minOf(cell, size.width - x), minOf(cell, size.height - y)))
                }
                x += cell
                col++
            }
            y += cell
            row++
        }
    }
}

@Composable
private fun SectionLabel(text: String) {
    Text(text, color = Palette.Accent, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.labelLarge)
}

/** การ์ดใหญ่เลือกฟอร์แมต (จุดวงกลมบอกว่าเลือกอยู่) */
@Composable
private fun FormatCard(title: String, tag: String, desc: String, selected: Boolean, enabled: Boolean, onClick: () -> Unit) {
    val shape = RoundedCornerShape(16.dp)
    Row(
        Modifier
            .fillMaxWidth()
            .alpha(if (enabled) 1f else 0.5f)
            .clip(shape)
            .background(if (selected) TonalBg else Palette.PanelHigh)
            .border(if (selected) 2.dp else 1.dp, if (selected) Palette.Accent else Palette.Stroke, shape)
            .clickable(enabled = enabled, onClick = onClick)
            .padding(14.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        Box(
            Modifier.size(22.dp).clip(CircleShape).border(2.dp, if (selected) Palette.Accent else Palette.Stroke, CircleShape),
            contentAlignment = Alignment.Center,
        ) {
            if (selected) Box(Modifier.size(10.dp).clip(CircleShape).background(Palette.Accent))
        }
        Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(2.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(title, fontWeight = FontWeight.Bold, color = if (selected) TonalFg else Palette.Accent)
                Text(tag, style = MaterialTheme.typography.labelSmall, color = Color(0xFF69F0AE))
            }
            Text(desc, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}

/** ชิปเลือกสีพื้นหลัง: มีวงสีตัวอย่างนำหน้า (โปร่งใส = ลายหมากรุก) */
@Composable
private fun SwatchChip(label: String, selected: Boolean, enabled: Boolean, swatch: @Composable () -> Unit, onClick: () -> Unit) {
    val shape = RoundedCornerShape(50)
    Row(
        Modifier
            .heightIn(min = 44.dp)
            .alpha(if (enabled) 1f else 0.38f)
            .clip(shape)
            .background(if (selected) TonalBg else Palette.PanelHigh)
            .border(1.dp, if (selected) Palette.Accent else Palette.Stroke, shape)
            .clickable(enabled = enabled, onClick = onClick)
            .padding(start = 12.dp, end = 16.dp, top = 8.dp, bottom = 8.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(8.dp),
    ) {
        Box(Modifier.size(20.dp).clip(CircleShape).border(1.dp, Color(0x88FFFFFF), CircleShape)) { swatch() }
        Text(
            label,
            color = if (selected) TonalFg else Color(0xFFC9C4D4),
            fontWeight = if (selected) FontWeight.Bold else FontWeight.Normal,
        )
    }
}

/**
 * ส่งออกภาพเคลื่อนไหว: เลือกฟอร์แมต (GIF / APNG) ขนาด ความลื่น พื้นหลัง (โปร่งใส/ขาว/ดำ/เขียว) และจำนวนรอบวน
 * มีตัวอย่างแอนิเมชันเล่นวนบนลายหมากรุก (หรือสีพื้นที่เลือก) งานรันใน ExportService เหมือนวิดีโอ จึงทำต่อได้แม้ออกจากแอป
 */
@Composable
private fun AnimExportDialog(vm: EditorViewModel, onDismiss: () -> Unit) {
    val context = LocalContext.current
    val busy = ExportJob.running
    var format by remember { mutableStateOf(if (busy && ExportJob.format != ExportFormat.MP4) ExportJob.format else ExportFormat.GIF) }
    var side by remember { mutableIntStateOf(384) } // ด้านสั้นของภาพ (px)
    var fpsOut by remember { mutableIntStateOf(25) }
    var bg by remember { mutableIntStateOf(0) } // 0 = โปร่งใส
    var loops by remember { mutableIntStateOf(0) } // 0 = วนไม่จำกัด
    var error by remember { mutableStateOf<String?>(null) }
    var preview by remember { mutableStateOf<Exporter.PreviewAnim?>(null) }
    var previewIdx by remember { mutableIntStateOf(0) }

    val bgColors = listOf(0, 0xFFFFFFFF.toInt(), 0xFF000000.toInt(), 0xFF00B140.toInt())
    val bgNames = listOf("โปร่งใส", "ขาว", "ดำ", "เขียว")
    val loopOptions = listOf(0 to "วนไม่จำกัด", 1 to "รอบเดียว", 3 to "3 รอบ", 5 to "5 รอบ")

    val (outW, outH) = Exporter.animSize(side, vm.videoWidth, vm.videoHeight)
    val loopN = vm.project.loopCount()
    val frameTotal = Exporter.animPlayheads(loopN, fpsOut) { i -> vm.project.fpsAt(i, vm.fps) }.size

    // เรนเดอร์ตัวอย่างเล็กใหม่เมื่อเปลี่ยนความลื่น/ขนาด (พื้นหลังวาดซ้อนทีหลัง ไม่ต้องเรนเดอร์ใหม่)
    LaunchedEffect(fpsOut, side) {
        preview = null
        val parts = vm.project.parts.toList()
        if (parts.isEmpty()) return@LaunchedEffect
        val frames = vm.project.snapshotFrames()
        val fpsTable = List(frames.size) { i -> vm.project.fpsAt(i, vm.fps) } // อ่านบน main thread ก่อนส่งให้เธรดเบื้องหลัง
        val ln = vm.project.loopCount()
        val pathsNow = vm.project.paths.toList() // อ่านบน main thread ก่อนส่งให้เธรดเบื้องหลัง
        val (fw, fh) = Exporter.animSize(side, vm.videoWidth, vm.videoHeight)
        val outFpsNow = fpsOut
        preview = withContext(Dispatchers.Default) {
            runCatching { Exporter.renderPreview(parts, frames, ln, outFpsNow, fw, fh, 360, { i -> fpsTable[i] }, pathsNow) }.getOrNull()
        }
    }
    LaunchedEffect(preview) {
        val p = preview ?: return@LaunchedEffect
        previewIdx = 0
        while (p.frames.size > 1) {
            delay(p.frameMs)
            previewIdx = (previewIdx + 1) % p.frames.size
        }
    }

    fun start() {
        if (vm.project.parts.isEmpty()) {
            error = "ยังไม่มีชิ้นส่วนให้ส่งออก"
            return
        }
        val err = Exporter.validateAnim(outW, outH, frameTotal)
        if (err != null) {
            error = err
            return
        }
        error = null
        val parts = vm.project.parts.toList()
        val frames = vm.project.snapshotFrames()
        val fpsTable = List(frames.size) { i -> vm.project.fpsAt(i, vm.fps) } // ความเร็วรายเฟรม (รวมช่วงที่ตั้งเอง) อ่านบน main thread ก่อนส่งให้ service
        ExportJob.progress = "กำลังเริ่ม..."
        ExportJob.format = format
        ExportJob.running = true
        ExportJob.request = ExportJob.Request(
            parts, frames, outW, outH, vm.fps, loops, bgColors[bg], fpsTable, loopN,
            quality = 0, format = format, outFps = fpsOut,
            paths = vm.project.paths.toList(),
        )
        try {
            ContextCompat.startForegroundService(context, Intent(context, ExportService::class.java))
        } catch (e: Exception) {
            ExportJob.running = false
            ExportJob.request = null
            error = "เริ่มสร้างไฟล์เบื้องหลังไม่ได้: ${e.message ?: e.javaClass.simpleName}"
        }
    }

    AlertDialog(
        onDismissRequest = { if (!busy) onDismiss() },
        title = { Text("ส่งออกภาพเคลื่อนไหว") },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                // ตัวอย่าง: เล่นวนบนลายหมากรุก (โปร่งใส) หรือสีพื้นที่เลือก
                val previewShape = RoundedCornerShape(16.dp)
                Box(
                    Modifier.fillMaxWidth().height(190.dp).clip(previewShape).border(1.dp, Palette.Stroke, previewShape),
                    contentAlignment = Alignment.Center,
                ) {
                    if (bg == 0) Checkerboard(Modifier.matchParentSize()) else Box(Modifier.matchParentSize().background(Color(bgColors[bg])))
                    val p = preview
                    if (p != null && p.frames.isNotEmpty()) {
                        Image(
                            bitmap = p.frames[previewIdx.coerceIn(0, p.frames.size - 1)].asImageBitmap(),
                            contentDescription = "ตัวอย่างแอนิเมชัน",
                            contentScale = ContentScale.Fit,
                            modifier = Modifier.fillMaxSize().padding(8.dp),
                        )
                    } else {
                        Text(
                            if (vm.project.parts.isEmpty()) "ยังไม่มีตัวละคร" else "กำลังเตรียมตัวอย่าง...",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                    }
                }

                SectionLabel("ฟอร์แมต")
                FormatCard("GIF", "เปิดได้เกือบทุกแอป", "โปร่งใสแบบ 1 บิต (ขอบอาจหยาบเล็กน้อย) สีไม่เกิน 256 สี", format == ExportFormat.GIF, !busy) { format = ExportFormat.GIF }
                FormatCard("APNG", "โปร่งใสเต็ม ขอบเนียนคม", "PNG เคลื่อนไหว สีเต็ม แต่บางแอปอาจแสดงเป็นรูปนิ่งเฟรมแรก (ไม่แน่ใจว่าแอปไหนบ้าง ลองเปิดในเบราว์เซอร์)", format == ExportFormat.APNG, !busy) { format = ExportFormat.APNG }

                SectionLabel("พื้นหลัง")
                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    bgNames.forEachIndexed { i, n ->
                        SwatchChip(
                            label = n,
                            selected = bg == i,
                            enabled = !busy,
                            swatch = {
                                if (i == 0) Checkerboard(Modifier.fillMaxSize(), cell = 6f) else Box(Modifier.fillMaxSize().background(Color(bgColors[i])))
                            },
                            onClick = { bg = i },
                        )
                    }
                }

                SectionLabel("ขนาด (ด้านสั้น)")
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Exporter.ANIM_SIZES.forEach { n -> Chip("$n px", side == n, enabled = !busy) { side = n } }
                }

                SectionLabel("ความลื่น")
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Exporter.ANIM_FPS.forEach { n -> Chip("$n fps", fpsOut == n, enabled = !busy) { fpsOut = n } }
                }

                SectionLabel("จำนวนรอบที่วน")
                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    loopOptions.forEach { (n, label) -> Chip(label, loops == n, enabled = !busy) { loops = n } }
                }

                Text(
                    "ภาพ $outW×$outH px · $frameTotal เฟรม · ยาวรอบละ ${String.format(java.util.Locale.US, "%.1f", frameTotal / fpsOut.toFloat())} วินาที · ใช้ความเร็วเฟรมที่ตั้งไว้" +
                        (if (vm.project.speedRanges.isNotEmpty()) " (รวมช่วงที่ตั้งเอง)" else ""),
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
                if (bg == 0 && format == ExportFormat.GIF) {
                    Text(
                        "เคล็ดลับ: GIF โปร่งใสแล้วขอบอาจเห็นเป็นเหลี่ยมเล็กน้อย ถ้าต้องการขอบเนียนให้เลือก APNG หรือเลือกสีพื้นหลัง",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
                error?.let { Text(it, color = MaterialTheme.colorScheme.error) }
                if (busy) Text(ExportJob.progress, color = MaterialTheme.colorScheme.primary)
            }
        },
        confirmButton = { PillButton(if (busy) "กำลังสร้าง..." else "ส่งออก", enabled = !busy, style = PillStyle.PRIMARY, onClick = { start() }) },
        dismissButton = { PillButton("ปิด", enabled = !busy, onClick = onDismiss) },
    )
}

@Composable
private fun VideoExportDialog(vm: EditorViewModel, onDismiss: () -> Unit) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var w by remember { mutableStateOf(vm.videoWidth.toString()) } // ค่าเริ่มต้นมาจากขนาดวิดีโอในเมนูตั้งค่า
    var h by remember { mutableStateOf(vm.videoHeight.toString()) }
    var loops by remember { mutableStateOf("3") }
    var bg by remember { mutableIntStateOf(0) }
    var quality by remember { mutableIntStateOf(0) } // ความชัดวิดีโอ 0=มาตรฐาน 1=ชัด 2=ชัดมาก
    var error by remember { mutableStateOf<String?>(null) }
    val busy = ExportJob.running // งานรันใน ExportService ต่อได้แม้ออกจากแอป
    val progress = ExportJob.progress
    val bgColors = listOf(0xFFFFFFFF.toInt(), 0xFF000000.toInt(), 0xFF00B140.toInt())
    val bgNames = listOf("ขาว", "ดำ", "เขียว")

    fun start() {
        val fw = w.toIntOrNull()
        val fh = h.toIntOrNull()
        val lp = loops.toIntOrNull()
        val loopN = vm.project.loopCount()
        val perLoop = Exporter.videoPlayheads(loopN) { i -> vm.project.fpsAt(i, vm.fps) }.size
        val err = Exporter.validateVideo(fw, fh, lp, perLoop)
        if (err != null) {
            error = err
            return
        }
        if (vm.project.parts.isEmpty()) {
            error = "ยังไม่มีชิ้นส่วนให้ส่งออก"
            return
        }
        error = null
        val parts = vm.project.parts.toList()
        val frames = vm.project.snapshotFrames()
        val fps = vm.fps
        val fpsTable = List(frames.size) { i -> vm.project.fpsAt(i, fps) } // ความเร็วรายเฟรม (รวมช่วงที่ตั้งเอง) อ่านบน main thread ก่อนส่งให้ service
        val color = bgColors[bg]
        ExportJob.progress = "กำลังเริ่ม..."
        ExportJob.format = ExportFormat.MP4 // กันหน้าต่างส่งออกไปแสดงความคืบหน้าผิดแบบ หลังเพิ่งส่งออก GIF/APNG มาก่อน
        ExportJob.running = true
        ExportJob.request = ExportJob.Request(parts, frames, fw!!, fh!!, fps, lp!!, color, fpsTable, loopN, quality, paths = vm.project.paths.toList())
        try {
            ContextCompat.startForegroundService(context, Intent(context, ExportService::class.java))
        } catch (e: Exception) {
            ExportJob.running = false
            ExportJob.request = null
            error = "เริ่มสร้างวิดีโอเบื้องหลังไม่ได้: ${e.message ?: e.javaClass.simpleName}"
        }
    }

    AlertDialog(
        onDismissRequest = { if (!busy) onDismiss() },
        title = { Text("ส่งออกวิดีโอ (MP4)") },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(w, { w = it }, label = { Text("กว้าง (px)") }, singleLine = true, enabled = !busy)
                OutlinedTextField(h, { h = it }, label = { Text("สูง (px)") }, singleLine = true, enabled = !busy)
                OutlinedTextField(loops, { loops = it }, label = { Text("วนกี่รอบ") }, singleLine = true, enabled = !busy)
                Text("สีพื้นหลัง (MP4 ไม่มีความโปร่งใส)", style = MaterialTheme.typography.bodySmall)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    bgNames.forEachIndexed { i, n -> Chip(n, bg == i, enabled = !busy) { bg = i } }
                }
                Text("ความชัด (บิตเรตสูง = ภาพคมขึ้น ไฟล์ใหญ่ขึ้น)", style = MaterialTheme.typography.bodySmall)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Exporter.VIDEO_QUALITY_NAMES.forEachIndexed { i, n -> Chip(n, quality == i, enabled = !busy) { quality = i } }
                }
                val fwN = w.toIntOrNull()
                val fhN = h.toIntOrNull()
                if (fwN != null && fhN != null && fwN in 64..1920 && fhN in 64..1920) {
                    val mbps = Exporter.videoBitrate(Exporter.videoSize(fwN), Exporter.videoSize(fhN), quality) / 1_000_000f
                    Text(
                        String.format(java.util.Locale.US, "บิตเรตประมาณ %.1f Mbps · ไฟล์ประมาณ %.0f MB ต่อ 10 วินาที", mbps, mbps * 10f / 8f),
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
                Text(
                    "ความเร็ว ${fmtFps(vm.fps)} fps (แก้ได้ที่ช่องความเร็วในไทม์ไลน์)" +
                        (if (vm.project.speedRanges.isNotEmpty()) " + ${vm.project.speedRanges.size} ช่วงที่ตั้งความเร็วเอง (ใช้ในวิดีโอด้วย)" else "") +
                        " · ${vm.project.frameCount} เฟรม · วิดีโอ 30 fps เคลื่อนลื่นเหมือนในแอป · ขนาดจะปัดเป็นพหุคูณของ 16",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
                error?.let { Text(it, color = MaterialTheme.colorScheme.error) }
                if (busy) Text(progress, color = MaterialTheme.colorScheme.primary)
            }
        },
        confirmButton = { TextButton(enabled = !busy, onClick = { start() }) { Text("สร้างวิดีโอ") } },
        dismissButton = { TextButton(enabled = !busy, onClick = onDismiss) { Text("ปิด") } },
    )
}

@Composable
private fun ImageExportDialog(vm: EditorViewModel, onDismiss: () -> Unit) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var w by remember { mutableStateOf("256") }
    var h by remember { mutableStateOf("256") }
    var cols by remember { mutableStateOf(minOf(5, vm.project.frameCount).toString()) } // คอลัมน์ต้องไม่เกินจำนวนเฟรม
    var preview by remember { mutableStateOf<Bitmap?>(null) }
    var error by remember { mutableStateOf<String?>(null) }
    var busy by remember { mutableStateOf(false) }

    fun generate(onDone: (Bitmap) -> Unit) {
        val fw = w.toIntOrNull()
        val fh = h.toIntOrNull()
        val c = cols.toIntOrNull()
        val err = Exporter.validate(fw, fh, c, vm.project.frameCount)
        if (err != null) {
            error = err
            return
        }
        if (vm.project.parts.isEmpty()) {
            error = "ยังไม่มีชิ้นส่วนให้ส่งออก"
            return
        }
        error = null
        busy = true
        val parts = vm.project.parts.toList()
        val frames = vm.project.snapshotFrames()
        scope.launch {
            val result = runCatching {
                withContext(Dispatchers.Default) { Exporter.buildSheet(parts, frames, fw!!, fh!!, c!!) }
            }
            busy = false
            result.onSuccess {
                preview = it
                onDone(it)
            }.onFailure {
                error = "สร้างสไปรต์ชีตไม่สำเร็จ: ${it.message ?: it.javaClass.simpleName}"
            }
        }
    }

    AlertDialog(
        onDismissRequest = { if (!busy) onDismiss() },
        title = { Text("ส่งออก Sprite Sheet (PNG โปร่งใส)") },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("ความชัด (ขนาดต่อเฟรม)", style = MaterialTheme.typography.bodySmall)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf(256, 512, 1024).forEach { n ->
                        Chip("$n px", w == n.toString() && h == n.toString(), enabled = !busy) {
                            w = n.toString(); h = n.toString(); preview = null
                        }
                    }
                }
                OutlinedTextField(w, { w = it; preview = null }, label = { Text("กว้างต่อเฟรม (px)") }, singleLine = true)
                OutlinedTextField(h, { h = it; preview = null }, label = { Text("สูงต่อเฟรม (px)") }, singleLine = true)
                OutlinedTextField(cols, { cols = it; preview = null }, label = { Text("จำนวนคอลัมน์") }, singleLine = true)
                Text(
                    "จำนวนแถวคำนวณอัตโนมัติจาก ${vm.project.frameCount} เฟรม ÷ คอลัมน์",
                    style = MaterialTheme.typography.bodySmall,
                )
                error?.let { Text(it, color = MaterialTheme.colorScheme.error) }
                preview?.let {
                    Image(
                        bitmap = it.asImageBitmap(),
                        contentDescription = "ตัวอย่างสไปรต์ชีต",
                        contentScale = ContentScale.Fit,
                        modifier = Modifier.fillMaxWidth().heightIn(max = 200.dp).background(Color(0xFF555555)),
                    )
                }
                if (busy) Text("กำลังประมวลผล...")
            }
        },
        confirmButton = {
            Row {
                TextButton(enabled = !busy, onClick = { generate { } }) { Text("ดูตัวอย่าง") }
                TextButton(enabled = !busy, onClick = {
                    generate { bmp ->
                        scope.launch {
                            busy = true
                            val saved = runCatching {
                                withContext(Dispatchers.IO) {
                                    Exporter.savePng(context, bmp, "spritesheet_${System.currentTimeMillis()}")
                                }
                            }
                            busy = false
                            saved.onSuccess {
                                vm.message = "บันทึกแล้ว: $it"
                                onDismiss()
                            }.onFailure {
                                error = "บันทึกไม่สำเร็จ: ${it.message ?: it.javaClass.simpleName}"
                            }
                        }
                    }
                }) { Text("บันทึก") }
            }
        },
        dismissButton = { TextButton(enabled = !busy, onClick = onDismiss) { Text("ปิด") } },
    )
}

private fun DrawScope.drawGuides(vm: EditorViewModel) {
    val grid = Color(0xFF2A2D34)
    val axis = Color(0xFF3B404A)
    for (k in -10..10) {
        val c = if (k == 0) axis else grid
        drawLine(c, vm.toScreen(Offset(k * 100f, -1000f)), vm.toScreen(Offset(k * 100f, 1000f)), 1.5f)
        drawLine(c, vm.toScreen(Offset(-1000f, k * 100f)), vm.toScreen(Offset(1000f, k * 100f)), 1.5f)
    }
    // กรอบส่งออก: สิ่งที่อยู่ในกรอบนี้คือสิ่งที่จะอยู่ในแต่ละเฟรมของวิดีโอ (ขนาดตั้งในเมนูตั้งค่า)
    val (fw, fh) = Exporter.frameWorldSize(vm.videoWidth, vm.videoHeight) // กรอบตามขนาดวิดีโอในเมนูตั้งค่า (ค่าเริ่มต้น 512x512 = จัตุรัส 600 หน่วยเหมือนเดิม)
    drawRect(
        Color(0xFF4FC3F7),
        topLeft = vm.toScreen(Offset(-fw / 2f, -fh / 2f)),
        size = Size(fw * vm.zoom, fh * vm.zoom),
        style = Stroke(width = 2f, pathEffect = PathEffect.dashPathEffect(floatArrayOf(14f, 10f))),
    )
}

private fun DrawScope.drawOverlay(vm: EditorViewModel) {
    if (vm.playing) return // ตอนเล่นแอนิเมชันไม่แสดงกระดูก/จุดต่างๆ ให้เห็นแต่ภาพตัวละคร
    val allParts = vm.project.parts
    val poseFn = vm.poseOf()
    val joints = computeJointMatrices(allParts, poseFn)
    val here = vm.currentFrame.toFloat()
    val parts = allParts.filter { it.shownAt(here) } // ตัวละครที่ไม่แสดงในเฟรมนี้ ไม่วาดกระดูก/จุดจับ
    val sel = vm.selected
    val screenPos = HashMap<Int, Offset>()
    for (p in parts) {
        val j = joints[p.id] ?: continue
        val pt = floatArrayOf(0f, 0f)
        j.mapPoints(pt)
        screenPos[p.id] = vm.toScreen(Offset(pt[0], pt[1]))
    }
    for (p in parts) { // กระดูก = เส้นเชื่อมข้อต่อ parent -> ข้อต่อลูก
        val pid = p.parentId ?: continue
        val a = screenPos[pid] ?: continue
        val b = screenPos[p.id] ?: continue
        drawLine(Color(0x88FFFFFF), a, b, 3f)
    }
    for (p in parts) { // ปลายของกระดูกที่ไม่มีลูก (เช่น มือ): วาดตามทิศจริงของกระดูก ให้เหมือนหน้าแก้ไขกระดูก
        if (p.boneLength <= 0f || parts.any { it.parentId == p.id }) continue
        val a = screenPos[p.id] ?: continue
        val j = joints[p.id] ?: continue
        val pt = floatArrayOf(p.boneLength, 0f)
        j.mapPoints(pt)
        val b = vm.toScreen(Offset(pt[0], pt[1]))
        drawLine(Color(0x88FFFFFF), a, b, 3f)
        drawCircle(Color(0xFFFFD54F), 6f, b)
    }
    for (p in parts) { // จุดต่อ (ปลายกระดูก): เส้นจากข้อต่อไปยังจุดปลาย แล้วจุดเขียวให้จับลาก
        if (!p.hasTip) continue
        val a = screenPos[p.id] ?: continue
        val b = Offset(a.x, a.y + tipLength(p) * vm.zoom) // ปุ่มเขียวอยู่ใต้ปุ่มแดงในแนวตั้งเสมอ
        drawLine(Color(0xFF4FC3F7), a, b, 4f)
        drawCircle(Color(0xFF69F0AE), if (p.id == sel?.id) 16f else 10f, b)
    }
    for (p in parts) {
        val s = screenPos[p.id] ?: continue
        val isSel = p.id == sel?.id && p.boneLength <= 0f // ชิ้นที่มาจากกระดูก: จุดแดงอยู่ที่ปลายกระดูก (ด้านล่าง)
        drawCircle(if (isSel) Color(0xFFFF5252) else Color(0xFFFFD54F), if (isSel) 10f else 6f, s)
    }
    for (r in parts) { // จุดหลัก (ข้อต่อราก): ลากเพื่อย้ายทั้งตัวละคร
        if (r.parentId != null) continue
        if (r.role == BoneRole.ITEM && poseFn(r.id).hold > 0) continue // สิ่งของที่ถืออยู่ตามมือ ไม่มีจุดหลักของตัวเอง
        val s = screenPos[r.id] ?: continue
        if (vm.mainDragging) drawCircle(Color(0xFFFF5252), 10f, s)
        drawCircle(Color(0xAAFFFFFF), 16f, s, style = Stroke(width = 2.5f))
    }
    if (sel != null && sel.boneLength > 0f) { // กระดูกที่เลือก: จุดแดงที่ปลายกระดูก (จุดที่แตะลากได้)
        val j = joints[sel.id]
        if (j != null) {
            val tp = floatArrayOf(sel.boneLength, 0f)
            j.mapPoints(tp)
            drawCircle(Color(0xFFFF5252), 10f, vm.toScreen(Offset(tp[0], tp[1])))
        }
    }
    // วงเขียวรอบจุดปลายของกระดูกมือที่เลือก (เมื่อมีสิ่งของที่ยังไม่ติดมือในฉาก): ลากจุดโคนของสิ่งของเข้ามาในวง ปล่อยนิ้ว = ติดที่ปลายมือ
    if (sel != null && sel.role == BoneRole.HAND && sel.boneLength > 0f && parts.any { it.role == BoneRole.ITEM && poseFn(it.id).hold <= 0 }) {
        val hj = joints[sel.id]
        if (hj != null) {
            val tp = floatArrayOf(sel.boneLength, 0f)
            hj.mapPoints(tp)
            val c = vm.toScreen(Offset(tp[0], tp[1]))
            val hot = vm.draggingItemMain && vm.hoverHandId == sel.id
            val green = Color(0xFF69F0AE)
            drawCircle(green.copy(alpha = if (hot) 0.4f else if (vm.draggingItemMain) 0.2f else 0.12f), HAND_RING_PX, c)
            drawCircle(green, HAND_RING_PX, c, style = Stroke(width = if (hot) 7f else 4f))
        }
    }
}

// ---------- เส้นทางเคลื่อนที่ ----------

private val PathMint = Color(0xFF69F0AE)
private val PathPink = Color(0xFFFF80AB)

private val pathLabelPaint = android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG).apply {
    color = android.graphics.Color.WHITE
    textSize = 26f
    textAlign = android.graphics.Paint.Align.CENTER
    isFakeBoldText = true
    setShadowLayer(5f, 0f, 0f, android.graphics.Color.BLACK)
}

private fun DrawScope.drawPathLabel(text: String, at: Offset) {
    drawIntoCanvas { it.nativeCanvas.drawText(text, at.x, at.y - 24f, pathLabelPaint) }
}

/** ผืนผ้าใบในโหมดเส้นทาง: หรี่ฉากลงเล็กน้อย แล้ววาดเส้นไล่สี จุดต่อเฟรม ลูกศรปลายทาง และจุดจับสำหรับดัดโค้ง */
private fun DrawScope.drawPathOverlay(vm: EditorViewModel) {
    if (!vm.playing) drawRect(Color(0x40000000)) // ให้เส้นเด่นขึ้นโดยไม่บังตัวละคร
    val path = vm.activePath() ?: vm.pathPrompt?.path

    // เส้นที่กำลังวาด / จุดที่วางไว้แล้วแต่ยังไม่ครบ 2 จุด
    val draft = vm.pathDraft.map { vm.toScreen(it) }
    if (draft.size >= 2 && vm.pathDrawMode != PathDrawMode.POINTS) {
        val live = Path().apply {
            moveTo(draft[0].x, draft[0].y)
            for (i in 1 until draft.size) lineTo(draft[i].x, draft[i].y)
        }
        drawPath(live, Color(0x33B69DFF), style = Stroke(width = 16f, cap = StrokeCap.Round, join = StrokeJoin.Round))
        drawPath(live, Palette.Accent, style = Stroke(width = 5f, cap = StrokeCap.Round, join = StrokeJoin.Round))
    }
    if (vm.pathDrawMode == PathDrawMode.LINE && draft.isNotEmpty()) { // เส้นตรงที่กำลังลาก: จุดแรกเขียว จุดสองชมพู
        drawCircle(Color(0x4469F0AE), 18f, draft.first())
        drawCircle(PathMint, 9f, draft.first())
        if (draft.size >= 2) {
            drawCircle(Color(0x44FF80AB), 18f, draft.last())
            drawCircle(PathPink, 9f, draft.last())
        }
    }
    if (vm.pathDrawMode == PathDrawMode.POINTS) {
        for (p in draft) {
            drawCircle(Color(0x33B69DFF), 22f, p)
            drawCircle(Color.White, 10f, p)
            drawCircle(Palette.Accent, 10f, p, style = Stroke(width = 3f))
        }
    }

    if (path == null || path.points.size < 2) return
    val dense = PathMath.dense(path.points, path.smooth, path.closed)
    val sp = dense.pts.map { vm.toScreen(it) }
    if (sp.size < 2) return
    val line = Path().apply {
        moveTo(sp[0].x, sp[0].y)
        for (i in 1 until sp.size) lineTo(sp[i].x, sp[i].y)
    }
    val brush: Brush = if ((sp.first() - sp.last()).getDistance() < 2f) {
        SolidColor(Palette.Accent) // เส้นปิดวง: จุดเริ่มกับจุดจบทับกัน ใช้สีเดียว
    } else {
        Brush.linearGradient(listOf(PathMint, Palette.Accent, PathPink), start = sp.first(), end = sp.last())
    }
    drawPath(line, Color(0x30B69DFF), style = Stroke(width = 22f, cap = StrokeCap.Round, join = StrokeJoin.Round)) // ออร่า
    drawPath(line, Color(0x66000000), style = Stroke(width = 9f, cap = StrokeCap.Round, join = StrokeJoin.Round)) // เงาใต้เส้น
    drawPath(line, brush, style = Stroke(width = 6f, cap = StrokeCap.Round, join = StrokeJoin.Round))
    drawPath(line, Color(0x55FFFFFF), style = Stroke(width = 1.5f, cap = StrokeCap.Round, join = StrokeJoin.Round)) // ไส้เส้นสว่างบางๆ

    // จุดต่อเฟรม: จุดห่างกัน = เร็ว จุดชิดกัน = ช้า
    val n = (path.endFrame - path.startFrame + 1).coerceAtLeast(1)
    val samples = PathMath.sample(path, n).map { vm.toScreen(it.pos) }
    val cur = vm.currentFrame - path.startFrame
    val grab = vm.pathGrab && !vm.playing
    val loop = PathMath.isLoop(path)
    samples.forEachIndexed { k, p ->
        if (k == 0 || k == cur) return@forEachIndexed
        val movable = loop || k != samples.lastIndex
        if (grab && movable) { // โหมดจับเฟรม: จุดใหญ่ขึ้นพร้อมเลขเฟรม ให้จับง่าย
            val dragging = vm.pathDot == k
            drawCircle(if (dragging) Color(0x5569F0AE) else Color(0x3369F0AE), if (dragging) 30f else 22f, p)
            drawCircle(Color(0xFF1B1D22), if (dragging) 15f else 12f, p)
            drawCircle(if (dragging) PathMint else Color.White, if (dragging) 12f else 9f, p)
            drawCircle(PathMint, if (dragging) 12f else 9f, p, style = Stroke(width = 3f))
            if (n <= 30 || dragging) drawPathLabel("${path.startFrame + k + 1}", p)
        } else if (k != samples.lastIndex) {
            drawCircle(Color(0xAA000000), 6f, p)
            drawCircle(Color.White, 4f, p)
        }
    }

    // ลูกศรปลายทาง (ชี้ตามทิศของเส้นช่วงท้าย)
    val tip = sp.last()
    val from = sp.asReversed().firstOrNull { (it - tip).getDistance() > 14f }
    if (from != null && !(path.closed && path.points.size >= 3)) {
        val dir = (tip - from)
        val len = dir.getDistance()
        val ux = dir.x / len
        val uy = dir.y / len
        val a = Offset(tip.x + ux * 16f, tip.y + uy * 16f)
        val b = Offset(tip.x - ux * 6f - uy * 11f, tip.y - uy * 6f + ux * 11f)
        val c = Offset(tip.x - ux * 6f + uy * 11f, tip.y - uy * 6f - ux * 11f)
        val arrow = Path().apply {
            moveTo(a.x, a.y); lineTo(b.x, b.y); lineTo(c.x, c.y); close()
        }
        drawPath(arrow, PathPink)
    }

    // เฟรมปัจจุบันบนเส้น: วงแหวนเรืองแสง
    if (cur in samples.indices) {
        val p = samples[cur]
        drawCircle(Color(0x44B69DFF), if (grab) 26f else 20f, p)
        drawCircle(Color.White, 8f, p)
        drawCircle(Palette.Accent, 12f, p, style = Stroke(width = 3.5f))
    }

    // จุดเริ่ม (เขียวมิ้นต์) / จุดจบ (ชมพู) พร้อมเลขเฟรม
    val s0 = samples.first()
    drawCircle(Color(0x4469F0AE), 18f, s0)
    drawCircle(PathMint, 9f, s0)
    drawPathLabel("${path.startFrame + 1}", s0)
    if (n > 1) {
        val s1 = samples.last()
        if (!(path.closed && path.points.size >= 3)) {
            drawCircle(Color(0x44FF80AB), 18f, s1)
            drawCircle(PathPink, 9f, s1)
        }
        drawPathLabel("${path.endFrame + 1}", s1)
    }

    // จุดจับ: ลากเพื่อดัดโค้ง (จุดที่กำลังลากใหญ่ขึ้นและเป็นสีมิ้นต์) ซ่อนไว้ตอนจับเฟรมไม่ให้สับสน
    if (!vm.playing && !grab) {
        path.points.forEachIndexed { i, wp ->
            val p = vm.toScreen(wp)
            val active = vm.pathHandle == i
            val chosen = vm.pathSel == i // จุดที่เลือกไว้ (ไฮไลต์ชมพู ไว้กดลบ)
            drawCircle(if (active) Color(0x5569F0AE) else if (chosen) Color(0x55FF80AB) else Color(0x33B69DFF), if (active || chosen) 30f else 22f, p)
            drawCircle(Color(0xFF1B1D22), 14f, p)
            drawCircle(Color.White, 11f, p)
            drawCircle(if (active) PathMint else if (chosen) PathPink else Palette.Accent, 11f, p, style = Stroke(width = 3.5f))
        }
    }
}

private val PathModeBg = Brush.horizontalGradient(listOf(Color(0xFF42338A), Color(0xFF5B46C4)))
private val PathGrabBg = Brush.horizontalGradient(listOf(Color(0xFF0E5C45), Color(0xFF1F8F6A)))
private val PathSubText = Color(0xFFC9C4D4)

/** ปุ่มเลือกวิธีวาด: ไอคอนใหญ่ + ชื่อ ตัวที่เลือกมีพื้นไล่สีม่วงและขอบสว่าง */
@Composable
private fun PathModeButton(icon: String, label: String, selected: Boolean, modifier: Modifier, onClick: () -> Unit) {
    val shape = RoundedCornerShape(16.dp)
    Column(
        modifier
            .heightIn(min = 62.dp)
            .clip(shape)
            .background(if (selected) PathModeBg else SolidColor(Palette.PanelHigh))
            .border(if (selected) 1.5.dp else 1.dp, if (selected) Palette.Accent else Palette.Stroke, shape)
            .clickable(onClick = onClick)
            .padding(horizontal = 6.dp, vertical = 8.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(2.dp),
    ) {
        Text(icon, fontSize = 22.sp, color = if (selected) Color.White else NormalFg)
        Text(
            label,
            fontSize = 12.sp,
            maxLines = 1,
            fontWeight = if (selected) FontWeight.Bold else FontWeight.Normal,
            color = if (selected) Color.White else NormalFg,
        )
    }
}

/** ปุ่มจับเฟรม: เปิดแล้วพื้นเขียวมิ้นต์ ใช้ลากจุดขาวเล็กๆ ของแต่ละเฟรมไปตามเส้น */
@Composable
private fun PathGrabButton(active: Boolean, modifier: Modifier, onClick: () -> Unit) {
    val shape = RoundedCornerShape(16.dp)
    Row(
        modifier
            .heightIn(min = 52.dp)
            .clip(shape)
            .background(if (active) PathGrabBg else SolidColor(Palette.PanelHigh))
            .border(if (active) 1.5.dp else 1.dp, if (active) PathMint else Palette.Stroke, shape)
            .clickable(onClick = onClick)
            .padding(horizontal = 14.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        Box(
            Modifier
                .size(22.dp)
                .clip(CircleShape)
                .background(if (active) Color(0x3369F0AE) else Color(0x22FFFFFF))
                .border(2.dp, if (active) PathMint else Color.White, CircleShape),
        )
        Column {
            Text("จับเฟรม", fontWeight = FontWeight.Bold, fontSize = 15.sp, color = if (active) Color.White else NormalFg)
            Text(
                if (active) "ลากจุดขาวไปตามเส้น" else "ปรับตำแหน่งแต่ละเฟรม",
                fontSize = 11.sp,
                color = if (active) Color(0xFFB9F6D9) else PathSubText,
            )
        }
    }
}

/** ปุ่มสลับตัวเลือกทรงแคปซูล: เปิดอยู่มีเครื่องหมายถูกและพื้นม่วง */
@Composable
private fun PathToggle(label: String, selected: Boolean, enabled: Boolean = true, onClick: () -> Unit) {
    val shape = RoundedCornerShape(50)
    Box(
        Modifier
            .heightIn(min = 40.dp)
            .alpha(if (enabled) 1f else 0.38f)
            .clip(shape)
            .background(if (selected) PathModeBg else SolidColor(Palette.PanelHigh))
            .border(1.dp, if (selected) Palette.Accent else Palette.Stroke, shape)
            .clickable(enabled = enabled, onClick = onClick)
            .padding(horizontal = 14.dp, vertical = 6.dp),
        contentAlignment = Alignment.Center,
    ) {
        Text(
            if (selected) "✓  $label" else label,
            fontSize = 13.sp,
            maxLines = 1,
            color = if (selected) Color.White else NormalFg,
            fontWeight = if (selected) FontWeight.Bold else FontWeight.Normal,
        )
    }
}

@Composable
private fun PathStepButton(label: String, enabled: Boolean, onClick: () -> Unit) {
    Box(
        Modifier.size(36.dp).alpha(if (enabled) 1f else 0.38f).clickable(enabled = enabled, onClick = onClick),
        contentAlignment = Alignment.Center,
    ) { Text(label, fontSize = 20.sp, color = NormalFg) }
}

/** ตัวปรับเลขเฟรมแบบ − เลข + */
@Composable
private fun PathStepper(value: Int, minusEnabled: Boolean, plusEnabled: Boolean, onMinus: () -> Unit, onPlus: () -> Unit) {
    val shape = RoundedCornerShape(50)
    Row(
        Modifier.clip(shape).background(Color(0xFF1B1D22)).border(1.dp, Palette.Stroke, shape),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        PathStepButton("−", minusEnabled, onMinus)
        Text("$value", Modifier.width(32.dp), textAlign = TextAlign.Center, fontWeight = FontWeight.Bold, color = Palette.Accent)
        PathStepButton("+", plusEnabled, onPlus)
    }
}

/** แถบตั้งค่าเส้นทาง (อยู่เหนือเส้นเวลา): วิธีวาด, ช่วงเฟรม, จับเฟรม, ตัวเลือก, ล้างเส้น */
@Composable
private fun PathBar(vm: EditorViewModel) {
    val path = vm.activePath()
    val grab = vm.pathGrab && path != null
    val card = RoundedCornerShape(16.dp)
    Column(
        Modifier.fillMaxWidth().padding(horizontal = 14.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp),
    ) {
        // หัวแถบ: ไอคอนไล่สี + สรุปเส้น + ปุ่มเสร็จ
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            Box(
                Modifier
                    .size(36.dp)
                    .clip(RoundedCornerShape(12.dp))
                    .background(Brush.linearGradient(listOf(PathMint, Palette.Accent, PathPink))),
                contentAlignment = Alignment.Center,
            ) { Text("〰", fontSize = 18.sp, fontWeight = FontWeight.Bold, color = Color(0xFF1B1D22)) }
            Column(Modifier.weight(1f)) {
                Text("เส้นทาง", fontWeight = FontWeight.Bold, color = NormalFg)
                Text(
                    if (path != null) "${path.endFrame - path.startFrame + 1} เฟรม · ${path.points.size} จุดควบคุม" else "ยังไม่มีเส้น",
                    fontSize = 11.sp,
                    color = PathSubText,
                )
            }
            PillButton("✓  เสร็จ", onClick = { vm.closePathMode() }, style = PillStyle.PRIMARY)
        }
        // วิธีวาด 3 แบบ
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            PathModeButton("✍", "วาดอิสระ", !grab && vm.pathDrawMode == PathDrawMode.FREE, Modifier.weight(1f)) {
                vm.selectPathDrawMode(PathDrawMode.FREE)
            }
            PathModeButton("◎", "แตะวางจุด", !grab && vm.pathDrawMode == PathDrawMode.POINTS, Modifier.weight(1f)) {
                vm.selectPathDrawMode(PathDrawMode.POINTS)
            }
            PathModeButton("╱", "เส้นตรง", !grab && vm.pathDrawMode == PathDrawMode.LINE, Modifier.weight(1f)) {
                vm.selectPathDrawMode(PathDrawMode.LINE)
            }
        }
        if (path == null) {
            Text(
                "วาดเส้นหนึ่งเส้น แอปจะวางตัวละครตามเส้นให้ทุกเฟรม ท่าแขนขาที่ทำไว้ไม่ถูกแตะ",
                color = PathSubText,
                fontSize = 12.sp,
            )
        } else {
            // ช่วงเฟรม
            Row(
                Modifier.fillMaxWidth().clip(card).background(Palette.PanelHigh).border(1.dp, Palette.Stroke, card).padding(horizontal = 12.dp, vertical = 6.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                Text("เฟรม", color = NormalFg, fontSize = 13.sp)
                PathStepper(
                    path.startFrame + 1,
                    minusEnabled = path.startFrame > 0,
                    plusEnabled = path.startFrame < path.endFrame,
                    onMinus = { vm.setPathRange(path.startFrame - 1, path.endFrame) },
                    onPlus = { vm.setPathRange(path.startFrame + 1, path.endFrame) },
                )
                Text("ถึง", color = NormalFg, fontSize = 13.sp)
                PathStepper(
                    path.endFrame + 1,
                    minusEnabled = path.endFrame > path.startFrame,
                    plusEnabled = path.endFrame < 599, // ที่เฟรมสุดท้ายกด + = เพิ่มเฟรมให้
                    onMinus = { vm.setPathRange(path.startFrame, path.endFrame - 1) },
                    onPlus = { vm.setPathRange(path.startFrame, path.endFrame + 1) },
                )
            }
            // จับเฟรม (+ จัดให้ห่างเท่ากัน เมื่อเปิดโหมดจับเฟรมและเคยลากย้ายแล้ว)
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                PathGrabButton(grab, Modifier.weight(1f)) { vm.togglePathGrab() }
                PillButton("เฉลี่ยเฟรม", onClick = { vm.resetPathFrameSpacing() }, enabled = path.frameT.isNotEmpty()) // ใช้ได้ทั้งโหมดวาดและโหมดจับเฟรม
            }
            // ตัวเลือก
            Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                PathToggle("โค้งเนียน", path.smooth, enabled = path.points.size >= 3) { vm.togglePathSmooth() }
                PathToggle("หันตามทิศเดิน", path.followHeading) { vm.togglePathHeading() }
                PathToggle("วนกลับจุดเริ่ม", path.closed, enabled = path.points.size >= 3) { vm.togglePathClosed() }
                PillButton("✕  ลบจุดดัดโค้ง", onClick = { vm.deleteSelectedPathPoint() }, enabled = vm.selectedPathPoint() != null && path.points.size > 2, style = PillStyle.DANGER)
                PillButton("🗑  ล้างเส้น", onClick = { vm.clearPath() }, style = PillStyle.DANGER)
            }
        }
    }
}

/** ถามก่อนใช้เส้น: ช่วงนั้นมีการย้ายตำแหน่งไว้แล้ว (จะถูกเขียนทับ) หรือเฟรมไม่พอสำหรับเคลื่อนที่ */
@Composable
private fun PathPromptDialog(vm: EditorViewModel, prompt: PathPrompt) {
    val p = prompt.path
    AlertDialog(
        onDismissRequest = { vm.cancelPathPrompt() },
        title = { Text("ใช้เส้นทางนี้?") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                if (prompt.overwrite) {
                    Text("ช่วงเฟรม ${p.startFrame + 1}–${p.endFrame + 1} มีการย้ายตำแหน่งตัวละครไว้แล้ว การใช้เส้นจะเขียนทับตำแหน่งเหล่านั้น (กดย้อนกลับเพื่อคืนได้)")
                }
                if (prompt.framesShort) {
                    Text("ช่วงนี้มีแค่ 1 เฟรม ไม่พอให้เคลื่อนที่ แอปจะเพิ่มเฟรมให้ครบ 12 เฟรมนับจากเฟรม ${p.startFrame + 1}")
                }
            }
        },
        confirmButton = { PillButton("ใช้", style = PillStyle.PRIMARY, onClick = { vm.confirmPathPrompt() }) },
        dismissButton = { PillButton("ยกเลิก", onClick = { vm.cancelPathPrompt() }) },
    )
}
