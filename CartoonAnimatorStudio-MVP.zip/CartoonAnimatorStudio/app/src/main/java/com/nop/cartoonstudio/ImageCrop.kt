package com.nop.cartoonstudio

import android.graphics.Bitmap
import android.graphics.BitmapShader
import android.graphics.DashPathEffect
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PathMeasure
import android.graphics.PorterDuff
import android.graphics.PorterDuffXfermode
import android.graphics.Rect
import android.graphics.RectF
import android.graphics.Region
import android.graphics.Shader
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.gestures.calculateCentroid
import androidx.compose.foundation.gestures.calculatePan
import androidx.compose.foundation.gestures.calculateZoom
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.RowScope
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.FilterChip
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.drawIntoCanvas
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.input.pointer.positionChanged
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import kotlin.math.ceil
import kotlin.math.floor
import kotlin.math.max
import kotlin.math.min
import java.util.IdentityHashMap
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

private enum class CropMode { ADD, REMOVE, BEND, ERASE }

/** สถานะ 1 ขั้นของประวัติ (ย้อนกลับ/ทำซ้ำ): บ่วง + ภาพที่ถูกลบด้วยยางลบแล้ว (บิตแมปที่ไม่เปลี่ยนใช้ตัวเดียวกันร่วมกัน) */
private class Snap(val lassos: List<Path>, val bmp: Bitmap)

/** จำนวนขั้นย้อนกลับที่เก็บภาพคนละใบได้สูงสุด (ภาพแต่ละใบกินหน่วยความจำ จึงจำกัดไว้) */
private const val MAX_BITMAP_HISTORY = 12

private fun trimHistory(list: List<Snap>): List<Snap> {
    val l = list.takeLast(MAX_HISTORY)
    val seen = java.util.Collections.newSetFromMap(IdentityHashMap<Bitmap, Boolean>())
    var cut = 0
    for (i in l.indices.reversed()) {
        seen.add(l[i].bmp)
        if (seen.size > MAX_BITMAP_HISTORY) {
            cut = i + 1
            break
        }
    }
    return if (cut > 0) l.drop(cut) else l
}

/** ตัวเลขสำหรับแสดง: ตัดศูนย์ท้ายทศนิยมทิ้ง (24.0 -> 24, 2.50 -> 2.5) */
private fun fmtNum(v: Float): String =
    runCatching { java.math.BigDecimal(v.toString()).stripTrailingZeros().toPlainString() }.getOrDefault(v.toString())

/** จุดควบคุมของบ่วง (ไว้ดัดโค้ง): contours = จุดของแต่ละเส้นขอบปิด (พิกัดภาพ), smooth = ต่อจุดเป็นเส้นโค้งเนียน, fillType = ชนิดการเติมของบ่วงเดิม (รักษารูโหว่) */
private class Ctrl(val contours: List<List<Offset>>, val smooth: Boolean, val fillType: Path.FillType)

/** จุดที่กำลังลากอยู่ตอนดัดโค้ง: orig = บ่วงเดิม, ctrl/preview = ผลระหว่างลาก (ยังไม่บันทึกลงประวัติจนกว่าจะปล่อยนิ้ว) */
private class BendDrag(val orig: Path, val ctrl: Ctrl, val preview: Path)

/** จุดควบคุมที่นิ้วแตะโดน: บ่วง path, เส้นขอบที่ c, จุดที่ p */
private class Hit(val path: Path, val c: Int, val p: Int)

/** เส้นขอบบ่วงที่ใกล้นิ้ว: seg = แทรกจุดใหม่ต่อจากจุดที่ seg, pt = จุดบนเส้น (พิกัดภาพ) */
private class EdgeHit(val path: Path, val c: Int, val seg: Int, val pt: Offset)

private fun projectOnSegment(p: Offset, a: Offset, b: Offset): Offset {
    val dx = b.x - a.x
    val dy = b.y - a.y
    val l2 = dx * dx + dy * dy
    if (l2 < 1e-9f) return a
    val t = (((p.x - a.x) * dx + (p.y - a.y) * dy) / l2).coerceIn(0f, 1f)
    return Offset(a.x + dx * t, a.y + dy * t)
}

/** ลดจำนวนจุดของเส้นด้วย Douglas-Peucker (ไม่ทำให้เส้นเรียบขึ้น จึงไม่กินซอกแคบ) */
private fun rdpOpen(pts: List<Offset>, eps: Float): List<Offset> {
    if (pts.size < 3) return pts
    val keep = BooleanArray(pts.size)
    keep[0] = true
    keep[pts.size - 1] = true
    val stack = ArrayDeque<IntArray>()
    stack.addLast(intArrayOf(0, pts.size - 1))
    while (stack.isNotEmpty()) {
        val seg = stack.removeLast()
        val a = seg[0]
        val b = seg[1]
        var maxD = 0f
        var idx = -1
        for (i in a + 1 until b) {
            val d = (pts[i] - projectOnSegment(pts[i], pts[a], pts[b])).getDistance()
            if (d > maxD) {
                maxD = d
                idx = i
            }
        }
        if (idx >= 0 && maxD > eps) {
            keep[idx] = true
            stack.addLast(intArrayOf(a, idx))
            stack.addLast(intArrayOf(idx, b))
        }
    }
    return pts.filterIndexed { i, _ -> keep[i] }
}

/** ลดจุดของเส้นขอบปิด (ได้อย่างน้อย 3 จุด และไม่เกิน ~80 จุด ให้ลากแก้ไหว) */
private fun simplifyClosed(raw: List<Offset>, eps0: Float): List<Offset> {
    var eps = eps0
    var out = rdpOpen(raw + raw[0], eps).dropLast(1)
    var guard = 0
    while (out.size > 80 && guard < 12) {
        eps *= 1.4f
        out = rdpOpen(raw + raw[0], eps).dropLast(1)
        guard++
    }
    if (out.size < 3) out = listOf(raw[0], raw[raw.size / 3], raw[raw.size * 2 / 3])
    return out
}

/** แตกบ่วง (Path) เป็นจุดควบคุมของแต่ละเส้นขอบ: เก็บแนวขอบเดิมไว้ ลดเหลือเฉพาะจุดที่จำเป็น tol = ความคลาดเคลื่อนที่ยอม (พิกเซลภาพ) */
private fun flattenToControls(p: Path, tol: Float): List<List<Offset>> {
    val pm = PathMeasure(p, true)
    val res = ArrayList<List<Offset>>()
    val pos = FloatArray(2)
    do {
        val len = pm.length
        if (len > 1f) {
            val n = (len / 2f).toInt().coerceIn(12, 800)
            val raw = ArrayList<Offset>(n)
            for (i in 0 until n) {
                pm.getPosTan(len * i / n, pos, null)
                raw.add(Offset(pos[0], pos[1]))
            }
            res.add(simplifyClosed(raw, tol))
        }
    } while (pm.nextContour())
    return res
}

/** สร้างบ่วงจากจุดควบคุม (smooth = เส้นโค้งเนียนผ่านทุกจุด ใช้สูตรเดียวกับเส้นทางเฟรม) */
private fun buildPath(c: Ctrl): Path {
    val out = Path()
    out.fillType = c.fillType
    for (pts in c.contours) {
        if (pts.size < 3) continue
        val d = PathMath.dense(pts, c.smooth, true).pts
        out.moveTo(d[0].x, d[0].y)
        for (i in 1 until d.size) out.lineTo(d[i].x, d[i].y)
        out.close()
    }
    return out
}

/** ระยะลากขั้นต่ำ (พิกเซลบนจอ) ที่ถือว่าเป็นการ "วาดบ่วง" ถ้าน้อยกว่านี้ถือเป็นการแตะ */
private const val MIN_STROKE_TRAVEL = 12f

/** จำนวนขั้นย้อนกลับสูงสุด */
private const val MAX_HISTORY = 50

// ───────────────────────── ตรรกะบ่วง (ไม่ผูกกับ UI) ─────────────────────────

private fun hasArea(p: Path): Boolean {
    if (p.isEmpty) return false
    val b = RectF()
    p.computeBounds(b, true)
    return b.width() > 1f && b.height() > 1f
}

private fun overlaps(a: Path, b: Path): Boolean {
    val r = Path()
    if (!r.op(a, b, Path.Op.INTERSECT)) return false
    return hasArea(r)
}

/** เพิ่มบ่วงใหม่: บ่วงที่ทับกันจะรวมเป็นบ่วงเดียว */
private fun addLasso(list: List<Path>, np: Path): List<Path> {
    var merged = np
    val rest = ArrayList<Path>()
    for (p in list) {
        if (overlaps(p, merged)) {
            val u = Path()
            if (u.op(p, merged, Path.Op.UNION)) merged = u else rest.add(p)
        } else {
            rest.add(p)
        }
    }
    rest.add(merged)
    return rest
}

/** ลบพื้นที่ของบ่วง [cut] ออกจากบ่วงที่มีอยู่ (บ่วงที่ไม่เหลือพื้นที่จะหายไป) */
private fun subtractLasso(list: List<Path>, cut: Path): List<Path> {
    val out = ArrayList<Path>()
    for (p in list) {
        if (!overlaps(p, cut)) {
            out.add(p)
            continue
        }
        val d = Path()
        if (d.op(p, cut, Path.Op.DIFFERENCE)) {
            if (hasArea(d)) out.add(d)
        } else {
            out.add(p)
        }
    }
    return out
}

private fun sameLassos(a: List<Path>, b: List<Path>): Boolean =
    a.size == b.size && a.indices.all { a[it] === b[it] }

private fun pathContains(p: Path, pt: Offset, w: Int, h: Int): Boolean {
    val r = Region()
    r.setPath(p, Region(0, 0, w, h))
    return r.contains(pt.x.toInt(), pt.y.toInt())
}

/**
 * ตัดภาพตามบ่วง: ได้ภาพขนาดเท่ากรอบที่ครอบบ่วงทั้งหมด ส่วนนอกบ่วงโปร่งใส
 * คืน null ถ้าบ่วงอยู่นอกภาพทั้งหมด (เรียกใน background thread)
 */
fun cropByLassos(src: Bitmap, lassos: List<Path>): Bitmap? = cropByLassosAt(src, lassos)?.bmp

/** ผลตัดภาพ: bmp = ภาพที่ตัดแล้ว, left/top = ตำแหน่งมุมซ้ายบนของภาพที่ตัดในพิกัดภาพเดิม (ไว้ชดเชยตำแหน่งตอนแก้ภาพที่วางอยู่แล้ว) */
class CropResult(val bmp: Bitmap, val left: Int, val top: Int)

fun cropByLassosAt(src: Bitmap, lassos: List<Path>): CropResult? {
    if (lassos.isEmpty()) return CropResult(src, 0, 0)
    val rect = RectF()
    val tmp = RectF()
    var first = true
    for (p in lassos) {
        p.computeBounds(tmp, true)
        if (first) {
            rect.set(tmp)
            first = false
        } else {
            rect.union(tmp)
        }
    }
    val l = floor(rect.left).toInt().coerceIn(0, src.width)
    val t = floor(rect.top).toInt().coerceIn(0, src.height)
    val r = ceil(rect.right).toInt().coerceIn(0, src.width)
    val b = ceil(rect.bottom).toInt().coerceIn(0, src.height)
    val w = r - l
    val h = b - t
    if (w < 1 || h < 1) return null

    val mask = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
    val mc = android.graphics.Canvas(mask)
    val fill = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.FILL
        color = android.graphics.Color.WHITE
    }
    mc.translate(-l.toFloat(), -t.toFloat())
    for (p in lassos) mc.drawPath(p, fill)

    val out = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
    val oc = android.graphics.Canvas(out)
    oc.drawBitmap(src, -l.toFloat(), -t.toFloat(), Paint(Paint.FILTER_BITMAP_FLAG))
    val dstIn = Paint().apply { xfermode = PorterDuffXfermode(PorterDuff.Mode.DST_IN) }
    oc.drawBitmap(mask, 0f, 0f, dstIn)
    mask.recycle()
    return CropResult(out, l, t)
}

// ───────────────────────── หน้าจอตัดภาพ ─────────────────────────

/**
 * หน้าตัดภาพตอนนำเข้า
 * - ลากนิ้วเดียววาดบ่วงรอบส่วนที่ต้องการ (ปล่อยนิ้วแล้วบ่วงปิดเอง) ขอบบ่วงเป็นเส้นปะ ขาว-ดำสลับกัน
 * - บ่วงที่วาดทับกันจะรวมเป็นบ่วงเดียว
 * - โหมด "เพิ่มบ่วง" / "ลบบ่วง" (ลบบ่วง: แตะในบ่วง = ลบทั้งบ่วง, วาดบ่วงทับ = ลบเฉพาะส่วนที่ทับ)
 * - ย้อนกลับ / ทำซ้ำ, ตกลง (ตัดแล้วนำเข้า), ยกเลิก (ไม่นำเข้าภาพนี้)
 * - 2 นิ้ว = ซูม/เลื่อนภาพเพื่อวาดละเอียด; ถ้าไม่วาดบ่วงเลย ตกลง = นำเข้าทั้งภาพ
 */
@Composable
fun ImageCropScreen(bitmap: Bitmap, onConfirm: (Bitmap, Int, Int) -> Unit, onCancel: () -> Unit) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val density = LocalDensity.current.density

    val bw = bitmap.width
    val bh = bitmap.height

    var mode by remember { mutableStateOf(CropMode.ADD) }
    var canvasSize by remember { mutableStateOf(IntSize.Zero) }
    var busy by remember { mutableStateOf(false) }

    // บ่วงที่ยืนยันแล้ว (พิกัดภาพ) — ไม่แก้ Path เดิม เปลี่ยนทั้งรายการเมื่อมีการแก้
    var lassos by remember { mutableStateOf<List<Path>>(emptyList()) }
    var undoStack by remember { mutableStateOf<List<Snap>>(emptyList()) }
    var redoStack by remember { mutableStateOf<List<Snap>>(emptyList()) }

    // ภาพที่กำลังแก้ (ยางลบแก้ที่สำเนาของภาพเสมอ ภาพต้นฉบับไม่ถูกแตะ); workVer = ตัวบอกให้วาดใหม่ตอนลบ (บิตแมปถูกแก้ในที่เดิมระหว่างลากนิ้ว)
    var work by remember { mutableStateOf(bitmap) }
    var workVer by remember { mutableIntStateOf(0) }
    var eraserSize by remember { mutableFloatStateOf(24f) } // ขนาดยางลบ (เส้นผ่านศูนย์กลาง หน่วยพิกเซลของภาพ รองรับทศนิยม)
    var showPad by remember { mutableStateOf(false) }
    val live = remember { mutableStateListOf<Offset>() } // บ่วงที่กำลังวาด (พิกัดภาพ)

    // มุมมอง: จอ = ภาพ * vs + off
    var vs by remember { mutableFloatStateOf(1f) }
    var off by remember { mutableStateOf(Offset.Zero) }

    // ดัดโค้งบ่วง: จุดควบคุมของแต่ละบ่วง (เก็บตามตัวบ่วง ย้อนกลับ/ทำซ้ำแล้วจุดตามบ่วงเดิมกลับมาด้วย)
    val ctrlCache = remember { IdentityHashMap<Path, Ctrl>() }
    var selPath by remember { mutableStateOf<Path?>(null) } // บ่วงที่เลือกจุดไว้
    var selC by remember { mutableIntStateOf(0) } // เส้นขอบที่เลือก
    var selP by remember { mutableIntStateOf(0) } // จุดที่เลือก (ไว้กดลบจุด)
    var bendDrag by remember { mutableStateOf<BendDrag?>(null) }
    var addPtMode by remember { mutableStateOf(false) } // โหมดเพิ่มจุด: แตะตรงไหนจุดใหม่ขึ้นตรงนิ้วตรงนั้น

    // แว่นขยายระหว่างลากนิ้ว: touch = ตำแหน่งนิ้วบนจอ (ไว้หลบ), lensImg = จุดบนภาพที่ขยายดู
    var touch by remember { mutableStateOf<Offset?>(null) }
    var lensImg by remember { mutableStateOf<Offset?>(null) }

    fun fitScale(): Float {
        if (canvasSize.width == 0 || canvasSize.height == 0) return 1f
        return min(canvasSize.width.toFloat() / bw, canvasSize.height.toFloat() / bh) * 0.96f
    }

    fun fitView() {
        if (canvasSize.width == 0 || canvasSize.height == 0) return
        val f = fitScale()
        vs = f
        off = Offset((canvasSize.width - bw * f) / 2f, (canvasSize.height - bh * f) / 2f)
    }

    LaunchedEffect(canvasSize) { fitView() }

    fun toImg(o: Offset): Offset = Offset(
        ((o.x - off.x) / vs).coerceIn(0f, bw.toFloat()),
        ((o.y - off.y) / vs).coerceIn(0f, bh.toFloat()),
    )

    fun toScreen(p: Path): Path {
        val m = Matrix()
        m.setScale(vs, vs)
        m.postTranslate(off.x, off.y)
        val q = Path(p)
        q.transform(m)
        return q
    }

    fun commit(newList: List<Path>) {
        if (sameLassos(newList, lassos)) return
        undoStack = trimHistory(undoStack + Snap(lassos, work))
        redoStack = emptyList()
        lassos = newList
    }

    fun undo() {
        val prev = undoStack.lastOrNull() ?: return
        redoStack = redoStack + Snap(lassos, work)
        lassos = prev.lassos
        work = prev.bmp
        workVer++
        undoStack = undoStack.dropLast(1)
    }

    fun redo() {
        val next = redoStack.lastOrNull() ?: return
        undoStack = trimHistory(undoStack + Snap(lassos, work))
        lassos = next.lassos
        work = next.bmp
        workVer++
        redoStack = redoStack.dropLast(1)
    }

    /** แปลงตำแหน่งจอเป็นพิกัดภาพแบบไม่ตัดขอบ (ยางลบลากเลยขอบภาพได้) */
    fun toImgRaw(o: Offset): Offset = Offset((o.x - off.x) / vs, (o.y - off.y) / vs)

    fun ctrlOf(p: Path): Ctrl = ctrlCache.getOrPut(p) { Ctrl(flattenToControls(p, 5f / max(vs, 0.01f)), false, p.fillType) }

    fun selValid(): Path? = selPath?.takeIf { sp -> lassos.any { it === sp } }

    /** แทนเส้นขอบ ci ของบ่วง orig ด้วยจุดชุดใหม่ แล้วบันทึกลงประวัติ (ย้อนกลับได้) */
    fun replaceContour(orig: Path, ci: Int, pts: List<Offset>, newSelP: Int) {
        val ct = ctrlOf(orig)
        val nc = Ctrl(ct.contours.mapIndexed { i, l -> if (i == ci) pts else l }, ct.smooth, ct.fillType)
        val np = buildPath(nc)
        ctrlCache[np] = nc
        commit(lassos.map { if (it === orig) np else it })
        selPath = np
        selC = ci
        selP = newSelP
    }

    fun hitHandle(pos: Offset): Hit? {
        var best: Hit? = null
        var bestD = 24f * density
        for (lp in lassos) {
            val ct = ctrlOf(lp)
            for (ci in ct.contours.indices) {
                val pts = ct.contours[ci]
                for (pi in pts.indices) {
                    val q = pts[pi]
                    val d = (Offset(q.x * vs + off.x, q.y * vs + off.y) - pos).getDistance()
                    if (d < bestD) {
                        bestD = d
                        best = Hit(lp, ci, pi)
                    }
                }
            }
        }
        return best
    }

    /** หาเส้นขอบบ่วงที่ใกล้ตำแหน่งนิ้วที่สุด (ภายใน radius พิกเซลจอ): คืนบ่วง เส้นขอบ ช่วงที่ต้องแทรกต่อท้าย และจุดบนเส้น (พิกัดภาพ) */
    fun findEdge(pos: Offset, radius: Float): EdgeHit? {
        var bestD = radius
        var best: EdgeHit? = null
        for (lp in lassos) {
            val ct = ctrlOf(lp)
            for (ci in ct.contours.indices) {
                val d = PathMath.dense(ct.contours[ci], ct.smooth, true)
                for (i in 0 until d.pts.size - 1) {
                    val a = d.pts[i]
                    val b = d.pts[i + 1]
                    val proj = projectOnSegment(
                        pos,
                        Offset(a.x * vs + off.x, a.y * vs + off.y),
                        Offset(b.x * vs + off.x, b.y * vs + off.y),
                    )
                    val dist = (pos - proj).getDistance()
                    if (dist < bestD) {
                        bestD = dist
                        best = EdgeHit(lp, ci, d.seg[i], Offset((proj.x - off.x) / vs, (proj.y - off.y) / vs))
                    }
                }
            }
        }
        return best
    }

    /** แตะใกล้เส้นขอบบ่วง = แทรกจุดควบคุมบนเส้นตรงนั้น (คืน false ถ้าไม่ได้แตะใกล้เส้น) */
    fun insertPointAt(pos: Offset): Boolean {
        val e = findEdge(pos, 20f * density) ?: return false
        val list = ctrlOf(e.path).contours[e.c].toMutableList()
        list.add(e.seg + 1, e.pt)
        replaceContour(e.path, e.c, list, e.seg + 1)
        return true
    }

    /**
     * โหมด "เพิ่มจุด": แตะที่ไหน จุดใหม่ก็ขึ้น ณ ตำแหน่งนิ้วตรงนั้น (แทรกในช่วงของเส้นบ่วงที่ใกล้นิ้วที่สุด) แล้วลากต่อเพื่อวางได้เลย
     * ยังไม่บันทึกลงประวัติ: ปล่อยนิ้วแล้วจึงบันทึกครั้งเดียว (ย้อนกลับครั้งเดียวได้ทั้งเพิ่ม+ย้าย)
     */
    fun beginAddAtFinger(pos: Offset): Hit? {
        val e = findEdge(pos, 60f * density) ?: return null
        val ct = ctrlOf(e.path)
        val list = ct.contours[e.c].toMutableList()
        list.add(e.seg + 1, toImg(pos))
        val nc = Ctrl(ct.contours.mapIndexed { i, l -> if (i == e.c) list else l }, ct.smooth, ct.fillType)
        bendDrag = BendDrag(e.path, nc, buildPath(nc))
        return Hit(e.path, e.c, e.seg + 1)
    }

    /** ปุ่ม "ลบจุด": ลบจุดควบคุมที่เลือก (ต้องเหลืออย่างน้อย 3 จุด) */
    fun deleteSelectedPoint() {
        val sp = selValid() ?: return
        val pts = ctrlOf(sp).contours.getOrNull(selC) ?: return
        if (pts.size <= 3 || selP !in pts.indices) {
            Toast.makeText(context, "ต้องเหลืออย่างน้อย 3 จุด", Toast.LENGTH_SHORT).show()
            return
        }
        replaceContour(sp, selC, pts.toMutableList().also { it.removeAt(selP) }, 0)
        selPath = null
    }

    /** ปุ่ม "โค้งเนียน": สลับบ่วงที่เลือกระหว่างต่อจุดเป็นเส้นตรง / เส้นโค้งเนียน */
    fun toggleSmooth() {
        val sp = selValid() ?: return
        val ct = ctrlOf(sp)
        val nc = Ctrl(ct.contours, !ct.smooth, ct.fillType)
        val np = buildPath(nc)
        ctrlCache[np] = nc
        commit(lassos.map { if (it === sp) np else it })
        selPath = np
    }

    fun finishStroke(pts: List<Offset>, travel: Float, tapAt: Offset) {
        if (mode == CropMode.REMOVE && travel < MIN_STROKE_TRAVEL) {
            // แตะในบ่วง = ลบทั้งบ่วง
            val p = toImg(tapAt)
            val hit = lassos.lastOrNull { pathContains(it, p, bw, bh) }
            if (hit != null) commit(lassos.filter { it !== hit })
            return
        }
        if (pts.size < 3 || travel < MIN_STROKE_TRAVEL) return
        val path = Path()
        path.moveTo(pts[0].x, pts[0].y)
        for (i in 1 until pts.size) path.lineTo(pts[i].x, pts[i].y)
        path.close()
        if (!hasArea(path)) return
        commit(if (mode == CropMode.ADD) addLasso(lassos, path) else subtractLasso(lassos, path))
    }

    fun confirm() {
        if (busy) return
        val current = lassos
        val src = work
        if (current.isEmpty()) {
            onConfirm(src, 0, 0) // ไม่วาดบ่วง = ใช้ทั้งภาพ (รวมส่วนที่ลบด้วยยางลบแล้ว)
            return
        }
        scope.launch {
            busy = true
            val r = withContext(Dispatchers.Default) { runCatching { cropByLassosAt(src, current) } }
            busy = false
            r.onSuccess { out ->
                if (out == null) {
                    Toast.makeText(context, "บ่วงอยู่นอกภาพ ลองวาดใหม่", Toast.LENGTH_SHORT).show()
                } else {
                    onConfirm(out.bmp, out.left, out.top)
                }
            }.onFailure {
                Toast.makeText(context, "ตัดภาพไม่สำเร็จ: ${it.message ?: it.javaClass.simpleName}", Toast.LENGTH_LONG).show()
            }
        }
    }

    // ข้อความบอกวิธีใช้: อ่านจาก "กำลังแตะอยู่ไหม" อย่างเดียว (ไม่อ่านตำแหน่งนิ้ว) ไม่งั้นทั้งหน้าจะคำนวณใหม่ทุกครั้งที่นิ้วขยับ = กระตุก
    val touching by remember { derivedStateOf { touch != null } }
    // เส้นบ่วงในพิกัดจอ: คำนวณใหม่เฉพาะเมื่อบ่วง/ซูม/เลื่อนเปลี่ยน ไม่คำนวณทุกเฟรมของการวาด
    val baseScreen = remember(lassos, vs, off) { lassos.map { toScreen(it) } }

    BackHandler(onBack = { if (!busy) onCancel() })

    // ── อุปกรณ์วาด ──
    val dash = 8f * density
    val antWhite = remember(density) {
        Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.STROKE
            color = android.graphics.Color.WHITE
            strokeWidth = 1.5f * density
            strokeJoin = Paint.Join.ROUND
        }
    }
    val antBlack = remember(density) {
        Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.STROKE
            color = android.graphics.Color.BLACK
            strokeWidth = 1.5f * density
            strokeJoin = Paint.Join.ROUND
        }
    }
    val erStroke = remember { // ยางลบ: ลบพิกเซลให้โปร่งใส (ขอบนุ่มด้วย anti-alias ขนาดทศนิยมเล็กกว่า 1 พิกเซลก็ลบจางๆ ได้)
        Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.STROKE
            strokeCap = Paint.Cap.ROUND
            xfermode = PorterDuffXfermode(PorterDuff.Mode.CLEAR)
        }
    }
    val erFill = remember {
        Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.FILL
            xfermode = PorterDuffXfermode(PorterDuff.Mode.CLEAR)
        }
    }
    val ringWhite = remember(density) {
        Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; color = android.graphics.Color.WHITE; strokeWidth = 1f * density }
    }
    val ringBlack = remember(density) {
        Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; color = android.graphics.Color.BLACK; strokeWidth = 2.2f * density }
    }
    val dimPaint = remember { Paint().apply { color = 0x99000000.toInt() } }
    val bmpPaint = remember { Paint(Paint.FILTER_BITMAP_FLAG or Paint.ANTI_ALIAS_FLAG) }
    val checkerPaint = remember(density) {
        val s = max(1, (8f * density).toInt())
        val bm = Bitmap.createBitmap(s * 2, s * 2, Bitmap.Config.ARGB_8888)
        val c = android.graphics.Canvas(bm)
        c.drawColor(0xFFB8B8C0.toInt())
        val p = Paint().apply { color = 0xFF8E8E98.toInt() }
        c.drawRect(0f, 0f, s.toFloat(), s.toFloat(), p)
        c.drawRect(s.toFloat(), s.toFloat(), s * 2f, s * 2f, p)
        Paint().apply { shader = BitmapShader(bm, Shader.TileMode.REPEAT, Shader.TileMode.REPEAT) }
    }
    val loupeWhite = remember { Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; color = android.graphics.Color.WHITE; strokeJoin = Paint.Join.ROUND } }
    val loupeBlack = remember { Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; color = android.graphics.Color.BLACK; strokeJoin = Paint.Join.ROUND } }
    val loupeBg = remember { Paint().apply { color = 0xFF1E1E26.toInt() } }
    val loupeBorder = remember(density) {
        Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.STROKE
            color = android.graphics.Color.WHITE
            strokeWidth = 2f * density
        }
    }
    val crossPaint = remember(density) {
        Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.STROKE
            color = 0xFFFF1744.toInt()
            strokeWidth = 1.5f * density
        }
    }
    val hFill = remember { Paint(Paint.ANTI_ALIAS_FLAG).apply { color = android.graphics.Color.WHITE } }
    val hStroke = remember(density) {
        Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.STROKE
            color = 0xFFB69DFF.toInt()
            strokeWidth = 2.5f * density
        }
    }
    val hSel = remember(density) {
        Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.STROKE
            color = 0xFFFF80AB.toInt()
            strokeWidth = 3.5f * density
        }
    }
    val ants = rememberInfiniteTransition(label = "ants")
    val phase by ants.animateFloat(
        initialValue = 0f,
        targetValue = dash * 2f,
        animationSpec = infiniteRepeatable(tween(900, easing = LinearEasing), RepeatMode.Restart),
        label = "antsPhase",
    )

    Column(
        Modifier
            .fillMaxSize()
            .background(Palette.Bg)
            .systemBarsPadding()
            .pointerInput(Unit) { detectTapGestures { } }, // กันการสัมผัสทะลุไปหน้าด้านล่าง
    ) {
        Box(Modifier.weight(1f).fillMaxWidth().background(Color(0xFF2A2A34))) {
            Canvas(
                Modifier
                    .fillMaxSize()
                    .onSizeChanged { canvasSize = it }
                    .pointerInput(mode) {
                        awaitEachGesture {
                            val down = awaitFirstDown(requireUnconsumed = false)
                            var drawing = true
                            var travel = 0f
                            var last = down.position
                            val bend = mode == CropMode.BEND
                            val erase = mode == CropMode.ERASE
                            var eOld: Bitmap? = null // ภาพก่อนเริ่มลบ (ไว้ย้อนกลับ/ยกเลิก)
                            var eCanvas: android.graphics.Canvas? = null
                            var ePrev = Offset.Zero
                            var hit: Hit? = null
                            var gap = Offset.Zero // ระยะจากนิ้วถึงจุดที่จับ (กันจุดกระโดดมาอยู่ใต้นิ้ว)
                            live.clear()
                            if (erase) { // ยางลบ: ทำสำเนาภาพแล้วลบบนสำเนา (ปล่อยนิ้วค่อยบันทึกเป็น 1 ขั้นย้อนกลับ)
                                val sb = runCatching { work.copy(Bitmap.Config.ARGB_8888, true) }.getOrNull()
                                if (sb == null) {
                                    drawing = false
                                    Toast.makeText(context, "หน่วยความจำไม่พอสำหรับยางลบ", Toast.LENGTH_SHORT).show()
                                } else {
                                    sb.setHasAlpha(true)
                                    val cv = android.graphics.Canvas(sb)
                                    eOld = work
                                    eCanvas = cv
                                    ePrev = toImgRaw(down.position)
                                    cv.drawCircle(ePrev.x, ePrev.y, max(eraserSize, 0.01f) / 2f, erFill)
                                    work = sb
                                    workVer++
                                    touch = down.position
                                    lensImg = ePrev
                                }
                            } else if (bend) { // โหมดดัดโค้ง: แตะโดนจุดควบคุม = เลือกและลากจุดนั้น
                                hit = hitHandle(down.position)
                                if (hit == null && addPtMode) {
                                    hit = beginAddAtFinger(down.position) // เพิ่มจุดใหม่ใต้นิ้ว แล้วลากต่อได้เลย
                                    if (hit != null) {
                                        touch = down.position
                                        lensImg = toImg(down.position)
                                    }
                                }
                                val h0 = hit
                                if (h0 != null) {
                                    selPath = h0.path
                                    selC = h0.c
                                    selP = h0.p
                                    val q = (bendDrag?.ctrl ?: ctrlOf(h0.path)).contours[h0.c][h0.p]
                                    gap = Offset(q.x * vs + off.x, q.y * vs + off.y) - down.position
                                }
                            } else {
                                live.add(toImg(down.position))
                            }
                            do {
                                val event = awaitPointerEvent()
                                val pressedCount = event.changes.count { it.pressed }
                                if (pressedCount >= 2) {
                                    // 2 นิ้ว = ซูม/เลื่อนภาพ (ยกเลิกบ่วงที่กำลังวาดอยู่)
                                    if (drawing) {
                                        drawing = false
                                        if (erase) { // ยกเลิกรอยลบที่กำลังลาก (เปลี่ยนเป็นซูมแทน)
                                            eOld?.let { work = it }
                                            eCanvas = null
                                            workVer++
                                        }
                                        live.clear()
                                        bendDrag = null // ยกเลิกการลากจุดที่ค้างอยู่
                                        touch = null
                                        lensImg = null
                                    }
                                    val zoom = event.calculateZoom()
                                    val pan = event.calculatePan()
                                    val c = event.calculateCentroid()
                                    val f = fitScale()
                                    val s0 = vs
                                    val s1 = (s0 * zoom).coerceIn(f * 0.5f, f * 20f)
                                    val k = s1 / s0
                                    off = Offset(
                                        c.x - (c.x - off.x) * k + pan.x,
                                        c.y - (c.y - off.y) * k + pan.y,
                                    )
                                    vs = s1
                                    event.changes.forEach { if (it.positionChanged()) it.consume() }
                                } else if (drawing) {
                                    val ch = event.changes.firstOrNull { it.pressed }
                                    if (ch != null && erase) {
                                        val cv = eCanvas
                                        if (cv != null) {
                                            val np = toImgRaw(ch.position)
                                            if ((np - ePrev).getDistance() > 0f) {
                                                erStroke.strokeWidth = max(eraserSize, 0.01f)
                                                cv.drawLine(ePrev.x, ePrev.y, np.x, np.y, erStroke)
                                                ePrev = np
                                                workVer++
                                            }
                                            touch = ch.position
                                            lensImg = np
                                        }
                                        ch.consume()
                                    } else if (ch != null) {
                                        val d = (ch.position - last).getDistance()
                                        val addLive = d >= 3f // จุดของบ่วงเก็บทุก 3 พิกเซล แต่ตำแหน่งแว่นขยาย/จุดที่ลากอัปเดตทุกครั้งที่นิ้วขยับ (ลื่น ไม่เป็นช่วงๆ)
                                        if (addLive) {
                                            travel += d
                                            last = ch.position
                                        }
                                        if (travel >= 3f) {
                                            touch = ch.position
                                            if (bend) {
                                                val hh = hit
                                                if (hh != null) { // ลากจุดควบคุม: ดูตัวอย่างทันที ยังไม่บันทึกลงประวัติจนกว่าจะปล่อยนิ้ว
                                                    val ct0 = bendDrag?.ctrl ?: ctrlOf(hh.path)
                                                    val np0 = toImg(ch.position + gap)
                                                    val list = ct0.contours[hh.c].toMutableList()
                                                    list[hh.p] = np0
                                                    val nc2 = Ctrl(ct0.contours.mapIndexed { i, l -> if (i == hh.c) list else l }, ct0.smooth, ct0.fillType)
                                                    bendDrag = BendDrag(hh.path, nc2, buildPath(nc2))
                                                    lensImg = np0
                                                }
                                            } else {
                                                val np1 = toImg(ch.position)
                                                if (addLive) live.add(np1)
                                                lensImg = np1
                                            }
                                        }
                                        ch.consume()
                                    }
                                }
                            } while (event.changes.any { it.pressed })

                            if (drawing) {
                                if (erase) {
                                    val eo = eOld
                                    if (eo != null && eCanvas != null) { // ปล่อยนิ้ว: บันทึกรอยลบเป็น 1 ขั้น
                                        undoStack = trimHistory(undoStack + Snap(lassos, eo))
                                        redoStack = emptyList()
                                    }
                                } else if (bend) {
                                    val hh = hit
                                    val bd = bendDrag
                                    if (hh != null) {
                                        if (bd != null) { // ปล่อยนิ้ว: บันทึกบ่วงที่ดัดแล้วลงประวัติ (ย้อนกลับได้)
                                            ctrlCache[bd.preview] = bd.ctrl
                                            commit(lassos.map { if (it === hh.path) bd.preview else it })
                                            selPath = bd.preview
                                        }
                                    } else if (travel < MIN_STROKE_TRAVEL) { // แตะที่ว่าง: แตะใกล้เส้นบ่วง = แทรกจุด ไม่ใช่ = เลิกเลือก
                                        if (!insertPointAt(down.position)) selPath = null
                                    }
                                } else {
                                    val pts = live.toList()
                                    live.clear()
                                    finishStroke(pts, travel, down.position)
                                }
                            } else {
                                live.clear()
                            }
                            bendDrag = null
                            touch = null
                            lensImg = null
                        }
                    },
            ) {
                if (canvasSize.width == 0) return@Canvas
                @Suppress("UNUSED_VARIABLE") val ver = workVer // อ่านไว้เพื่อให้วาดใหม่ทุกครั้งที่ยางลบแก้ภาพ
                val dst = RectF(off.x, off.y, off.x + bw * vs, off.y + bh * vs)
                if (touching) {
                    // ระหว่างลากนิ้ว: หยุดเส้นปะวิ่งแต่ยังเป็นเส้นปะขาว-ดำสลับกันพอดี (ไม่ใช้เส้นขาวซ้อนเส้นดำที่ขอบขาวจางๆ โผล่รอบเส้น) และไม่อ่านค่า phase
                    antWhite.pathEffect = DashPathEffect(floatArrayOf(dash, dash), 0f)
                    antBlack.pathEffect = DashPathEffect(floatArrayOf(dash, dash), dash)
                } else {
                    antWhite.pathEffect = DashPathEffect(floatArrayOf(dash, dash), phase)
                    antBlack.pathEffect = DashPathEffect(floatArrayOf(dash, dash), phase + dash)
                }
                drawIntoCanvas { c ->
                    val nc = c.nativeCanvas
                    nc.drawRect(dst, checkerPaint)
                    nc.drawBitmap(work, null, dst, bmpPaint)

                    val bd = bendDrag
                    val screenLassos = if (bd == null) baseScreen else lassos.mapIndexed { i, lp -> if (lp === bd.orig) toScreen(bd.preview) else baseScreen[i] }
                    if (screenLassos.isNotEmpty()) {
                        // ทำให้ส่วนนอกบ่วงมืดลง เพื่อเห็นชัดว่าส่วนไหนจะถูกเก็บไว้
                        nc.save()
                        for (sp in screenLassos) nc.clipOutPath(sp)
                        nc.drawRect(dst, dimPaint)
                        nc.restore()
                    }
                    for (sp in screenLassos) {
                        nc.drawPath(sp, antWhite)
                        nc.drawPath(sp, antBlack)
                    }
                    if (live.size >= 2) { // เส้นที่กำลังวาด: ใช้เส้นปะแบบเดียวกัน
                        val lp = Path()
                        live.forEachIndexed { i, o ->
                            val x = o.x * vs + off.x
                            val y = o.y * vs + off.y
                            if (i == 0) lp.moveTo(x, y) else lp.lineTo(x, y)
                        }
                        lp.close()
                        nc.drawPath(lp, antWhite)
                        nc.drawPath(lp, antBlack)
                    }
                    if (mode == CropMode.BEND) { // จุดควบคุมของทุกบ่วง (จุดที่เลือกเป็นสีชมพู)
                        for (lp in lassos) {
                            val ct = if (bd != null && lp === bd.orig) bd.ctrl else ctrlOf(lp)
                            ct.contours.forEachIndexed { ci, pts ->
                                pts.forEachIndexed { pi, q ->
                                    val sel = lp === selPath && ci == selC && pi == selP
                                    val x = q.x * vs + off.x
                                    val y = q.y * vs + off.y
                                    nc.drawCircle(x, y, (if (sel) 9f else 7f) * density, hFill)
                                    nc.drawCircle(x, y, (if (sel) 9f else 7f) * density, if (sel) hSel else hStroke)
                                }
                            }
                        }
                    }

                    val rt = touch
                    if (mode == CropMode.ERASE && rt != null) { // วงบอกขนาดยางลบใต้นิ้ว
                        val rr = max(eraserSize * vs / 2f, 2f * density)
                        nc.drawCircle(rt.x, rt.y, rr, ringBlack)
                        nc.drawCircle(rt.x, rt.y, rr, ringWhite)
                    }

                    // จออีกจอขนาดเล็ก (แว่นขยาย) ระหว่างลากนิ้ว: ขยายบริเวณรอบจุดที่กำลังวาด/ลาก ย้ายไปมุมอื่นเองเมื่อนิ้วเข้าใกล้
                    val lt = touch
                    val lf = lensImg
                    if (lt != null && lf != null) {
                        val sizePx = 130f * density
                        val mg = 8f * density
                        val cw = canvasSize.width.toFloat()
                        val chh = canvasSize.height.toFloat()
                        val cands = listOf(
                            RectF(mg, mg, mg + sizePx, mg + sizePx),
                            RectF(cw - mg - sizePx, mg, cw - mg, mg + sizePx),
                            RectF(mg, chh - mg - sizePx, mg + sizePx, chh - mg),
                            RectF(cw - mg - sizePx, chh - mg - sizePx, cw - mg, chh - mg),
                        )
                        val clear = 56f * density
                        val box = cands.firstOrNull { r ->
                            lt.x < r.left - clear || lt.x > r.right + clear || lt.y < r.top - clear || lt.y > r.bottom + clear
                        } ?: cands[0]
                        val k = max(vs, min(vs * 3f, 12f)) // ขยาย 3 เท่าของมุมมองตอนนี้ (ไม่เกิน 12 เท่าของพิกเซลภาพ)
                        val lm = Matrix()
                        lm.setTranslate(-lf.x, -lf.y)
                        lm.postScale(k, k)
                        lm.postTranslate(box.centerX(), box.centerY())
                        val clipP = Path()
                        clipP.addRoundRect(box, 14f * density, 14f * density, Path.Direction.CW)
                        nc.save()
                        nc.clipPath(clipP)
                        nc.drawRect(box, loupeBg)
                        val imgR = RectF(0f, 0f, bw.toFloat(), bh.toFloat())
                        lm.mapRect(imgR)
                        nc.drawRect(imgR, checkerPaint)
                        nc.save()
                        nc.concat(lm) // ต่อจากนี้วาดด้วยพิกัดภาพตรงๆ ไม่ต้องสร้าง Path ใหม่ทุกเฟรม (ลื่นขึ้น)
                        val half = (sizePx / 2f) / k + 2f
                        val src = Rect(
                            floor(lf.x - half).toInt().coerceIn(0, bw),
                            floor(lf.y - half).toInt().coerceIn(0, bh),
                            ceil(lf.x + half).toInt().coerceIn(0, bw),
                            ceil(lf.y + half).toInt().coerceIn(0, bh),
                        )
                        if (src.width() > 0 && src.height() > 0) nc.drawBitmap(work, src, RectF(src), bmpPaint) // วาดเฉพาะส่วนที่เห็นในจอเล็ก
                        loupeBlack.strokeWidth = 3f * density / k
                        loupeWhite.strokeWidth = 1.5f * density / k
                        for (lp in lassos) {
                            val q = if (bd != null && lp === bd.orig) bd.preview else lp
                            nc.drawPath(q, loupeBlack)
                            nc.drawPath(q, loupeWhite)
                        }
                        if (mode == CropMode.ERASE) { // วงขนาดยางลบในแว่นขยาย
                            val er = max(eraserSize / 2f, 1.5f * density / k)
                            nc.drawCircle(lf.x, lf.y, er, loupeBlack)
                            nc.drawCircle(lf.x, lf.y, er, loupeWhite)
                        }
                        if (live.size >= 2) {
                            val lq = Path()
                            val from = max(0, live.size - 150) // เห็นแค่ช่วงปลายเส้น จึงวาดเฉพาะจุดล่าสุด
                            for (i in from until live.size) {
                                val o = live[i]
                                if (i == from) lq.moveTo(o.x, o.y) else lq.lineTo(o.x, o.y)
                            }
                            nc.drawPath(lq, loupeBlack)
                            nc.drawPath(lq, loupeWhite)
                        }
                        nc.restore()
                        if (mode == CropMode.BEND) {
                            for (lp in lassos) {
                                val ct = if (bd != null && lp === bd.orig) bd.ctrl else ctrlOf(lp)
                                ct.contours.forEachIndexed { ci, pts ->
                                    pts.forEachIndexed { pi, q ->
                                        val sel = lp === selPath && ci == selC && pi == selP
                                        val arr = floatArrayOf(q.x, q.y)
                                        lm.mapPoints(arr)
                                        nc.drawCircle(arr[0], arr[1], (if (sel) 7f else 5f) * density, hFill)
                                        nc.drawCircle(arr[0], arr[1], (if (sel) 7f else 5f) * density, if (sel) hSel else hStroke)
                                    }
                                }
                            }
                        }
                        val cx0 = box.centerX()
                        val cy0 = box.centerY()
                        val arm = 9f * density
                        nc.drawLine(cx0 - arm, cy0, cx0 + arm, cy0, crossPaint) // กากบาทแดง = จุดที่กำลังวาด/ลากอยู่พอดี
                        nc.drawLine(cx0, cy0 - arm, cx0, cy0 + arm, crossPaint)
                        nc.restore()
                        nc.drawPath(clipP, loupeBorder)
                    }
                }
            }

            val hint = when {
                mode == CropMode.ERASE -> "ยางลบ: ลากนิ้วลบส่วนของภาพ · แตะช่องขนาดด้านล่างเพื่อใส่ขนาด · 2 นิ้ว = ซูม/เลื่อน"
                mode == CropMode.BEND && addPtMode && lassos.isNotEmpty() -> "เพิ่มจุด: แตะตรงตำแหน่งที่ต้องการ จุดจะขึ้นใต้นิ้ว ลากต่อเพื่อวางแล้วปล่อย · กด \"เพิ่มจุด\" อีกครั้งเพื่อกลับไปดัด"
                mode == CropMode.BEND && lassos.isEmpty() -> "ดัดโค้ง: ยังไม่มีบ่วง วาดบ่วงในโหมด \"เพิ่มบ่วง\" ก่อน"
                mode == CropMode.BEND -> "ดัดโค้ง: ลากจุดเพื่อดัดบ่วง · แตะที่เส้นบ่วงเพื่อแทรกจุด · แตะจุดแล้วกด \"ลบจุด\" · 2 นิ้ว = ซูม"
                mode == CropMode.REMOVE -> "ลบบ่วง: แตะในบ่วงเพื่อลบทั้งบ่วง · หรือวาดบ่วงทับเพื่อลบเฉพาะส่วน"
                lassos.isEmpty() -> "ลากนิ้ววาดบ่วงรอบส่วนที่ต้องการ · ไม่วาด = ใช้ทั้งภาพ · 2 นิ้ว = ซูม"
                else -> "เพิ่มบ่วง: บ่วงที่วาดทับกันจะรวมเป็นบ่วงเดียว · 2 นิ้ว = ซูม/เลื่อน"
            }
            if (!touching) { // ระหว่างลากนิ้วซ่อนข้อความไว้ ไม่ให้บังภาพและแว่นขยาย
                Box(
                    Modifier
                        .align(Alignment.TopCenter)
                        .padding(8.dp)
                        .clip(RoundedCornerShape(12.dp))
                        .background(Color(0xFFFFD600))
                        .padding(horizontal = 12.dp, vertical = 6.dp),
                ) { Text(hint, color = Color.Black, fontSize = 13.sp) }
            }
        }

        Column(
            Modifier.fillMaxWidth().background(Palette.Panel).padding(horizontal = 8.dp, vertical = 8.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            if (mode == CropMode.BEND) { // ปุ่มของโหมดดัดโค้ง (แยกแถวไว้ให้เห็นครบโดยไม่ต้องเลื่อน)
                val sp = selValid()
                val selPts = if (sp != null) ctrlOf(sp).contours.getOrNull(selC)?.size ?: 0 else 0
                Row(
                    Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    FilterChip(
                        selected = addPtMode,
                        onClick = { addPtMode = !addPtMode },
                        enabled = lassos.isNotEmpty() && !busy,
                        label = { Text("＋ เพิ่มจุด") },
                        modifier = Modifier.weight(1f).heightIn(min = 48.dp),
                    )
                    OutlinedButton(
                        onClick = { deleteSelectedPoint() },
                        enabled = sp != null && selPts > 3 && !busy,
                        modifier = Modifier.weight(1f).heightIn(min = 48.dp),
                    ) { Text("✕ ลบจุด") }
                    FilterChip(
                        selected = sp != null && ctrlOf(sp).smooth,
                        onClick = { toggleSmooth() },
                        enabled = sp != null && !busy,
                        label = { Text("โค้งเนียน") },
                        modifier = Modifier.weight(1f).heightIn(min = 48.dp),
                    )
                }
            }
            if (mode == CropMode.ERASE) { // ช่องขนาดยางลบ: แตะแล้วขึ้นแผงตัวเลข (ไม่ต้องเปิดแป้นพิมพ์)
                Row(
                    Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Text("ขนาดยางลบ", color = Color(0xFFC9C4D4), fontSize = 14.sp)
                    Box(
                        Modifier
                            .weight(1f)
                            .heightIn(min = 48.dp)
                            .clip(RoundedCornerShape(14.dp))
                            .background(Palette.PanelHigh)
                            .border(1.dp, Palette.Accent, RoundedCornerShape(14.dp))
                            .clickable(enabled = !busy) { showPad = true }
                            .padding(horizontal = 14.dp),
                        contentAlignment = Alignment.CenterStart,
                    ) { Text("${fmtNum(eraserSize)} px  ✎", color = Color.White, fontSize = 17.sp, fontWeight = FontWeight.Medium) }
                }
            }
            Row(
                Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                FilterChip(
                    selected = mode == CropMode.ADD,
                    onClick = { mode = CropMode.ADD },
                    label = { Text("เพิ่มบ่วง") },
                    modifier = Modifier.heightIn(min = 48.dp),
                )
                FilterChip(
                    selected = mode == CropMode.REMOVE,
                    onClick = { mode = CropMode.REMOVE },
                    label = { Text("ลบบ่วง") },
                    modifier = Modifier.heightIn(min = 48.dp),
                )
                FilterChip(
                    selected = mode == CropMode.BEND,
                    onClick = { mode = CropMode.BEND },
                    label = { Text("ดัดโค้ง") },
                    modifier = Modifier.heightIn(min = 48.dp),
                )
                FilterChip(
                    selected = mode == CropMode.ERASE,
                    onClick = { mode = CropMode.ERASE },
                    label = { Text("ยางลบ") },
                    modifier = Modifier.heightIn(min = 48.dp),
                )
                OutlinedButton(
                    onClick = { undo() },
                    enabled = undoStack.isNotEmpty() && !busy,
                    modifier = Modifier.heightIn(min = 48.dp),
                ) { Text("↶ ย้อนกลับ") }
                OutlinedButton(
                    onClick = { redo() },
                    enabled = redoStack.isNotEmpty() && !busy,
                    modifier = Modifier.heightIn(min = 48.dp),
                ) { Text("↷ ทำซ้ำ") }
                OutlinedButton(
                    onClick = { fitView() },
                    modifier = Modifier.heightIn(min = 48.dp),
                ) { Text("พอดีจอ") }
            }
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(
                    onClick = { onCancel() },
                    enabled = !busy,
                    modifier = Modifier.weight(1f).heightIn(min = 48.dp),
                ) { Text("ยกเลิก") }
                Button(
                    onClick = { confirm() },
                    enabled = !busy,
                    modifier = Modifier.weight(1f).heightIn(min = 48.dp),
                ) { Text(if (busy) "กำลังตัด…" else "ตกลง ✓") }
            }
        }

        if (showPad) {
            NumberPadDialog(
                title = "ขนาดยางลบ",
                unit = "px",
                initial = eraserSize,
                onDismiss = { showPad = false },
                onOk = { v ->
                    eraserSize = v
                    showPad = false
                },
            )
        }
    }
}

/** แผงตัวเลขของแอป (ไม่ใช้แป้นพิมพ์ระบบ): 123 / 456 / 789 / ลบ 0 . ตกลง รองรับจุดทศนิยม */
@Composable
private fun NumberPadDialog(title: String, unit: String, initial: Float, onDismiss: () -> Unit, onOk: (Float) -> Unit) {
    val context = LocalContext.current
    var s by remember { mutableStateOf(fmtNum(initial)) }
    var fresh by remember { mutableStateOf(true) } // แตะเลขแรก = แทนที่ค่าเดิมทั้งหมด

    fun digit(d: String) {
        if (fresh) {
            s = d
            fresh = false
        } else if (s == "0") {
            s = d
        } else if (s.length < 9) {
            s += d
        }
    }

    fun dot() {
        if (fresh) {
            s = "0."
            fresh = false
        } else if (!s.contains('.') && s.length < 9) {
            s = if (s.isEmpty()) "0." else "$s."
        }
    }

    fun back() {
        fresh = false
        s = s.dropLast(1)
    }

    fun ok() {
        val v = s.toFloatOrNull()
        if (v == null || v <= 0f) {
            Toast.makeText(context, "ใส่ตัวเลขที่มากกว่า 0", Toast.LENGTH_SHORT).show()
        } else {
            onOk(v)
        }
    }

    Dialog(onDismissRequest = onDismiss, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        Column(
            Modifier
                .fillMaxWidth(0.88f)
                .widthIn(max = 340.dp)
                .clip(RoundedCornerShape(26.dp))
                .background(Palette.Panel)
                .border(1.dp, Palette.Stroke, RoundedCornerShape(26.dp))
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp),
        ) {
            Text(title, color = Color(0xFFC9C4D4), fontSize = 15.sp)
            Row(
                Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(16.dp))
                    .background(Palette.Bg)
                    .border(1.dp, Palette.Accent, RoundedCornerShape(16.dp))
                    .padding(horizontal = 16.dp, vertical = 14.dp),
                horizontalArrangement = Arrangement.End,
                verticalAlignment = Alignment.Bottom,
            ) {
                Text(s.ifEmpty { "0" }, color = Color.White, fontSize = 36.sp, fontWeight = FontWeight.Bold, maxLines = 1)
                Text("  $unit", color = Color(0xFF9E9AB0), fontSize = 16.sp, modifier = Modifier.padding(bottom = 6.dp))
            }
            val keyBg = Palette.PanelHigh
            val keyFg = Color.White
            for (row in listOf(listOf("1", "2", "3"), listOf("4", "5", "6"), listOf("7", "8", "9"))) {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    for (k in row) PadKey(k, keyBg, keyFg) { digit(k) }
                }
            }
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                PadKey("ลบ", Color(0xFF4A2630), Color(0xFFFF8A80)) { back() }
                PadKey("0", keyBg, keyFg) { digit("0") }
                PadKey(".", keyBg, keyFg) { dot() }
                PadKey("ตกลง", Palette.Accent, Color(0xFF2A1A66)) { ok() }
            }
        }
    }
}

@Composable
private fun RowScope.PadKey(label: String, bg: Color, fg: Color, onClick: () -> Unit) {
    Box(
        Modifier
            .weight(1f)
            .height(60.dp)
            .clip(RoundedCornerShape(18.dp))
            .background(bg)
            .clickable(onClick = onClick),
        contentAlignment = Alignment.Center,
    ) { Text(label, color = fg, fontSize = if (label.length > 1) 17.sp else 26.sp, fontWeight = FontWeight.Medium) }
}
