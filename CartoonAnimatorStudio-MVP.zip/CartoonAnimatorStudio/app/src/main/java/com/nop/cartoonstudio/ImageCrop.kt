package com.nop.cartoonstudio

import android.graphics.Bitmap
import android.graphics.BitmapShader
import android.graphics.DashPathEffect
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PathMeasure
import android.graphics.PorterDuff
import android.graphics.PorterDuffXfermode
import android.graphics.Rect
import android.graphics.RectF
import android.graphics.Region
import android.graphics.Shader
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.gestures.calculateCentroid
import androidx.compose.foundation.gestures.calculatePan
import androidx.compose.foundation.gestures.calculateZoom
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.RowScope
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.FilterChip
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.runtime.withFrameNanos
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.drawIntoCanvas
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.input.pointer.positionChanged
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import kotlin.math.ceil
import kotlin.math.floor
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min
import java.util.IdentityHashMap
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

private enum class CropMode { ADD, REMOVE, BEND, ERASE, JOY }

/** ยางลบลบอะไร: ภาพทั้งภาพ / เฉพาะภาพในบ่วง / เส้นบ่วงและจุดโค้งที่ยางลบลากผ่าน */
private enum class EraseTarget { IMAGE, INSIDE, LINES }

/** แผงตัวเลขที่เปิดอยู่ตอนนี้ใช้ใส่ค่าอะไร */
private enum class PadTarget { NONE, ERASER, JOY_SPEED }

/** รูปที่เพิ่มเข้ามาซ้อนบนภาพที่กำลังแก้ (cx,cy = กึ่งกลางรูปในพิกัดภาพ, scale = ขนาดรูปเทียบพิกเซลภาพ) รอลาก/ย่อขยายแล้วกดวาง */
private data class Overlay(val bmp: Bitmap, val cx: Float, val cy: Float, val scale: Float)

/** สถานะ 1 ขั้นของประวัติ (ย้อนกลับ/ทำซ้ำ): บ่วง + ภาพที่ถูกลบด้วยยางลบแล้ว (บิตแมปที่ไม่เปลี่ยนใช้ตัวเดียวกันร่วมกัน) */
private class Snap(val lassos: List<Path>, val bmp: Bitmap)

/** จำนวนขั้นย้อนกลับที่เก็บภาพคนละใบได้สูงสุด (ภาพแต่ละใบกินหน่วยความจำ จึงจำกัดไว้) */
private const val MAX_BITMAP_HISTORY = 12

private fun trimHistory(list: List<Snap>): List<Snap> {
    val l = list.takeLast(MAX_HISTORY)
    val seen = java.util.Collections.newSetFromMap(IdentityHashMap<Bitmap, Boolean>())
    var cut = 0
    for (i in l.indices.reversed()) {
        seen.add(l[i].bmp)
        if (seen.size > MAX_BITMAP_HISTORY) {
            cut = i + 1
            break
        }
    }
    return if (cut > 0) l.drop(cut) else l
}

/** ตัวเลขสำหรับแสดง: ตัดศูนย์ท้ายทศนิยมทิ้ง (24.0 -> 24, 2.50 -> 2.5) */
private fun fmtNum(v: Float): String =
    runCatching { java.math.BigDecimal(v.toString()).stripTrailingZeros().toPlainString() }.getOrDefault(v.toString())

/** จุดควบคุมของบ่วง (ไว้ดัดโค้ง): contours = จุดของแต่ละเส้นขอบปิด (พิกัดภาพ), smooth = ต่อจุดเป็นเส้นโค้งเนียน, fillType = ชนิดการเติมของบ่วงเดิม (รักษารูโหว่) */
private class Ctrl(val contours: List<List<Offset>>, val smooth: Boolean, val fillType: Path.FillType)

/** จุดที่กำลังลากอยู่ตอนดัดโค้ง: orig = บ่วงเดิม, ctrl/preview = ผลระหว่างลาก (ยังไม่บันทึกลงประวัติจนกว่าจะปล่อยนิ้ว) */
private class BendDrag(val orig: Path, val ctrl: Ctrl, val preview: Path)

/** จุดควบคุมที่นิ้วแตะโดน: บ่วง path, เส้นขอบที่ c, จุดที่ p */
private class Hit(val path: Path, val c: Int, val p: Int)

/** เส้นขอบบ่วงที่ใกล้นิ้ว: seg = แทรกจุดใหม่ต่อจากจุดที่ seg, pt = จุดบนเส้น (พิกัดภาพ) */
private class EdgeHit(val path: Path, val c: Int, val seg: Int, val pt: Offset)

private fun projectOnSegment(p: Offset, a: Offset, b: Offset): Offset {
    val dx = b.x - a.x
    val dy = b.y - a.y
    val l2 = dx * dx + dy * dy
    if (l2 < 1e-9f) return a
    val t = (((p.x - a.x) * dx + (p.y - a.y) * dy) / l2).coerceIn(0f, 1f)
    return Offset(a.x + dx * t, a.y + dy * t)
}

/** ลดจำนวนจุดของเส้นด้วย Douglas-Peucker (ไม่ทำให้เส้นเรียบขึ้น จึงไม่กินซอกแคบ) */
private fun rdpOpen(pts: List<Offset>, eps: Float): List<Offset> {
    if (pts.size < 3) return pts
    val keep = BooleanArray(pts.size)
    keep[0] = true
    keep[pts.size - 1] = true
    val stack = ArrayDeque<IntArray>()
    stack.addLast(intArrayOf(0, pts.size - 1))
    while (stack.isNotEmpty()) {
        val seg = stack.removeLast()
        val a = seg[0]
        val b = seg[1]
        var maxD = 0f
        var idx = -1
        for (i in a + 1 until b) {
            val d = (pts[i] - projectOnSegment(pts[i], pts[a], pts[b])).getDistance()
            if (d > maxD) {
                maxD = d
                idx = i
            }
        }
        if (idx >= 0 && maxD > eps) {
            keep[idx] = true
            stack.addLast(intArrayOf(a, idx))
            stack.addLast(intArrayOf(idx, b))
        }
    }
    return pts.filterIndexed { i, _ -> keep[i] }
}

/** ลดจุดของเส้นขอบปิด (ได้อย่างน้อย 3 จุด และไม่เกิน ~80 จุด ให้ลากแก้ไหว) */
private fun simplifyClosed(raw: List<Offset>, eps0: Float): List<Offset> {
    var eps = eps0
    var out = rdpOpen(raw + raw[0], eps).dropLast(1)
    var guard = 0
    while (out.size > 80 && guard < 12) {
        eps *= 1.4f
        out = rdpOpen(raw + raw[0], eps).dropLast(1)
        guard++
    }
    if (out.size < 3) out = listOf(raw[0], raw[raw.size / 3], raw[raw.size * 2 / 3])
    return out
}

/** แตกบ่วง (Path) เป็นจุดควบคุมของแต่ละเส้นขอบ: เก็บแนวขอบเดิมไว้ ลดเหลือเฉพาะจุดที่จำเป็น tol = ความคลาดเคลื่อนที่ยอม (พิกเซลภาพ) */
private fun flattenToControls(p: Path, tol: Float): List<List<Offset>> {
    val pm = PathMeasure(p, true)
    val res = ArrayList<List<Offset>>()
    val pos = FloatArray(2)
    do {
        val len = pm.length
        if (len > 1f) {
            val n = (len / 2f).toInt().coerceIn(12, 800)
            val raw = ArrayList<Offset>(n)
            for (i in 0 until n) {
                pm.getPosTan(len * i / n, pos, null)
                raw.add(Offset(pos[0], pos[1]))
            }
            res.add(simplifyClosed(raw, tol))
        }
    } while (pm.nextContour())
    return res
}

/** สร้างบ่วงจากจุดควบคุม (smooth = เส้นโค้งเนียนผ่านทุกจุด ใช้สูตรเดียวกับเส้นทางเฟรม) */
private fun buildPath(c: Ctrl): Path {
    val out = Path()
    out.fillType = c.fillType
    for (pts in c.contours) {
        if (pts.size < 3) continue
        val d = PathMath.dense(pts, c.smooth, true).pts
        out.moveTo(d[0].x, d[0].y)
        for (i in 1 until d.size) out.lineTo(d[i].x, d[i].y)
        out.close()
    }
    return out
}

// ───────────────────────── ยางลบเส้นบ่วง ─────────────────────────

private fun ptSegDist(p: Offset, a: Offset, b: Offset): Float {
    val abx = b.x - a.x
    val aby = b.y - a.y
    val l2 = abx * abx + aby * aby
    val t = if (l2 == 0f) 0f else (((p.x - a.x) * abx + (p.y - a.y) * aby) / l2).coerceIn(0f, 1f)
    return hypot(p.x - (a.x + t * abx), p.y - (a.y + t * aby))
}

private fun segsCross(p1: Offset, p2: Offset, q1: Offset, q2: Offset): Boolean {
    fun cr(o: Offset, a: Offset, b: Offset) = (a.x - o.x) * (b.y - o.y) - (a.y - o.y) * (b.x - o.x)
    val d1 = cr(q1, q2, p1)
    val d2 = cr(q1, q2, p2)
    val d3 = cr(p1, p2, q1)
    val d4 = cr(p1, p2, q2)
    return ((d1 > 0f && d2 < 0f) || (d1 < 0f && d2 > 0f)) && ((d3 > 0f && d4 < 0f) || (d3 < 0f && d4 > 0f))
}

/** ระยะใกล้สุดระหว่างสองช่วงเส้น */
private fun segSegDist(p1: Offset, p2: Offset, q1: Offset, q2: Offset): Float =
    if (segsCross(p1, p2, q1, q2)) 0f
    else min(min(ptSegDist(p1, q1, q2), ptSegDist(p2, q1, q2)), min(ptSegDist(q1, p1, p2), ptSegDist(q2, p1, p2)))

/**
 * ลบเส้นขอบบ่วง (ปิด) ตรงที่ยางลบ (วงรัศมี r ลากจาก a ไป b) ผ่าน: แทรกจุดถี่ๆ บนเส้นช่วงที่ยางลบผ่าน แล้วลบจุดที่อยู่ในวงยางลบ
 * ผลคือเส้นช่วงนั้นหายไปและปลายสองข้างต่อกันด้วยเส้นตรง (บ่วงต้องปิดเสมอเพื่อใช้ตัดภาพได้)
 * คืน null ถ้ายางลบไม่โดนเส้นนี้เลย · ผลที่เหลือไม่ถึง 3 จุด = เส้นขอบนี้หายไปทั้งเส้น (ผู้เรียกตัดทิ้งเอง)
 */
private fun eraseContour(pts: List<Offset>, a: Offset, b: Offset, r: Float): List<Offset>? {
    val n = pts.size
    if (n < 3) return null
    val step = max(r * 0.6f, 1f)
    val dense = ArrayList<Offset>(n + 16)
    var near = false
    for (i in 0 until n) {
        val p = pts[i]
        val q = pts[(i + 1) % n]
        dense.add(p)
        if (segSegDist(p, q, a, b) < r) {
            near = true
            val len = hypot(q.x - p.x, q.y - p.y)
            val k = min((len / step).toInt(), 400)
            for (j in 1..k) {
                val t = j.toFloat() / (k + 1)
                dense.add(Offset(p.x + (q.x - p.x) * t, p.y + (q.y - p.y) * t))
            }
        }
    }
    if (!near) return null
    val kept = dense.filter { ptSegDist(it, a, b) >= r }
    return if (kept.size == dense.size) null else kept
}

/** ระยะลากขั้นต่ำ (พิกเซลบนจอ) ที่ถือว่าเป็นการ "วาดบ่วง" ถ้าน้อยกว่านี้ถือเป็นการแตะ */
private const val MIN_STROKE_TRAVEL = 12f

/** จำนวนขั้นย้อนกลับสูงสุด */
private const val MAX_HISTORY = 50

// ───────────────────────── ตรรกะบ่วง (ไม่ผูกกับ UI) ─────────────────────────

private fun hasArea(p: Path): Boolean {
    if (p.isEmpty) return false
    val b = RectF()
    p.computeBounds(b, true)
    return b.width() > 1f && b.height() > 1f
}

private fun overlaps(a: Path, b: Path): Boolean {
    val r = Path()
    if (!r.op(a, b, Path.Op.INTERSECT)) return false
    return hasArea(r)
}

/** เพิ่มบ่วงใหม่: บ่วงที่ทับกันจะรวมเป็นบ่วงเดียว */
private fun addLasso(list: List<Path>, np: Path): List<Path> {
    var merged = np
    val rest = ArrayList<Path>()
    for (p in list) {
        if (overlaps(p, merged)) {
            val u = Path()
            if (u.op(p, merged, Path.Op.UNION)) merged = u else rest.add(p)
        } else {
            rest.add(p)
        }
    }
    rest.add(merged)
    return rest
}

/** ลบพื้นที่ของบ่วง [cut] ออกจากบ่วงที่มีอยู่ (บ่วงที่ไม่เหลือพื้นที่จะหายไป) */
private fun subtractLasso(list: List<Path>, cut: Path): List<Path> {
    val out = ArrayList<Path>()
    for (p in list) {
        if (!overlaps(p, cut)) {
            out.add(p)
            continue
        }
        val d = Path()
        if (d.op(p, cut, Path.Op.DIFFERENCE)) {
            if (hasArea(d)) out.add(d)
        } else {
            out.add(p)
        }
    }
    return out
}

private fun sameLassos(a: List<Path>, b: List<Path>): Boolean =
    a.size == b.size && a.indices.all { a[it] === b[it] }

private fun pathContains(p: Path, pt: Offset, w: Int, h: Int): Boolean {
    val r = Region()
    r.setPath(p, Region(0, 0, w, h))
    return r.contains(pt.x.toInt(), pt.y.toInt())
}

/**
 * ตัดภาพตามบ่วง: ได้ภาพขนาดเท่ากรอบที่ครอบบ่วงทั้งหมด ส่วนนอกบ่วงโปร่งใส
 * คืน null ถ้าบ่วงอยู่นอกภาพทั้งหมด (เรียกใน background thread)
 */
fun cropByLassos(src: Bitmap, lassos: List<Path>): Bitmap? = cropByLassosAt(src, lassos)?.bmp

/** ผลตัดภาพ: bmp = ภาพที่ตัดแล้ว, left/top = ตำแหน่งมุมซ้ายบนของภาพที่ตัดในพิกัดภาพเดิม (ไว้ชดเชยตำแหน่งตอนแก้ภาพที่วางอยู่แล้ว) */
class CropResult(val bmp: Bitmap, val left: Int, val top: Int)

fun cropByLassosAt(src: Bitmap, lassos: List<Path>): CropResult? {
    if (lassos.isEmpty()) return CropResult(src, 0, 0)
    val rect = RectF()
    val tmp = RectF()
    var first = true
    for (p in lassos) {
        p.computeBounds(tmp, true)
        if (first) {
            rect.set(tmp)
            first = false
        } else {
            rect.union(tmp)
        }
    }
    val l = floor(rect.left).toInt().coerceIn(0, src.width)
    val t = floor(rect.top).toInt().coerceIn(0, src.height)
    val r = ceil(rect.right).toInt().coerceIn(0, src.width)
    val b = ceil(rect.bottom).toInt().coerceIn(0, src.height)
    val w = r - l
    val h = b - t
    if (w < 1 || h < 1) return null

    val mask = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
    val mc = android.graphics.Canvas(mask)
    val fill = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.FILL
        color = android.graphics.Color.WHITE
    }
    mc.translate(-l.toFloat(), -t.toFloat())
    for (p in lassos) mc.drawPath(p, fill)

    val out = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
    val oc = android.graphics.Canvas(out)
    oc.drawBitmap(src, -l.toFloat(), -t.toFloat(), Paint(Paint.FILTER_BITMAP_FLAG))
    val dstIn = Paint().apply { xfermode = PorterDuffXfermode(PorterDuff.Mode.DST_IN) }
    oc.drawBitmap(mask, 0f, 0f, dstIn)
    mask.recycle()
    return CropResult(out, l, t)
}

// ───────────────────────── หน้าจอตัดภาพ ─────────────────────────

/**
 * หน้าตัดภาพตอนนำเข้า
 * - ลากนิ้วเดียววาดบ่วงรอบส่วนที่ต้องการ (ปล่อยนิ้วแล้วบ่วงปิดเอง) ขอบบ่วงเป็นเส้นปะ ขาว-ดำสลับกัน
 * - บ่วงที่วาดทับกันจะรวมเป็นบ่วงเดียว
 * - โหมด "เพิ่มบ่วง" / "ลบบ่วง" (ลบบ่วง: แตะในบ่วง = ลบทั้งบ่วง, วาดบ่วงทับ = ลบเฉพาะส่วนที่ทับ)
 * - ย้อนกลับ / ทำซ้ำ, ตกลง (ตัดแล้วนำเข้า), ยกเลิก (ไม่นำเข้าภาพนี้)
 * - 2 นิ้ว = ซูม/เลื่อนภาพเพื่อวาดละเอียด; ถ้าไม่วาดบ่วงเลย ตกลง = นำเข้าทั้งภาพ
 */
@Composable
fun ImageCropScreen(bitmap: Bitmap, onConfirm: (Bitmap, Int, Int) -> Unit, onCancel: () -> Unit, allowAddImage: Boolean = false) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val density = LocalDensity.current.density

    val bw = bitmap.width
    val bh = bitmap.height

    var mode by remember { mutableStateOf(CropMode.ADD) }
    var canvasSize by remember { mutableStateOf(IntSize.Zero) }
    var busy by remember { mutableStateOf(false) }

    // บ่วงที่ยืนยันแล้ว (พิกัดภาพ) — ไม่แก้ Path เดิม เปลี่ยนทั้งรายการเมื่อมีการแก้
    var lassos by remember { mutableStateOf<List<Path>>(emptyList()) }
    var undoStack by remember { mutableStateOf<List<Snap>>(emptyList()) }
    var redoStack by remember { mutableStateOf<List<Snap>>(emptyList()) }

    // ภาพที่กำลังแก้ (ยางลบแก้ที่สำเนาของภาพเสมอ ภาพต้นฉบับไม่ถูกแตะ); workVer = ตัวบอกให้วาดใหม่ตอนลบ (บิตแมปถูกแก้ในที่เดิมระหว่างลากนิ้ว)
    var work by remember { mutableStateOf(bitmap) }
    var workVer by remember { mutableIntStateOf(0) }
    var eraserSize by remember { mutableFloatStateOf(24f) } // ขนาดยางลบ (เส้นผ่านศูนย์กลาง หน่วยพิกเซลของภาพ รองรับทศนิยม)
    var eraseTarget by remember { mutableStateOf(EraseTarget.IMAGE) } // ยางลบลบอะไร (เลือกได้ในแถบล่างตอนอยู่โหมดยางลบ)
    var padTarget by remember { mutableStateOf(PadTarget.NONE) } // แผงตัวเลขเล็กมุมซ้ายล่าง: ใส่ค่าอะไรอยู่
    val live = remember { mutableStateListOf<Offset>() } // บ่วงที่กำลังวาด (พิกัดภาพ)

    // มุมมอง: จอ = ภาพ * vs + off
    var vs by remember { mutableFloatStateOf(1f) }
    var off by remember { mutableStateOf(Offset.Zero) }

    // ดัดโค้งบ่วง: จุดควบคุมของแต่ละบ่วง (เก็บตามตัวบ่วง ย้อนกลับ/ทำซ้ำแล้วจุดตามบ่วงเดิมกลับมาด้วย)
    val ctrlCache = remember { IdentityHashMap<Path, Ctrl>() }
    var selPath by remember { mutableStateOf<Path?>(null) } // บ่วงที่เลือกจุดไว้
    var selC by remember { mutableIntStateOf(0) } // เส้นขอบที่เลือก
    var selP by remember { mutableIntStateOf(0) } // จุดที่เลือก (ไว้กดลบจุด)
    var bendDrag by remember { mutableStateOf<BendDrag?>(null) }
    var addPtMode by remember { mutableStateOf(false) } // โหมดเพิ่มจุด: แตะตรงไหนจุดใหม่ขึ้นตรงนิ้วตรงนั้น

    // โหมดจอย: แตะวางเป้า แล้วบังคับเป้าด้วยจอยซ้ายล่าง เป้าเดินแล้วทิ้งเส้นไว้ (ใช้ live เป็นเส้นทาง) จากนั้น "เอาตรงนี้" แตะบนเส้นเพื่อเลือกจุดที่จะเอา แล้ว "ปิดบ่วง"
    var joyPos by remember { mutableStateOf<Offset?>(null) } // ตำแหน่งเป้า (พิกัดภาพ) null = ยังไม่ได้วาง
    var joyHeld by remember { mutableStateOf(false) } // กำลังจับจอยอยู่
    val joyVec = remember { floatArrayOf(0f, 0f) } // ทิศจอย -1..1 (เก็บนอก state ไม่ให้หน้าจอวาดใหม่ทุกครั้งที่นิ้วขยับ)
    var joySpeed by remember { mutableFloatStateOf(120f) } // ความเร็วเมื่อดันสุด (พิกเซลหน้าจอ/วินาที)
    var joyPick by remember { mutableStateOf(false) } // กด "เอาตรงนี้" แล้ว: แตะบนเส้นเพื่อเลือกจุด
    var joyOp by remember { mutableStateOf(CropMode.ADD) } // บ่วงจากจอยเป็นแบบ เพิ่ม (ADD) หรือ ลบ (REMOVE)
    val joyPlaced by remember { derivedStateOf { joyPos != null } }
    val joyHasLine by remember { derivedStateOf { live.size >= 2 } }
    val joyCanClose by remember { derivedStateOf { live.size >= 3 } }

    var overlay by remember { mutableStateOf<Overlay?>(null) } // รูปที่เพิ่มเข้ามาและกำลังวางอยู่

    // แว่นขยายระหว่างลากนิ้ว: touch = ตำแหน่งนิ้วบนจอ (ไว้หลบ), lensImg = จุดบนภาพที่ขยายดู
    var touch by remember { mutableStateOf<Offset?>(null) }
    var lensImg by remember { mutableStateOf<Offset?>(null) }

    fun fitScale(): Float {
        if (canvasSize.width == 0 || canvasSize.height == 0) return 1f
        return min(canvasSize.width.toFloat() / bw, canvasSize.height.toFloat() / bh) * 0.96f
    }

    fun fitView() {
        if (canvasSize.width == 0 || canvasSize.height == 0) return
        val f = fitScale()
        vs = f
        off = Offset((canvasSize.width - bw * f) / 2f, (canvasSize.height - bh * f) / 2f)
    }

    LaunchedEffect(canvasSize) { fitView() }

    fun toImg(o: Offset): Offset = Offset(
        ((o.x - off.x) / vs).coerceIn(0f, bw.toFloat()),
        ((o.y - off.y) / vs).coerceIn(0f, bh.toFloat()),
    )

    fun toScreen(p: Path): Path {
        val m = Matrix()
        m.setScale(vs, vs)
        m.postTranslate(off.x, off.y)
        val q = Path(p)
        q.transform(m)
        return q
    }

    fun commit(newList: List<Path>) {
        if (sameLassos(newList, lassos)) return
        undoStack = trimHistory(undoStack + Snap(lassos, work))
        redoStack = emptyList()
        lassos = newList
    }

    fun undo() {
        val prev = undoStack.lastOrNull() ?: return
        redoStack = redoStack + Snap(lassos, work)
        lassos = prev.lassos
        work = prev.bmp
        workVer++
        undoStack = undoStack.dropLast(1)
    }

    fun redo() {
        val next = redoStack.lastOrNull() ?: return
        undoStack = trimHistory(undoStack + Snap(lassos, work))
        lassos = next.lassos
        work = next.bmp
        workVer++
        redoStack = redoStack.dropLast(1)
    }

    /** แปลงตำแหน่งจอเป็นพิกัดภาพแบบไม่ตัดขอบ (ยางลบลากเลยขอบภาพได้) */
    fun toImgRaw(o: Offset): Offset = Offset((o.x - off.x) / vs, (o.y - off.y) / vs)

    fun ctrlOf(p: Path): Ctrl = ctrlCache.getOrPut(p) { Ctrl(flattenToControls(p, 5f / max(vs, 0.01f)), false, p.fillType) }

    fun selValid(): Path? = selPath?.takeIf { sp -> lassos.any { it === sp } }

    /** แทนเส้นขอบ ci ของบ่วง orig ด้วยจุดชุดใหม่ แล้วบันทึกลงประวัติ (ย้อนกลับได้) */
    fun replaceContour(orig: Path, ci: Int, pts: List<Offset>, newSelP: Int) {
        val ct = ctrlOf(orig)
        val nc = Ctrl(ct.contours.mapIndexed { i, l -> if (i == ci) pts else l }, ct.smooth, ct.fillType)
        val np = buildPath(nc)
        ctrlCache[np] = nc
        commit(lassos.map { if (it === orig) np else it })
        selPath = np
        selC = ci
        selP = newSelP
    }

    fun hitHandle(pos: Offset): Hit? {
        var best: Hit? = null
        var bestD = 24f * density
        for (lp in lassos) {
            val ct = ctrlOf(lp)
            for (ci in ct.contours.indices) {
                val pts = ct.contours[ci]
                for (pi in pts.indices) {
                    val q = pts[pi]
                    val d = (Offset(q.x * vs + off.x, q.y * vs + off.y) - pos).getDistance()
                    if (d < bestD) {
                        bestD = d
                        best = Hit(lp, ci, pi)
                    }
                }
            }
        }
        return best
    }

    /** หาเส้นขอบบ่วงที่ใกล้ตำแหน่งนิ้วที่สุด (ภายใน radius พิกเซลจอ): คืนบ่วง เส้นขอบ ช่วงที่ต้องแทรกต่อท้าย และจุดบนเส้น (พิกัดภาพ) */
    fun findEdge(pos: Offset, radius: Float): EdgeHit? {
        var bestD = radius
        var best: EdgeHit? = null
        for (lp in lassos) {
            val ct = ctrlOf(lp)
            for (ci in ct.contours.indices) {
                val d = PathMath.dense(ct.contours[ci], ct.smooth, true)
                for (i in 0 until d.pts.size - 1) {
                    val a = d.pts[i]
                    val b = d.pts[i + 1]
                    val proj = projectOnSegment(
                        pos,
                        Offset(a.x * vs + off.x, a.y * vs + off.y),
                        Offset(b.x * vs + off.x, b.y * vs + off.y),
                    )
                    val dist = (pos - proj).getDistance()
                    if (dist < bestD) {
                        bestD = dist
                        best = EdgeHit(lp, ci, d.seg[i], Offset((proj.x - off.x) / vs, (proj.y - off.y) / vs))
                    }
                }
            }
        }
        return best
    }

    /** แตะใกล้เส้นขอบบ่วง = แทรกจุดควบคุมบนเส้นตรงนั้น (คืน false ถ้าไม่ได้แตะใกล้เส้น) */
    fun insertPointAt(pos: Offset): Boolean {
        val e = findEdge(pos, 20f * density) ?: return false
        val list = ctrlOf(e.path).contours[e.c].toMutableList()
        list.add(e.seg + 1, e.pt)
        replaceContour(e.path, e.c, list, e.seg + 1)
        return true
    }

    /**
     * โหมด "เพิ่มจุด": แตะที่ไหน จุดใหม่ก็ขึ้น ณ ตำแหน่งนิ้วตรงนั้น (แทรกในช่วงของเส้นบ่วงที่ใกล้นิ้วที่สุด) แล้วลากต่อเพื่อวางได้เลย
     * ยังไม่บันทึกลงประวัติ: ปล่อยนิ้วแล้วจึงบันทึกครั้งเดียว (ย้อนกลับครั้งเดียวได้ทั้งเพิ่ม+ย้าย)
     */
    fun beginAddAtFinger(pos: Offset): Hit? {
        val e = findEdge(pos, 60f * density) ?: return null
        val ct = ctrlOf(e.path)
        val list = ct.contours[e.c].toMutableList()
        list.add(e.seg + 1, toImg(pos))
        val nc = Ctrl(ct.contours.mapIndexed { i, l -> if (i == e.c) list else l }, ct.smooth, ct.fillType)
        bendDrag = BendDrag(e.path, nc, buildPath(nc))
        return Hit(e.path, e.c, e.seg + 1)
    }

    /** ปุ่ม "ลบจุด": ลบจุดควบคุมที่เลือก (ต้องเหลืออย่างน้อย 3 จุด) */
    fun deleteSelectedPoint() {
        val sp = selValid() ?: return
        val pts = ctrlOf(sp).contours.getOrNull(selC) ?: return
        if (pts.size <= 3 || selP !in pts.indices) {
            Toast.makeText(context, "ต้องเหลืออย่างน้อย 3 จุด", Toast.LENGTH_SHORT).show()
            return
        }
        replaceContour(sp, selC, pts.toMutableList().also { it.removeAt(selP) }, 0)
        selPath = null
    }

    /** ปุ่ม "โค้งเนียน": สลับบ่วงที่เลือกระหว่างต่อจุดเป็นเส้นตรง / เส้นโค้งเนียน */
    fun toggleSmooth() {
        val sp = selValid() ?: return
        val ct = ctrlOf(sp)
        val nc = Ctrl(ct.contours, !ct.smooth, ct.fillType)
        val np = buildPath(nc)
        ctrlCache[np] = nc
        commit(lassos.map { if (it === sp) np else it })
        selPath = np
    }

    fun finishStroke(pts: List<Offset>, travel: Float, tapAt: Offset) {
        if (mode == CropMode.REMOVE && travel < MIN_STROKE_TRAVEL) {
            // แตะในบ่วง = ลบทั้งบ่วง
            val p = toImg(tapAt)
            val hit = lassos.lastOrNull { pathContains(it, p, bw, bh) }
            if (hit != null) commit(lassos.filter { it !== hit })
            return
        }
        if (pts.size < 3 || travel < MIN_STROKE_TRAVEL) return
        val path = Path()
        path.moveTo(pts[0].x, pts[0].y)
        for (i in 1 until pts.size) path.lineTo(pts[i].x, pts[i].y)
        path.close()
        if (!hasArea(path)) return
        commit(if (mode == CropMode.ADD) addLasso(lassos, path) else subtractLasso(lassos, path))
    }

    fun confirm() {
        if (busy) return
        val current = lassos
        val src = work
        if (current.isEmpty()) {
            onConfirm(src, 0, 0) // ไม่วาดบ่วง = ใช้ทั้งภาพ (รวมส่วนที่ลบด้วยยางลบแล้ว)
            return
        }
        scope.launch {
            busy = true
            val r = withContext(Dispatchers.Default) { runCatching { cropByLassosAt(src, current) } }
            busy = false
            r.onSuccess { out ->
                if (out == null) {
                    Toast.makeText(context, "บ่วงอยู่นอกภาพ ลองวาดใหม่", Toast.LENGTH_SHORT).show()
                } else {
                    onConfirm(out.bmp, out.left, out.top)
                }
            }.onFailure {
                Toast.makeText(context, "ตัดภาพไม่สำเร็จ: ${it.message ?: it.javaClass.simpleName}", Toast.LENGTH_LONG).show()
            }
        }
    }

    // ข้อความบอกวิธีใช้: อ่านจาก "กำลังแตะอยู่ไหม" อย่างเดียว (ไม่อ่านตำแหน่งนิ้ว) ไม่งั้นทั้งหน้าจะคำนวณใหม่ทุกครั้งที่นิ้วขยับ = กระตุก
    val touching by remember { derivedStateOf { touch != null } }
    // เส้นบ่วงในพิกัดจอ: คำนวณใหม่เฉพาะเมื่อบ่วง/ซูม/เลื่อนเปลี่ยน ไม่คำนวณทุกเฟรมของการวาด
    val baseScreen = remember(lassos, vs, off) { lassos.map { toScreen(it) } }

    BackHandler(onBack = { if (!busy) { if (overlay != null) overlay = null else onCancel() } })

    // ── อุปกรณ์วาด ──
    val dash = 8f * density
    val antWhite = remember(density) {
        Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.STROKE
            color = android.graphics.Color.WHITE
            strokeWidth = 1.5f * density
            strokeJoin = Paint.Join.ROUND
        }
    }
    val antBlack = remember(density) {
        Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.STROKE
            color = android.graphics.Color.BLACK
            strokeWidth = 1.5f * density
            strokeJoin = Paint.Join.ROUND
        }
    }
    val erStroke = remember { // ยางลบ: ลบพิกเซลให้โปร่งใส (ขอบนุ่มด้วย anti-alias ขนาดทศนิยมเล็กกว่า 1 พิกเซลก็ลบจางๆ ได้)
        Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.STROKE
            strokeCap = Paint.Cap.ROUND
            xfermode = PorterDuffXfermode(PorterDuff.Mode.CLEAR)
        }
    }
    val erFill = remember {
        Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.FILL
            xfermode = PorterDuffXfermode(PorterDuff.Mode.CLEAR)
        }
    }
    val ringWhite = remember(density) {
        Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; color = android.graphics.Color.WHITE; strokeWidth = 1f * density }
    }
    val ringBlack = remember(density) {
        Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; color = android.graphics.Color.BLACK; strokeWidth = 2.2f * density }
    }
    val dimPaint = remember { Paint().apply { color = 0x99000000.toInt() } }
    val bmpPaint = remember { Paint(Paint.FILTER_BITMAP_FLAG or Paint.ANTI_ALIAS_FLAG) }
    val checkerPaint = remember(density) {
        val s = max(1, (8f * density).toInt())
        val bm = Bitmap.createBitmap(s * 2, s * 2, Bitmap.Config.ARGB_8888)
        val c = android.graphics.Canvas(bm)
        c.drawColor(0xFFB8B8C0.toInt())
        val p = Paint().apply { color = 0xFF8E8E98.toInt() }
        c.drawRect(0f, 0f, s.toFloat(), s.toFloat(), p)
        c.drawRect(s.toFloat(), s.toFloat(), s * 2f, s * 2f, p)
        Paint().apply { shader = BitmapShader(bm, Shader.TileMode.REPEAT, Shader.TileMode.REPEAT) }
    }
    val loupeWhite = remember { Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; color = android.graphics.Color.WHITE; strokeJoin = Paint.Join.ROUND } }
    val loupeBlack = remember { Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; color = android.graphics.Color.BLACK; strokeJoin = Paint.Join.ROUND } }
    val loupeBg = remember { Paint().apply { color = 0xFF1E1E26.toInt() } }
    val loupeBorder = remember(density) {
        Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.STROKE
            color = android.graphics.Color.WHITE
            strokeWidth = 2f * density
        }
    }
    val crossPaint = remember(density) {
        Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.STROKE
            color = 0xFFFF1744.toInt()
            strokeWidth = 1.5f * density
        }
    }
    val hFill = remember { Paint(Paint.ANTI_ALIAS_FLAG).apply { color = android.graphics.Color.WHITE } }
    val hStroke = remember(density) {
        Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.STROKE
            color = 0xFFB69DFF.toInt()
            strokeWidth = 2.5f * density
        }
    }
    val hSel = remember(density) {
        Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.STROKE
            color = 0xFFFF80AB.toInt()
            strokeWidth = 3.5f * density
        }
    }
    val ants = rememberInfiniteTransition(label = "ants")
    val phase by ants.animateFloat(
        initialValue = 0f,
        targetValue = dash * 2f,
        animationSpec = infiniteRepeatable(tween(900, easing = LinearEasing), RepeatMode.Restart),
        label = "antsPhase",
    )

    val joyGlow = remember(density) { // เส้นเรืองแสงใต้เส้นทางของเป้า
        Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.STROKE
            color = 0x66B69DFF
            strokeWidth = 6f * density
            strokeJoin = Paint.Join.ROUND
            strokeCap = Paint.Cap.ROUND
        }
    }

    /** ยางลบลบพิกเซล: a == b = จุดเดียว (กดครั้งแรก) · clip != null = ลบเฉพาะส่วนที่อยู่ในบ่วงเหล่านั้น */
    fun eraseDraw(cv: android.graphics.Canvas, a: Offset, b: Offset, clip: List<Path>?) {
        val r = max(eraserSize, 0.01f) / 2f
        erStroke.strokeWidth = max(eraserSize, 0.01f)
        fun once() {
            if (a == b) cv.drawCircle(a.x, a.y, r, erFill) else cv.drawLine(a.x, a.y, b.x, b.y, erStroke)
        }
        if (clip == null) {
            once()
        } else {
            for (lp in clip) {
                cv.save()
                cv.clipPath(lp)
                once()
                cv.restore()
            }
        }
    }

    /** ยางลบเส้น: ลบเส้นบ่วง/จุดโค้งที่ยางลบ (a→b) ลากผ่าน แล้วแสดงผลทันที (ผู้เรียกบันทึกลงประวัติตอนปล่อยนิ้ว) */
    fun eraseLines(a: Offset, b: Offset) {
        val r = max(eraserSize, 0.01f) / 2f
        var changed = false
        val out = ArrayList<Path>()
        for (lp in lassos) {
            val ct = ctrlOf(lp)
            var touched = false
            val newC = ArrayList<List<Offset>>()
            for (pts0 in ct.contours) {
                val src = if (ct.smooth) PathMath.dense(pts0, true, true).pts.dropLast(1) else pts0 // บ่วงโค้งเนียน: แปลงเป็นเส้นตรงถี่ๆ ก่อนลบ
                val res = eraseContour(src, a, b, r)
                if (res == null) {
                    newC.add(src)
                } else {
                    touched = true
                    if (res.size >= 3) newC.add(res)
                }
            }
            if (!touched) {
                out.add(lp)
                continue
            }
            changed = true
            if (newC.isEmpty()) continue // เส้นขอบทุกเส้นถูกลบหมด = บ่วงนี้หายไป
            val nc = Ctrl(newC, false, ct.fillType)
            val np = buildPath(nc)
            ctrlCache[np] = nc
            out.add(np)
        }
        if (changed) {
            lassos = out
            selPath = null
        }
    }

    // ── จอย: ฟังก์ชันช่วย ──
    fun joyReset() {
        live.clear()
        joyPos = null
        joyPick = false
        joyHeld = false
        joyVec[0] = 0f
        joyVec[1] = 0f
    }

    fun joyPlace(p: Offset) {
        live.clear()
        live.add(p)
        joyPos = p
    }

    /** แตะบนเส้นทางของเป้า: ตัดเส้นให้เหลือถึงจุดที่แตะ แล้วย้ายเป้าไปอยู่ตรงนั้น */
    fun joyTrim(screenPt: Offset) {
        var bestD = Float.MAX_VALUE
        var bestSeg = -1
        var bestPt = Offset.Zero
        for (i in 0 until live.size - 1) {
            val a = Offset(live[i].x * vs + off.x, live[i].y * vs + off.y)
            val b = Offset(live[i + 1].x * vs + off.x, live[i + 1].y * vs + off.y)
            val q = projectOnSegment(screenPt, a, b)
            val d = (q - screenPt).getDistance()
            if (d < bestD) {
                bestD = d
                bestSeg = i
                bestPt = q
            }
        }
        if (bestSeg < 0 || bestD > 40f * density) {
            Toast.makeText(context, "แตะให้ใกล้เส้นกว่านี้", Toast.LENGTH_SHORT).show()
            return
        }
        val imgPt = Offset(((bestPt.x - off.x) / vs).coerceIn(0f, bw.toFloat()), ((bestPt.y - off.y) / vs).coerceIn(0f, bh.toFloat()))
        while (live.size > bestSeg + 1) live.removeAt(live.size - 1)
        if ((live.last() - imgPt).getDistance() * vs > 0.5f) live.add(imgPt)
        joyPos = live.last()
        joyPick = false
    }

    /** ปิดบ่วงจากเส้นทางของเป้า (ต่อจุดท้ายกลับจุดแรก) แล้วเพิ่ม/ลบบ่วงเหมือนวาดด้วยนิ้ว */
    fun joyCommit() {
        val pts = live.toList()
        if (pts.size < 3) {
            Toast.makeText(context, "เส้นสั้นเกินไป บังคับเป้าวนรอบส่วนที่ต้องการก่อน", Toast.LENGTH_SHORT).show()
            return
        }
        val path = Path()
        path.moveTo(pts[0].x, pts[0].y)
        for (i in 1 until pts.size) path.lineTo(pts[i].x, pts[i].y)
        path.close()
        if (!hasArea(path)) {
            Toast.makeText(context, "บ่วงไม่มีพื้นที่ ลองบังคับเป้าวนใหม่", Toast.LENGTH_SHORT).show()
            return
        }
        commit(if (joyOp == CropMode.ADD) addLasso(lassos, path) else subtractLasso(lassos, path))
        joyReset()
    }

    LaunchedEffect(mode) {
        padTarget = PadTarget.NONE
        if (mode != CropMode.JOY) {
            joyPos = null
            joyPick = false
            joyHeld = false
        }
    }

    // เป้าเดินตามจอยทุกเฟรมที่ดันอยู่ (ความเร็วคิดเป็นพิกเซลหน้าจอ ไม่ขึ้นกับระดับซูม)
    LaunchedEffect(joyHeld, mode) {
        if (!joyHeld || mode != CropMode.JOY) return@LaunchedEffect
        try {
            var last = withFrameNanos { it }
            while (true) {
                val now = withFrameNanos { it }
                val dt = ((now - last) / 1_000_000_000f).coerceAtMost(0.05f)
                last = now
                val p = joyPos
                val vx = joyVec[0]
                val vy = joyVec[1]
                if (p == null || joyPick || (vx == 0f && vy == 0f)) continue
                val k = joySpeed * dt / max(vs, 0.01f)
                val np = Offset((p.x + vx * k).coerceIn(0f, bw.toFloat()), (p.y + vy * k).coerceIn(0f, bh.toFloat()))
                if (np != p) {
                    joyPos = np
                    val lp = live.lastOrNull()
                    if (lp == null || (np - lp).getDistance() * vs >= 2f * density) live.add(np)
                }
                touch = Offset(np.x * vs + off.x, np.y * vs + off.y)
                lensImg = np
            }
        } finally {
            val p = joyPos
            if (p != null && live.isNotEmpty() && live.last() != p) live.add(p) // ปล่อยจอย: เส้นต้องไปถึงตำแหน่งเป้าจริง
            touch = null
            lensImg = null
        }
    }

    // ── เพิ่มรูปซ้อนบนภาพที่กำลังแก้ ──
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri ->
        if (uri != null) {
            scope.launch {
                val r = runCatching { withContext(Dispatchers.IO) { ImageImport.trimTransparent(ImageImport.decode(context, uri)) } }
                r.onSuccess { b ->
                    val fit = 0.5f * min(bw / b.width.toFloat(), bh / b.height.toFloat())
                    val c = toImg(Offset(canvasSize.width / 2f, canvasSize.height / 2f))
                    overlay = Overlay(b, c.x, c.y, fit.coerceAtLeast(0.01f))
                }.onFailure {
                    Toast.makeText(context, "เพิ่มรูปไม่สำเร็จ: ${it.message ?: it.javaClass.simpleName}", Toast.LENGTH_LONG).show()
                }
            }
        }
    }

    /** กด "วางรูป": ประกอบรูปลงบนสำเนาของภาพ (ย้อนกลับได้) ส่วนที่ล้นกรอบภาพเดิมถูกตัดทิ้ง */
    fun placeOverlay() {
        val ov = overlay ?: return
        val sb = runCatching { work.copy(Bitmap.Config.ARGB_8888, true) }.getOrNull()
        if (sb == null) {
            Toast.makeText(context, "หน่วยความจำไม่พอ", Toast.LENGTH_SHORT).show()
            return
        }
        sb.setHasAlpha(true)
        val m = Matrix()
        m.postTranslate(-ov.bmp.width / 2f, -ov.bmp.height / 2f)
        m.postScale(ov.scale, ov.scale)
        m.postTranslate(ov.cx, ov.cy)
        android.graphics.Canvas(sb).drawBitmap(ov.bmp, m, bmpPaint)
        undoStack = trimHistory(undoStack + Snap(lassos, work))
        redoStack = emptyList()
        work = sb
        workVer++
        overlay = null
    }

    Column(
        Modifier
            .fillMaxSize()
            .background(Palette.Bg)
            .systemBarsPadding()
            .pointerInput(Unit) { detectTapGestures { } }, // กันการสัมผัสทะลุไปหน้าด้านล่าง
    ) {
        Box(Modifier.weight(1f).fillMaxWidth().background(Color(0xFF2A2A34))) {
            Canvas(
                Modifier
                    .fillMaxSize()
                    .onSizeChanged { canvasSize = it }
                    .pointerInput(mode) {
                        awaitEachGesture {
                            val down = awaitFirstDown(requireUnconsumed = false)
                            if (overlay != null) { // กำลังวางรูปที่เพิ่ม: 1 นิ้ว = ย้ายรูป · 2 นิ้ว = ย่อ/ขยายรูป
                                do {
                                    val event = awaitPointerEvent()
                                    val ov = overlay
                                    if (ov != null) {
                                        if (event.changes.count { it.pressed } >= 2) {
                                            val zoom = event.calculateZoom()
                                            val pan = event.calculatePan()
                                            overlay = ov.copy(cx = ov.cx + pan.x / vs, cy = ov.cy + pan.y / vs, scale = (ov.scale * zoom).coerceIn(0.02f, 20f))
                                            event.changes.forEach { if (it.positionChanged()) it.consume() }
                                        } else {
                                            val ch = event.changes.firstOrNull { it.pressed }
                                            if (ch != null) {
                                                val d = ch.position - ch.previousPosition
                                                overlay = ov.copy(cx = ov.cx + d.x / vs, cy = ov.cy + d.y / vs)
                                                ch.consume()
                                            }
                                        }
                                    }
                                } while (event.changes.any { it.pressed })
                                return@awaitEachGesture
                            }
                            if (mode == CropMode.JOY) { // โหมดจอย: นิ้วเดียวบนภาพมีผลแค่ "วางเป้าครั้งแรก" กับ "แตะเลือกจุดบนเส้น" นอกนั้นไม่ติด · 2 นิ้ว = ซูม/เลื่อน
                                var multi = false
                                var moved = 0f
                                var prev = down.position
                                do {
                                    val event = awaitPointerEvent()
                                    if (event.changes.count { it.pressed } >= 2) {
                                        multi = true
                                        val zoom = event.calculateZoom()
                                        val pan = event.calculatePan()
                                        val c = event.calculateCentroid()
                                        val f = fitScale()
                                        val s0 = vs
                                        val s1 = (s0 * zoom).coerceIn(f * 0.5f, f * 20f)
                                        val k = s1 / s0
                                        off = Offset(c.x - (c.x - off.x) * k + pan.x, c.y - (c.y - off.y) * k + pan.y)
                                        vs = s1
                                        event.changes.forEach { if (it.positionChanged()) it.consume() }
                                    } else {
                                        val ch = event.changes.firstOrNull { it.pressed }
                                        if (ch != null) {
                                            moved += (ch.position - prev).getDistance()
                                            prev = ch.position
                                        }
                                    }
                                } while (event.changes.any { it.pressed })
                                if (!multi && moved < 14f * density) {
                                    if (joyPick) {
                                        joyTrim(down.position)
                                    } else if (joyPos == null) {
                                        val raw = toImgRaw(down.position)
                                        if (raw.x in 0f..bw.toFloat() && raw.y in 0f..bh.toFloat()) joyPlace(raw)
                                    }
                                }
                                return@awaitEachGesture
                            }
                            var drawing = true
                            var travel = 0f
                            var last = down.position
                            val bend = mode == CropMode.BEND
                            val erase = mode == CropMode.ERASE
                            var eOld: Bitmap? = null // ภาพก่อนเริ่มลบ (ไว้ย้อนกลับ/ยกเลิก)
                            var eCanvas: android.graphics.Canvas? = null
                            var ePrev = Offset.Zero
                            var hit: Hit? = null
                            var gap = Offset.Zero // ระยะจากนิ้วถึงจุดที่จับ (กันจุดกระโดดมาอยู่ใต้นิ้ว)
                            live.clear()
                            val eTarget = eraseTarget
                            var eLines: List<Path>? = null // ยางลบเส้น: บ่วงก่อนเริ่มลบ (ไว้ย้อนกลับ/ยกเลิก)
                            var eClip: List<Path>? = null // ยางลบในบ่วง: ลบเฉพาะส่วนที่อยู่ในบ่วงเหล่านี้
                            if (erase && eTarget == EraseTarget.LINES) {
                                if (lassos.isEmpty()) {
                                    drawing = false
                                    Toast.makeText(context, "ยังไม่มีบ่วงให้ลบเส้น", Toast.LENGTH_SHORT).show()
                                } else {
                                    eLines = lassos
                                    ePrev = toImgRaw(down.position)
                                    eraseLines(ePrev, ePrev)
                                    touch = down.position
                                    lensImg = ePrev
                                }
                            } else if (erase && eTarget == EraseTarget.INSIDE && lassos.isEmpty()) {
                                drawing = false
                                Toast.makeText(context, "ยังไม่มีบ่วง วาดบ่วงก่อนแล้วค่อยลบในบ่วง", Toast.LENGTH_SHORT).show()
                            } else if (erase) { // ยางลบ: ทำสำเนาภาพแล้วลบบนสำเนา (ปล่อยนิ้วค่อยบันทึกเป็น 1 ขั้นย้อนกลับ)
                                val sb = runCatching { work.copy(Bitmap.Config.ARGB_8888, true) }.getOrNull()
                                if (sb == null) {
                                    drawing = false
                                    Toast.makeText(context, "หน่วยความจำไม่พอสำหรับยางลบ", Toast.LENGTH_SHORT).show()
                                } else {
                                    sb.setHasAlpha(true)
                                    val cv = android.graphics.Canvas(sb)
                                    eOld = work
                                    eCanvas = cv
                                    eClip = if (eTarget == EraseTarget.INSIDE) lassos else null
                                    ePrev = toImgRaw(down.position)
                                    eraseDraw(cv, ePrev, ePrev, eClip)
                                    work = sb
                                    workVer++
                                    touch = down.position
                                    lensImg = ePrev
                                }
                            } else if (bend) { // โหมดดัดโค้ง: แตะโดนจุดควบคุม = เลือกและลากจุดนั้น
                                hit = hitHandle(down.position)
                                if (hit == null && addPtMode) {
                                    hit = beginAddAtFinger(down.position) // เพิ่มจุดใหม่ใต้นิ้ว แล้วลากต่อได้เลย
                                    if (hit != null) {
                                        touch = down.position
                                        lensImg = toImg(down.position)
                                    }
                                }
                                val h0 = hit
                                if (h0 != null) {
                                    selPath = h0.path
                                    selC = h0.c
                                    selP = h0.p
                                    val q = (bendDrag?.ctrl ?: ctrlOf(h0.path)).contours[h0.c][h0.p]
                                    gap = Offset(q.x * vs + off.x, q.y * vs + off.y) - down.position
                                }
                            } else {
                                live.add(toImg(down.position))
                            }
                            do {
                                val event = awaitPointerEvent()
                                val pressedCount = event.changes.count { it.pressed }
                                if (pressedCount >= 2) {
                                    // 2 นิ้ว = ซูม/เลื่อนภาพ (ยกเลิกบ่วงที่กำลังวาดอยู่)
                                    if (drawing) {
                                        drawing = false
                                        if (erase) { // ยกเลิกรอยลบที่กำลังลาก (เปลี่ยนเป็นซูมแทน)
                                            eOld?.let { work = it }
                                            eLines?.let { lassos = it }
                                            eCanvas = null
                                            workVer++
                                        }
                                        live.clear()
                                        bendDrag = null // ยกเลิกการลากจุดที่ค้างอยู่
                                        touch = null
                                        lensImg = null
                                    }
                                    val zoom = event.calculateZoom()
                                    val pan = event.calculatePan()
                                    val c = event.calculateCentroid()
                                    val f = fitScale()
                                    val s0 = vs
                                    val s1 = (s0 * zoom).coerceIn(f * 0.5f, f * 20f)
                                    val k = s1 / s0
                                    off = Offset(
                                        c.x - (c.x - off.x) * k + pan.x,
                                        c.y - (c.y - off.y) * k + pan.y,
                                    )
                                    vs = s1
                                    event.changes.forEach { if (it.positionChanged()) it.consume() }
                                } else if (drawing) {
                                    val ch = event.changes.firstOrNull { it.pressed }
                                    if (ch != null && erase) {
                                        val cv = eCanvas
                                        if (cv != null) {
                                            val np = toImgRaw(ch.position)
                                            if ((np - ePrev).getDistance() > 0f) {
                                                eraseDraw(cv, ePrev, np, eClip)
                                                ePrev = np
                                                workVer++
                                            }
                                            touch = ch.position
                                            lensImg = np
                                        } else if (eLines != null) {
                                            val np = toImgRaw(ch.position)
                                            if ((np - ePrev).getDistance() > 0f) {
                                                eraseLines(ePrev, np)
                                                ePrev = np
                                            }
                                            touch = ch.position
                                            lensImg = np
                                        }
                                        ch.consume()
                                    } else if (ch != null) {
                                        val d = (ch.position - last).getDistance()
                                        val addLive = d >= 3f // จุดของบ่วงเก็บทุก 3 พิกเซล แต่ตำแหน่งแว่นขยาย/จุดที่ลากอัปเดตทุกครั้งที่นิ้วขยับ (ลื่น ไม่เป็นช่วงๆ)
                                        if (addLive) {
                                            travel += d
                                            last = ch.position
                                        }
                                        if (travel >= 3f) {
                                            touch = ch.position
                                            if (bend) {
                                                val hh = hit
                                                if (hh != null) { // ลากจุดควบคุม: ดูตัวอย่างทันที ยังไม่บันทึกลงประวัติจนกว่าจะปล่อยนิ้ว
                                                    val ct0 = bendDrag?.ctrl ?: ctrlOf(hh.path)
                                                    val np0 = toImg(ch.position + gap)
                                                    val list = ct0.contours[hh.c].toMutableList()
                                                    list[hh.p] = np0
                                                    val nc2 = Ctrl(ct0.contours.mapIndexed { i, l -> if (i == hh.c) list else l }, ct0.smooth, ct0.fillType)
                                                    bendDrag = BendDrag(hh.path, nc2, buildPath(nc2))
                                                    lensImg = np0
                                                }
                                            } else {
                                                val np1 = toImg(ch.position)
                                                if (addLive) live.add(np1)
                                                lensImg = np1
                                            }
                                        }
                                        ch.consume()
                                    }
                                }
                            } while (event.changes.any { it.pressed })

                            if (drawing) {
                                if (erase) {
                                    val eo = eOld
                                    if (eo != null && eCanvas != null) { // ปล่อยนิ้ว: บันทึกรอยลบเป็น 1 ขั้น
                                        undoStack = trimHistory(undoStack + Snap(lassos, eo))
                                        redoStack = emptyList()
                                    }
                                    val el = eLines
                                    if (el != null && !sameLassos(lassos, el)) { // ยางลบเส้น: บันทึกบ่วงก่อนลบเป็น 1 ขั้น
                                        undoStack = trimHistory(undoStack + Snap(el, work))
                                        redoStack = emptyList()
                                    }
                                } else if (bend) {
                                    val hh = hit
                                    val bd = bendDrag
                                    if (hh != null) {
                                        if (bd != null) { // ปล่อยนิ้ว: บันทึกบ่วงที่ดัดแล้วลงประวัติ (ย้อนกลับได้)
                                            ctrlCache[bd.preview] = bd.ctrl
                                            commit(lassos.map { if (it === hh.path) bd.preview else it })
                                            selPath = bd.preview
                                        }
                                    } else if (travel < MIN_STROKE_TRAVEL) { // แตะที่ว่าง: แตะใกล้เส้นบ่วง = แทรกจุด ไม่ใช่ = เลิกเลือก
                                        if (!insertPointAt(down.position)) selPath = null
                                    }
                                } else {
                                    val pts = live.toList()
                                    live.clear()
                                    finishStroke(pts, travel, down.position)
                                }
                            } else {
                                live.clear()
                            }
                            bendDrag = null
                            touch = null
                            lensImg = null
                        }
                    },
            ) {
                if (canvasSize.width == 0) return@Canvas
                @Suppress("UNUSED_VARIABLE") val ver = workVer // อ่านไว้เพื่อให้วาดใหม่ทุกครั้งที่ยางลบแก้ภาพ
                val dst = RectF(off.x, off.y, off.x + bw * vs, off.y + bh * vs)
                if (touching) {
                    // ระหว่างลากนิ้ว: หยุดเส้นปะวิ่งแต่ยังเป็นเส้นปะขาว-ดำสลับกันพอดี (ไม่ใช้เส้นขาวซ้อนเส้นดำที่ขอบขาวจางๆ โผล่รอบเส้น) และไม่อ่านค่า phase
                    antWhite.pathEffect = DashPathEffect(floatArrayOf(dash, dash), 0f)
                    antBlack.pathEffect = DashPathEffect(floatArrayOf(dash, dash), dash)
                } else {
                    antWhite.pathEffect = DashPathEffect(floatArrayOf(dash, dash), phase)
                    antBlack.pathEffect = DashPathEffect(floatArrayOf(dash, dash), phase + dash)
                }
                drawIntoCanvas { c ->
                    val nc = c.nativeCanvas
                    nc.drawRect(dst, checkerPaint)
                    nc.drawBitmap(work, null, dst, bmpPaint)
                    val ovd = overlay
                    if (ovd != null) { // รูปที่กำลังวาง: โชว์เฉพาะส่วนที่อยู่ในกรอบภาพ (ส่วนที่ล้นจะถูกตัด) + กรอบปะรอบรูป
                        nc.save()
                        nc.clipRect(dst)
                        nc.translate(off.x, off.y)
                        nc.scale(vs, vs)
                        nc.translate(ovd.cx, ovd.cy)
                        nc.scale(ovd.scale, ovd.scale)
                        nc.drawBitmap(ovd.bmp, -ovd.bmp.width / 2f, -ovd.bmp.height / 2f, bmpPaint)
                        nc.restore()
                        val hw = ovd.bmp.width * ovd.scale * vs / 2f
                        val hh = ovd.bmp.height * ovd.scale * vs / 2f
                        val ocx = ovd.cx * vs + off.x
                        val ocy = ovd.cy * vs + off.y
                        val op = Path()
                        op.addRect(ocx - hw, ocy - hh, ocx + hw, ocy + hh, Path.Direction.CW)
                        nc.drawPath(op, antWhite)
                        nc.drawPath(op, antBlack)
                    }

                    val bd = bendDrag
                    val screenLassos = if (bd == null) baseScreen else lassos.mapIndexed { i, lp -> if (lp === bd.orig) toScreen(bd.preview) else baseScreen[i] }
                    if (screenLassos.isNotEmpty()) {
                        // ทำให้ส่วนนอกบ่วงมืดลง เพื่อเห็นชัดว่าส่วนไหนจะถูกเก็บไว้
                        nc.save()
                        for (sp in screenLassos) nc.clipOutPath(sp)
                        nc.drawRect(dst, dimPaint)
                        nc.restore()
                    }
                    for (sp in screenLassos) {
                        nc.drawPath(sp, antWhite)
                        nc.drawPath(sp, antBlack)
                    }
                    if (live.size >= 2) { // เส้นที่กำลังวาด: ใช้เส้นปะแบบเดียวกัน
                        val lp = Path()
                        live.forEachIndexed { i, o ->
                            val x = o.x * vs + off.x
                            val y = o.y * vs + off.y
                            if (i == 0) lp.moveTo(x, y) else lp.lineTo(x, y)
                        }
                        if (mode == CropMode.JOY) {
                            joyGlow.color = if (joyPick) 0xCCFFD600.toInt() else 0x66B69DFF // รอแตะเลือกจุด = เส้นเหลืองเด่นขึ้น
                            nc.drawPath(lp, joyGlow) // เส้นทางของเป้า: เปิดปลาย (ยังไม่ปิดบ่วง)
                        } else {
                            lp.close()
                        }
                        nc.drawPath(lp, antWhite)
                        nc.drawPath(lp, antBlack)
                    }
                    val jp = joyPos
                    if (mode == CropMode.JOY && jp != null) { // เป้า: วงขาว-ดำ + กากบาทแดง
                        val jx = jp.x * vs + off.x
                        val jy = jp.y * vs + off.y
                        val jr = 11f * density
                        nc.drawCircle(jx, jy, jr, ringBlack)
                        nc.drawCircle(jx, jy, jr, ringWhite)
                        nc.drawLine(jx - jr * 1.7f, jy, jx + jr * 1.7f, jy, crossPaint)
                        nc.drawLine(jx, jy - jr * 1.7f, jx, jy + jr * 1.7f, crossPaint)
                    }
                    if (mode == CropMode.BEND) { // จุดควบคุมของทุกบ่วง (จุดที่เลือกเป็นสีชมพู)
                        for (lp in lassos) {
                            val ct = if (bd != null && lp === bd.orig) bd.ctrl else ctrlOf(lp)
                            ct.contours.forEachIndexed { ci, pts ->
                                pts.forEachIndexed { pi, q ->
                                    val sel = lp === selPath && ci == selC && pi == selP
                                    val x = q.x * vs + off.x
                                    val y = q.y * vs + off.y
                                    nc.drawCircle(x, y, (if (sel) 9f else 7f) * density, hFill)
                                    nc.drawCircle(x, y, (if (sel) 9f else 7f) * density, if (sel) hSel else hStroke)
                                }
                            }
                        }
                    }

                    val rt = touch
                    if (mode == CropMode.ERASE && rt != null) { // วงบอกขนาดยางลบใต้นิ้ว
                        val rr = max(eraserSize * vs / 2f, 2f * density)
                        nc.drawCircle(rt.x, rt.y, rr, ringBlack)
                        nc.drawCircle(rt.x, rt.y, rr, ringWhite)
                    }

                    // จออีกจอขนาดเล็ก (แว่นขยาย) ระหว่างลากนิ้ว: ขยายบริเวณรอบจุดที่กำลังวาด/ลาก ย้ายไปมุมอื่นเองเมื่อนิ้วเข้าใกล้
                    val lt = touch
                    val lf = lensImg
                    if (lt != null && lf != null) {
                        val sizePx = LoupeSize.boxPx(density, min(canvasSize.width, canvasSize.height).toFloat()) // ขนาดตั้งได้ในหน้าตั้งค่า (10–100)
                        val mg = 8f * density
                        val cw = canvasSize.width.toFloat()
                        val chh = canvasSize.height.toFloat()
                        val candsAll = listOf(
                            RectF(mg, mg, mg + sizePx, mg + sizePx),
                            RectF(cw - mg - sizePx, mg, cw - mg, mg + sizePx),
                            RectF(mg, chh - mg - sizePx, mg + sizePx, chh - mg),
                            RectF(cw - mg - sizePx, chh - mg - sizePx, cw - mg, chh - mg),
                        )
                        val cands = candsAll // จอยย้ายไปกลางล่างแล้ว มุมทั้ง 4 ว่างให้แว่นขยายใช้ได้
                        val clear = 56f * density
                        val box = cands.firstOrNull { r ->
                            lt.x < r.left - clear || lt.x > r.right + clear || lt.y < r.top - clear || lt.y > r.bottom + clear
                        } ?: cands[0]
                        val k = max(vs, min(vs * 3f, 12f)) // ขยาย 3 เท่าของมุมมองตอนนี้ (ไม่เกิน 12 เท่าของพิกเซลภาพ)
                        val lm = Matrix()
                        lm.setTranslate(-lf.x, -lf.y)
                        lm.postScale(k, k)
                        lm.postTranslate(box.centerX(), box.centerY())
                        val clipP = Path()
                        clipP.addRoundRect(box, 14f * density, 14f * density, Path.Direction.CW)
                        nc.save()
                        nc.clipPath(clipP)
                        nc.drawRect(box, loupeBg)
                        val imgR = RectF(0f, 0f, bw.toFloat(), bh.toFloat())
                        lm.mapRect(imgR)
                        nc.drawRect(imgR, checkerPaint)
                        nc.save()
                        nc.concat(lm) // ต่อจากนี้วาดด้วยพิกัดภาพตรงๆ ไม่ต้องสร้าง Path ใหม่ทุกเฟรม (ลื่นขึ้น)
                        val half = (sizePx / 2f) / k + 2f
                        val src = Rect(
                            floor(lf.x - half).toInt().coerceIn(0, bw),
                            floor(lf.y - half).toInt().coerceIn(0, bh),
                            ceil(lf.x + half).toInt().coerceIn(0, bw),
                            ceil(lf.y + half).toInt().coerceIn(0, bh),
                        )
                        if (src.width() > 0 && src.height() > 0) nc.drawBitmap(work, src, RectF(src), bmpPaint) // วาดเฉพาะส่วนที่เห็นในจอเล็ก
                        loupeBlack.strokeWidth = 3f * density / k
                        loupeWhite.strokeWidth = 1.5f * density / k
                        for (lp in lassos) {
                            val q = if (bd != null && lp === bd.orig) bd.preview else lp
                            nc.drawPath(q, loupeBlack)
                            nc.drawPath(q, loupeWhite)
                        }
                        if (mode == CropMode.ERASE) { // วงขนาดยางลบในแว่นขยาย
                            val er = max(eraserSize / 2f, 1.5f * density / k)
                            nc.drawCircle(lf.x, lf.y, er, loupeBlack)
                            nc.drawCircle(lf.x, lf.y, er, loupeWhite)
                        }
                        if (live.size >= 2) {
                            val lq = Path()
                            val from = max(0, live.size - 150) // เห็นแค่ช่วงปลายเส้น จึงวาดเฉพาะจุดล่าสุด
                            for (i in from until live.size) {
                                val o = live[i]
                                if (i == from) lq.moveTo(o.x, o.y) else lq.lineTo(o.x, o.y)
                            }
                            nc.drawPath(lq, loupeBlack)
                            nc.drawPath(lq, loupeWhite)
                        }
                        nc.restore()
                        if (mode == CropMode.BEND) {
                            for (lp in lassos) {
                                val ct = if (bd != null && lp === bd.orig) bd.ctrl else ctrlOf(lp)
                                ct.contours.forEachIndexed { ci, pts ->
                                    pts.forEachIndexed { pi, q ->
                                        val sel = lp === selPath && ci == selC && pi == selP
                                        val arr = floatArrayOf(q.x, q.y)
                                        lm.mapPoints(arr)
                                        nc.drawCircle(arr[0], arr[1], (if (sel) 7f else 5f) * density, hFill)
                                        nc.drawCircle(arr[0], arr[1], (if (sel) 7f else 5f) * density, if (sel) hSel else hStroke)
                                    }
                                }
                            }
                        }
                        val cx0 = box.centerX()
                        val cy0 = box.centerY()
                        val arm = 9f * density
                        nc.drawLine(cx0 - arm, cy0, cx0 + arm, cy0, crossPaint) // กากบาทแดง = จุดที่กำลังวาด/ลากอยู่พอดี
                        nc.drawLine(cx0, cy0 - arm, cx0, cy0 + arm, crossPaint)
                        nc.restore()
                        nc.drawPath(clipP, loupeBorder)
                    }
                }
            }

            // กลางล่างของพื้นที่ภาพ: แผงตัวเลข + จอยพร้อมช่องความเร็ว (ย้ายจากซ้ายล่างมากลาง)
            val areaWDp = canvasSize.width / density
            // จอยใหญ่ขึ้น 1 เท่า (120 -> 240 dp) แต่ไม่ให้ทับปุ่มขวาล่าง (กว้างราว 140 dp ต่อข้าง) ถ้าจอแคบจะลดลงเอง ไม่ต่ำกว่า 120 dp
            val joyDp = min(JOY_SIZE_DP, max(120f, areaWDp - 2f * 140f))
            Column(
                Modifier.align(Alignment.BottomCenter).padding(10.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
            ) {
                when (padTarget) {
                    PadTarget.ERASER -> FloatingPad(
                        title = "ขนาดยางลบ",
                        unit = "px",
                        initial = eraserSize,
                        onDismiss = { padTarget = PadTarget.NONE },
                        onOk = { v ->
                            eraserSize = v
                            padTarget = PadTarget.NONE
                        },
                    )
                    PadTarget.JOY_SPEED -> FloatingPad(
                        title = "ความเร็วจอย",
                        unit = "px/วิ",
                        initial = joySpeed,
                        onDismiss = { padTarget = PadTarget.NONE },
                        onOk = { v ->
                            joySpeed = v
                            padTarget = PadTarget.NONE
                        },
                    )
                    PadTarget.NONE -> {}
                }
                // แผงตัวเลขของความเร็วเปิดอยู่ = ซ่อนจอยชั่วคราว (แผงใหญ่ขึ้นแล้วจะทับจอย) ปิดแผงแล้วจอยกลับมา
                if (mode == CropMode.JOY && joyPlaced && overlay == null && padTarget != PadTarget.JOY_SPEED) {
                    Column(
                        verticalArrangement = Arrangement.spacedBy(6.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Text("ความเร็ว", color = Color(0xFFC9C4D4), fontSize = 12.sp)
                            Box(
                                Modifier
                                    .clip(RoundedCornerShape(14.dp))
                                    .background(Color(0xE6272734))
                                    .border(1.dp, Palette.Accent, RoundedCornerShape(14.dp))
                                    .clickable { padTarget = PadTarget.JOY_SPEED }
                                    .padding(horizontal = 12.dp, vertical = 8.dp),
                            ) { Text("${fmtNum(joySpeed)} px/วิ  ✎", color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.Medium) }
                        }
                        JoyStick(
                            sizeDp = joyDp.dp,
                            onMove = { x, y ->
                                joyVec[0] = x
                                joyVec[1] = y
                            },
                            onHold = { joyHeld = it },
                        )
                    }
                }
            }
            if (mode == CropMode.JOY && joyPlaced && overlay == null) { // ขวาล่าง: ปุ่มจัดการเส้นทางของเป้า
                Column(
                    Modifier.align(Alignment.BottomEnd).padding(10.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp),
                    horizontalAlignment = Alignment.End,
                ) {
                    OverlayButton(if (joyPick) "ยกเลิกเลือก" else "📍 เอาตรงนี้", primary = joyPick, enabled = joyHasLine) { joyPick = !joyPick }
                    OverlayButton("ปิดบ่วง ✓", primary = true, enabled = joyCanClose && !joyPick) { joyCommit() }
                    OverlayButton("เริ่มใหม่", primary = false, enabled = true) { joyReset() }
                }
            }

            val hint = when {
                overlay != null -> "เพิ่มรูป: ลาก 1 นิ้ว = ย้ายรูป · 2 นิ้ว = ย่อ/ขยายรูป · กด \"วางรูป\" เมื่อพอใจ (ส่วนที่ล้นกรอบภาพเดิมจะถูกตัด)"
                mode == CropMode.JOY && !joyPlaced -> "จอย: แตะจุดที่ต้องการให้เป้าปรากฏ · 2 นิ้ว = ซูม/เลื่อน"
                mode == CropMode.JOY && joyPick -> "แตะบนเส้นตรงจุดที่ต้องการเอา เป้าจะไปอยู่ตรงนั้น"
                mode == CropMode.JOY -> "บังคับเป้าด้วยจอยกลางล่าง (แตะที่อื่นไม่ติด) · เลยจุดไปแล้วกด \"เอาตรงนี้\" · เสร็จแล้วกด \"ปิดบ่วง\""
                mode == CropMode.ERASE && eraseTarget == EraseTarget.LINES -> "ยางลบตามเส้น: ลากผ่านเส้นบ่วง/จุดโค้งเพื่อลบช่วงนั้น (ปลายที่เหลือจะต่อกันด้วยเส้นตรง) · 2 นิ้ว = ซูม/เลื่อน"
                mode == CropMode.ERASE && eraseTarget == EraseTarget.INSIDE -> "ยางลบในบ่วง: ลบเฉพาะส่วนของภาพที่อยู่ในบ่วง · แตะช่องขนาดด้านล่างเพื่อใส่ขนาด · 2 นิ้ว = ซูม/เลื่อน"
                mode == CropMode.ERASE -> "ยางลบ: ลากนิ้วลบส่วนของภาพ · แตะช่องขนาดด้านล่างเพื่อใส่ขนาด · 2 นิ้ว = ซูม/เลื่อน"
                mode == CropMode.BEND && addPtMode && lassos.isNotEmpty() -> "เพิ่มจุด: แตะตรงตำแหน่งที่ต้องการ จุดจะขึ้นใต้นิ้ว ลากต่อเพื่อวางแล้วปล่อย · กด \"เพิ่มจุด\" อีกครั้งเพื่อกลับไปดัด"
                mode == CropMode.BEND && lassos.isEmpty() -> "ดัดโค้ง: ยังไม่มีบ่วง วาดบ่วงในโหมด \"เพิ่มบ่วง\" ก่อน"
                mode == CropMode.BEND -> "ดัดโค้ง: ลากจุดเพื่อดัดบ่วง · แตะที่เส้นบ่วงเพื่อแทรกจุด · แตะจุดแล้วกด \"ลบจุด\" · 2 นิ้ว = ซูม"
                mode == CropMode.REMOVE -> "ลบบ่วง: แตะในบ่วงเพื่อลบทั้งบ่วง · หรือวาดบ่วงทับเพื่อลบเฉพาะส่วน"
                lassos.isEmpty() -> "ลากนิ้ววาดบ่วงรอบส่วนที่ต้องการ · ไม่วาด = ใช้ทั้งภาพ · 2 นิ้ว = ซูม"
                else -> "เพิ่มบ่วง: บ่วงที่วาดทับกันจะรวมเป็นบ่วงเดียว · 2 นิ้ว = ซูม/เลื่อน"
            }
            if (!touching) { // ระหว่างลากนิ้วซ่อนข้อความไว้ ไม่ให้บังภาพและแว่นขยาย
                Box(
                    Modifier
                        .align(Alignment.TopCenter)
                        .padding(8.dp)
                        .clip(RoundedCornerShape(12.dp))
                        .background(Color(0xFFFFD600))
                        .padding(horizontal = 12.dp, vertical = 6.dp),
                ) { Text(hint, color = Color.Black, fontSize = 13.sp) }
            }
        }

        Column(
            Modifier.fillMaxWidth().background(Palette.Panel).padding(horizontal = 8.dp, vertical = 8.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            if (overlay != null) { // กำลังวางรูปที่เพิ่ม: ซ่อนเครื่องมืออื่นไว้ก่อน
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(
                        onClick = { overlay = null },
                        modifier = Modifier.weight(1f).heightIn(min = 48.dp),
                    ) { Text("ยกเลิกรูป") }
                    Button(
                        onClick = { placeOverlay() },
                        modifier = Modifier.weight(1f).heightIn(min = 48.dp),
                    ) { Text("วางรูป ✓") }
                }
            } else {
            if (mode == CropMode.BEND) { // ปุ่มของโหมดดัดโค้ง (แยกแถวไว้ให้เห็นครบโดยไม่ต้องเลื่อน)
                val sp = selValid()
                val selPts = if (sp != null) ctrlOf(sp).contours.getOrNull(selC)?.size ?: 0 else 0
                Row(
                    Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    FilterChip(
                        selected = addPtMode,
                        onClick = { addPtMode = !addPtMode },
                        enabled = lassos.isNotEmpty() && !busy,
                        label = { Text("＋ เพิ่มจุด") },
                        modifier = Modifier.weight(1f).heightIn(min = 48.dp),
                    )
                    OutlinedButton(
                        onClick = { deleteSelectedPoint() },
                        enabled = sp != null && selPts > 3 && !busy,
                        modifier = Modifier.weight(1f).heightIn(min = 48.dp),
                    ) { Text("✕ ลบจุด") }
                    FilterChip(
                        selected = sp != null && ctrlOf(sp).smooth,
                        onClick = { toggleSmooth() },
                        enabled = sp != null && !busy,
                        label = { Text("โค้งเนียน") },
                        modifier = Modifier.weight(1f).heightIn(min = 48.dp),
                    )
                }
            }
            if (mode == CropMode.ERASE) { // ช่องขนาดยางลบ: แตะแล้วขึ้นแผงตัวเลข (ไม่ต้องเปิดแป้นพิมพ์)
                Row(
                    Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Text("ขนาดยางลบ", color = Color(0xFFC9C4D4), fontSize = 14.sp)
                    Box(
                        Modifier
                            .weight(1f)
                            .heightIn(min = 48.dp)
                            .clip(RoundedCornerShape(14.dp))
                            .background(Palette.PanelHigh)
                            .border(1.dp, Palette.Accent, RoundedCornerShape(14.dp))
                            .clickable(enabled = !busy) { padTarget = PadTarget.ERASER }
                            .padding(horizontal = 14.dp),
                        contentAlignment = Alignment.CenterStart,
                    ) { Text("${fmtNum(eraserSize)} px  ✎", color = Color.White, fontSize = 17.sp, fontWeight = FontWeight.Medium) }
                }
                Row( // ยางลบลบอะไร
                    Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    FilterChip(
                        selected = eraseTarget == EraseTarget.IMAGE,
                        onClick = { eraseTarget = EraseTarget.IMAGE },
                        label = { Text("ลบภาพ", maxLines = 1) },
                        modifier = Modifier.weight(1f).heightIn(min = 48.dp),
                    )
                    FilterChip(
                        selected = eraseTarget == EraseTarget.INSIDE,
                        onClick = { eraseTarget = EraseTarget.INSIDE },
                        label = { Text("ลบในบ่วง", maxLines = 1) },
                        modifier = Modifier.weight(1f).heightIn(min = 48.dp),
                    )
                    FilterChip(
                        selected = eraseTarget == EraseTarget.LINES,
                        onClick = { eraseTarget = EraseTarget.LINES },
                        label = { Text("ลบตามเส้น", maxLines = 1) },
                        modifier = Modifier.weight(1f).heightIn(min = 48.dp),
                    )
                }
            }
            if (mode == CropMode.JOY) { // เป้าจอยวาดบ่วงแบบเพิ่มหรือลบ
                Row(
                    Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Text("เป้าวาด", color = Color(0xFFC9C4D4), fontSize = 14.sp)
                    FilterChip(
                        selected = joyOp == CropMode.ADD,
                        onClick = { joyOp = CropMode.ADD },
                        label = { Text("＋ เพิ่มส่วน") },
                        modifier = Modifier.weight(1f).heightIn(min = 48.dp),
                    )
                    FilterChip(
                        selected = joyOp == CropMode.REMOVE,
                        onClick = { joyOp = CropMode.REMOVE },
                        label = { Text("－ ลบส่วน") },
                        modifier = Modifier.weight(1f).heightIn(min = 48.dp),
                    )
                }
            }
            Row(
                Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                FilterChip(
                    selected = mode == CropMode.ADD,
                    onClick = { mode = CropMode.ADD },
                    label = { Text("เพิ่มบ่วง") },
                    modifier = Modifier.heightIn(min = 48.dp),
                )
                FilterChip(
                    selected = mode == CropMode.REMOVE,
                    onClick = { mode = CropMode.REMOVE },
                    label = { Text("ลบบ่วง") },
                    modifier = Modifier.heightIn(min = 48.dp),
                )
                FilterChip(
                    selected = mode == CropMode.BEND,
                    onClick = { mode = CropMode.BEND },
                    label = { Text("ดัดโค้ง") },
                    modifier = Modifier.heightIn(min = 48.dp),
                )
                FilterChip(
                    selected = mode == CropMode.ERASE,
                    onClick = { mode = CropMode.ERASE },
                    label = { Text("ยางลบ") },
                    modifier = Modifier.heightIn(min = 48.dp),
                )
                FilterChip(
                    selected = mode == CropMode.JOY,
                    onClick = { mode = CropMode.JOY },
                    label = { Text("จอย") },
                    modifier = Modifier.heightIn(min = 48.dp),
                )
                if (allowAddImage) {
                    OutlinedButton(
                        onClick = { picker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)) },
                        enabled = !busy,
                        modifier = Modifier.heightIn(min = 48.dp),
                    ) { Text("＋ เพิ่มรูป") }
                }
                OutlinedButton(
                    onClick = { undo() },
                    enabled = undoStack.isNotEmpty() && !busy,
                    modifier = Modifier.heightIn(min = 48.dp),
                ) { Text("↶ ย้อนกลับ") }
                OutlinedButton(
                    onClick = { redo() },
                    enabled = redoStack.isNotEmpty() && !busy,
                    modifier = Modifier.heightIn(min = 48.dp),
                ) { Text("↷ ทำซ้ำ") }
                OutlinedButton(
                    onClick = { fitView() },
                    modifier = Modifier.heightIn(min = 48.dp),
                ) { Text("พอดีจอ") }
            }
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(
                    onClick = { onCancel() },
                    enabled = !busy,
                    modifier = Modifier.weight(1f).heightIn(min = 48.dp),
                ) { Text("ยกเลิก") }
                Button(
                    onClick = { confirm() },
                    enabled = !busy,
                    modifier = Modifier.weight(1f).heightIn(min = 48.dp),
                ) { Text(if (busy) "กำลังตัด…" else "ตกลง ✓") }
            }
            } // จบ else ของ "กำลังวางรูป"
        }

    }
}

/** ขนาดจอย (dp) ที่ 100% ของ UI: เดิม 120 ตอนนี้ใหญ่ขึ้น 1 เท่า = 240 */
private const val JOY_SIZE_DP = 240f

/** จอยบังคับเป้า: ฐานกลม + ปุ่มกลมลากได้ ตอบสนองทันทีที่แตะ ปล่อยแล้วกลับกลาง onMove ส่งทิศ -1..1 */
@Composable
private fun JoyStick(sizeDp: Dp, onMove: (Float, Float) -> Unit, onHold: (Boolean) -> Unit) {
    var knob by remember { mutableStateOf(Offset.Zero) }
    var held by remember { mutableStateOf(false) }
    Canvas(
        Modifier
            .size(sizeDp)
            .pointerInput(Unit) {
                awaitEachGesture {
                    val down = awaitFirstDown(requireUnconsumed = false)
                    val r = size.width / 2f
                    val travel = r * 0.6f
                    fun update(pos: Offset) {
                        var v = Offset((pos.x - r) / travel, (pos.y - r) / travel)
                        val len = v.getDistance()
                        if (len > 1f) v = Offset(v.x / len, v.y / len)
                        knob = v
                        onMove(v.x, v.y)
                    }
                    held = true
                    onHold(true)
                    update(down.position)
                    down.consume()
                    while (true) {
                        val e = awaitPointerEvent()
                        val ch = e.changes.firstOrNull { it.id == down.id }
                        if (ch == null || !ch.pressed) break
                        update(ch.position)
                        ch.consume()
                    }
                    knob = Offset.Zero
                    held = false
                    onMove(0f, 0f)
                    onHold(false)
                }
            },
    ) {
        val r = size.minDimension / 2f
        val c = center
        drawCircle(Brush.radialGradient(listOf(Color(0xE62E2E40), Color(0xE612121A)), c, r), r, c)
        drawCircle(Palette.Accent.copy(alpha = if (held) 0.95f else 0.5f), r - 1.5.dp.toPx(), c, style = Stroke(2.dp.toPx()))
        drawCircle(Color(0x22FFFFFF), r * 0.6f, c, style = Stroke(1.dp.toPx()))
        drawLine(Color(0x33FFFFFF), Offset(c.x - r * 0.8f, c.y), Offset(c.x + r * 0.8f, c.y), 1.dp.toPx())
        drawLine(Color(0x33FFFFFF), Offset(c.x, c.y - r * 0.8f), Offset(c.x, c.y + r * 0.8f), 1.dp.toPx())
        val kr = r * 0.36f
        val kc = Offset(c.x + knob.x * r * 0.6f, c.y + knob.y * r * 0.6f)
        drawCircle(Brush.radialGradient(listOf(Color(0xFFE3DAFF), Palette.Accent, Color(0xFF6E52D6)), kc, kr), kr, kc)
        drawCircle(Color(0x66FFFFFF), kr, kc, style = Stroke(1.5.dp.toPx()))
    }
}

/** ปุ่มกลมแคปซูลที่วางทับภาพ (ปุ่มของโหมดจอย) */
@Composable
private fun OverlayButton(label: String, primary: Boolean, enabled: Boolean, onClick: () -> Unit) {
    val shape = RoundedCornerShape(50)
    Box(
        Modifier
            .heightIn(min = 44.dp)
            .clip(shape)
            .background(if (!enabled) Color(0x99272734) else if (primary) Palette.Accent else Color(0xE6272734))
            .border(1.dp, if (primary && enabled) Palette.Accent else Palette.Stroke, shape)
            .clickable(enabled = enabled, onClick = onClick)
            .padding(horizontal = 16.dp, vertical = 8.dp),
        contentAlignment = Alignment.Center,
    ) {
        Text(
            label,
            color = if (!enabled) Color(0x669E9AB0) else if (primary) Color(0xFF2A1A66) else Color.White,
            fontSize = 14.sp,
            fontWeight = FontWeight.Medium,
        )
    }
}
