package com.nop.cartoonstudio

import android.graphics.Bitmap
import android.graphics.BitmapShader
import android.graphics.DashPathEffect
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PathMeasure
import android.graphics.PorterDuff
import android.graphics.PorterDuffXfermode
import android.graphics.RectF
import android.graphics.Region
import android.graphics.Shader
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.gestures.calculateCentroid
import androidx.compose.foundation.gestures.calculatePan
import androidx.compose.foundation.gestures.calculateZoom
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.FilterChip
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.drawIntoCanvas
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.input.pointer.positionChanged
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlin.math.ceil
import kotlin.math.floor
import kotlin.math.max
import kotlin.math.min
import java.util.IdentityHashMap
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

private enum class CropMode { ADD, REMOVE, BEND }

/** จุดควบคุมของบ่วง (ไว้ดัดโค้ง): contours = จุดของแต่ละเส้นขอบปิด (พิกัดภาพ), smooth = ต่อจุดเป็นเส้นโค้งเนียน, fillType = ชนิดการเติมของบ่วงเดิม (รักษารูโหว่) */
private class Ctrl(val contours: List<List<Offset>>, val smooth: Boolean, val fillType: Path.FillType)

/** จุดที่กำลังลากอยู่ตอนดัดโค้ง: orig = บ่วงเดิม, ctrl/preview = ผลระหว่างลาก (ยังไม่บันทึกลงประวัติจนกว่าจะปล่อยนิ้ว) */
private class BendDrag(val orig: Path, val ctrl: Ctrl, val preview: Path)

/** จุดควบคุมที่นิ้วแตะโดน: บ่วง path, เส้นขอบที่ c, จุดที่ p */
private class Hit(val path: Path, val c: Int, val p: Int)

private fun projectOnSegment(p: Offset, a: Offset, b: Offset): Offset {
    val dx = b.x - a.x
    val dy = b.y - a.y
    val l2 = dx * dx + dy * dy
    if (l2 < 1e-9f) return a
    val t = (((p.x - a.x) * dx + (p.y - a.y) * dy) / l2).coerceIn(0f, 1f)
    return Offset(a.x + dx * t, a.y + dy * t)
}

/** ลดจำนวนจุดของเส้นด้วย Douglas-Peucker (ไม่ทำให้เส้นเรียบขึ้น จึงไม่กินซอกแคบ) */
private fun rdpOpen(pts: List<Offset>, eps: Float): List<Offset> {
    if (pts.size < 3) return pts
    val keep = BooleanArray(pts.size)
    keep[0] = true
    keep[pts.size - 1] = true
    val stack = ArrayDeque<IntArray>()
    stack.addLast(intArrayOf(0, pts.size - 1))
    while (stack.isNotEmpty()) {
        val seg = stack.removeLast()
        val a = seg[0]
        val b = seg[1]
        var maxD = 0f
        var idx = -1
        for (i in a + 1 until b) {
            val d = (pts[i] - projectOnSegment(pts[i], pts[a], pts[b])).getDistance()
            if (d > maxD) {
                maxD = d
                idx = i
            }
        }
        if (idx >= 0 && maxD > eps) {
            keep[idx] = true
            stack.addLast(intArrayOf(a, idx))
            stack.addLast(intArrayOf(idx, b))
        }
    }
    return pts.filterIndexed { i, _ -> keep[i] }
}

/** ลดจุดของเส้นขอบปิด (ได้อย่างน้อย 3 จุด และไม่เกิน ~80 จุด ให้ลากแก้ไหว) */
private fun simplifyClosed(raw: List<Offset>, eps0: Float): List<Offset> {
    var eps = eps0
    var out = rdpOpen(raw + raw[0], eps).dropLast(1)
    var guard = 0
    while (out.size > 80 && guard < 12) {
        eps *= 1.4f
        out = rdpOpen(raw + raw[0], eps).dropLast(1)
        guard++
    }
    if (out.size < 3) out = listOf(raw[0], raw[raw.size / 3], raw[raw.size * 2 / 3])
    return out
}

/** แตกบ่วง (Path) เป็นจุดควบคุมของแต่ละเส้นขอบ: เก็บแนวขอบเดิมไว้ ลดเหลือเฉพาะจุดที่จำเป็น tol = ความคลาดเคลื่อนที่ยอม (พิกเซลภาพ) */
private fun flattenToControls(p: Path, tol: Float): List<List<Offset>> {
    val pm = PathMeasure(p, true)
    val res = ArrayList<List<Offset>>()
    val pos = FloatArray(2)
    do {
        val len = pm.length
        if (len > 1f) {
            val n = (len / 2f).toInt().coerceIn(12, 800)
            val raw = ArrayList<Offset>(n)
            for (i in 0 until n) {
                pm.getPosTan(len * i / n, pos, null)
                raw.add(Offset(pos[0], pos[1]))
            }
            res.add(simplifyClosed(raw, tol))
        }
    } while (pm.nextContour())
    return res
}

/** สร้างบ่วงจากจุดควบคุม (smooth = เส้นโค้งเนียนผ่านทุกจุด ใช้สูตรเดียวกับเส้นทางเฟรม) */
private fun buildPath(c: Ctrl): Path {
    val out = Path()
    out.fillType = c.fillType
    for (pts in c.contours) {
        if (pts.size < 3) continue
        val d = PathMath.dense(pts, c.smooth, true).pts
        out.moveTo(d[0].x, d[0].y)
        for (i in 1 until d.size) out.lineTo(d[i].x, d[i].y)
        out.close()
    }
    return out
}

/** ระยะลากขั้นต่ำ (พิกเซลบนจอ) ที่ถือว่าเป็นการ "วาดบ่วง" ถ้าน้อยกว่านี้ถือเป็นการแตะ */
private const val MIN_STROKE_TRAVEL = 12f

/** จำนวนขั้นย้อนกลับสูงสุด */
private const val MAX_HISTORY = 50

// ───────────────────────── ตรรกะบ่วง (ไม่ผูกกับ UI) ─────────────────────────

private fun hasArea(p: Path): Boolean {
    if (p.isEmpty) return false
    val b = RectF()
    p.computeBounds(b, true)
    return b.width() > 1f && b.height() > 1f
}

private fun overlaps(a: Path, b: Path): Boolean {
    val r = Path()
    if (!r.op(a, b, Path.Op.INTERSECT)) return false
    return hasArea(r)
}

/** เพิ่มบ่วงใหม่: บ่วงที่ทับกันจะรวมเป็นบ่วงเดียว */
private fun addLasso(list: List<Path>, np: Path): List<Path> {
    var merged = np
    val rest = ArrayList<Path>()
    for (p in list) {
        if (overlaps(p, merged)) {
            val u = Path()
            if (u.op(p, merged, Path.Op.UNION)) merged = u else rest.add(p)
        } else {
            rest.add(p)
        }
    }
    rest.add(merged)
    return rest
}

/** ลบพื้นที่ของบ่วง [cut] ออกจากบ่วงที่มีอยู่ (บ่วงที่ไม่เหลือพื้นที่จะหายไป) */
private fun subtractLasso(list: List<Path>, cut: Path): List<Path> {
    val out = ArrayList<Path>()
    for (p in list) {
        if (!overlaps(p, cut)) {
            out.add(p)
            continue
        }
        val d = Path()
        if (d.op(p, cut, Path.Op.DIFFERENCE)) {
            if (hasArea(d)) out.add(d)
        } else {
            out.add(p)
        }
    }
    return out
}

private fun sameLassos(a: List<Path>, b: List<Path>): Boolean =
    a.size == b.size && a.indices.all { a[it] === b[it] }

private fun pathContains(p: Path, pt: Offset, w: Int, h: Int): Boolean {
    val r = Region()
    r.setPath(p, Region(0, 0, w, h))
    return r.contains(pt.x.toInt(), pt.y.toInt())
}

/**
 * ตัดภาพตามบ่วง: ได้ภาพขนาดเท่ากรอบที่ครอบบ่วงทั้งหมด ส่วนนอกบ่วงโปร่งใส
 * คืน null ถ้าบ่วงอยู่นอกภาพทั้งหมด (เรียกใน background thread)
 */
fun cropByLassos(src: Bitmap, lassos: List<Path>): Bitmap? {
    if (lassos.isEmpty()) return src
    val rect = RectF()
    val tmp = RectF()
    var first = true
    for (p in lassos) {
        p.computeBounds(tmp, true)
        if (first) {
            rect.set(tmp)
            first = false
        } else {
            rect.union(tmp)
        }
    }
    val l = floor(rect.left).toInt().coerceIn(0, src.width)
    val t = floor(rect.top).toInt().coerceIn(0, src.height)
    val r = ceil(rect.right).toInt().coerceIn(0, src.width)
    val b = ceil(rect.bottom).toInt().coerceIn(0, src.height)
    val w = r - l
    val h = b - t
    if (w < 1 || h < 1) return null

    val mask = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
    val mc = android.graphics.Canvas(mask)
    val fill = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.FILL
        color = android.graphics.Color.WHITE
    }
    mc.translate(-l.toFloat(), -t.toFloat())
    for (p in lassos) mc.drawPath(p, fill)

    val out = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
    val oc = android.graphics.Canvas(out)
    oc.drawBitmap(src, -l.toFloat(), -t.toFloat(), Paint(Paint.FILTER_BITMAP_FLAG))
    val dstIn = Paint().apply { xfermode = PorterDuffXfermode(PorterDuff.Mode.DST_IN) }
    oc.drawBitmap(mask, 0f, 0f, dstIn)
    mask.recycle()
    return out
}

// ───────────────────────── หน้าจอตัดภาพ ─────────────────────────

/**
 * หน้าตัดภาพตอนนำเข้า
 * - ลากนิ้วเดียววาดบ่วงรอบส่วนที่ต้องการ (ปล่อยนิ้วแล้วบ่วงปิดเอง) ขอบบ่วงเป็นเส้นปะ ขาว-ดำสลับกัน
 * - บ่วงที่วาดทับกันจะรวมเป็นบ่วงเดียว
 * - โหมด "เพิ่มบ่วง" / "ลบบ่วง" (ลบบ่วง: แตะในบ่วง = ลบทั้งบ่วง, วาดบ่วงทับ = ลบเฉพาะส่วนที่ทับ)
 * - ย้อนกลับ / ทำซ้ำ, ตกลง (ตัดแล้วนำเข้า), ยกเลิก (ไม่นำเข้าภาพนี้)
 * - 2 นิ้ว = ซูม/เลื่อนภาพเพื่อวาดละเอียด; ถ้าไม่วาดบ่วงเลย ตกลง = นำเข้าทั้งภาพ
 */
@Composable
fun ImageCropScreen(bitmap: Bitmap, onConfirm: (Bitmap) -> Unit, onCancel: () -> Unit) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val density = LocalDensity.current.density

    val bw = bitmap.width
    val bh = bitmap.height

    var mode by remember { mutableStateOf(CropMode.ADD) }
    var canvasSize by remember { mutableStateOf(IntSize.Zero) }
    var busy by remember { mutableStateOf(false) }

    // บ่วงที่ยืนยันแล้ว (พิกัดภาพ) — ไม่แก้ Path เดิม เปลี่ยนทั้งรายการเมื่อมีการแก้
    var lassos by remember { mutableStateOf<List<Path>>(emptyList()) }
    var undoStack by remember { mutableStateOf<List<List<Path>>>(emptyList()) }
    var redoStack by remember { mutableStateOf<List<List<Path>>>(emptyList()) }
    val live = remember { mutableStateListOf<Offset>() } // บ่วงที่กำลังวาด (พิกัดภาพ)

    // มุมมอง: จอ = ภาพ * vs + off
    var vs by remember { mutableFloatStateOf(1f) }
    var off by remember { mutableStateOf(Offset.Zero) }

    // ดัดโค้งบ่วง: จุดควบคุมของแต่ละบ่วง (เก็บตามตัวบ่วง ย้อนกลับ/ทำซ้ำแล้วจุดตามบ่วงเดิมกลับมาด้วย)
    val ctrlCache = remember { IdentityHashMap<Path, Ctrl>() }
    var selPath by remember { mutableStateOf<Path?>(null) } // บ่วงที่เลือกจุดไว้
    var selC by remember { mutableIntStateOf(0) } // เส้นขอบที่เลือก
    var selP by remember { mutableIntStateOf(0) } // จุดที่เลือก (ไว้กดลบจุด)
    var bendDrag by remember { mutableStateOf<BendDrag?>(null) }

    // แว่นขยายระหว่างลากนิ้ว: touch = ตำแหน่งนิ้วบนจอ (ไว้หลบ), lensImg = จุดบนภาพที่ขยายดู
    var touch by remember { mutableStateOf<Offset?>(null) }
    var lensImg by remember { mutableStateOf<Offset?>(null) }

    fun fitScale(): Float {
        if (canvasSize.width == 0 || canvasSize.height == 0) return 1f
        return min(canvasSize.width.toFloat() / bw, canvasSize.height.toFloat() / bh) * 0.96f
    }

    fun fitView() {
        if (canvasSize.width == 0 || canvasSize.height == 0) return
        val f = fitScale()
        vs = f
        off = Offset((canvasSize.width - bw * f) / 2f, (canvasSize.height - bh * f) / 2f)
    }

    LaunchedEffect(canvasSize) { fitView() }

    fun toImg(o: Offset): Offset = Offset(
        ((o.x - off.x) / vs).coerceIn(0f, bw.toFloat()),
        ((o.y - off.y) / vs).coerceIn(0f, bh.toFloat()),
    )

    fun toScreen(p: Path): Path {
        val m = Matrix()
        m.setScale(vs, vs)
        m.postTranslate(off.x, off.y)
        val q = Path(p)
        q.transform(m)
        return q
    }

    fun commit(newList: List<Path>) {
        if (sameLassos(newList, lassos)) return
        undoStack = (undoStack + listOf(lassos)).takeLast(MAX_HISTORY)
        redoStack = emptyList()
        lassos = newList
    }

    fun undo() {
        val prev = undoStack.lastOrNull() ?: return
        redoStack = redoStack + listOf(lassos)
        lassos = prev
        undoStack = undoStack.dropLast(1)
    }

    fun redo() {
        val next = redoStack.lastOrNull() ?: return
        undoStack = undoStack + listOf(lassos)
        lassos = next
        redoStack = redoStack.dropLast(1)
    }

    fun ctrlOf(p: Path): Ctrl = ctrlCache.getOrPut(p) { Ctrl(flattenToControls(p, 5f / max(vs, 0.01f)), false, p.fillType) }

    fun selValid(): Path? = selPath?.takeIf { sp -> lassos.any { it === sp } }

    /** แทนเส้นขอบ ci ของบ่วง orig ด้วยจุดชุดใหม่ แล้วบันทึกลงประวัติ (ย้อนกลับได้) */
    fun replaceContour(orig: Path, ci: Int, pts: List<Offset>, newSelP: Int) {
        val ct = ctrlOf(orig)
        val nc = Ctrl(ct.contours.mapIndexed { i, l -> if (i == ci) pts else l }, ct.smooth, ct.fillType)
        val np = buildPath(nc)
        ctrlCache[np] = nc
        commit(lassos.map { if (it === orig) np else it })
        selPath = np
        selC = ci
        selP = newSelP
    }

    fun hitHandle(pos: Offset): Hit? {
        var best: Hit? = null
        var bestD = 24f * density
        for (lp in lassos) {
            val ct = ctrlOf(lp)
            for (ci in ct.contours.indices) {
                val pts = ct.contours[ci]
                for (pi in pts.indices) {
                    val q = pts[pi]
                    val d = (Offset(q.x * vs + off.x, q.y * vs + off.y) - pos).getDistance()
                    if (d < bestD) {
                        bestD = d
                        best = Hit(lp, ci, pi)
                    }
                }
            }
        }
        return best
    }

    /** แตะใกล้เส้นขอบบ่วง = แทรกจุดควบคุมตรงนั้น (คืน false ถ้าไม่ได้แตะใกล้เส้น) */
    fun insertPointAt(pos: Offset): Boolean {
        var bestD = 20f * density
        var bestPath: Path? = null
        var bestC = 0
        var bestSeg = 0
        var bestPt = Offset.Zero
        for (lp in lassos) {
            val ct = ctrlOf(lp)
            for (ci in ct.contours.indices) {
                val d = PathMath.dense(ct.contours[ci], ct.smooth, true)
                for (i in 0 until d.pts.size - 1) {
                    val a = d.pts[i]
                    val b = d.pts[i + 1]
                    val proj = projectOnSegment(
                        pos,
                        Offset(a.x * vs + off.x, a.y * vs + off.y),
                        Offset(b.x * vs + off.x, b.y * vs + off.y),
                    )
                    val dist = (pos - proj).getDistance()
                    if (dist < bestD) {
                        bestD = dist
                        bestPath = lp
                        bestC = ci
                        bestSeg = d.seg[i]
                        bestPt = Offset((proj.x - off.x) / vs, (proj.y - off.y) / vs)
                    }
                }
            }
        }
        val bp = bestPath ?: return false
        val list = ctrlOf(bp).contours[bestC].toMutableList()
        list.add(bestSeg + 1, bestPt)
        replaceContour(bp, bestC, list, bestSeg + 1)
        return true
    }

    /** ปุ่ม "ลบจุด": ลบจุดควบคุมที่เลือก (ต้องเหลืออย่างน้อย 3 จุด) */
    fun deleteSelectedPoint() {
        val sp = selValid() ?: return
        val pts = ctrlOf(sp).contours.getOrNull(selC) ?: return
        if (pts.size <= 3 || selP !in pts.indices) {
            Toast.makeText(context, "ต้องเหลืออย่างน้อย 3 จุด", Toast.LENGTH_SHORT).show()
            return
        }
        replaceContour(sp, selC, pts.toMutableList().also { it.removeAt(selP) }, 0)
        selPath = null
    }

    /** ปุ่ม "โค้งเนียน": สลับบ่วงที่เลือกระหว่างต่อจุดเป็นเส้นตรง / เส้นโค้งเนียน */
    fun toggleSmooth() {
        val sp = selValid() ?: return
        val ct = ctrlOf(sp)
        val nc = Ctrl(ct.contours, !ct.smooth, ct.fillType)
        val np = buildPath(nc)
        ctrlCache[np] = nc
        commit(lassos.map { if (it === sp) np else it })
        selPath = np
    }

    fun finishStroke(pts: List<Offset>, travel: Float, tapAt: Offset) {
        if (mode == CropMode.REMOVE && travel < MIN_STROKE_TRAVEL) {
            // แตะในบ่วง = ลบทั้งบ่วง
            val p = toImg(tapAt)
            val hit = lassos.lastOrNull { pathContains(it, p, bw, bh) }
            if (hit != null) commit(lassos.filter { it !== hit })
            return
        }
        if (pts.size < 3 || travel < MIN_STROKE_TRAVEL) return
        val path = Path()
        path.moveTo(pts[0].x, pts[0].y)
        for (i in 1 until pts.size) path.lineTo(pts[i].x, pts[i].y)
        path.close()
        if (!hasArea(path)) return
        commit(if (mode == CropMode.ADD) addLasso(lassos, path) else subtractLasso(lassos, path))
    }

    fun confirm() {
        if (busy) return
        val current = lassos
        if (current.isEmpty()) {
            onConfirm(bitmap) // ไม่วาดบ่วง = ใช้ทั้งภาพ
            return
        }
        scope.launch {
            busy = true
            val r = withContext(Dispatchers.Default) { runCatching { cropByLassos(bitmap, current) } }
            busy = false
            r.onSuccess { out ->
                if (out == null) {
                    Toast.makeText(context, "บ่วงอยู่นอกภาพ ลองวาดใหม่", Toast.LENGTH_SHORT).show()
                } else {
                    onConfirm(out)
                }
            }.onFailure {
                Toast.makeText(context, "ตัดภาพไม่สำเร็จ: ${it.message ?: it.javaClass.simpleName}", Toast.LENGTH_LONG).show()
            }
        }
    }

    BackHandler(onBack = { if (!busy) onCancel() })

    // ── อุปกรณ์วาด ──
    val dash = 8f * density
    val antWhite = remember(density) {
        Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.STROKE
            color = android.graphics.Color.WHITE
            strokeWidth = 2.5f * density
            strokeJoin = Paint.Join.ROUND
        }
    }
    val antBlack = remember(density) {
        Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.STROKE
            color = android.graphics.Color.BLACK
            strokeWidth = 2.5f * density
            strokeJoin = Paint.Join.ROUND
        }
    }
    val dimPaint = remember { Paint().apply { color = 0x99000000.toInt() } }
    val bmpPaint = remember { Paint(Paint.FILTER_BITMAP_FLAG or Paint.ANTI_ALIAS_FLAG) }
    val checkerPaint = remember(density) {
        val s = max(1, (8f * density).toInt())
        val bm = Bitmap.createBitmap(s * 2, s * 2, Bitmap.Config.ARGB_8888)
        val c = android.graphics.Canvas(bm)
        c.drawColor(0xFFB8B8C0.toInt())
        val p = Paint().apply { color = 0xFF8E8E98.toInt() }
        c.drawRect(0f, 0f, s.toFloat(), s.toFloat(), p)
        c.drawRect(s.toFloat(), s.toFloat(), s * 2f, s * 2f, p)
        Paint().apply { shader = BitmapShader(bm, Shader.TileMode.REPEAT, Shader.TileMode.REPEAT) }
    }
    val loupeBg = remember { Paint().apply { color = 0xFF1E1E26.toInt() } }
    val loupeBorder = remember(density) {
        Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.STROKE
            color = android.graphics.Color.WHITE
            strokeWidth = 2f * density
        }
    }
    val crossPaint = remember(density) {
        Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.STROKE
            color = 0xFFFF1744.toInt()
            strokeWidth = 1.5f * density
        }
    }
    val hFill = remember { Paint(Paint.ANTI_ALIAS_FLAG).apply { color = android.graphics.Color.WHITE } }
    val hStroke = remember(density) {
        Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.STROKE
            color = 0xFFB69DFF.toInt()
            strokeWidth = 2.5f * density
        }
    }
    val hSel = remember(density) {
        Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.STROKE
            color = 0xFFFF80AB.toInt()
            strokeWidth = 3.5f * density
        }
    }
    val ants = rememberInfiniteTransition(label = "ants")
    val phase by ants.animateFloat(
        initialValue = 0f,
        targetValue = dash * 2f,
        animationSpec = infiniteRepeatable(tween(900, easing = LinearEasing), RepeatMode.Restart),
        label = "antsPhase",
    )

    Column(
        Modifier
            .fillMaxSize()
            .background(Palette.Bg)
            .systemBarsPadding()
            .pointerInput(Unit) { detectTapGestures { } }, // กันการสัมผัสทะลุไปหน้าด้านล่าง
    ) {
        Box(Modifier.weight(1f).fillMaxWidth().background(Color(0xFF2A2A34))) {
            Canvas(
                Modifier
                    .fillMaxSize()
                    .onSizeChanged { canvasSize = it }
                    .pointerInput(mode) {
                        awaitEachGesture {
                            val down = awaitFirstDown(requireUnconsumed = false)
                            var drawing = true
                            var travel = 0f
                            var last = down.position
                            val bend = mode == CropMode.BEND
                            var hit: Hit? = null
                            var gap = Offset.Zero // ระยะจากนิ้วถึงจุดที่จับ (กันจุดกระโดดมาอยู่ใต้นิ้ว)
                            live.clear()
                            if (bend) { // โหมดดัดโค้ง: แตะโดนจุดควบคุม = เลือกและลากจุดนั้น
                                hit = hitHandle(down.position)
                                val h0 = hit
                                if (h0 != null) {
                                    selPath = h0.path
                                    selC = h0.c
                                    selP = h0.p
                                    val q = ctrlOf(h0.path).contours[h0.c][h0.p]
                                    gap = Offset(q.x * vs + off.x, q.y * vs + off.y) - down.position
                                }
                            } else {
                                live.add(toImg(down.position))
                            }
                            do {
                                val event = awaitPointerEvent()
                                val pressedCount = event.changes.count { it.pressed }
                                if (pressedCount >= 2) {
                                    // 2 นิ้ว = ซูม/เลื่อนภาพ (ยกเลิกบ่วงที่กำลังวาดอยู่)
                                    if (drawing) {
                                        drawing = false
                                        live.clear()
                                        bendDrag = null // ยกเลิกการลากจุดที่ค้างอยู่
                                        touch = null
                                        lensImg = null
                                    }
                                    val zoom = event.calculateZoom()
                                    val pan = event.calculatePan()
                                    val c = event.calculateCentroid()
                                    val f = fitScale()
                                    val s0 = vs
                                    val s1 = (s0 * zoom).coerceIn(f * 0.5f, f * 20f)
                                    val k = s1 / s0
                                    off = Offset(
                                        c.x - (c.x - off.x) * k + pan.x,
                                        c.y - (c.y - off.y) * k + pan.y,
                                    )
                                    vs = s1
                                    event.changes.forEach { if (it.positionChanged()) it.consume() }
                                } else if (drawing) {
                                    val ch = event.changes.firstOrNull { it.pressed }
                                    if (ch != null) {
                                        val d = (ch.position - last).getDistance()
                                        if (d >= 3f) {
                                            travel += d
                                            last = ch.position
                                            touch = ch.position
                                            if (bend) {
                                                val hh = hit
                                                if (hh != null) { // ลากจุดควบคุม: ดูตัวอย่างทันที ยังไม่บันทึกลงประวัติจนกว่าจะปล่อยนิ้ว
                                                    val ct0 = ctrlOf(hh.path)
                                                    val np0 = toImg(ch.position + gap)
                                                    val list = ct0.contours[hh.c].toMutableList()
                                                    list[hh.p] = np0
                                                    val nc2 = Ctrl(ct0.contours.mapIndexed { i, l -> if (i == hh.c) list else l }, ct0.smooth, ct0.fillType)
                                                    bendDrag = BendDrag(hh.path, nc2, buildPath(nc2))
                                                    lensImg = np0
                                                }
                                            } else {
                                                val np1 = toImg(ch.position)
                                                live.add(np1)
                                                lensImg = np1
                                            }
                                        }
                                        ch.consume()
                                    }
                                }
                            } while (event.changes.any { it.pressed })

                            if (drawing) {
                                if (bend) {
                                    val hh = hit
                                    val bd = bendDrag
                                    if (hh != null) {
                                        if (bd != null) { // ปล่อยนิ้ว: บันทึกบ่วงที่ดัดแล้วลงประวัติ (ย้อนกลับได้)
                                            ctrlCache[bd.preview] = bd.ctrl
                                            commit(lassos.map { if (it === hh.path) bd.preview else it })
                                            selPath = bd.preview
                                        }
                                    } else if (travel < MIN_STROKE_TRAVEL) { // แตะที่ว่าง: แตะใกล้เส้นบ่วง = แทรกจุด ไม่ใช่ = เลิกเลือก
                                        if (!insertPointAt(down.position)) selPath = null
                                    }
                                } else {
                                    val pts = live.toList()
                                    live.clear()
                                    finishStroke(pts, travel, down.position)
                                }
                            } else {
                                live.clear()
                            }
                            bendDrag = null
                            touch = null
                            lensImg = null
                        }
                    },
            ) {
                if (canvasSize.width == 0) return@Canvas
                val dst = RectF(off.x, off.y, off.x + bw * vs, off.y + bh * vs)
                val dashWhite = DashPathEffect(floatArrayOf(dash, dash), phase)
                val dashBlack = DashPathEffect(floatArrayOf(dash, dash), phase + dash)
                antWhite.pathEffect = dashWhite
                antBlack.pathEffect = dashBlack
                drawIntoCanvas { c ->
                    val nc = c.nativeCanvas
                    nc.drawRect(dst, checkerPaint)
                    nc.drawBitmap(bitmap, null, dst, bmpPaint)

                    val bd = bendDrag
                    val screenLassos = lassos.map { toScreen(if (bd != null && it === bd.orig) bd.preview else it) }
                    if (screenLassos.isNotEmpty()) {
                        // ทำให้ส่วนนอกบ่วงมืดลง เพื่อเห็นชัดว่าส่วนไหนจะถูกเก็บไว้
                        nc.save()
                        for (sp in screenLassos) nc.clipOutPath(sp)
                        nc.drawRect(dst, dimPaint)
                        nc.restore()
                    }
                    for (sp in screenLassos) {
                        nc.drawPath(sp, antWhite)
                        nc.drawPath(sp, antBlack)
                    }
                    if (live.size >= 2) {
                        val lp = Path()
                        live.forEachIndexed { i, o ->
                            val x = o.x * vs + off.x
                            val y = o.y * vs + off.y
                            if (i == 0) lp.moveTo(x, y) else lp.lineTo(x, y)
                        }
                        lp.close()
                        nc.drawPath(lp, antWhite)
                        nc.drawPath(lp, antBlack)
                    }
                    if (mode == CropMode.BEND) { // จุดควบคุมของทุกบ่วง (จุดที่เลือกเป็นสีชมพู)
                        for (lp in lassos) {
                            val ct = if (bd != null && lp === bd.orig) bd.ctrl else ctrlOf(lp)
                            ct.contours.forEachIndexed { ci, pts ->
                                pts.forEachIndexed { pi, q ->
                                    val sel = lp === selPath && ci == selC && pi == selP
                                    val x = q.x * vs + off.x
                                    val y = q.y * vs + off.y
                                    nc.drawCircle(x, y, (if (sel) 9f else 7f) * density, hFill)
                                    nc.drawCircle(x, y, (if (sel) 9f else 7f) * density, if (sel) hSel else hStroke)
                                }
                            }
                        }
                    }

                    // จออีกจอขนาดเล็ก (แว่นขยาย) ระหว่างลากนิ้ว: ขยายบริเวณรอบจุดที่กำลังวาด/ลาก ย้ายไปมุมอื่นเองเมื่อนิ้วเข้าใกล้
                    val lt = touch
                    val lf = lensImg
                    if (lt != null && lf != null) {
                        val sizePx = 130f * density
                        val mg = 8f * density
                        val cw = canvasSize.width.toFloat()
                        val chh = canvasSize.height.toFloat()
                        val cands = listOf(
                            RectF(mg, mg, mg + sizePx, mg + sizePx),
                            RectF(cw - mg - sizePx, mg, cw - mg, mg + sizePx),
                            RectF(mg, chh - mg - sizePx, mg + sizePx, chh - mg),
                            RectF(cw - mg - sizePx, chh - mg - sizePx, cw - mg, chh - mg),
                        )
                        val clear = 56f * density
                        val box = cands.firstOrNull { r ->
                            lt.x < r.left - clear || lt.x > r.right + clear || lt.y < r.top - clear || lt.y > r.bottom + clear
                        } ?: cands[0]
                        val k = max(vs, min(vs * 3f, 12f)) // ขยาย 3 เท่าของมุมมองตอนนี้ (ไม่เกิน 12 เท่าของพิกเซลภาพ)
                        val lm = Matrix()
                        lm.setTranslate(-lf.x, -lf.y)
                        lm.postScale(k, k)
                        lm.postTranslate(box.centerX(), box.centerY())
                        val clipP = Path()
                        clipP.addRoundRect(box, 14f * density, 14f * density, Path.Direction.CW)
                        nc.save()
                        nc.clipPath(clipP)
                        nc.drawRect(box, loupeBg)
                        val imgR = RectF(0f, 0f, bw.toFloat(), bh.toFloat())
                        lm.mapRect(imgR)
                        nc.drawRect(imgR, checkerPaint)
                        nc.drawBitmap(bitmap, lm, bmpPaint)
                        val lps = lassos.map { lp ->
                            val q = Path(if (bd != null && lp === bd.orig) bd.preview else lp)
                            q.transform(lm)
                            q
                        }
                        if (lps.isNotEmpty()) {
                            nc.save()
                            for (sp in lps) nc.clipOutPath(sp)
                            nc.drawRect(imgR, dimPaint)
                            nc.restore()
                        }
                        for (sp in lps) {
                            nc.drawPath(sp, antWhite)
                            nc.drawPath(sp, antBlack)
                        }
                        if (live.size >= 2) {
                            val lq = Path()
                            live.forEachIndexed { i, o -> if (i == 0) lq.moveTo(o.x, o.y) else lq.lineTo(o.x, o.y) }
                            lq.close()
                            lq.transform(lm)
                            nc.drawPath(lq, antWhite)
                            nc.drawPath(lq, antBlack)
                        }
                        if (mode == CropMode.BEND) {
                            for (lp in lassos) {
                                val ct = if (bd != null && lp === bd.orig) bd.ctrl else ctrlOf(lp)
                                ct.contours.forEachIndexed { ci, pts ->
                                    pts.forEachIndexed { pi, q ->
                                        val sel = lp === selPath && ci == selC && pi == selP
                                        val arr = floatArrayOf(q.x, q.y)
                                        lm.mapPoints(arr)
                                        nc.drawCircle(arr[0], arr[1], (if (sel) 7f else 5f) * density, hFill)
                                        nc.drawCircle(arr[0], arr[1], (if (sel) 7f else 5f) * density, if (sel) hSel else hStroke)
                                    }
                                }
                            }
                        }
                        val cx0 = box.centerX()
                        val cy0 = box.centerY()
                        val arm = 9f * density
                        nc.drawLine(cx0 - arm, cy0, cx0 + arm, cy0, crossPaint) // กากบาทแดง = จุดที่กำลังวาด/ลากอยู่พอดี
                        nc.drawLine(cx0, cy0 - arm, cx0, cy0 + arm, crossPaint)
                        nc.restore()
                        nc.drawPath(clipP, loupeBorder)
                    }
                }
            }

            val hint = when {
                mode == CropMode.BEND && lassos.isEmpty() -> "ดัดโค้ง: ยังไม่มีบ่วง วาดบ่วงในโหมด \"เพิ่มบ่วง\" ก่อน"
                mode == CropMode.BEND -> "ดัดโค้ง: ลากจุดเพื่อดัดบ่วง · แตะที่เส้นบ่วงเพื่อแทรกจุด · แตะจุดแล้วกด \"ลบจุด\" · 2 นิ้ว = ซูม"
                mode == CropMode.REMOVE -> "ลบบ่วง: แตะในบ่วงเพื่อลบทั้งบ่วง · หรือวาดบ่วงทับเพื่อลบเฉพาะส่วน"
                lassos.isEmpty() -> "ลากนิ้ววาดบ่วงรอบส่วนที่ต้องการ · ไม่วาด = ใช้ทั้งภาพ · 2 นิ้ว = ซูม"
                else -> "เพิ่มบ่วง: บ่วงที่วาดทับกันจะรวมเป็นบ่วงเดียว · 2 นิ้ว = ซูม/เลื่อน"
            }
            if (touch == null) { // ระหว่างลากนิ้วซ่อนข้อความไว้ ไม่ให้บังภาพและแว่นขยาย
                Box(
                    Modifier
                        .align(Alignment.TopCenter)
                        .padding(8.dp)
                        .clip(RoundedCornerShape(12.dp))
                        .background(Color(0xFFFFD600))
                        .padding(horizontal = 12.dp, vertical = 6.dp),
                ) { Text(hint, color = Color.Black, fontSize = 13.sp) }
            }
        }

        Column(
            Modifier.fillMaxWidth().background(Palette.Panel).padding(horizontal = 8.dp, vertical = 8.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            if (mode == CropMode.BEND) { // ปุ่มของโหมดดัดโค้ง (แยกแถวไว้ให้เห็นครบโดยไม่ต้องเลื่อน)
                val sp = selValid()
                val selPts = if (sp != null) ctrlOf(sp).contours.getOrNull(selC)?.size ?: 0 else 0
                Row(
                    Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    OutlinedButton(
                        onClick = { deleteSelectedPoint() },
                        enabled = sp != null && selPts > 3 && !busy,
                        modifier = Modifier.weight(1f).heightIn(min = 48.dp),
                    ) { Text("✕ ลบจุด") }
                    FilterChip(
                        selected = sp != null && ctrlOf(sp).smooth,
                        onClick = { toggleSmooth() },
                        enabled = sp != null && !busy,
                        label = { Text("โค้งเนียน") },
                        modifier = Modifier.weight(1f).heightIn(min = 48.dp),
                    )
                }
            }
            Row(
                Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                FilterChip(
                    selected = mode == CropMode.ADD,
                    onClick = { mode = CropMode.ADD },
                    label = { Text("เพิ่มบ่วง") },
                    modifier = Modifier.heightIn(min = 48.dp),
                )
                FilterChip(
                    selected = mode == CropMode.REMOVE,
                    onClick = { mode = CropMode.REMOVE },
                    label = { Text("ลบบ่วง") },
                    modifier = Modifier.heightIn(min = 48.dp),
                )
                FilterChip(
                    selected = mode == CropMode.BEND,
                    onClick = { mode = CropMode.BEND },
                    label = { Text("ดัดโค้ง") },
                    modifier = Modifier.heightIn(min = 48.dp),
                )
                OutlinedButton(
                    onClick = { undo() },
                    enabled = undoStack.isNotEmpty() && !busy,
                    modifier = Modifier.heightIn(min = 48.dp),
                ) { Text("↶ ย้อนกลับ") }
                OutlinedButton(
                    onClick = { redo() },
                    enabled = redoStack.isNotEmpty() && !busy,
                    modifier = Modifier.heightIn(min = 48.dp),
                ) { Text("↷ ทำซ้ำ") }
                OutlinedButton(
                    onClick = { fitView() },
                    modifier = Modifier.heightIn(min = 48.dp),
                ) { Text("พอดีจอ") }
            }
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(
                    onClick = { onCancel() },
                    enabled = !busy,
                    modifier = Modifier.weight(1f).heightIn(min = 48.dp),
                ) { Text("ยกเลิก") }
                Button(
                    onClick = { confirm() },
                    enabled = !busy,
                    modifier = Modifier.weight(1f).heightIn(min = 48.dp),
                ) { Text(if (busy) "กำลังตัด…" else "ตกลง ✓") }
            }
        }
    }
}
