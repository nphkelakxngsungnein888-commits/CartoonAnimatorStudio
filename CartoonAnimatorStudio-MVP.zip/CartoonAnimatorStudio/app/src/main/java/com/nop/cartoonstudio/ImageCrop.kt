package com.nop.cartoonstudio

import android.graphics.Bitmap
import android.graphics.BitmapShader
import android.graphics.DashPathEffect
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PorterDuff
import android.graphics.PorterDuffXfermode
import android.graphics.RectF
import android.graphics.Region
import android.graphics.Shader
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.gestures.calculateCentroid
import androidx.compose.foundation.gestures.calculatePan
import androidx.compose.foundation.gestures.calculateZoom
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.FilterChip
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.drawIntoCanvas
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.input.pointer.positionChanged
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlin.math.ceil
import kotlin.math.floor
import kotlin.math.max
import kotlin.math.min
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

private enum class CropMode { ADD, REMOVE }

/** ระยะลากขั้นต่ำ (พิกเซลบนจอ) ที่ถือว่าเป็นการ "วาดบ่วง" ถ้าน้อยกว่านี้ถือเป็นการแตะ */
private const val MIN_STROKE_TRAVEL = 12f

/** จำนวนขั้นย้อนกลับสูงสุด */
private const val MAX_HISTORY = 50

// ───────────────────────── ตรรกะบ่วง (ไม่ผูกกับ UI) ─────────────────────────

private fun hasArea(p: Path): Boolean {
    if (p.isEmpty) return false
    val b = RectF()
    p.computeBounds(b, true)
    return b.width() > 1f && b.height() > 1f
}

private fun overlaps(a: Path, b: Path): Boolean {
    val r = Path()
    if (!r.op(a, b, Path.Op.INTERSECT)) return false
    return hasArea(r)
}

/** เพิ่มบ่วงใหม่: บ่วงที่ทับกันจะรวมเป็นบ่วงเดียว */
private fun addLasso(list: List<Path>, np: Path): List<Path> {
    var merged = np
    val rest = ArrayList<Path>()
    for (p in list) {
        if (overlaps(p, merged)) {
            val u = Path()
            if (u.op(p, merged, Path.Op.UNION)) merged = u else rest.add(p)
        } else {
            rest.add(p)
        }
    }
    rest.add(merged)
    return rest
}

/** ลบพื้นที่ของบ่วง [cut] ออกจากบ่วงที่มีอยู่ (บ่วงที่ไม่เหลือพื้นที่จะหายไป) */
private fun subtractLasso(list: List<Path>, cut: Path): List<Path> {
    val out = ArrayList<Path>()
    for (p in list) {
        if (!overlaps(p, cut)) {
            out.add(p)
            continue
        }
        val d = Path()
        if (d.op(p, cut, Path.Op.DIFFERENCE)) {
            if (hasArea(d)) out.add(d)
        } else {
            out.add(p)
        }
    }
    return out
}

private fun sameLassos(a: List<Path>, b: List<Path>): Boolean =
    a.size == b.size && a.indices.all { a[it] === b[it] }

private fun pathContains(p: Path, pt: Offset, w: Int, h: Int): Boolean {
    val r = Region()
    r.setPath(p, Region(0, 0, w, h))
    return r.contains(pt.x.toInt(), pt.y.toInt())
}

/**
 * ตัดภาพตามบ่วง: ได้ภาพขนาดเท่ากรอบที่ครอบบ่วงทั้งหมด ส่วนนอกบ่วงโปร่งใส
 * คืน null ถ้าบ่วงอยู่นอกภาพทั้งหมด (เรียกใน background thread)
 */
fun cropByLassos(src: Bitmap, lassos: List<Path>): Bitmap? {
    if (lassos.isEmpty()) return src
    val rect = RectF()
    val tmp = RectF()
    var first = true
    for (p in lassos) {
        p.computeBounds(tmp, true)
        if (first) {
            rect.set(tmp)
            first = false
        } else {
            rect.union(tmp)
        }
    }
    val l = floor(rect.left).toInt().coerceIn(0, src.width)
    val t = floor(rect.top).toInt().coerceIn(0, src.height)
    val r = ceil(rect.right).toInt().coerceIn(0, src.width)
    val b = ceil(rect.bottom).toInt().coerceIn(0, src.height)
    val w = r - l
    val h = b - t
    if (w < 1 || h < 1) return null

    val mask = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
    val mc = android.graphics.Canvas(mask)
    val fill = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.FILL
        color = android.graphics.Color.WHITE
    }
    mc.translate(-l.toFloat(), -t.toFloat())
    for (p in lassos) mc.drawPath(p, fill)

    val out = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
    val oc = android.graphics.Canvas(out)
    oc.drawBitmap(src, -l.toFloat(), -t.toFloat(), Paint(Paint.FILTER_BITMAP_FLAG))
    val dstIn = Paint().apply { xfermode = PorterDuffXfermode(PorterDuff.Mode.DST_IN) }
    oc.drawBitmap(mask, 0f, 0f, dstIn)
    mask.recycle()
    return out
}

// ───────────────────────── หน้าจอตัดภาพ ─────────────────────────

/**
 * หน้าตัดภาพตอนนำเข้า
 * - ลากนิ้วเดียววาดบ่วงรอบส่วนที่ต้องการ (ปล่อยนิ้วแล้วบ่วงปิดเอง) ขอบบ่วงเป็นเส้นปะ ขาว-ดำสลับกัน
 * - บ่วงที่วาดทับกันจะรวมเป็นบ่วงเดียว
 * - โหมด "เพิ่มบ่วง" / "ลบบ่วง" (ลบบ่วง: แตะในบ่วง = ลบทั้งบ่วง, วาดบ่วงทับ = ลบเฉพาะส่วนที่ทับ)
 * - ย้อนกลับ / ทำซ้ำ, ตกลง (ตัดแล้วนำเข้า), ยกเลิก (ไม่นำเข้าภาพนี้)
 * - 2 นิ้ว = ซูม/เลื่อนภาพเพื่อวาดละเอียด; ถ้าไม่วาดบ่วงเลย ตกลง = นำเข้าทั้งภาพ
 */
@Composable
fun ImageCropScreen(bitmap: Bitmap, onConfirm: (Bitmap) -> Unit, onCancel: () -> Unit) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val density = LocalDensity.current.density

    val bw = bitmap.width
    val bh = bitmap.height

    var mode by remember { mutableStateOf(CropMode.ADD) }
    var canvasSize by remember { mutableStateOf(IntSize.Zero) }
    var busy by remember { mutableStateOf(false) }

    // บ่วงที่ยืนยันแล้ว (พิกัดภาพ) — ไม่แก้ Path เดิม เปลี่ยนทั้งรายการเมื่อมีการแก้
    var lassos by remember { mutableStateOf<List<Path>>(emptyList()) }
    var undoStack by remember { mutableStateOf<List<List<Path>>>(emptyList()) }
    var redoStack by remember { mutableStateOf<List<List<Path>>>(emptyList()) }
    val live = remember { mutableStateListOf<Offset>() } // บ่วงที่กำลังวาด (พิกัดภาพ)

    // มุมมอง: จอ = ภาพ * vs + off
    var vs by remember { mutableFloatStateOf(1f) }
    var off by remember { mutableStateOf(Offset.Zero) }

    fun fitScale(): Float {
        if (canvasSize.width == 0 || canvasSize.height == 0) return 1f
        return min(canvasSize.width.toFloat() / bw, canvasSize.height.toFloat() / bh) * 0.96f
    }

    fun fitView() {
        if (canvasSize.width == 0 || canvasSize.height == 0) return
        val f = fitScale()
        vs = f
        off = Offset((canvasSize.width - bw * f) / 2f, (canvasSize.height - bh * f) / 2f)
    }

    LaunchedEffect(canvasSize) { fitView() }

    fun toImg(o: Offset): Offset = Offset(
        ((o.x - off.x) / vs).coerceIn(0f, bw.toFloat()),
        ((o.y - off.y) / vs).coerceIn(0f, bh.toFloat()),
    )

    fun toScreen(p: Path): Path {
        val m = Matrix()
        m.setScale(vs, vs)
        m.postTranslate(off.x, off.y)
        val q = Path(p)
        q.transform(m)
        return q
    }

    fun commit(newList: List<Path>) {
        if (sameLassos(newList, lassos)) return
        undoStack = (undoStack + listOf(lassos)).takeLast(MAX_HISTORY)
        redoStack = emptyList()
        lassos = newList
    }

    fun undo() {
        val prev = undoStack.lastOrNull() ?: return
        redoStack = redoStack + listOf(lassos)
        lassos = prev
        undoStack = undoStack.dropLast(1)
    }

    fun redo() {
        val next = redoStack.lastOrNull() ?: return
        undoStack = undoStack + listOf(lassos)
        lassos = next
        redoStack = redoStack.dropLast(1)
    }

    fun finishStroke(pts: List<Offset>, travel: Float, tapAt: Offset) {
        if (mode == CropMode.REMOVE && travel < MIN_STROKE_TRAVEL) {
            // แตะในบ่วง = ลบทั้งบ่วง
            val p = toImg(tapAt)
            val hit = lassos.lastOrNull { pathContains(it, p, bw, bh) }
            if (hit != null) commit(lassos.filter { it !== hit })
            return
        }
        if (pts.size < 3 || travel < MIN_STROKE_TRAVEL) return
        val path = Path()
        path.moveTo(pts[0].x, pts[0].y)
        for (i in 1 until pts.size) path.lineTo(pts[i].x, pts[i].y)
        path.close()
        if (!hasArea(path)) return
        commit(if (mode == CropMode.ADD) addLasso(lassos, path) else subtractLasso(lassos, path))
    }

    fun confirm() {
        if (busy) return
        val current = lassos
        if (current.isEmpty()) {
            onConfirm(bitmap) // ไม่วาดบ่วง = ใช้ทั้งภาพ
            return
        }
        scope.launch {
            busy = true
            val r = withContext(Dispatchers.Default) { runCatching { cropByLassos(bitmap, current) } }
            busy = false
            r.onSuccess { out ->
                if (out == null) {
                    Toast.makeText(context, "บ่วงอยู่นอกภาพ ลองวาดใหม่", Toast.LENGTH_SHORT).show()
                } else {
                    onConfirm(out)
                }
            }.onFailure {
                Toast.makeText(context, "ตัดภาพไม่สำเร็จ: ${it.message ?: it.javaClass.simpleName}", Toast.LENGTH_LONG).show()
            }
        }
    }

    BackHandler(onBack = { if (!busy) onCancel() })

    // ── อุปกรณ์วาด ──
    val dash = 8f * density
    val antWhite = remember(density) {
        Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.STROKE
            color = android.graphics.Color.WHITE
            strokeWidth = 2.5f * density
            strokeJoin = Paint.Join.ROUND
        }
    }
    val antBlack = remember(density) {
        Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.STROKE
            color = android.graphics.Color.BLACK
            strokeWidth = 2.5f * density
            strokeJoin = Paint.Join.ROUND
        }
    }
    val dimPaint = remember { Paint().apply { color = 0x99000000.toInt() } }
    val bmpPaint = remember { Paint(Paint.FILTER_BITMAP_FLAG or Paint.ANTI_ALIAS_FLAG) }
    val checkerPaint = remember(density) {
        val s = max(1, (8f * density).toInt())
        val bm = Bitmap.createBitmap(s * 2, s * 2, Bitmap.Config.ARGB_8888)
        val c = android.graphics.Canvas(bm)
        c.drawColor(0xFFB8B8C0.toInt())
        val p = Paint().apply { color = 0xFF8E8E98.toInt() }
        c.drawRect(0f, 0f, s.toFloat(), s.toFloat(), p)
        c.drawRect(s.toFloat(), s.toFloat(), s * 2f, s * 2f, p)
        Paint().apply { shader = BitmapShader(bm, Shader.TileMode.REPEAT, Shader.TileMode.REPEAT) }
    }
    val ants = rememberInfiniteTransition(label = "ants")
    val phase by ants.animateFloat(
        initialValue = 0f,
        targetValue = dash * 2f,
        animationSpec = infiniteRepeatable(tween(900, easing = LinearEasing), RepeatMode.Restart),
        label = "antsPhase",
    )

    Column(
        Modifier
            .fillMaxSize()
            .background(Palette.Bg)
            .systemBarsPadding()
            .pointerInput(Unit) { detectTapGestures { } }, // กันการสัมผัสทะลุไปหน้าด้านล่าง
    ) {
        Box(Modifier.weight(1f).fillMaxWidth().background(Color(0xFF2A2A34))) {
            Canvas(
                Modifier
                    .fillMaxSize()
                    .onSizeChanged { canvasSize = it }
                    .pointerInput(mode) {
                        awaitEachGesture {
                            val down = awaitFirstDown(requireUnconsumed = false)
                            var drawing = true
                            var travel = 0f
                            var last = down.position
                            live.clear()
                            live.add(toImg(down.position))
                            do {
                                val event = awaitPointerEvent()
                                val pressedCount = event.changes.count { it.pressed }
                                if (pressedCount >= 2) {
                                    // 2 นิ้ว = ซูม/เลื่อนภาพ (ยกเลิกบ่วงที่กำลังวาดอยู่)
                                    if (drawing) {
                                        drawing = false
                                        live.clear()
                                    }
                                    val zoom = event.calculateZoom()
                                    val pan = event.calculatePan()
                                    val c = event.calculateCentroid()
                                    val f = fitScale()
                                    val s0 = vs
                                    val s1 = (s0 * zoom).coerceIn(f * 0.5f, f * 20f)
                                    val k = s1 / s0
                                    off = Offset(
                                        c.x - (c.x - off.x) * k + pan.x,
                                        c.y - (c.y - off.y) * k + pan.y,
                                    )
                                    vs = s1
                                    event.changes.forEach { if (it.positionChanged()) it.consume() }
                                } else if (drawing) {
                                    val ch = event.changes.firstOrNull { it.pressed }
                                    if (ch != null) {
                                        val d = (ch.position - last).getDistance()
                                        if (d >= 3f) {
                                            travel += d
                                            last = ch.position
                                            live.add(toImg(ch.position))
                                        }
                                        ch.consume()
                                    }
                                }
                            } while (event.changes.any { it.pressed })

                            if (drawing) {
                                val pts = live.toList()
                                live.clear()
                                finishStroke(pts, travel, down.position)
                            } else {
                                live.clear()
                            }
                        }
                    },
            ) {
                if (canvasSize.width == 0) return@Canvas
                val dst = RectF(off.x, off.y, off.x + bw * vs, off.y + bh * vs)
                val dashWhite = DashPathEffect(floatArrayOf(dash, dash), phase)
                val dashBlack = DashPathEffect(floatArrayOf(dash, dash), phase + dash)
                antWhite.pathEffect = dashWhite
                antBlack.pathEffect = dashBlack
                drawIntoCanvas { c ->
                    val nc = c.nativeCanvas
                    nc.drawRect(dst, checkerPaint)
                    nc.drawBitmap(bitmap, null, dst, bmpPaint)

                    val screenLassos = lassos.map { toScreen(it) }
                    if (screenLassos.isNotEmpty()) {
                        // ทำให้ส่วนนอกบ่วงมืดลง เพื่อเห็นชัดว่าส่วนไหนจะถูกเก็บไว้
                        nc.save()
                        for (sp in screenLassos) nc.clipOutPath(sp)
                        nc.drawRect(dst, dimPaint)
                        nc.restore()
                    }
                    for (sp in screenLassos) {
                        nc.drawPath(sp, antWhite)
                        nc.drawPath(sp, antBlack)
                    }
                    if (live.size >= 2) {
                        val lp = Path()
                        live.forEachIndexed { i, o ->
                            val x = o.x * vs + off.x
                            val y = o.y * vs + off.y
                            if (i == 0) lp.moveTo(x, y) else lp.lineTo(x, y)
                        }
                        lp.close()
                        nc.drawPath(lp, antWhite)
                        nc.drawPath(lp, antBlack)
                    }
                }
            }

            val hint = when {
                mode == CropMode.REMOVE -> "ลบบ่วง: แตะในบ่วงเพื่อลบทั้งบ่วง · หรือวาดบ่วงทับเพื่อลบเฉพาะส่วน"
                lassos.isEmpty() -> "ลากนิ้ววาดบ่วงรอบส่วนที่ต้องการ · ไม่วาด = ใช้ทั้งภาพ · 2 นิ้ว = ซูม"
                else -> "เพิ่มบ่วง: บ่วงที่วาดทับกันจะรวมเป็นบ่วงเดียว · 2 นิ้ว = ซูม/เลื่อน"
            }
            Box(
                Modifier
                    .align(Alignment.TopCenter)
                    .padding(8.dp)
                    .clip(RoundedCornerShape(12.dp))
                    .background(Color(0xFFFFD600))
                    .padding(horizontal = 12.dp, vertical = 6.dp),
            ) { Text(hint, color = Color.Black, fontSize = 13.sp) }
        }

        Column(
            Modifier.fillMaxWidth().background(Palette.Panel).padding(horizontal = 8.dp, vertical = 8.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            Row(
                Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                FilterChip(
                    selected = mode == CropMode.ADD,
                    onClick = { mode = CropMode.ADD },
                    label = { Text("เพิ่มบ่วง") },
                    modifier = Modifier.heightIn(min = 48.dp),
                )
                FilterChip(
                    selected = mode == CropMode.REMOVE,
                    onClick = { mode = CropMode.REMOVE },
                    label = { Text("ลบบ่วง") },
                    modifier = Modifier.heightIn(min = 48.dp),
                )
                OutlinedButton(
                    onClick = { undo() },
                    enabled = undoStack.isNotEmpty() && !busy,
                    modifier = Modifier.heightIn(min = 48.dp),
                ) { Text("↶ ย้อนกลับ") }
                OutlinedButton(
                    onClick = { redo() },
                    enabled = redoStack.isNotEmpty() && !busy,
                    modifier = Modifier.heightIn(min = 48.dp),
                ) { Text("↷ ทำซ้ำ") }
                OutlinedButton(
                    onClick = { fitView() },
                    modifier = Modifier.heightIn(min = 48.dp),
                ) { Text("พอดีจอ") }
            }
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(
                    onClick = { onCancel() },
                    enabled = !busy,
                    modifier = Modifier.weight(1f).heightIn(min = 48.dp),
                ) { Text("ยกเลิก") }
                Button(
                    onClick = { confirm() },
                    enabled = !busy,
                    modifier = Modifier.weight(1f).heightIn(min = 48.dp),
                ) { Text(if (busy) "กำลังตัด…" else "ตกลง ✓") }
            }
        }
    }
}
