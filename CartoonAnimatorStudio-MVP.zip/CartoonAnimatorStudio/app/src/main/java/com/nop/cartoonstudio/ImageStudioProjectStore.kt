package com.nop.cartoonstudio

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.InputStream
import java.util.UUID

/** Persistent storage for Image Studio projects. Each project owns copies of its source images. */
data class ImageStudioProject(
    val id: String,
    val name: String,
    val updatedAt: Long,
    val imageCount: Int,
)

data class ImageStudioImageRecord(
    val id: Int,
    val fileName: String,
    val duration: Float,
)

object ImageStudioProjectStore {
    private const val MANIFEST = "project.json"
    private fun root(context: Context) = File(context.filesDir, "image_studio/projects").apply { mkdirs() }
    private fun directory(context: Context, id: String) = File(root(context), id)

    fun list(context: Context): List<ImageStudioProject> = root(context).listFiles()
        ?.filter { it.isDirectory }
        ?.mapNotNull { dir -> runCatching { readProject(dir) }.getOrNull() }
        ?.sortedByDescending { it.updatedAt }
        ?: emptyList()

    fun create(context: Context, name: String): ImageStudioProject {
        val id = UUID.randomUUID().toString()
        val dir = directory(context, id)
        check(dir.mkdirs()) { "ไม่สามารถสร้างโฟลเดอร์โปรเจกต์ได้" }
        File(dir, "images").mkdirs()
        val project = ImageStudioProject(id, name.trim().ifBlank { "โปรเจกต์ใหม่" }, System.currentTimeMillis(), 0)
        writeManifest(context, project, emptyList(), false, "เลื่อนภาพ")
        return project
    }

    fun delete(context: Context, id: String): Boolean = directory(context, id).deleteRecursively()

    fun importImage(context: Context, projectId: String, imageId: Int, sourceName: String, input: InputStream): File {
        val imageDir = File(directory(context, projectId), "images").apply { mkdirs() }
        val safeExt = sourceName.substringAfterLast('.', "img").lowercase().filter { it.isLetterOrDigit() }.take(8).ifBlank { "img" }
        val file = File(imageDir, "image_${imageId}.$safeExt")
        input.use { source -> file.outputStream().use { target -> source.copyTo(target) } }
        return file
    }

    fun loadSettings(context: Context, projectId: String): Pair<Boolean, String> {
        val json = JSONObject(File(directory(context, projectId), MANIFEST).readText())
        return json.optBoolean("animationMode", false) to json.optString("motionPreset", "เลื่อนภาพ")
    }

    fun loadImages(context: Context, projectId: String): List<Pair<ImageStudioImageRecord, Bitmap>> {
        val dir = directory(context, projectId)
        val json = JSONObject(File(dir, MANIFEST).readText())
        val array = json.optJSONArray("images") ?: JSONArray()
        val result = mutableListOf<Pair<ImageStudioImageRecord, Bitmap>>()
        for (i in 0 until array.length()) {
            val item = array.optJSONObject(i) ?: continue
            val record = ImageStudioImageRecord(item.optInt("id"), item.optString("fileName"), item.optDouble("duration", 3.0).toFloat())
            val file = File(File(dir, "images"), record.fileName)
            if (!file.isFile) throw IllegalStateException("ไม่พบไฟล์ภาพ ${record.fileName}")
            val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            BitmapFactory.decodeFile(file.absolutePath, bounds)
            if (bounds.outWidth <= 0 || bounds.outHeight <= 0) throw IllegalStateException("ไฟล์ภาพ ${record.fileName} เสียหาย")
            var sample = 1
            while (maxOf(bounds.outWidth, bounds.outHeight) / sample > 1600) sample *= 2
            val bitmap = BitmapFactory.decodeFile(file.absolutePath, BitmapFactory.Options().apply { inSampleSize = sample })
                ?: throw IllegalStateException("ไม่สามารถถอดรหัสภาพ ${record.fileName} ได้")
            result += record to bitmap
        }
        return result
    }

    fun save(
        context: Context,
        projectId: String,
        images: List<ImageStudioImageRecord>,
        animationMode: Boolean,
        motionPreset: String,
    ) {
        val old = runCatching { readProject(directory(context, projectId)) }.getOrNull()
        val project = ImageStudioProject(projectId, old?.name ?: "โปรเจกต์รูปภาพ", System.currentTimeMillis(), images.size)
        writeManifest(context, project, images, animationMode, motionPreset)
        val keep = images.map { it.fileName }.toSet()
        File(directory(context, projectId), "images").listFiles()?.forEach { file ->
            if (file.isFile && file.name !in keep) file.delete()
        }
    }

    private fun readProject(dir: File): ImageStudioProject {
        val json = JSONObject(File(dir, MANIFEST).readText())
        val images = json.optJSONArray("images") ?: JSONArray()
        return ImageStudioProject(
            json.getString("id"), json.optString("name", "โปรเจกต์รูปภาพ"),
            json.optLong("updatedAt", dir.lastModified()), images.length(),
        )
    }

    private fun writeManifest(
        context: Context,
        project: ImageStudioProject,
        images: List<ImageStudioImageRecord>,
        animationMode: Boolean,
        motionPreset: String,
    ) {
        val array = JSONArray()
        images.forEach { item ->
            array.put(JSONObject().put("id", item.id).put("fileName", item.fileName).put("duration", item.duration.toDouble()))
        }
        val json = JSONObject()
            .put("schemaVersion", 1)
            .put("id", project.id)
            .put("name", project.name)
            .put("updatedAt", System.currentTimeMillis())
            .put("animationMode", animationMode)
            .put("motionPreset", motionPreset)
            .put("images", array)
        val dir = directory(context, project.id)
        dir.mkdirs()
        val temp = File(dir, "$MANIFEST.tmp")
        temp.writeText(json.toString())
        val target = File(dir, MANIFEST)
        val backup = File(dir, "$MANIFEST.bak")
        if (backup.exists()) backup.delete()
        if (target.exists() && !target.renameTo(backup)) {
            temp.delete()
            throw IllegalStateException("ไม่สามารถสำรองข้อมูลโปรเจกต์เดิมได้")
        }
        if (!temp.renameTo(target)) {
            if (backup.exists()) backup.renameTo(target)
            temp.delete()
            throw IllegalStateException("ไม่สามารถบันทึกข้อมูลโปรเจกต์ได้")
        }
        backup.delete()
    }
}
