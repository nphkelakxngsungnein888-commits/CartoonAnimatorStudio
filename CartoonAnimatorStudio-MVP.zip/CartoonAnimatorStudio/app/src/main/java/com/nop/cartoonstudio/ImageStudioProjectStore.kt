package com.nop.cartoonstudio

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.InputStream
import java.util.UUID

/** Persistent storage for Image Studio projects. Each project owns copies of its source images. */
data class ImageStudioProject(
    val id: String,
    val name: String,
    val updatedAt: Long,
    val imageCount: Int,
)

data class ImageStudioKeyframeRecord(
    val time: Float, val x: Float, val y: Float, val scale: Float, val rotation: Float, val opacity: Float,
    val sculpt: SculptGrid? = null,
)

data class ImageStudioImageRecord(
    val id: Int,
    val fileName: String,
    val duration: Float,
    val x: Float = 0f,
    val y: Float = 0f,
    val scale: Float = 1f,
    val rotation: Float = 0f,
    val opacity: Float = 1f,
    val visible: Boolean = true,
    val startTime: Float = 0f,
    val keyframes: List<ImageStudioKeyframeRecord> = emptyList(),
    val name: String = "", val locked: Boolean = false, val layerId: Int = 1,
    val sculpt: SculptGrid? = null, val sizeLocked: Boolean = false,
    val videoLength: Float = 0f, // > 0 = คลิปวิดีโอ (ความยาวไฟล์ต้นฉบับ วินาที) · 0 = รูปภาพ
    val videoOffset: Float = 0f, // จุดเริ่มเล่นในไฟล์วิดีโอ (วินาที)
    val rig: PinRig = PinRig(), // หมุดข้อต่ออัจฉริยะของคลิป (ไม่มี = ไม่ใช้)
)

object ImageStudioProjectStore {
    private fun sculptToJson(g: SculptGrid): JSONObject = JSONObject().put("cols", g.cols).put("rows", g.rows)
        .put("off", JSONArray().apply { g.off.forEach { put(Math.round(it * 100f) / 100.0) } })
        .also { o ->
            g.xs?.let { xs -> o.put("xs", JSONArray().apply { xs.forEach { put(Math.round(it * 100000f) / 100000.0) } }) }
            g.ys?.let { ys -> o.put("ys", JSONArray().apply { ys.forEach { put(Math.round(it * 100000f) / 100000.0) } }) }
            g.pinAngles?.takeIf { pa -> pa.any { it != 0f } }?.let { pa -> o.put("pa", JSONArray().apply { pa.forEach { put(Math.round(it * 100f) / 100.0) } }) }
        }

    private fun breaksFromJson(arr: JSONArray?, n: Int): FloatArray? {
        if (arr == null || arr.length() != n + 1) return null
        val out = FloatArray(n + 1) { arr.optDouble(it, 0.0).toFloat() }
        // ต้องเรียงจากน้อยไปมาก เริ่ม 0 จบ 1 ไม่งั้นทิ้ง (ใช้ตาข่ายเว้นระยะเท่ากันแทน)
        for (i in 1..n) if (out[i] < out[i - 1]) return null
        return if (out[0] < -0.001f || out[n] > 1.001f) null else out
    }

    private fun sculptFromJson(o: JSONObject?): SculptGrid? {
        if (o == null) return null
        val cols = o.optInt("cols", 0)
        val rows = o.optInt("rows", 0)
        val arr = o.optJSONArray("off") ?: return null
        if (cols < 1 || rows < 1 || cols > 64 || rows > 64 || arr.length() != (cols + 1) * (rows + 1) * 2) return null
        val pa = o.optJSONArray("pa")?.let { a -> FloatArray(a.length().coerceAtMost(JointPins.MAX_PINS)) { a.optDouble(it, 0.0).toFloat() } }
        return SculptGrid(
            cols, rows, FloatArray(arr.length()) { arr.optDouble(it, 0.0).toFloat() },
            breaksFromJson(o.optJSONArray("xs"), cols), breaksFromJson(o.optJSONArray("ys"), rows), pa,
        )
    }

    private fun rigToJson(r: PinRig): JSONObject = JSONObject().put("adaptive", r.adaptive).put("density", r.density.toDouble())
        .put("pins", JSONArray().apply {
            r.pins.forEach { p ->
                put(JSONObject().put("id", p.id).put("name", p.name).put("x", p.x.toDouble()).put("y", p.y.toDouble())
                    .put("dir", p.dirDeg.toDouble()).put("soft", p.soft.toDouble()).put("reach", p.reach.toDouble())
                    .put("meshR", p.meshRadius.toDouble()).put("parent", p.parentId)
                    .put("min", p.minDeg.toDouble()).put("max", p.maxDeg.toDouble()))
            }
        })

    private fun rigFromJson(o: JSONObject?): PinRig {
        if (o == null) return PinRig()
        val arr = o.optJSONArray("pins") ?: JSONArray()
        val pins = ArrayList<JointPin>()
        for (i in 0 until arr.length()) {
            if (pins.size >= JointPins.MAX_PINS) break
            val p = arr.optJSONObject(i) ?: continue
            val id = p.optInt("id", 0)
            if (id <= 0 || pins.any { it.id == id }) continue
            pins.add(JointPin(
                id = id, name = p.optString("name", ""),
                x = p.optDouble("x", 0.0).toFloat(), y = p.optDouble("y", 0.0).toFloat(),
                dirDeg = p.optDouble("dir", 0.0).toFloat(),
                soft = p.optDouble("soft", 45.0).toFloat().coerceIn(JointPins.SOFT_MIN, JointPins.SOFT_MAX),
                reach = p.optDouble("reach", 0.0).toFloat().coerceAtLeast(0f),
                meshRadius = p.optDouble("meshR", 0.0).toFloat().coerceAtLeast(0f),
                parentId = p.optInt("parent", 0),
                minDeg = p.optDouble("min", -180.0).toFloat().coerceIn(-180f, 180f),
                maxDeg = p.optDouble("max", 180.0).toFloat().coerceIn(-180f, 180f),
            ))
        }
        return PinRig(pins, o.optBoolean("adaptive", true), o.optDouble("density", 3.0).toFloat().coerceIn(0f, JointPins.DENSITY_MAX))
    }

    private const val MANIFEST = "project.json"
    private fun root(context: Context) = File(context.filesDir, "image_studio/projects").apply { mkdirs() }
    private fun directory(context: Context, id: String) = File(root(context), id)

    fun list(context: Context): List<ImageStudioProject> = root(context).listFiles()
        ?.filter { it.isDirectory }
        ?.mapNotNull { dir -> runCatching { readProject(dir) }.getOrNull() }
        ?.sortedByDescending { it.updatedAt }
        ?: emptyList()

    fun create(context: Context, name: String): ImageStudioProject {
        val id = UUID.randomUUID().toString()
        val dir = directory(context, id)
        check(dir.mkdirs()) { "ไม่สามารถสร้างโฟลเดอร์โปรเจกต์ได้" }
        File(dir, "images").mkdirs()
        val project = ImageStudioProject(id, name.trim().ifBlank { "โปรเจกต์ใหม่" }, System.currentTimeMillis(), 0)
        writeManifest(context, project, emptyList(), false, "เลื่อนภาพ")
        return project
    }

    fun delete(context: Context, id: String): Boolean = directory(context, id).deleteRecursively()

    fun importImage(context: Context, projectId: String, imageId: Int, sourceName: String, input: InputStream): File {
        val imageDir = File(directory(context, projectId), "images").apply { mkdirs() }
        val safeExt = sourceName.substringAfterLast('.', "img").lowercase().filter { it.isLetterOrDigit() }.take(8).ifBlank { "img" }
        val file = File(imageDir, "image_${imageId}.$safeExt")
        input.use { source -> file.outputStream().use { target -> source.copyTo(target) } }
        return file
    }

    fun loadSettings(context: Context, projectId: String): Pair<Boolean, String> {
        val json = JSONObject(File(directory(context, projectId), MANIFEST).readText())
        return json.optBoolean("animationMode", false) to json.optString("motionPreset", "เลื่อนภาพ")
    }

    /** ขนาดวิดีโอที่ตั้งไว้ในโปรเจกต์ (กว้าง, สูง) px: โปรเจกต์เก่าที่ไม่มีค่านี้ใช้ 720 x 720 */
    fun loadVideoSize(context: Context, projectId: String): Pair<Int, Int> {
        val json = JSONObject(File(directory(context, projectId), MANIFEST).readText())
        return json.optInt("videoWidth", 720).coerceIn(64, 1920) to json.optInt("videoHeight", 720).coerceIn(64, 1920)
    }

    /** อัตราเฟรมที่ตั้งไว้ (เฟรมต่อวินาที) ตั้งแต่ 1 ขึ้นไป ไม่มีเพดาน: โปรเจกต์เก่าที่ไม่มีค่านี้ใช้ 30 */
    fun loadVideoFps(context: Context, projectId: String): Int {
        val json = JSONObject(File(directory(context, projectId), MANIFEST).readText())
        return json.optInt("videoFps", 30).coerceAtLeast(1)
    }

    fun loadLayerIds(context: Context, projectId: String): List<Int> {
        val json = JSONObject(File(directory(context, projectId), MANIFEST).readText())
        val array = json.optJSONArray("layers") ?: JSONArray()
        return (0 until array.length()).mapNotNull { array.optInt(it, -1).takeIf { id -> id > 0 } }.distinct().sorted()
    }

    fun loadImages(context: Context, projectId: String): List<Pair<ImageStudioImageRecord, Bitmap>> {
        val dir = directory(context, projectId)
        val json = JSONObject(File(dir, MANIFEST).readText())
        val array = json.optJSONArray("images") ?: JSONArray()
        val result = mutableListOf<Pair<ImageStudioImageRecord, Bitmap>>()
        var legacyTimelineCursor = 0f
        for (i in 0 until array.length()) {
            val item = array.optJSONObject(i) ?: continue
            val duration = item.optDouble("duration", 3.0).toFloat().coerceIn(0.5f, 1_000_000f)
            val startTime = if (item.has("startTime")) item.optDouble("startTime", 0.0).toFloat().coerceIn(0f, 1_000_000f) else legacyTimelineCursor
            legacyTimelineCursor = maxOf(legacyTimelineCursor, startTime + duration)
            val keyArray = item.optJSONArray("keyframes") ?: JSONArray()
            val keyframes = (0 until keyArray.length()).mapNotNull { index ->
                val key = keyArray.optJSONObject(index) ?: return@mapNotNull null
                ImageStudioKeyframeRecord(
                    key.optDouble("time", 0.0).toFloat().coerceIn(0f, duration),
                    key.optDouble("x", 0.0).toFloat().coerceIn(-1500f, 1500f), // ช่วงเดียวกับตอนลากในแอป (transformClip)
                    key.optDouble("y", 0.0).toFloat().coerceIn(-1500f, 1500f),
                    key.optDouble("scale", 1.0).toFloat().coerceIn(0.1f, 8f),
                    key.optDouble("rotation", 0.0).toFloat().coerceIn(-180f, 180f),
                    key.optDouble("opacity", 1.0).toFloat().coerceIn(0f, 1f),
                    sculptFromJson(key.optJSONObject("sculpt")),
                )
            }.sortedBy { it.time }
            val record = ImageStudioImageRecord(
                item.optInt("id"), item.optString("fileName"), duration,
                item.optDouble("x", 0.0).toFloat(), item.optDouble("y", 0.0).toFloat(),
                item.optDouble("scale", 1.0).toFloat(), item.optDouble("rotation", 0.0).toFloat(),
                item.optDouble("opacity", 1.0).toFloat(), item.optBoolean("visible", true),
                startTime, keyframes, item.optString("name", ""), item.optBoolean("locked", false), item.optInt("layerId", 1).coerceAtLeast(1),
                sculptFromJson(item.optJSONObject("sculpt")), item.optBoolean("sizeLocked", false),
                item.optDouble("videoLength", 0.0).toFloat().coerceAtLeast(0f), item.optDouble("videoOffset", 0.0).toFloat().coerceAtLeast(0f),
                rigFromJson(item.optJSONObject("pinRig")),
            )
            val file = File(File(dir, "images"), record.fileName)
            if (!file.isFile) throw IllegalStateException("ไม่พบไฟล์ภาพ ${record.fileName}")
            if (record.videoLength > 0f) { // คลิปวิดีโอ: ภาพปกคือเฟรมที่จุดเริ่มเล่น
                val poster = runCatching { VideoFrames.probe(file, record.videoOffset).poster }.getOrNull()
                    ?: throw IllegalStateException("เปิดไฟล์วิดีโอ ${record.fileName} ไม่ได้")
                result += record to poster
                continue
            }
            val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            BitmapFactory.decodeFile(file.absolutePath, bounds)
            if (bounds.outWidth <= 0 || bounds.outHeight <= 0) throw IllegalStateException("ไฟล์ภาพ ${record.fileName} เสียหาย")
            var sample = 1
            while (maxOf(bounds.outWidth, bounds.outHeight) / sample > 1600) sample *= 2
            val bitmap = BitmapFactory.decodeFile(file.absolutePath, BitmapFactory.Options().apply { inSampleSize = sample })
                ?: throw IllegalStateException("ไม่สามารถถอดรหัสภาพ ${record.fileName} ได้")
            result += record to bitmap
        }
        return result
    }

    fun save(
        context: Context,
        projectId: String,
        images: List<ImageStudioImageRecord>,
        animationMode: Boolean,
        motionPreset: String,
        layerIds: List<Int> = images.map { it.layerId }.distinct(),
        videoWidth: Int = 720,
        videoHeight: Int = 720,
        videoFps: Int = 30,
    ) {
        val old = runCatching { readProject(directory(context, projectId)) }.getOrNull()
        val project = ImageStudioProject(projectId, old?.name ?: "โปรเจกต์รูปภาพ", System.currentTimeMillis(), images.size)
        writeManifest(context, project, images, animationMode, motionPreset, layerIds, videoWidth, videoHeight, videoFps)
        val keep = images.map { it.fileName }.toSet()
        File(directory(context, projectId), "images").listFiles()?.forEach { file ->
            // ไฟล์ที่เพิ่งเขียน (เช่น วิดีโอที่กำลังคัดลอกเข้ามา ยังไม่เป็นคลิป) ห้ามลบ
            if (file.isFile && file.name !in keep && System.currentTimeMillis() - file.lastModified() > 60_000L) file.delete()
        }
    }

    private fun readProject(dir: File): ImageStudioProject {
        val json = JSONObject(File(dir, MANIFEST).readText())
        val images = json.optJSONArray("images") ?: JSONArray()
        return ImageStudioProject(
            json.getString("id"), json.optString("name", "โปรเจกต์รูปภาพ"),
            json.optLong("updatedAt", dir.lastModified()), images.length(),
        )
    }

    private fun writeManifest(
        context: Context,
        project: ImageStudioProject,
        images: List<ImageStudioImageRecord>,
        animationMode: Boolean,
        motionPreset: String,
        layerIds: List<Int> = images.map { it.layerId }.distinct(),
        videoWidth: Int = 720,
        videoHeight: Int = 720,
        videoFps: Int = 30,
    ) {
        val array = JSONArray()
        images.forEach { item ->
            array.put(JSONObject().put("id", item.id).put("fileName", item.fileName).put("duration", item.duration.toDouble())
                .put("x", item.x.toDouble()).put("y", item.y.toDouble())
                .put("scale", item.scale.toDouble()).put("rotation", item.rotation.toDouble())
                .put("opacity", item.opacity.toDouble()).put("visible", item.visible)
                .put("startTime", item.startTime.toDouble()).put("name", item.name).put("locked", item.locked).put("layerId", item.layerId)
                .put("keyframes", JSONArray().apply { item.keyframes.forEach { key ->
                    put(JSONObject().put("time", key.time.toDouble()).put("x", key.x.toDouble()).put("y", key.y.toDouble())
                        .put("scale", key.scale.toDouble()).put("rotation", key.rotation.toDouble()).put("opacity", key.opacity.toDouble())
                        .also { o -> key.sculpt?.takeIf { !it.isZero() }?.let { o.put("sculpt", sculptToJson(it)) } })
                } })
                .put("sizeLocked", item.sizeLocked)
                .also { o -> if (item.videoLength > 0f) o.put("videoLength", item.videoLength.toDouble()).put("videoOffset", item.videoOffset.toDouble()) }
                .also { o -> item.sculpt?.takeIf { !it.isZero() }?.let { o.put("sculpt", sculptToJson(it)) } }
                .also { o -> if (item.rig.pins.isNotEmpty()) o.put("pinRig", rigToJson(item.rig)) })
        }
        val json = JSONObject()
            .put("schemaVersion", 1)
            .put("id", project.id)
            .put("name", project.name)
            .put("updatedAt", System.currentTimeMillis())
            .put("animationMode", animationMode)
            .put("motionPreset", motionPreset)
            .put("videoWidth", videoWidth)
            .put("videoHeight", videoHeight)
            .put("videoFps", videoFps)
            .put("layers", JSONArray().apply { layerIds.distinct().sorted().forEach { put(it) } })
            .put("images", array)
        val dir = directory(context, project.id)
        dir.mkdirs()
        val temp = File(dir, "$MANIFEST.tmp")
        temp.writeText(json.toString())
        val target = File(dir, MANIFEST)
        val backup = File(dir, "$MANIFEST.bak")
        if (backup.exists()) backup.delete()
        if (target.exists() && !target.renameTo(backup)) {
            temp.delete()
            throw IllegalStateException("ไม่สามารถสำรองข้อมูลโปรเจกต์เดิมได้")
        }
        if (!temp.renameTo(target)) {
            if (backup.exists()) backup.renameTo(target)
            temp.delete()
            throw IllegalStateException("ไม่สามารถบันทึกข้อมูลโปรเจกต์ได้")
        }
        backup.delete()
    }
}
