package com.nop.cartoonstudio

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.InputStream
import java.util.UUID

/** Persistent storage for Image Studio projects. Each project owns copies of its source images. */
data class ImageStudioProject(
    val id: String,
    val name: String,
    val updatedAt: Long,
    val imageCount: Int,
)

data class ImageStudioKeyframeRecord(
    val time: Float, val x: Float, val y: Float, val scale: Float, val rotation: Float, val opacity: Float,
    val sculpt: SculptGrid? = null,
)

data class ImageStudioImageRecord(
    val id: Int,
    val fileName: String,
    val duration: Float,
    val x: Float = 0f,
    val y: Float = 0f,
    val scale: Float = 1f,
    val rotation: Float = 0f,
    val opacity: Float = 1f,
    val visible: Boolean = true,
    val startTime: Float = 0f,
    val keyframes: List<ImageStudioKeyframeRecord> = emptyList(),
    val name: String = "", val locked: Boolean = false, val layerId: Int = 1,
    val sculpt: SculptGrid? = null, val sizeLocked: Boolean = false,
)

object ImageStudioProjectStore {
    private fun sculptToJson(g: SculptGrid): JSONObject = JSONObject().put("cols", g.cols).put("rows", g.rows)
        .put("off", JSONArray().apply { g.off.forEach { put(Math.round(it * 100f) / 100.0) } })

    private fun sculptFromJson(o: JSONObject?): SculptGrid? {
        if (o == null) return null
        val cols = o.optInt("cols", 0)
        val rows = o.optInt("rows", 0)
        val arr = o.optJSONArray("off") ?: return null
        if (cols < 1 || rows < 1 || cols > 64 || rows > 64 || arr.length() != (cols + 1) * (rows + 1) * 2) return null
        return SculptGrid(cols, rows, FloatArray(arr.length()) { arr.optDouble(it, 0.0).toFloat() })
    }

    private const val MANIFEST = "project.json"
    private fun root(context: Context) = File(context.filesDir, "image_studio/projects").apply { mkdirs() }
    private fun directory(context: Context, id: String) = File(root(context), id)

    fun list(context: Context): List<ImageStudioProject> = root(context).listFiles()
        ?.filter { it.isDirectory }
        ?.mapNotNull { dir -> runCatching { readProject(dir) }.getOrNull() }
        ?.sortedByDescending { it.updatedAt }
        ?: emptyList()

    fun create(context: Context, name: String): ImageStudioProject {
        val id = UUID.randomUUID().toString()
        val dir = directory(context, id)
        check(dir.mkdirs()) { "ไม่สามารถสร้างโฟลเดอร์โปรเจกต์ได้" }
        File(dir, "images").mkdirs()
        val project = ImageStudioProject(id, name.trim().ifBlank { "โปรเจกต์ใหม่" }, System.currentTimeMillis(), 0)
        writeManifest(context, project, emptyList(), false, "เลื่อนภาพ")
        return project
    }

    fun delete(context: Context, id: String): Boolean = directory(context, id).deleteRecursively()

    fun importImage(context: Context, projectId: String, imageId: Int, sourceName: String, input: InputStream): File {
        val imageDir = File(directory(context, projectId), "images").apply { mkdirs() }
        val safeExt = sourceName.substringAfterLast('.', "img").lowercase().filter { it.isLetterOrDigit() }.take(8).ifBlank { "img" }
        val file = File(imageDir, "image_${imageId}.$safeExt")
        input.use { source -> file.outputStream().use { target -> source.copyTo(target) } }
        return file
    }

    fun loadSettings(context: Context, projectId: String): Pair<Boolean, String> {
        val json = JSONObject(File(directory(context, projectId), MANIFEST).readText())
        return json.optBoolean("animationMode", false) to json.optString("motionPreset", "เลื่อนภาพ")
    }

    fun loadLayerIds(context: Context, projectId: String): List<Int> {
        val json = JSONObject(File(directory(context, projectId), MANIFEST).readText())
        val array = json.optJSONArray("layers") ?: JSONArray()
        return (0 until array.length()).mapNotNull { array.optInt(it, -1).takeIf { id -> id > 0 } }.distinct().sorted()
    }

    fun loadImages(context: Context, projectId: String): List<Pair<ImageStudioImageRecord, Bitmap>> {
        val dir = directory(context, projectId)
        val json = JSONObject(File(dir, MANIFEST).readText())
        val array = json.optJSONArray("images") ?: JSONArray()
        val result = mutableListOf<Pair<ImageStudioImageRecord, Bitmap>>()
        var legacyTimelineCursor = 0f
        for (i in 0 until array.length()) {
            val item = array.optJSONObject(i) ?: continue
            val duration = item.optDouble("duration", 3.0).toFloat().coerceIn(0.5f, 100f)
            val startTime = if (item.has("startTime")) item.optDouble("startTime", 0.0).toFloat().coerceIn(0f, 600f) else legacyTimelineCursor
            legacyTimelineCursor = maxOf(legacyTimelineCursor, startTime + duration)
            val keyArray = item.optJSONArray("keyframes") ?: JSONArray()
            val keyframes = (0 until keyArray.length()).mapNotNull { index ->
                val key = keyArray.optJSONObject(index) ?: return@mapNotNull null
                ImageStudioKeyframeRecord(
                    key.optDouble("time", 0.0).toFloat().coerceIn(0f, duration),
                    key.optDouble("x", 0.0).toFloat().coerceIn(-400f, 400f),
                    key.optDouble("y", 0.0).toFloat().coerceIn(-400f, 400f),
                    key.optDouble("scale", 1.0).toFloat().coerceIn(0.2f, 3f),
                    key.optDouble("rotation", 0.0).toFloat().coerceIn(-180f, 180f),
                    key.optDouble("opacity", 1.0).toFloat().coerceIn(0f, 1f),
                    sculptFromJson(key.optJSONObject("sculpt")),
                )
            }.sortedBy { it.time }
            val record = ImageStudioImageRecord(
                item.optInt("id"), item.optString("fileName"), duration,
                item.optDouble("x", 0.0).toFloat(), item.optDouble("y", 0.0).toFloat(),
                item.optDouble("scale", 1.0).toFloat(), item.optDouble("rotation", 0.0).toFloat(),
                item.optDouble("opacity", 1.0).toFloat(), item.optBoolean("visible", true),
                startTime, keyframes, item.optString("name", ""), item.optBoolean("locked", false), item.optInt("layerId", 1).coerceAtLeast(1),
                sculptFromJson(item.optJSONObject("sculpt")), item.optBoolean("sizeLocked", false),
            )
            val file = File(File(dir, "images"), record.fileName)
            if (!file.isFile) throw IllegalStateException("ไม่พบไฟล์ภาพ ${record.fileName}")
            val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            BitmapFactory.decodeFile(file.absolutePath, bounds)
            if (bounds.outWidth <= 0 || bounds.outHeight <= 0) throw IllegalStateException("ไฟล์ภาพ ${record.fileName} เสียหาย")
            var sample = 1
            while (maxOf(bounds.outWidth, bounds.outHeight) / sample > 1600) sample *= 2
            val bitmap = BitmapFactory.decodeFile(file.absolutePath, BitmapFactory.Options().apply { inSampleSize = sample })
                ?: throw IllegalStateException("ไม่สามารถถอดรหัสภาพ ${record.fileName} ได้")
            result += record to bitmap
        }
        return result
    }

    fun save(
        context: Context,
        projectId: String,
        images: List<ImageStudioImageRecord>,
        animationMode: Boolean,
        motionPreset: String,
        layerIds: List<Int> = images.map { it.layerId }.distinct(),
    ) {
        val old = runCatching { readProject(directory(context, projectId)) }.getOrNull()
        val project = ImageStudioProject(projectId, old?.name ?: "โปรเจกต์รูปภาพ", System.currentTimeMillis(), images.size)
        writeManifest(context, project, images, animationMode, motionPreset, layerIds)
        val keep = images.map { it.fileName }.toSet()
        File(directory(context, projectId), "images").listFiles()?.forEach { file ->
            if (file.isFile && file.name !in keep) file.delete()
        }
    }

    private fun readProject(dir: File): ImageStudioProject {
        val json = JSONObject(File(dir, MANIFEST).readText())
        val images = json.optJSONArray("images") ?: JSONArray()
        return ImageStudioProject(
            json.getString("id"), json.optString("name", "โปรเจกต์รูปภาพ"),
            json.optLong("updatedAt", dir.lastModified()), images.length(),
        )
    }

    private fun writeManifest(
        context: Context,
        project: ImageStudioProject,
        images: List<ImageStudioImageRecord>,
        animationMode: Boolean,
        motionPreset: String,
        layerIds: List<Int> = images.map { it.layerId }.distinct(),
    ) {
        val array = JSONArray()
        images.forEach { item ->
            array.put(JSONObject().put("id", item.id).put("fileName", item.fileName).put("duration", item.duration.toDouble())
                .put("x", item.x.toDouble()).put("y", item.y.toDouble())
                .put("scale", item.scale.toDouble()).put("rotation", item.rotation.toDouble())
                .put("opacity", item.opacity.toDouble()).put("visible", item.visible)
                .put("startTime", item.startTime.toDouble()).put("name", item.name).put("locked", item.locked).put("layerId", item.layerId)
                .put("keyframes", JSONArray().apply { item.keyframes.forEach { key ->
                    put(JSONObject().put("time", key.time.toDouble()).put("x", key.x.toDouble()).put("y", key.y.toDouble())
                        .put("scale", key.scale.toDouble()).put("rotation", key.rotation.toDouble()).put("opacity", key.opacity.toDouble())
                        .also { o -> key.sculpt?.takeIf { !it.isZero() }?.let { o.put("sculpt", sculptToJson(it)) } })
                } })
                .put("sizeLocked", item.sizeLocked)
                .also { o -> item.sculpt?.takeIf { !it.isZero() }?.let { o.put("sculpt", sculptToJson(it)) } })
        }
        val json = JSONObject()
            .put("schemaVersion", 1)
            .put("id", project.id)
            .put("name", project.name)
            .put("updatedAt", System.currentTimeMillis())
            .put("animationMode", animationMode)
            .put("motionPreset", motionPreset)
            .put("layers", JSONArray().apply { layerIds.distinct().sorted().forEach { put(it) } })
            .put("images", array)
        val dir = directory(context, project.id)
        dir.mkdirs()
        val temp = File(dir, "$MANIFEST.tmp")
        temp.writeText(json.toString())
        val target = File(dir, MANIFEST)
        val backup = File(dir, "$MANIFEST.bak")
        if (backup.exists()) backup.delete()
        if (target.exists() && !target.renameTo(backup)) {
            temp.delete()
            throw IllegalStateException("ไม่สามารถสำรองข้อมูลโปรเจกต์เดิมได้")
        }
        if (!temp.renameTo(target)) {
            if (backup.exists()) backup.renameTo(target)
            temp.delete()
            throw IllegalStateException("ไม่สามารถบันทึกข้อมูลโปรเจกต์ได้")
        }
        backup.delete()
    }
}
