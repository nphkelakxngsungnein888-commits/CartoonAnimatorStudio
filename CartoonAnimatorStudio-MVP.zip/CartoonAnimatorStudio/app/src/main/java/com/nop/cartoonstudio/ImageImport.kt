package com.nop.cartoonstudio

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import java.io.IOException

object ImageImport {
    /** ด้านยาวสุดหลังโหลด (ลดหน่วยความจำ ภาพเล็กกว่านี้จะไม่ถูกย่อ) */
    const val MAX_SIDE = 2048

    /** โหลดภาพเป็น ARGB_8888 (คงช่องอัลฟา/ความโปร่งใสของ PNG) ควรเรียกใน Dispatchers.IO */
    fun decode(context: Context, uri: Uri): Bitmap {
        val resolver = context.contentResolver
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        val s1 = resolver.openInputStream(uri) ?: throw IOException("เปิดไฟล์ไม่ได้")
        s1.use { BitmapFactory.decodeStream(it, null, bounds) }
        if (bounds.outWidth <= 0 || bounds.outHeight <= 0) {
            throw IOException("ไฟล์นี้ไม่ใช่รูปภาพที่อ่านได้")
        }
        var sample = 1
        while (bounds.outWidth / sample > MAX_SIDE || bounds.outHeight / sample > MAX_SIDE) sample *= 2

        val opts = BitmapFactory.Options().apply {
            inSampleSize = sample
            inPreferredConfig = Bitmap.Config.ARGB_8888
        }
        val s2 = resolver.openInputStream(uri) ?: throw IOException("เปิดไฟล์ไม่ได้")
        return s2.use { BitmapFactory.decodeStream(it, null, opts) }
            ?: throw IOException("ถอดรหัสรูปภาพไม่สำเร็จ")
    }
}
