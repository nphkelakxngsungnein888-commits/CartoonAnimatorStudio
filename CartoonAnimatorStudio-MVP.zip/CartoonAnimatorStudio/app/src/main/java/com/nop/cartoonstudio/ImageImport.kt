package com.nop.cartoonstudio

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import java.io.IOException
import kotlin.math.max
import kotlin.math.roundToInt

object ImageImport {
    /** ด้านยาวสุดหลังโหลด (ลดหน่วยความจำ ภาพเล็กกว่านี้จะไม่ถูกย่อ) */
    const val MAX_SIDE = 2048

    /** ด้านยาวสุดของภาพที่เก็บเป็นชิ้นส่วนตัวละคร (ใหญ่กว่านี้ถูกย่อตอนนำเข้า): ภาพที่แสดงบนจอกว้างราว 300 หน่วย ใหญ่กว่านี้ไม่ได้ช่วยให้คมขึ้นแต่กินหน่วยความจำ */
    const val IMPORT_MAX_SIDE = 1024

    /**
     * ตัดขอบโปร่งใสรอบภาพทิ้ง ให้กรอบภาพแนบรูปร่างจริง (พิกเซลที่ความทึบไม่เกิน alphaThreshold จาก 255 ถือว่าว่าง)
     * คืนภาพเดิมถ้าไม่มีช่องโปร่งใส (เช่น JPEG) ไม่มีขอบให้ตัด หรือโปร่งใสทั้งภาพ ไม่ recycle ภาพต้นฉบับ
     */
    fun trimTransparent(src: Bitmap, alphaThreshold: Int = 8): Bitmap {
        if (!src.hasAlpha()) return src
        val w = src.width
        val h = src.height
        val row = IntArray(w)
        var top = -1
        var bottom = -1
        var left = w
        var right = -1
        for (y in 0 until h) {
            src.getPixels(row, 0, w, 0, y, w, 1)
            var first = -1
            var last = -1
            for (x in 0 until w) {
                if ((row[x] ushr 24) > alphaThreshold) {
                    if (first < 0) first = x
                    last = x
                }
            }
            if (first >= 0) {
                if (top < 0) top = y
                bottom = y
                if (first < left) left = first
                if (last > right) right = last
            }
        }
        if (top < 0) return src
        if (left == 0 && top == 0 && right == w - 1 && bottom == h - 1) return src
        return Bitmap.createBitmap(src, left, top, right - left + 1, bottom - top + 1)
    }

    /** ย่อภาพให้ด้านยาวสุดไม่เกิน maxSide (คงสัดส่วนและความโปร่งใส) ย่อทีละครึ่งก่อนเพื่อให้คม คืนภาพเดิมถ้าเล็กพอแล้ว ไม่ recycle ภาพต้นฉบับ */
    fun limitSize(src: Bitmap, maxSide: Int = IMPORT_MAX_SIDE): Bitmap {
        val longest = max(src.width, src.height)
        if (longest <= maxSide) return src
        var cur = src
        while (max(cur.width, cur.height) / 2 >= maxSide) {
            val next = Bitmap.createScaledBitmap(cur, max(1, cur.width / 2), max(1, cur.height / 2), true)
            if (cur !== src) cur.recycle()
            cur = next
        }
        val k = maxSide.toFloat() / longest
        val out = Bitmap.createScaledBitmap(cur, max(1, (src.width * k).roundToInt()), max(1, (src.height * k).roundToInt()), true)
        if (cur !== src && cur !== out) cur.recycle()
        return out
    }

    /** เตรียมภาพก่อนเป็นชิ้นส่วน: ตัดขอบโปร่งใส แล้วย่อถ้าใหญ่เกิน ควรเรียกนอก main thread */
    fun prepare(src: Bitmap): Bitmap = limitSize(trimTransparent(src))

    /** โหลดภาพเป็น ARGB_8888 (คงช่องอัลฟา/ความโปร่งใสของ PNG) ควรเรียกใน Dispatchers.IO */
    fun decode(context: Context, uri: Uri): Bitmap {
        val resolver = context.contentResolver
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        val s1 = resolver.openInputStream(uri) ?: throw IOException("เปิดไฟล์ไม่ได้")
        s1.use { BitmapFactory.decodeStream(it, null, bounds) }
        if (bounds.outWidth <= 0 || bounds.outHeight <= 0) {
            throw IOException("ไฟล์นี้ไม่ใช่รูปภาพที่อ่านได้")
        }
        var sample = 1
        while (bounds.outWidth / sample > MAX_SIDE || bounds.outHeight / sample > MAX_SIDE) sample *= 2

        val opts = BitmapFactory.Options().apply {
            inSampleSize = sample
            inPreferredConfig = Bitmap.Config.ARGB_8888
        }
        val s2 = resolver.openInputStream(uri) ?: throw IOException("เปิดไฟล์ไม่ได้")
        return s2.use { BitmapFactory.decodeStream(it, null, opts) }
            ?: throw IOException("ถอดรหัสรูปภาพไม่สำเร็จ")
    }
}
