package com.nop.cartoonstudio

import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.drawIntoCanvas
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlin.math.hypot
import kotlin.math.roundToInt

private val BONE_IDLE = Color(0xFF29B6F6)    // ฟ้า = ยังไม่เลือก
private val BONE_SELECTED = Color(0xFF00E676) // เขียว = เลือกอยู่
private val BONE_CREATING = Color(0xFFFFB74D) // ส้ม = กำลังสร้าง

/**
 * หน้าจัดกระดูก (รอบที่ 1): มีจุดราก 1 จุด
 * - กดค้างปุ่ม "+" ค้างไว้ แล้วลากบนจอ = เพิ่มกระดูก (ออกจากปลายกระดูกที่เลือกอยู่ หรือจากจุดรากถ้าไม่ได้เลือก)
 * - แตะเส้นกระดูก = เลือก (เส้นเขียว), แตะจุดราก = ยกเลิกการเลือก
 * - ลากที่ปลายของกระดูกที่เลือก = ปรับความยาว/มุม
 */
@Composable
fun BoneEditorScreen(skeleton: Skeleton, onClose: () -> Unit) {
    var editingId by remember { mutableStateOf<Int?>(null) }
    var previewing by remember { mutableStateOf(false) }
    val editing = skeleton.bone(editingId)
    Box(Modifier.fillMaxSize()) {
        // หน้าจัดกระดูกอยู่ใต้หน้าใส่ภาพ/ดูตัวอย่างตลอด เพื่อไม่ให้ค่าที่เลือกไว้หาย
        BoneSkeletonScreen(skeleton, onClose, onEdit = { editingId = it }, onPreview = { previewing = true })
        if (editing != null) BoneImageEditor(editing) { editingId = null }
        if (previewing) BonePreview(skeleton) { previewing = false }
    }
}

@Composable
private fun BoneSkeletonScreen(skeleton: Skeleton, onClose: () -> Unit, onEdit: (Int) -> Unit, onPreview: () -> Unit) {
    val context = LocalContext.current
    val paint = remember {
        android.graphics.Paint(android.graphics.Paint.FILTER_BITMAP_FLAG or android.graphics.Paint.ANTI_ALIAS_FLAG)
    }
    var selectedId by remember { mutableStateOf<Int?>(null) }
    var creatingId by remember { mutableStateOf<Int?>(null) }
    var draggingTipId by remember { mutableStateOf<Int?>(null) }
    var adding by remember { mutableStateOf(false) }
    var canvasSize by remember { mutableStateOf(IntSize.Zero) }

    BackHandler(onBack = onClose)

    fun toWorld(o: Offset): Offset = Offset(o.x - canvasSize.width / 2f, o.y - canvasSize.height / 2f)

    Row(Modifier.fillMaxSize().systemBarsPadding().background(Color(0xFF16161D))) {
        // แถบเครื่องมือด้านซ้าย
        Column(
            Modifier
                .width(92.dp)
                .fillMaxHeight()
                .background(Color(0xFF22222B))
                .padding(8.dp)
                .verticalScroll(rememberScrollState()),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(10.dp),
        ) {
            OutlinedButton(
                onClick = onClose,
                contentPadding = PaddingValues(4.dp),
                modifier = Modifier.fillMaxWidth(),
            ) { Text("ปิด") }

            Box(
                Modifier
                    .size(64.dp)
                    .clip(CircleShape)
                    .background(if (adding) Color(0xFF558B2F) else Color(0xFF8BC34A))
                    .pointerInput(Unit) {
                        detectTapGestures(onPress = {
                            adding = true
                            tryAwaitRelease()
                            adding = false
                        })
                    },
                contentAlignment = Alignment.Center,
            ) { Text("+", fontSize = 34.sp, color = Color.White) }
            Text("ใหม่ (กดค้าง)", fontSize = 12.sp)

            OutlinedButton(
                onClick = {
                    val id = selectedId
                    if (id == null) {
                        Toast.makeText(context, "แตะเลือกกระดูกก่อน", Toast.LENGTH_SHORT).show()
                    } else {
                        onEdit(id)
                    }
                },
                contentPadding = PaddingValues(4.dp),
                modifier = Modifier.fillMaxWidth(),
            ) { Text("แก้ไข") }

            OutlinedButton(
                onClick = {
                    val id = selectedId
                    if (id != null) {
                        skeleton.remove(id)
                        selectedId = null
                    }
                },
                enabled = selectedId != null,
                contentPadding = PaddingValues(4.dp),
                modifier = Modifier.fillMaxWidth(),
            ) { Text("ลบ") }

            OutlinedButton(
                onClick = onPreview,
                contentPadding = PaddingValues(4.dp),
                modifier = Modifier.fillMaxWidth(),
            ) { Text("ดูตัวอย่าง") }
        }

        // พื้นที่วาดกระดูก (จุดราก = กลางพื้นที่)
        Box(Modifier.weight(1f).fillMaxHeight()) {
            Canvas(
                Modifier
                    .fillMaxSize()
                    .onSizeChanged { canvasSize = it }
                    .pointerInput(skeleton) {
                        detectTapGestures { o ->
                            val p = toWorld(o)
                            if (hypot(p.x, p.y) < 22f) {
                                selectedId = null // แตะจุดราก
                            } else {
                                var best: Bone? = null
                                var bestD = 50f
                                for (b in skeleton.bones) {
                                    val d = distToSegment(p, skeleton.baseOf(b), skeleton.tipOf(b))
                                    if (d < bestD) {
                                        bestD = d
                                        best = b
                                    }
                                }
                                best?.let { selectedId = it.id }
                            }
                        }
                    }
                    .pointerInput(skeleton) {
                        detectDragGestures(
                            onDragStart = { o ->
                                val p = toWorld(o)
                                if (adding) {
                                    val parent = skeleton.bone(selectedId)
                                    val b = skeleton.add(parent?.id, MIN_BONE_LENGTH, 0f)
                                    skeleton.aim(b, p)
                                    creatingId = b.id
                                } else {
                                    val sel = skeleton.bone(selectedId)
                                    if (sel != null) {
                                        val t = skeleton.tipOf(sel)
                                        if (hypot(t.x - p.x, t.y - p.y) < 70f) draggingTipId = sel.id
                                    }
                                }
                            },
                            onDragEnd = {
                                creatingId?.let { selectedId = it }
                                creatingId = null
                                draggingTipId = null
                            },
                            onDragCancel = {
                                creatingId?.let { selectedId = it }
                                creatingId = null
                                draggingTipId = null
                            },
                            onDrag = { change, _ ->
                                change.consume()
                                val b = skeleton.bone(creatingId ?: draggingTipId)
                                if (b != null) skeleton.aim(b, toWorld(change.position))
                            },
                        )
                    },
            ) {
                val origin = Offset(this.size.width / 2f, this.size.height / 2f)
                drawIntoCanvas { c -> // ภาพของกระดูก (วาดใต้เส้นกระดูก ไม่มีกรอบ)
                    for (b in skeleton.bones) {
                        if (b.images.isEmpty()) continue
                        val base = origin + skeleton.baseOf(b)
                        val ang = skeleton.worldAngle(b)
                        for (img in b.images) c.nativeCanvas.drawBitmap(img.bitmap, boneImageMatrix(img, base, ang), paint)
                    }
                }
                for (b in skeleton.bones) {
                    val a = origin + skeleton.baseOf(b)
                    val t = origin + skeleton.tipOf(b)
                    val col = when {
                        b.id == creatingId -> BONE_CREATING
                        b.id == selectedId -> BONE_SELECTED
                        else -> BONE_IDLE
                    }
                    drawLine(col, a, t, strokeWidth = 7f)
                    drawCircle(col, radius = 10f, center = t)
                }
                drawCircle(BONE_IDLE, radius = 16f, center = origin, style = Stroke(width = 4f))
                drawCircle(BONE_IDLE, radius = 5f, center = origin)
            }

            if (adding) {
                Box(
                    Modifier
                        .align(Alignment.TopCenter)
                        .padding(8.dp)
                        .background(Color(0xFFFFD600))
                        .padding(horizontal = 10.dp, vertical = 4.dp),
                ) {
                    Text(
                        "ลากบนจอเพื่อสร้างกระดูก (เริ่มจากปลายกระดูกที่เลือก หรือจุดราก)",
                        color = Color.Black,
                        fontSize = 13.sp,
                    )
                }
            }

            // ความยาว / มุม ของกระดูกที่กำลังสร้างหรือเลือกอยู่
            val shown = skeleton.bone(creatingId ?: selectedId)
            if (shown != null) {
                val ang = skeleton.worldAngle(shown).roundToInt()
                Text(
                    "ความยาว: ${shown.length.roundToInt()}\nมุม: ${String.format("%+d", ang)}",
                    Modifier.align(Alignment.BottomStart).padding(8.dp),
                    color = Color.White,
                    fontSize = 14.sp,
                )
            }
        }
    }
}

private fun distToSegment(p: Offset, a: Offset, b: Offset): Float {
    val abx = b.x - a.x
    val aby = b.y - a.y
    val len2 = abx * abx + aby * aby
    val t = if (len2 == 0f) 0f else (((p.x - a.x) * abx + (p.y - a.y) * aby) / len2).coerceIn(0f, 1f)
    val cx = a.x + t * abx
    val cy = a.y + t * aby
    return hypot(p.x - cx, p.y - cy)
}
