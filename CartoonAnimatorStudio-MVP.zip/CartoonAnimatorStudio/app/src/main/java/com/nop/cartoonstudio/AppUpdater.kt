package com.nop.cartoonstudio

import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.PackageInstaller
import android.net.Uri
import android.os.Build
import android.provider.Settings
import androidx.core.content.FileProvider
import java.io.File
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL
import java.time.Instant
import org.json.JSONObject

/** อัปเดตแอป: โหลด APK ล่าสุดจาก GitHub Release ชื่อ "latest" แล้วเปิดตัวติดตั้งของ Android */
object AppUpdater {
    private fun apkUrl(): String? {
        val repo = BuildConfig.UPDATE_REPO
        if (repo.isBlank()) return null
        return "https://github.com/$repo/releases/download/latest/CartoonAnimatorStudio.apk"
    }

    /** ผลการเช็กเวอร์ชัน: ใหม่กว่า / เป็นล่าสุดแล้ว / เช็กไม่ได้ (พร้อมสาเหตุ เพื่อบอกผู้ใช้ว่าตั้งค่าตรงไหนพลาด) */
    sealed interface Check {
        object Newer : Check
        object UpToDate : Check
        class Failed(val why: String, val network: Boolean) : Check
    }

    /**
     * มี APK ใน Release "latest" ที่ใหม่กว่าตัวที่ติดตั้งอยู่ไหม: เทียบเวลาอัปเดตไฟล์ APK บน GitHub กับเวลาที่แอปนี้ถูกติดตั้งล่าสุด
     * เรียกจากเธรดพื้นหลังเท่านั้น (ใช้เครือข่าย)
     */
    fun check(context: Context): Check {
        val repo = BuildConfig.UPDATE_REPO
        if (repo.isBlank()) return Check.Failed("แอปนี้ไม่ได้ build จาก GitHub Actions (ไม่ทราบ repo สำหรับอัปเดต)", false)
        return try {
            val conn = URL("https://api.github.com/repos/$repo/releases/tags/latest").openConnection() as HttpURLConnection
            conn.connectTimeout = 8_000
            conn.readTimeout = 8_000
            conn.setRequestProperty("Accept", "application/vnd.github+json")
            conn.setRequestProperty("User-Agent", "CartoonAnimatorStudio-Updater")
            try {
                val code = conn.responseCode
                if (code != 200) {
                    return Check.Failed("GitHub ตอบ $code (repo $repo ต้องเป็น public และมี Release ชื่อ latest)", false)
                }
                val json = JSONObject(conn.inputStream.bufferedReader().use { it.readText() })
                val assets = json.optJSONArray("assets") ?: return Check.Failed("Release latest ไม่มีไฟล์แนบ", false)
                var remote = 0L
                for (i in 0 until assets.length()) {
                    val a = assets.getJSONObject(i)
                    if (a.optString("name") == "CartoonAnimatorStudio.apk") {
                        remote = Instant.parse(a.optString("updated_at")).toEpochMilli()
                    }
                }
                if (remote == 0L) return Check.Failed("Release latest ไม่มีไฟล์ชื่อ CartoonAnimatorStudio.apk", false)
                // เทียบกับ "เวลา build" ของแอปที่ติดตั้งอยู่ (ไม่ใช่เวลาที่กดติดตั้ง: ถ้าติดตั้งไฟล์เก่าที่โหลดไว้ทีหลัง จะไม่ถูกมองว่าเป็นล่าสุดผิดๆ)
                // APK ของ build เดียวกันถูกอัปโหลดหลัง build ไม่เกินไม่กี่นาที จึงเผื่อไว้ 3 นาที
                if (remote > BuildConfig.BUILD_TIME + BUILD_UPLOAD_MARGIN_MS) Check.Newer else Check.UpToDate
            } finally {
                conn.disconnect()
            }
        } catch (e: IOException) {
            Check.Failed("ต่อเน็ตไม่ได้", true)
        } catch (e: Exception) {
            Check.Failed("เช็กเวอร์ชันไม่สำเร็จ: ${e.message ?: e.javaClass.simpleName}", false)
        }
    }

    fun hasNewer(context: Context): Boolean = check(context) is Check.Newer

    /** เรียกจากเธรดพื้นหลังเท่านั้น (ใช้เครือข่าย) */
    fun download(context: Context): File {
        val url = apkUrl() ?: throw IOException("ไม่ทราบ repo (แอปนี้ไม่ได้ build จาก GitHub Actions)")
        val dir = File(context.cacheDir, "updates").apply { mkdirs() }
        val out = File(dir, "update.apk")
        val conn = URL(url).openConnection() as HttpURLConnection
        conn.connectTimeout = 15_000
        conn.readTimeout = 30_000
        conn.instanceFollowRedirects = true
        try {
            if (conn.responseCode != 200) {
                throw IOException("เซิร์ฟเวอร์ตอบ ${conn.responseCode} (repo ต้องเป็น public และมี Release ชื่อ latest)")
            }
            conn.inputStream.use { input -> out.outputStream().use { input.copyTo(it) } }
        } finally {
            conn.disconnect()
        }
        return out
    }

    private const val BUILD_UPLOAD_MARGIN_MS = 3L * 60 * 1000
    private const val PREFS = "updater"
    private const val KEY_LAST_AUTO = "last_auto_try"
    private const val AUTO_COOLDOWN_MS = 30L * 60 * 1000 // ลองอัปเดตอัตโนมัติไม่ถี่กว่าทุก 30 นาที (กันวนซ้ำถ้าติดตั้งไม่สำเร็จ/กดยกเลิก)

    fun canInstall(context: Context): Boolean = context.packageManager.canRequestPackageInstalls()

    /** ผ่านช่วงพักจากการลองอัปเดตอัตโนมัติครั้งก่อนแล้วหรือยัง */
    fun autoCooldownPassed(context: Context): Boolean {
        val last = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getLong(KEY_LAST_AUTO, 0L)
        return System.currentTimeMillis() - last >= AUTO_COOLDOWN_MS
    }

    private const val KEY_LAST_CHECK = "last_check"
    private const val CHECK_COOLDOWN_MS = 2L * 60 * 1000 // เช็กเวอร์ชันไม่ถี่กว่าทุก 2 นาที (กลับเข้าแอปบ่อยๆ ไม่ยิง GitHub รัว)

    fun checkCooldownPassed(context: Context): Boolean {
        val last = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getLong(KEY_LAST_CHECK, 0L)
        return System.currentTimeMillis() - last >= CHECK_COOLDOWN_MS
    }

    /** ล้างช่วงพักของการเช็ก (ใช้ตอนกลับจากหน้าอนุญาตติดตั้ง จะได้เช็กและอัปเดตต่อทันที) */
    fun clearCheckCooldown(context: Context) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putLong(KEY_LAST_CHECK, 0L).apply()
    }

    /** เปิดหน้าตั้งค่า "อนุญาตให้แอปนี้ติดตั้งแอป" ให้เลย (ติ๊กครั้งเดียว แล้วกลับมาแอปจะอัปเดตต่อเอง) */
    fun openInstallPermission(context: Context) {
        runCatching {
            context.startActivity(
                Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES, Uri.parse("package:${context.packageName}"))
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK),
            )
        }
        clearCheckCooldown(context)
    }

    fun markCheck(context: Context) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putLong(KEY_LAST_CHECK, System.currentTimeMillis()).apply()
    }

    fun markAutoTry(context: Context) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putLong(KEY_LAST_AUTO, System.currentTimeMillis()).apply()
    }

    /**
     * ติดตั้งผ่าน PackageInstaller: Android 12+ ที่แอปนี้เป็นผู้ติดตั้งเดิม จะอัปเดตทับได้เงียบๆ ไม่ต้องกดยืนยัน
     * ถ้าระบบต้องการให้ยืนยัน (เช่น ติดตั้งครั้งแรกจากเบราว์เซอร์/เครื่องเก่า) UpdateInstallReceiver จะเปิดหน้ายืนยันให้เอง
     * ถ้าสร้าง session ไม่ได้ ถอยไปใช้ตัวติดตั้งแบบเดิม
     */
    private fun installViaSession(context: Context, apk: File): Boolean = runCatching {
        val installer = context.packageManager.packageInstaller
        val params = PackageInstaller.SessionParams(PackageInstaller.SessionParams.MODE_FULL_INSTALL)
        params.setAppPackageName(context.packageName)
        if (Build.VERSION.SDK_INT >= 31) {
            params.setRequireUserAction(PackageInstaller.SessionParams.USER_ACTION_NOT_REQUIRED)
        }
        val id = installer.createSession(params)
        installer.openSession(id).use { session ->
            apk.inputStream().use { input ->
                session.openWrite("update.apk", 0, apk.length()).use { out ->
                    input.copyTo(out)
                    session.fsync(out)
                }
            }
            val intent = Intent(context, UpdateInstallReceiver::class.java).setAction(UpdateInstallReceiver.ACTION)
            val flags = PendingIntent.FLAG_UPDATE_CURRENT or (if (Build.VERSION.SDK_INT >= 31) PendingIntent.FLAG_MUTABLE else 0)
            session.commit(PendingIntent.getBroadcast(context, id, intent, flags).intentSender)
        }
        true
    }.getOrDefault(false)

    /** คืน false ถ้ายังไม่ได้รับอนุญาตให้ติดตั้งแอป (จะเปิดหน้าตั้งค่าให้) */
    fun install(context: Context, apk: File): Boolean {
        if (!context.packageManager.canRequestPackageInstalls()) {
            context.startActivity(
                Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES, Uri.parse("package:${context.packageName}"))
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK),
            )
            return false
        }
        if (installViaSession(context, apk)) return true
        val uri = FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", apk)
        context.startActivity(
            Intent(Intent.ACTION_VIEW)
                .setDataAndType(uri, "application/vnd.android.package-archive")
                .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK),
        )
        return true
    }
}
