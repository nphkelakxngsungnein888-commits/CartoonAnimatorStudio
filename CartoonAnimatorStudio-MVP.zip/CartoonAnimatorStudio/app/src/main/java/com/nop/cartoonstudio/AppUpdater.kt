package com.nop.cartoonstudio

import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.PackageInstaller
import android.net.Uri
import android.os.Build
import android.provider.Settings
import androidx.core.content.FileProvider
import java.io.File
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL
import java.time.Instant
import org.json.JSONObject

/** อัปเดตแอป: โหลด APK ล่าสุดจาก GitHub Release ชื่อ "latest" แล้วเปิดตัวติดตั้งของ Android */
object AppUpdater {
    private fun apkUrl(): String? {
        val repo = BuildConfig.UPDATE_REPO
        if (repo.isBlank()) return null
        return "https://github.com/$repo/releases/download/latest/CartoonAnimatorStudio.apk"
    }

    /**
     * มี APK ใน Release "latest" ที่ใหม่กว่าตัวที่ติดตั้งอยู่ไหม: เทียบเวลาอัปเดตไฟล์ APK บน GitHub กับเวลาที่แอปนี้ถูกติดตั้งล่าสุด
     * คืน false ถ้าเช็กไม่ได้ (ไม่มีเน็ต/ไม่มี repo/ตอบผิดรูปแบบ) เรียกจากเธรดพื้นหลังเท่านั้น (ใช้เครือข่าย)
     */
    fun hasNewer(context: Context): Boolean = runCatching {
        val repo = BuildConfig.UPDATE_REPO
        if (repo.isBlank()) return@runCatching false
        val conn = URL("https://api.github.com/repos/$repo/releases/tags/latest").openConnection() as HttpURLConnection
        conn.connectTimeout = 8_000
        conn.readTimeout = 8_000
        conn.setRequestProperty("Accept", "application/vnd.github+json")
        try {
            if (conn.responseCode != 200) return@runCatching false
            val json = JSONObject(conn.inputStream.bufferedReader().use { it.readText() })
            val assets = json.optJSONArray("assets") ?: return@runCatching false
            var remote = 0L
            for (i in 0 until assets.length()) {
                val a = assets.getJSONObject(i)
                if (a.optString("name") == "CartoonAnimatorStudio.apk") {
                    remote = Instant.parse(a.optString("updated_at")).toEpochMilli()
                }
            }
            val installed = context.packageManager.getPackageInfo(context.packageName, 0).lastUpdateTime
            remote > installed
        } finally {
            conn.disconnect()
        }
    }.getOrDefault(false)

    /** เรียกจากเธรดพื้นหลังเท่านั้น (ใช้เครือข่าย) */
    fun download(context: Context): File {
        val url = apkUrl() ?: throw IOException("ไม่ทราบ repo (แอปนี้ไม่ได้ build จาก GitHub Actions)")
        val dir = File(context.cacheDir, "updates").apply { mkdirs() }
        val out = File(dir, "update.apk")
        val conn = URL(url).openConnection() as HttpURLConnection
        conn.connectTimeout = 15_000
        conn.readTimeout = 30_000
        conn.instanceFollowRedirects = true
        try {
            if (conn.responseCode != 200) {
                throw IOException("เซิร์ฟเวอร์ตอบ ${conn.responseCode} (repo ต้องเป็น public และมี Release ชื่อ latest)")
            }
            conn.inputStream.use { input -> out.outputStream().use { input.copyTo(it) } }
        } finally {
            conn.disconnect()
        }
        return out
    }

    private const val PREFS = "updater"
    private const val KEY_LAST_AUTO = "last_auto_try"
    private const val AUTO_COOLDOWN_MS = 3L * 60 * 60 * 1000 // ลองอัปเดตอัตโนมัติไม่ถี่กว่าทุก 3 ชั่วโมง (กันวนซ้ำถ้าติดตั้งไม่สำเร็จ/กดยกเลิก)

    fun canInstall(context: Context): Boolean = context.packageManager.canRequestPackageInstalls()

    /** ผ่านช่วงพักจากการลองอัปเดตอัตโนมัติครั้งก่อนแล้วหรือยัง */
    fun autoCooldownPassed(context: Context): Boolean {
        val last = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getLong(KEY_LAST_AUTO, 0L)
        return System.currentTimeMillis() - last >= AUTO_COOLDOWN_MS
    }

    fun markAutoTry(context: Context) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putLong(KEY_LAST_AUTO, System.currentTimeMillis()).apply()
    }

    /**
     * ติดตั้งผ่าน PackageInstaller: Android 12+ ที่แอปนี้เป็นผู้ติดตั้งเดิม จะอัปเดตทับได้เงียบๆ ไม่ต้องกดยืนยัน
     * ถ้าระบบต้องการให้ยืนยัน (เช่น ติดตั้งครั้งแรกจากเบราว์เซอร์/เครื่องเก่า) UpdateInstallReceiver จะเปิดหน้ายืนยันให้เอง
     * ถ้าสร้าง session ไม่ได้ ถอยไปใช้ตัวติดตั้งแบบเดิม
     */
    private fun installViaSession(context: Context, apk: File): Boolean = runCatching {
        val installer = context.packageManager.packageInstaller
        val params = PackageInstaller.SessionParams(PackageInstaller.SessionParams.MODE_FULL_INSTALL)
        params.setAppPackageName(context.packageName)
        if (Build.VERSION.SDK_INT >= 31) {
            params.setRequireUserAction(PackageInstaller.SessionParams.USER_ACTION_NOT_REQUIRED)
        }
        val id = installer.createSession(params)
        installer.openSession(id).use { session ->
            apk.inputStream().use { input ->
                session.openWrite("update.apk", 0, apk.length()).use { out ->
                    input.copyTo(out)
                    session.fsync(out)
                }
            }
            val intent = Intent(context, UpdateInstallReceiver::class.java).setAction(UpdateInstallReceiver.ACTION)
            val flags = PendingIntent.FLAG_UPDATE_CURRENT or (if (Build.VERSION.SDK_INT >= 31) PendingIntent.FLAG_MUTABLE else 0)
            session.commit(PendingIntent.getBroadcast(context, id, intent, flags).intentSender)
        }
        true
    }.getOrDefault(false)

    /** คืน false ถ้ายังไม่ได้รับอนุญาตให้ติดตั้งแอป (จะเปิดหน้าตั้งค่าให้) */
    fun install(context: Context, apk: File): Boolean {
        if (!context.packageManager.canRequestPackageInstalls()) {
            context.startActivity(
                Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES, Uri.parse("package:${context.packageName}"))
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK),
            )
            return false
        }
        if (installViaSession(context, apk)) return true
        val uri = FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", apk)
        context.startActivity(
            Intent(Intent.ACTION_VIEW)
                .setDataAndType(uri, "application/vnd.android.package-archive")
                .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK),
        )
        return true
    }
}
