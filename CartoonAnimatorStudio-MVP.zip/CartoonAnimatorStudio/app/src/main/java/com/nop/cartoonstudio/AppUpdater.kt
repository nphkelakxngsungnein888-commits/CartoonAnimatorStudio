package com.nop.cartoonstudio

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.provider.Settings
import androidx.core.content.FileProvider
import java.io.File
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL
import java.time.Instant
import org.json.JSONObject

/** อัปเดตแอป: โหลด APK ล่าสุดจาก GitHub Release ชื่อ "latest" แล้วเปิดตัวติดตั้งของ Android */
object AppUpdater {
    private fun apkUrl(): String? {
        val repo = BuildConfig.UPDATE_REPO
        if (repo.isBlank()) return null
        return "https://github.com/$repo/releases/download/latest/CartoonAnimatorStudio.apk"
    }

    /**
     * มี APK ใน Release "latest" ที่ใหม่กว่าตัวที่ติดตั้งอยู่ไหม: เทียบเวลาอัปเดตไฟล์ APK บน GitHub กับเวลาที่แอปนี้ถูกติดตั้งล่าสุด
     * คืน false ถ้าเช็กไม่ได้ (ไม่มีเน็ต/ไม่มี repo/ตอบผิดรูปแบบ) เรียกจากเธรดพื้นหลังเท่านั้น (ใช้เครือข่าย)
     */
    fun hasNewer(context: Context): Boolean = runCatching {
        val repo = BuildConfig.UPDATE_REPO
        if (repo.isBlank()) return@runCatching false
        val conn = URL("https://api.github.com/repos/$repo/releases/tags/latest").openConnection() as HttpURLConnection
        conn.connectTimeout = 8_000
        conn.readTimeout = 8_000
        conn.setRequestProperty("Accept", "application/vnd.github+json")
        try {
            if (conn.responseCode != 200) return@runCatching false
            val json = JSONObject(conn.inputStream.bufferedReader().use { it.readText() })
            val assets = json.optJSONArray("assets") ?: return@runCatching false
            var remote = 0L
            for (i in 0 until assets.length()) {
                val a = assets.getJSONObject(i)
                if (a.optString("name") == "CartoonAnimatorStudio.apk") {
                    remote = Instant.parse(a.optString("updated_at")).toEpochMilli()
                }
            }
            val installed = context.packageManager.getPackageInfo(context.packageName, 0).lastUpdateTime
            remote > installed
        } finally {
            conn.disconnect()
        }
    }.getOrDefault(false)

    /** เรียกจากเธรดพื้นหลังเท่านั้น (ใช้เครือข่าย) */
    fun download(context: Context): File {
        val url = apkUrl() ?: throw IOException("ไม่ทราบ repo (แอปนี้ไม่ได้ build จาก GitHub Actions)")
        val dir = File(context.cacheDir, "updates").apply { mkdirs() }
        val out = File(dir, "update.apk")
        val conn = URL(url).openConnection() as HttpURLConnection
        conn.connectTimeout = 15_000
        conn.readTimeout = 30_000
        conn.instanceFollowRedirects = true
        try {
            if (conn.responseCode != 200) {
                throw IOException("เซิร์ฟเวอร์ตอบ ${conn.responseCode} (repo ต้องเป็น public และมี Release ชื่อ latest)")
            }
            conn.inputStream.use { input -> out.outputStream().use { input.copyTo(it) } }
        } finally {
            conn.disconnect()
        }
        return out
    }

    /** คืน false ถ้ายังไม่ได้รับอนุญาตให้ติดตั้งแอป (จะเปิดหน้าตั้งค่าให้) */
    fun install(context: Context, apk: File): Boolean {
        if (!context.packageManager.canRequestPackageInstalls()) {
            context.startActivity(
                Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES, Uri.parse("package:${context.packageName}"))
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK),
            )
            return false
        }
        val uri = FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", apk)
        context.startActivity(
            Intent(Intent.ACTION_VIEW)
                .setDataAndType(uri, "application/vnd.android.package-archive")
                .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK),
        )
        return true
    }
}
