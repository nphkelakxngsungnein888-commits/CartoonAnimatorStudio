package com.nop.cartoonstudio

import android.content.ContentValues
import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.media.Image
import android.media.MediaCodec
import android.media.MediaCodecInfo
import android.media.MediaFormat
import android.media.MediaMuxer
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import java.io.File
import java.io.FileOutputStream
import java.io.IOException

object Exporter {
    /** หน้าต่างโลกที่ถูกแมปลงในเฟรมส่งออก: จัตุรัส 600x600 หน่วย กึ่งกลางที่ (0,0) (ตรงกับกรอบประในหน้าแก้ไข) */
    const val WORLD_WINDOW = 600f

    /**
     * ขนาดกรอบส่งออกวิดีโอในหน่วยโลก (กว้าง, สูง): ด้านสั้นสุด = WORLD_WINDOW ตรงกับที่ encodeVideo แมปไว้ (s = min(w,h)/WORLD_WINDOW)
     * ใช้ขนาดที่ปัดเป็นพหุคูณของ 16 เหมือนตอนส่งออกจริง เพื่อให้เส้นประสีฟ้าตรงกับสิ่งที่จะอยู่ในวิดีโอ
     */
    fun frameWorldSize(w: Int, h: Int): Pair<Float, Float> {
        val rw = videoSize(w)
        val rh = videoSize(h)
        val k = WORLD_WINDOW / minOf(rw, rh)
        return Pair(rw * k, rh * k)
    }

    /** คืนข้อความผิดพลาด หรือ null ถ้าค่าถูกต้อง */
    fun validate(fw: Int?, fh: Int?, cols: Int?, frames: Int): String? {
        if (fw == null || fh == null || cols == null) return "กรอกตัวเลขจำนวนเต็มให้ครบทุกช่อง"
        if (fw !in 16..2048 || fh !in 16..2048) return "ความกว้าง/ความสูงเฟรมต้องอยู่ระหว่าง 16–2048"
        if (cols !in 1..frames) return "จำนวนคอลัมน์ต้องอยู่ระหว่าง 1–$frames"
        val rows = (frames + cols - 1) / cols
        val sheetW = fw.toLong() * cols
        val sheetH = fh.toLong() * rows
        if (sheetW > 8192 || sheetH > 8192 || sheetW * sheetH > 16_000_000L) {
            return "สไปรต์ชีตใหญ่เกินไป (สูงสุด 8192 px ต่อด้าน และราว 16 ล้านพิกเซล)"
        }
        return null
    }

    /** วาดทุกเฟรมลงชีตเดียว พื้นหลังโปร่งใส ทุกเฟรมขนาดเท่ากันและใช้กล้องเดียวกัน (จัดแนวตรงกัน) */
    fun buildSheet(
        parts: List<Part>,
        frames: List<Map<Int, Pose>>,
        fw: Int,
        fh: Int,
        cols: Int,
    ): Bitmap {
        val rows = (frames.size + cols - 1) / cols
        val sheet = Bitmap.createBitmap(fw * cols, fh * rows, Bitmap.Config.ARGB_8888)
        sheet.eraseColor(Color.TRANSPARENT)
        val canvas = Canvas(sheet)
        val paint = Paint(Paint.FILTER_BITMAP_FLAG or Paint.ANTI_ALIAS_FLAG)
        val s = minOf(fw, fh) / WORLD_WINDOW
        frames.forEachIndexed { i, poses ->
            val left = (i % cols) * fw
            val top = (i / cols) * fh
            canvas.save()
            canvas.clipRect(left, top, left + fw, top + fh)
            canvas.translate(left + fw / 2f, top + fh / 2f)
            canvas.scale(s, s)
            drawScene(canvas, parts, { id -> poses[id] ?: Pose() }, paint)
            canvas.restore()
        }
        return sheet
    }

    /** บันทึก PNG (คงความโปร่งใส) คืนค่าตำแหน่งที่บันทึก ควรเรียกใน Dispatchers.IO */
    fun savePng(context: Context, bmp: Bitmap, displayName: String): String {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            val values = ContentValues().apply {
                put(MediaStore.Images.Media.DISPLAY_NAME, "$displayName.png")
                put(MediaStore.Images.Media.MIME_TYPE, "image/png")
                put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/CartoonAnimatorStudio")
                put(MediaStore.Images.Media.IS_PENDING, 1)
            }
            val resolver = context.contentResolver
            val uri = resolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values)
                ?: throw IOException("สร้างไฟล์ในแกลเลอรีไม่ได้")
            try {
                val out = resolver.openOutputStream(uri) ?: throw IOException("เปิดไฟล์เพื่อเขียนไม่ได้")
                out.use {
                    if (!bmp.compress(Bitmap.CompressFormat.PNG, 100, it)) throw IOException("เข้ารหัส PNG ไม่สำเร็จ")
                }
                values.clear()
                values.put(MediaStore.Images.Media.IS_PENDING, 0)
                resolver.update(uri, values, null, null)
            } catch (e: Exception) {
                resolver.delete(uri, null, null)
                throw e
            }
            return "Pictures/CartoonAnimatorStudio/$displayName.png"
        } else {
            val dir = File(context.getExternalFilesDir(Environment.DIRECTORY_PICTURES), "CartoonAnimatorStudio")
            if (!dir.exists() && !dir.mkdirs()) throw IOException("สร้างโฟลเดอร์ไม่ได้")
            val f = File(dir, "$displayName.png")
            FileOutputStream(f).use {
                if (!bmp.compress(Bitmap.CompressFormat.PNG, 100, it)) throw IOException("เข้ารหัส PNG ไม่สำเร็จ")
            }
            return f.absolutePath
        }
    }

    // ---------- วิดีโอ (MP4 / H.264) ----------

    /** ขนาดวิดีโอที่ใช้จริง: ปัดเป็นพหุคูณของ 16 (ตัวเข้ารหัส H.264 ส่วนใหญ่ต้องการ) */
    fun videoSize(v: Int): Int = ((v + 8) / 16 * 16).coerceAtLeast(16)

    /** อัตราเฟรมของวิดีโอที่ส่งออก: เรนเดอร์ท่าระหว่างเฟรมให้ลื่นเหมือนตอนเล่นในแอป */
    const val VIDEO_FPS = 30

    /** ตำแหน่ง playhead (เหมือน tick ในแอป) ของทุกเฟรมวิดีโอใน 1 รอบ: เดินทีละเฟรมตามความเร็วของเฟรมนั้น */
    fun videoPlayheads(loopN: Int, fpsAt: (Int) -> Int): FloatArray {
        val n = loopN.coerceAtLeast(1)
        var duration = 0.0
        for (i in 0 until n) duration += 1.0 / fpsAt(i).coerceAtLeast(1)
        val count = Math.round(duration * VIDEO_FPS).toInt().coerceAtLeast(1)
        val out = FloatArray(count)
        var p = 0f
        val dt = 1f / VIDEO_FPS
        for (k in 0 until count) {
            out[k] = p
            var left = dt
            var guard = 0
            while (left > 0f && guard++ < 1000) {
                val idx = p.toInt().coerceIn(0, n - 1)
                val f = fpsAt(idx).coerceAtLeast(1).toFloat()
                val toNext = (idx + 1 - p) / f
                if (left < toNext) { p += left * f; left = 0f } else { left -= toNext; p = (idx + 1).toFloat() }
                if (p >= n) p -= n
            }
        }
        return out
    }

    /** คืนข้อความผิดพลาด หรือ null ถ้าค่าถูกต้อง */
    fun validateVideo(fw: Int?, fh: Int?, loops: Int?, frameCount: Int): String? {
        if (fw == null || fh == null || loops == null) return "กรอกตัวเลขจำนวนเต็มให้ครบทุกช่อง"
        if (fw !in 64..1920 || fh !in 64..1920) return "ความกว้าง/ความสูงต้องอยู่ระหว่าง 64–1920"
        if (loops !in 1..100) return "จำนวนรอบต้องอยู่ระหว่าง 1–100"
        if (frameCount.toLong() * loops > 3000L) return "วิดีโอยาวเกินไป (เฟรมวิดีโอ 30 fps × จำนวนรอบ ต้องไม่เกิน 3000)"
        return null
    }

    /**
     * เข้ารหัสแอนิเมชันเป็น MP4 (H.264) ลงไฟล์ out: เฟรมละ 1/fps วินาที วนซ้ำ loops รอบ
     * MP4 ไม่มีความโปร่งใส จึงเติมสีพื้นหลัง background (ARGB) ควรเรียกใน thread เบื้องหลัง
     * ป้อนภาพเข้าตัวเข้ารหัสแบบ buffer (YUV420) พร้อมกำหนดเวลาของแต่ละเฟรมเอง
     */
    fun encodeVideo(
        parts: List<Part>,
        frames: List<Map<Int, Pose>>,
        w: Int,
        h: Int,
        fps: Int,
        loops: Int,
        background: Int,
        out: File,
        fpsAt: (Int) -> Int = { fps }, // ความเร็วของเฟรมที่ index (ช่วงที่ตั้งความเร็วเองได้ค่าของช่วง) ค่าเริ่มต้น = fps เท่ากันทุกเฟรม
        loopN: Int = frames.size, // จำนวนเฟรมที่วนจริง (ไม่นับเฟรมปิดวงที่ซ้ำเฟรมแรก)
        onProgress: (Int, Int) -> Unit,
    ) {
        if (frames.isEmpty()) throw IOException("ไม่มีเฟรมให้เข้ารหัส")
        val n = loopN.coerceIn(1, frames.size)
        val heads = videoPlayheads(n, fpsAt) // ท่าระหว่างเฟรมแบบเดียวกับที่เล่นในแอป
        val total = heads.size * loops
        val outFps = VIDEO_FPS
        // เวลาเริ่ม (µs) ของแต่ละเฟรมวิดีโอ: เฟรมละ 1/30 วินาที (index ที่ [total] = เวลาจบ)
        val ptsTable = LongArray(total + 1) { Math.round(it * 1_000_000.0 / outFps) }
        val format = MediaFormat.createVideoFormat(MediaFormat.MIMETYPE_VIDEO_AVC, w, h)
        format.setInteger(MediaFormat.KEY_COLOR_FORMAT, MediaCodecInfo.CodecCapabilities.COLOR_FormatYUV420Flexible)
        format.setInteger(MediaFormat.KEY_BIT_RATE, (w.toLong() * h * outFps / 2).coerceIn(2_000_000L, 40_000_000L).toInt())
        format.setInteger(MediaFormat.KEY_FRAME_RATE, outFps)
        format.setInteger(MediaFormat.KEY_I_FRAME_INTERVAL, 1)

        // วาดที่ขนาดใหญ่กว่า 2 เท่าแล้วย่อลง (supersampling) ภาพจะคมไม่เป็นขอบหยัก ภาพต้นฉบับที่ใหญ่ถูกย่อแบบเนียนกว่าย่อตรง ๆ
        val ss = if (maxOf(w, h) <= 1080) 2 else 1
        val bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888) // ภาพสุดท้ายส่งเข้าตัวเข้ารหัส
        val big = Bitmap.createBitmap(w * ss, h * ss, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(big)
        val outCanvas = Canvas(bmp)
        val downPaint = Paint(Paint.FILTER_BITMAP_FLAG)
        val srcRect = android.graphics.Rect(0, 0, w * ss, h * ss)
        val dstRect = android.graphics.Rect(0, 0, w, h)
        val paint = Paint(Paint.FILTER_BITMAP_FLAG or Paint.ANTI_ALIAS_FLAG)
        val s = minOf(w, h) * ss / WORLD_WINDOW
        fun render(index: Int) {
            val pos = heads[index % heads.size]
            val base = Math.floor(pos.toDouble()).toInt()
            val t = pos - base
            val pa = frames[Math.floorMod(base, n)]
            val pb = frames[Math.floorMod(base + 1, n)]
            val poseOf = { id: Int ->
                val a = pa[id] ?: Pose()
                val b = pb[id] ?: Pose()
                Pose(a.rotation + (b.rotation - a.rotation) * t, a.dx + (b.dx - a.dx) * t, a.dy + (b.dy - a.dy) * t)
            }
            big.eraseColor(background)
            canvas.save()
            canvas.translate(w * ss / 2f, h * ss / 2f)
            canvas.scale(s, s)
            drawScene(canvas, parts, poseOf, paint)
            canvas.restore()
            if (ss == 1) {
                outCanvas.drawBitmap(big, 0f, 0f, null)
            } else {
                outCanvas.drawBitmap(big, srcRect, dstRect, downPaint)
            }
        }

        val codec = MediaCodec.createEncoderByType(MediaFormat.MIMETYPE_VIDEO_AVC)
        var muxer: MediaMuxer? = null
        var muxerStarted = false
        try {
            codec.configure(format, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE)
            codec.start()
            muxer = MediaMuxer(out.absolutePath, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4)
            val info = MediaCodec.BufferInfo()
            var track = -1
            var fed = 0
            var inputDone = false
            var outputDone = false
            var written = 0L
            while (!outputDone) {
                if (!inputDone) {
                    val ii = codec.dequeueInputBuffer(10_000L)
                    if (ii >= 0) {
                        val ptsUs = ptsTable[fed]
                        if (fed >= total) {
                            codec.queueInputBuffer(ii, 0, 0, ptsUs, MediaCodec.BUFFER_FLAG_END_OF_STREAM)
                            inputDone = true
                        } else {
                            val image = codec.getInputImage(ii) ?: throw IOException("อุปกรณ์นี้ไม่รองรับการป้อนภาพเข้าตัวเข้ารหัสวิดีโอ")
                            render(fed)
                            fillYuv(image, bmp, w, h)
                            codec.queueInputBuffer(ii, 0, w * h * 3 / 2, ptsUs, 0)
                            fed++
                            onProgress(fed, total)
                        }
                    }
                }
                val oi = codec.dequeueOutputBuffer(info, 10_000L)
                if (oi == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) {
                    track = muxer.addTrack(codec.outputFormat)
                    muxer.start()
                    muxerStarted = true
                } else if (oi >= 0) {
                    val buf = codec.getOutputBuffer(oi)
                    if ((info.flags and MediaCodec.BUFFER_FLAG_CODEC_CONFIG) != 0) info.size = 0
                    if (info.size > 0 && muxerStarted && buf != null) {
                        buf.position(info.offset)
                        buf.limit(info.offset + info.size)
                        info.presentationTimeUs = ptsTable[written.toInt().coerceAtMost(total)] // เวลาตามลำดับเฟรม ไม่ขึ้นกับความเร็วเครื่อง
                        muxer.writeSampleData(track, buf, info)
                        written++
                    }
                    codec.releaseOutputBuffer(oi, false)
                    if ((info.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0) outputDone = true
                }
            }
            if (!muxerStarted) throw IOException("ตัวเข้ารหัสไม่ได้ส่งวิดีโอออกมา")
        } finally {
            runCatching { codec.stop() }
            runCatching { codec.release() }
            runCatching { if (muxerStarted) muxer?.stop() }
            runCatching { muxer?.release() }
            bmp.recycle()
            big.recycle()
        }
    }

    /** แปลงภาพ ARGB เป็น YUV420 (BT.601) ลงในภาพของตัวเข้ารหัส โดยเคารพ rowStride/pixelStride ของแต่ละเครื่อง */
    private fun fillYuv(image: Image, bmp: Bitmap, w: Int, h: Int) {
        val px = IntArray(w * h)
        bmp.getPixels(px, 0, w, 0, 0, w, h)
        val planes = image.planes
        val yBuf = planes[0].buffer
        val uBuf = planes[1].buffer
        val vBuf = planes[2].buffer
        val yRow = planes[0].rowStride
        val yPix = planes[0].pixelStride
        val uRow = planes[1].rowStride
        val uPix = planes[1].pixelStride
        val vRow = planes[2].rowStride
        val vPix = planes[2].pixelStride
        for (j in 0 until h) {
            for (i in 0 until w) {
                val c = px[j * w + i]
                val r = (c shr 16) and 0xFF
                val g = (c shr 8) and 0xFF
                val b = c and 0xFF
                yBuf.put(j * yRow + i * yPix, (((66 * r + 129 * g + 25 * b + 128) shr 8) + 16).toByte())
            }
        }
        for (j in 0 until h / 2) {
            for (i in 0 until w / 2) {
                var r = 0
                var g = 0
                var b = 0
                for (dy in 0..1) {
                    for (dx in 0..1) {
                        val c = px[(j * 2 + dy) * w + (i * 2 + dx)]
                        r += (c shr 16) and 0xFF
                        g += (c shr 8) and 0xFF
                        b += c and 0xFF
                    }
                }
                r /= 4
                g /= 4
                b /= 4
                uBuf.put(j * uRow + i * uPix, (((-38 * r - 74 * g + 112 * b + 128) shr 8) + 128).toByte())
                vBuf.put(j * vRow + i * vPix, (((112 * r - 94 * g - 18 * b + 128) shr 8) + 128).toByte())
            }
        }
    }

    /** เก็บไฟล์ MP4 ลงแกลเลอรี (Movies/CartoonAnimatorStudio) คืนตำแหน่งที่บันทึก ควรเรียกใน Dispatchers.IO */
    fun saveVideo(context: Context, src: File, displayName: String): String {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            val values = ContentValues().apply {
                put(MediaStore.Video.Media.DISPLAY_NAME, "$displayName.mp4")
                put(MediaStore.Video.Media.MIME_TYPE, "video/mp4")
                put(MediaStore.Video.Media.RELATIVE_PATH, "Movies/CartoonAnimatorStudio")
                put(MediaStore.Video.Media.IS_PENDING, 1)
            }
            val resolver = context.contentResolver
            val uri = resolver.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, values)
                ?: throw IOException("สร้างไฟล์ในแกลเลอรีไม่ได้")
            try {
                val out = resolver.openOutputStream(uri) ?: throw IOException("เปิดไฟล์เพื่อเขียนไม่ได้")
                out.use { o -> src.inputStream().use { it.copyTo(o) } }
                values.clear()
                values.put(MediaStore.Video.Media.IS_PENDING, 0)
                resolver.update(uri, values, null, null)
            } catch (e: Exception) {
                resolver.delete(uri, null, null)
                throw e
            }
            return "Movies/CartoonAnimatorStudio/$displayName.mp4"
        } else {
            val dir = File(context.getExternalFilesDir(Environment.DIRECTORY_MOVIES), "CartoonAnimatorStudio")
            if (!dir.exists() && !dir.mkdirs()) throw IOException("สร้างโฟลเดอร์ไม่ได้")
            val f = File(dir, "$displayName.mp4")
            src.inputStream().use { i -> FileOutputStream(f).use { i.copyTo(it) } }
            return f.absolutePath
        }
    }
}
