package com.nop.cartoonstudio

import android.content.ContentValues
import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import java.io.File
import java.io.FileOutputStream
import java.io.IOException

object Exporter {
    /** หน้าต่างโลกที่ถูกแมปลงในเฟรมส่งออก: จัตุรัส 600x600 หน่วย กึ่งกลางที่ (0,0) (ตรงกับกรอบประในหน้าแก้ไข) */
    const val WORLD_WINDOW = 600f

    /** คืนข้อความผิดพลาด หรือ null ถ้าค่าถูกต้อง */
    fun validate(fw: Int?, fh: Int?, cols: Int?, frames: Int): String? {
        if (fw == null || fh == null || cols == null) return "กรอกตัวเลขจำนวนเต็มให้ครบทุกช่อง"
        if (fw !in 16..2048 || fh !in 16..2048) return "ความกว้าง/ความสูงเฟรมต้องอยู่ระหว่าง 16–2048"
        if (cols !in 1..frames) return "จำนวนคอลัมน์ต้องอยู่ระหว่าง 1–$frames"
        val rows = (frames + cols - 1) / cols
        val sheetW = fw.toLong() * cols
        val sheetH = fh.toLong() * rows
        if (sheetW > 8192 || sheetH > 8192 || sheetW * sheetH > 16_000_000L) {
            return "สไปรต์ชีตใหญ่เกินไป (สูงสุด 8192 px ต่อด้าน และราว 16 ล้านพิกเซล)"
        }
        return null
    }

    /** วาดทุกเฟรมลงชีตเดียว พื้นหลังโปร่งใส ทุกเฟรมขนาดเท่ากันและใช้กล้องเดียวกัน (จัดแนวตรงกัน) */
    fun buildSheet(
        parts: List<Part>,
        frames: List<Map<Int, Pose>>,
        fw: Int,
        fh: Int,
        cols: Int,
    ): Bitmap {
        val rows = (frames.size + cols - 1) / cols
        val sheet = Bitmap.createBitmap(fw * cols, fh * rows, Bitmap.Config.ARGB_8888)
        sheet.eraseColor(Color.TRANSPARENT)
        val canvas = Canvas(sheet)
        val paint = Paint(Paint.FILTER_BITMAP_FLAG or Paint.ANTI_ALIAS_FLAG)
        val s = minOf(fw, fh) / WORLD_WINDOW
        frames.forEachIndexed { i, poses ->
            val left = (i % cols) * fw
            val top = (i / cols) * fh
            canvas.save()
            canvas.clipRect(left, top, left + fw, top + fh)
            canvas.translate(left + fw / 2f, top + fh / 2f)
            canvas.scale(s, s)
            drawScene(canvas, parts, { id -> poses[id] ?: Pose() }, paint)
            canvas.restore()
        }
        return sheet
    }

    /** บันทึก PNG (คงความโปร่งใส) คืนค่าตำแหน่งที่บันทึก ควรเรียกใน Dispatchers.IO */
    fun savePng(context: Context, bmp: Bitmap, displayName: String): String {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            val values = ContentValues().apply {
                put(MediaStore.Images.Media.DISPLAY_NAME, "$displayName.png")
                put(MediaStore.Images.Media.MIME_TYPE, "image/png")
                put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/CartoonAnimatorStudio")
                put(MediaStore.Images.Media.IS_PENDING, 1)
            }
            val resolver = context.contentResolver
            val uri = resolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values)
                ?: throw IOException("สร้างไฟล์ในแกลเลอรีไม่ได้")
            try {
                val out = resolver.openOutputStream(uri) ?: throw IOException("เปิดไฟล์เพื่อเขียนไม่ได้")
                out.use {
                    if (!bmp.compress(Bitmap.CompressFormat.PNG, 100, it)) throw IOException("เข้ารหัส PNG ไม่สำเร็จ")
                }
                values.clear()
                values.put(MediaStore.Images.Media.IS_PENDING, 0)
                resolver.update(uri, values, null, null)
            } catch (e: Exception) {
                resolver.delete(uri, null, null)
                throw e
            }
            return "Pictures/CartoonAnimatorStudio/$displayName.png"
        } else {
            val dir = File(context.getExternalFilesDir(Environment.DIRECTORY_PICTURES), "CartoonAnimatorStudio")
            if (!dir.exists() && !dir.mkdirs()) throw IOException("สร้างโฟลเดอร์ไม่ได้")
            val f = File(dir, "$displayName.png")
            FileOutputStream(f).use {
                if (!bmp.compress(Bitmap.CompressFormat.PNG, 100, it)) throw IOException("เข้ารหัส PNG ไม่สำเร็จ")
            }
            return f.absolutePath
        }
    }
}
