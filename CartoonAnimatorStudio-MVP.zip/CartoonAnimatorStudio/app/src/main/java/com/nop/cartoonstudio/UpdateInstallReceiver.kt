package com.nop.cartoonstudio

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.pm.PackageInstaller
import android.widget.Toast

/** รับผลการติดตั้งอัปเดตจาก PackageInstaller: ถ้าระบบขอให้ผู้ใช้ยืนยัน เปิดหน้ายืนยันให้ / ถ้าล้มเหลวแจ้งสาเหตุ */
class UpdateInstallReceiver : BroadcastReceiver() {
    companion object {
        const val ACTION = "com.nop.cartoonstudio.UPDATE_INSTALL_RESULT"
    }

    private fun notifyConfirm(context: Context, confirm: Intent) {
        runCatching {
            val nm = context.getSystemService(Context.NOTIFICATION_SERVICE) as android.app.NotificationManager
            if (android.os.Build.VERSION.SDK_INT >= 26) {
                nm.createNotificationChannel(android.app.NotificationChannel("update", "อัปเดตแอป", android.app.NotificationManager.IMPORTANCE_HIGH))
            }
            val pi = android.app.PendingIntent.getActivity(
                context, 1, confirm,
                android.app.PendingIntent.FLAG_UPDATE_CURRENT or android.app.PendingIntent.FLAG_IMMUTABLE,
            )
            val n = androidx.core.app.NotificationCompat.Builder(context, "update")
                .setSmallIcon(android.R.drawable.stat_sys_download_done)
                .setContentTitle("Cartoon Animator Studio")
                .setContentText("แตะเพื่อยืนยันการอัปเดตเวอร์ชันใหม่")
                .setContentIntent(pi)
                .setAutoCancel(true)
                .build()
            nm.notify(7001, n)
        }
    }

    @Suppress("DEPRECATION")
    override fun onReceive(context: Context, intent: Intent) {
        when (intent.getIntExtra(PackageInstaller.EXTRA_STATUS, PackageInstaller.STATUS_FAILURE)) {
            PackageInstaller.STATUS_PENDING_USER_ACTION -> {
                val confirm = intent.getParcelableExtra<Intent>(Intent.EXTRA_INTENT)
                if (confirm != null) {
                    confirm.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    // เปิดหน้ายืนยันไม่ได้ (เช่น แอปอยู่เบื้องหลัง Android ไม่ให้เปิดหน้าเอง) = ขึ้นการแจ้งเตือนให้แตะเพื่อยืนยันแทน
                    if (runCatching { context.startActivity(confirm) }.isFailure) notifyConfirm(context, confirm)
                }
            }
            PackageInstaller.STATUS_SUCCESS, PackageInstaller.STATUS_FAILURE_ABORTED -> Unit // สำเร็จ (แอปถูกแทนที่) หรือผู้ใช้กดยกเลิกเอง
            else -> {
                val msg = intent.getStringExtra(PackageInstaller.EXTRA_STATUS_MESSAGE) ?: "ไม่ทราบสาเหตุ"
                Toast.makeText(context, "อัปเดตไม่สำเร็จ: $msg", Toast.LENGTH_LONG).show()
            }
        }
    }
}
