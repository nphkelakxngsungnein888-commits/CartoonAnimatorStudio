package com.nop.cartoonstudio

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.pm.PackageInstaller
import android.widget.Toast

/** รับผลการติดตั้งอัปเดตจาก PackageInstaller: ถ้าระบบขอให้ผู้ใช้ยืนยัน เปิดหน้ายืนยันให้ / ถ้าล้มเหลวแจ้งสาเหตุ */
class UpdateInstallReceiver : BroadcastReceiver() {
    companion object {
        const val ACTION = "com.nop.cartoonstudio.UPDATE_INSTALL_RESULT"
    }

    @Suppress("DEPRECATION")
    override fun onReceive(context: Context, intent: Intent) {
        when (intent.getIntExtra(PackageInstaller.EXTRA_STATUS, PackageInstaller.STATUS_FAILURE)) {
            PackageInstaller.STATUS_PENDING_USER_ACTION -> {
                val confirm = intent.getParcelableExtra<Intent>(Intent.EXTRA_INTENT)
                if (confirm != null) {
                    confirm.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    runCatching { context.startActivity(confirm) }
                }
            }
            PackageInstaller.STATUS_SUCCESS, PackageInstaller.STATUS_FAILURE_ABORTED -> Unit // สำเร็จ (แอปถูกแทนที่) หรือผู้ใช้กดยกเลิกเอง
            else -> {
                val msg = intent.getStringExtra(PackageInstaller.EXTRA_STATUS_MESSAGE) ?: "ไม่ทราบสาเหตุ"
                Toast.makeText(context, "อัปเดตไม่สำเร็จ: $msg", Toast.LENGTH_LONG).show()
            }
        }
    }
}
