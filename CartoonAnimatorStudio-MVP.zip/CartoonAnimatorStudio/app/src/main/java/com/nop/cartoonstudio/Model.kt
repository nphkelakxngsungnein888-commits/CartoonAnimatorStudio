package com.nop.cartoonstudio

import android.graphics.Bitmap
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.runtime.snapshots.SnapshotStateMap

/** ท่าของชิ้นส่วนในเฟรมหนึ่ง: มุมหมุน (องศา) และการเลื่อนในพิกัดของ parent */
data class Pose(val rotation: Float = 0f, val dx: Float = 0f, val dy: Float = 0f)

/**
 * ชิ้นส่วนตัวละคร (part)
 * x,y = ตำแหน่งข้อต่อ (joint) ในพิกัดของ parent (ถ้าไม่มี parent = พิกัดโลก)
 * pivotX,pivotY = ตำแหน่งข้อต่อบนภาพ (หน่วยพิกเซลของ bitmap)
 */
class Part(val id: Int, name: String, val bitmap: Bitmap) {
    var name by mutableStateOf(name)
    var parentId by mutableStateOf<Int?>(null)
    var x by mutableFloatStateOf(0f)
    var y by mutableFloatStateOf(0f)
    var pivotX by mutableFloatStateOf(bitmap.width / 2f)
    var pivotY by mutableFloatStateOf(bitmap.height / 2f)
    var restRotation by mutableFloatStateOf(0f) // มุมหมุนพื้นฐานของภาพในโหมดโครง (องศา)
    var boneLength by mutableFloatStateOf(0f) // ความยาวกระดูกที่โหลดมาจากตัวละคร (0 = ไม่ใช่ชิ้นที่มาจากกระดูก)
    var hasTip by mutableStateOf(false) // จุดต่อ (ปลายกระดูก) ที่เพิ่มเอง เป็นของภาพนี้
    var tipX by mutableFloatStateOf(0f)  // ตำแหน่งจุดต่อบนภาพ (พิกเซลของ bitmap)
    var tipY by mutableFloatStateOf(0f)
    var scale by mutableFloatStateOf(1f)
    var flipX by mutableStateOf(false)
    var visible by mutableStateOf(true)
    var characterId by mutableIntStateOf(0) // ตัวละครที่ชิ้นนี้อยู่ในนั้น (0 = ไม่ได้จัดกลุ่ม)
    var characterName by mutableStateOf("")
}

/** ช่วงเฟรมที่ตั้งความเร็วเล่นเอง: เลขเฟรมเริ่มที่ 0 รวมทั้งต้นและปลาย; ช่วงในลิสต์ต้องไม่ทับกัน */
data class SpeedRange(val start: Int, val end: Int, val fps: Int)

class Project {
    val parts = mutableStateListOf<Part>() // ลำดับในลิสต์ = ลำดับการวาด (ล่าง -> บน)
    val speedRanges = mutableStateListOf<SpeedRange>() // ช่วงเฟรมที่ใช้ความเร็วของตัวเองแทนความเร็วปกติ
    // เริ่มที่ 1 เฟรม เพิ่มได้ด้วยปุ่ม + (addFrameFrom)
    val frames = mutableStateListOf<SnapshotStateMap<Int, Pose>>().apply { add(mutableStateMapOf<Int, Pose>()) }
    val frameCount: Int get() = frames.size
    private var nextId = 1

    fun addPart(name: String, bitmap: Bitmap, parentId: Int? = null): Part {
        val p = Part(nextId++, name, bitmap)
        p.parentId = parentId
        parts.add(p)
        return p
    }

    fun part(id: Int?): Part? = if (id == null) null else parts.firstOrNull { it.id == id }

    fun children(id: Int): List<Part> = parts.filter { it.parentId == id }

    fun descendants(id: Int): Set<Int> {
        val out = LinkedHashSet<Int>()
        val stack = ArrayList<Int>()
        stack.add(id)
        while (stack.isNotEmpty()) {
            val cur = stack.removeAt(stack.lastIndex)
            for (c in children(cur)) if (out.add(c.id)) stack.add(c.id)
        }
        return out
    }

    /** ลบชิ้นส่วนและลูกหลานทั้งหมด */
    fun removeWithDescendants(id: Int) {
        val ids = descendants(id) + id
        parts.removeAll { it.id in ids }
        for (f in frames) for (i in ids) f.remove(i)
    }

    private var nextCharacterId = 1
    fun newCharacterId(): Int = nextCharacterId++

    /** ตัวละครทั้งหมดในฉาก (จัดกลุ่มตาม characterId ตามลำดับที่เพิ่ม) */
    fun characters(): List<Pair<Int, String>> =
        parts.filter { it.characterId != 0 }.map { it.characterId to it.characterName }.distinct()

    /** ลบเฉพาะตัวละครตัวนี้ (ทุกชิ้นส่วนของมัน) ตัวอื่นและเฟรมไม่ถูกรีเซ็ต */
    fun removeCharacter(characterId: Int) {
        val ids = parts.filter { it.characterId == characterId }.map { it.id }.toSet()
        parts.removeAll { it.id in ids }
        for (f in frames) for (i in ids) f.remove(i)
    }

    fun clear() {
        parts.clear()
        speedRanges.clear()
        frames.clear()
        frames.add(mutableStateMapOf<Int, Pose>()) // กลับไปเหลือ 1 เฟรมว่าง
    }

    fun rangeAt(frame: Int): SpeedRange? = speedRanges.firstOrNull { frame in it.start..it.end }

    /** ความเร็วของเฟรมนี้: อยู่ในช่วงที่ตั้งไว้ = ค่าของช่วง ไม่งั้นใช้ defaultFps (ความเร็วปกติ) */
    fun fpsAt(frame: Int, defaultFps: Int): Int = rangeAt(frame)?.fps ?: defaultFps

    /**
     * ตรวจว่าตั้งช่วงเฟรม fromN..toN (เลขเฟรมแบบที่แสดงบนจอ เริ่มที่ 1) ได้ไหม: คืนข้อความผิดพลาด หรือ null ถ้าตั้งได้
     * ตั้งทับช่วงที่มีอยู่แล้วไม่ได้ (แม้แต่เฟรมเดียว) ต้องรีเซ็ตช่วงเดิมก่อน
     */
    fun speedRangeError(fromN: Int, toN: Int?, fps: Int?): String? {
        rangeAt(fromN - 1)?.let {
            return "เฟรม $fromN อยู่ในช่วง ${it.start + 1}–${it.end + 1} ที่ตั้งความเร็วไว้แล้ว (${it.fps} fps) ถ้าจะตั้งใหม่ให้กด \"รีเซ็ต\" ก่อน"
        }
        if (toN == null) return "ใส่เลขเฟรมที่จะให้ถึง"
        if (toN < fromN) return "เลขเฟรมต้องไม่น้อยกว่า $fromN"
        if (toN > frameCount) return "มีแค่ $frameCount เฟรม"
        if (fps == null || fps !in 1..240) return "ความเร็วต้องเป็นเลข 1–240"
        val clash = speedRanges.firstOrNull { it.start <= toN - 1 && fromN - 1 <= it.end }
        if (clash != null) {
            return "ช่วงนี้ทับกับเฟรม ${clash.start + 1}–${clash.end + 1} (${clash.fps} fps) ที่ตั้งไว้แล้ว ตั้งซ้ำไม่ได้"
        }
        return null
    }

    fun addSpeedRange(fromN: Int, toN: Int, fps: Int) {
        speedRanges.add(SpeedRange(fromN - 1, toN - 1, fps))
    }

    /** ลบเฟรมที่ index (ต้องเหลืออย่างน้อย 1 เฟรม) คืน false ถ้าลบไม่ได้ */
    fun removeFrame(index: Int): Boolean {
        if (frames.size <= 1 || index !in frames.indices) return false
        frames.removeAt(index)
        // เฟรมหลังจุดที่ลบเลื่อนขึ้น: ช่วงความเร็วต้องเลื่อนตาม (ช่วงที่คร่อมเฟรมที่ลบสั้นลง 1, ช่วงเฟรมเดียวที่ถูกลบหายไป)
        val moved = speedRanges.mapNotNull { r ->
            when {
                index < r.start -> r.copy(start = r.start - 1, end = r.end - 1)
                index <= r.end -> if (r.end > r.start) r.copy(end = r.end - 1) else null
                else -> r
            }
        }
        speedRanges.clear()
        speedRanges.addAll(moved)
        return true
    }

    /** ลบเฟรมทั้งหมด เหลือ 1 เฟรมว่าง (ท่าทั้งหมดและช่วงความเร็วที่ตั้งไว้ถูกล้างด้วย) */
    fun resetFrames() {
        frames.clear()
        frames.add(mutableStateMapOf<Int, Pose>())
        speedRanges.clear()
    }

    /** เพิ่มเฟรมท้ายสุด โดยคัดลอกท่าจากเฟรม src (เฟรมใหม่ไม่รีเซ็ตท่า) */
    fun addFrameFrom(src: Int) {
        val m = mutableStateMapOf<Int, Pose>()
        frames.getOrNull(src)?.let { m.putAll(it) }
        frames.add(m)
    }

    /**
     * จำนวนเฟรมที่ใช้วนเล่นจริง: ถ้าเฟรมสุดท้ายท่าเหมือนเฟรมแรก (คนทำเฟรมปิดวงไว้เอง)
     * จะไม่นับซ้ำ ไม่งั้นท่าเดียวกันค้างอยู่ 2 เฟรมตอนวนกลับ ทำให้ดูสโลว์/กระตุก
     */
    fun loopCount(): Int {
        val n = frameCount
        if (n < 3) return n
        val first = frames[0]
        val last = frames[n - 1]
        val ids = first.keys + last.keys
        for (id in ids) {
            val a = first[id] ?: Pose()
            val b = last[id] ?: Pose()
            if (Math.abs(a.rotation - b.rotation) > 0.5f || Math.abs(a.dx - b.dx) > 0.5f || Math.abs(a.dy - b.dy) > 0.5f) return n
        }
        return n - 1
    }

    /**
     * แทรกเฟรมใหม่ที่ตำแหน่ง index (เฟรมเดิมตั้งแต่ index เป็นต้นไปเลื่อนไปข้างหลัง 1 ตำแหน่ง)
     * ช่วงความเร็วเลื่อนตาม: ช่วงที่อยู่หลังจุดแทรกเลื่อนไป 1, ช่วงที่คร่อมจุดแทรกยาวขึ้น 1, ช่วงที่จบก่อนจุดแทรกไม่เปลี่ยน
     */
    fun insertFrameAt(index: Int, poses: Map<Int, Pose>) {
        val i = index.coerceIn(0, frames.size)
        val m = mutableStateMapOf<Int, Pose>()
        m.putAll(poses)
        frames.add(i, m)
        val moved = speedRanges.map { r ->
            when {
                i <= r.start -> r.copy(start = r.start + 1, end = r.end + 1)
                i <= r.end -> r.copy(end = r.end + 1)
                else -> r
            }
        }
        speedRanges.clear()
        speedRanges.addAll(moved)
    }

    fun poseAt(frame: Int, id: Int): Pose = frames[frame][id] ?: Pose()

    /** ค่ากลางระหว่างเฟรม (วนกลับเฟรมแรกเมื่อเกินเฟรมสุดท้าย) */
    fun interpolated(position: Float, id: Int, loopN: Int = frameCount): Pose {
        val n = loopN
        val base = Math.floor(position.toDouble()).toInt()
        val t = position - base
        val a = poseAt(Math.floorMod(base, n), id)
        val b = poseAt(Math.floorMod(base + 1, n), id)
        return Pose(
            lerpF(a.rotation, b.rotation, t),
            lerpF(a.dx, b.dx, t),
            lerpF(a.dy, b.dy, t),
        )
    }

    fun snapshotFrames(): List<Map<Int, Pose>> = frames.map { it.toMap() }
}

private fun lerpF(a: Float, b: Float, t: Float): Float = a + (b - a) * t
