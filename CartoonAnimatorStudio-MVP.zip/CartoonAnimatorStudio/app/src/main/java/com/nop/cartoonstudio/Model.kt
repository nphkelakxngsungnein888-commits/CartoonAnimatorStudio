package com.nop.cartoonstudio

import android.graphics.Bitmap
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.runtime.snapshots.SnapshotStateMap
import androidx.compose.ui.geometry.Offset

/** ท่าของชิ้นส่วนในเฟรมหนึ่ง: มุมหมุน (องศา) และการเลื่อนในพิกัดของ parent */
data class Pose(
    val rotation: Float = 0f,
    val dx: Float = 0f,
    val dy: Float = 0f,
    val sculpt: SculptGrid? = null, // การปั้นภาพอิสระของชิ้นนี้ในเฟรมนี้ (null = ไม่ปั้น)
    val flipH: Boolean = false, // พลิกซ้าย-ขวาเฉพาะเฟรมนี้ (ใช้กับชิ้นราก สลับจากค่า Part.mirrorH)
    val flipV: Boolean = false, // พลิกขึ้น-ลงเฉพาะเฟรมนี้
    val from: Pose? = null, // เฉพาะค่ากลางตอนเล่น/ส่งออก (ไม่เก็บในเฟรม): ท่าอิสระของสิ่งของก่อนเข้ามือ ไว้เฉลี่ยให้เลื่อนเข้ามืออย่างต่อเนื่อง
    val blend: Float = 1f, // ใช้คู่กับ from: 0 = อยู่ที่ท่า from, 1 = ถึงปลายมือแล้ว
    val hold: Int = HOLD_NONE, // เฉพาะ "สิ่งของ": HOLD_NONE = ยังไม่ติดมือ (แสดงเป็นสิ่งของอิสระที่ตำแหน่งตอนโหลด ลากย้ายได้), HOLD_FREE = ถอดแล้วค้างอยู่กับที่, มากกว่า 0 = id ของมือที่ถืออยู่ในเฟรมนี้
)

const val HOLD_NONE = 0 // สิ่งของยังไม่ถูกติดมือ ณ เฟรมนี้ (แสดงตามปกติ เหมือนตัวละครที่เพิ่งเพิ่ม)
const val HOLD_FREE = -1 // สิ่งของถูกถอดแล้ว ค้างอยู่ที่ตำแหน่งในท่าของเฟรมนี้ (พิกัดโลก)

/** ค่ากลางระหว่างสองท่า (ใช้ร่วมกันทั้งตอนเล่นในแอปและตอนส่งออก) */
fun lerpPose(a: Pose, b: Pose, t: Float): Pose {
    // สถานะถือของเปลี่ยนระหว่างสองเฟรม (ซ่อน/ถือ/ถอด): ค่าท่าของสองสถานะอยู่คนละกรอบ เฉลี่ยกันไม่ได้ จึงคงท่าเฟรมก่อนหน้าไว้จนถึงเฟรมถัดไป
    if (a.hold != b.hold) {
        // สิ่งของกำลังบินเข้ามือ (อิสระ -> ถือ): เฉลี่ยจากท่าอิสระเข้าปลายมือ ให้เลื่อนต่อเนื่อง (คิดตอนวาดใน computeJointMatrices)
        if (a.hold <= 0 && b.hold > 0) return b.copy(from = a, blend = t)
        return a
    }
    return Pose(
        a.rotation + (b.rotation - a.rotation) * t,
        a.dx + (b.dx - a.dx) * t,
        a.dy + (b.dy - a.dy) * t,
        Sculpt.lerp(a.sculpt, b.sculpt, t),
        a.flipH, // พลิกเป็นแบบสลับทันที: คงค่าเฟรมก่อนหน้าจนถึงเฟรมถัดไป
        a.flipV,
        hold = a.hold,
    )
}

/**
 * ชิ้นส่วนตัวละคร (part)
 * x,y = ตำแหน่งข้อต่อ (joint) ในพิกัดของ parent (ถ้าไม่มี parent = พิกัดโลก)
 * pivotX,pivotY = ตำแหน่งข้อต่อบนภาพ (หน่วยพิกเซลของ bitmap)
 */
class Part(val id: Int, name: String, val bitmap: Bitmap) {
    var name by mutableStateOf(name)
    var parentId by mutableStateOf<Int?>(null)
    var x by mutableFloatStateOf(0f)
    var y by mutableFloatStateOf(0f)
    var pivotX by mutableFloatStateOf(bitmap.width / 2f)
    var pivotY by mutableFloatStateOf(bitmap.height / 2f)
    var restRotation by mutableFloatStateOf(0f) // มุมหมุนพื้นฐานของภาพในโหมดโครง (องศา)
    var boneLength by mutableFloatStateOf(0f) // ความยาวกระดูกที่โหลดมาจากตัวละคร (0 = ไม่ใช่ชิ้นที่มาจากกระดูก)
    var hasTip by mutableStateOf(false) // จุดต่อ (ปลายกระดูก) ที่เพิ่มเอง เป็นของภาพนี้
    var tipX by mutableFloatStateOf(0f)  // ตำแหน่งจุดต่อบนภาพ (พิกเซลของ bitmap)
    var tipY by mutableFloatStateOf(0f)
    var scale by mutableFloatStateOf(1f)
    var flipX by mutableStateOf(false)
    var visible by mutableStateOf(true)
    var characterId by mutableIntStateOf(0) // ตัวละครที่ชิ้นนี้อยู่ในนั้น (0 = ไม่ได้จัดกลุ่ม)
    var characterName by mutableStateOf("")
    var mirrorH by mutableStateOf(false) // พลิกซ้าย-ขวาทั้งตัวละคร (กลับภาพแบบกระจก ใช้กับชิ้นรากเท่านั้น เก็บไว้ทุกชิ้นของตัวละครให้ตรงกัน)
    var mirrorV by mutableStateOf(false) // พลิกขึ้น-ลงทั้งตัวละคร
    var charScale by mutableFloatStateOf(1f) // ขนาดตัวละครทั้งตัวเทียบตอนโหลด (1 = 100%) เก็บไว้ทุกชิ้นของตัวละครให้ตรงกัน
    var role by mutableStateOf(BoneRole.NORMAL) // ประเภทที่ตั้งไว้ในหน้าจัดกระดูก: มือ / สิ่งของ (ปกติ = ไม่เกี่ยวกับการถือของ)
    var homeRest by mutableFloatStateOf(0f) // เฉพาะสิ่งของ: มุมพื้นฐานจริง (องศา ในกรอบโลก) ตอนโหลด ใช้คำนวณมุมตอนเอาไปติดมืออีกครั้ง

    var freed by mutableStateOf(false) // สิ่งของที่ผู้ใช้กด "ถอด" ในหน้าอนิเมชันแล้ว (ต่างจากสิ่งของที่เพิ่งโหลดมายังไม่เคยติดมือ)

    // ช่วงเฟรมที่ตัวละครนี้แสดง (เลขเฟรมเริ่มที่ 0 รวมต้นและปลาย) เก็บไว้ทุกชิ้นของตัวละครให้ตรงกัน: appearTo = -1 = แสดงไปจนจบ (รวมเฟรมที่เพิ่มทีหลัง)
    var appearFrom by mutableIntStateOf(0)
    var appearTo by mutableIntStateOf(-1)
    var charAlpha by mutableFloatStateOf(1f) // ความจางของตัวละครทั้งตัว (1 = ทึบปกติ, น้อยลง = จางลง) เก็บไว้ทุกชิ้นของตัวละครให้ตรงกัน

    /** ชิ้นนี้แสดงที่ตำแหน่งเล่น pos (เลขเฟรมแบบทศนิยมได้ เริ่มที่ 0) ไหม: ก่อนเฟรมเริ่ม / หลังเฟรมจบ = ไม่แสดง */
    fun shownAt(pos: Float): Boolean =
        pos >= appearFrom - 0.001f && (appearTo < 0 || pos <= appearTo + 0.001f)

    /** สิ่งของ: ไม่ใช่ชิ้นรากของตัวละคร (สถานะซ่อน/ถือ/ถอดอยู่ใน Pose.hold รายเฟรม ไม่ตามการลากตัวละคร/เส้นทาง) */
    val isDetachedItem: Boolean get() = role == BoneRole.ITEM && parentId == null
}

/** ช่วงเฟรมที่ตั้งความเร็วเล่นเอง: เลขเฟรมเริ่มที่ 0 รวมทั้งต้นและปลาย; ช่วงในลิสต์ต้องไม่ทับกัน */
data class SpeedRange(val start: Int, val end: Int, val fps: Float)

/** แสดงความเร็ว fps: จำนวนเต็มไม่มีจุด (12) ทศนิยมตัดศูนย์ท้าย (12.5) */
fun fmtFps(f: Float): String {
    if (f == Math.floor(f.toDouble()).toFloat()) return f.toInt().toString()
    return java.math.BigDecimal(f.toString()).stripTrailingZeros().toPlainString()
}

/** ล้างข้อความช่องความเร็ว: เหลือเลข 0-9 กับจุดทศนิยมได้ 1 จุด (รับ "," เป็นจุด) ยาวไม่เกิน 6 ตัว */
fun cleanFpsText(raw: String): String {
    val sb = StringBuilder()
    var dot = false
    for (c in raw) {
        if (c in '0'..'9') sb.append(c)
        else if ((c == '.' || c == ',') && !dot) { dot = true; sb.append('.') }
    }
    return sb.toString().take(6)
}

const val FPS_MIN = 0.1f
const val FPS_MAX = 240f

/**
 * เส้นทางเคลื่อนที่ของตัวละครหนึ่งตัว (เส้นยังแก้ได้ทีหลัง และถูกเก็บในไฟล์เซฟ)
 * points = จุดควบคุมในพิกัดฉาก (ไม่ขึ้นกับซูม/เลื่อนจอ), startFrame..endFrame = ช่วงเฟรมที่เส้นนี้คุม (เริ่มที่ 0 รวมปลาย)
 * ตำแหน่งในแต่ละเฟรมถูก "ฝัง" ลง Pose ของชิ้นรากทุกครั้งที่เส้นเปลี่ยน เครื่องเล่นและตัวส่งออกจึงอ่าน Pose เหมือนเดิม
 * frameT = ตำแหน่งของแต่ละเฟรมบนเส้น เป็นสัดส่วนความยาวเส้น 0..1 (จุดขาวเล็กๆ ที่ลากย้ายได้ตามเส้นเท่านั้น); ว่าง = ห่างเท่ากันทุกเฟรม
 * baseRotation = มุมของตัวละครตอนสร้างเส้น (ใช้เป็นฐานเมื่อเปิด "หันตามทิศเดิน"), headingWritten = เคยเขียนมุมลงเฟรมแล้ว
 */
data class MotionPath(
    val characterId: Int,
    val points: List<Offset>,
    val smooth: Boolean = true,
    val startFrame: Int = 0,
    val endFrame: Int = 0,
    val frameT: List<Float> = emptyList(),
    val followHeading: Boolean = false,
    val closed: Boolean = false,
    val baseRotation: Float = 0f,
    val headingWritten: Boolean = false,
)

class Project {
    val parts = mutableStateListOf<Part>() // ลำดับในลิสต์ = ลำดับการวาด (ล่าง -> บน)
    val speedRanges = mutableStateListOf<SpeedRange>() // ช่วงเฟรมที่ใช้ความเร็วของตัวเองแทนความเร็วปกติ
    val paths = mutableStateListOf<MotionPath>() // เส้นทางเคลื่อนที่ (ตัวละครละไม่เกิน 1 เส้น)
    // เริ่มที่ 1 เฟรม เพิ่มได้ด้วยปุ่ม + (addFrameFrom)
    val frames = mutableStateListOf<SnapshotStateMap<Int, Pose>>().apply { add(mutableStateMapOf<Int, Pose>()) }
    val frameCount: Int get() = frames.size
    private var nextId = 1

    fun addPart(name: String, bitmap: Bitmap, parentId: Int? = null): Part {
        val p = Part(nextId++, name, bitmap)
        p.parentId = parentId
        parts.add(p)
        return p
    }

    fun pathOf(characterId: Int?): MotionPath? = if (characterId == null) null else paths.firstOrNull { it.characterId == characterId }

    /** ใส่/แทนที่เส้นทางของตัวละครนั้น (ตัวละครละ 1 เส้น) */
    fun putPath(path: MotionPath) {
        val i = paths.indexOfFirst { it.characterId == path.characterId }
        if (i >= 0) paths[i] = path else paths.add(path)
    }

    fun part(id: Int?): Part? = if (id == null) null else parts.firstOrNull { it.id == id }

    fun children(id: Int): List<Part> = parts.filter { it.parentId == id }

    fun descendants(id: Int): Set<Int> {
        val out = LinkedHashSet<Int>()
        val stack = ArrayList<Int>()
        stack.add(id)
        while (stack.isNotEmpty()) {
            val cur = stack.removeAt(stack.lastIndex)
            for (c in children(cur)) if (out.add(c.id)) stack.add(c.id)
        }
        return out
    }

    /** ลบชิ้นส่วนและลูกหลานทั้งหมด */
    fun removeWithDescendants(id: Int) {
        val ids = descendants(id) + id
        parts.removeAll { it.id in ids }
        for (f in frames) for (i in ids) f.remove(i)
    }

    private var nextCharacterId = 1
    fun newCharacterId(): Int = nextCharacterId++

    /** ตัวละครทั้งหมดในฉาก (จัดกลุ่มตาม characterId ตามลำดับที่เพิ่ม) */
    fun characters(): List<Pair<Int, String>> =
        parts.filter { it.characterId != 0 }.map { it.characterId to it.characterName }.distinct()

    /** ลบเฉพาะตัวละครตัวนี้ (ทุกชิ้นส่วนของมัน) ตัวอื่นและเฟรมไม่ถูกรีเซ็ต */
    fun removeCharacter(characterId: Int) {
        val ids = parts.filter { it.characterId == characterId }.map { it.id }.toSet()
        parts.removeAll { it.id in ids }
        for (f in frames) for (i in ids) f.remove(i)
        paths.removeAll { it.characterId == characterId } // เส้นทางของตัวละครที่ถูกลบหายไปด้วย
    }

    fun clear() {
        parts.clear()
        speedRanges.clear()
        paths.clear()
        frames.clear()
        frames.add(mutableStateMapOf<Int, Pose>()) // กลับไปเหลือ 1 เฟรมว่าง
    }

    fun rangeAt(frame: Int): SpeedRange? = speedRanges.firstOrNull { frame in it.start..it.end }

    /** ความเร็วของเฟรมนี้: อยู่ในช่วงที่ตั้งไว้ = ค่าของช่วง ไม่งั้นใช้ defaultFps (ความเร็วปกติ) */
    fun fpsAt(frame: Int, defaultFps: Float): Float = rangeAt(frame)?.fps ?: defaultFps

    /**
     * ตรวจว่าตั้งช่วงเฟรม fromN..toN (เลขเฟรมแบบที่แสดงบนจอ เริ่มที่ 1) ได้ไหม: คืนข้อความผิดพลาด หรือ null ถ้าตั้งได้
     * ตั้งทับช่วงที่มีอยู่แล้วไม่ได้ (แม้แต่เฟรมเดียว) ต้องรีเซ็ตช่วงเดิมก่อน
     */
    fun speedRangeError(fromN: Int, toN: Int?, fps: Float?): String? {
        rangeAt(fromN - 1)?.let {
            return "เฟรม $fromN อยู่ในช่วง ${it.start + 1}–${it.end + 1} ที่ตั้งความเร็วไว้แล้ว (${fmtFps(it.fps)} fps) ถ้าจะตั้งใหม่ให้กด \"รีเซ็ต\" ก่อน"
        }
        if (toN == null) return "ใส่เลขเฟรมที่จะให้ถึง"
        if (toN < fromN) return "เลขเฟรมต้องไม่น้อยกว่า $fromN"
        if (toN > frameCount) return "มีแค่ $frameCount เฟรม"
        if (fps == null || fps !in FPS_MIN..FPS_MAX) return "ความเร็วต้องเป็นเลข ${fmtFps(FPS_MIN)}–${fmtFps(FPS_MAX)}"
        val clash = speedRanges.firstOrNull { it.start <= toN - 1 && fromN - 1 <= it.end }
        if (clash != null) {
            return "ช่วงนี้ทับกับเฟรม ${clash.start + 1}–${clash.end + 1} (${fmtFps(clash.fps)} fps) ที่ตั้งไว้แล้ว ตั้งซ้ำไม่ได้"
        }
        return null
    }

    fun addSpeedRange(fromN: Int, toN: Int, fps: Float) {
        speedRanges.add(SpeedRange(fromN - 1, toN - 1, fps))
    }

    /** ลบเฟรมที่ index (ต้องเหลืออย่างน้อย 1 เฟรม) คืน false ถ้าลบไม่ได้ */
    fun removeFrame(index: Int): Boolean {
        if (frames.size <= 1 || index !in frames.indices) return false
        frames.removeAt(index)
        // เฟรมหลังจุดที่ลบเลื่อนขึ้น: ช่วงความเร็วต้องเลื่อนตาม (ช่วงที่คร่อมเฟรมที่ลบสั้นลง 1, ช่วงเฟรมเดียวที่ถูกลบหายไป)
        shiftAppearOnRemove(index)
        val moved = speedRanges.mapNotNull { r ->
            when {
                index < r.start -> r.copy(start = r.start - 1, end = r.end - 1)
                index <= r.end -> if (r.end > r.start) r.copy(end = r.end - 1) else null
                else -> r
            }
        }
        speedRanges.clear()
        speedRanges.addAll(moved)
        // ช่วงเฟรมของเส้นทางเลื่อนตามแบบเดียวกัน (ช่วงที่คร่อมเฟรมที่ลบสั้นลง 1, ช่วงเฟรมเดียวที่ถูกลบหายไป)
        val movedPaths = paths.mapNotNull { r ->
            when {
                index < r.startFrame -> r.copy(startFrame = r.startFrame - 1, endFrame = r.endFrame - 1)
                index <= r.endFrame -> if (r.endFrame > r.startFrame) r.copy(endFrame = r.endFrame - 1) else null
                else -> r
            }
        }
        paths.clear()
        paths.addAll(movedPaths)
        return true
    }

    /** ลบเฟรมทั้งหมด เหลือ 1 เฟรมว่าง (ท่าทั้งหมดและช่วงความเร็วที่ตั้งไว้ถูกล้างด้วย) */
    fun resetFrames() {
        frames.clear()
        frames.add(mutableStateMapOf<Int, Pose>())
        speedRanges.clear()
        paths.clear() // ท่าทั้งหมดถูกล้าง เส้นทางที่ฝังไว้ก็หมดความหมาย
        for (p in parts) { p.appearFrom = 0; p.appearTo = -1 } // เหลือเฟรมเดียว: ช่วงแสดงของตัวละครกลับเป็นแสดงตลอด
    }

    /** ลบเฟรม index ไปแล้ว: ช่วงแสดงของตัวละครเลื่อนตาม (เหมือนช่วงความเร็ว) ช่วงเฟรมเดียวที่ถูกลบ = ตัวละครไปอยู่เฟรมที่เลื่อนมาแทน ไม่หายไปจากไทม์ไลน์ */
    private fun shiftAppearOnRemove(index: Int) {
        val last = frames.size - 1 // นับหลังลบแล้ว
        for (p in parts) {
            val f = p.appearFrom
            val t = p.appearTo
            if (f == 0 && t < 0) continue
            when {
                index < f -> { p.appearFrom = f - 1; if (t >= 0) p.appearTo = t - 1 }
                t < 0 -> p.appearFrom = f.coerceAtMost(last)
                index <= t -> if (t > f) {
                    p.appearTo = t - 1
                } else {
                    p.appearFrom = f.coerceAtMost(last)
                    p.appearTo = p.appearFrom
                }
            }
        }
    }

    /** แทรกเฟรมที่ index แล้ว: ช่วงแสดงของตัวละครเลื่อนตาม (หลังจุดแทรกเลื่อนไป 1, คร่อมจุดแทรกยาวขึ้น 1) */
    private fun shiftAppearOnInsert(i: Int) {
        for (p in parts) {
            val f = p.appearFrom
            val t = p.appearTo
            if (f == 0 && t < 0) continue
            when {
                i <= f -> { p.appearFrom = f + 1; if (t >= 0) p.appearTo = t + 1 }
                t >= 0 && i <= t -> p.appearTo = t + 1
            }
        }
    }

    /** เพิ่มเฟรมท้ายสุด โดยคัดลอกท่าจากเฟรม src (เฟรมใหม่ไม่รีเซ็ตท่า) */
    fun addFrameFrom(src: Int) {
        val m = mutableStateMapOf<Int, Pose>()
        frames.getOrNull(src)?.let { m.putAll(it) }
        frames.add(m)
    }

    /**
     * จำนวนเฟรมที่ใช้วนเล่นจริง: ถ้าเฟรมสุดท้ายท่าเหมือนเฟรมแรก (คนทำเฟรมปิดวงไว้เอง)
     * จะไม่นับซ้ำ ไม่งั้นท่าเดียวกันค้างอยู่ 2 เฟรมตอนวนกลับ ทำให้ดูสโลว์/กระตุก
     */
    fun loopCount(): Int {
        val n = frameCount
        if (n < 3) return n
        val first = frames[0]
        val last = frames[n - 1]
        val ids = first.keys + last.keys
        for (id in ids) {
            val a = first[id] ?: Pose()
            val b = last[id] ?: Pose()
            if (Math.abs(a.rotation - b.rotation) > 0.5f || Math.abs(a.dx - b.dx) > 0.5f || Math.abs(a.dy - b.dy) > 0.5f || a.sculpt != b.sculpt || a.flipH != b.flipH || a.flipV != b.flipV || a.hold != b.hold) return n
        }
        return n - 1
    }

    /**
     * แทรกเฟรมใหม่ที่ตำแหน่ง index (เฟรมเดิมตั้งแต่ index เป็นต้นไปเลื่อนไปข้างหลัง 1 ตำแหน่ง)
     * ช่วงความเร็วเลื่อนตาม: ช่วงที่อยู่หลังจุดแทรกเลื่อนไป 1, ช่วงที่คร่อมจุดแทรกยาวขึ้น 1, ช่วงที่จบก่อนจุดแทรกไม่เปลี่ยน
     */
    fun insertFrameAt(index: Int, poses: Map<Int, Pose>) {
        val i = index.coerceIn(0, frames.size)
        val m = mutableStateMapOf<Int, Pose>()
        m.putAll(poses)
        frames.add(i, m)
        shiftAppearOnInsert(i)
        val moved = speedRanges.map { r ->
            when {
                i <= r.start -> r.copy(start = r.start + 1, end = r.end + 1)
                i <= r.end -> r.copy(end = r.end + 1)
                else -> r
            }
        }
        speedRanges.clear()
        speedRanges.addAll(moved)
        val movedPaths = paths.map { r ->
            when {
                i <= r.startFrame -> r.copy(startFrame = r.startFrame + 1, endFrame = r.endFrame + 1)
                i <= r.endFrame -> r.copy(endFrame = r.endFrame + 1)
                else -> r
            }
        }
        paths.clear()
        paths.addAll(movedPaths)
    }

    fun poseAt(frame: Int, id: Int): Pose = frames[frame][id] ?: Pose()

    /** ค่ากลางระหว่างเฟรม (วนกลับเฟรมแรกเมื่อเกินเฟรมสุดท้าย) */
    fun interpolated(position: Float, id: Int, loopN: Int = frameCount): Pose {
        val n = loopN
        val base = Math.floor(position.toDouble()).toInt()
        val t = position - base
        val a = poseAt(Math.floorMod(base, n), id)
        val b = poseAt(Math.floorMod(base + 1, n), id)
        return lerpPose(a, b, t)
    }

    fun snapshotFrames(): List<Map<Int, Pose>> = frames.map { it.toMap() }
}

private fun lerpF(a: Float, b: Float, t: Float): Float = a + (b - a) * t
