package com.nop.cartoonstudio

import android.graphics.Bitmap
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.runtime.snapshots.SnapshotStateMap

/** ท่าของชิ้นส่วนในเฟรมหนึ่ง: มุมหมุน (องศา) และการเลื่อนในพิกัดของ parent */
data class Pose(val rotation: Float = 0f, val dx: Float = 0f, val dy: Float = 0f)

/**
 * ชิ้นส่วนตัวละคร (part)
 * x,y = ตำแหน่งข้อต่อ (joint) ในพิกัดของ parent (ถ้าไม่มี parent = พิกัดโลก)
 * pivotX,pivotY = ตำแหน่งข้อต่อบนภาพ (หน่วยพิกเซลของ bitmap)
 */
class Part(val id: Int, name: String, val bitmap: Bitmap) {
    var name by mutableStateOf(name)
    var parentId by mutableStateOf<Int?>(null)
    var x by mutableFloatStateOf(0f)
    var y by mutableFloatStateOf(0f)
    var pivotX by mutableFloatStateOf(bitmap.width / 2f)
    var pivotY by mutableFloatStateOf(bitmap.height / 2f)
    var restRotation by mutableFloatStateOf(0f) // มุมหมุนพื้นฐานของภาพในโหมดโครง (องศา)
    var boneLength by mutableFloatStateOf(0f) // ความยาวกระดูกที่โหลดมาจากตัวละคร (0 = ไม่ใช่ชิ้นที่มาจากกระดูก)
    var hasTip by mutableStateOf(false) // จุดต่อ (ปลายกระดูก) ที่เพิ่มเอง เป็นของภาพนี้
    var tipX by mutableFloatStateOf(0f)  // ตำแหน่งจุดต่อบนภาพ (พิกเซลของ bitmap)
    var tipY by mutableFloatStateOf(0f)
    var scale by mutableFloatStateOf(1f)
    var flipX by mutableStateOf(false)
    var visible by mutableStateOf(true)
}

class Project {
    val parts = mutableStateListOf<Part>() // ลำดับในลิสต์ = ลำดับการวาด (ล่าง -> บน)
    // เริ่มที่ 1 เฟรม เพิ่มได้ด้วยปุ่ม + (addFrameFrom)
    val frames = mutableStateListOf<SnapshotStateMap<Int, Pose>>().apply { add(mutableStateMapOf<Int, Pose>()) }
    val frameCount: Int get() = frames.size
    private var nextId = 1

    fun addPart(name: String, bitmap: Bitmap, parentId: Int? = null): Part {
        val p = Part(nextId++, name, bitmap)
        p.parentId = parentId
        parts.add(p)
        return p
    }

    fun part(id: Int?): Part? = if (id == null) null else parts.firstOrNull { it.id == id }

    fun children(id: Int): List<Part> = parts.filter { it.parentId == id }

    fun descendants(id: Int): Set<Int> {
        val out = LinkedHashSet<Int>()
        val stack = ArrayList<Int>()
        stack.add(id)
        while (stack.isNotEmpty()) {
            val cur = stack.removeAt(stack.lastIndex)
            for (c in children(cur)) if (out.add(c.id)) stack.add(c.id)
        }
        return out
    }

    /** ลบชิ้นส่วนและลูกหลานทั้งหมด */
    fun removeWithDescendants(id: Int) {
        val ids = descendants(id) + id
        parts.removeAll { it.id in ids }
        for (f in frames) for (i in ids) f.remove(i)
    }

    fun clear() {
        parts.clear()
        frames.clear()
        frames.add(mutableStateMapOf<Int, Pose>()) // กลับไปเหลือ 1 เฟรมว่าง
    }

    /** เพิ่มเฟรมท้ายสุด โดยคัดลอกท่าจากเฟรม src (เฟรมใหม่ไม่รีเซ็ตท่า) */
    fun addFrameFrom(src: Int) {
        val m = mutableStateMapOf<Int, Pose>()
        frames.getOrNull(src)?.let { m.putAll(it) }
        frames.add(m)
    }

    fun poseAt(frame: Int, id: Int): Pose = frames[frame][id] ?: Pose()

    /** ค่ากลางระหว่างเฟรม (วนกลับเฟรมแรกเมื่อเกินเฟรมสุดท้าย) */
    fun interpolated(position: Float, id: Int): Pose {
        val n = frameCount
        val base = Math.floor(position.toDouble()).toInt()
        val t = position - base
        val a = poseAt(Math.floorMod(base, n), id)
        val b = poseAt(Math.floorMod(base + 1, n), id)
        return Pose(
            lerpF(a.rotation, b.rotation, t),
            lerpF(a.dx, b.dx, t),
            lerpF(a.dy, b.dy, t),
        )
    }

    fun snapshotFrames(): List<Map<Int, Pose>> = frames.map { it.toMap() }
}

private fun lerpF(a: Float, b: Float, t: Float): Float = a + (b - a) * t
