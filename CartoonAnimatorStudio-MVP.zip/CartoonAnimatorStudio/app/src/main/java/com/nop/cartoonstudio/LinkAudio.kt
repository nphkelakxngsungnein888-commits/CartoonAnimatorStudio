package com.nop.cartoonstudio

import android.content.ContentValues
import android.content.Context
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import okhttp3.OkHttpClient
import okhttp3.RequestBody.Companion.toRequestBody
import org.schabi.newpipe.extractor.NewPipe
import org.schabi.newpipe.extractor.downloader.Downloader
import org.schabi.newpipe.extractor.downloader.Request
import org.schabi.newpipe.extractor.downloader.Response
import org.schabi.newpipe.extractor.exceptions.ReCaptchaException
import org.schabi.newpipe.extractor.stream.DeliveryMethod
import org.schabi.newpipe.extractor.stream.StreamInfo
import java.io.File
import java.io.FileOutputStream
import java.io.IOException
import java.util.concurrent.TimeUnit

/**
 * โหลดเสียงจากลิงค์: YouTube (ผ่าน NewPipeExtractor) หรือลิงค์ตรงไปยังไฟล์เสียง/วิดีโอ
 * ดาวน์โหลดลงแคช -> แปลงเป็น WAV ด้วย AudioDecoder เดิม (ได้ไฟล์ในที่เก็บเสียงของแอป) -> บันทึกเข้าเครื่องได้ด้วย saveAudio
 * ส่วน YouTube แยกไว้ในฟังก์ชันของตัวเอง ถ้า YouTube เปลี่ยนระบบจนใช้ไม่ได้ ลิงค์ตรงยังใช้ได้ตามปกติ
 */
object LinkAudio {
    class Cancelled : IOException("ยกเลิกแล้ว")
    private class HttpError(val code: Int) : IOException("เซิร์ฟเวอร์ตอบกลับ HTTP $code")

    private const val UA = "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:128.0) Gecko/20100101 Firefox/128.0"
    private const val CHUNK = 4L * 1024 * 1024 // ขนาดก้อนตอนโหลดแบบแบ่งช่วง (ใช้เมื่อ googlevideo ตอบ 403)

    private val client: OkHttpClient by lazy {
        OkHttpClient.Builder()
            .connectTimeout(20, TimeUnit.SECONDS)
            .readTimeout(30, TimeUnit.SECONDS)
            .followRedirects(true)
            .build()
    }

    @Volatile private var inited = false

    private fun ensureInit() {
        if (inited) return
        synchronized(this) {
            if (!inited) {
                NewPipe.init(NpDownloader(client))
                inited = true
            }
        }
    }

    /** ตัวโหลดหน้าเว็บให้ NewPipeExtractor (ใช้ OkHttp) */
    private class NpDownloader(private val http: OkHttpClient) : Downloader() {
        override fun execute(request: Request): Response {
            val method = request.httpMethod()
            val data = request.dataToSend()
            val body = when {
                data != null -> data.toRequestBody()
                method == "POST" || method == "PUT" -> ByteArray(0).toRequestBody()
                else -> null
            }
            val b = okhttp3.Request.Builder().url(request.url()).method(method, body).header("User-Agent", UA)
            for ((k, list) in request.headers()) {
                b.removeHeader(k)
                for (v in list) b.addHeader(k, v)
            }
            http.newCall(b.build()).execute().use { resp ->
                if (resp.code == 429) throw ReCaptchaException("reCaptcha Challenge requested", request.url())
                val text = resp.body?.string()
                return Response(resp.code, resp.message, resp.headers.toMultimap(), text, resp.request.url.toString())
            }
        }
    }

    fun isYoutube(url: String): Boolean {
        val h = Uri.parse(url).host?.lowercase() ?: return false
        return h == "youtu.be" || h == "youtube.com" || h.endsWith(".youtube.com")
    }

    /** เติม https:// ให้ถ้าไม่มี คืน null ถ้าไม่ใช่ลิงค์ที่ใช้ได้ */
    fun normalize(raw: String): String? {
        var s = raw.trim()
        if (s.isEmpty() || s.any { it.isWhitespace() }) return null
        if (!s.contains("://")) s = "https://$s"
        val u = Uri.parse(s)
        val scheme = u.scheme?.lowercase()
        if (scheme != "http" && scheme != "https") return null
        if (u.host.isNullOrBlank()) return null
        return s
    }

    /**
     * โหลดลิงค์แล้วแปลงเป็น WAV ในที่เก็บเสียงของแอป (เรียกใน Dispatchers.IO)
     * onStatus = ข้อความขั้นตอน, onProgress = 0..1 รวมทั้งดาวน์โหลดและแปลง, cancelled = เช็คว่าผู้ใช้กดยกเลิกหรือยัง
     */
    fun fetch(
        context: Context,
        rawUrl: String,
        onStatus: (String) -> Unit,
        onProgress: (Float) -> Unit,
        cancelled: () -> Boolean,
    ): AudioStore.Imported {
        val url = normalize(rawUrl) ?: throw IOException("ลิงค์ไม่ถูกต้อง")
        val cache = File(context.cacheDir, "linkaudio")
        if (!cache.exists()) cache.mkdirs()
        val now = System.currentTimeMillis()
        cache.listFiles()?.forEach { if (it.isFile && now - it.lastModified() > 30 * 60 * 1000L) it.delete() } // เก็บกวาดไฟล์ค้างเก่า

        val streamUrl: String
        val name: String
        val ext: String
        val direct: Boolean
        if (isYoutube(url)) {
            direct = false
            onStatus("กำลังอ่านข้อมูลวิดีโอ YouTube...")
            val info = try {
                ensureInit()
                StreamInfo.getInfo(url)
            } catch (t: Throwable) {
                throw IOException("อ่านลิงค์ YouTube ไม่สำเร็จ (${t.message ?: t.javaClass.simpleName}) อาจเป็นเพราะ YouTube เปลี่ยนระบบ ต้องอัปเดตไลบรารี NewPipeExtractor")
            }
            val best = info.audioStreams
                .filter { it.deliveryMethod == DeliveryMethod.PROGRESSIVE_HTTP && it.content.startsWith("http") }
                .maxByOrNull { it.averageBitrate }
                ?: throw IOException("ไม่พบสตรีมเสียงที่โหลดตรงได้ในวิดีโอนี้ (อาจเป็นไลฟ์สด วิดีโอจำกัดอายุ หรือถูกบล็อก)")
            streamUrl = best.content
            name = info.name ?: "YouTube"
            ext = best.format?.suffix ?: "m4a"
        } else {
            direct = true
            streamUrl = url
            val last = Uri.parse(url).lastPathSegment ?: "เสียง"
            name = last.substringBeforeLast('.').ifBlank { "เสียง" }
            ext = last.substringAfterLast('.', "").lowercase().takeIf { it.length in 2..5 && it.all { c -> c.isLetterOrDigit() } } ?: "bin"
        }

        val src = File(cache, "dl_${System.currentTimeMillis()}.$ext")
        val fileName = AudioStore.newFileName()
        val out = File(AudioStore.dir(context), fileName)
        try {
            onStatus("กำลังดาวน์โหลด...")
            download(streamUrl, src, direct, cancelled) { p -> onProgress(p * 0.5f) }
            if (cancelled()) throw Cancelled()
            onStatus("กำลังแปลงเป็นไฟล์เสียง...")
            val r = AudioDecoder.decodeToWav(context, Uri.fromFile(src), out) { p -> onProgress(0.5f + p * 0.5f) }
            return AudioStore.Imported(fileName, name.take(40).ifBlank { "เสียง" }, r.durSec, r.peaks)
        } catch (t: Throwable) {
            out.delete()
            if (t is IOException && t.message?.contains("Cleartext", ignoreCase = true) == true) {
                throw IOException("ลิงค์แบบ http ไม่ปลอดภัยและถูกบล็อก ลองใช้ลิงค์ https")
            }
            throw t
        } finally {
            src.delete()
        }
    }

    private fun download(url: String, dest: File, rejectHtml: Boolean, cancelled: () -> Boolean, onProgress: (Float) -> Unit) {
        try {
            get(url, dest, append = false, range = null, rejectHtml = rejectHtml, cancelled = cancelled) { done, total ->
                if (total > 0) onProgress((done.toFloat() / total).coerceIn(0f, 1f))
            }
        } catch (e: HttpError) {
            // ลิงค์ของ googlevideo บางครั้งตอบ 403 ถ้าไม่ขอเป็นช่วง ลองโหลดเป็นก้อนด้วยพารามิเตอร์ range (ใช้ความยาวจาก clen ในลิงค์)
            val clen = Uri.parse(url).getQueryParameter("clen")?.toLongOrNull()
            if (e.code != 403 || clen == null || clen <= 0) throw e
            dest.delete()
            var start = 0L
            while (start < clen) {
                if (cancelled()) throw Cancelled()
                val end = minOf(start + CHUNK - 1, clen - 1)
                val got = get("$url&range=$start-$end", dest, append = true, range = null, rejectHtml = false, cancelled = cancelled) { _, _ -> }
                if (got <= 0) throw IOException("โหลดแบบแบ่งช่วงไม่สำเร็จ")
                start += got
                onProgress((start.toFloat() / clen).coerceIn(0f, 1f))
            }
        }
    }

    /** ดาวน์โหลดลิงค์เดียวลงไฟล์ คืนจำนวนไบต์ที่ได้ */
    private fun get(
        url: String,
        dest: File,
        append: Boolean,
        range: String?,
        rejectHtml: Boolean,
        cancelled: () -> Boolean,
        onBytes: (Long, Long) -> Unit,
    ): Long {
        val rb = okhttp3.Request.Builder().url(url).header("User-Agent", UA)
        if (range != null) rb.header("Range", range)
        client.newCall(rb.build()).execute().use { resp ->
            if (!resp.isSuccessful) throw HttpError(resp.code)
            val ct = resp.header("Content-Type")?.lowercase() ?: ""
            if (rejectHtml && (ct.startsWith("text/") || ct.contains("html"))) {
                throw IOException("ลิงค์นี้เป็นหน้าเว็บ ไม่ใช่ไฟล์เสียงหรือวิดีโอโดยตรง")
            }
            val body = resp.body ?: throw IOException("เซิร์ฟเวอร์ไม่ส่งข้อมูลมา")
            val total = body.contentLength()
            var done = 0L
            FileOutputStream(dest, append).use { os ->
                body.byteStream().use { ins ->
                    val buf = ByteArray(1 shl 16)
                    while (true) {
                        if (cancelled()) throw Cancelled()
                        val n = ins.read(buf)
                        if (n < 0) break
                        os.write(buf, 0, n)
                        done += n
                        onBytes(done, total)
                    }
                }
            }
            return done
        }
    }

    /** บันทึกไฟล์ WAV เข้าเครื่อง (โฟลเดอร์ Music/CartoonAnimatorStudio) คืนข้อความที่อยู่ไฟล์ (เรียกใน Dispatchers.IO) */
    fun saveAudio(context: Context, src: File, name: String): String {
        val safe = name.replace(Regex("[\\\\/:*?\"<>|\\p{Cntrl}]"), "_").trim().take(60).ifBlank { "audio" }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            val values = ContentValues().apply {
                put(MediaStore.Audio.Media.DISPLAY_NAME, "$safe.wav")
                put(MediaStore.Audio.Media.MIME_TYPE, "audio/x-wav")
                put(MediaStore.Audio.Media.RELATIVE_PATH, "Music/CartoonAnimatorStudio")
                put(MediaStore.Audio.Media.IS_PENDING, 1)
            }
            val resolver = context.contentResolver
            val uri = resolver.insert(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, values)
                ?: throw IOException("สร้างไฟล์ในโฟลเดอร์เพลงไม่ได้")
            try {
                val os = resolver.openOutputStream(uri) ?: throw IOException("เปิดไฟล์เพื่อเขียนไม่ได้")
                os.use { o -> src.inputStream().use { it.copyTo(o) } }
                values.clear()
                values.put(MediaStore.Audio.Media.IS_PENDING, 0)
                resolver.update(uri, values, null, null)
            } catch (e: Exception) {
                resolver.delete(uri, null, null)
                throw e
            }
            return "Music/CartoonAnimatorStudio/$safe.wav"
        } else {
            val dir = File(context.getExternalFilesDir(Environment.DIRECTORY_MUSIC), "CartoonAnimatorStudio")
            if (!dir.exists() && !dir.mkdirs()) throw IOException("สร้างโฟลเดอร์ไม่ได้")
            var f = File(dir, "$safe.wav")
            var i = 1
            while (f.exists()) f = File(dir, "${safe}_${i++}.wav")
            src.inputStream().use { ins -> FileOutputStream(f).use { ins.copyTo(it) } }
            return f.absolutePath
        }
    }
}
