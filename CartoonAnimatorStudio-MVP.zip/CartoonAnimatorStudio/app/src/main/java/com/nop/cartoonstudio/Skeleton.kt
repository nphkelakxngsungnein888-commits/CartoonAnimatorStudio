package com.nop.cartoonstudio

import android.graphics.Bitmap
import android.graphics.Matrix
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.geometry.Offset
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.sin

const val MIN_BONE_LENGTH = 20f

/**
 * ภาพที่ติดกับกระดูก: พิกัดอยู่ในกรอบของกระดูก (โคน = (0,0), แกน x ชี้ไปทางปลายกระดูก, y ชี้ลง)
 * x,y = ตำแหน่งกึ่งกลางภาพ, rotation = มุมหมุนของภาพ (องศา ตามเข็ม), scale = ขนาด
 */
class BoneImage(bitmap: Bitmap) {
    var bitmap by mutableStateOf(bitmap) // เปลี่ยนได้ตอนพลิกภาพ (สร้างบิตแมปกลับฝั่งใหม่)
    var x by mutableFloatStateOf(0f)
    var y by mutableFloatStateOf(0f)
    var rotation by mutableFloatStateOf(0f)
    var scale by mutableFloatStateOf(1f)
}

/** เมทริกซ์วาดภาพของกระดูก: base = ตำแหน่งโคนบนจอ, worldAngle = มุมจริงของกระดูก (ทวนเข็มเป็นบวก) */
fun boneImageMatrix(img: BoneImage, base: Offset, worldAngle: Float): Matrix {
    val m = Matrix()
    m.postTranslate(-img.bitmap.width / 2f, -img.bitmap.height / 2f)
    m.postScale(img.scale, img.scale)
    m.postRotate(img.rotation)
    m.postTranslate(img.x, img.y)
    m.postRotate(-worldAngle) // กระดูกหมุนทวนเข็ม = หมุนบนจอแบบ y ลงเป็นค่าลบ
    m.postTranslate(base.x, base.y)
    return m
}

/**
 * กระดูก (bone) 1 เส้น
 * parentId = กระดูกที่พ่วงอยู่ (null = ออกจากจุดราก)
 * length = ความยาว, angle = มุม (องศา) สัมพัทธ์กับทิศของ parent (ไม่มี parent = มุมจริง)
 * 0 = ชี้ขวา, ค่าบวก = หมุนทวนเข็มนาฬิกา (เหมือนตัวเลข "มุม" ในแอปต้นแบบ)
 */
class Bone(val id: Int, val parentId: Int?, length: Float, angle: Float) {
    var length by mutableFloatStateOf(length)
    var angle by mutableFloatStateOf(angle)
    var poseAngle by mutableFloatStateOf(0f) // มุมที่ขยับเพิ่มตอนดูตัวอย่าง (ไม่แตะมุมจริงของกระดูก)
    var lengthLocked by mutableStateOf(false) // ล็อกความยาว: ลากปลายกระดูกแล้วปรับได้แค่มุม (ไม่ถูกเซฟลงไฟล์ตัวละคร)
    val images = mutableStateListOf<BoneImage>() // ภาพของกระดูกเส้นนี้
}

/** โครงกระดูก: จุดราก (0,0) + กระดูกที่พ่วงต่อกันเป็นต้นไม้ พิกัด x ขวา, y ลง (หน่วยพิกเซล) */
class Skeleton {
    val bones = mutableStateListOf<Bone>()
    private var nextId = 1

    fun bone(id: Int?): Bone? = if (id == null) null else bones.firstOrNull { it.id == id }

    fun add(parentId: Int?, length: Float, angle: Float): Bone {
        val b = Bone(nextId++, parentId, length, angle)
        bones.add(b)
        return b
    }

    fun descendants(id: Int): Set<Int> {
        val out = LinkedHashSet<Int>()
        val stack = ArrayList<Int>()
        stack.add(id)
        while (stack.isNotEmpty()) {
            val cur = stack.removeAt(stack.lastIndex)
            for (c in bones) if (c.parentId == cur && out.add(c.id)) stack.add(c.id)
        }
        return out
    }

    /** เลื่อนกระดูกในลำดับชั้น (ลิสต์ = ล่าง -> บน): delta +1 = ขึ้นบน 1 ชั้น, -1 = ลงล่าง 1 ชั้น; คืน false ถ้าเลื่อนไม่ได้ */
    fun moveBone(id: Int, delta: Int): Boolean {
        val i = bones.indexOfFirst { it.id == id }
        if (i < 0) return false
        val j = i + delta
        if (j !in bones.indices) return false
        val b = bones.removeAt(i)
        bones.add(j, b)
        return true
    }

    /** จัดลำดับชั้นใหม่ตามรายการ id (ต้องมี id ครบทุกกระดูก ไม่งั้นไม่ทำอะไร) */
    fun reorder(ids: List<Int>) {
        val byId = bones.associateBy { it.id }
        val ordered = ids.mapNotNull { byId[it] }
        if (ordered.size != bones.size) return
        bones.clear()
        bones.addAll(ordered)
    }

    /** แทนที่กระดูกทั้งหมดด้วยของ other (ใช้ตอนโหลดตัวละครที่เซฟไว้เข้ามาแก้ไข) */
    fun replaceWith(other: Skeleton) {
        val newBones = other.bones.toList()
        bones.clear()
        bones.addAll(newBones)
        nextId = other.nextId
    }

    /** ลบกระดูกและกระดูกที่พ่วงต่อทั้งหมด */
    fun remove(id: Int) {
        val ids = descendants(id) + id
        bones.removeAll { it.id in ids }
    }

    /** มุมจริงของกระดูก (รวมมุมของ parent ทั้งสาย) */
    fun worldAngle(b: Bone, pose: Boolean = false): Float {
        var sum = 0f
        var cur: Bone? = b
        var guard = 0
        while (cur != null && guard++ < 64) {
            sum += cur.angle + (if (pose) cur.poseAngle else 0f)
            cur = bone(cur.parentId)
        }
        return normalizeAngle(sum)
    }

    /** จุดโคนของกระดูก = ปลายของ parent (ไม่มี parent = จุดราก); pose = true คิดมุมที่ขยับตอนดูตัวอย่างด้วย */
    fun baseOf(b: Bone, pose: Boolean = false): Offset = bone(b.parentId)?.let { tipOf(it, pose) } ?: Offset.Zero

    fun tipOf(b: Bone, pose: Boolean = false): Offset {
        val base = baseOf(b, pose)
        val r = Math.toRadians(worldAngle(b, pose).toDouble())
        return Offset(base.x + b.length * cos(r).toFloat(), base.y - b.length * sin(r).toFloat())
    }

    /** ดูตัวอย่าง: หมุนกระดูกรอบจุดโคน (ความยาวคงเดิม) ให้ชี้ไปที่จุด p; ลูกและภาพตามไปด้วย */
    fun aimPose(b: Bone, p: Offset) {
        val base = baseOf(b, true)
        val dx = p.x - base.x
        val dy = p.y - base.y
        if (hypot(dx, dy) < 1f) return
        val abs = Math.toDegrees(atan2((-dy).toDouble(), dx.toDouble())).toFloat()
        val parentAbs = bone(b.parentId)?.let { worldAngle(it, true) } ?: 0f
        b.poseAngle = normalizeAngle(abs - parentAbs - b.angle)
    }

    /** ชี้ปลายกระดูกไปที่จุด p (ปรับทั้งความยาวและมุม); กระดูกที่พ่วงต่อจะขยับตาม */
    fun aim(b: Bone, p: Offset) {
        val base = baseOf(b)
        val dx = p.x - base.x
        val dy = p.y - base.y
        if (!b.lengthLocked) b.length = max(hypot(dx, dy), MIN_BONE_LENGTH)
        val abs = Math.toDegrees(atan2((-dy).toDouble(), dx.toDouble())).toFloat()
        val parentAbs = bone(b.parentId)?.let { worldAngle(it) } ?: 0f
        b.angle = normalizeAngle(abs - parentAbs)
    }
}

fun normalizeAngle(a: Float): Float {
    var v = a % 360f
    if (v > 180f) v -= 360f
    if (v <= -180f) v += 360f
    return v
}
