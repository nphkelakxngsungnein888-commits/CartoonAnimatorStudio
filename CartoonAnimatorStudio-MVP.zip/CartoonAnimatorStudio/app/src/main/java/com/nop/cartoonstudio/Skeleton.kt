package com.nop.cartoonstudio

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.geometry.Offset
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.sin

const val MIN_BONE_LENGTH = 20f

/**
 * กระดูก (bone) 1 เส้น
 * parentId = กระดูกที่พ่วงอยู่ (null = ออกจากจุดราก)
 * length = ความยาว, angle = มุม (องศา) สัมพัทธ์กับทิศของ parent (ไม่มี parent = มุมจริง)
 * 0 = ชี้ขวา, ค่าบวก = หมุนทวนเข็มนาฬิกา (เหมือนตัวเลข "มุม" ในแอปต้นแบบ)
 */
class Bone(val id: Int, val parentId: Int?, length: Float, angle: Float) {
    var length by mutableFloatStateOf(length)
    var angle by mutableFloatStateOf(angle)
}

/** โครงกระดูก: จุดราก (0,0) + กระดูกที่พ่วงต่อกันเป็นต้นไม้ พิกัด x ขวา, y ลง (หน่วยพิกเซล) */
class Skeleton {
    val bones = mutableStateListOf<Bone>()
    private var nextId = 1

    fun bone(id: Int?): Bone? = if (id == null) null else bones.firstOrNull { it.id == id }

    fun add(parentId: Int?, length: Float, angle: Float): Bone {
        val b = Bone(nextId++, parentId, length, angle)
        bones.add(b)
        return b
    }

    fun descendants(id: Int): Set<Int> {
        val out = LinkedHashSet<Int>()
        val stack = ArrayList<Int>()
        stack.add(id)
        while (stack.isNotEmpty()) {
            val cur = stack.removeAt(stack.lastIndex)
            for (c in bones) if (c.parentId == cur && out.add(c.id)) stack.add(c.id)
        }
        return out
    }

    /** ลบกระดูกและกระดูกที่พ่วงต่อทั้งหมด */
    fun remove(id: Int) {
        val ids = descendants(id) + id
        bones.removeAll { it.id in ids }
    }

    /** มุมจริงของกระดูก (รวมมุมของ parent ทั้งสาย) */
    fun worldAngle(b: Bone): Float {
        var sum = 0f
        var cur: Bone? = b
        var guard = 0
        while (cur != null && guard++ < 64) {
            sum += cur.angle
            cur = bone(cur.parentId)
        }
        return normalizeAngle(sum)
    }

    /** จุดโคนของกระดูก = ปลายของ parent (ไม่มี parent = จุดราก) */
    fun baseOf(b: Bone): Offset = bone(b.parentId)?.let { tipOf(it) } ?: Offset.Zero

    fun tipOf(b: Bone): Offset {
        val base = baseOf(b)
        val r = Math.toRadians(worldAngle(b).toDouble())
        return Offset(base.x + b.length * cos(r).toFloat(), base.y - b.length * sin(r).toFloat())
    }

    /** ชี้ปลายกระดูกไปที่จุด p (ปรับทั้งความยาวและมุม); กระดูกที่พ่วงต่อจะขยับตาม */
    fun aim(b: Bone, p: Offset) {
        val base = baseOf(b)
        val dx = p.x - base.x
        val dy = p.y - base.y
        b.length = max(hypot(dx, dy), MIN_BONE_LENGTH)
        val abs = Math.toDegrees(atan2((-dy).toDouble(), dx.toDouble())).toFloat()
        val parentAbs = bone(b.parentId)?.let { worldAngle(it) } ?: 0f
        b.angle = normalizeAngle(abs - parentAbs)
    }
}

fun normalizeAngle(a: Float): Float {
    var v = a % 360f
    if (v > 180f) v -= 360f
    if (v <= -180f) v += 360f
    return v
}
