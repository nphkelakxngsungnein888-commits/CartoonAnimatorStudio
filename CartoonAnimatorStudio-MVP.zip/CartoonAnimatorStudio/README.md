# Cartoon Animator Studio (MVP)
ดูวิธีติดตั้งในคำตอบแชท

## Canvas & Layers update
- Canvas displays visible image layers as a composited stack.
- Select one or multiple layers from the side Layer panel.
- Drag/pan and pinch gestures transform selected unlocked layers; the rotation handle adjusts the active layer freely.
- Layer controls include visibility, lock, reorder, rename, duplicate, and delete.
- Opacity controls apply to the active selected layer only.
- Layer names and lock states are stored in the project manifest; older projects remain compatible through default values.
