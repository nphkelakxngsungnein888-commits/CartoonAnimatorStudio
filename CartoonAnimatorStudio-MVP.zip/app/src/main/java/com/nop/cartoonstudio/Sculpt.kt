package com.nop.cartoonstudio

import kotlin.math.abs
import kotlin.math.ceil
import kotlin.math.cos
import kotlin.math.hypot
import kotlin.math.pow
import kotlin.math.sin

/**
 * ปั้นภาพอิสระ (mesh deform) ระยะ 0
 *
 * ภาพของชิ้นส่วนถูกแบ่งเป็นตารางจุด (cols x rows ช่อง) แล้วเก็บ "ออฟเซ็ต" ของแต่ละจุดเป็นหน่วยพิกเซลของ bitmap
 * ออฟเซ็ต 0 = รูปเดิม วาดด้วย Canvas.drawBitmapMesh
 *
 * SculptGrid เป็นวัตถุ immutable: ห้ามแก้ค่าใน off หลังสร้าง (สร้างอันใหม่ทุกครั้งที่แก้)
 * เหตุผล: Pose เป็น data class และระบบ undo เปรียบเทียบสถานะด้วย == จึงต้องมี equals ตามค่า
 * และท่าที่ถูกคัดลอกระหว่างเฟรมใช้วัตถุเดียวกันร่วมกันได้โดยไม่กิน RAM เพิ่ม
 *
 * ไฟล์นี้ไม่พึ่ง Android (ทดสอบบน JVM ได้)
 */
class SculptGrid(
    val cols: Int, val rows: Int, val off: FloatArray,
    /** ตำแหน่งเส้นตาข่ายตั้งต้น (สัดส่วน 0..1 ของความกว้าง/สูง ยาว cols+1 / rows+1) null = เว้นระยะเท่ากัน (ตาข่ายถี่ตามจุด = หมุดข้อต่อ) */
    val xs: FloatArray? = null, val ys: FloatArray? = null,
    /** มุมงอ (องศา) ของหมุดข้อต่อ เรียงตามลำดับหมุดของคลิป null/สั้นกว่า = 0 */
    val pinAngles: FloatArray? = null,
) {
    init {
        require(off.size == (cols + 1) * (rows + 1) * 2) { "ขนาดออฟเซ็ตไม่ตรงกับตาราง" }
        require(xs == null || xs.size == cols + 1) { "จำนวนเส้นตาข่ายแนวตั้งไม่ตรง" }
        require(ys == null || ys.size == rows + 1) { "จำนวนเส้นตาข่ายแนวนอนไม่ตรง" }
    }

    /** ไม่มีการบิดเลย: ออฟเซ็ตเป็นศูนย์ และมุมงอของหมุดเป็นศูนย์ทั้งหมด */
    fun isZero(): Boolean = off.all { it == 0f } && (pinAngles == null || pinAngles.all { it == 0f })

    /** ตำแหน่ง x ตั้งต้นของเส้นตาข่ายที่ i (พิกเซล bitmap กว้าง w) */
    fun restX(i: Int, w: Int): Float = if (xs == null) i * w.toFloat() / cols else xs[i] * w
    fun restY(j: Int, h: Int): Float = if (ys == null) j * h.toFloat() / rows else ys[j] * h

    /** สำเนาที่เปลี่ยนเฉพาะออฟเซ็ต (คงรูปแบบตาข่ายและมุมงอของหมุดไว้) */
    fun withOff(o: FloatArray) = SculptGrid(cols, rows, o, xs, ys, pinAngles)

    /** มุมงอของหมุดลำดับที่ i (0 ถ้าไม่มี) */
    fun angleOf(i: Int): Float = pinAngles?.getOrNull(i) ?: 0f

    /** ตาข่ายรูปแบบเดียวกันไหม (จำนวนช่องและตำแหน่งเส้นตรงกัน) */
    fun sameLayout(o: SculptGrid): Boolean =
        cols == o.cols && rows == o.rows &&
            (if (xs == null) o.xs == null else o.xs != null && xs.contentEquals(o.xs)) &&
            (if (ys == null) o.ys == null else o.ys != null && ys.contentEquals(o.ys))

    override fun equals(other: Any?): Boolean =
        this === other || (other is SculptGrid && sameLayout(other) && off.contentEquals(other.off) &&
            (pinAngles ?: FloatArray(0)).let { a -> (other.pinAngles ?: FloatArray(0)).let { b -> trimmedEquals(a, b) } })

    override fun hashCode(): Int {
        var h = 31 * (31 * cols + rows) + off.contentHashCode()
        h = 31 * h + (xs?.contentHashCode() ?: 0)
        h = 31 * h + (ys?.contentHashCode() ?: 0)
        var last = (pinAngles?.size ?: 0) - 1
        while (last >= 0 && pinAngles!![last] == 0f) last--
        for (k in 0..last) h = 31 * h + (pinAngles!![k] + 0f).hashCode()
        return h
    }

    companion object {
        fun zero(cols: Int, rows: Int, xs: FloatArray? = null, ys: FloatArray? = null) =
            SculptGrid(cols, rows, FloatArray((cols + 1) * (rows + 1) * 2), xs, ys)

        /** เทียบมุมงอสองชุด: ตัดศูนย์ท้ายแถวออกก่อน (ยาวไม่เท่ากันแต่ค่าเท่ากัน = เท่ากัน) */
        private fun trimmedEquals(a: FloatArray, b: FloatArray): Boolean {
            val n = maxOf(a.size, b.size)
            for (k in 0 until n) if ((a.getOrNull(k) ?: 0f) != (b.getOrNull(k) ?: 0f)) return false
            return true
        }
    }
}


/** รูปแบบการบิดเชิงพื้นที่เพิ่มเติมที่ทำงานบนตาข่ายเดิม */
enum class AdvancedWarpMode { PINCH, BULGE, SPIRAL, WAVE, SHEAR, PERSPECTIVE, RIPPLE, PUSH, INFLATE, DEFLATE, SMOOTH, FLATTEN, CREASE, GRAVITY, ELASTIC, MAGNET, ARC_BEND, TAPER, RIGID_TRANSFORM, RIBBON_BEND, EDGE_SLIDE, CONTOUR_FLOW, FAN_DEFORM, ORIGAMI_FOLD, TOPOLOGY_REMAP, BOUNDARY_TENSION, VISCOUS_MELT, SEGMENT_OFFSET, ASYMMETRIC_WARP, DIRECTIONAL_COMPRESS, SURFACE_ROLL }

/** ค่าพู่กันและตัวกรองสำหรับ Advanced Warp (หน่วยเปอร์เซ็นต์ ยกเว้นมุม/ระยะ) */
data class WarpSettings(
    val strength: Float = 100f,
    val falloff: Float = 70f,
    val hardness: Float = 0f,
    val smoothness: Float = 70f,
    val angleDeg: Float = 0f,
    val scaleX: Float = 100f,
    val scaleY: Float = 100f,
    val frequency: Float = 4f,
    val phaseDeg: Float = 0f,
    val wavelengthPx: Float = 80f,
    val waveType: String = "Sine",
    val pressure: Float = 100f,
    val pressureCurve: Float = 1f,
    val flow: Float = 100f,
    val density: Float = 100f,
    val stabilizer: Float = 0f,
    val spacing: Float = 10f,
    // Advanced brush dynamics
    val brushShape: String = "วงกลม",
    val startForce: Float = 100f,
    val endForce: Float = 100f,
    val distanceResponse: Float = 0f,
    val forceJitter: Float = 0f,
    val sizeJitter: Float = 0f,
    val angleJitter: Float = 0f,
    val opacity: Float = 100f,
    val maxDeformation: Float = 50f,
    val edgeProtection: Float = 0f,
    val minPointDistance: Float = 0f,
    val meshSmoothing: Float = 0f,
    val centerLock: Boolean = false,
    val symmetry: Boolean = false,
    val lockHorizontal: Boolean = false,
    val lockVertical: Boolean = false,
    val invert: Boolean = false,
    val accumulate: Boolean = false,
    val preserveBoundary: Boolean = true,
    val boundaryClamp: Boolean = false,
    val preventFolding: Boolean = true,
    val preventSelfIntersection: Boolean = true,
    val antiAliasing: Boolean = true,
    val highQualityPreview: Boolean = true,
    val autoKeyframe: Boolean = false,
    val followMotion: Boolean = true,
    val motionStrength: Float = 100f,
    val interpolation: String = "Linear",
    val loopDuration: Float = 1f,
    val deformationDelay: Float = 0f,
    val warpSpeed: Float = 1f,
    val meshCols: Int = 0,
    val meshRows: Int = 0,
)

object Sculpt {
    /** ขนาดช่องตาข่ายโดยประมาณ (พิกเซลของ bitmap) */
    private const val CELL = 48f

    /** ค่าความปลอดภัยกันตาข่ายพับ (ทดสอบด้วยสคริปต์: 1.0 พับ, 0.7 ไม่พับ; ใช้ 0.5 เผื่อไว้) */
    private const val SAFETY = 0.5f

    /** จำนวนช่องของตารางสำหรับ bitmap ขนาด w x h (ผลลัพธ์ = cols, rows) */
    fun gridDims(w: Int, h: Int): Pair<Int, Int> =
        Pair(ceil(w / CELL).toInt().coerceIn(4, 64), ceil(h / CELL).toInt().coerceIn(4, 64))

    /** จำนวนช่องสูงสุดต่อด้านตอนวาดตาข่ายถี่ตามจุด (แปลงเป็นตาข่ายเว้นระยะเท่ากันที่ละเอียดขึ้น) */
    private const val DRAW_GRID_MAX = 96

    /**
     * วาดภาพผ่านตาข่าย (ใช้แทน drawBitmapMesh ตรง ๆ)
     * สาเหตุ: drawBitmapMesh แมปพื้นผิวแบบเว้นระยะเท่ากันเสมอ แต่ตาข่ายถี่ตามจุด (xs/ys ไม่เท่ากัน) วางจุดไม่เท่ากัน
     * ภาพทั้งภาพจึงถูกดึงเข้าหาหมุดทันทีที่งอหมุด (ดูเหมือนภาพย่อ) → แปลงเป็นตาข่ายเว้นระยะเท่ากัน (ละเอียดขึ้น 3 เท่า) ก่อนวาด
     * ตาข่ายปกติ (xs/ys เป็น null) วาดเหมือนเดิมทุกอย่าง
     */
    fun drawMesh(canvas: android.graphics.Canvas, bmp: android.graphics.Bitmap, g: SculptGrid, paint: android.graphics.Paint?) {
        val d = if (g.xs == null && g.ys == null) g
        else resample(g, minOf(g.cols * 3, DRAW_GRID_MAX), minOf(g.rows * 3, DRAW_GRID_MAX))
        canvas.drawBitmapMesh(bmp, d.cols, d.rows, verts(bmp.width, bmp.height, d), 0, null, 0, paint)
    }

    /** ตำแหน่งจุดตาข่ายทั้งหมด (พื้นฐาน + ออฟเซ็ต) รูปแบบ [x0,y0,x1,y1,...] สำหรับ drawBitmapMesh ส่งอาร์เรย์ใหม่ทุกครั้ง */
    fun verts(w: Int, h: Int, g: SculptGrid): FloatArray {
        val out = FloatArray(g.off.size)
        var n = 0
        for (j in 0..g.rows) for (i in 0..g.cols) {
            out[2 * n] = g.restX(i, w) + g.off[2 * n]
            out[2 * n + 1] = g.restY(j, h) + g.off[2 * n + 1]
            n++
        }
        return out
    }

    /**
     * น้ำหนักของแต่ละจุดต่อพู่กัน (คำนวณครั้งเดียวตอนวางนิ้ว)
     * (cx,cy) = จุดนิ้วในพิกัดตาข่าย (พิกเซล bitmap) ใช้ตำแหน่งจุดที่ปั้นแล้ว ให้ตรงกับภาพที่เห็นบนจอ
     * pinR > 0 = ตรึงข้อต่อ: น้ำหนักค่อยๆ ลดเป็น 0 ที่จุดหมุน (pivotX,pivotY)
     */
    /** Signed distance proxy shared by deformation and brush preview geometry. */
    fun brushDistance(nx: Float, ny: Float, shape: String): Float = when (shape) {
        "วงรี" -> hypot(nx / 1.5f, ny / 0.75f)
        "สี่เหลี่ยม" -> maxOf(abs(nx), abs(ny))
        "เพชร" -> abs(nx) + abs(ny)
        "เส้นแนวนอน" -> maxOf(abs(nx), abs(ny) * 2.5f)
        "เส้นแนวตั้ง" -> maxOf(abs(nx) * 2.5f, abs(ny))
        else -> hypot(nx, ny)
    }

    fun brushWeights(
        w: Int, h: Int, g: SculptGrid,
        cx: Float, cy: Float, radius: Float,
        pivotX: Float, pivotY: Float, pinR: Float,
        settings: WarpSettings = WarpSettings(),
    ): FloatArray {
        val out = FloatArray((g.cols + 1) * (g.rows + 1))
        val rawSx = settings.scaleX / 100f
        val rawSy = settings.scaleY / 100f
        val sx = if (abs(rawSx) < 0.000001f) if (rawSx < 0f) -0.000001f else 0.000001f else rawSx
        val sy = if (abs(rawSy) < 0.000001f) if (rawSy < 0f) -0.000001f else 0.000001f else rawSy
        val angle = Math.toRadians(settings.angleDeg.toDouble()).toFloat()
        val cs = cos(angle); val sn = sin(angle)
        val hard = (settings.hardness / 100f).coerceIn(0f, 0.95f)
        val fall = (settings.falloff / 100f).coerceIn(0f, 1f)
        val smooth = (settings.smoothness / 100f).coerceIn(0f, 1f)
        var n = 0
        for (j in 0..g.rows) for (i in 0..g.cols) {
            val vx = g.restX(i, w) + g.off[2 * n]
            val vy = g.restY(j, h) + g.off[2 * n + 1]
            val dx = vx - cx; val dy = vy - cy
            val pointSeed = ((i + 1) * 83492791) xor ((j + 1) * 297121507)
            val pointNoise = ((pointSeed ushr 9) and 2047) / 1023.5f - 1f
            val jitterAngle = Math.toRadians((pointNoise * settings.angleJitter).toDouble()).toFloat()
            val jcs = cos(jitterAngle); val jsn = sin(jitterAngle)
            val localX = (dx * cs + dy * sn) * jcs + (-dx * sn + dy * cs) * jsn
            val localY = -(dx * cs + dy * sn) * jsn + (-dx * sn + dy * cs) * jcs
            val sizeFactor = 1f + pointNoise * settings.sizeJitter / 100f
            val nx = localX / (sx * sizeFactor)
            val ny = localY / (sy * sizeFactor)
            val distance = brushDistance(nx, ny, settings.brushShape)
            val u = (distance / radius.coerceAtLeast(1f)).coerceIn(0f, 1f)
            val t = ((1f - u) / (1f - hard)).coerceIn(0f, 1f)
            val shaped = t.pow(0.35f + fall * 2.65f)
            val eased = t * t * (3f - 2f * t)
            var wt = shaped * (1f - smooth) + eased * smooth
            if (settings.preserveBoundary) {
                val edge = minOf(vx, w - vx, vy, h - vy).coerceAtLeast(0f)
                wt *= (edge / (radius * 0.35f).coerceAtLeast(1f)).coerceIn(0f, 1f)
            }
            val edge = minOf(vx, w - vx, vy, h - vy).coerceAtLeast(0f)
            val edgeKeep = (edge / (radius * 0.5f).coerceAtLeast(1f)).coerceIn(0f, 1f)
            wt *= (1f - (settings.edgeProtection / 100f).coerceIn(0f, 1f)) + (settings.edgeProtection / 100f).coerceIn(0f, 1f) * edgeKeep
            if (settings.forceJitter != 0f) {
                wt *= (1f + pointNoise * settings.forceJitter / 100f)
            }
            if (settings.centerLock && distance < radius * 0.08f) wt = 0f
            if (pinR > 0f) {
                val uPin = (hypot(vx - pivotX, vy - pivotY) / pinR).coerceAtMost(1f)
                wt *= uPin * uPin * (3f - 2f * uPin)
            }
            out[n++] = wt
        }
        return out
    }

    /** ระยะลากรวมสูงสุดต่อ 1 สโตรกที่ยังไม่ทำให้ตาข่ายพับ (ประมาณจากความชันสูงสุดของน้ำหนัก) */
    fun maxStep(radius: Float, pinR: Float): Float {
        val slope = 1.5f / radius + (if (pinR > 0f) 1.5f / pinR else 0f)
        return SAFETY / slope
    }

    /**
     * ดึงตาข่าย: start = ตาข่ายตอนวางนิ้ว, (dx,dy) = ระยะที่นิ้วลากรวมตั้งแต่วางนิ้ว (พิกเซล bitmap)
     * คำนวณจาก start ทุกครั้ง (ไม่สะสมทีละเฟรม) จึงไม่ลอยเพี้ยนและ 1 สโตรก = 1 ก้าว undo
     */
    fun applyGrab(
        start: SculptGrid, wts: FloatArray, dx: Float, dy: Float, maxStep: Float,
        lockedIndices: Set<Int> = emptySet(), settings: WarpSettings = WarpSettings(),
        width: Int = 0, height: Int = 0, radius: Float = 0f,
    ): SculptGrid {
        val inverse = if (settings.invert) -1f else 1f
        val pressure = (settings.pressure / 100f).coerceIn(0f, 1f).pow(settings.pressureCurve.coerceIn(0.25f, 3f))
        val startEnd = settings.startForce / 100f + (settings.endForce - settings.startForce) / 100f * (hypot(dx, dy) / radius.coerceAtLeast(1f)).coerceIn(0f, 1f)
        val distanceFactor = 1f + (hypot(dx, dy) / radius.coerceAtLeast(1f)) * settings.distanceResponse / 100f
        val brushGain = (settings.strength / 100f) * pressure * startEnd * distanceFactor *
            (settings.flow / 100f).coerceIn(0f, 1f) * (settings.density / 100f).coerceIn(0f, 1f) *
            (settings.opacity / 100f).coerceIn(0f, 1f)
        val activation = (hypot(dx, dy) / radius.coerceAtLeast(1f)).coerceIn(0f, 1f)
        val accumulation = if (settings.accumulate) 1f + activation * 0.75f else 1f
        var moveX = dx * inverse * brushGain * accumulation
        var moveY = dy * inverse * brushGain * accumulation
        if (settings.lockHorizontal) moveX = 0f
        if (settings.lockVertical) moveY = 0f
        // Honor the user's deformation value without applying an automatic stroke ceiling.
        val maxAllowed = if (radius > 0f) radius * (if (settings.maxDeformation.isFinite()) settings.maxDeformation / 100f else Float.MAX_VALUE) else Float.MAX_VALUE
        val m = hypot(moveX, moveY)
        val scale = if (m > maxAllowed && m > 0f) maxAllowed / m else 1f
        val out = start.off.copyOf()
        val stride = start.cols + 1
        var n = 0
        for (j in 0..start.rows) for (i in 0..start.cols) {
            if (n in lockedIndices) { n++; continue }
            val mirror = j * stride + (start.cols - i)
            val directWeight = wts.getOrElse(n) { 0f }
            val mirrorWeight = if (settings.symmetry) wts.getOrElse(mirror) { 0f } else 0f
            val deltaX = (directWeight * moveX - mirrorWeight * moveX) * scale
            val deltaY = (directWeight * moveY + mirrorWeight * moveY) * scale
            val oldX = start.restX(i, width.coerceAtLeast(1)) + out[2 * n]
            val oldY = start.restY(j, height.coerceAtLeast(1)) + out[2 * n + 1]
            var nextX = oldX + deltaX
            var nextY = oldY + deltaY
            if (settings.boundaryClamp && width > 0 && height > 0) {
                nextX = nextX.coerceIn(0f, width.toFloat())
                nextY = nextY.coerceIn(0f, height.toFloat())
            }
            out[2 * n] += nextX - oldX
            out[2 * n + 1] += nextY - oldY
            n++
        }
        return start.withOff(out)
    }

    /** คลายความตึงของตาข่ายด้วยค่าเฉลี่ยเพื่อนบ้าน; ไม่เปลี่ยนขอบและจุดที่ล็อก */
    fun smoothGrid(
        grid: SculptGrid, amount: Float, lockedIndices: Set<Int> = emptySet(),
        lockHorizontal: Boolean = false, lockVertical: Boolean = false,
    ): SculptGrid {
        val a = (amount / 100f).coerceIn(0f, 1f)
        if (a <= 0f || grid.cols < 2 || grid.rows < 2) return grid
        val out = grid.off.copyOf()
        val stride = grid.cols + 1
        for (j in 1 until grid.rows) for (i in 1 until grid.cols) {
            val n = j * stride + i
            if (n in lockedIndices) continue
            val left = n - 1; val right = n + 1; val up = n - stride; val down = n + stride
            for (axis in 0..1) {
                val average = (grid.off[2 * left + axis] + grid.off[2 * right + axis] +
                    grid.off[2 * up + axis] + grid.off[2 * down + axis]) * 0.25f
                val lockedAxis = (axis == 0 && lockHorizontal) || (axis == 1 && lockVertical)
                out[2 * n + axis] = if (lockedAxis) grid.off[2 * n + axis]
                else grid.off[2 * n + axis] + (average - grid.off[2 * n + axis]) * a * 0.45f
            }
        }
        return grid.withOff(out)
    }

    /** รีเซ็ตออฟเซ็ตจุดตาข่ายหนึ่งจุด โดยคง Layout และมุมหมุดเดิม */
    fun resetVertex(grid: SculptGrid, index: Int): SculptGrid {
        if (index !in 0..(grid.cols + 1) * (grid.rows + 1) - 1) return grid
        val out = grid.off.copyOf()
        out[2 * index] = 0f
        out[2 * index + 1] = 0f
        return grid.withOff(out)
    }

    /** ค่ากลางระหว่างสองท่า (null = ไม่ปั้น = ออฟเซ็ตศูนย์) มุมงอของหมุดข้อต่อก็ผสมเป็นเส้นตรงเช่นกัน (ตาข่ายสร้างใหม่จากมุมทุกเฟรม แขนจึงไม่หดระหว่างท่า) */
    fun lerp(a: SculptGrid?, b: SculptGrid?, t: Float): SculptGrid? {
        if (a == null && b == null) return null
        if (a != null && b != null && !a.sameLayout(b)) return if (t < 0.5f) a else b
        val ref = (a ?: b)!!
        val ao = a?.off
        val bo = b?.off
        val na = maxOf(a?.pinAngles?.size ?: 0, b?.pinAngles?.size ?: 0)
        val angles = if (na == 0) null else FloatArray(na) { k ->
            val x = a?.angleOf(k) ?: 0f
            val y = b?.angleOf(k) ?: 0f
            x + (y - x) * t
        }
        return SculptGrid(ref.cols, ref.rows, FloatArray(ref.off.size) { i ->
            val x = if (ao != null) ao[i] else 0f
            val y = if (bo != null) bo[i] else 0f
            x + (y - x) * t
        }, ref.xs, ref.ys, angles)
    }

    // ───────────── ขนาดช่องตาข่ายที่ตั้งเองได้ / Mesh Warp / Twist ─────────────

    /** ช่วงขนาดช่องตาข่าย (พิกเซลของ bitmap) ที่ให้ผู้ใช้ตั้งได้ */
    const val CELL_MIN = 16f
    const val CELL_MAX = Float.MAX_VALUE

    /** ขอบเขตจำนวนช่องจริงต่อด้านเพื่อป้องกันการใช้หน่วยความจำเกิน; ช่องกรอกไม่ตัดจำนวนหลัก */
    private const val GRID_MAX = 64

    /** จำนวนช่องตามขนาดช่องที่ผู้ใช้ตั้ง (พิกเซลของ bitmap); cell = null = อัตโนมัติ ใช้ค่าเดิมของแอป (gridDims สองพารามิเตอร์) */
    fun gridDims(w: Int, h: Int, cell: Float?): Pair<Int, Int> = gridDims(w, h, cell, 0, 0)

    /** จำนวนช่อง X/Y ที่กำหนดเอง; 0 หมายถึงคำนวณจากขนาดช่อง */
    fun gridDims(w: Int, h: Int, cell: Float?, colsOverride: Int, rowsOverride: Int): Pair<Int, Int> {
        val c = (cell ?: CELL).coerceIn(CELL_MIN, CELL_MAX)
        val autoCols = if (cell == null) gridDims(w, h).first else ceil(w / c).toInt().coerceIn(4, GRID_MAX)
        val autoRows = if (cell == null) gridDims(w, h).second else ceil(h / c).toInt().coerceIn(4, GRID_MAX)
        return Pair(
            if (colsOverride > 0) colsOverride.coerceIn(4, GRID_MAX) else autoCols,
            if (rowsOverride > 0) rowsOverride.coerceIn(4, GRID_MAX) else autoRows,
        )
    }

    /** ตำแหน่งเศษส่วนของ u (0..1) บนแนวเส้นตาข่าย: จำนวนเต็ม = ตรงเส้น (breaks = null → เว้นระยะเท่ากัน) */
    private fun fracIndex(breaks: FloatArray?, n: Int, u: Float): Float {
        if (breaks == null) return u * n
        var k = 0
        while (k < n - 1 && breaks[k + 1] < u) k++
        val span = breaks[k + 1] - breaks[k]
        return k + if (span > 1e-6f) ((u - breaks[k]) / span).coerceIn(0f, 1f) else 0f
    }

    private fun sameBreaks(a: FloatArray?, b: FloatArray?): Boolean = if (a == null) b == null else b != null && a.contentEquals(b)

    /**
     * แปลงตารางเป็นจำนวนช่อง/รูปแบบเส้นตาข่ายใหม่ (สุ่มค่าออฟเซ็ตแบบ bilinear ตามตำแหน่งตั้งต้นของแต่ละจุด) ใช้ตอนเปลี่ยนความละเอียดตาข่าย
     * หรือย้ายหมุดข้อต่อ (ตาข่ายถี่ตามจุดเปลี่ยนที่) xs / ys ใหม่ = null → เว้นระยะเท่ากัน
     * เป็นการประมาณ: รายละเอียดที่ละเอียดกว่าตารางเดิมไม่กลับมา และตารางที่ถี่ลงจะไม่ทำให้ท่าเดิมเปลี่ยนรูป · มุมงอของหมุดคงเดิม
     */
    fun resample(g: SculptGrid, cols: Int, rows: Int, xs: FloatArray? = null, ys: FloatArray? = null): SculptGrid {
        if (g.cols == cols && g.rows == rows && sameBreaks(g.xs, xs) && sameBreaks(g.ys, ys)) return g
        val out = FloatArray((cols + 1) * (rows + 1) * 2)
        val ow = g.cols + 1
        var n = 0
        for (j in 0..rows) for (i in 0..cols) {
            val fx = fracIndex(g.xs, g.cols, xs?.get(i) ?: (i.toFloat() / cols))
            val fy = fracIndex(g.ys, g.rows, ys?.get(j) ?: (j.toFloat() / rows))
            val x0 = fx.toInt().coerceIn(0, g.cols - 1)
            val y0 = fy.toInt().coerceIn(0, g.rows - 1)
            val tx = fx - x0
            val ty = fy - y0
            for (k in 0..1) {
                val a = g.off[2 * (y0 * ow + x0) + k]
                val b = g.off[2 * (y0 * ow + x0 + 1) + k]
                val c = g.off[2 * ((y0 + 1) * ow + x0) + k]
                val d = g.off[2 * ((y0 + 1) * ow + x0 + 1) + k]
                out[2 * n + k] = (a * (1f - tx) + b * tx) * (1f - ty) + (c * (1f - tx) + d * tx) * ty
            }
            n++
        }
        return SculptGrid(cols, rows, out, xs, ys, g.pinAngles)
    }

    /**
     * ตารางใหม่ (lat: ตาข่ายเว้นระยะเท่ากันวางทับกรอบภาพ ออฟเซ็ต = ระยะที่ถูกดึง) ซ้อนบนท่าที่เห็นอยู่ตอนเริ่ม (e0)
     * จุดของ e0 แต่ละจุดถูกย้ายตามสนามระยะของ lat (interpolate แบบ bilinear ที่ตำแหน่งของจุดนั้น; นอกกรอบใช้ค่าขอบ)
     * คืนตาข่ายรูปแบบเดียวกับ e0 (ออฟเซ็ตตำแหน่งที่เห็น ไม่มีมุมหมุด) · lat ศูนย์ = e0 เดิม
     */
    fun compose(e0: SculptGrid, lat: SculptGrid, w: Int, h: Int): SculptGrid {
        val out = FloatArray(e0.off.size)
        val lw = lat.cols + 1
        var n = 0
        for (j in 0..e0.rows) for (i in 0..e0.cols) {
            val px = e0.restX(i, w) + e0.off[2 * n]
            val py = e0.restY(j, h) + e0.off[2 * n + 1]
            val fx = (px / w * lat.cols).coerceIn(0f, lat.cols.toFloat())
            val fy = (py / h * lat.rows).coerceIn(0f, lat.rows.toFloat())
            val x0 = fx.toInt().coerceIn(0, lat.cols - 1)
            val y0 = fy.toInt().coerceIn(0, lat.rows - 1)
            val tx = fx - x0
            val ty = fy - y0
            for (k in 0..1) {
                val a = lat.off[2 * (y0 * lw + x0) + k]
                val b = lat.off[2 * (y0 * lw + x0 + 1) + k]
                val c = lat.off[2 * ((y0 + 1) * lw + x0) + k]
                val d = lat.off[2 * ((y0 + 1) * lw + x0 + 1) + k]
                out[2 * n + k] = e0.off[2 * n + k] + (a * (1f - tx) + b * tx) * (1f - ty) + (c * (1f - tx) + d * tx) * ty
            }
            n++
        }
        return SculptGrid(e0.cols, e0.rows, out, e0.xs, e0.ys)
    }

    /** จำกัดระยะลากของจุดบิดต่อหนึ่งสโตรกไม่เกินครึ่งรัศมี (กันตาข่ายพับ) */
    fun capMove(ax: Float, ay: Float, radius: Float): Pair<Float, Float> {
        val m = hypot(ax, ay)
        val cap = 0.5f * maxOf(radius, 1f)
        return if (m > cap && m > 0f) Pair(ax * cap / m, ay * cap / m) else Pair(ax, ay)
    }

    /**
     * ห่วงบิด (วงกลม): ภาพในวงกลมศูนย์กลาง (cx, cy) รัศมี r ขยับตาม (ax, ay) แรงสูงสุดที่ศูนย์กลาง ลดลงนุ่ม ๆ จนเป็นศูนย์ที่ขอบวง
     * น้ำหนัก = (1 − (ระยะ/r)²)² : ต่อเนื่องที่ขอบ ไม่มีรอยหัก · คืนตาข่ายใหม่จาก st
     */
    fun applyRing(bw: Int, bh: Int, st: SculptGrid, cx: Float, cy: Float, r: Float, ax: Float, ay: Float): SculptGrid {
        val rr2 = maxOf(r, 1f) * maxOf(r, 1f)
        val out = st.off.copyOf()
        var n = 0
        for (j in 0..st.rows) for (i in 0..st.cols) {
            val dx = st.restX(i, bw) + st.off[2 * n] - cx
            val dy = st.restY(j, bh) + st.off[2 * n + 1] - cy
            val t2 = (dx * dx + dy * dy) / rr2
            if (t2 < 1f) {
                val w = (1f - t2) * (1f - t2)
                out[2 * n] += ax * w
                out[2 * n + 1] += ay * w
            }
            n++
        }
        return SculptGrid(st.cols, st.rows, out, st.xs, st.ys, st.pinAngles)
    }

    /** น้ำหนักของห่วง (cx, cy, r) ที่จุด (x, y): 1 ที่ศูนย์กลาง → 0 ที่ขอบวง/นอกวง (สูตรเดียวกับ applyRing) */
    fun ringWeight(cx: Float, cy: Float, r: Float, x: Float, y: Float): Float {
        val rr = maxOf(r, 1f)
        val t2 = ((x - cx) * (x - cx) + (y - cy) * (y - cy)) / (rr * rr)
        return if (t2 < 1f) (1f - t2) * (1f - t2) else 0f
    }

    /**
     * ย้อนกลับของ samplePos: จุดบนจอ (vx, vy) มาจากจุดไหนของภาพตั้งต้น — หาช่องตาข่ายที่ครอบจุดนั้น แล้วแก้สมการ bilinear (Newton)
     * ใช้วางหมุดตอนภาพงอ/ปั้นอยู่ · ถ้าไม่เจอช่อง (จุดอยู่นอกภาพ) ใช้วนซ้ำแก้ทีละน้อยแทน
     */
    fun restPoint(g: SculptGrid, bw: Int, bh: Int, vx: Float, vy: Float): Pair<Float, Float> {
        val lw = g.cols + 1
        for (j in 0 until g.rows) for (i in 0 until g.cols) {
            val a = j * lw + i
            val c = a + lw
            val x00 = g.restX(i, bw) + g.off[2 * a]
            val y00 = g.restY(j, bh) + g.off[2 * a + 1]
            val x10 = g.restX(i + 1, bw) + g.off[2 * (a + 1)]
            val y10 = g.restY(j, bh) + g.off[2 * (a + 1) + 1]
            val x01 = g.restX(i, bw) + g.off[2 * c]
            val y01 = g.restY(j + 1, bh) + g.off[2 * c + 1]
            val x11 = g.restX(i + 1, bw) + g.off[2 * (c + 1)]
            val y11 = g.restY(j + 1, bh) + g.off[2 * (c + 1) + 1]
            if (vx < minOf(minOf(x00, x10), minOf(x01, x11)) - 0.5f || vx > maxOf(maxOf(x00, x10), maxOf(x01, x11)) + 0.5f) continue
            if (vy < minOf(minOf(y00, y10), minOf(y01, y11)) - 0.5f || vy > maxOf(maxOf(y00, y10), maxOf(y01, y11)) + 0.5f) continue
            var u = 0.5f
            var v = 0.5f
            for (it in 0 until 8) {
                val fx = (1f - u) * (1f - v) * x00 + u * (1f - v) * x10 + (1f - u) * v * x01 + u * v * x11 - vx
                val fy = (1f - u) * (1f - v) * y00 + u * (1f - v) * y10 + (1f - u) * v * y01 + u * v * y11 - vy
                val dxu = (1f - v) * (x10 - x00) + v * (x11 - x01)
                val dxv = (1f - u) * (x01 - x00) + u * (x11 - x10)
                val dyu = (1f - v) * (y10 - y00) + v * (y11 - y01)
                val dyv = (1f - u) * (y01 - y00) + u * (y11 - y10)
                val det = dxu * dyv - dxv * dyu
                if (abs(det) < 1e-6f) break
                u = (u - (fx * dyv - fy * dxv) / det).coerceIn(-0.5f, 1.5f)
                v = (v - (dxu * fy - dyu * fx) / det).coerceIn(-0.5f, 1.5f)
            }
            if (u >= -0.002f && u <= 1.002f && v >= -0.002f && v <= 1.002f) {
                val uu = u.coerceIn(0f, 1f)
                val vv = v.coerceIn(0f, 1f)
                return Pair((1f - uu) * g.restX(i, bw) + uu * g.restX(i + 1, bw), (1f - vv) * g.restY(j, bh) + vv * g.restY(j + 1, bh))
            }
        }
        var rx = vx.coerceIn(0f, bw.toFloat())
        var ry = vy.coerceIn(0f, bh.toFloat())
        repeat(25) {
            val (px, py) = samplePos(g, bw, bh, rx, ry)
            rx = (rx - 0.6f * (px - vx)).coerceIn(0f, bw.toFloat())
            ry = (ry - 0.6f * (py - vy)).coerceIn(0f, bh.toFloat())
        }
        return Pair(rx, ry)
    }

    /** ตำแหน่งที่เห็นของจุด (x, y) ของภาพตั้งต้น บนตาข่าย g (interpolate bilinear ในช่องที่จุดนั้นอยู่) */
    fun samplePos(g: SculptGrid, bw: Int, bh: Int, x: Float, y: Float): Pair<Float, Float> {
        var i = 0
        while (i < g.cols - 1 && g.restX(i + 1, bw) <= x) i++
        var j = 0
        while (j < g.rows - 1 && g.restY(j + 1, bh) <= y) j++
        val x0 = g.restX(i, bw)
        val x1 = g.restX(i + 1, bw)
        val y0 = g.restY(j, bh)
        val y1 = g.restY(j + 1, bh)
        val tx = if (x1 > x0) ((x - x0) / (x1 - x0)).coerceIn(0f, 1f) else 0f
        val ty = if (y1 > y0) ((y - y0) / (y1 - y0)).coerceIn(0f, 1f) else 0f
        val lw = g.cols + 1
        fun px(ii: Int, jj: Int) = g.restX(ii, bw) + g.off[2 * (jj * lw + ii)]
        fun py(ii: Int, jj: Int) = g.restY(jj, bh) + g.off[2 * (jj * lw + ii) + 1]
        val ax = px(i, j) * (1f - tx) + px(i + 1, j) * tx
        val bx = px(i, j + 1) * (1f - tx) + px(i + 1, j + 1) * tx
        val ay = py(i, j) * (1f - tx) + py(i + 1, j) * tx
        val by = py(i, j + 1) * (1f - tx) + py(i + 1, j + 1) * tx
        return Pair(ax * (1f - ty) + bx * ty, ay * (1f - ty) + by * ty)
    }

    /** สองท่าเหมือนกันไหม (ตาข่ายรูปแบบเดียวกัน ออฟเซ็ตและมุมหมุดต่างกันไม่เกิน tol) — null เทียบกับ null เท่านั้น; ใช้เช็คว่าท่าบนจอยังเป็นท่าที่เพิ่งบิดเองอยู่ */
    fun approxEquals(a: SculptGrid?, b: SculptGrid?, tol: Float = 0.01f): Boolean {
        if (a == null || b == null) return a == null && b == null
        if (!a.sameLayout(b)) return false
        for (i in a.off.indices) if (abs(a.off[i] - b.off[i]) > tol) return false
        val n = maxOf(a.pinAngles?.size ?: 0, b.pinAngles?.size ?: 0)
        for (k in 0 until n) if (abs(a.angleOf(k) - b.angleOf(k)) > tol) return false
        return true
    }

    /** ช่องตาข่ายที่ใหญ่ที่สุด (พิกเซล bitmap) ตารางเว้นระยะเท่ากัน = max(w/cols, h/rows) เหมือนเดิม */
    fun cellMaxPx(w: Int, h: Int, g: SculptGrid): Float {
        var m = 0f
        for (i in 0 until g.cols) m = maxOf(m, g.restX(i + 1, w) - g.restX(i, w))
        for (j in 0 until g.rows) m = maxOf(m, g.restY(j + 1, h) - g.restY(j, h))
        return m
    }

    /** ช่องตาข่ายที่เล็กที่สุด (พิกเซล bitmap) ใช้คิดขีดจำกัดความปลอดภัยของ Mesh Warp บนตาข่ายถี่ตามจุด */
    fun cellMinPx(w: Int, h: Int, g: SculptGrid): Float {
        var m = Float.MAX_VALUE
        for (i in 0 until g.cols) m = minOf(m, g.restX(i + 1, w) - g.restX(i, w))
        for (j in 0 until g.rows) m = minOf(m, g.restY(j + 1, h) - g.restY(j, h))
        return m
    }

    /** จำนวนช่องที่ตาข่ายพับ (มุมใดมุมหนึ่งของช่องกลับด้าน) ตอนนี้ ใช้เตือนผู้ใช้เมื่อหมุดงอเกินที่ตาข่ายรับได้ */
    fun foldCount(w: Int, h: Int, g: SculptGrid): Int {
        val v = verts(w, h, g)
        val rw = g.cols + 1
        var bad = 0
        for (j in 0 until g.rows) for (i in 0 until g.cols) {
            val a = j * rw + i
            val b = a + 1
            val d = a + rw
            val c = d + 1
            // มุมซ้ายบน/ขวาบน/ขวาล่าง/ซ้ายล่าง: ทุกมุมต้องวนทิศเดียวกับตอนไม่บิด (cross > 0 ในพิกัดที่ y ชี้ลง)
            fun cr(p: Int, q: Int, r: Int): Float =
                (v[2 * q] - v[2 * p]) * (v[2 * r + 1] - v[2 * p + 1]) - (v[2 * q + 1] - v[2 * p + 1]) * (v[2 * r] - v[2 * p])
            if (cr(a, b, d) <= 0f || cr(b, c, a) <= 0f || cr(c, d, b) <= 0f || cr(d, a, c) <= 0f) bad++
        }
        return bad
    }

    /** จุดตาข่ายที่ถูกเลือกโดย Mesh Warp: ตำแหน่งในตาราง (i, j) และระยะจากนิ้ว (พิกเซล bitmap) */
    class VertexHit(val i: Int, val j: Int, val dist: Float)

    /** จุดตาข่ายที่ใกล้ (px, py) ที่สุด (พิกัด bitmap ใช้ตำแหน่งของจุดที่บิดแล้ว ตรงกับที่เห็นบนจอ) */
    fun nearestVertex(w: Int, h: Int, g: SculptGrid, px: Float, py: Float): VertexHit {
        var bi = 0
        var bj = 0
        var bd = Float.MAX_VALUE
        var n = 0
        for (j in 0..g.rows) for (i in 0..g.cols) {
            val vx = g.restX(i, w) + g.off[2 * n]
            val vy = g.restY(j, h) + g.off[2 * n + 1]
            val d = hypot(vx - px, vy - py)
            if (d < bd) { bd = d; bi = i; bj = j }
            n++
        }
        return VertexHit(bi, bj, bd)
    }

    /** น้ำหนักแบบ Mesh Warp: จุด (vi, vj) = 1 แล้วลดลงตามระยะ (นับเป็นช่อง) จนเป็น 0 ที่ระยะ rings+1 ช่อง; rings = 0 ขยับจุดเดียว */
    fun ringWeights(g: SculptGrid, vi: Int, vj: Int, rings: Int, settings: WarpSettings = WarpSettings()): FloatArray {
        val out = FloatArray((g.cols + 1) * (g.rows + 1))
        val rawSx = settings.scaleX / 100f
        val rawSy = settings.scaleY / 100f
        val sx = if (abs(rawSx) < 0.000001f) if (rawSx < 0f) -0.000001f else 0.000001f else rawSx
        val sy = if (abs(rawSy) < 0.000001f) if (rawSy < 0f) -0.000001f else 0.000001f else rawSy
        val hard = (settings.hardness / 100f).coerceIn(0f, 0.95f)
        val fall = (settings.falloff / 100f).coerceIn(0f, 1f)
        val smooth = (settings.smoothness / 100f).coerceIn(0f, 1f)
        val angle = Math.toRadians(settings.angleDeg.toDouble()).toFloat()
        val cs = cos(angle); val sn = sin(angle)
        var n = 0
        for (j in 0..g.rows) for (i in 0..g.cols) {
            val rawX = (i - vi).toFloat(); val rawY = (j - vj).toFloat()
            val dx = (rawX * cs + rawY * sn) / sx
            val dy = (-rawX * sn + rawY * cs) / sy
            val u = (hypot(dx, dy) / (rings.coerceAtLeast(0).toFloat() + 1f)).coerceIn(0f, 1f)
            val t = ((1f - u) / (1f - hard)).coerceIn(0f, 1f)
            val shaped = t.pow(0.35f + fall * 2.65f)
            val eased = t * t * (3f - 2f * t)
            out[n++] = shaped * (1f - smooth) + eased * smooth
        }
        return out
    }

    /**
     * ระยะลากรวมสูงสุดต่อ 1 สโตรกของ Mesh Warp ที่ตาข่ายยังไม่พับ
     * ทดสอบด้วยสคริปต์จำลอง: ระยะปลอดภัยเพิ่มตามจำนวนวงอิทธิพลและขนาดช่อง; ใช้ตัวคูณ 0.4 เผื่อไว้
     */
    fun maxStepRings(cellMin: Float, rings: Int): Float = 0.4f * (rings.coerceAtLeast(0).toFloat() + 1f) * cellMin

    /**
     * มุมบิด Twist สูงสุด (เรเดียน) ที่ตาข่ายยังไม่พับ ตามรัศมีและขนาดช่องใหญ่สุด
     * ทดสอบด้วยสคริปต์จำลอง (รัศมี/ช่อง = 2–48) มุมที่ไม่พับจริงมากกว่าค่านี้ทุกกรณี: ยิ่งรัศมีใหญ่/ช่องถี่ ยิ่งบิดได้มาก
     */
    fun maxTwist(radius: Float, cellMax: Float): Float {
        val rc = (radius / cellMax).coerceAtLeast(1f)
        return rc.pow(0.37f)
    }

    /**
     * Twist: หมุนจุดตาข่ายรอบ (cx, cy) ด้วยมุม angle (เรเดียน, บวก = ตามเข็มบนจอ) ที่กลางพู่กัน ลดเป็น 0 ที่ขอบรัศมี
     * คำนวณจาก start ทุกครั้ง (ไม่สะสม) เหมือน applyGrab
     */
    fun applyTwist(w: Int, h: Int, start: SculptGrid, cx: Float, cy: Float, radius: Float, angle: Float, settings: WarpSettings = WarpSettings()): SculptGrid {
        val o = start.off.copyOf()
        val brushAngle = Math.toRadians(settings.angleDeg.toDouble()).toFloat()
        val bc = cos(brushAngle); val bs = sin(brushAngle)
        val sx = (settings.scaleX / 100f).let { if (abs(it) < 0.000001f) 0.000001f else it }
        val sy = (settings.scaleY / 100f).let { if (abs(it) < 0.000001f) 0.000001f else it }
        var n = 0
        for (j in 0..start.rows) for (i in 0..start.cols) {
            val vx = start.restX(i, w) + start.off[2 * n]
            val vy = start.restY(j, h) + start.off[2 * n + 1]
            val dx = vx - cx
            val dy = vy - cy
            val lx = (dx * bc + dy * bs) / sx
            val ly = (-dx * bs + dy * bc) / sy
            val shapeDistance = brushDistance(lx, ly, settings.brushShape)
            val k = 1f - (shapeDistance / radius).coerceAtMost(1f)
            val a = angle * (k * k * (3f - 2f * k))
            if (a != 0f) {
                val c = cos(a)
                val s = sin(a)
                o[2 * n] += cx + dx * c - dy * s - vx
                o[2 * n + 1] += cy + dx * s + dy * c - vy
            }
            n++
        }
        return start.withOff(o)
    }


    /**
     * Advanced Warp: คำนวณจากตารางตอนเริ่มลากทุกครั้ง เพื่อไม่ให้ผลลัพธ์สะสมตามจำนวนเฟรม pointer
     * amountX/amountY คือระยะลากสะสมในพิกัด bitmap; ป้องกันตาข่ายพับด้วยการลดผลแบบ binary search
     */
    fun applyAdvancedWarp(
        w: Int, h: Int, start: SculptGrid, cx: Float, cy: Float, radius: Float,
        mode: AdvancedWarpMode, amountX: Float, amountY: Float, settings: WarpSettings,
        lockedIndices: Set<Int> = emptySet(),
    ): SculptGrid {
        // ช่องกรอกไม่กำหนดเพดาน; จำกัดเฉพาะค่าที่ส่งเข้าคณิตศาสตร์เพื่อป้องกัน Float ล้น/NaN
        val r = (if (radius.isFinite()) radius else 1f).coerceIn(1f, maxOf(w, h).coerceAtLeast(1) * 8f)
        val rawSx = settings.scaleX / 100f
        val rawSy = settings.scaleY / 100f
        val sx = if (abs(rawSx) < 0.000001f) if (rawSx < 0f) -0.000001f else 0.000001f else rawSx
        val sy = if (abs(rawSy) < 0.000001f) if (rawSy < 0f) -0.000001f else 0.000001f else rawSy
        val sign = if (settings.invert) -1f else 1f
        val dragX = amountX * sign
        val dragY = amountY * sign
        val dragActivation = (hypot(dragX, dragY) / r).coerceIn(0f, 1f)
        val pressure = (settings.pressure / 100f).coerceIn(0f, 1f).pow(settings.pressureCurve.coerceIn(0.25f, 3f))
        val brushGain = pressure * (settings.flow / 100f).coerceIn(0f, 1f) * (settings.density / 100f).coerceIn(0f, 1f) *
            (settings.opacity / 100f).coerceIn(0f, 1f)
        val accumulation = if (settings.accumulate) 1f + dragActivation * 0.75f else 1f
        val rawStrength = if (settings.strength.isFinite()) settings.strength else 100f
        val forceRamp = settings.startForce / 100f + (settings.endForce - settings.startForce) / 100f * dragActivation
        val distanceGain = 1f + dragActivation * settings.distanceResponse / 100f
        val strength = (rawStrength / 100f) * brushGain * accumulation * forceRamp * distanceGain
        val phase = Math.toRadians((if (settings.phaseDeg.isFinite()) settings.phaseDeg % 360f else 0f).toDouble()).toFloat()
        val dir = Math.toRadians((if (settings.angleDeg.isFinite()) settings.angleDeg % 360f else 0f).toDouble()).toFloat()
        val dirX = cos(dir); val dirY = sin(dir)
        val normalX = -dirY; val normalY = dirX
        val wavelength = settings.wavelengthPx.coerceAtLeast(2f)
        val amp = r * strength * dragActivation
        val hard = (settings.hardness / 100f).coerceIn(0f, 0.95f)
        val fall = (settings.falloff / 100f).coerceIn(0f, 1f)
        val smooth = (settings.smoothness / 100f).coerceIn(0f, 1f)
        val maxDelta = r * (if (settings.maxDeformation.isFinite()) settings.maxDeformation / 100f else Float.MAX_VALUE)
        val edgeProtect = (settings.edgeProtection / 100f).coerceIn(0f, 1f)
        val safetyEnabled = settings.preventFolding || settings.preventSelfIntersection || settings.minPointDistance > 0f
        val baseFolds = if (safetyEnabled) foldCount(w, h, start) else 0
        val out = start.off.copyOf()

        fun waveValue(value: Float): Float {
            val phaseValue = value + phase
            return when (settings.waveType) {
                "Triangle" -> (2f / Math.PI.toFloat()) * kotlin.math.asin(sin(phaseValue))
                "Square" -> if (sin(phaseValue) >= 0f) 1f else -1f
                else -> sin(phaseValue)
            }
        }

        fun weightAt(dx: Float, dy: Float, centerX: Float, centerY: Float, noise: Float): Float {
            // หมุนวงพู่กันก่อนคิดรัศมี เพื่อให้ Scale X/Y ใช้ร่วมกับ Angle ได้
            val jitter = Math.toRadians(noise * settings.angleJitter.toDouble()).toFloat()
            val a = dir + jitter
            val c = cos(a); val sn = sin(a)
            val localX = dx * c + dy * sn
            val localY = -dx * sn + dy * c
            val sizeFactorRaw = 1f + noise * settings.sizeJitter / 100f
            val sizeFactor = if (abs(sizeFactorRaw) < 0.000001f) 0.000001f else sizeFactorRaw
            val nx = localX / (sx * sizeFactor)
            val ny = localY / (sy * sizeFactor)
            val distance = brushDistance(nx, ny, settings.brushShape)
            val u = (distance / r).coerceIn(0f, 1f)
            if (u >= 1f) return 0f
            val t = ((1f - u) / (1f - hard)).coerceIn(0f, 1f)
            val shaped = t.pow(0.35f + fall * 2.65f)
            val smoothed = t * t * (3f - 2f * t)
            var weight = (shaped * (1f - smooth) + smoothed * smooth) * (1f + noise * settings.forceJitter / 100f)
            if (settings.preserveBoundary) {
                val edge = minOf(dx + centerX, w - (centerX + dx), dy + centerY, h - (centerY + dy)).coerceAtLeast(0f)
                weight *= (edge / (r * 0.35f)).coerceIn(0f, 1f)
            }
            if (edgeProtect > 0f) {
                val edge = minOf(centerX + dx, w - (centerX + dx), centerY + dy, h - (centerY + dy)).coerceAtLeast(0f)
                val keep = (edge / (r * 0.5f)).coerceIn(0f, 1f)
                weight *= (1f - edgeProtect) + edgeProtect * keep
            }
            if (settings.centerLock && distance < r * 0.08f) weight = 0f
            return weight
        }

        fun deltaAt(vx: Float, vy: Float, centerX: Float, centerY: Float, mirror: Boolean, noise: Float): Pair<Float, Float> {
            val dx = vx - centerX
            val dy = vy - centerY
            val weight = weightAt(dx, dy, centerX, centerY, noise)
            if (weight <= 0f) return 0f to 0f
            val nx = dx / (r * sx)
            val ny = dy / (r * sy)
            var ddx = 0f
            var ddy = 0f
            val localX = dx * dirX + dy * dirY
            val localY = -dx * dirY + dy * dirX
            val dragForward = dragX * dirX + dragY * dirY
            val dragNormal = -dragX * dirY + dragY * dirX
            when (mode) {
                AdvancedWarpMode.INFLATE, AdvancedWarpMode.BULGE, AdvancedWarpMode.DEFLATE,
                AdvancedWarpMode.PINCH, AdvancedWarpMode.MAGNET, AdvancedWarpMode.ELASTIC, AdvancedWarpMode.CREASE -> {
                    val polarity = when (mode) {
                        AdvancedWarpMode.DEFLATE, AdvancedWarpMode.PINCH, AdvancedWarpMode.MAGNET, AdvancedWarpMode.CREASE -> -1f
                        else -> 1f
                    } * sign
                    val distance = hypot(dx, dy).coerceAtLeast(0.001f)
                    val profile = when (mode) {
                        AdvancedWarpMode.ELASTIC -> (1f + 0.25f * sin(distance / r * Math.PI.toFloat() * 2f))
                        AdvancedWarpMode.CREASE -> weight * weight
                        else -> 1f
                    }
                    val move = amp * weight * polarity * profile
                    ddx = dx / distance * move
                    ddy = dy / distance * move
                }
                AdvancedWarpMode.FLATTEN -> {
                    val nx = -dirY; val ny = dirX
                    val distanceToPlane = dx * nx + dy * ny
                    ddx = -nx * distanceToPlane * strength * weight
                    ddy = -ny * distanceToPlane * strength * weight
                }
                AdvancedWarpMode.GRAVITY -> {
                    val gravity = Math.toRadians(settings.angleDeg.toDouble()).toFloat()
                    val magnitude = amp * weight * sign
                    ddx = cos(gravity) * magnitude
                    ddy = sin(gravity) * magnitude
                }
                AdvancedWarpMode.SMOOTH -> { /* ใช้ตัวกรอง smoothGrid หลังสร้างผล */ }
                AdvancedWarpMode.SPIRAL -> {
                    val dragProjection = amountX * dirX + amountY * dirY
                    val dragSign = if (dragProjection < 0f) -1f else 1f
                    val spin = dir * dragActivation * strength.coerceAtMost(1f) * weight * dragSign * sign
                    val cs = cos(spin); val sn = sin(spin)
                    ddx = dx * cs - dy * sn - dx
                    ddy = dx * sn + dy * cs - dy
                }
                AdvancedWarpMode.WAVE -> {
                    val along = dx * dirX + dy * dirY
                    val freq = ((if (settings.frequency.isFinite()) settings.frequency else 1f) % 10_000f).coerceAtLeast(0.1f)
                    val wave = waveValue((along / wavelength) * (2f * Math.PI.toFloat()) * freq)
                    val disp = wave * amp * weight * sign
                    ddx = normalX * disp
                    ddy = normalY * disp
                }
                AdvancedWarpMode.SHEAR -> {
                    val localX = dx * dirX + dy * dirY
                    val localY = -dx * dirY + dy * dirX
                    val shX = (localY / (r * sy) * dragX + localX / (r * sx) * dragY * 0.25f) * strength * weight
                    val shY = (localX / (r * sx) * dragY + localY / (r * sy) * dragX * 0.25f) * strength * weight
                    ddx = shX * dirX - shY * dirY
                    ddy = shX * dirY + shY * dirX
                }
                AdvancedWarpMode.PERSPECTIVE -> {
                    val localX = dx * dirX + dy * dirY
                    val localY = -dx * dirY + dy * dirX
                    val perspectiveX = dragX * strength * weight * (localY / (r * sy)) * (1f - nx * nx).coerceAtLeast(0f)
                    val perspectiveY = dragY * strength * weight * (localX / (r * sx)) * (1f - ny * ny).coerceAtLeast(0f)
                    ddx = perspectiveX * dirX - perspectiveY * dirY
                    ddy = perspectiveX * dirY + perspectiveY * dirX
                }
                AdvancedWarpMode.RIPPLE -> {
                    val distance = hypot(dx, dy)
                    val freq = ((if (settings.frequency.isFinite()) settings.frequency else 1f) % 10_000f).coerceAtLeast(0.1f)
                    val phaseWave = (distance / wavelength) * (2f * Math.PI.toFloat()) * freq
                    val wave = waveValue(phaseWave)
                    val radial = (wave * amp * weight) * sign
                    val d = distance.coerceAtLeast(0.001f)
                    ddx = dx / d * radial
                    ddy = dy / d * radial
                }
                AdvancedWarpMode.PUSH -> {
                    val magnitude = hypot(dragX, dragY)
                    val dragAngle = kotlin.math.atan2(dragY, dragX)
                    val pushAngle = dragAngle + dir
                    ddx = cos(pushAngle) * magnitude * strength * weight
                    ddy = sin(pushAngle) * magnitude * strength * weight
                }
                // ── พู่กันบิดรูปขั้นสูงชุดใหม่ 15 แบบ ──
                AdvancedWarpMode.ARC_BEND -> {
                    // ดัดเป็นส่วนโค้งพาราโบลา โดยทิศตั้งฉากกับแกนพู่กันเป็นตัวกำหนดด้านโค้ง
                    val bendInput = if (abs(dragNormal) >= abs(dragForward) * 0.15f) dragNormal else dragForward * 0.35f
                    val bend = (bendInput / r).coerceIn(-1f, 1f) * strength * 0.9f
                    val curve = (localX * localX / (2f * r)) * bend * weight
                    val tangentComp = -localX * bend * bend * 0.12f * weight
                    ddx = dirX * tangentComp - dirY * curve
                    ddy = dirY * tangentComp + dirX * curve
                }
                AdvancedWarpMode.TAPER -> {
                    // ปลายด้านหนึ่งเรียวลง อีกด้านขยายขึ้นตามตำแหน่งบนแกนลาก
                    val along = (localX / (r * sx)).coerceIn(-1f, 1f)
                    val profile = along * (0.5f + settings.frequency.coerceIn(0.1f, 10f) * 0.08f)
                    val taper = (profile * strength * dragActivation * 0.7f * sign).coerceIn(-0.9f, 0.9f)
                    val across = -localY * taper * weight
                    ddx = -dirY * across
                    ddy = dirX * across
                }
                AdvancedWarpMode.RIGID_TRANSFORM -> {
                    // ย้ายและหมุนบริเวณให้เหมือนแผ่นเดียว น้ำหนักขอบทำหน้าที่ผสมกับภาพรอบนอก
                    val rotation = Math.toRadians(settings.angleDeg.toDouble()).toFloat() * dragActivation * strength * weight * sign
                    val cs = cos(rotation); val sn = sin(rotation)
                    val tx = dragX * strength * weight
                    val ty = dragY * strength * weight
                    ddx = dx * cs - dy * sn - dx + tx
                    ddy = dx * sn + dy * cs - dy + ty
                }
                AdvancedWarpMode.RIBBON_BEND -> {
                    // แถบแคบยืดตามแกน X ของพู่กันและโค้งเป็นแนวริบบิ้น
                    val along = localX / wavelength * (2f * Math.PI.toFloat()) * settings.frequency.coerceIn(0.1f, 20f) + phase
                    val ribbon = sin(along) * amp * weight * sign
                    val curl = (1f - cos(along)) * amp * 0.12f * weight * sign
                    ddx = dirX * curl - dirY * ribbon
                    ddy = dirY * curl + dirX * ribbon
                }
                AdvancedWarpMode.EDGE_SLIDE -> {
                    // เลื่อนจุดสัมผัสไปตามเส้นสัมผัสของวงอิทธิพล แทนการดันเข้า/ออกจากศูนย์กลาง
                    val d = hypot(localX, localY).coerceAtLeast(0.001f)
                    val dragSide = if (dragForward < 0f) -1f else 1f
                    val slide = amp * weight * dragSide
                    val tangentX = -localY / d
                    val tangentY = localX / d
                    ddx = (dirX * tangentX - dirY * tangentY) * slide
                    ddy = (dirY * tangentX + dirX * tangentY) * slide
                }
                AdvancedWarpMode.CONTOUR_FLOW -> {
                    // สนามไหลวนตามเส้นระดับของวงพู่กัน มีแนวไหลสลับตามคลื่นเฟส
                    val d = hypot(localX, localY).coerceAtLeast(0.001f)
                    val flowWave = sin((localX / wavelength) * (2f * Math.PI.toFloat()) * settings.frequency.coerceIn(0.1f, 20f) + phase)
                    val tangent = amp * weight * flowWave * sign
                    val u = -localY / d * tangent
                    val v = localX / d * tangent
                    ddx = dirX * u - dirY * v
                    ddy = dirY * u + dirX * v
                }
                AdvancedWarpMode.FAN_DEFORM -> {
                    // แผ่เป็นกลีบพัดจากศูนย์กลาง จำนวนริ้วกำหนดด้วยความถี่
                    val angleAt = kotlin.math.atan2(localY, localX)
                    val lobes = settings.frequency.coerceIn(1f, 24f)
                    val fan = cos(angleAt * lobes + phase)
                    val d = hypot(localX, localY).coerceAtLeast(0.001f)
                    val radial = amp * weight * fan * sign
                    val u = localX / d * radial
                    val v = localY / d * radial
                    ddx = dirX * u - dirY * v
                    ddy = dirY * u + dirX * v
                }
                AdvancedWarpMode.ORIGAMI_FOLD -> {
                    // พับด้านเดียวเข้าหาแนวสันพับ ความแข็งขอบเป็นความกว้างของรอยพับ
                    val foldSide = if (dragNormal < 0f) -1f else 1f
                    val sideDistance = localY * foldSide
                    if (sideDistance > 0f) {
                        val crease = (0.08f + (settings.hardness / 100f).coerceIn(0f, 0.95f) * 0.55f)
                        val fold = (strength * dragActivation * crease).coerceIn(0f, 0.95f) * weight
                        val across = -sideDistance * fold * foldSide
                        val along = sideDistance * fold * 0.12f * foldSide
                        ddx = dirX * along - dirY * across
                        ddy = dirY * along + dirX * across
                    }
                }
                AdvancedWarpMode.TOPOLOGY_REMAP -> {
                    // รีแมปตำแหน่งจุดตาข่ายเป็นสนามตารางไขว้ (ไม่เปลี่ยนจำนวนจุด/การเชื่อมต่อของ topology)
                    val waveX = sin((localX / wavelength) * (2f * Math.PI.toFloat()) * settings.frequency.coerceIn(0.1f, 20f) + phase)
                    val waveY = sin((localY / wavelength) * (2f * Math.PI.toFloat()) * settings.frequency.coerceIn(0.1f, 20f) - phase)
                    val remapX = waveY * amp * 0.42f * weight * sign
                    val remapY = waveX * amp * 0.42f * weight * sign
                    ddx = dirX * remapX - dirY * remapY
                    ddy = dirY * remapX + dirX * remapY
                }
                AdvancedWarpMode.BOUNDARY_TENSION -> {
                    // สร้างแรงตึงที่ขอบวงพู่กัน เน้นดึงบริเวณนอกเข้าหาแกนกลาง
                    val d = hypot(localX, localY).coerceAtLeast(0.001f)
                    val u = (d / r).coerceIn(0f, 1f)
                    val edgeBand = (u * u) * (0.25f + settings.edgeProtection.coerceIn(0f, 100f) / 100f * 0.75f)
                    val tension = (strength * dragActivation * edgeBand * weight).coerceIn(0f, 1.5f)
                    val pull = -tension * d * sign
                    val ux = localX / d * pull
                    val uy = localY / d * pull
                    ddx = dirX * ux - dirY * uy
                    ddy = dirY * ux + dirX * uy
                }
                AdvancedWarpMode.VISCOUS_MELT -> {
                    // ไหลย้อยตามทิศที่กำหนด มีแรงหน่วงมากขึ้นเมื่อห่างจากแนวกลางของพู่กัน
                    val direction = if (dragForward < 0f) -1f else 1f
                    val side = (1f - abs(localY / (r * sy)).coerceIn(0f, 1f))
                    val viscosity = (1f - side).pow(1f + settings.falloff.coerceIn(0f, 100f) / 50f)
                    val reach = (abs(localX) / wavelength).coerceIn(0f, 1f)
                    val slide = amp * weight * direction * (0.25f + 0.75f * viscosity) * (0.4f + 0.6f * reach)
                    val sag = localY * strength * dragActivation * 0.18f * weight * sign
                    val u = cos(dir) * slide - sin(dir) * sag
                    val v = sin(dir) * slide + cos(dir) * sag
                    ddx = u
                    ddy = v
                }
                AdvancedWarpMode.SEGMENT_OFFSET -> {
                    // แบ่งเป็นแถบแล้วเลื่อนสลับกัน เกิดเอฟเฟกต์เหลื่อมเป็นชั้น
                    val segmentSize = (wavelength / settings.frequency.coerceIn(0.1f, 20f)).coerceAtLeast(2f)
                    val segment = kotlin.math.floor((localY + r * sy) / segmentSize + phase / (2f * Math.PI.toFloat())).toInt()
                    val offsetSign = if (segment % 2 == 0) 1f else -1f
                    val offset = amp * weight * offsetSign * sign
                    ddx = dirX * offset
                    ddy = dirY * offset
                }
                AdvancedWarpMode.ASYMMETRIC_WARP -> {
                    // สร้างการบิดไม่เท่ากันสองฝั่งของแกนพู่กัน
                    val bias = sin(phase).coerceIn(-1f, 1f)
                    val side = if (localX >= 0f) (1f + bias).coerceAtLeast(0.05f) else (1f - bias).coerceAtLeast(0.05f)
                    val asym = side * (0.35f + abs(localX / (r * sx)).coerceIn(0f, 1f) * 0.65f)
                    val u = dragForward / r * amp * weight * asym
                    val v = dragNormal / r * amp * weight * (2f - asym.coerceAtMost(1.95f))
                    ddx = dirX * u - dirY * v
                    ddy = dirY * u + dirX * v
                }
                AdvancedWarpMode.DIRECTIONAL_COMPRESS -> {
                    // บีบตามแกนที่ตั้งและชดเชยอีกแกนเพื่อคงพื้นที่โดยประมาณ
                    val compression = (0.72f * strength * dragActivation * sign).coerceIn(-0.5f, 0.82f) * weight
                    val stretch = (1f / (1f - compression).coerceAtLeast(0.18f)).let { kotlin.math.sqrt(it) - 1f }
                    val u = -localX * compression
                    val v = localY * stretch * 0.65f
                    ddx = dirX * u - dirY * v
                    ddy = dirY * u + dirX * v
                }
                AdvancedWarpMode.SURFACE_ROLL -> {
                    // ม้วนผิวรอบแกนเหมือนแผ่นวัสดุโค้งเป็นทรงกระบอก
                    val rollRadius = wavelength.coerceAtLeast(6f)
                    val theta = (localY / rollRadius) * dragActivation * strength * settings.frequency.coerceIn(0.1f, 8f) * sign
                    val bounded = theta.coerceIn(-Math.PI.toFloat(), Math.PI.toFloat())
                    val rolledY = rollRadius * sin(bounded) - localY
                    val rolledX = rollRadius * (1f - cos(bounded)) * (if (dragNormal < 0f) -1f else 1f)
                    val u = rolledX * weight
                    val v = rolledY * weight
                    ddx = dirX * u - dirY * v
                    ddy = dirY * u + dirX * v
                }
            }
            if (mirror) ddx = -ddx
            if (settings.lockHorizontal) ddx = 0f
            if (settings.lockVertical) ddy = 0f
            val len = hypot(ddx, ddy)
            if (len > maxDelta && len > 0f) { val f = maxDelta / len; ddx *= f; ddy *= f }
            return ddx to ddy
        }

        var n = 0
        for (j in 0..start.rows) for (i in 0..start.cols) {
            if (n in lockedIndices) { n++; continue }
            val vx = start.restX(i, w) + start.off[2 * n]
            val vy = start.restY(j, h) + start.off[2 * n + 1]
            val seed = ((i + 1) * 83492791) xor ((j + 1) * 297121507)
            val noise = ((seed ushr 9) and 2047) / 1023.5f - 1f
            var d = deltaAt(vx, vy, cx, cy, false, noise)
            if (settings.symmetry) {
                val mirrorCenter = w - cx
                val md = deltaAt(vx, vy, mirrorCenter, cy, true, noise)
                d = (d.first + md.first) to (d.second + md.second)
            }
            var targetX = vx + d.first
            var targetY = vy + d.second
            if (settings.boundaryClamp) {
                targetX = targetX.coerceIn(0f, w.toFloat())
                targetY = targetY.coerceIn(0f, h.toFloat())
            }
            out[2 * n] = targetX - start.restX(i, w)
            out[2 * n + 1] = targetY - start.restY(j, h)
            n++
        }
        val smoothAmount = if (mode == AdvancedWarpMode.SMOOTH) maxOf(settings.meshSmoothing, settings.strength) else settings.meshSmoothing
        var candidate = smoothGrid(start.withOff(out), smoothAmount, lockedIndices, settings.lockHorizontal, settings.lockVertical)
        fun safe(grid: SculptGrid): Boolean {
            if (!safetyEnabled) return true
            if (foldCount(w, h, grid) > baseFolds) return false
            val minDistance = settings.minPointDistance.coerceIn(0f, 500f)
            if (minDistance > 0f) {
                val verts = verts(w, h, grid)
                val rowWidth = grid.cols + 1
                for (j in 0..grid.rows) for (i in 0..grid.cols) {
                    val at = j * rowWidth + i
                    if (i < grid.cols) {
                        val next = at + 1
                        if (hypot(verts[2 * at] - verts[2 * next], verts[2 * at + 1] - verts[2 * next + 1]) < minDistance) return false
                    }
                    if (j < grid.rows) {
                        val next = at + rowWidth
                        if (hypot(verts[2 * at] - verts[2 * next], verts[2 * at + 1] - verts[2 * next + 1]) < minDistance) return false
                    }
                }
            }
            return true
        }
        if (!safe(candidate)) {
            var lo = 0f
            var hi = 1f
            repeat(7) {
                val mid = (lo + hi) * 0.5f
                val testOff = FloatArray(out.size) { k -> start.off[k] + (out[k] - start.off[k]) * mid }
                val test = start.withOff(testOff)
                if (safe(smoothGrid(test, smoothAmount, lockedIndices, settings.lockHorizontal, settings.lockVertical))) lo = mid else hi = mid
            }
            val safeOff = FloatArray(out.size) { k -> start.off[k] + (out[k] - start.off[k]) * lo }
            candidate = smoothGrid(start.withOff(safeOff), smoothAmount, lockedIndices, settings.lockHorizontal, settings.lockVertical)
        }
        return candidate
    }
}
