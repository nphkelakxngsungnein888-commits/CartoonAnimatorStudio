package com.nop.cartoonstudio

import kotlin.math.abs
import kotlin.math.exp
import kotlin.math.max
import kotlin.math.min
import kotlin.math.pow

/** โหมดผสมชั้นบิดภาพ */
enum class WarpBlendMode { ADD, SUBTRACT, REPLACE, MULTIPLY }

/** หน้ากากของชั้นบิด เก็บน้ำหนักต่อจุดตาข่าย 0..1; null หมายถึงมีผลเต็มพื้นที่ */
data class WarpMask(
    val cols: Int,
    val rows: Int,
    val weights: FloatArray,
) {
    init { require(weights.size == (cols + 1) * (rows + 1)) }
    fun weight(index: Int): Float = weights.getOrElse(index) { 1f }.let { if (it.isFinite()) it.coerceIn(0f, 1f) else 0f }

    /** ระบายหน้ากากบนจุดตาข่ายโดยตรง; strength 0..1, erase=true ค่อย ๆ ลบเป็นสีดำ */
    fun paint(grid: SculptGrid, width: Int, height: Int, centerX: Float, centerY: Float, radius: Float, strength: Float, erase: Boolean = false, settings: WarpSettings = WarpSettings()): WarpMask {
        val source = if (cols == grid.cols && rows == grid.rows) this else resized(grid.cols, grid.rows)
        val out = source.weights.copyOf()
        val r = (if (radius.isFinite()) radius else 1f).coerceAtLeast(1f)
        val power = (if (strength.isFinite()) strength else 0f).coerceIn(0f, 1f)
        val target = if (erase) 0f else 1f
        val angle = Math.toRadians(settings.angleDeg.toDouble()).toFloat()
        val ca = kotlin.math.cos(angle); val sa = kotlin.math.sin(angle)
        val sx = (settings.scaleX / 100f).let { if (kotlin.math.abs(it) < 0.000001f) 0.000001f else it }
        val sy = (settings.scaleY / 100f).let { if (kotlin.math.abs(it) < 0.000001f) 0.000001f else it }
        var point = 0
        for (j in 0..grid.rows) for (i in 0..grid.cols) {
            val vx = grid.restX(i, width) + grid.off[2 * point]
            val vy = grid.restY(j, height) + grid.off[2 * point + 1]
            val dx = vx - centerX; val dy = vy - centerY
            val nx = (dx * ca + dy * sa) / sx
            val ny = (-dx * sa + dy * ca) / sy
            val d = Sculpt.brushDistance(nx, ny, settings.brushShape)
            if (d < r) {
                val u = (1f - d / r).coerceIn(0f, 1f)
                val falloff = u * u * (3f - 2f * u)
                val amount = (power * falloff).coerceIn(0f, 1f)
                out[point] = (out[point] + (target - out[point]) * amount).coerceIn(0f, 1f)
            }
            point++
        }
        return WarpMask(grid.cols, grid.rows, out)
    }

    fun resized(cols: Int, rows: Int): WarpMask {
        val out = FloatArray((cols + 1) * (rows + 1))
        for (y in 0..rows) for (x in 0..cols) {
            val sx = x.toFloat() / cols.coerceAtLeast(1) * this.cols
            val sy = y.toFloat() / rows.coerceAtLeast(1) * this.rows
            val x0 = sx.toInt().coerceIn(0, this.cols); val y0 = sy.toInt().coerceIn(0, this.rows)
            val x1 = (x0 + 1).coerceAtMost(this.cols); val y1 = (y0 + 1).coerceAtMost(this.rows)
            val fx = sx - x0; val fy = sy - y0
            fun at(px: Int, py: Int) = weight(py * (this.cols + 1) + px)
            val a = at(x0,y0) * (1f-fx) + at(x1,y0) * fx
            val b = at(x0,y1) * (1f-fx) + at(x1,y1) * fx
            out[y * (cols + 1) + x] = a * (1f-fy) + b * fy
        }
        return WarpMask(cols, rows, out)
    }
    companion object { fun full(cols: Int, rows: Int) = WarpMask(cols, rows, FloatArray((cols+1)*(rows+1)) { 1f }) }
}

/** ชั้นบิดแยกอิสระ ทำให้เปิด/ปิด ปรับความเข้ม และเปลี่ยนโหมดผสมได้โดยไม่แก้ภาพต้นฉบับ */
data class WarpLayer(
    val id: Long,
    val name: String,
    val grid: SculptGrid,
    val mask: WarpMask? = null,
    val opacity: Float = 1f,
    val enabled: Boolean = true,
    val blend: WarpBlendMode = WarpBlendMode.ADD,
    val locked: Boolean = false,
)

/** ค่าฟิสิกส์สำหรับการเคลื่อนไหวรองของภาพ/ชิ้นส่วน */
data class WarpPhysicsSettings(
    val enabled: Boolean = false,
    val gravityX: Float = 0f,
    val gravityY: Float = 980f,
    val mass: Float = 1f,
    val stiffness: Float = 180f,
    val damping: Float = 18f,
    val elasticity: Float = 0.35f,
    val springStrength: Float = 120f,
    val bounce: Float = 0.2f,
    val drag: Float = 0.05f,
    val windX: Float = 0f,
    val windY: Float = 0f,
    val collision: Boolean = false,
    val recoverySpeed: Float = 5f,
    val maxStretch: Float = 1.5f,
) {
    fun sanitized() = copy(
        gravityX = gravityX.finiteOrZero().coerceIn(-1_000_000f, 1_000_000f), gravityY = gravityY.finiteOrZero().coerceIn(-1_000_000f, 1_000_000f),
        mass = mass.finitePositive().coerceIn(0.0001f, 1_000_000f), stiffness = stiffness.finiteNonNegative().coerceAtMost(1_000_000f), damping = damping.finiteNonNegative().coerceAtMost(1_000_000f),
        elasticity = elasticity.finiteNonNegative().coerceAtMost(1_000_000f), springStrength = springStrength.finiteNonNegative().coerceAtMost(1_000_000f),
        bounce = bounce.finiteNonNegative().coerceAtMost(1_000_000f), drag = drag.finiteNonNegative().coerceAtMost(1_000_000f), windX = windX.finiteOrZero().coerceIn(-1_000_000f, 1_000_000f),
        windY = windY.finiteOrZero().coerceIn(-1_000_000f, 1_000_000f), recoverySpeed = recoverySpeed.finiteNonNegative().coerceAtMost(1_000_000f), maxStretch = maxStretch.finitePositive().coerceAtMost(10_000f),
    )
}

private fun Float.finiteOrZero() = if (isFinite()) this else 0f
private fun Float.finitePositive() = finiteOrZero().coerceAtLeast(0.0001f)
private fun Float.finiteNonNegative() = finiteOrZero().coerceAtLeast(0f)

/** คำนวณผลรวมชั้นบิดแบบไม่ทำลายต้นฉบับ */
object WarpStackMath {
    fun composite(base: SculptGrid?, layers: List<WarpLayer>): SculptGrid? {
        val active = layers.filter { it.enabled && !it.grid.isZero() }
        if (base == null && active.isEmpty()) return null
        val template = base ?: active.first().grid
        val cols = template.cols; val rows = template.rows
        val out = FloatArray((cols + 1) * (rows + 1) * 2)
        if (base != null) {
            val b = Sculpt.resample(base, cols, rows)
            for (i in out.indices) out[i] = b.off[i]
        }
        active.forEach { layer ->
            val g = Sculpt.resample(layer.grid, cols, rows)
            val mask = layer.mask?.resized(cols, rows)
            val opacity = if (layer.opacity.isFinite()) layer.opacity.coerceIn(0f, 1f) else 0f
            for (point in 0 until (cols + 1) * (rows + 1)) {
                val m = (mask?.weight(point) ?: 1f) * opacity
                val k = point * 2
                for (axis in 0..1) {
                    val v = g.off[k + axis] * m
                    out[k + axis] = when (layer.blend) {
                        WarpBlendMode.ADD -> out[k + axis] + v
                        WarpBlendMode.SUBTRACT -> out[k + axis] - v
                        WarpBlendMode.REPLACE -> out[k + axis] * (1f - m) + g.off[k + axis] * m
                        WarpBlendMode.MULTIPLY -> out[k + axis] * (1f - m) + out[k + axis] * (g.off[k + axis] / 100f) * m
                    }
                }
            }
        }
        return SculptGrid(cols, rows, out, template.xs, template.ys, template.pinAngles)
    }

    /** คำนวณการเคลื่อนที่รองแบบกำหนดผลซ้ำได้จากเวลา จึงแสดงผลตรงกันทั้ง Preview และ Export */
    fun physicsAt(grid: SculptGrid, settings: WarpPhysicsSettings, timeSeconds: Float): SculptGrid {
        val s = settings.sanitized()
        if (!s.enabled || timeSeconds <= 0f || !timeSeconds.isFinite()) return grid
        val t = timeSeconds.coerceAtMost(120f)
        val omega = kotlin.math.sqrt(s.stiffness / s.mass)
        val decay = exp((-(s.damping / (2f * s.mass) + s.drag) * t).coerceAtLeast(-60f))
        val oscillation = decay * kotlin.math.cos(omega * t) * (1f + s.bounce)
        val gravityFactor = 0.5f * t * t
        val out = grid.off.copyOf()
        for (i in out.indices step 2) {
            val bx = out[i].finiteOrZero(); val by = out[i + 1].finiteOrZero()
            val recovery = 1f - exp((-s.recoverySpeed * t).coerceAtLeast(-60f))
            val spring = (1f - oscillation) * (s.springStrength / 120f) * recovery
            val gx = (s.gravityX + s.windX) * gravityFactor / s.mass
            val gy = (s.gravityY + s.windY) * gravityFactor / s.mass
            val dx = bx * oscillation + gx * s.elasticity
            val dy = by * oscillation + gy * s.elasticity
            val limit = max(1f, max(abs(bx), abs(by)) + max(abs(gx), abs(gy))) * s.maxStretch
            out[i] = (dx * (1f - spring * 0.05f)).coerceIn(-limit, limit).finiteOrZero()
            out[i + 1] = (dy * (1f - spring * 0.05f)).coerceIn(-limit, limit).finiteOrZero()
        }
        return grid.withOff(out)
    }

    /** ใช้แรงคืนรูปแบบสปริงอย่างปลอดภัย; dt ถูกแบ่งย่อยเพื่อไม่ให้เฟรมกระโดดทำให้ระบบระเบิด */
    fun physicsStep(grid: SculptGrid, settings: WarpPhysicsSettings, dtSeconds: Float): SculptGrid {
        val s = settings.sanitized()
        if (!s.enabled || dtSeconds <= 0f || !dtSeconds.isFinite()) return grid
        val dt = dtSeconds.coerceAtMost(0.25f)
        val steps = (dt / (1f / 120f)).toInt().coerceIn(1, 30)
        val h = dt / steps
        val out = grid.off.copyOf()
        for (i in out.indices step 2) {
            var x = out[i].finiteOrZero(); var y = out[i + 1].finiteOrZero()
            var vx = 0f; var vy = 0f
            repeat(steps) {
                val ax = (s.gravityX + s.windX - s.stiffness * x - s.damping * vx) / s.mass
                val ay = (s.gravityY + s.windY - s.stiffness * y - s.damping * vy) / s.mass
                vx += ax * h; vy += ay * h
                val damp = exp((-s.drag * h).coerceAtLeast(-30f))
                vx *= damp; vy *= damp
                x += vx * h; y += vy * h
                val maxOffset = max(1f, max(abs(grid.off[i]), abs(grid.off[i + 1])) + 1f) * s.maxStretch
                x = x.coerceIn(-maxOffset, maxOffset); y = y.coerceIn(-maxOffset, maxOffset)
            }
            val recover = (s.recoverySpeed * dt).coerceIn(0f, 1f)
            out[i] = (x * (1f - recover)).finiteOrZero()
            out[i + 1] = (y * (1f - recover)).finiteOrZero()
        }
        return grid.withOff(out)
    }
}

/** ค่าพื้นที่ทำงาน Warp ที่บันทึกกับโปรเจกต์ */
data class WarpWorkspaceSettings(
    val warp: WarpSettings = WarpSettings(),
    val brushFraction: Float = 0.25f,
    val meshCell: Float? = null,
    val meshRings: Int = 1,
    val twistDegrees: Float = 90f,
    val customPresets: List<WarpPreset> = emptyList(),
)

/** พรีเซ็ตตั้งต้นพร้อมคำอธิบายภาษาไทย */
data class WarpPreset(val name: String, val description: String, val settings: WarpSettings)
object WarpPresets {
    val all = listOf(
        WarpPreset("ปั้นนุ่ม", "เปลี่ยนรูปอย่างค่อยเป็นค่อยไป เหมาะกับใบหน้าและส่วนโค้ง", WarpSettings(strength=45f, falloff=90f, smoothness=95f, hardness=0f)),
        WarpPreset("ยางยืด", "ยืดหยุ่นและคืนรูป เหมาะกับตัวการ์ตูน", WarpSettings(strength=125f, falloff=70f, smoothness=65f, accumulate=true)),
        WarpPreset("คลื่นน้ำ", "สร้างการบิดเป็นคลื่นต่อเนื่อง", WarpSettings(strength=80f, frequency=5f, wavelengthPx=72f, waveType="Sine")),
        WarpPreset("เกลียวเวทมนตร์", "หมุนพื้นที่เข้าหาศูนย์กลางคล้ายพลังเวท", WarpSettings(strength=95f, angleDeg=240f, frequency=3f)),
        WarpPreset("บวมการ์ตูน", "ขยายส่วนที่เลือกให้ดูนูนและเกินจริง", WarpSettings(strength=110f, scaleX=125f, scaleY=125f)),
        WarpPreset("บีบการ์ตูน", "บีบส่วนที่เลือกเข้าหาจุดกลาง", WarpSettings(strength=90f, scaleX=80f, scaleY=80f)),
    )
}


/** โครงหมุดตัวละคร 2 มิติแบบเริ่มต้น ใช้ตำแหน่งสัดส่วนของภาพและสายหมุดพ่อ-ลูก */
object BodyRigPresets {
    fun humanoid(width: Int, height: Int): PinRig {
        val w = width.coerceAtLeast(1).toFloat(); val h = height.coerceAtLeast(1).toFloat()
        fun p(id: Int, name: String, x: Float, y: Float, dir: Float, parent: Int = 0) = JointPin(
            id=id, name=name, x=x*w, y=y*h, dirDeg=dir, soft=48f, reach=0f, meshRadius=0f,
            parentId=parent, minDeg=-150f, maxDeg=150f,
        )
        val pins = listOf(
            p(1,"คอ",.50f,.34f,90f),
            p(2,"ไหล่ซ้าย",.39f,.40f,150f,1), p(3,"ศอกซ้าย",.29f,.53f,150f,2), p(4,"ข้อมือซ้าย",.20f,.66f,150f,3),
            p(5,"ไหล่ขวา",.61f,.40f,30f,1), p(6,"ศอกขวา",.71f,.53f,30f,5), p(7,"ข้อมือขวา",.80f,.66f,30f,6),
            p(8,"สะโพก",.50f,.64f,90f), p(9,"เข่าซ้าย",.43f,.80f,90f,8), p(10,"ข้อเท้าซ้าย",.40f,.95f,90f,9),
            p(11,"เข่าขวา",.57f,.80f,90f,8), p(12,"ข้อเท้าขวา",.60f,.95f,90f,11),
        )
        return PinRig(pins=pins, adaptive=true, density=3f)
    }

    fun arms(width: Int, height: Int): PinRig = humanoid(width,height).let { rig -> rig.copy(pins=rig.pins.filter { it.id in 1..7 }) }
    fun legs(width: Int, height: Int): PinRig = humanoid(width,height).let { rig -> rig.copy(pins=rig.pins.filter { it.id == 8 || it.id in 9..12 }) }
}
