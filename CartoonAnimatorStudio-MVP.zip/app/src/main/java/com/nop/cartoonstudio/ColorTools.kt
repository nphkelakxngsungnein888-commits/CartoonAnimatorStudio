package com.nop.cartoonstudio

import android.content.Context
import android.os.Handler
import android.os.Looper
import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import org.json.JSONArray
import org.json.JSONObject
import kotlin.math.max
import kotlin.math.roundToInt

/** ระยะ (dp) จากจุดที่นิ้วกดถึงกลางวงสีตัวอย่างตอนดูดสี: เดิม 74 → 148 → 222 (ปรับเลขนี้ตัวเดียวถ้าอยากสูง/ต่ำกว่านี้) */
internal const val EYEDROP_GAP_DP = 222f

/** ขนาดปุ่มสีที่เซฟ (dp) */
internal const val SAVED_BTN_DP = 46f

/** เซฟสีได้สูงสุดกี่สี */
internal const val SAVED_COLOR_MAX = 24

private val DelRed = Color(0xFFE5484D)

/** ข้อความสั้นของเครื่องมือสี: แสดงแค่ ~1.3 วินาที และข้อความใหม่แทนที่ข้อความเก่าทันที (ไม่ต่อคิวซ้อนกัน) */
internal object QuickToast {
    private val handler = Handler(Looper.getMainLooper())
    private var current: Toast? = null
    private var hide: Runnable? = null

    fun show(ctx: Context, msg: String, ms: Long = 1300L) {
        hide?.let { handler.removeCallbacks(it) }
        current?.cancel()
        val t = Toast.makeText(ctx.applicationContext, msg, Toast.LENGTH_SHORT)
        current = t
        t.show()
        val r = Runnable { t.cancel() }
        hide = r
        handler.postDelayed(r, ms)
    }
}

/** สีที่เซฟไว้ 1 สี = ปุ่มลอย 1 ปุ่ม · xDp/yDp = ตำแหน่งมุมบนซ้ายของปุ่มในผืนผ้าใบ (หน่วย dp เพื่อให้ตรงกันทุกความหนาแน่นจอ) */
internal class SavedColor(val id: Long, val color: Int, x: Float, y: Float) {
    var xDp by mutableFloatStateOf(x)
    var yDp by mutableFloatStateOf(y)
}

/** เก็บสีที่เซฟไว้ในเครื่อง (ปิดแอปแล้วยังอยู่) */
internal object SavedColorStore {
    private const val PREF = "brush_saved_colors"
    private const val KEY = "list_v1"

    fun load(ctx: Context): List<SavedColor> {
        return try {
            val s = ctx.getSharedPreferences(PREF, Context.MODE_PRIVATE).getString(KEY, null) ?: return emptyList()
            val a = JSONArray(s)
            val out = ArrayList<SavedColor>()
            for (i in 0 until a.length()) {
                val o = a.getJSONObject(i)
                out.add(SavedColor(o.getLong("id"), o.getInt("c"), o.optDouble("x", 0.0).toFloat(), o.optDouble("y", 0.0).toFloat()))
            }
            out
        } catch (_: Exception) {
            emptyList()
        }
    }

    fun save(ctx: Context, list: List<SavedColor>) {
        try {
            val a = JSONArray()
            for (c in list) {
                a.put(JSONObject().put("id", c.id).put("c", c.color).put("x", c.xDp.toDouble()).put("y", c.yDp.toDouble()))
            }
            ctx.getSharedPreferences(PREF, Context.MODE_PRIVATE).edit().putString(KEY, a.toString()).apply()
        } catch (_: Exception) {
            // เก็บไม่ได้ก็แค่ไม่จำข้ามการเปิดแอป ไม่กระทบการใช้งานตอนนี้
        }
    }
}

/**
 * ปุ่มสีที่เซฟไว้ทั้งหมด (ปุ่มลอยอิสระ): แตะ = เปลี่ยนเป็นสีนั้น · ลากนิ้ว = ย้ายไปวางตรงไหนก็ได้
 * โหมดลบ (deleteMode): แตะ = เลือก/ยกเลิกเลือกปุ่มที่จะลบ (ยังลากย้ายได้)
 * วางเป็นลูกของ Box ผืนผ้าใบโดยตรง (ตำแหน่งนับจากมุมบนซ้ายของ Box)
 */
@Composable
internal fun SavedColorLayer(
    colors: List<SavedColor>,
    current: Int,
    deleteMode: Boolean,
    marked: Set<Long>,
    areaPx: IntSize,
    onPick: (SavedColor) -> Unit,
    onToggle: (SavedColor) -> Unit,
    onMoved: () -> Unit,
) {
    val cur = current or (0xFF shl 24)
    for (sc in colors) {
        key(sc.id) {
            SavedColorButton(
                sc = sc,
                active = (sc.color or (0xFF shl 24)) == cur,
                deleteMode = deleteMode,
                marked = sc.id in marked,
                areaPx = areaPx,
                onPick = { onPick(sc) },
                onToggle = { onToggle(sc) },
                onMoved = onMoved,
            )
        }
    }
}

@Composable
private fun SavedColorButton(
    sc: SavedColor,
    active: Boolean,
    deleteMode: Boolean,
    marked: Boolean,
    areaPx: IntSize,
    onPick: () -> Unit,
    onToggle: () -> Unit,
    onMoved: () -> Unit,
) {
    val density = LocalDensity.current.density
    val sizePx = SAVED_BTN_DP * density
    val maxX = max(0f, areaPx.width - sizePx)
    val maxY = max(0f, areaPx.height - sizePx)
    val px = (sc.xDp * density).coerceIn(0f, maxX)
    val py = (sc.yDp * density).coerceIn(0f, maxY)
    var dragging by remember { mutableStateOf(false) }
    val deleteNow by rememberUpdatedState(deleteMode)
    val areaNow by rememberUpdatedState(areaPx)
    val pickNow by rememberUpdatedState(onPick)
    val toggleNow by rememberUpdatedState(onToggle)
    val movedNow by rememberUpdatedState(onMoved)

    val ring = when {
        deleteMode && marked -> DelRed
        deleteMode -> Color(0x99FFFFFF)
        active -> Palette.Accent
        else -> Color(0xCCFFFFFF)
    }
    val ringW = if ((deleteMode && marked) || (!deleteMode && active)) 3.dp else 2.dp

    Box(
        Modifier
            .offset { IntOffset(px.roundToInt(), py.roundToInt()) }
            .size(SAVED_BTN_DP.dp)
            .graphicsLayer {
                val s = if (dragging) 1.14f else 1f
                scaleX = s
                scaleY = s
            }
            .pointerInput(sc.id) {
                awaitEachGesture {
                    val down = awaitFirstDown(requireUnconsumed = false)
                    down.consume()
                    var total = Offset.Zero
                    var moved = false
                    while (true) {
                        val e = awaitPointerEvent()
                        val ch = e.changes.firstOrNull { it.id == down.id } ?: break
                        if (!ch.pressed) {
                            if (!moved) {
                                if (deleteNow) toggleNow() else pickNow()
                            }
                            break
                        }
                        val d = ch.position - ch.previousPosition
                        var step = Offset.Zero
                        if (!moved) {
                            total += d
                            if (total.getDistance() > viewConfiguration.touchSlop) {
                                moved = true
                                dragging = true
                                step = total
                            }
                        } else {
                            step = d
                        }
                        if (step != Offset.Zero) {
                            val a = areaNow
                            val mx = max(0f, a.width - sizePx)
                            val my = max(0f, a.height - sizePx)
                            sc.xDp = ((sc.xDp * density + step.x).coerceIn(0f, mx)) / density
                            sc.yDp = ((sc.yDp * density + step.y).coerceIn(0f, my)) / density
                        }
                        ch.consume()
                    }
                    dragging = false
                    if (moved) movedNow()
                }
            },
        contentAlignment = Alignment.Center,
    ) {
        Box(
            Modifier
                .fillMaxSize()
                .shadow(if (dragging) 10.dp else 4.dp, CircleShape)
                .clip(CircleShape)
                .background(Color(0xE61B1D22))
                .border(ringW, ring, CircleShape),
            contentAlignment = Alignment.Center,
        ) {
            Box(
                Modifier
                    .size(32.dp)
                    .alpha(if (deleteMode && marked) 0.45f else 1f)
                    .clip(CircleShape)
                    .background(Color(sc.color))
                    .border(1.dp, Color(0x55000000), CircleShape),
            )
        }
        if (deleteMode && marked) {
            Box(
                Modifier
                    .align(Alignment.TopEnd)
                    .offset(4.dp, (-4).dp)
                    .size(18.dp)
                    .clip(CircleShape)
                    .background(DelRed)
                    .border(1.5.dp, Color.White, CircleShape),
                contentAlignment = Alignment.Center,
            ) { Text("✕", color = Color.White, fontSize = 10.sp, fontWeight = FontWeight.Bold) }
        }
    }
}

/**
 * ตัวอย่างสีสดๆ ระหว่างลากนิ้วดูดสี: วงเล็งอยู่ใต้นิ้ว + วงสีใหญ่ลอยเหนือนิ้ว (นิ้วไม่บัง) พร้อมรหัสสี
 * pos = ตำแหน่งนิ้วในผืนผ้าใบ (px) · color = สีที่จุดนั้น (null = โปร่งใส ไม่มีสีให้ดูด)
 */
@Composable
internal fun EyedropPreview(pos: Offset, color: Int?, areaPx: IntSize) {
    val d = LocalDensity.current.density
    val bubble = 78f * d
    val gap = EYEDROP_GAP_DP * d // ระยะจากนิ้วถึงกลางวงสี
    val cx = pos.x.coerceIn(bubble / 2f, max(bubble / 2f, areaPx.width - bubble / 2f))
    // ลอยเหนือนิ้วเสมอ ถ้านิ้วอยู่ใกล้ขอบบนก็ดันวงชิดขอบบนแทน · พลิกไปอยู่ใต้นิ้วเฉพาะเมื่อวงจะทับนิ้ว
    val upCy = max(pos.y - gap, bubble / 2f + 30f * d)
    val above = pos.y - upCy >= bubble / 2f + 24f * d
    val cy = if (above) upCy else pos.y + gap

    // วงเล็งใต้นิ้ว
    Box(
        Modifier
            .offset { IntOffset((pos.x - 14f * d).roundToInt(), (pos.y - 14f * d).roundToInt()) }
            .size(28.dp),
        contentAlignment = Alignment.Center,
    ) {
        Box(Modifier.fillMaxSize().border(3.dp, Color(0x99000000), CircleShape))
        Box(Modifier.size(24.dp).border(1.5.dp, Color.White, CircleShape))
    }

    // วงสีตัวอย่าง
    Box(
        Modifier
            .offset { IntOffset((cx - bubble / 2f).roundToInt(), (cy - bubble / 2f).roundToInt()) }
            .size(78.dp)
            .shadow(8.dp, CircleShape)
            .clip(CircleShape)
            .background(if (color != null) Color(color) else Color(0xFF2A2A34))
            .border(4.dp, Color.White, CircleShape),
        contentAlignment = Alignment.Center,
    ) {
        if (color == null) Text("โปร่งใส", color = Color(0xFFC9C4D4), fontSize = 11.sp)
    }

    // รหัสสี
    if (color != null) {
        val labelY = if (above) cy - bubble / 2f - 28f * d else cy + bubble / 2f + 6f * d
        Box(
            Modifier
                .offset { IntOffset((cx - 36f * d).roundToInt(), labelY.roundToInt()) }
                .size(width = 72.dp, height = 22.dp)
                .clip(RoundedCornerShape(11.dp))
                .background(Color(0xCC000000)),
            contentAlignment = Alignment.Center,
        ) {
            Text(String.format("#%06X", color and 0xFFFFFF), color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Medium)
        }
    }
}

/** แบนเนอร์บอกโหมด (ดูดสี / ลบสีที่เซฟ) พร้อมปุ่มยกเลิก และปุ่มตกลง (ถ้ามี) */
@Composable
internal fun ColorModeBanner(
    modifier: Modifier,
    text: String,
    onCancel: () -> Unit,
    okText: String? = null,
    okEnabled: Boolean = true,
    onOk: () -> Unit = {},
) {
    val shape = RoundedCornerShape(18.dp)
    Column(
        modifier
            .widthIn(max = 230.dp)
            .clip(shape)
            .background(Color(0xF01B1D22))
            .border(1.dp, Palette.Stroke, shape)
            .pointerInput(Unit) { detectTapGestures { } } // กันการแตะทะลุลงไปที่ภาพ
            .padding(10.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(8.dp),
    ) {
        Text(text, color = Color(0xFFE6E1F0), fontSize = 12.sp, lineHeight = 16.sp, textAlign = TextAlign.Center)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            BannerPill("ยกเลิก", primary = false, enabled = true, onClick = onCancel)
            if (okText != null) BannerPill(okText, primary = true, enabled = okEnabled, onClick = onOk)
        }
    }
}

@Composable
private fun BannerPill(label: String, primary: Boolean, enabled: Boolean, onClick: () -> Unit) {
    val pill = RoundedCornerShape(14.dp)
    Box(
        Modifier
            .alpha(if (enabled) 1f else 0.38f)
            .clip(pill)
            .background(if (primary) Palette.Accent else Palette.PanelHigh)
            .border(1.dp, if (primary) Palette.Accent else Palette.Stroke, pill)
            .clickable(enabled = enabled, onClick = onClick)
            .padding(horizontal = 16.dp, vertical = 8.dp),
        contentAlignment = Alignment.Center,
    ) {
        Text(label, color = if (primary) Color(0xFF2A1A66) else Color.White, fontSize = 13.sp, fontWeight = FontWeight.Medium)
    }
}
