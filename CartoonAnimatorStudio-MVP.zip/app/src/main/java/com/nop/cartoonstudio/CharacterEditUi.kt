package com.nop.cartoonstudio

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

/**
 * หน้าแก้ไขตัวละครในฉาก: ใช้หน้าจัดกระดูกเดิมกับโครงกระดูกชั่วคราว (vm.charEdit) แทนโครงของเมนูกระดูก
 * กด ✔ ตกลง -> ถามว่าจะให้ฉบับที่แก้แสดงถึงเฟรมไหน -> ใช้ผลกับฉาก (ก่อนหน้านั้นฉากไม่ถูกแตะ)
 */
@Composable
fun CharacterEditHost(vm: EditorViewModel, session: CharEditSession) {
    var askCancel by remember { mutableStateOf(false) }
    var askRange by remember { mutableStateOf(false) }

    BoneEditorScreen(
        session.skeleton,
        { askCancel = true }, // ✕ หรือปุ่มย้อนกลับของเครื่อง: ถามก่อนทิ้งสิ่งที่แก้
        SceneEditUi(session.name) { askRange = true },
    )

    if (askCancel) {
        AlertDialog(
            onDismissRequest = { askCancel = false },
            title = { Text("ยกเลิกการแก้ไข?") },
            text = { Text("สิ่งที่แก้ในหน้านี้จะหายไป ตัวละครในฉากไม่เปลี่ยน") },
            confirmButton = {
                TextButton(onClick = {
                    askCancel = false
                    vm.cancelCharacterEdit()
                }) { Text("ยกเลิกการแก้ไข") }
            },
            dismissButton = { TextButton(onClick = { askCancel = false }) { Text("แก้ต่อ") } },
        )
    }
    if (askRange) CharEditRangeDialog(vm, session) { askRange = false }
}

private enum class EditScope { THIS, RANGE, TO_END }

private val EditTonalBg = Color(0xFF42338A)
private val EditNormalFg = Color(0xFFE7E3EE)

/** ถามว่าจะให้ตัวละครฉบับที่แก้แสดงถึงเฟรมไหน (เริ่มที่เฟรมที่เปิดแก้ไข) เฟรมก่อน/หลังช่วงนั้นยังเป็นตัวละครเดิม */
@Composable
private fun CharEditRangeDialog(vm: EditorViewModel, s: CharEditSession, onDismiss: () -> Unit) {
    val n = vm.project.frameCount
    val af = s.appearFrom
    val at = s.appearTo
    val lastShown = if (at < 0) n - 1 else minOf(at, n - 1) // เฟรมสุดท้ายที่ตัวละครเดิมแสดงอยู่จริง
    val lo = maxOf(s.fromFrame, af) // เฟรมที่ฉบับแก้ไขเริ่มแสดง (เริ่มที่ 0)
    val canEdit = lo <= lastShown
    var scope by remember { mutableStateOf(if (lo < lastShown) EditScope.TO_END else EditScope.THIS) }
    var to by remember { mutableIntStateOf((lo + 2).coerceAtMost(lastShown + 1)) } // เลขเฟรมที่ผู้ใช้เห็น (เริ่มที่ 1)
    var error by remember { mutableStateOf<String?>(null) }

    val hi = when (scope) { // เฟรมสุดท้ายที่ใช้ฉบับแก้ไข (เริ่มที่ 0)
        EditScope.THIS -> lo
        EditScope.RANGE -> (to - 1).coerceIn(lo, lastShown)
        EditScope.TO_END -> lastShown
    }
    val toEnd = scope == EditScope.TO_END || hi >= lastShown
    val oldEnd = if (at < 0) "จนจบ" else "${at + 1}"
    val summary = buildString {
        if (canEdit) {
            if (lo > af) append("ฉบับเดิม: เฟรม ${af + 1}–$lo\n")
            append("ฉบับที่แก้: เฟรม ${lo + 1}–${if (toEnd) oldEnd else "${hi + 1}"}")
            if (!toEnd) append("\nฉบับเดิม (สำเนา): เฟรม ${hi + 2}–$oldEnd")
        } else {
            append("ตัวละครนี้แสดงเฟรม ${af + 1}–$oldEnd ไม่แสดงในเฟรม ${s.fromFrame + 1} ที่เปิดแก้ไข กลับไปเลือกเฟรมที่ตัวละครแสดงอยู่ก่อน")
        }
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
                Text("แก้ไขถึงเฟรมไหน?", fontWeight = FontWeight.Bold)
                Text(
                    "\"${s.name}\" · เริ่มแก้ที่เฟรม ${lo + 1}",
                    fontSize = 12.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
        },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                EditScopeCard("📍", "เฉพาะเฟรมนี้", "เฟรม ${lo + 1} เท่านั้น", scope == EditScope.THIS, enabled = canEdit) {
                    scope = EditScope.THIS
                    error = null
                }
                EditScopeCard("🎯", "ถึงเฟรมที่กำหนด", "เลือกเฟรมสุดท้ายที่ใช้ฉบับที่แก้", scope == EditScope.RANGE, enabled = canEdit && lo < lastShown) {
                    scope = EditScope.RANGE
                    to = to.coerceIn(lo + 2, lastShown + 1)
                    error = null
                }
                if (scope == EditScope.RANGE) {
                    Row(
                        Modifier.fillMaxWidth().padding(start = 8.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp),
                    ) {
                        Text("ถึงเฟรม", fontSize = 13.sp, color = EditNormalFg)
                        EditStepper(to, to > lo + 2, to < lastShown + 1, { to-- }, { to++ })
                    }
                }
                EditScopeCard("⏭", "ถึงเฟรมสุดท้าย", "เฟรม ${lo + 1}–$oldEnd", scope == EditScope.TO_END, enabled = canEdit) {
                    scope = EditScope.TO_END
                    error = null
                }
                Text(
                    summary,
                    fontSize = 12.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.padding(top = 4.dp),
                )
                Text(
                    "เฟรมนอกช่วงที่เลือกยังเป็นตัวละครเดิม (แยกเป็นตัวละครคนละตัวในแถบซ้าย) · กดย้อนกลับได้ทีเดียว",
                    fontSize = 11.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
                error?.let { Text(it, fontSize = 12.sp, color = Color(0xFFFF8A80)) }
            }
        },
        confirmButton = {
            Button(enabled = canEdit, onClick = {
                val err = vm.applyCharacterEdit(hi, toEnd)
                if (err != null) error = err // สำเร็จ = หน้าแก้ไขปิดเอง (vm.charEdit เป็น null)
            }) { Text("✔  แก้ไขเลย") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("กลับไปแก้ต่อ") } },
    )
}

@Composable
private fun EditScopeCard(icon: String, title: String, sub: String, selected: Boolean, enabled: Boolean = true, onClick: () -> Unit) {
    val shape = RoundedCornerShape(16.dp)
    Row(
        Modifier
            .fillMaxWidth()
            .alpha(if (enabled) 1f else 0.38f)
            .clip(shape)
            .background(if (selected) EditTonalBg else Palette.PanelHigh)
            .border(if (selected) 2.dp else 1.dp, if (selected) Palette.Accent else Palette.Stroke, shape)
            .clickable(enabled = enabled, onClick = onClick)
            .padding(horizontal = 14.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        Text(icon, fontSize = 20.sp)
        Column(Modifier.weight(1f)) {
            Text(title, fontSize = 14.sp, color = EditNormalFg, fontWeight = if (selected) FontWeight.Bold else FontWeight.Normal)
            Text(sub, fontSize = 11.sp, color = Color(0xFF9E9AB0))
        }
        if (selected) Text("✓", fontSize = 16.sp, color = Palette.Accent)
    }
}

@Composable
private fun EditStepButton(label: String, enabled: Boolean, onClick: () -> Unit) {
    Box(
        Modifier.size(36.dp).alpha(if (enabled) 1f else 0.38f).clickable(enabled = enabled, onClick = onClick),
        contentAlignment = Alignment.Center,
    ) { Text(label, fontSize = 20.sp, color = EditNormalFg) }
}

/** ตัวปรับเลขเฟรมแบบ − เลข + */
@Composable
private fun EditStepper(value: Int, minusEnabled: Boolean, plusEnabled: Boolean, onMinus: () -> Unit, onPlus: () -> Unit) {
    val shape = RoundedCornerShape(50)
    Row(
        Modifier.clip(shape).background(Color(0xFF1B1D22)).border(1.dp, Palette.Stroke, shape),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        EditStepButton("−", minusEnabled, onMinus)
        Text("$value", Modifier.width(36.dp), textAlign = TextAlign.Center, fontWeight = FontWeight.Bold, color = Palette.Accent)
        EditStepButton("+", plusEnabled, onPlus)
    }
}
