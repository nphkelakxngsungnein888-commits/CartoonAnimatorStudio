package com.nop.cartoonstudio

import android.graphics.Bitmap
import android.graphics.Path
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.defaultMinSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlin.math.cos
import kotlin.math.roundToInt
import kotlin.math.sin

/*
 * เครื่องมือบ่วง (คัดลอก / ตัด / วาง) ของหน้าแก้ไขภาพ + แผงปรับรูปตอนวาง (ขนาด · องศา · กุญแจล็อกสัดส่วน)
 * แยกมาไว้ไฟล์นี้ เพื่อไม่ให้ฟังก์ชันหน้าจอ ImageCropScreen ใหญ่ขึ้นอีก (เคยเจอ VerifyError ตอนเปิดหน้าเพราะฟังก์ชันใหญ่เกิน)
 * สถานะที่ต้องจำข้ามการวาดใหม่เก็บใน CropLayerUi (lassoClip, toolsOpen) · สถานะของรูปที่กำลังวางอยู่ใน Overlay (ImageCrop.kt)
 */

/** ส่วนที่คัดลอก/ตัดจากบ่วง: bmp = ภาพในกรอบที่ครอบบ่วง (นอกบ่วงโปร่งใส) · left/top = มุมซ้ายบนในพิกัดภาพเดิม (ไว้วางกลับที่เดิม) */
internal class LassoClip(val bmp: Bitmap, val left: Int, val top: Int)

/** ช่วงขนาดรูปที่วาง (เท่าของพิกเซลภาพ) ใช้ค่าเดียวกับตอนซูมด้วย 2 นิ้ว */
internal const val PASTE_SCALE_MIN = 0.02f
internal const val PASTE_SCALE_MAX = 20f

/**
 * คัดลอกส่วนของ src ที่อยู่ในบ่วง (ไม่แก้ src) · null = บ่วงอยู่นอกภาพ หรือในบ่วงไม่มีพิกเซลที่เห็นได้เลย
 * หมายเหตุ: ทำงานบน thread ที่เรียก (ภาพใหญ่มากอาจใช้เวลาหน่อย)
 */
internal fun lassoCopyOf(src: Bitmap, lassos: List<Path>): LassoClip? {
    if (lassos.isEmpty()) return null // cropByLassosAt ถ้าไม่มีบ่วงจะคืนภาพเดิมทั้งใบ ซึ่งที่นี่ไม่ต้องการ
    val r = cropByLassosAt(src, lassos) ?: return null
    val b = r.bmp
    val row = IntArray(b.width)
    var any = false
    for (y in 0 until b.height) { // ไล่ทีละแถว (ไม่ดึงพิกเซลทั้งภาพมาพร้อมกัน กันหน่วยความจำพอง) เจอพิกเซลที่เห็นได้ก็หยุด
        b.getPixels(row, 0, b.width, 0, y, b.width, 1)
        for (px in row) {
            if ((px ushr 24) != 0) {
                any = true
                break
            }
        }
        if (any) break
    }
    if (!any) {
        b.recycle() // b สร้างใหม่ใน cropByLassosAt (ไม่ใช่ src) ปล่อยได้
        return null
    }
    return LassoClip(b, r.left, r.top)
}

/** ทำมุมให้อยู่ในช่วง (-180, 180] */
internal fun normAngle(a: Float): Float {
    var r = a % 360f
    if (r > 180f) r -= 360f
    if (r <= -180f) r += 360f
    return r
}

/** กรอบรอบรูปที่กำลังวาง (หมุน/ยืดตามค่าปัจจุบัน) ในพิกัดจอ: จอ = ภาพ * vs + (offX, offY) */
internal fun overlayOutline(ov: Overlay, vs: Float, offX: Float, offY: Float): Path {
    val hw = ov.bmp.width * ov.scale / 2f
    val hh = ov.bmp.height * ov.scale * ov.ratio / 2f
    val rad = Math.toRadians(ov.angle.toDouble())
    val c = cos(rad).toFloat()
    val s = sin(rad).toFloat()
    val p = Path()
    val xs = floatArrayOf(-hw, hw, hw, -hw)
    val ys = floatArrayOf(-hh, -hh, hh, hh)
    for (i in 0 until 4) {
        val rx = xs[i] * c - ys[i] * s // หมุนตามเข็ม (แกน y ชี้ลง เหมือน Matrix.postRotate)
        val ry = xs[i] * s + ys[i] * c
        val sx = (ov.cx + rx) * vs + offX
        val sy = (ov.cy + ry) * vs + offY
        if (i == 0) p.moveTo(sx, sy) else p.lineTo(sx, sy)
    }
    p.close()
    return p
}

private fun round1(v: Float): Float = (v * 10f).roundToInt() / 10f

// ───────────────────────── แผงเครื่องมือบ่วง: คัดลอก / ตัด / วาง ─────────────────────────

private enum class ToolGlyph { COPY, CUT, PASTE }

/** แผงเล็กใต้ปุ่มเครื่องมือมุมบนขวา · คัดลอก/ตัด ใช้ได้เมื่อมีบ่วง · วาง ใช้ได้เมื่อเคยคัดลอก/ตัดไว้ */
@Composable
internal fun LassoToolsPanel(
    modifier: Modifier,
    hasLasso: Boolean,
    hasClip: Boolean,
    busy: Boolean,
    onCopy: () -> Unit,
    onCut: () -> Unit,
    onPaste: () -> Unit,
) {
    val shape = RoundedCornerShape(20.dp)
    Column(
        modifier
            .width(150.dp)
            .clip(shape)
            .background(Color(0xE6272734))
            .border(1.dp, Palette.Stroke, shape)
            .pointerInput(Unit) { detectTapGestures { } } // กันการแตะทะลุลงไปโดนภาพด้านหลัง
            .padding(8.dp),
        verticalArrangement = Arrangement.spacedBy(6.dp),
    ) {
        ToolRow(ToolGlyph.COPY, "คัดลอก", hasLasso && !busy, onCopy)
        ToolRow(ToolGlyph.CUT, "ตัด", hasLasso && !busy, onCut)
        ToolRow(ToolGlyph.PASTE, "วาง", hasClip && !busy, onPaste)
        if (!hasLasso) Text("วาดบ่วงก่อน จึงจะคัดลอก/ตัดได้", color = Color(0xFFC9C4D4), fontSize = 12.sp, modifier = Modifier.padding(horizontal = 4.dp))
    }
}

@Composable
private fun ToolRow(kind: ToolGlyph, label: String, enabled: Boolean, onClick: () -> Unit) {
    val shape = RoundedCornerShape(14.dp)
    Row(
        Modifier
            .fillMaxWidth()
            .defaultMinSize(minHeight = 42.dp)
            .alpha(if (enabled) 1f else 0.38f)
            .clip(shape)
            .background(Palette.PanelHigh)
            .border(1.dp, if (enabled) Palette.Accent.copy(alpha = 0.6f) else Palette.Stroke, shape)
            .clickable(enabled = enabled, onClick = onClick)
            .padding(horizontal = 12.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(10.dp),
    ) {
        Canvas(Modifier.size(20.dp)) { drawToolGlyph(kind, Color.White) }
        Text(label, color = Color.White, fontSize = 15.sp, fontWeight = FontWeight.Medium)
    }
}

private fun DrawScope.drawToolGlyph(kind: ToolGlyph, tint: Color) {
    val w = size.width
    val h = size.height
    val sw = w * 0.09f
    val round = StrokeCap.Round
    when (kind) {
        ToolGlyph.COPY -> { // กระดาษสองแผ่นซ้อนกัน
            drawRoundRect(tint, Offset(w * 0.08f, h * 0.08f), Size(w * 0.55f, h * 0.60f), CornerRadius(w * 0.08f), style = Stroke(sw))
            drawRoundRect(tint, Offset(w * 0.37f, h * 0.32f), Size(w * 0.55f, h * 0.60f), CornerRadius(w * 0.08f), style = Stroke(sw))
        }
        ToolGlyph.CUT -> { // กรรไกร
            drawCircle(tint, w * 0.13f, Offset(w * 0.26f, h * 0.80f), style = Stroke(sw))
            drawCircle(tint, w * 0.13f, Offset(w * 0.74f, h * 0.80f), style = Stroke(sw))
            drawLine(tint, Offset(w * 0.33f, h * 0.68f), Offset(w * 0.80f, h * 0.08f), sw, round)
            drawLine(tint, Offset(w * 0.67f, h * 0.68f), Offset(w * 0.20f, h * 0.08f), sw, round)
        }
        ToolGlyph.PASTE -> { // แผ่นรองเขียน + ที่หนีบ
            drawRoundRect(tint, Offset(w * 0.14f, h * 0.16f), Size(w * 0.72f, h * 0.78f), CornerRadius(w * 0.08f), style = Stroke(sw))
            drawRoundRect(tint, Offset(w * 0.34f, h * 0.05f), Size(w * 0.32f, h * 0.18f), CornerRadius(w * 0.05f))
            drawLine(tint, Offset(w * 0.30f, h * 0.50f), Offset(w * 0.70f, h * 0.50f), sw, round)
            drawLine(tint, Offset(w * 0.30f, h * 0.70f), Offset(w * 0.58f, h * 0.70f), sw, round)
        }
    }
}

// ───────────────────────── แผงปรับรูปตอนวาง: ขนาด · องศา · กุญแจ ─────────────────────────

/**
 * แผงลอยกลางล่างตอนกำลังวางรูป (ลากย้าย/2 นิ้วซูมหมุนทำที่ภาพ แผงนี้แสดงค่าและให้พิมพ์ค่าเอง)
 * ขนาดแสดงเป็น % เทียบตอนเริ่มวาง (100% = ขนาดตอนเริ่ม) · แตะค่าแล้วขึ้นแผงตัวเลข
 * กุญแจ: ล็อก = ช่องเดียว "ขนาด" ปรับแล้วกว้าง:สูงคงเดิม · ปลดล็อก = แยกช่อง "กว้าง" "สูง" ปรับอิสระ
 * (การซูมด้วย 2 นิ้วย่อ/ขยายทั้งสองด้านเท่ากัน คงสัดส่วนปัจจุบันเสมอ)
 */
@Composable
internal fun PasteControls(ov: Overlay, onChange: (Overlay) -> Unit, modifier: Modifier) {
    var pad by remember { mutableIntStateOf(0) } // 0 = ปิดแผงตัวเลข · 1 = ขนาด/กว้าง · 2 = สูง · 3 = องศา
    val widthPct = round1(ov.scale / ov.base * 100f)
    val heightPct = round1(ov.scale * ov.ratio / ov.base * 100f)
    val shape = RoundedCornerShape(22.dp)
    Column(
        modifier
            .clip(shape)
            .background(Color(0xE6272734))
            .border(1.dp, Palette.Stroke, shape)
            .pointerInput(Unit) { detectTapGestures { } } // กันการแตะ/ลากที่แผงทะลุไปย้ายรูป
            .padding(10.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp),
    ) {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            LockButton(ov.locked) { onChange(ov.copy(locked = !ov.locked)) }
            if (ov.locked) {
                ValueChip("ขนาด", padFmt(widthPct) + "%") { pad = 1 }
            } else {
                ValueChip("กว้าง", padFmt(widthPct) + "%") { pad = 1 }
                ValueChip("สูง", padFmt(heightPct) + "%") { pad = 2 }
            }
        }
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            ValueChip("องศา", padFmt(round1(normAngle(ov.angle))) + "°") { pad = 3 }
        }
    }
    when (pad) {
        1 -> FloatingPad(
            title = if (ov.locked) "ขนาด" else "ความกว้าง", unit = "%", initial = widthPct,
            onDismiss = { pad = 0 },
            onOk = { v ->
                val ns = (ov.base * v / 100f).coerceIn(PASTE_SCALE_MIN, PASTE_SCALE_MAX)
                if (ov.locked) onChange(ov.copy(scale = ns)) // ล็อก: สูงตามไปด้วย (ratio คงเดิม)
                else onChange(ov.copy(scale = ns, ratio = ov.scale * ov.ratio / ns)) // ปลดล็อก: เปลี่ยนแค่ความกว้าง ความสูงจริงคงเดิม
                pad = 0
            },
        )
        2 -> FloatingPad(
            title = "ความสูง", unit = "%", initial = heightPct,
            onDismiss = { pad = 0 },
            onOk = { v ->
                val nsy = (ov.base * v / 100f).coerceIn(PASTE_SCALE_MIN, PASTE_SCALE_MAX)
                onChange(ov.copy(ratio = nsy / ov.scale))
                pad = 0
            },
        )
        3 -> FloatingPad(
            title = "องศา", unit = "°", initial = round1(normAngle(ov.angle)),
            allowZero = true, allowSign = true,
            onDismiss = { pad = 0 },
            onOk = { v ->
                onChange(ov.copy(angle = normAngle(v)))
                pad = 0
            },
        )
    }
}

@Composable
private fun ValueChip(label: String, value: String, onClick: () -> Unit) {
    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
        Text(label, color = Color(0xFFC9C4D4), fontSize = 13.sp)
        Box(
            Modifier
                .clip(RoundedCornerShape(14.dp))
                .background(Palette.PanelHigh)
                .border(1.dp, Palette.Accent, RoundedCornerShape(14.dp))
                .clickable(onClick = onClick)
                .padding(horizontal = 12.dp, vertical = 9.dp),
        ) { Text("$value  ✎", color = Color.White, fontSize = 15.sp, fontWeight = FontWeight.Medium) }
    }
}

@Composable
private fun LockButton(locked: Boolean, onClick: () -> Unit) {
    Box(
        Modifier
            .size(44.dp)
            .clip(CircleShape)
            .background(if (locked) Palette.Accent.copy(alpha = 0.38f) else Color(0xE6272734))
            .border(if (locked) 2.dp else 1.dp, if (locked) Palette.Accent else Palette.Stroke, CircleShape)
            .clickable(onClick = onClick),
        contentAlignment = Alignment.Center,
    ) {
        Canvas(Modifier.size(24.dp)) { drawLockGlyph(locked, if (locked) Color.White else Color(0xFFD8D4E4)) }
    }
}

/** กุญแจ: ล็อก = ห่วงปิดสนิท · ปลดล็อก = ห่วงยกขึ้นและเปิดข้างซ้าย */
private fun DrawScope.drawLockGlyph(locked: Boolean, tint: Color) {
    val w = size.width
    val h = size.height
    val sw = w * 0.11f
    val round = StrokeCap.Round
    drawRoundRect(tint, Offset(w * 0.16f, h * 0.46f), Size(w * 0.68f, h * 0.46f), CornerRadius(w * 0.10f)) // ตัวกุญแจ
    val lift = if (locked) 0f else h * 0.07f
    drawArc(
        tint, 180f, 180f, false,
        topLeft = Offset(w * 0.28f, h * 0.08f - lift), size = Size(w * 0.44f, h * 0.44f),
        style = Stroke(sw, cap = round),
    ) // ห่วง
    drawLine(tint, Offset(w * 0.72f, h * 0.30f - lift), Offset(w * 0.72f, h * 0.48f), sw, round) // ขาขวาของห่วง
    if (locked) drawLine(tint, Offset(w * 0.28f, h * 0.30f), Offset(w * 0.28f, h * 0.48f), sw, round) // ขาซ้าย (ปลดล็อก = ไม่มี จึงดูเหมือนเปิดอยู่)
}
