package com.nop.cartoonstudio

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.BitmapShader
import android.graphics.DashPathEffect
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PathMeasure
import android.graphics.PorterDuff
import android.graphics.PorterDuffXfermode
import android.graphics.Rect
import android.graphics.RectF
import android.graphics.Region
import android.graphics.Shader
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.gestures.calculateCentroid
import androidx.compose.foundation.gestures.calculatePan
import androidx.compose.foundation.gestures.calculateRotation
import androidx.compose.foundation.gestures.calculateZoom
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.RowScope
import androidx.compose.foundation.layout.height
import androidx.compose.ui.draw.alpha
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.TextButton
import androidx.compose.material3.FilterChip
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.MutableState
import androidx.compose.runtime.State
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.runtime.withFrameNanos
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.drawIntoCanvas
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.input.pointer.positionChanged
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import kotlin.math.PI
import kotlin.math.ceil
import kotlin.math.cos
import kotlin.math.sin
import kotlin.math.floor
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt
import java.util.IdentityHashMap
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

private enum class CropMode { ADD, REMOVE, BEND, ERASE, JOY, CURVE, BRUSH }

/** แผงตัวเลขที่เปิดอยู่ตอนนี้ใช้ใส่ค่าอะไร */
private enum class PadTarget { NONE, ERASER, JOY_SPEED, BRUSH, BRUSH_COLOR }

/**
 * รูปที่เพิ่มเข้ามาซ้อนบนภาพที่กำลังแก้ (cx,cy = กึ่งกลางรูปในพิกัดภาพ, scale = ขนาดด้านกว้างเทียบพิกเซลภาพ) รอลาก/ย่อขยาย/หมุนแล้วกดวาง
 * angle = องศาที่หมุน (ตามเข็ม) · ratio = สูง÷กว้าง ของมาตราส่วน (1 = ไม่ยืด) · base = มาตราส่วนตอนเริ่มวาง (ไว้แสดงเป็น 100%) · locked = ล็อกสัดส่วนตอนพิมพ์ขนาด
 * move != null = ชิ้นที่ยกออกจากบ่วงด้วยปุ่ม "ย้าย" (ที่เดิมเจาะโปร่งใสไว้แล้ว) · frozen = ล็อกขนาด/องศา (เฉพาะโหมดย้าย) ยังลากย้ายได้
 * (internal ไม่ใช่ private เพราะแผงปรับค่าอยู่ใน CropPaste.kt)
 */
internal data class Overlay(
    val bmp: Bitmap, val cx: Float, val cy: Float, val scale: Float,
    val angle: Float = 0f, val ratio: Float = 1f, val base: Float = 1f, val locked: Boolean = true,
    val move: MoveInfo? = null, val frozen: Boolean = false,
)

/** สถานะ 1 ขั้นของประวัติ (ย้อนกลับ/ทำซ้ำ): บ่วง + ภาพที่ถูกลบด้วยยางลบแล้ว (บิตแมปที่ไม่เปลี่ยนใช้ตัวเดียวกันร่วมกัน) */
/**
 * ภาพของ 1 ก้าวย้อนกลับ: ก้าวใหม่เก็บเป็นบิตแมปตรงๆ ก้าวเก่าจะถูกบีบเป็น PNG ในหน่วยความจำ (ไม่ตัดทิ้ง)
 * แล้วคลายออกเมื่อย้อนกลับมาถึง จึงย้อนกลับ/ทำซ้ำได้ไม่จำกัดจำนวนครั้ง · ก้าวที่ใช้บิตแมปใบเดียวกันแชร์กล่องเดียว
 */
private class BmpBox(b: Bitmap) {
    private var ref: Bitmap? = b
    private var packed: ByteArray? = null

    @Synchronized
    fun get(): Bitmap {
        ref?.let { return it }
        val d = packed
        val opts = BitmapFactory.Options().apply {
            inMutable = true
            inPreferredConfig = Bitmap.Config.ARGB_8888
        }
        val b = (if (d != null) BitmapFactory.decodeByteArray(d, 0, d.size, opts) else null)
            ?: Bitmap.createBitmap(1, 1, Bitmap.Config.ARGB_8888)
        ref = b
        packed = null
        return b
    }

    @Synchronized
    fun isLive(): Boolean = ref != null

    @Synchronized
    fun pack() {
        val b = ref ?: return
        val out = java.io.ByteArrayOutputStream()
        if (b.compress(Bitmap.CompressFormat.PNG, 100, out)) {
            packed = out.toByteArray()
            ref = null
        }
    }
}

private class Snap(
    val lassos: List<Path>, bmp0: Bitmap,
    val order: List<Int>? = null, // ลำดับ id เลเยอร์ (ล่างสุด → บนสุด) · null = ไม่มีข้อมูลเลเยอร์
    val activeId: Int = 0, // เลเยอร์ที่เลือกอยู่ตอนนั้น (ภาพของเลเยอร์นี้คือ bmp0)
    val others: Map<Int, Bitmap> = emptyMap(), // ภาพของเลเยอร์อื่นๆ (บิตแมปที่ไม่เปลี่ยนใช้ตัวเดียวกันร่วมกัน)
) {
    val src = java.lang.ref.WeakReference(bmp0)
    var box = BmpBox(bmp0)
    val bmp: Bitmap get() = box.get()
}

/** จำนวนก้าวล่าสุดที่เก็บเป็นบิตแมปเต็ม (ก้าวที่เก่ากว่านี้ถูกบีบเก็บไว้ ไม่ตัดทิ้ง) */
private const val MAX_BITMAP_HISTORY = 12

/** จำนวนเลเยอร์สูงสุด (แต่ละชั้นเป็นบิตแมปเต็มผืนผ้าใบ กินหน่วยความจำ) */
private const val MAX_LAYERS = 12

private fun trimHistory(list: List<Snap>): List<Snap> {
    val boxes = java.util.IdentityHashMap<Bitmap, BmpBox>()
    for (s in list) {
        val bm = s.src.get() ?: continue
        s.box = boxes.getOrPut(bm) { s.box } // ก้าวที่ใช้บิตแมปใบเดียวกันแชร์กล่องเดียว
    }
    val seen = HashSet<BmpBox>()
    val toPack = ArrayList<BmpBox>()
    for (i in list.indices.reversed()) {
        val b = list[i].box
        if (seen.add(b) && seen.size > MAX_BITMAP_HISTORY && b.isLive()) toPack.add(b)
    }
    if (toPack.isNotEmpty()) Thread { toPack.forEach { it.pack() } }.start()
    return list
}

/** ตัวเลขสำหรับแสดง: ตัดศูนย์ท้ายทศนิยมทิ้ง (24.0 -> 24, 2.50 -> 2.5) */
private fun fmtNum(v: Float): String =
    runCatching { java.math.BigDecimal(v.toString()).stripTrailingZeros().toPlainString() }.getOrDefault(v.toString())

/** จุดควบคุมของบ่วง (ไว้ดัดโค้ง): contours = จุดของแต่ละเส้นขอบปิด (พิกัดภาพ), smooth = ต่อจุดเป็นเส้นโค้งเนียน, fillType = ชนิดการเติมของบ่วงเดิม (รักษารูโหว่) */
private class Ctrl(val contours: List<List<Offset>>, val smooth: Boolean, val fillType: Path.FillType)

/** จุดที่กำลังลากอยู่ตอนดัดโค้ง: orig = บ่วงเดิม, ctrl/preview = ผลระหว่างลาก (ยังไม่บันทึกลงประวัติจนกว่าจะปล่อยนิ้ว) */
private class BendDrag(val orig: Path, val ctrl: Ctrl, val preview: Path)

/** จุดควบคุมที่นิ้วแตะโดน: บ่วง path, เส้นขอบที่ c, จุดที่ p */
private class Hit(val path: Path, val c: Int, val p: Int)

/** เส้นขอบบ่วงที่ใกล้นิ้ว: seg = แทรกจุดใหม่ต่อจากจุดที่ seg, pt = จุดบนเส้น (พิกัดภาพ) */
private class EdgeHit(val path: Path, val c: Int, val seg: Int, val pt: Offset)

/** โหนดของโหมด "เส้นโค้ง": p = จุดยึด (anchor), hin/hout = เวกเตอร์จากจุดยึดไปจุดจับขาเข้า/ขาออก (handle) ตอนลากจุดจับสองฝั่งจะสมมาตรกัน */
private class BNode(val p: Offset, val hin: Offset, val hout: Offset)

/** เส้นโค้งเบซิเยร์ของบ่วง: contours = โหนดของแต่ละเส้นขอบปิด */
private class Bez(val contours: List<List<BNode>>, val fillType: Path.FillType)

/** ผลระหว่างลากโหนด/จุดจับของโหมดเส้นโค้ง (ยังไม่บันทึกลงประวัติจนกว่าจะปล่อยนิ้ว) */
private class CurveDrag(val orig: Path, val bez: Bez, val preview: Path)

/** สิ่งที่นิ้วแตะโดนในโหมดเส้นโค้ง: kind 0 = จุดยึด, 1 = จุดจับขาออก, 2 = จุดจับขาเข้า */
private class CHit(val path: Path, val c: Int, val i: Int, val kind: Int)

/** เส้นยางลบที่ลากค้างไว้ (ยังไม่กดตกลง): closed = false เป็นเส้นเปิด (ลบตามแนวเส้น) · true เป็นบ่วงปิด (ลบข้างใน) */
private class EBez(val nodes: List<BNode>, val closed: Boolean)

/** สิ่งที่นิ้วแตะโดนบนเส้นยางลบ: kind 0 = จุดยึด, 1 = จุดจับขาออก, 2 = จุดจับขาเข้า */
private class EHit(val i: Int, val kind: Int)

/** จำนวนช่วงที่หั่นเส้นโค้ง 1 ช่วงไว้หาจุดที่ใกล้นิ้ว */
private const val CURVE_STEPS = 24

private fun cubicPt(a: Offset, b: Offset, c: Offset, d: Offset, t: Float): Offset {
    val u = 1f - t
    val w0 = u * u * u
    val w1 = 3f * u * u * t
    val w2 = 3f * u * t * t
    val w3 = t * t * t
    return Offset(w0 * a.x + w1 * b.x + w2 * c.x + w3 * d.x, w0 * a.y + w1 * b.y + w2 * c.y + w3 * d.y)
}

/** แปลงบ่วงเป็นโหนดเบซิเยร์: จุดยึดมาจากจุดควบคุมเดิม จุดจับตั้งต้นให้เส้นเนียนผ่านทุกจุด (Catmull-Rom) */
private fun bezFromPath(p: Path, tol: Float): Bez {
    val cs = flattenToControls(p, tol)
    return Bez(
        cs.map { pts ->
            val n = pts.size
            pts.mapIndexed { i, q ->
                val a = pts[(i - 1 + n) % n]
                val b = pts[(i + 1) % n]
                val h = Offset((b.x - a.x) / 6f, (b.y - a.y) / 6f)
                BNode(q, Offset(-h.x, -h.y), h)
            }
        },
        p.fillType,
    )
}

/** แปลงจุดควบคุมของโหมดดัดโค้งเป็นโหนดเบซิเยร์ โดยเก็บทุกจุดไว้ครบ (จุดที่เพิ่มในดัดโค้งต้องมาในเส้นโค้งด้วย) · รูปร่างคงเดิม: smooth = Catmull-Rom, ไม่ smooth = จุดจับอยู่บนเส้นตรง 1/3 ช่วง */
private fun bezFromCtrl(c: Ctrl): Bez = Bez(
    c.contours.map { pts ->
        val n = pts.size
        pts.mapIndexed { i, q ->
            val a = pts[(i - 1 + n) % n]
            val b = pts[(i + 1) % n]
            if (c.smooth) {
                val h = Offset((b.x - a.x) / 6f, (b.y - a.y) / 6f)
                BNode(q, Offset(-h.x, -h.y), h)
            } else {
                BNode(q, Offset((a.x - q.x) / 3f, (a.y - q.y) / 3f), Offset((b.x - q.x) / 3f, (b.y - q.y) / 3f))
            }
        }
    },
    c.fillType,
)

/** แปลงโหนดเบซิเยร์กลับเป็นจุดควบคุมของโหมดดัดโค้ง (ใช้จุดยึดทุกจุด จุดที่เพิ่มในเส้นโค้งต้องมาในดัดโค้งด้วย) */
private fun ctrlFromBez(b: Bez): Ctrl {
    val curved = b.contours.any { ns -> ns.any { it.hin.getDistance() > 0.01f || it.hout.getDistance() > 0.01f } }
    return Ctrl(b.contours.map { ns -> ns.map { it.p } }, curved, b.fillType)
}

/** สร้างบ่วงจากโหนดเบซิเยร์ (cubicTo ต่อโหนดถึงโหนด ปิดเป็นวง) */
private fun buildBezPath(b: Bez): Path {
    val out = Path()
    out.fillType = b.fillType
    for (ns in b.contours) {
        if (ns.size < 3) continue
        out.moveTo(ns[0].p.x, ns[0].p.y)
        for (i in ns.indices) {
            val a = ns[i]
            val e = ns[(i + 1) % ns.size]
            out.cubicTo(a.p.x + a.hout.x, a.p.y + a.hout.y, e.p.x + e.hin.x, e.p.y + e.hin.y, e.p.x, e.p.y)
        }
        out.close()
    }
    return out
}

/** แปลงจุดที่ลากด้วยนิ้วเป็นโหนดเบซิเยร์ของเส้นยางลบ (เส้นเปิดใช้ Douglas-Peucker, บ่วงปิดใช้ simplifyClosed) */
private fun eBezFromPoints(raw: List<Offset>, closed: Boolean, tol: Float): EBez? {
    if (raw.size < 2) return null
    if (closed) {
        if (raw.size < 3) return null
        val pts = simplifyClosed(raw, tol)
        val n = pts.size
        return EBez(
            pts.mapIndexed { i, q ->
                val a = pts[(i - 1 + n) % n]
                val b = pts[(i + 1) % n]
                val h = Offset((b.x - a.x) / 6f, (b.y - a.y) / 6f)
                BNode(q, Offset(-h.x, -h.y), h)
            },
            true,
        )
    }
    val pts = rdpOpen(raw, tol)
    if (pts.size < 2) return null
    val n = pts.size
    return EBez(
        pts.mapIndexed { i, q ->
            val a = pts[max(i - 1, 0)]
            val b = pts[min(i + 1, n - 1)]
            val h = Offset((b.x - a.x) / 6f, (b.y - a.y) / 6f)
            BNode(q, Offset(-h.x, -h.y), h)
        },
        false,
    )
}

/** สร้างโหนดของเส้นยางลบ/พู่กันจากจุดยึดอย่างเดียว (ใช้ในโหมดดัดโค้ง): smooth = โค้งเนียนผ่านทุกจุด (Catmull-Rom) · ไม่ smooth = ต่อจุดด้วยเส้นตรง · เส้นเปิดไม่ต่อหัวท้าย */
private fun eBezFromCtrl(pts: List<Offset>, closed: Boolean, smooth: Boolean): EBez {
    val n = pts.size
    return EBez(
        pts.mapIndexed { i, q ->
            val a = if (closed) pts[(i - 1 + n) % n] else pts[max(i - 1, 0)]
            val b = if (closed) pts[(i + 1) % n] else pts[min(i + 1, n - 1)]
            if (smooth) {
                val h = Offset((b.x - a.x) / 6f, (b.y - a.y) / 6f)
                BNode(q, Offset(-h.x, -h.y), h)
            } else {
                BNode(q, Offset((a.x - q.x) / 3f, (a.y - q.y) / 3f), Offset((b.x - q.x) / 3f, (b.y - q.y) / 3f))
            }
        },
        closed,
    )
}

/** สร้างเส้นทางจากโหนดเส้นยางลบ (เส้นเปิดไม่ต่อหัวท้าย · บ่วงปิดต่อกลับจุดแรก) */
private fun buildEBezPath(e: EBez): Path {
    val out = Path()
    val ns = e.nodes
    if (ns.isEmpty()) return out
    out.moveTo(ns[0].p.x, ns[0].p.y)
    val segs = if (e.closed) ns.size else ns.size - 1
    for (i in 0 until segs) {
        val a = ns[i]
        val b = ns[(i + 1) % ns.size]
        out.cubicTo(a.p.x + a.hout.x, a.p.y + a.hout.y, b.p.x + b.hin.x, b.p.y + b.hin.y, b.p.x, b.p.y)
    }
    if (e.closed) out.close()
    return out
}

/** แทรกโหนดใหม่ในช่วงที่ i (ตำแหน่ง t) ด้วย de Casteljau: รูปเส้นเดิมไม่เปลี่ยน */
private fun splitBez(ns: List<BNode>, i: Int, t: Float): List<BNode> {
    val n = ns.size
    val ei = (i + 1) % n
    val a = ns[i]
    val e = ns[ei]
    val c1 = a.p + a.hout
    val c2 = e.p + e.hin
    fun lp(u: Offset, v: Offset) = Offset(u.x + (v.x - u.x) * t, u.y + (v.y - u.y) * t)
    val q0 = lp(a.p, c1)
    val q1 = lp(c1, c2)
    val q2 = lp(c2, e.p)
    val r0 = lp(q0, q1)
    val r1 = lp(q1, q2)
    val sp = lp(r0, r1)
    val out = ns.toMutableList()
    out[i] = BNode(a.p, a.hin, q0 - a.p)
    out[ei] = BNode(e.p, q2 - e.p, e.hout)
    out.add(i + 1, BNode(sp, r0 - sp, r1 - sp))
    return out
}

private fun projectOnSegment(p: Offset, a: Offset, b: Offset): Offset {
    val dx = b.x - a.x
    val dy = b.y - a.y
    val l2 = dx * dx + dy * dy
    if (l2 < 1e-9f) return a
    val t = (((p.x - a.x) * dx + (p.y - a.y) * dy) / l2).coerceIn(0f, 1f)
    return Offset(a.x + dx * t, a.y + dy * t)
}

/** ลดจำนวนจุดของเส้นด้วย Douglas-Peucker (ไม่ทำให้เส้นเรียบขึ้น จึงไม่กินซอกแคบ) */
private fun rdpOpen(pts: List<Offset>, eps: Float): List<Offset> {
    if (pts.size < 3) return pts
    val keep = BooleanArray(pts.size)
    keep[0] = true
    keep[pts.size - 1] = true
    val stack = ArrayDeque<IntArray>()
    stack.addLast(intArrayOf(0, pts.size - 1))
    while (stack.isNotEmpty()) {
        val seg = stack.removeLast()
        val a = seg[0]
        val b = seg[1]
        var maxD = 0f
        var idx = -1
        for (i in a + 1 until b) {
            val d = (pts[i] - projectOnSegment(pts[i], pts[a], pts[b])).getDistance()
            if (d > maxD) {
                maxD = d
                idx = i
            }
        }
        if (idx >= 0 && maxD > eps) {
            keep[idx] = true
            stack.addLast(intArrayOf(a, idx))
            stack.addLast(intArrayOf(idx, b))
        }
    }
    return pts.filterIndexed { i, _ -> keep[i] }
}

/** ลดจุดของเส้นขอบปิด (ได้อย่างน้อย 3 จุด และไม่เกิน ~80 จุด ให้ลากแก้ไหว) */
private fun simplifyClosed(raw: List<Offset>, eps0: Float): List<Offset> {
    var eps = eps0
    var out = rdpOpen(raw + raw[0], eps).dropLast(1)
    var guard = 0
    while (out.size > 80 && guard < 12) {
        eps *= 1.4f
        out = rdpOpen(raw + raw[0], eps).dropLast(1)
        guard++
    }
    if (out.size < 3) out = listOf(raw[0], raw[raw.size / 3], raw[raw.size * 2 / 3])
    return out
}

/** แตกบ่วง (Path) เป็นจุดควบคุมของแต่ละเส้นขอบ: เก็บแนวขอบเดิมไว้ ลดเหลือเฉพาะจุดที่จำเป็น tol = ความคลาดเคลื่อนที่ยอม (พิกเซลภาพ) */
private fun flattenToControls(p: Path, tol: Float): List<List<Offset>> {
    val pm = PathMeasure(p, true)
    val res = ArrayList<List<Offset>>()
    val pos = FloatArray(2)
    do {
        val len = pm.length
        if (len > 1f) {
            val n = (len / 2f).toInt().coerceIn(12, 800)
            val raw = ArrayList<Offset>(n)
            for (i in 0 until n) {
                pm.getPosTan(len * i / n, pos, null)
                raw.add(Offset(pos[0], pos[1]))
            }
            res.add(simplifyClosed(raw, tol))
        }
    } while (pm.nextContour())
    return res
}

/** สร้างบ่วงจากจุดควบคุม (smooth = เส้นโค้งเนียนผ่านทุกจุด ใช้สูตรเดียวกับเส้นทางเฟรม) */
private fun buildPath(c: Ctrl): Path {
    val out = Path()
    out.fillType = c.fillType
    for (pts in c.contours) {
        if (pts.size < 3) continue
        val d = PathMath.dense(pts, c.smooth, true).pts
        out.moveTo(d[0].x, d[0].y)
        for (i in 1 until d.size) out.lineTo(d[i].x, d[i].y)
        out.close()
    }
    return out
}

/** ระยะลากขั้นต่ำ (พิกเซลบนจอ) ที่ถือว่าเป็นการ "วาดบ่วง" ถ้าน้อยกว่านี้ถือเป็นการแตะ */
private const val MIN_STROKE_TRAVEL = 12f

/** จำนวนขั้นย้อนกลับสูงสุด */

// ───────────────────────── ตรรกะบ่วง (ไม่ผูกกับ UI) ─────────────────────────

private fun hasArea(p: Path): Boolean {
    if (p.isEmpty) return false
    val b = RectF()
    p.computeBounds(b, true)
    return b.width() > 1f && b.height() > 1f
}

private fun overlaps(a: Path, b: Path): Boolean {
    val r = Path()
    if (!r.op(a, b, Path.Op.INTERSECT)) return false
    return hasArea(r)
}

/** เพิ่มบ่วงใหม่: บ่วงที่ทับกันจะรวมเป็นบ่วงเดียว */
private fun addLasso(list: List<Path>, np: Path): List<Path> {
    var merged = np
    val rest = ArrayList<Path>()
    for (p in list) {
        if (overlaps(p, merged)) {
            val u = Path()
            if (u.op(p, merged, Path.Op.UNION)) merged = u else rest.add(p)
        } else {
            rest.add(p)
        }
    }
    rest.add(merged)
    return rest
}

/** ลบพื้นที่ของบ่วง [cut] ออกจากบ่วงที่มีอยู่ (บ่วงที่ไม่เหลือพื้นที่จะหายไป) */
private fun subtractLasso(list: List<Path>, cut: Path): List<Path> {
    val out = ArrayList<Path>()
    for (p in list) {
        if (!overlaps(p, cut)) {
            out.add(p)
            continue
        }
        val d = Path()
        if (d.op(p, cut, Path.Op.DIFFERENCE)) {
            if (hasArea(d)) out.add(d)
        } else {
            out.add(p)
        }
    }
    return out
}

private fun sameLassos(a: List<Path>, b: List<Path>): Boolean =
    a.size == b.size && a.indices.all { a[it] === b[it] }

private fun pathContains(p: Path, pt: Offset, w: Int, h: Int): Boolean {
    val r = Region()
    r.setPath(p, Region(0, 0, w, h))
    return r.contains(pt.x.toInt(), pt.y.toInt())
}

/**
 * ตัดภาพตามบ่วง: ได้ภาพขนาดเท่ากรอบที่ครอบบ่วงทั้งหมด ส่วนนอกบ่วงโปร่งใส
 * คืน null ถ้าบ่วงอยู่นอกภาพทั้งหมด (เรียกใน background thread)
 */
fun cropByLassos(src: Bitmap, lassos: List<Path>): Bitmap? = cropByLassosAt(src, lassos)?.bmp

/** ผลตัดภาพ: bmp = ภาพที่ตัดแล้ว, left/top = ตำแหน่งมุมซ้ายบนของภาพที่ตัดในพิกัดภาพเดิม (ไว้ชดเชยตำแหน่งตอนแก้ภาพที่วางอยู่แล้ว) */
class CropResult(val bmp: Bitmap, val left: Int, val top: Int)

fun cropByLassosAt(src: Bitmap, lassos: List<Path>): CropResult? {
    if (lassos.isEmpty()) return CropResult(src, 0, 0)
    val rect = RectF()
    val tmp = RectF()
    var first = true
    for (p in lassos) {
        p.computeBounds(tmp, true)
        if (first) {
            rect.set(tmp)
            first = false
        } else {
            rect.union(tmp)
        }
    }
    val l = floor(rect.left).toInt().coerceIn(0, src.width)
    val t = floor(rect.top).toInt().coerceIn(0, src.height)
    val r = ceil(rect.right).toInt().coerceIn(0, src.width)
    val b = ceil(rect.bottom).toInt().coerceIn(0, src.height)
    val w = r - l
    val h = b - t
    if (w < 1 || h < 1) return null

    val mask = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
    val mc = android.graphics.Canvas(mask)
    val fill = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.FILL
        color = android.graphics.Color.WHITE
    }
    mc.translate(-l.toFloat(), -t.toFloat())
    for (p in lassos) mc.drawPath(p, fill)

    val out = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
    val oc = android.graphics.Canvas(out)
    oc.drawBitmap(src, -l.toFloat(), -t.toFloat(), Paint(Paint.FILTER_BITMAP_FLAG))
    val dstIn = Paint().apply { xfermode = PorterDuffXfermode(PorterDuff.Mode.DST_IN) }
    oc.drawBitmap(mask, 0f, 0f, dstIn)
    mask.recycle()
    return CropResult(out, l, t)
}

// ───────────────────────── หน้าจอตัดภาพ ─────────────────────────

/**
 * หน้าตัดภาพตอนนำเข้า
 * - ลากนิ้วเดียววาดบ่วงรอบส่วนที่ต้องการ (ปล่อยนิ้วแล้วบ่วงปิดเอง) ขอบบ่วงเป็นเส้นปะ ขาว-ดำสลับกัน
 * - บ่วงที่วาดทับกันจะรวมเป็นบ่วงเดียว
 * - โหมด "เพิ่มบ่วง" / "ลบบ่วง" (ลบบ่วง: แตะในบ่วง = ลบทั้งบ่วง, วาดบ่วงทับ = ลบเฉพาะส่วนที่ทับ)
 * - ย้อนกลับ / ทำซ้ำ, ตกลง (ตัดแล้วนำเข้า), ยกเลิก (ไม่นำเข้าภาพนี้)
 * - 2 นิ้ว = ซูม/เลื่อนภาพเพื่อวาดละเอียด; ถ้าไม่วาดบ่วงเลย ตกลง = นำเข้าทั้งภาพ
 */
@Composable
fun ImageCropScreen(bitmap: Bitmap, onConfirm: (Bitmap, Int, Int) -> Unit, onCancel: () -> Unit, allowAddImage: Boolean = false) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val density = LocalDensity.current.density

    val bw = bitmap.width
    val bh = bitmap.height

    var mode by remember { mutableStateOf(CropMode.ADD) }
    var canvasSize by remember { mutableStateOf(IntSize.Zero) }
    var busy by remember { mutableStateOf(false) }

    // บ่วงที่ยืนยันแล้ว (พิกัดภาพ) — ไม่แก้ Path เดิม เปลี่ยนทั้งรายการเมื่อมีการแก้
    var lassos by remember { mutableStateOf<List<Path>>(emptyList()) }
    var undoStack by remember { mutableStateOf<List<Snap>>(emptyList()) }
    var redoStack by remember { mutableStateOf<List<Snap>>(emptyList()) }

    // ภาพที่กำลังแก้ (ยางลบแก้ที่สำเนาของภาพเสมอ ภาพต้นฉบับไม่ถูกแตะ); workVer = ตัวบอกให้วาดใหม่ตอนลบ (บิตแมปถูกแก้ในที่เดิมระหว่างลากนิ้ว)
    var work by remember { mutableStateOf(bitmap) }
    var workVer by remember { mutableIntStateOf(0) }
    // ── เลเยอร์ (กระดาษใสซ้อนกันแบบ ibisPaint): สถานะทั้งหมดรวมไว้ในก้อนเดียว (ดู CropLayerUi ใน CropLayers.kt) ──
    // รายการเรียงจากล่างสุด → บนสุด · เครื่องมือวาด/ลบทำกับเลเยอร์ที่เลือก · ภาพจริงของเลเยอร์ที่เลือกอยู่ที่ work (ค่าในรายการอาจเก่า
    // จนกว่าจะสลับเลเยอร์/เพิ่ม/ลบ/ย้าย ซึ่งจะเก็บ work กลับเข้ารายการก่อน) · ui.locked = เลเยอร์ที่ล็อก ยางลบ/พู่กัน/วางรูปแก้ไม่ได้
    val ui = remember { CropLayerUi(bitmap) }
    var eraserSize by remember { mutableFloatStateOf(24f) } // ขนาดยางลบ (เส้นผ่านศูนย์กลาง หน่วยพิกเซลของภาพ รองรับทศนิยม)
    var brushSize by remember { mutableFloatStateOf(12f) } // ขนาดพู่กัน (เส้นผ่านศูนย์กลาง หน่วยพิกเซลของภาพ รองรับทศนิยม)
    var brushColor by remember { mutableIntStateOf(android.graphics.Color.BLACK) } // สีพู่กัน (ARGB)
    var padTarget by remember { mutableStateOf(PadTarget.NONE) } // แผงตัวเลขเล็กมุมซ้ายล่าง: ใส่ค่าอะไรอยู่
    // สีที่เซฟไว้ (ปุ่มลอยลากย้ายได้) · โหมดลบสีที่เซฟ · โหมดดูดสี
    val savedColors = remember { mutableStateListOf<SavedColor>().also { it.addAll(SavedColorStore.load(context)) } }
    var colorDeleteMode by remember { mutableStateOf(false) } // กดปุ่มลบสีแล้ว: แตะปุ่มสีที่เซฟเพื่อเลือก แล้วกด "ตกลง" ถึงจะลบ
    var colorDeleteSel by remember { mutableStateOf<Set<Long>>(emptySet()) } // id ของสีที่เซฟที่เลือกไว้จะลบ
    var eyedropOn by remember { mutableStateOf(false) } // โหมดดูดสี: ลากนิ้วบนภาพ ปล่อยนิ้วแล้วคัดลอกสี
    var eyedropPos by remember { mutableStateOf<Offset?>(null) } // ตำแหน่งนิ้วบนจอ (ไว้วาดตัวอย่างสี)
    var eyedropColor by remember { mutableStateOf<Int?>(null) } // สีที่จุดใต้นิ้ว (null = โปร่งใส)
    val live = remember { mutableStateListOf<Offset>() } // บ่วงที่กำลังวาด (พิกัดภาพ)

    // มุมมอง: จอ = ภาพ * vs + off
    var vs by remember { mutableFloatStateOf(1f) }
    var off by remember { mutableStateOf(Offset.Zero) }

    // ดัดโค้งบ่วง: จุดควบคุมของแต่ละบ่วง (เก็บตามตัวบ่วง ย้อนกลับ/ทำซ้ำแล้วจุดตามบ่วงเดิมกลับมาด้วย)
    val ctrlCache = remember { IdentityHashMap<Path, Ctrl>() }
    val userCtrl = remember { IdentityHashMap<Path, Ctrl>() } // บ่วงที่ผู้ใช้แก้ในโหมดดัดโค้งแล้ว (จุดครบ) · ให้โหมดเส้นโค้งใช้จุดชุดเดียวกัน
    val userBez = remember { IdentityHashMap<Path, Bez>() } // บ่วงที่ผู้ใช้แก้ในโหมดเส้นโค้งแล้ว · ให้โหมดดัดโค้งใช้จุดชุดเดียวกัน
    var selPath by remember { mutableStateOf<Path?>(null) } // บ่วงที่เลือกจุดไว้
    var selC by remember { mutableIntStateOf(0) } // เส้นขอบที่เลือก
    var selP by remember { mutableIntStateOf(0) } // จุดที่เลือก (ไว้กดลบจุด)
    var bendDrag by remember { mutableStateOf<BendDrag?>(null) }
    var addPtMode by remember { mutableStateOf(false) } // โหมดเพิ่มจุด: แตะตรงไหนจุดใหม่ขึ้นตรงนิ้วตรงนั้น

    // โหมดเส้นโค้ง (จุดยึด + จุดจับ): โหนดเบซิเยร์ของแต่ละบ่วง เก็บตามตัวบ่วงเหมือนโหมดดัดโค้ง
    val bezCache = remember { IdentityHashMap<Path, Bez>() }
    var cPath by remember { mutableStateOf<Path?>(null) } // บ่วงที่เลือกโหนดไว้
    var cC by remember { mutableIntStateOf(0) } // เส้นขอบที่เลือก
    var cI by remember { mutableIntStateOf(0) } // โหนดที่เลือก
    var curveDrag by remember { mutableStateOf<CurveDrag?>(null) }

    // ยางลบแบบเส้น: ลากเป็นเส้นค้างไว้ (ยังไม่ลบ) ดัดด้วยโหมดเส้นโค้งได้ แล้วกด "ตกลง" ค่อยลบ
    var eraseLineMode by remember { mutableStateOf(false) } // false = ลบทันที (แบบเดิม) · true = ลากเป็นเส้น
    var eraseClosed by remember { mutableStateOf(false) } // false = เส้นเปิด · true = บ่วงปิด
    var eraseLine by remember { mutableStateOf<EBez?>(null) } // เส้นที่ลากค้างอยู่ (ของยางลบหรือพู่กัน)
    var lineOwner by remember { mutableStateOf(CropMode.ERASE) } // เครื่องมือที่เป็นเจ้าของเส้นที่ค้างอยู่: ยางลบ (ERASE) หรือ พู่กัน (BRUSH)
    var eSmooth by remember { mutableStateOf(true) } // ดัดโค้งเส้นที่ค้างอยู่: true = โค้งเนียนผ่านทุกจุด · false = ต่อจุดด้วยเส้นตรง
    var curveSub by remember { mutableStateOf(CropMode.BEND) } // โหมดย่อยล่าสุดของปุ่ม "เส้นโค้ง" (ดัดโค้ง / เส้นโค้ง) กดปุ่มซ้ำแล้วกลับมาโหมดเดิม
    var curvePaired by remember { mutableStateOf(false) } // จุดจับ: false = หมุนทีละจุด (ค่าเริ่มต้น) · true = สองฝั่งสมมาตรหมุนพร้อมกัน
    var eSel by remember { mutableIntStateOf(-1) } // โหนดที่เลือกบนเส้นยางลบ

    // โหมดจอย: แตะวางเป้า แล้วบังคับเป้าด้วยจอยซ้ายล่าง เป้าเดินแล้วทิ้งเส้นไว้ (ใช้ live เป็นเส้นทาง) จากนั้น "เอาตรงนี้" แตะบนเส้นเพื่อเลือกจุดที่จะเอา แล้ว "ปิดบ่วง"
    var joyPos by remember { mutableStateOf<Offset?>(null) } // ตำแหน่งเป้า (พิกัดภาพ) null = ยังไม่ได้วาง
    var joyHeld by remember { mutableStateOf(false) } // กำลังกดค้างปุ่ม "ไปหน้า" อยู่ (เป้าเดินไปตามทิศของจอย)
    val joyVec = remember { floatArrayOf(0f, -1f) } // ทิศที่จอยชี้ (เวกเตอร์หน่วย) ใช้ตอนกด "ไปหน้า" · ค้างไว้แม้ปล่อยนิ้วจากจอย
    val joyDir = remember { mutableStateOf(Offset(0f, -1f)) } // ทิศเดียวกัน แต่เป็น state ไว้ให้ลูกศรบนจอย/บนเป้าวาดใหม่ตามทันที (อ่านเฉพาะตอนวาด ไม่ทำให้หน้าจอคำนวณใหม่)
    var joySpeed by remember { mutableFloatStateOf(120f) } // ความเร็วเมื่อดันสุด (พิกเซลหน้าจอ/วินาที)
    var joyPick by remember { mutableStateOf(false) } // กด "เอาตรงนี้" แล้ว: แตะบนเส้นเพื่อเลือกจุด
    var joyMove by remember { mutableStateOf(false) } // เปิด = ลากจอยกับปุ่มไปหน้าไปวางตรงไหนก็ได้ (ปิด = ใช้งานปกติ)
    val joyOff = remember { mutableStateOf(Offset.Zero) }
    var showLoupeSettings by remember { mutableStateOf(false) } // หน้าต่างตั้งค่าแว่นขยาย (ขนาด + กำลังซูม)
    var eraseJoy by remember { mutableStateOf(false) } // ยางลบควบคุมด้วยจอย: จอยพาเป้ายางลบเดิน กด "ไปหน้า" = ลบตามทาง
    val strokeTool = mode == CropMode.ERASE || mode == CropMode.BRUSH // เครื่องมือเส้นของหน้านี้: ยางลบ / พู่กัน
    val joyUi = mode == CropMode.JOY || (strokeTool && eraseJoy) // แสดงจอย/ปุ่มไปหน้า/ช่องความเร็ว (ยางลบกับพู่กันใช้สวิตช์จอยตัวเดียวกัน)
    val lineCtx = eraseLine != null && (mode == CropMode.CURVE || mode == CropMode.BEND) // กำลังดัดเส้นที่ค้างอยู่ (ของยางลบหรือพู่กัน)
    val brushCtx = mode == CropMode.BRUSH || (lineCtx && lineOwner == CropMode.BRUSH) // บริบทตอนนี้เป็นของพู่กัน
    val strokeUi = strokeTool || lineCtx // แสดงแผงเครื่องมือฝั่งขวา
    val toolSize = if (brushCtx) brushSize else eraserSize // ขนาดของเครื่องมือเส้นที่ใช้อยู่
    val fwdOff = remember { mutableStateOf(Offset.Zero) }
    val speedOff = remember { mutableStateOf(Offset.Zero) }
    val pickOff = remember { mutableStateOf(Offset.Zero) }
    val closeOff = remember { mutableStateOf(Offset.Zero) }
    val resetOff = remember { mutableStateOf(Offset.Zero) }
    val opOff = remember { mutableStateOf(Offset.Zero) }
    var joyOp by remember { mutableStateOf(CropMode.ADD) } // บ่วงจากจอยเป็นแบบ เพิ่ม (ADD) หรือ ลบ (REMOVE)
    val joyPlaced by remember { derivedStateOf { joyPos != null } }
    val joyHasLine by remember { derivedStateOf { live.size >= 2 } }
    val joyCanClose by remember { derivedStateOf { live.size >= 3 } }

    var overlay by remember { mutableStateOf<Overlay?>(null) } // รูปที่เพิ่มเข้ามาและกำลังวางอยู่

    // แว่นขยายระหว่างลากนิ้ว: touch = ตำแหน่งนิ้วบนจอ (ไว้หลบ), lensImg = จุดบนภาพที่ขยายดู
    var touch by remember { mutableStateOf<Offset?>(null) }
    var lensImg by remember { mutableStateOf<Offset?>(null) }

    fun fitScale(): Float {
        if (canvasSize.width == 0 || canvasSize.height == 0) return 1f
        return min(canvasSize.width.toFloat() / bw, canvasSize.height.toFloat() / bh) * 0.96f
    }

    fun fitView() {
        if (canvasSize.width == 0 || canvasSize.height == 0) return
        val f = fitScale()
        vs = f
        off = Offset((canvasSize.width - bw * f) / 2f, (canvasSize.height - bh * f) / 2f)
    }

    var lastCanvas by remember { mutableStateOf(IntSize.Zero) } // ขนาดผืนผ้าใบครั้งก่อน: ขนาดเปลี่ยน (เช่น แผงปุ่มด้านล่างเปลี่ยนความสูงตามโหมด) ต้องคงซูมไว้ ไม่รีเซ็ต
    LaunchedEffect(canvasSize) {
        val old = lastCanvas
        if (canvasSize.width > 0 && canvasSize.height > 0) {
            if (old.width == 0 || old.height == 0) fitView() // ครั้งแรกเท่านั้นที่จัดให้พอดีจอ
            else off = Offset(off.x + (canvasSize.width - old.width) / 2f, off.y + (canvasSize.height - old.height) / 2f) // คงซูม รักษาจุดกึ่งกลางเดิม
            lastCanvas = canvasSize
        }
    }
    LaunchedEffect(mode) { // ออกจากยางลบ/เส้นโค้งแล้วเส้นยางลบที่ค้างอยู่เป็นอันยกเลิก
        if (mode != lineOwner && mode != CropMode.CURVE && mode != CropMode.BEND) {
            eraseLine = null
            eSel = -1
        }
    }

    fun toImg(o: Offset): Offset = Offset(
        ((o.x - off.x) / vs).coerceIn(0f, bw.toFloat()),
        ((o.y - off.y) / vs).coerceIn(0f, bh.toFloat()),
    )

    fun toScreen(p: Path): Path {
        val m = Matrix()
        m.setScale(vs, vs)
        m.postTranslate(off.x, off.y)
        val q = Path(p)
        q.transform(m)
        return q
    }

    // ── เลเยอร์: ฟังก์ชันช่วย ──
    /** บันทึก 1 ก้าวของประวัติ: บ่วง + ภาพของเลเยอร์ที่เลือก (bmp) + โครงสร้างเลเยอร์ทั้งหมด */
    fun snapOf(bmp: Bitmap): Snap =
        Snap(lassos, bmp, ui.layers.map { it.id }, ui.activeId, ui.layers.filter { it.id != ui.activeId }.associate { it.id to it.bmp })

    /** เก็บภาพที่กำลังแก้ (work) กลับเข้ารายการเลเยอร์ ก่อนสลับ/เพิ่ม/ลบ/ย้ายเลเยอร์ */
    fun commitWorkToLayer() {
        ui.layers = ui.layers.map { if (it.id == ui.activeId) LayerItem(it.id, work) else it }
    }

    /** ย้อนกลับ/ทำซ้ำ: คืนบ่วง + โครงสร้างเลเยอร์ + ภาพของเลเยอร์ที่เลือก (สถานะล็อกคงตามปัจจุบัน) */
    fun restoreSnap(sn: Snap) {
        val b = sn.bmp
        lassos = sn.lassos
        val order = sn.order
        if (order != null) {
            ui.layers = order.map { id -> LayerItem(id, if (id == sn.activeId) b else (sn.others[id] ?: b)) }
            ui.activeId = sn.activeId
            ui.locked = ui.locked.filter { it in order }.toSet()
        }
        work = b
        workVer++
    }

    fun pushLayerUndo() {
        undoStack = trimHistory(undoStack + snapOf(work))
        redoStack = emptyList()
    }

    /** ทำสำเนาภาพของเลเยอร์ที่เลือกไว้แก้ · เลเยอร์ที่ล็อกอยู่ได้ null (เครื่องมือที่เรียกจะหยุดและแจ้งผู้ใช้) */
    fun editCopy(): Bitmap? =
        if (ui.activeId in ui.locked) null else runCatching { work.copy(Bitmap.Config.ARGB_8888, true) }.getOrNull()

    fun selectLayer(id: Int) {
        if (id == ui.activeId || ui.layers.none { it.id == id }) return
        commitWorkToLayer()
        val target = ui.layers.first { it.id == id }
        ui.activeId = id
        work = target.bmp
        workVer++
    }

    fun addLayer() {
        if (ui.layers.size >= MAX_LAYERS) {
            QuickToast.show(context, "มีเลเยอร์ได้สูงสุด $MAX_LAYERS ชั้น")
            return
        }
        val nb = runCatching { Bitmap.createBitmap(bw, bh, Bitmap.Config.ARGB_8888) }.getOrNull()
        if (nb == null) {
            Toast.makeText(context, "หน่วยความจำไม่พอสำหรับเลเยอร์ใหม่", Toast.LENGTH_SHORT).show()
            return
        }
        pushLayerUndo()
        commitWorkToLayer()
        val id = ui.nextId
        ui.nextId = id + 1
        val at = ui.layers.indexOfFirst { it.id == ui.activeId } + 1
        ui.layers = ui.layers.toMutableList().also { it.add(at, LayerItem(id, nb)) } // เลเยอร์ใหม่ (โปร่งใส) วางเหนือเลเยอร์ที่เลือก
        ui.activeId = id
        work = nb
        workVer++
    }

    fun copyLayer() {
        val cp = runCatching { work.copy(Bitmap.Config.ARGB_8888, false) }.getOrNull()
        if (cp == null) {
            Toast.makeText(context, "หน่วยความจำไม่พอสำหรับคัดลอกเลเยอร์", Toast.LENGTH_SHORT).show()
            return
        }
        ui.clip = cp
        QuickToast.show(context, "คัดลอกเลเยอร์แล้ว")
    }

    fun pasteLayer() {
        val clip = ui.clip ?: return
        if (ui.layers.size >= MAX_LAYERS) {
            QuickToast.show(context, "มีเลเยอร์ได้สูงสุด $MAX_LAYERS ชั้น")
            return
        }
        val nb = runCatching { clip.copy(Bitmap.Config.ARGB_8888, true) }.getOrNull()
        if (nb == null) {
            Toast.makeText(context, "หน่วยความจำไม่พอสำหรับวางเลเยอร์", Toast.LENGTH_SHORT).show()
            return
        }
        pushLayerUndo()
        commitWorkToLayer()
        val id = ui.nextId
        ui.nextId = id + 1
        val at = ui.layers.indexOfFirst { it.id == ui.activeId } + 1
        ui.layers = ui.layers.toMutableList().also { it.add(at, LayerItem(id, nb)) }
        ui.activeId = id
        work = nb
        workVer++
    }

    fun deleteLayer() {
        if (ui.layers.size <= 1) {
            QuickToast.show(context, "ต้องมีอย่างน้อย 1 เลเยอร์")
            return
        }
        pushLayerUndo()
        commitWorkToLayer()
        val i = ui.layers.indexOfFirst { it.id == ui.activeId }
        val rest = ui.layers.filter { it.id != ui.activeId }
        val next = rest[(i - 1).coerceIn(0, rest.size - 1)] // เลือกเลเยอร์ที่อยู่ใต้ลบไป (ถ้าลบชั้นล่างสุด เลือกชั้นที่ขึ้นมาแทน)
        ui.locked = ui.locked - ui.activeId
        ui.layers = rest
        ui.activeId = next.id
        work = next.bmp
        workVer++
    }

    fun toggleLayerLock(id: Int) {
        ui.locked = if (id in ui.locked) ui.locked - id else ui.locked + id
    }

    /** เลื่อนเลเยอร์ขึ้น (up = true) หรือลง หนึ่งชั้น · คืน true ถ้าเลื่อนได้ */
    fun moveLayer(id: Int, up: Boolean): Boolean {
        val i = ui.layers.indexOfFirst { it.id == id }
        val j = if (up) i + 1 else i - 1
        if (i < 0 || j < 0 || j >= ui.layers.size) return false
        pushLayerUndo()
        commitWorkToLayer()
        val m = ui.layers.toMutableList()
        val t = m[i]
        m[i] = m[j]
        m[j] = t
        ui.layers = m
        return true
    }

    /** รวมทุกเลเยอร์เป็นภาพเดียวตามลำดับซ้อน (เลเยอร์เดียว = ใช้ภาพที่แก้อยู่เลย) · null = หน่วยความจำไม่พอ */
    fun flattenLayers(): Bitmap? {
        if (ui.layers.size <= 1) return work
        val out = runCatching { Bitmap.createBitmap(bw, bh, Bitmap.Config.ARGB_8888) }.getOrNull() ?: return null
        val cv = android.graphics.Canvas(out)
        for (ly in ui.layers) cv.drawBitmap(if (ly.id == ui.activeId) work else ly.bmp, 0f, 0f, null)
        return out
    }

    fun commit(newList: List<Path>) {
        if (sameLassos(newList, lassos)) return
        undoStack = trimHistory(undoStack + snapOf(work))
        redoStack = emptyList()
        lassos = newList
    }

    fun undo() {
        val prev = undoStack.lastOrNull() ?: return
        redoStack = redoStack + snapOf(work)
        restoreSnap(prev)
        undoStack = undoStack.dropLast(1)
    }

    fun redo() {
        val next = redoStack.lastOrNull() ?: return
        undoStack = trimHistory(undoStack + snapOf(work))
        restoreSnap(next)
        redoStack = redoStack.dropLast(1)
    }

    /** แปลงตำแหน่งจอเป็นพิกัดภาพแบบไม่ตัดขอบ (ยางลบลากเลยขอบภาพได้) */
    fun toImgRaw(o: Offset): Offset = Offset((o.x - off.x) / vs, (o.y - off.y) / vs)

    /** สีของพิกเซลบนภาพที่กำลังแก้ ณ ตำแหน่งจอ p (รวมรอยพู่กันที่ระบายแล้ว) · null = นอกภาพ หรือโปร่งใส */
    fun sampleColorAt(p: Offset): Int? {
        val r = toImgRaw(p)
        if (r.x < 0f || r.y < 0f) return null
        val x = r.x.toInt()
        val y = r.y.toInt()
        for (ly in ui.layers.asReversed()) { // ไล่จากเลเยอร์บนสุดลงมา เอาสีแรกที่ไม่โปร่งใส (เหมือนที่ตาเห็น)
            val bm = if (ly.id == ui.activeId) work else ly.bmp
            if (x >= bm.width || y >= bm.height) continue
            val c = try { bm.getPixel(x, y) } catch (_: Exception) { continue }
            if ((c ushr 24) >= 16) return c or (0xFF shl 24) // โปร่งใสเกือบหมด = ไม่มีสีให้ดูด
        }
        return null
    }

    fun cancelColorModes() {
        eyedropOn = false
        eyedropPos = null
        eyedropColor = null
        colorDeleteMode = false
        colorDeleteSel = emptySet()
    }

    /** เซฟสีพู่กันตอนนี้เป็นปุ่มลอย วางที่ช่องว่างช่องแรกด้านซ้ายของแผงเครื่องมือขวา (ลากย้ายภายหลังได้) */
    fun saveCurrentColor() {
        val c = brushColor or (0xFF shl 24)
        if (savedColors.any { it.color == c }) {
            QuickToast.show(context, "มีสีนี้อยู่ในรายการที่เซฟแล้ว")
            return
        }
        if (savedColors.size >= SAVED_COLOR_MAX) {
            QuickToast.show(context, "เซฟได้สูงสุด $SAVED_COLOR_MAX สี ลบบางสีก่อน")
            return
        }
        val wDp = canvasSize.width / density
        val hDp = canvasSize.height / density
        val rows = max(1, ((hDp - 74f - 150f) / 52f).toInt())
        var col = 0
        var row = 0
        var x = 0f
        var y = 0f
        while (col <= 8) {
            x = (wDp - 112f - col * 52f).coerceAtLeast(0f)
            y = 74f + row * 52f
            val taken = savedColors.any { kotlin.math.abs(it.xDp - x) < 24f && kotlin.math.abs(it.yDp - y) < 24f }
            if (!taken) break
            row++
            if (row >= rows) { row = 0; col++ }
        }
        var id = System.currentTimeMillis()
        while (savedColors.any { it.id == id }) id++
        savedColors.add(SavedColor(id, c, x, y))
        SavedColorStore.save(context, savedColors)
        QuickToast.show(context, "เซฟสีแล้ว · ลากปุ่มไปวางตรงไหนก็ได้")
    }

    fun confirmDeleteColors() {
        val n = colorDeleteSel.size
        if (n > 0) {
            savedColors.removeAll { it.id in colorDeleteSel }
            SavedColorStore.save(context, savedColors)
            QuickToast.show(context, "ลบสีที่เซฟแล้ว $n สี")
        }
        colorDeleteSel = emptySet()
        colorDeleteMode = false
    }

    fun ctrlOf(p: Path): Ctrl = ctrlCache.getOrPut(p) { userBez[p]?.let { ctrlFromBez(it) } ?: Ctrl(flattenToControls(p, 5f / max(vs, 0.01f)), false, p.fillType) }

    fun selValid(): Path? = selPath?.takeIf { sp -> lassos.any { it === sp } }

    /** แทนเส้นขอบ ci ของบ่วง orig ด้วยจุดชุดใหม่ แล้วบันทึกลงประวัติ (ย้อนกลับได้) */
    fun replaceContour(orig: Path, ci: Int, pts: List<Offset>, newSelP: Int) {
        val ct = ctrlOf(orig)
        val nc = Ctrl(ct.contours.mapIndexed { i, l -> if (i == ci) pts else l }, ct.smooth, ct.fillType)
        val np = buildPath(nc)
        ctrlCache[np] = nc
        userCtrl[np] = nc
        commit(lassos.map { if (it === orig) np else it })
        selPath = np
        selC = ci
        selP = newSelP
    }

    fun hitHandle(pos: Offset): Hit? {
        var best: Hit? = null
        var bestD = 24f * density
        for (lp in lassos) {
            val ct = ctrlOf(lp)
            for (ci in ct.contours.indices) {
                val pts = ct.contours[ci]
                for (pi in pts.indices) {
                    val q = pts[pi]
                    val d = (Offset(q.x * vs + off.x, q.y * vs + off.y) - pos).getDistance()
                    if (d < bestD) {
                        bestD = d
                        best = Hit(lp, ci, pi)
                    }
                }
            }
        }
        return best
    }

    /** หาเส้นขอบบ่วงที่ใกล้ตำแหน่งนิ้วที่สุด (ภายใน radius พิกเซลจอ): คืนบ่วง เส้นขอบ ช่วงที่ต้องแทรกต่อท้าย และจุดบนเส้น (พิกัดภาพ) */
    fun findEdge(pos: Offset, radius: Float): EdgeHit? {
        var bestD = radius
        var best: EdgeHit? = null
        for (lp in lassos) {
            val ct = ctrlOf(lp)
            for (ci in ct.contours.indices) {
                val d = PathMath.dense(ct.contours[ci], ct.smooth, true)
                for (i in 0 until d.pts.size - 1) {
                    val a = d.pts[i]
                    val b = d.pts[i + 1]
                    val proj = projectOnSegment(
                        pos,
                        Offset(a.x * vs + off.x, a.y * vs + off.y),
                        Offset(b.x * vs + off.x, b.y * vs + off.y),
                    )
                    val dist = (pos - proj).getDistance()
                    if (dist < bestD) {
                        bestD = dist
                        best = EdgeHit(lp, ci, d.seg[i], Offset((proj.x - off.x) / vs, (proj.y - off.y) / vs))
                    }
                }
            }
        }
        return best
    }

    /** แตะใกล้เส้นขอบบ่วง = แทรกจุดควบคุมบนเส้นตรงนั้น (คืน false ถ้าไม่ได้แตะใกล้เส้น) */
    fun insertPointAt(pos: Offset): Boolean {
        val e = findEdge(pos, 20f * density) ?: return false
        val list = ctrlOf(e.path).contours[e.c].toMutableList()
        list.add(e.seg + 1, e.pt)
        replaceContour(e.path, e.c, list, e.seg + 1)
        return true
    }

    /**
     * โหมด "เพิ่มจุด": แตะที่ไหน จุดใหม่ก็ขึ้น ณ ตำแหน่งนิ้วตรงนั้น (แทรกในช่วงของเส้นบ่วงที่ใกล้นิ้วที่สุด) แล้วลากต่อเพื่อวางได้เลย
     * ยังไม่บันทึกลงประวัติ: ปล่อยนิ้วแล้วจึงบันทึกครั้งเดียว (ย้อนกลับครั้งเดียวได้ทั้งเพิ่ม+ย้าย)
     */
    fun beginAddAtFinger(pos: Offset): Hit? {
        val e = findEdge(pos, 60f * density) ?: return null
        val ct = ctrlOf(e.path)
        val list = ct.contours[e.c].toMutableList()
        list.add(e.seg + 1, toImg(pos))
        val nc = Ctrl(ct.contours.mapIndexed { i, l -> if (i == e.c) list else l }, ct.smooth, ct.fillType)
        bendDrag = BendDrag(e.path, nc, buildPath(nc))
        return Hit(e.path, e.c, e.seg + 1)
    }

    /** ปุ่ม "ลบจุด": ลบจุดควบคุมที่เลือก (ต้องเหลืออย่างน้อย 3 จุด) */
    fun deleteSelectedPoint() {
        val sp = selValid() ?: return
        val pts = ctrlOf(sp).contours.getOrNull(selC) ?: return
        if (pts.size <= 3 || selP !in pts.indices) {
            Toast.makeText(context, "ต้องเหลืออย่างน้อย 3 จุด", Toast.LENGTH_SHORT).show()
            return
        }
        replaceContour(sp, selC, pts.toMutableList().also { it.removeAt(selP) }, 0)
        selPath = null
    }

    /** ปุ่ม "โค้งเนียน": สลับบ่วงที่เลือกระหว่างต่อจุดเป็นเส้นตรง / เส้นโค้งเนียน */
    fun toggleSmooth() {
        val sp = selValid() ?: return
        val ct = ctrlOf(sp)
        val nc = Ctrl(ct.contours, !ct.smooth, ct.fillType)
        val np = buildPath(nc)
        ctrlCache[np] = nc
        userCtrl[np] = nc
        commit(lassos.map { if (it === sp) np else it })
        selPath = np
    }

    // ───── โหมดเส้นโค้ง ─────
    fun bezOf(p: Path): Bez = bezCache.getOrPut(p) { userCtrl[p]?.let { bezFromCtrl(it) } ?: bezFromPath(p, 5f / max(vs, 0.01f)) }

    fun cValid(): Path? = cPath?.takeIf { sp -> lassos.any { it === sp } }

    /** แตะโดนอะไร: จุดจับของโหนดที่เลือกอยู่ก่อน (ถ้านิ้วใกล้จุดจับกว่าจุดยึด) แล้วค่อยจุดยึดของทุกบ่วง */
    fun hitCurve(pos: Offset): CHit? {
        fun scr(q: Offset) = Offset(q.x * vs + off.x, q.y * vs + off.y)
        val sp = cValid()
        if (sp != null) {
            val n = bezOf(sp).contours.getOrNull(cC)?.getOrNull(cI)
            if (n != null) {
                val dOut = (scr(n.p + n.hout) - pos).getDistance()
                val dIn = (scr(n.p + n.hin) - pos).getDistance()
                val dA = (scr(n.p) - pos).getDistance()
                val dH = min(dOut, dIn)
                if (dH < 22f * density && dH <= dA) return CHit(sp, cC, cI, if (dOut <= dIn) 1 else 2)
            }
        }
        var best: CHit? = null
        var bestD = 24f * density
        for (lp in lassos) {
            val b = bezOf(lp)
            for (ci in b.contours.indices) {
                for (i in b.contours[ci].indices) {
                    val d = (scr(b.contours[ci][i].p) - pos).getDistance()
                    if (d < bestD) {
                        bestD = d
                        best = CHit(lp, ci, i, 0)
                    }
                }
            }
        }
        return best
    }

    /** บันทึกบ่วงที่แก้เป็นโหนดใหม่ลงประวัติ (ย้อนกลับได้) คืนบ่วงใหม่ */
    fun commitBez(orig: Path, nb: Bez): Path {
        val np = buildBezPath(nb)
        bezCache[np] = nb
        userBez[np] = nb
        commit(lassos.map { if (it === orig) np else it })
        return np
    }

    /** แตะใกล้เส้นโค้ง = แทรกจุดยึดบนเส้นตรงนั้น (รูปเส้นไม่เปลี่ยน) คืน false ถ้าไม่ได้แตะใกล้เส้น */
    fun insertCurveNodeAt(pos: Offset): Boolean {
        var bestD = 22f * density
        var bp: Path? = null
        var bc = 0
        var bi = 0
        var bt = 0f
        for (lp in lassos) {
            val b = bezOf(lp)
            for (ci in b.contours.indices) {
                val ns = b.contours[ci]
                for (i in ns.indices) {
                    val a = ns[i]
                    val e = ns[(i + 1) % ns.size]
                    val c1 = a.p + a.hout
                    val c2 = e.p + e.hin
                    var prev = Offset(a.p.x * vs + off.x, a.p.y * vs + off.y)
                    for (k in 1..CURVE_STEPS) {
                        val q = cubicPt(a.p, c1, c2, e.p, k / CURVE_STEPS.toFloat())
                        val sc = Offset(q.x * vs + off.x, q.y * vs + off.y)
                        val proj = projectOnSegment(pos, prev, sc)
                        val d = (pos - proj).getDistance()
                        if (d < bestD) {
                            bestD = d
                            bp = lp
                            bc = ci
                            bi = i
                            val sl = (sc - prev).getDistance()
                            val fr = if (sl < 1e-6f) 0f else (proj - prev).getDistance() / sl
                            bt = (k - 1 + fr) / CURVE_STEPS
                        }
                        prev = sc
                    }
                }
            }
        }
        val path = bp ?: return false
        val b = bezOf(path)
        val ns = splitBez(b.contours[bc], bi, bt)
        val nb = Bez(b.contours.mapIndexed { i, l -> if (i == bc) ns else l }, b.fillType)
        cPath = commitBez(path, nb)
        cC = bc
        cI = bi + 1
        return true
    }

    fun hitE(pos: Offset): EHit? {
        val el = eraseLine ?: return null
        fun scr(q: Offset) = Offset(q.x * vs + off.x, q.y * vs + off.y)
        val sn = el.nodes.getOrNull(eSel)
        if (sn != null) {
            val dOut = (scr(sn.p + sn.hout) - pos).getDistance()
            val dIn = (scr(sn.p + sn.hin) - pos).getDistance()
            val dA = (scr(sn.p) - pos).getDistance()
            val dH = min(dOut, dIn)
            if (dH < 22f * density && dH <= dA) return EHit(eSel, if (dOut <= dIn) 1 else 2)
        }
        var best: EHit? = null
        var bestD = 24f * density
        for (i in el.nodes.indices) {
            val d = (scr(el.nodes[i].p) - pos).getDistance()
            if (d < bestD) {
                bestD = d
                best = EHit(i, 0)
            }
        }
        return best
    }

    /** แตะใกล้เส้นยางลบ = แทรกจุดยึดบนเส้นตรงนั้น (รูปเส้นไม่เปลี่ยน) */
    fun insertEraseNodeAt(pos: Offset): Boolean {
        val el = eraseLine ?: return false
        val ns = el.nodes
        val segs = if (el.closed) ns.size else ns.size - 1
        var bestD = 22f * density
        var bi = -1
        var bt = 0f
        for (i in 0 until segs) {
            val a = ns[i]
            val e = ns[(i + 1) % ns.size]
            val c1 = a.p + a.hout
            val c2 = e.p + e.hin
            var prev = Offset(a.p.x * vs + off.x, a.p.y * vs + off.y)
            for (k in 1..CURVE_STEPS) {
                val q = cubicPt(a.p, c1, c2, e.p, k / CURVE_STEPS.toFloat())
                val sc = Offset(q.x * vs + off.x, q.y * vs + off.y)
                val proj = projectOnSegment(pos, prev, sc)
                val d = (pos - proj).getDistance()
                if (d < bestD) {
                    bestD = d
                    bi = i
                    val sl = (sc - prev).getDistance()
                    val fr = if (sl < 1e-6f) 0f else (proj - prev).getDistance() / sl
                    bt = (k - 1 + fr) / CURVE_STEPS
                }
                prev = sc
            }
        }
        if (bi < 0) return false
        eraseLine = EBez(splitBez(ns, bi, bt), el.closed)
        eSel = bi + 1
        return true
    }

    /** ปุ่มถังขยะตอนดัดเส้นยางลบ: ลบจุดยึดที่เลือก (เส้นเปิดเหลืออย่างน้อย 2 จุด · บ่วงปิดอย่างน้อย 3 จุด) */
    fun deleteEraseNode() {
        val el = eraseLine ?: return
        val minN = if (el.closed) 3 else 2
        if (el.nodes.size <= minN || eSel !in el.nodes.indices) {
            Toast.makeText(context, "ต้องเหลืออย่างน้อย $minN จุด", Toast.LENGTH_SHORT).show()
            return
        }
        val nn = el.nodes.toMutableList().also { it.removeAt(eSel) }
        eraseLine = if (mode == CropMode.BEND) eBezFromCtrl(nn.map { it.p }, el.closed, eSmooth) else EBez(nn, el.closed)
        eSel = -1
    }

    /** ปุ่ม ＋ จุด: เพิ่มจุดยึดตรงกลางช่วงถัดจากจุดที่เลือก (ไม่ได้เลือก = ช่วงที่ยาวที่สุด) แล้วเข้าโหมดดัดเส้นให้ลากได้ทันที */
    fun addEraseNode() {
        val el = eraseLine ?: return
        val ns = el.nodes
        val segs = if (el.closed) ns.size else ns.size - 1
        if (segs < 1) return
        var bi = if (eSel in 0 until segs) eSel else -1
        if (bi < 0) {
            var best = -1f
            for (i in 0 until segs) {
                val d = (ns[(i + 1) % ns.size].p - ns[i].p).getDistance()
                if (d > best) { best = d; bi = i }
            }
        }
        eraseLine = EBez(splitBez(ns, bi, 0.5f), el.closed)
        eSel = bi + 1
        mode = CropMode.CURVE
    }

    /** ดัดโค้งเส้นที่ค้างอยู่: จุดยึดที่ใกล้นิ้วที่สุด (ภายใน 24dp) คืนลำดับโหนด หรือ -1 ถ้าไม่โดนจุดไหน */
    fun hitEAnchor(pos: Offset): Int {
        val el = eraseLine ?: return -1
        var best = -1
        var bestD = 24f * density
        for (i in el.nodes.indices) {
            val q = el.nodes[i].p
            val d = (Offset(q.x * vs + off.x, q.y * vs + off.y) - pos).getDistance()
            if (d < bestD) {
                bestD = d
                best = i
            }
        }
        return best
    }

    /** หาช่วงของเส้นที่ค้างอยู่ที่ใกล้นิ้วที่สุดภายใน radius พิกเซลจอ: คืนลำดับช่วง (ช่วง i = โหนด i ถึงโหนดถัดไป) หรือ -1 */
    fun nearestEraseSeg(pos: Offset, radius: Float): Int {
        val el = eraseLine ?: return -1
        val ns = el.nodes
        val segs = if (el.closed) ns.size else ns.size - 1
        var bestD = radius
        var bi = -1
        for (i in 0 until segs) {
            val a = ns[i]
            val e = ns[(i + 1) % ns.size]
            val c1 = a.p + a.hout
            val c2 = e.p + e.hin
            var prev = Offset(a.p.x * vs + off.x, a.p.y * vs + off.y)
            for (k in 1..CURVE_STEPS) {
                val q = cubicPt(a.p, c1, c2, e.p, k / CURVE_STEPS.toFloat())
                val sc = Offset(q.x * vs + off.x, q.y * vs + off.y)
                val d = (pos - projectOnSegment(pos, prev, sc)).getDistance()
                if (d < bestD) {
                    bestD = d
                    bi = i
                }
                prev = sc
            }
        }
        return bi
    }

    /** โหมดเพิ่มจุดของดัดโค้ง (เส้นที่ค้างอยู่): จุดใหม่ขึ้นตรงนิ้ว แทรกในช่วงที่ใกล้นิ้วที่สุด คืนลำดับโหนดใหม่ หรือ -1 ถ้าไม่มีเส้นอยู่ใกล้ */
    fun beginAddOnLine(pos: Offset): Int {
        val el = eraseLine ?: return -1
        val bi = nearestEraseSeg(pos, 60f * density)
        if (bi < 0) return -1
        val pts = el.nodes.map { it.p }.toMutableList()
        pts.add(bi + 1, toImg(pos))
        eraseLine = eBezFromCtrl(pts, el.closed, eSmooth)
        eSel = bi + 1
        return bi + 1
    }

    /** ปุ่ม ⌒ ของดัดโค้ง (เส้นที่ค้างอยู่): สลับระหว่างต่อจุดด้วยเส้นตรง / โค้งเนียนผ่านทุกจุด */
    fun toggleEraseSmooth() {
        val el = eraseLine ?: return
        eSmooth = !eSmooth
        eraseLine = eBezFromCtrl(el.nodes.map { it.p }, el.closed, eSmooth)
    }

    /** ลากนิ้วเสร็จในโหมดยางลบแบบเส้น: ทำเป็นเส้นค้างไว้ (ยังไม่ลบ) */
    fun finishEraseLine(pts: List<Offset>, travel: Float, owner: CropMode) {
        if (travel < MIN_STROKE_TRAVEL) return
        val e = eBezFromPoints(pts, eraseClosed, 4f / max(vs, 0.01f)) ?: return
        eraseLine = e
        lineOwner = owner
        eSmooth = true
        eSel = -1
    }

    /** ปุ่มถังขยะ: ลบจุดยึดที่เลือก (ต้องเหลืออย่างน้อย 3 จุด) */
    fun deleteCurveNode() {
        val sp = cValid() ?: return
        val b = bezOf(sp)
        val ns = b.contours.getOrNull(cC) ?: return
        if (ns.size <= 3 || cI !in ns.indices) {
            Toast.makeText(context, "ต้องเหลืออย่างน้อย 3 จุด", Toast.LENGTH_SHORT).show()
            return
        }
        val nn = ns.toMutableList().also { it.removeAt(cI) }
        commitBez(sp, Bez(b.contours.mapIndexed { i, l -> if (i == cC) nn else l }, b.fillType))
        cPath = null
    }

    fun finishStroke(pts: List<Offset>, travel: Float, tapAt: Offset) {
        if (mode == CropMode.REMOVE && travel < MIN_STROKE_TRAVEL) {
            // แตะในบ่วง = ลบทั้งบ่วง
            val p = toImg(tapAt)
            val hit = lassos.lastOrNull { pathContains(it, p, bw, bh) }
            if (hit != null) commit(lassos.filter { it !== hit })
            return
        }
        if (pts.size < 3 || travel < MIN_STROKE_TRAVEL) return
        val path = Path()
        path.moveTo(pts[0].x, pts[0].y)
        for (i in 1 until pts.size) path.lineTo(pts[i].x, pts[i].y)
        path.close()
        if (!hasArea(path)) return
        commit(if (mode == CropMode.ADD) addLasso(lassos, path) else subtractLasso(lassos, path))
    }

    fun confirm() {
        if (busy) return
        val current = lassos
        val src = flattenLayers()
        if (src == null) {
            Toast.makeText(context, "หน่วยความจำไม่พอสำหรับรวมเลเยอร์", Toast.LENGTH_SHORT).show()
            return
        }
        if (current.isEmpty()) {
            onConfirm(src, 0, 0) // ไม่วาดบ่วง = ใช้ทั้งภาพ (รวมส่วนที่ลบด้วยยางลบแล้ว)
            return
        }
        scope.launch {
            busy = true
            val r = withContext(Dispatchers.Default) { runCatching { cropByLassosAt(src, current) } }
            busy = false
            r.onSuccess { out ->
                if (out == null) {
                    Toast.makeText(context, "บ่วงอยู่นอกภาพ ลองวาดใหม่", Toast.LENGTH_SHORT).show()
                } else {
                    onConfirm(out.bmp, out.left, out.top)
                }
            }.onFailure {
                Toast.makeText(context, "ตัดภาพไม่สำเร็จ: ${it.message ?: it.javaClass.simpleName}", Toast.LENGTH_LONG).show()
            }
        }
    }

    // ข้อความบอกวิธีใช้: อ่านจาก "กำลังแตะอยู่ไหม" อย่างเดียว (ไม่อ่านตำแหน่งนิ้ว) ไม่งั้นทั้งหน้าจะคำนวณใหม่ทุกครั้งที่นิ้วขยับ = กระตุก
    val touching by remember { derivedStateOf { touch != null } }
    // เส้นบ่วงในพิกัดจอ: คำนวณใหม่เฉพาะเมื่อบ่วง/ซูม/เลื่อนเปลี่ยน ไม่คำนวณทุกเฟรมของการวาด
    val baseScreen = remember(lassos, vs, off) { lassos.map { toScreen(it) } }

    /** ปิดชิ้นลอยโดยไม่วาง: โหมดย้าย = คืนภาพเดิมก่อนเจาะรู (ชิ้นกลับที่เดิม) */
    fun closeOverlay() {
        val mv = overlay?.move
        if (mv != null) {
            work = mv.before
            workVer++
        }
        overlay = null
    }

    BackHandler(onBack = { if (!busy) { if (overlay != null) closeOverlay() else onCancel() } })

    // ── อุปกรณ์วาด ──
    val dash = 8f * density
    val antWhite = remember(density) {
        Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.STROKE
            color = android.graphics.Color.WHITE
            strokeWidth = 1.5f * density
            strokeJoin = Paint.Join.ROUND
        }
    }
    val antBlack = remember(density) {
        Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.STROKE
            color = android.graphics.Color.BLACK
            strokeWidth = 1.5f * density
            strokeJoin = Paint.Join.ROUND
        }
    }
    val erStroke = remember { // ยางลบ: ลบพิกเซลให้โปร่งใส (ขอบนุ่มด้วย anti-alias ขนาดทศนิยมเล็กกว่า 1 พิกเซลก็ลบจางๆ ได้)
        Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.STROKE
            strokeCap = Paint.Cap.ROUND
            xfermode = PorterDuffXfermode(PorterDuff.Mode.CLEAR)
        }
    }
    val erFill = remember {
        Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.FILL
            xfermode = PorterDuffXfermode(PorterDuff.Mode.CLEAR)
        }
    }
    val ringWhite = remember(density) {
        Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; color = android.graphics.Color.WHITE; strokeWidth = 1f * density }
    }
    val ringBlack = remember(density) {
        Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; color = android.graphics.Color.BLACK; strokeWidth = 2.2f * density }
    }
    val dimPaint = remember { Paint().apply { color = 0x99000000.toInt() } }
    val bmpPaint = remember { Paint(Paint.FILTER_BITMAP_FLAG or Paint.ANTI_ALIAS_FLAG) }
    val checkerPaint = remember(density) {
        val s = max(1, (8f * density).toInt())
        val bm = Bitmap.createBitmap(s * 2, s * 2, Bitmap.Config.ARGB_8888)
        val c = android.graphics.Canvas(bm)
        c.drawColor(0xFFB8B8C0.toInt())
        val p = Paint().apply { color = 0xFF8E8E98.toInt() }
        c.drawRect(0f, 0f, s.toFloat(), s.toFloat(), p)
        c.drawRect(s.toFloat(), s.toFloat(), s * 2f, s * 2f, p)
        Paint().apply { shader = BitmapShader(bm, Shader.TileMode.REPEAT, Shader.TileMode.REPEAT) }
    }
    val loupeWhite = remember { Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; color = android.graphics.Color.WHITE; strokeJoin = Paint.Join.ROUND } }
    val loupeBlack = remember { Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; color = android.graphics.Color.BLACK; strokeJoin = Paint.Join.ROUND } }
    val loupeBg = remember { Paint().apply { color = 0xFF1E1E26.toInt() } }
    val loupeBorder = remember(density) {
        Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.STROKE
            color = android.graphics.Color.WHITE
            strokeWidth = 2f * density
        }
    }
    val arrowFill = remember { Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL; color = 0xFFEDE7FF.toInt() } }
    val arrowShaft = remember(density) {
        Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; color = 0xFFB69DFF.toInt(); strokeWidth = 3.5f * density; strokeCap = Paint.Cap.ROUND }
    }
    val arrowEdge = remember(density) {
        Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.STROKE; color = android.graphics.Color.BLACK; strokeWidth = 6.5f * density
            strokeCap = Paint.Cap.ROUND; strokeJoin = Paint.Join.ROUND
        }
    }
    val arrowPath = remember { Path() }
    val crossPaint = remember(density) {
        Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.STROKE
            color = 0xFFFF1744.toInt()
            strokeWidth = 1.5f * density
        }
    }
    val hFill = remember { Paint(Paint.ANTI_ALIAS_FLAG).apply { color = android.graphics.Color.WHITE } }
    val hStroke = remember(density) {
        Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.STROKE
            color = 0xFFB69DFF.toInt()
            strokeWidth = 2.5f * density
        }
    }
    val hSel = remember(density) {
        Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.STROKE
            color = 0xFFFF80AB.toInt()
            strokeWidth = 3.5f * density
        }
    }
    val cLine = remember(density) {
        Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.STROKE
            color = 0xFF42A5F5.toInt()
            strokeWidth = 2.5f * density
        }
    }
    val cDot = remember { Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xFF42A5F5.toInt() } }
    val ePreFill = remember { Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0x55FF5252 } }
    val ePreStroke = remember {
        Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.STROKE
            color = 0x55FF5252
            strokeCap = Paint.Cap.ROUND
            strokeJoin = Paint.Join.ROUND
        }
    }
    val ants = rememberInfiniteTransition(label = "ants")
    val phase by ants.animateFloat(
        initialValue = 0f,
        targetValue = dash * 2f,
        animationSpec = infiniteRepeatable(tween(900, easing = LinearEasing), RepeatMode.Restart),
        label = "antsPhase",
    )

    val joyGlow = remember(density) { // เส้นเรืองแสงใต้เส้นทางของเป้า
        Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.STROKE
            color = 0x66B69DFF
            strokeWidth = 6f * density
            strokeJoin = Paint.Join.ROUND
            strokeCap = Paint.Cap.ROUND
        }
    }

    val brStroke = remember { // พู่กัน: ระบายสีทับลงบนภาพ (ขอบนุ่มด้วย anti-alias)
        Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.STROKE
            strokeCap = Paint.Cap.ROUND
            strokeJoin = Paint.Join.ROUND
        }
    }
    val brFill = remember { Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL } }

    /** จุดเริ่มของรอยยางลบ/พู่กันบนสำเนาภาพ (ยางลบ = ลบพิกเซลให้โปร่งใส · พู่กัน = ระบายสีที่เลือก) */
    fun strokeDot(cv: android.graphics.Canvas, p: Offset, brush: Boolean) {
        if (brush) {
            brFill.color = brushColor
            cv.drawCircle(p.x, p.y, max(brushSize, 0.01f) / 2f, brFill)
        } else {
            cv.drawCircle(p.x, p.y, max(eraserSize, 0.01f) / 2f, erFill)
        }
    }

    /** รอยลากช่วง a → b ของยางลบ/พู่กันบนสำเนาภาพ */
    fun strokeSeg(cv: android.graphics.Canvas, a: Offset, b: Offset, brush: Boolean) {
        if (brush) {
            brStroke.color = brushColor
            brStroke.strokeWidth = max(brushSize, 0.01f)
            cv.drawLine(a.x, a.y, b.x, b.y, brStroke)
        } else {
            erStroke.strokeWidth = max(eraserSize, 0.01f)
            erStroke.strokeJoin = Paint.Join.MITER
            cv.drawLine(a.x, a.y, b.x, b.y, erStroke)
        }
    }

    /** ปุ่ม "ลบในบ่วง": ลบภาพที่อยู่ข้างในบ่วงทั้งหมดทันที (ไม่ต้องลากเอง) ย้อนกลับได้ */
    fun eraseInsideLassos() {
        if (lassos.isEmpty()) return
        val sb = editCopy()
        if (sb == null) {
            Toast.makeText(context, if (ui.activeId in ui.locked) "เลเยอร์นี้ถูกล็อก ปลดล็อกก่อนจึงจะแก้ได้" else "หน่วยความจำไม่พอสำหรับยางลบ", Toast.LENGTH_SHORT).show()
            return
        }
        sb.setHasAlpha(true)
        val cv = android.graphics.Canvas(sb)
        for (lp in lassos) cv.drawPath(lp, erFill) // erFill = ลบพิกเซลให้โปร่งใส เติมทั้งพื้นที่ของบ่วง (รักษารูโหว่ของบ่วง)
        undoStack = trimHistory(undoStack + snapOf(work))
        redoStack = emptyList()
        work = sb
        workVer++
    }

    /** ปุ่ม "ลบตามเส้น": ลบภาพตามแนวเส้นขอบของบ่วงทั้งหมดทันที ความกว้างเท่าขนาดยางลบ (ไม่ต้องลากเอง) ย้อนกลับได้ */
    fun eraseAlongLassos() {
        if (lassos.isEmpty()) return
        val sb = editCopy()
        if (sb == null) {
            Toast.makeText(context, if (ui.activeId in ui.locked) "เลเยอร์นี้ถูกล็อก ปลดล็อกก่อนจึงจะแก้ได้" else "หน่วยความจำไม่พอสำหรับยางลบ", Toast.LENGTH_SHORT).show()
            return
        }
        sb.setHasAlpha(true)
        val cv = android.graphics.Canvas(sb)
        erStroke.strokeWidth = max(eraserSize, 0.01f)
        erStroke.strokeJoin = Paint.Join.ROUND
        for (lp in lassos) cv.drawPath(lp, erStroke)
        undoStack = trimHistory(undoStack + snapOf(work))
        redoStack = emptyList()
        work = sb
        workVer++
    }

    /** ปุ่ม "ตกลง" ของยางลบแบบเส้น: เส้นเปิด = ลบตามแนวเส้นกว้างเท่าขนาดยางลบ · บ่วงปิด = ลบภาพข้างใน (ย้อนกลับได้ 1 ขั้น) */
    fun applyEraseLine() {
        val el = eraseLine ?: return
        val sb = editCopy()
        if (sb == null) {
            Toast.makeText(context, if (ui.activeId in ui.locked) "เลเยอร์นี้ถูกล็อก ปลดล็อกก่อนจึงจะแก้ได้" else "หน่วยความจำไม่พอสำหรับยางลบ", Toast.LENGTH_SHORT).show()
            return
        }
        sb.setHasAlpha(true)
        val cv = android.graphics.Canvas(sb)
        val ep = buildEBezPath(el)
        val owner = lineOwner
        if (owner == CropMode.BRUSH) { // พู่กัน: เส้นเปิด = ระบายตามแนวเส้นกว้างเท่าขนาดพู่กัน · บ่วงปิด = เติมสีข้างใน
            if (el.closed) {
                brFill.color = brushColor
                cv.drawPath(ep, brFill)
            } else {
                brStroke.color = brushColor
                brStroke.strokeWidth = max(brushSize, 0.01f)
                cv.drawPath(ep, brStroke)
            }
        } else if (el.closed) {
            cv.drawPath(ep, erFill)
        } else {
            val oc = erStroke.strokeCap
            val oj = erStroke.strokeJoin
            erStroke.strokeWidth = max(eraserSize, 0.01f)
            erStroke.strokeCap = Paint.Cap.ROUND
            erStroke.strokeJoin = Paint.Join.ROUND
            cv.drawPath(ep, erStroke)
            erStroke.strokeCap = oc
            erStroke.strokeJoin = oj
        }
        undoStack = trimHistory(undoStack + snapOf(work))
        redoStack = emptyList()
        work = sb
        workVer++
        eraseLine = null
        eSel = -1
        if (mode == CropMode.CURVE || mode == CropMode.BEND) mode = owner
    }

    // ── จอย: ฟังก์ชันช่วย ──
    fun joyReset() {
        live.clear()
        joyPos = null
        joyPick = false
        joyHeld = false // ทิศของจอยไม่รีเซ็ต: ลูกศรยังชี้ทางเดิม
    }

    fun joyPlace(p: Offset) {
        live.clear()
        live.add(p)
        joyPos = p
    }

    /** แตะบนเส้นทางของเป้า: ตัดเส้นให้เหลือถึงจุดที่แตะ แล้วย้ายเป้าไปอยู่ตรงนั้น */
    fun joyTrim(screenPt: Offset) {
        var bestD = Float.MAX_VALUE
        var bestSeg = -1
        var bestPt = Offset.Zero
        for (i in 0 until live.size - 1) {
            val a = Offset(live[i].x * vs + off.x, live[i].y * vs + off.y)
            val b = Offset(live[i + 1].x * vs + off.x, live[i + 1].y * vs + off.y)
            val q = projectOnSegment(screenPt, a, b)
            val d = (q - screenPt).getDistance()
            if (d < bestD) {
                bestD = d
                bestSeg = i
                bestPt = q
            }
        }
        if (bestSeg < 0 || bestD > 40f * density) {
            Toast.makeText(context, "แตะให้ใกล้เส้นกว่านี้", Toast.LENGTH_SHORT).show()
            return
        }
        val imgPt = Offset(((bestPt.x - off.x) / vs).coerceIn(0f, bw.toFloat()), ((bestPt.y - off.y) / vs).coerceIn(0f, bh.toFloat()))
        while (live.size > bestSeg + 1) live.removeAt(live.size - 1)
        if ((live.last() - imgPt).getDistance() * vs > 0.5f) live.add(imgPt)
        joyPos = live.last()
        joyPick = false
    }

    /** ปิดบ่วงจากเส้นทางของเป้า (ต่อจุดท้ายกลับจุดแรก) แล้วเพิ่ม/ลบบ่วงเหมือนวาดด้วยนิ้ว */
    fun joyCommit() {
        val pts = live.toList()
        if (pts.size < 3) {
            Toast.makeText(context, "เส้นสั้นเกินไป บังคับเป้าวนรอบส่วนที่ต้องการก่อน", Toast.LENGTH_SHORT).show()
            return
        }
        val path = Path()
        path.moveTo(pts[0].x, pts[0].y)
        for (i in 1 until pts.size) path.lineTo(pts[i].x, pts[i].y)
        path.close()
        if (!hasArea(path)) {
            Toast.makeText(context, "บ่วงไม่มีพื้นที่ ลองบังคับเป้าวนใหม่", Toast.LENGTH_SHORT).show()
            return
        }
        commit(if (joyOp == CropMode.ADD) addLasso(lassos, path) else subtractLasso(lassos, path))
        joyReset()
    }

    LaunchedEffect(mode, eraseJoy) {
        padTarget = PadTarget.NONE
        if (!(mode == CropMode.JOY || (strokeTool && eraseJoy))) {
            joyPos = null
            joyPick = false
            joyHeld = false
            if (eraseJoy || !strokeTool) live.clear()
        }
    }

    // เป้าเดินตามจอยทุกเฟรมที่ดันอยู่ (ความเร็วคิดเป็นพิกเซลหน้าจอ ไม่ขึ้นกับระดับซูม)
    LaunchedEffect(joyHeld, mode, eraseJoy) {
        val eraseJ = strokeTool && eraseJoy
        val brushJ = mode == CropMode.BRUSH // ใช้พู่กัน (ไม่ใช่ยางลบ)
        if (!joyHeld || !(mode == CropMode.JOY || eraseJ) || overlay != null) return@LaunchedEffect // ถือชิ้นลอยอยู่ = จอยพาชิ้นเดิน (ด้านล่าง) ไม่ใช่เป้า
        var eOldJ: Bitmap? = null // โหมดยางลบ: ภาพก่อนเริ่มลบ (ไว้ย้อนกลับเป็น 1 ขั้น)
        var eCvJ: android.graphics.Canvas? = null
        var ePrevJ = Offset.Zero
        try {
            val p0 = joyPos
            if (eraseJ && p0 != null) {
                if (eraseLineMode) { // ยางลบแบบเส้น: เส้นทางของเป้าคือเส้นที่ลาก
                    live.clear()
                    live.add(p0)
                } else {
                    val sb = editCopy()
                    if (sb == null) {
                        Toast.makeText(context, if (ui.activeId in ui.locked) "เลเยอร์นี้ถูกล็อก ปลดล็อกก่อนจึงจะแก้ได้" else "หน่วยความจำไม่พอสำหรับยางลบ", Toast.LENGTH_SHORT).show()
                    } else {
                        sb.setHasAlpha(true)
                        val cv = android.graphics.Canvas(sb)
                        strokeDot(cv, p0, brushJ)
                        eOldJ = work
                        eCvJ = cv
                        ePrevJ = p0
                        work = sb
                        workVer++
                    }
                }
            }
            var last = withFrameNanos { it }
            while (true) {
                val now = withFrameNanos { it }
                val dt = ((now - last) / 1_000_000_000f).coerceAtMost(0.05f)
                last = now
                val p = joyPos
                val vx = joyVec[0]
                val vy = joyVec[1]
                if (p == null || joyPick || (vx == 0f && vy == 0f)) continue
                val k = joySpeed * dt / max(vs, 0.01f)
                val np = Offset((p.x + vx * k).coerceIn(0f, bw.toFloat()), (p.y + vy * k).coerceIn(0f, bh.toFloat()))
                if (np != p) {
                    joyPos = np
                    val cv = eCvJ
                    if (cv != null) {
                        strokeSeg(cv, ePrevJ, np, brushJ)
                        ePrevJ = np
                        workVer++
                    } else {
                        val lp = live.lastOrNull()
                        if (lp == null || (np - lp).getDistance() * vs >= 2f * density) live.add(np)
                    }
                }
                touch = Offset(np.x * vs + off.x, np.y * vs + off.y)
                lensImg = np
            }
        } finally {
            val p = joyPos
            if (eraseJ) {
                val eo = eOldJ
                if (eo != null && eCvJ != null) { // ปล่อยปุ่ม "ไปหน้า": บันทึกรอยลบเป็น 1 ขั้นย้อนกลับ
                    undoStack = trimHistory(undoStack + snapOf(eo))
                    redoStack = emptyList()
                } else if (eraseLineMode && live.size >= 2) {
                    finishEraseLine(live.toList(), 1_000_000f, if (brushJ) CropMode.BRUSH else CropMode.ERASE)
                }
                live.clear()
            } else if (p != null && live.isNotEmpty() && live.last() != p) {
                live.add(p) // ปล่อยจอย: เส้นต้องไปถึงตำแหน่งเป้าจริง
            }
            touch = null
            lensImg = null
        }
    }

    // ── เพิ่มรูปซ้อนบนภาพที่กำลังแก้ ──
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri ->
        if (uri != null) {
            scope.launch {
                val r = runCatching { withContext(Dispatchers.IO) { ImageImport.trimTransparent(ImageImport.decode(context, uri)) } }
                r.onSuccess { b ->
                    val fit = 0.5f * min(bw / b.width.toFloat(), bh / b.height.toFloat())
                    val c = toImg(Offset(canvasSize.width / 2f, canvasSize.height / 2f))
                    val s0 = fit.coerceAtLeast(0.01f)
                    overlay = Overlay(b, c.x, c.y, s0, base = s0) // 100% = ขนาดตอนเริ่มวาง
                }.onFailure {
                    Toast.makeText(context, "เพิ่มรูปไม่สำเร็จ: ${it.message ?: it.javaClass.simpleName}", Toast.LENGTH_LONG).show()
                }
            }
        }
    }

    /** กด "วางรูป": ประกอบรูปลงบนสำเนาของภาพ (ย้อนกลับได้) ส่วนที่ล้นกรอบภาพเดิมถูกตัดทิ้ง */
    fun placeOverlay() {
        val ov = overlay ?: return
        val sb = editCopy()
        if (sb == null) {
            Toast.makeText(context, if (ui.activeId in ui.locked) "เลเยอร์นี้ถูกล็อก ปลดล็อกก่อนจึงจะวางรูปได้" else "หน่วยความจำไม่พอ", Toast.LENGTH_SHORT).show()
            return
        }
        sb.setHasAlpha(true)
        val m = Matrix()
        m.postTranslate(-ov.bmp.width / 2f, -ov.bmp.height / 2f)
        m.postScale(ov.scale, ov.scale * ov.ratio)
        m.postRotate(ov.angle)
        m.postTranslate(ov.cx, ov.cy)
        android.graphics.Canvas(sb).drawBitmap(ov.bmp, m, bmpPaint)
        val mv = ov.move
        undoStack = trimHistory(undoStack + snapOf(mv?.before ?: work)) // โหมดย้าย: ย้อนกลับ = ภาพก่อนเจาะรู + บ่วงเดิม (ชิ้นกลับที่เดิมในขั้นเดียว)
        redoStack = emptyList()
        if (mv != null) lassos = movedLassos(mv, ov) // บ่วงตามชิ้นไปที่ใหม่
        work = sb
        workVer++
        overlay = null
    }

    /** ปุ่ม "ย้าย": ยกภาพในบ่วงออกเป็นชิ้นลอย (ลาก/2 นิ้วย่อขยายหมุน/จอยเลื่อนได้) ที่เดิมเจาะโปร่งใส · กด ✔ วางลงที่ใหม่ · กด ✕ คืนที่เดิม */
    fun startMove() {
        val sb = editCopy() // null = เลเยอร์ล็อก/หน่วยความจำไม่พอ (ข้อความแจ้งอยู่ใน lassoMoveLift)
        val ov = lassoMoveLift(context, ui, work, sb, lassos, erFill) ?: return // งานหนักอยู่ใน CropPaste.kt (กันฟังก์ชันหน้าจอใหญ่เกิน)
        work = sb ?: return // ภาพที่เจาะรูแล้ว (ยังไม่เข้าประวัติ จนกว่าจะกดวาง)
        workVer++
        overlay = ov
    }

    // ชิ้นที่ยกออกมา (ปุ่ม "ย้าย") เลื่อนต่อเนื่องตามทิศจอยเมื่อกดค้าง "ไปหน้า" · ความเร็วใช้ค่าเดียวกับเป้า (พิกเซลหน้าจอ/วินาที)
    val moveActive = overlay?.move != null
    LaunchedEffect(joyHeld, moveActive) {
        if (!joyHeld || !moveActive) return@LaunchedEffect
        var last = withFrameNanos { it }
        while (true) {
            val now = withFrameNanos { it }
            val dt = ((now - last) / 1_000_000_000f).coerceAtMost(0.05f)
            last = now
            val ov = overlay ?: break
            val vx = joyVec[0]
            val vy = joyVec[1]
            if (vx == 0f && vy == 0f) continue
            val k = joySpeed * dt / max(vs, 0.01f)
            overlay = ov.copy(cx = (ov.cx + vx * k).coerceIn(0f, bw.toFloat()), cy = (ov.cy + vy * k).coerceIn(0f, bh.toFloat()))
        }
    }

    Column(
        Modifier
            .fillMaxSize()
            .background(Palette.Bg)
            .systemBarsPadding()
            .pointerInput(Unit) { detectTapGestures { } }, // กันการสัมผัสทะลุไปหน้าด้านล่าง
    ) {
        Box(Modifier.weight(1f).fillMaxWidth().background(Color(0xFF2A2A34))) {
            Canvas(
                Modifier
                    .fillMaxSize()
                    .onSizeChanged { canvasSize = it }
                    .pointerInput(mode, eraseJoy, eyedropOn) {
                        awaitEachGesture {
                            val down = awaitFirstDown(requireUnconsumed = false)
                            if (eyedropOn) { // ดูดสี: ลากนิ้วบนภาพ เห็นสีใต้นิ้วทันที ปล่อยนิ้วแล้วคัดลอกสีนั้นเป็นสีพู่กัน
                                eyedropPos = down.position
                                eyedropColor = sampleColorAt(down.position)
                                down.consume()
                                while (true) {
                                    val event = awaitPointerEvent()
                                    val ch = event.changes.firstOrNull { it.id == down.id }
                                    if (ch == null || !ch.pressed) break
                                    eyedropPos = ch.position
                                    eyedropColor = sampleColorAt(ch.position)
                                    ch.consume()
                                }
                                val picked = eyedropColor
                                eyedropPos = null
                                eyedropColor = null
                                if (picked != null) {
                                    brushColor = picked
                                    eyedropOn = false
                                } else {
                                    QuickToast.show(context, "ตรงนั้นโปร่งใส ไม่มีสีให้ดูด ลองลากไปจุดอื่น")
                                }
                                return@awaitEachGesture
                            }
                            if (overlay != null) { // กำลังวางรูปที่เพิ่ม: 1 นิ้ว = ย้ายรูป · 2 นิ้ว = ย่อ/ขยายรูป
                                do {
                                    val event = awaitPointerEvent()
                                    val ov = overlay
                                    if (ov != null) {
                                        if (event.changes.count { it.pressed } >= 2) {
                                            val zoom = event.calculateZoom()
                                            val pan = event.calculatePan()
                                            val rot = event.calculateRotation() // องศาที่นิ้วหมุนในรอบนี้ (ตามเข็ม = บวก)
                                            val fz = ov.frozen // ล็อกอยู่ (โหมดย้าย): 2 นิ้วเลื่อนอย่างเดียว ไม่ย่อ/ขยาย/หมุน
                                            overlay = ov.copy(cx = ov.cx + pan.x / vs, cy = ov.cy + pan.y / vs, scale = if (fz) ov.scale else (ov.scale * zoom).coerceIn(PASTE_SCALE_MIN, PASTE_SCALE_MAX), angle = if (fz) ov.angle else normAngle(ov.angle + rot))
                                            event.changes.forEach { if (it.positionChanged()) it.consume() }
                                        } else {
                                            val ch = event.changes.firstOrNull { it.pressed }
                                            if (ch != null) {
                                                val d = ch.position - ch.previousPosition
                                                overlay = ov.copy(cx = ov.cx + d.x / vs, cy = ov.cy + d.y / vs)
                                                ch.consume()
                                            }
                                        }
                                    }
                                } while (event.changes.any { it.pressed })
                                return@awaitEachGesture
                            }
                            if (joyUi) { // โหมดจอย (รวมยางลบที่ใช้จอย): นิ้วเดียวบนภาพมีผลแค่ "วางเป้าครั้งแรก" กับ "แตะเลือกจุดบนเส้น" นอกนั้นไม่ติด · 2 นิ้ว = ซูม/เลื่อน
                                var multi = false
                                var moved = 0f
                                var prev = down.position
                                do {
                                    val event = awaitPointerEvent()
                                    if (event.changes.count { it.pressed } >= 2) {
                                        multi = true
                                        val zoom = event.calculateZoom()
                                        val pan = event.calculatePan()
                                        val c = event.calculateCentroid()
                                        val f = fitScale()
                                        val s0 = vs
                                        val s1 = (s0 * zoom).coerceIn(f * 0.5f, f * 20f)
                                        val k = s1 / s0
                                        off = Offset(c.x - (c.x - off.x) * k + pan.x, c.y - (c.y - off.y) * k + pan.y)
                                        vs = s1
                                        event.changes.forEach { if (it.positionChanged()) it.consume() }
                                    } else {
                                        val ch = event.changes.firstOrNull { it.pressed }
                                        if (ch != null) {
                                            moved += (ch.position - prev).getDistance()
                                            prev = ch.position
                                        }
                                    }
                                } while (event.changes.any { it.pressed })
                                if (!multi && moved < 14f * density) {
                                    if (joyPick) {
                                        joyTrim(down.position)
                                    } else if (mode == CropMode.JOY) {
                                        if (joyPos == null) {
                                            val raw = toImgRaw(down.position)
                                            if (raw.x in 0f..bw.toFloat() && raw.y in 0f..bh.toFloat()) joyPlace(raw)
                                        }
                                    } else { // ยางลบ+จอย: แตะตรงไหน เป้ายางลบไปอยู่ตรงนั้น
                                        val raw = toImgRaw(down.position)
                                        if (raw.x in 0f..bw.toFloat() && raw.y in 0f..bh.toFloat()) joyPos = raw
                                    }
                                }
                                return@awaitEachGesture
                            }
                            var drawing = true
                            var travel = 0f
                            var last = down.position
                            val bend = mode == CropMode.BEND
                            val curve = mode == CropMode.CURVE
                            val bendLine = bend && eraseLine != null // ดัดโค้งเส้นที่ลากค้างอยู่ของยางลบ/พู่กัน (ไม่ใช่บ่วง)
                            var ebi = -1 // จุดยึดของเส้นที่ค้างอยู่ที่กำลังลากในโหมดดัดโค้ง
                            val erase = strokeTool && !eraseLineMode // ยางลบ/พู่กันแบบเส้นไม่ลงมือทันที ใช้การลากแบบบ่วงแทน
                            var eOld: Bitmap? = null // ภาพก่อนเริ่มลบ (ไว้ย้อนกลับ/ยกเลิก)
                            var eCanvas: android.graphics.Canvas? = null
                            var ePrev = Offset.Zero
                            val stabR = StrokeStabilizer.leashPx(density) // ความเสถียรของนิ้ว: ความยาวเชือกที่ผูกปลายพู่กันไว้กับนิ้ว (0 = ปิด ตามนิ้วทุกจุด)
                            var sp = down.position // ตำแหน่งปลายพู่กันบนจอ (ตามนิ้วด้วยเชือกยาว stabR)
                            var fp = down.position // ตำแหน่งนิ้วล่าสุดบนจอ
                            var hit: Hit? = null
                            var chit: CHit? = null
                            var ehit: EHit? = null
                            var gap = Offset.Zero // ระยะจากนิ้วถึงจุดที่จับ (กันจุดกระโดดมาอยู่ใต้นิ้ว)
                            live.clear()
                            if (erase) { // ยางลบ: ทำสำเนาภาพแล้วลบบนสำเนา (ปล่อยนิ้วค่อยบันทึกเป็น 1 ขั้นย้อนกลับ)
                                val sb = editCopy()
                                if (sb == null) {
                                    drawing = false
                                    Toast.makeText(context, if (ui.activeId in ui.locked) "เลเยอร์นี้ถูกล็อก ปลดล็อกก่อนจึงจะแก้ได้" else "หน่วยความจำไม่พอสำหรับยางลบ", Toast.LENGTH_SHORT).show()
                                } else {
                                    sb.setHasAlpha(true)
                                    val cv = android.graphics.Canvas(sb)
                                    eOld = work
                                    eCanvas = cv
                                    ePrev = toImgRaw(down.position)
                                    strokeDot(cv, ePrev, mode == CropMode.BRUSH)
                                    work = sb
                                    workVer++
                                    touch = down.position
                                    lensImg = ePrev
                                }
                            } else if (bendLine) { // ดัดโค้งเส้นที่ค้างอยู่: แตะโดนจุดยึด = เลือกและลากจุดนั้น
                                var bi = hitEAnchor(down.position)
                                if (bi < 0 && addPtMode) {
                                    bi = beginAddOnLine(down.position) // เพิ่มจุดใหม่ใต้นิ้ว แล้วลากต่อได้เลย
                                    if (bi >= 0) {
                                        touch = down.position
                                        lensImg = toImg(down.position)
                                    }
                                }
                                ebi = bi
                                val bn = eraseLine?.nodes?.getOrNull(bi)
                                if (bn != null) {
                                    eSel = bi
                                    gap = Offset(bn.p.x * vs + off.x, bn.p.y * vs + off.y) - down.position
                                }
                            } else if (bend) { // โหมดดัดโค้ง: แตะโดนจุดควบคุม = เลือกและลากจุดนั้น
                                hit = hitHandle(down.position)
                                if (hit == null && addPtMode) {
                                    hit = beginAddAtFinger(down.position) // เพิ่มจุดใหม่ใต้นิ้ว แล้วลากต่อได้เลย
                                    if (hit != null) {
                                        touch = down.position
                                        lensImg = toImg(down.position)
                                    }
                                }
                                val h0 = hit
                                if (h0 != null) {
                                    selPath = h0.path
                                    selC = h0.c
                                    selP = h0.p
                                    val q = (bendDrag?.ctrl ?: ctrlOf(h0.path)).contours[h0.c][h0.p]
                                    gap = Offset(q.x * vs + off.x, q.y * vs + off.y) - down.position
                                }
                            } else if (curve && eraseLine != null) { // ดัดเส้นยางลบที่ลากค้างอยู่
                                val e0 = hitE(down.position)
                                ehit = e0
                                val el0 = eraseLine
                                if (e0 != null && el0 != null) {
                                    eSel = e0.i
                                    val n0 = el0.nodes[e0.i]
                                    val tg = when (e0.kind) {
                                        1 -> n0.p + n0.hout
                                        2 -> n0.p + n0.hin
                                        else -> n0.p
                                    }
                                    gap = Offset(tg.x * vs + off.x, tg.y * vs + off.y) - down.position
                                }
                            } else if (curve) { // โหมดเส้นโค้ง: แตะโดนจุดยึด/จุดจับ = เลือกและลากอันนั้น
                                val h0 = hitCurve(down.position)
                                chit = h0
                                if (h0 != null) {
                                    cPath = h0.path
                                    cC = h0.c
                                    cI = h0.i
                                    val n0 = (curveDrag?.bez ?: bezOf(h0.path)).contours[h0.c][h0.i]
                                    val tg = when (h0.kind) {
                                        1 -> n0.p + n0.hout
                                        2 -> n0.p + n0.hin
                                        else -> n0.p
                                    }
                                    gap = Offset(tg.x * vs + off.x, tg.y * vs + off.y) - down.position
                                }
                            } else {
                                live.add(toImg(down.position))
                            }
                            do {
                                val event = awaitPointerEvent()
                                val pressedCount = event.changes.count { it.pressed }
                                if (pressedCount >= 2) {
                                    // 2 นิ้ว = ซูม/เลื่อนภาพ (ยกเลิกบ่วงที่กำลังวาดอยู่)
                                    if (drawing) {
                                        drawing = false
                                        if (erase) { // ยกเลิกรอยลบที่กำลังลาก (เปลี่ยนเป็นซูมแทน)
                                            eOld?.let { work = it }
                                            eCanvas = null
                                            workVer++
                                        }
                                        live.clear()
                                        bendDrag = null // ยกเลิกการลากจุดที่ค้างอยู่
                                        curveDrag = null
                                        touch = null
                                        lensImg = null
                                    }
                                    val zoom = event.calculateZoom()
                                    val pan = event.calculatePan()
                                    val c = event.calculateCentroid()
                                    val f = fitScale()
                                    val s0 = vs
                                    val s1 = (s0 * zoom).coerceIn(f * 0.5f, f * 20f)
                                    val k = s1 / s0
                                    off = Offset(
                                        c.x - (c.x - off.x) * k + pan.x,
                                        c.y - (c.y - off.y) * k + pan.y,
                                    )
                                    vs = s1
                                    event.changes.forEach { if (it.positionChanged()) it.consume() }
                                } else if (drawing) {
                                    val ch = event.changes.firstOrNull { it.pressed }
                                    if (ch != null && erase) {
                                        val cv = eCanvas
                                        if (cv != null) {
                                            fp = ch.position
                                            sp = StrokeStabilizer.follow(sp, fp, stabR)
                                            val np = toImgRaw(sp)
                                            if ((np - ePrev).getDistance() > 0f) {
                                                strokeSeg(cv, ePrev, np, mode == CropMode.BRUSH)
                                                ePrev = np
                                                workVer++
                                            }
                                            touch = ch.position
                                            lensImg = np
                                        }
                                        ch.consume()
                                    } else if (ch != null) {
                                        val d = (ch.position - last).getDistance()
                                        val addLive = d >= 3f // จุดของบ่วงเก็บทุก 3 พิกเซล แต่ตำแหน่งแว่นขยาย/จุดที่ลากอัปเดตทุกครั้งที่นิ้วขยับ (ลื่น ไม่เป็นช่วงๆ)
                                        if (addLive) {
                                            travel += d
                                            last = ch.position
                                        }
                                        if (travel >= 3f) {
                                            touch = ch.position
                                            if (bendLine) {
                                                val bl = eraseLine
                                                if (ebi >= 0 && bl != null && ebi < bl.nodes.size) { // ลากจุดยึดของเส้นที่ค้างอยู่: เส้นปรับรูปตามทันที (ยังไม่ลบ/ระบายจนกว่าจะกดตกลง)
                                                    val bpts = bl.nodes.map { it.p }.toMutableList()
                                                    val bnp = toImg(ch.position + gap)
                                                    bpts[ebi] = bnp
                                                    eraseLine = eBezFromCtrl(bpts, bl.closed, eSmooth)
                                                    lensImg = bnp
                                                }
                                            } else if (bend) {
                                                val hh = hit
                                                if (hh != null) { // ลากจุดควบคุม: ดูตัวอย่างทันที ยังไม่บันทึกลงประวัติจนกว่าจะปล่อยนิ้ว
                                                    val ct0 = bendDrag?.ctrl ?: ctrlOf(hh.path)
                                                    val np0 = toImg(ch.position + gap)
                                                    val list = ct0.contours[hh.c].toMutableList()
                                                    list[hh.p] = np0
                                                    val nc2 = Ctrl(ct0.contours.mapIndexed { i, l -> if (i == hh.c) list else l }, ct0.smooth, ct0.fillType)
                                                    bendDrag = BendDrag(hh.path, nc2, buildPath(nc2))
                                                    lensImg = np0
                                                }
                                            } else if (curve && eraseLine != null) {
                                                val he = ehit
                                                val el = eraseLine
                                                if (he != null && el != null) { // ลากโหนด/จุดจับของเส้นยางลบ (จุดจับสองฝั่งสมมาตร ยืดได้)
                                                    val ns = el.nodes.toMutableList()
                                                    val n0 = ns[he.i]
                                                    val tp = if (he.kind == 0) toImg(ch.position + gap) else toImgRaw(ch.position + gap)
                                                    ns[he.i] = when (he.kind) {
                                                        1 -> BNode(n0.p, if (curvePaired) n0.p - tp else n0.hin, tp - n0.p)
                                                        2 -> BNode(n0.p, tp - n0.p, if (curvePaired) n0.p - tp else n0.hout)
                                                        else -> BNode(tp, n0.hin, n0.hout)
                                                    }
                                                    eraseLine = EBez(ns, el.closed)
                                                    lensImg = tp
                                                }
                                            } else if (curve) {
                                                val hc = chit
                                                if (hc != null) { // ลากโหนด/จุดจับ: ดูตัวอย่างทันที ยังไม่บันทึกลงประวัติจนกว่าจะปล่อยนิ้ว
                                                    val b0 = curveDrag?.bez ?: bezOf(hc.path)
                                                    val ns = b0.contours[hc.c].toMutableList()
                                                    val n0 = ns[hc.i]
                                                    val tp = if (hc.kind == 0) toImg(ch.position + gap) else toImgRaw(ch.position + gap)
                                                    ns[hc.i] = when (hc.kind) {
                                                        1 -> BNode(n0.p, if (curvePaired) n0.p - tp else n0.hin, tp - n0.p) // จุดจับสองฝั่งสมมาตร ยืด/หดได้
                                                        2 -> BNode(n0.p, tp - n0.p, if (curvePaired) n0.p - tp else n0.hout)
                                                        else -> BNode(tp, n0.hin, n0.hout)
                                                    }
                                                    val nb = Bez(b0.contours.mapIndexed { i, l -> if (i == hc.c) ns else l }, b0.fillType)
                                                    curveDrag = CurveDrag(hc.path, nb, buildBezPath(nb))
                                                    lensImg = tp
                                                }
                                            } else {
                                                fp = ch.position
                                                sp = StrokeStabilizer.follow(sp, fp, stabR)
                                                val np1 = toImg(sp)
                                                if (addLive && np1 != live.lastOrNull()) live.add(np1)
                                                lensImg = np1
                                            }
                                        }
                                        ch.consume()
                                    }
                                }
                            } while (event.changes.any { it.pressed })

                            if (drawing) {
                                if (erase) {
                                    val cvE = eCanvas
                                    if (cvE != null && stabR > 0f) { // ปล่อยนิ้ว: ลากปลายพู่กันที่ยังตามอยู่ ไปให้ถึงจุดที่นิ้วยกจริง
                                        val endP = toImgRaw(fp)
                                        if ((endP - ePrev).getDistance() > 0f) {
                                            strokeSeg(cvE, ePrev, endP, mode == CropMode.BRUSH)
                                            workVer++
                                        }
                                    }
                                    val eo = eOld
                                    if (eo != null && eCanvas != null) { // ปล่อยนิ้ว: บันทึกรอยลบเป็น 1 ขั้น
                                        undoStack = trimHistory(undoStack + snapOf(eo))
                                        redoStack = emptyList()
                                    }
                                } else if (bendLine) {
                                    if (ebi < 0 && travel < MIN_STROKE_TRAVEL) { // แตะที่ว่าง: ใกล้เส้น = แทรกจุดยึด ไม่ใช่ = เลิกเลือก
                                        if (!insertEraseNodeAt(down.position)) eSel = -1
                                    }
                                } else if (bend) {
                                    val hh = hit
                                    val bd = bendDrag
                                    if (hh != null) {
                                        if (bd != null) { // ปล่อยนิ้ว: บันทึกบ่วงที่ดัดแล้วลงประวัติ (ย้อนกลับได้)
                                            ctrlCache[bd.preview] = bd.ctrl
                                            userCtrl[bd.preview] = bd.ctrl
                                            commit(lassos.map { if (it === hh.path) bd.preview else it })
                                            selPath = bd.preview
                                        }
                                    } else if (travel < MIN_STROKE_TRAVEL) { // แตะที่ว่าง: แตะใกล้เส้นบ่วง = แทรกจุด ไม่ใช่ = เลิกเลือก
                                        if (!insertPointAt(down.position)) selPath = null
                                    }
                                } else if (curve && eraseLine != null) {
                                    if (ehit == null && travel < MIN_STROKE_TRAVEL) { // แตะที่ว่าง: ใกล้เส้น = แทรกจุดยึด ไม่ใช่ = เลิกเลือก
                                        if (!insertEraseNodeAt(down.position)) eSel = -1
                                    }
                                } else if (curve) {
                                    val hc = chit
                                    val cd = curveDrag
                                    if (hc != null) {
                                        if (cd != null) { // ปล่อยนิ้ว: บันทึกบ่วงที่แก้แล้วลงประวัติ (ย้อนกลับได้)
                                            bezCache[cd.preview] = cd.bez
                                            userBez[cd.preview] = cd.bez
                                            commit(lassos.map { if (it === hc.path) cd.preview else it })
                                            cPath = cd.preview
                                        }
                                    } else if (travel < MIN_STROKE_TRAVEL) { // แตะที่ว่าง: ใกล้เส้น = แทรกจุดยึด ไม่ใช่ = เลิกเลือก
                                        if (!insertCurveNodeAt(down.position)) cPath = null
                                    }
                                } else {
                                    if (stabR > 0f && live.isNotEmpty()) { // ปล่อยนิ้ว: เส้นต่อไปให้ถึงจุดที่นิ้วยกจริง
                                        val endP = toImg(fp)
                                        if (endP != live.last()) live.add(endP)
                                    }
                                    val pts = live.toList()
                                    live.clear()
                                    if (strokeTool) finishEraseLine(pts, travel, mode) else finishStroke(pts, travel, down.position)
                                }
                            } else {
                                live.clear()
                            }
                            bendDrag = null
                            curveDrag = null
                            touch = null
                            lensImg = null
                        }
                    },
            ) {
                if (canvasSize.width == 0) return@Canvas
                @Suppress("UNUSED_VARIABLE") val ver = workVer // อ่านไว้เพื่อให้วาดใหม่ทุกครั้งที่ยางลบแก้ภาพ
                val dst = RectF(off.x, off.y, off.x + bw * vs, off.y + bh * vs)
                if (touching) {
                    // ระหว่างลากนิ้ว: หยุดเส้นปะวิ่งแต่ยังเป็นเส้นปะขาว-ดำสลับกันพอดี (ไม่ใช้เส้นขาวซ้อนเส้นดำที่ขอบขาวจางๆ โผล่รอบเส้น) และไม่อ่านค่า phase
                    antWhite.pathEffect = DashPathEffect(floatArrayOf(dash, dash), 0f)
                    antBlack.pathEffect = DashPathEffect(floatArrayOf(dash, dash), dash)
                } else {
                    antWhite.pathEffect = DashPathEffect(floatArrayOf(dash, dash), phase)
                    antBlack.pathEffect = DashPathEffect(floatArrayOf(dash, dash), phase + dash)
                }
                drawIntoCanvas { c ->
                    val nc = c.nativeCanvas
                    nc.drawRect(dst, checkerPaint)
                    for (ly in ui.layers) nc.drawBitmap(if (ly.id == ui.activeId) work else ly.bmp, null, dst, bmpPaint) // วาดจากเลเยอร์ล่างสุดขึ้นไป อันบนทับอันล่าง
                    val ovd = overlay
                    if (ovd != null) { // รูปที่กำลังวาง: โชว์เฉพาะส่วนที่อยู่ในกรอบภาพ (ส่วนที่ล้นจะถูกตัด) + กรอบปะรอบรูป
                        nc.save()
                        nc.clipRect(dst)
                        nc.translate(off.x, off.y)
                        nc.scale(vs, vs)
                        nc.translate(ovd.cx, ovd.cy)
                        nc.rotate(ovd.angle)
                        nc.scale(ovd.scale, ovd.scale * ovd.ratio)
                        nc.drawBitmap(ovd.bmp, -ovd.bmp.width / 2f, -ovd.bmp.height / 2f, bmpPaint)
                        nc.restore()
                        val op = overlayOutline(ovd, vs, off.x, off.y) // กรอบหมุน/ยืดตามรูป (คำนวณใน CropPaste.kt)
                        nc.drawPath(op, antWhite)
                        nc.drawPath(op, antBlack)
                        if (ovd.move != null) { // โหมดย้าย: ลูกศรทิศจอยที่กึ่งกลางชิ้น (ชิ้นจะเลื่อนไปทางนี้เมื่อกด "ไปหน้า")
                            drawDirArrow(nc, ovd.cx * vs + off.x, ovd.cy * vs + off.y, 11f * density, joyDir.value, arrowEdge, arrowShaft, arrowFill, arrowPath)
                        }
                    }

                    val bd = bendDrag
                    val cdv = curveDrag
                    val screenLassos = if (bd != null) {
                        lassos.mapIndexed { i, lp -> if (lp === bd.orig) toScreen(bd.preview) else baseScreen[i] }
                    } else if (cdv != null) {
                        lassos.mapIndexed { i, lp -> if (lp === cdv.orig) toScreen(cdv.preview) else baseScreen[i] }
                    } else {
                        baseScreen
                    }
                    if (screenLassos.isNotEmpty() && ovd == null) { // กำลังวาง/ย้ายชิ้น = ไม่ทำให้มืด (เห็นชิ้นสีจริงตลอด)
                        // ทำให้ส่วนนอกบ่วงมืดลง เพื่อเห็นชัดว่าส่วนไหนจะถูกเก็บไว้
                        nc.save()
                        for (sp in screenLassos) nc.clipOutPath(sp)
                        nc.drawRect(dst, dimPaint)
                        nc.restore()
                    }
                    if (ovd == null) for (sp in screenLassos) { // ระหว่างวาง/ย้าย ชิ้นมีกรอบปะของตัวเองแล้ว ซ่อนบ่วงเดิมไว้
                        nc.drawPath(sp, antWhite)
                        nc.drawPath(sp, antBlack)
                    }
                    if (live.size >= 2) { // เส้นที่กำลังวาด: ใช้เส้นปะแบบเดียวกัน
                        val lp = Path()
                        live.forEachIndexed { i, o ->
                            val x = o.x * vs + off.x
                            val y = o.y * vs + off.y
                            if (i == 0) lp.moveTo(x, y) else lp.lineTo(x, y)
                        }
                        if (mode == CropMode.JOY) {
                            joyGlow.color = if (joyPick) 0xCCFFD600.toInt() else 0x66B69DFF // รอแตะเลือกจุด = เส้นเหลืองเด่นขึ้น
                            nc.drawPath(lp, joyGlow) // เส้นทางของเป้า: เปิดปลาย (ยังไม่ปิดบ่วง)
                        } else if (!(strokeTool && !eraseClosed)) { // ยางลบ/พู่กันแบบเส้นเปิด: ไม่ปิดวง
                            lp.close()
                        }
                        nc.drawPath(lp, antWhite)
                        nc.drawPath(lp, antBlack)
                    }
                    val jp = joyPos
                    if (joyUi && jp != null) { // เป้า: วงขาว-ดำ + กากบาทแดง
                        val jx = jp.x * vs + off.x
                        val jy = jp.y * vs + off.y
                        val jr = 11f * density
                        val rc = if (strokeTool) max(toolSize * vs / 2f, 4f * density) else jr // ยางลบ/พู่กัน = วงเท่าขนาดเครื่องมือ
                        nc.drawCircle(jx, jy, rc, ringBlack)
                        nc.drawCircle(jx, jy, rc, ringWhite)
                        nc.drawLine(jx - jr * 1.7f, jy, jx + jr * 1.7f, jy, crossPaint)
                        nc.drawLine(jx, jy - jr * 1.7f, jx, jy + jr * 1.7f, crossPaint)
                        // ลูกศรบอกทิศที่เป้าจะเดินไปเมื่อกด "ไปหน้า" (ทิศเดียวกับลูกศรบนจอย)
                        val dv = joyDir.value
                        val sx = jx + dv.x * jr * 2.0f
                        val sy = jy + dv.y * jr * 2.0f
                        val ex = jx + dv.x * jr * 4.4f
                        val ey = jy + dv.y * jr * 4.4f
                        val hl = jr * 1.5f
                        val hw = jr * 0.95f
                        arrowPath.reset()
                        arrowPath.moveTo(ex + dv.x * hl, ey + dv.y * hl)
                        arrowPath.lineTo(ex - dv.y * hw, ey + dv.x * hw)
                        arrowPath.lineTo(ex + dv.y * hw, ey - dv.x * hw)
                        arrowPath.close()
                        nc.drawLine(sx, sy, ex, ey, arrowEdge)
                        nc.drawPath(arrowPath, arrowEdge)
                        nc.drawLine(sx, sy, ex, ey, arrowShaft)
                        nc.drawPath(arrowPath, arrowFill)
                    }
                    if (mode == CropMode.BEND && eraseLine == null) { // จุดควบคุมของทุกบ่วง (จุดที่เลือกเป็นสีชมพู)
                        for (lp in lassos) {
                            val ct = if (bd != null && lp === bd.orig) bd.ctrl else ctrlOf(lp)
                            ct.contours.forEachIndexed { ci, pts ->
                                pts.forEachIndexed { pi, q ->
                                    val sel = lp === selPath && ci == selC && pi == selP
                                    val x = q.x * vs + off.x
                                    val y = q.y * vs + off.y
                                    nc.drawCircle(x, y, (if (sel) 9f else 7f) * density, hFill)
                                    nc.drawCircle(x, y, (if (sel) 9f else 7f) * density, if (sel) hSel else hStroke)
                                }
                            }
                        }
                    }

                    if (mode == CropMode.CURVE && eraseLine == null) { // จุดยึด (สี่เหลี่ยม) ของทุกบ่วง · โหนดที่เลือกโชว์จุดจับสองฝั่ง
                        val csel = cValid()
                        for (lp in lassos) {
                            val b = if (cdv != null && lp === cdv.orig) cdv.bez else bezOf(lp)
                            b.contours.forEachIndexed { ci, ns ->
                                ns.forEachIndexed { ni, n ->
                                    val x = n.p.x * vs + off.x
                                    val y = n.p.y * vs + off.y
                                    val sel = lp === csel && ci == cC && ni == cI
                                    if (sel) {
                                        val ox = (n.p.x + n.hout.x) * vs + off.x
                                        val oy = (n.p.y + n.hout.y) * vs + off.y
                                        val ix = (n.p.x + n.hin.x) * vs + off.x
                                        val iy = (n.p.y + n.hin.y) * vs + off.y
                                        nc.drawLine(x, y, ix, iy, cLine)
                                        nc.drawLine(x, y, ox, oy, cLine) // เส้นจากจุดยึดไปจุดจับแต่ละข้าง (จุดจับหมุนทีละจุดแล้วสองข้างไม่อยู่แนวเดียวกัน ถ้าลากเส้นเดียวต่อสองจุดจะดูเหมือนหลุดจากจุดยึด)
                                        nc.drawCircle(ox, oy, 6f * density, cDot)
                                        nc.drawCircle(ix, iy, 6f * density, cDot)
                                    }
                                    val r = (if (sel) 6f else 5f) * density
                                    nc.drawRect(x - r, y - r, x + r, y + r, if (sel) cDot else hFill)
                                    nc.drawRect(x - r, y - r, x + r, y + r, cLine)
                                }
                            }
                        }
                    }

                    val elv = eraseLine
                    if (elv != null && (strokeTool || mode == CropMode.CURVE || mode == CropMode.BEND)) { // เส้นที่ลากค้างอยู่ (ยางลบ = แถบแดงจางคือพื้นที่ที่จะถูกลบ · พู่กัน = แถบสีที่เลือกคือรอยที่จะระบาย)
                        val epath = toScreen(buildEBezPath(elv))
                        val preColor = if (brushCtx) ((brushColor and 0xFFFFFF) or (0xB0 shl 24)) else 0x55FF5252
                        ePreFill.color = preColor
                        ePreStroke.color = preColor
                        if (elv.closed) {
                            nc.drawPath(epath, ePreFill)
                        } else {
                            ePreStroke.strokeWidth = max(toolSize * vs, 2f * density)
                            nc.drawPath(epath, ePreStroke)
                        }
                        nc.drawPath(epath, antWhite)
                        nc.drawPath(epath, antBlack)
                        if (mode == CropMode.CURVE) {
                            elv.nodes.forEachIndexed { ni, n ->
                                val x = n.p.x * vs + off.x
                                val y = n.p.y * vs + off.y
                                val sel = ni == eSel
                                if (sel) {
                                    val ox = (n.p.x + n.hout.x) * vs + off.x
                                    val oy = (n.p.y + n.hout.y) * vs + off.y
                                    val ix = (n.p.x + n.hin.x) * vs + off.x
                                    val iy = (n.p.y + n.hin.y) * vs + off.y
                                    nc.drawLine(x, y, ix, iy, cLine)
                                        nc.drawLine(x, y, ox, oy, cLine) // เส้นจากจุดยึดไปจุดจับแต่ละข้าง (จุดจับหมุนทีละจุดแล้วสองข้างไม่อยู่แนวเดียวกัน ถ้าลากเส้นเดียวต่อสองจุดจะดูเหมือนหลุดจากจุดยึด)
                                    nc.drawCircle(ox, oy, 6f * density, cDot)
                                    nc.drawCircle(ix, iy, 6f * density, cDot)
                                }
                                val r = (if (sel) 6f else 5f) * density
                                nc.drawRect(x - r, y - r, x + r, y + r, if (sel) cDot else hFill)
                                nc.drawRect(x - r, y - r, x + r, y + r, cLine)
                            }
                        } else if (mode == CropMode.BEND) { // ดัดโค้ง: จุดยึดของเส้นเป็นวงกลม (จุดที่เลือกเป็นสีชมพู)
                            elv.nodes.forEachIndexed { ni, n ->
                                val x = n.p.x * vs + off.x
                                val y = n.p.y * vs + off.y
                                val sel = ni == eSel
                                nc.drawCircle(x, y, (if (sel) 9f else 7f) * density, hFill)
                                nc.drawCircle(x, y, (if (sel) 9f else 7f) * density, if (sel) hSel else hStroke)
                            }
                        }
                    }

                    val rt = touch
                    if (strokeTool && rt != null) { // วงบอกขนาดยางลบ/พู่กันใต้นิ้ว
                        val rr = max(toolSize * vs / 2f, 2f * density)
                        nc.drawCircle(rt.x, rt.y, rr, ringBlack)
                        nc.drawCircle(rt.x, rt.y, rr, ringWhite)
                    }

                    // จออีกจอขนาดเล็ก (แว่นขยาย) ระหว่างลากนิ้ว: ขยายบริเวณรอบจุดที่กำลังวาด/ลาก ย้ายไปมุมอื่นเองเมื่อนิ้วเข้าใกล้
                    val jpL = joyPos
                    val joyLoupe = joyUi && jpL != null && overlay == null // โหมดจอย: แว่นขยายแสดงตลอดที่เป้า (ไม่ใช่แค่ตอนเป้าเดิน)
                    val lt = touch ?: (if (joyLoupe && jpL != null) Offset(jpL.x * vs + off.x, jpL.y * vs + off.y) else null)
                    val lf = lensImg ?: (if (joyLoupe) jpL else null)
                    if (lt != null && lf != null) {
                        val sizePx = LoupeSize.boxPx(density, min(canvasSize.width, canvasSize.height).toFloat()) // ขนาดตั้งได้ในหน้าตั้งค่า (10–100)
                        val mg = 8f * density
                        val cw = canvasSize.width.toFloat()
                        val chh = canvasSize.height.toFloat()
                        val shL = if (joyUi) 66f * density else 0f // โหมดจอยแสดงแว่นขยายตลอด: หลบแถบเครื่องมือซ้าย/ขวา และปุ่มแถวบน
                        val shR = if (joyUi && strokeUi) 56f * density else 0f
                        val shT = if (joyUi) 64f * density else 0f
                        val candsAll = listOf(
                            RectF(mg + shL, mg + shT, mg + shL + sizePx, mg + shT + sizePx),
                            RectF(cw - mg - shR - sizePx, mg + shT, cw - mg - shR, mg + shT + sizePx),
                            RectF(mg + shL, chh - mg - sizePx, mg + shL + sizePx, chh - mg),
                            RectF(cw - mg - shR - sizePx, chh - mg - sizePx, cw - mg - shR, chh - mg),
                        )
                        val cands = candsAll // จอยย้ายไปกลางล่างแล้ว มุมทั้ง 4 ว่างให้แว่นขยายใช้ได้
                        val clear = 56f * density
                        val box = cands.firstOrNull { r ->
                            lt.x < r.left - clear || lt.x > r.right + clear || lt.y < r.top - clear || lt.y > r.bottom + clear
                        } ?: cands[0]
                        val k = max(vs, min(vs * LoupeZoom.value, 40f)) // ขยายตามกำลังซูมที่ตั้งไว้ (ตั้งต้น 3 เท่าของมุมมองตอนนี้ ไม่เกิน 40 เท่าของพิกเซลภาพ)
                        val lm = Matrix()
                        lm.setTranslate(-lf.x, -lf.y)
                        lm.postScale(k, k)
                        lm.postTranslate(box.centerX(), box.centerY())
                        val clipP = Path()
                        clipP.addRoundRect(box, 14f * density, 14f * density, Path.Direction.CW)
                        nc.save()
                        nc.clipPath(clipP)
                        nc.drawRect(box, loupeBg)
                        val imgR = RectF(0f, 0f, bw.toFloat(), bh.toFloat())
                        lm.mapRect(imgR)
                        nc.drawRect(imgR, checkerPaint)
                        nc.save()
                        nc.concat(lm) // ต่อจากนี้วาดด้วยพิกัดภาพตรงๆ ไม่ต้องสร้าง Path ใหม่ทุกเฟรม (ลื่นขึ้น)
                        val half = (sizePx / 2f) / k + 2f
                        val src = Rect(
                            floor(lf.x - half).toInt().coerceIn(0, bw),
                            floor(lf.y - half).toInt().coerceIn(0, bh),
                            ceil(lf.x + half).toInt().coerceIn(0, bw),
                            ceil(lf.y + half).toInt().coerceIn(0, bh),
                        )
                        if (src.width() > 0 && src.height() > 0) for (ly in ui.layers) nc.drawBitmap(if (ly.id == ui.activeId) work else ly.bmp, src, RectF(src), bmpPaint) // วาดเฉพาะส่วนที่เห็นในจอเล็ก (ทุกเลเยอร์)
                        loupeBlack.strokeWidth = 3f * density / k
                        loupeWhite.strokeWidth = 1.5f * density / k
                        for (lp in lassos) {
                            val q = if (bd != null && lp === bd.orig) bd.preview else lp
                            nc.drawPath(q, loupeBlack)
                            nc.drawPath(q, loupeWhite)
                        }
                        val elq = eraseLine
                        if (elq != null) { // เส้นที่ลากค้างอยู่ (ยางลบ/พู่กัน) ในแว่นขยาย
                            val lqp = buildEBezPath(elq)
                            nc.drawPath(lqp, loupeBlack)
                            nc.drawPath(lqp, loupeWhite)
                        }
                        if (strokeTool) { // วงขนาดยางลบ/พู่กันในแว่นขยาย
                            val er = max(toolSize / 2f, 1.5f * density / k)
                            nc.drawCircle(lf.x, lf.y, er, loupeBlack)
                            nc.drawCircle(lf.x, lf.y, er, loupeWhite)
                        }
                        if (live.size >= 2) {
                            val lq = Path()
                            val from = max(0, live.size - 150) // เห็นแค่ช่วงปลายเส้น จึงวาดเฉพาะจุดล่าสุด
                            for (i in from until live.size) {
                                val o = live[i]
                                if (i == from) lq.moveTo(o.x, o.y) else lq.lineTo(o.x, o.y)
                            }
                            nc.drawPath(lq, loupeBlack)
                            nc.drawPath(lq, loupeWhite)
                        }
                        nc.restore()
                        if (mode == CropMode.BEND && eraseLine == null) {
                            for (lp in lassos) {
                                val ct = if (bd != null && lp === bd.orig) bd.ctrl else ctrlOf(lp)
                                ct.contours.forEachIndexed { ci, pts ->
                                    pts.forEachIndexed { pi, q ->
                                        val sel = lp === selPath && ci == selC && pi == selP
                                        val arr = floatArrayOf(q.x, q.y)
                                        lm.mapPoints(arr)
                                        nc.drawCircle(arr[0], arr[1], (if (sel) 7f else 5f) * density, hFill)
                                        nc.drawCircle(arr[0], arr[1], (if (sel) 7f else 5f) * density, if (sel) hSel else hStroke)
                                    }
                                }
                            }
                        }
                        val elm = eraseLine
                        if (mode == CropMode.BEND && elm != null) { // จุดยึดของเส้นที่ค้างอยู่ในแว่นขยาย
                            elm.nodes.forEachIndexed { ni, n ->
                                val arr = floatArrayOf(n.p.x, n.p.y)
                                lm.mapPoints(arr)
                                nc.drawCircle(arr[0], arr[1], (if (ni == eSel) 7f else 5f) * density, hFill)
                                nc.drawCircle(arr[0], arr[1], (if (ni == eSel) 7f else 5f) * density, if (ni == eSel) hSel else hStroke)
                            }
                        }
                        val cx0 = box.centerX()
                        val cy0 = box.centerY()
                        val arm = 9f * density
                        nc.drawLine(cx0 - arm, cy0, cx0 + arm, cy0, crossPaint) // กากบาทแดง = จุดที่กำลังวาด/ลากอยู่พอดี
                        nc.drawLine(cx0, cy0 - arm, cx0, cy0 + arm, crossPaint)
                        nc.restore()
                        nc.drawPath(clipP, loupeBorder)
                    }
                }
            }

            // กลางล่างของพื้นที่ภาพ: แผงตัวเลข + จอยพร้อมช่องความเร็ว (ย้ายจากซ้ายล่างมากลาง)
            val areaWDp = canvasSize.width / density
            // จอยใหญ่ขึ้น 1 เท่า (120 -> 240 dp) แต่ไม่ให้ทับปุ่มขวาล่าง (กว้างราว 140 dp ต่อข้าง) ถ้าจอแคบจะลดลงเอง ไม่ต่ำกว่า 120 dp
            val joyDp = min(JOY_SIZE_DP, max(110f, areaWDp - 2f * 140f - JOY_FWD_DP - 12f)) // เผื่อที่ให้ปุ่ม "ไปหน้า" ข้างจอยด้วย
            Column(
                Modifier.align(Alignment.BottomCenter).padding(10.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
            ) {
                when (padTarget) {
                    PadTarget.ERASER -> FloatingPad(
                        title = "ขนาดยางลบ",
                        unit = "px",
                        initial = eraserSize,
                        onDismiss = { padTarget = PadTarget.NONE },
                        onOk = { v ->
                            eraserSize = v
                            padTarget = PadTarget.NONE
                        },
                    )
                    PadTarget.JOY_SPEED -> FloatingPad(
                        title = "ความเร็วจอย",
                        unit = "px/วิ",
                        initial = joySpeed,
                        onDismiss = { padTarget = PadTarget.NONE },
                        onOk = { v ->
                            joySpeed = v
                            padTarget = PadTarget.NONE
                        },
                    )
                    PadTarget.BRUSH -> FloatingPad(
                        title = "ขนาดพู่กัน",
                        unit = "px",
                        initial = brushSize,
                        onDismiss = { padTarget = PadTarget.NONE },
                        onOk = { v ->
                            brushSize = v
                            padTarget = PadTarget.NONE
                        },
                    )
                    PadTarget.BRUSH_COLOR -> if (!eyedropOn) BrushColorPanel( // ดูดสีอยู่ = ซ่อนแผงชั่วคราวให้เห็นภาพเต็ม
                        color = brushColor,
                        onColor = { brushColor = it },
                        onClose = {
                            cancelColorModes()
                            padTarget = PadTarget.NONE
                        },
                        onSave = { saveCurrentColor() },
                        onEyedrop = {
                            colorDeleteMode = false
                            colorDeleteSel = emptySet()
                            eyedropOn = true
                        },
                        deleteMode = colorDeleteMode,
                        savedCount = savedColors.size,
                        onToggleDelete = {
                            colorDeleteSel = emptySet()
                            colorDeleteMode = !colorDeleteMode
                        },
                    )
                    PadTarget.NONE -> {}
                }
                // แผงตัวเลขของความเร็วเปิดอยู่ = ซ่อนจอยชั่วคราว (แผงใหญ่ขึ้นแล้วจะทับจอย) ปิดแผงแล้วจอยกลับมา
                if (((joyUi && joyPlaced && overlay == null) || moveActive) && padTarget != PadTarget.JOY_SPEED && padTarget != PadTarget.BRUSH_COLOR) {
                    Column(
                        verticalArrangement = Arrangement.spacedBy(6.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                    ) {
                        if (moveActive) OverlayButton(if (joyMove) "เสร็จ ✓ (ล็อกตำแหน่งปุ่ม)" else "✥ ย้ายปุ่มจอย", primary = joyMove, enabled = true) { joyMove = !joyMove } // โหมดย้ายชิ้น: ปุ่มย้ายตำแหน่งจอย/ไปหน้า/ความเร็ว
                        MovableBox(speedOff, joyMove) { Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Text("ความเร็ว", color = Color(0xFFC9C4D4), fontSize = 12.sp)
                            Box(
                                Modifier
                                    .clip(RoundedCornerShape(14.dp))
                                    .background(Color(0xE6272734))
                                    .border(1.dp, Palette.Accent, RoundedCornerShape(14.dp))
                                    .clickable { padTarget = PadTarget.JOY_SPEED }
                                    .padding(horizontal = 12.dp, vertical = 8.dp),
                            ) { Text("${fmtNum(joySpeed)} พิกเซล/วินาที  ✎", color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.Medium) }
                        } }
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                            MovableBox(fwdOff, joyMove) { ForwardButton(sizeDp = JOY_FWD_DP.dp, dir = joyDir, onHold = { joyHeld = it }) }
                            MovableBox(joyOff, joyMove) {
                                JoyStick(
                                    sizeDp = joyDp.dp,
                                    dir = joyDir,
                                    onDir = { d ->
                                        joyVec[0] = d.x
                                        joyVec[1] = d.y
                                    },
                                )
                            }
                        }
                    }
                }
            }
            if (mode == CropMode.JOY && joyPlaced && overlay == null) { // ขวาล่าง: ปุ่มจัดการเส้นทางของเป้า
                Column(
                    Modifier.align(Alignment.BottomEnd).padding(10.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp),
                    horizontalAlignment = Alignment.End,
                ) {
                    MovableBox(pickOff, joyMove) { OverlayButton(if (joyPick) "ยกเลิกเลือก" else "📍 เอาตรงนี้", primary = joyPick, enabled = joyHasLine) { joyPick = !joyPick } }
                    MovableBox(closeOff, joyMove) { OverlayButton("ปิดบ่วง ✓", primary = true, enabled = joyCanClose && !joyPick) { joyCommit() } }
                    MovableBox(resetOff, joyMove) { OverlayButton("เริ่มใหม่", primary = false, enabled = true) { joyReset() } }
                }
            }

            if ((mode == CropMode.BEND || mode == CropMode.CURVE) && overlay == null) { // แถบลอยบนสุด: เลือกโหมดย่อยของปุ่ม "เส้นโค้ง"
                Row(
                    Modifier
                        .align(Alignment.TopCenter)
                        .padding(top = 72.dp)
                        .clip(RoundedCornerShape(16.dp))
                        .background(Color(0xE6272734))
                        .border(1.dp, Palette.Stroke, RoundedCornerShape(16.dp))
                        .padding(4.dp),
                    horizontalArrangement = Arrangement.spacedBy(4.dp),
                ) {
                    for ((m, label) in listOf(CropMode.BEND to "ดัดโค้ง", CropMode.CURVE to "เส้นโค้ง")) {
                        Box(
                            Modifier
                                .heightIn(min = 40.dp)
                                .clip(RoundedCornerShape(12.dp))
                                .background(if (mode == m) Palette.Accent.copy(alpha = 0.35f) else Color.Transparent)
                                .clickable(enabled = !busy) {
                                    mode = m
                                    curveSub = m
                                }
                                .padding(horizontal = 14.dp),
                            contentAlignment = Alignment.Center,
                        ) { Text(label, color = if (!busy) Color.White else Color(0x66FFFFFF), fontSize = 14.sp) }
                    }
                }
            }

            if (mode == CropMode.BEND && overlay == null) { // แถบเครื่องมือเล็กลอยกลางล่าง (โหมดดัดโค้ง): ＋ เพิ่มจุด · 🗑 ลบจุด · ⌒ โค้งเนียน
                val bsp = selValid()
                val bPts = if (bsp != null) ctrlOf(bsp).contours.getOrNull(selC)?.size ?: 0 else 0
                val belb = eraseLine // มีเส้นยางลบ/พู่กันค้างอยู่ = ปุ่มในแถบนี้ทำงานกับเส้นนั้นแทนบ่วง
                Row(
                    Modifier
                        .align(Alignment.BottomCenter)
                        .padding(bottom = 12.dp)
                        .clip(RoundedCornerShape(16.dp))
                        .background(Color(0xE6272734))
                        .border(1.dp, Palette.Stroke, RoundedCornerShape(16.dp))
                        .padding(horizontal = 6.dp, vertical = 4.dp),
                    horizontalArrangement = Arrangement.spacedBy(4.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    CurveBarButton("＋", enabled = (lassos.isNotEmpty() || belb != null) && !busy, active = addPtMode) { addPtMode = !addPtMode }
                    CurveBarButton(
                        "🗑",
                        enabled = !busy && (if (belb != null) (eSel in belb.nodes.indices && belb.nodes.size > (if (belb.closed) 3 else 2)) else (bsp != null && bPts > 3)),
                    ) { if (belb != null) deleteEraseNode() else deleteSelectedPoint() }
                    CurveBarButton(
                        "⌒",
                        enabled = !busy && (belb != null || bsp != null),
                        active = if (belb != null) eSmooth else (bsp != null && ctrlOf(bsp).smooth),
                    ) { if (belb != null) toggleEraseSmooth() else toggleSmooth() }
                }
            }

            if (mode == CropMode.CURVE && overlay == null) { // แถบเครื่องมือเล็กลอยกลางล่าง: ถังขยะ (ลบจุดยึดที่เลือก) · ✓ (เสร็จ กลับโหมดเพิ่มบ่วง)
                val csp = cValid()
                val cn = if (csp != null) bezOf(csp).contours.getOrNull(cC)?.size ?: 0 else 0
                val elb = eraseLine
                Row(
                    Modifier
                        .align(Alignment.BottomCenter)
                        .padding(bottom = 12.dp)
                        .clip(RoundedCornerShape(16.dp))
                        .background(Color(0xE6272734))
                        .border(1.dp, Palette.Stroke, RoundedCornerShape(16.dp))
                        .padding(horizontal = 6.dp, vertical = 4.dp),
                    horizontalArrangement = Arrangement.spacedBy(4.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    CurveBarButton(if (curvePaired) "②" else "①", enabled = !busy, active = curvePaired) { curvePaired = !curvePaired } // ① หมุนจุดจับทีละจุด · ② หมุนสองฝั่งพร้อมกัน
                    CurveBarButton(
                        "🗑",
                        enabled = !busy && (if (elb != null) (eSel in elb.nodes.indices && elb.nodes.size > (if (elb.closed) 3 else 2)) else (csp != null && cn > 3)),
                    ) { if (elb != null) deleteEraseNode() else deleteCurveNode() }
                    CurveBarButton("✓", enabled = !busy) { // เส้นยางลบค้างอยู่ = กลับไปยางลบ (ยังไม่ลบ ต้องกด "ตกลง") · ไม่มี = กลับโหมดเพิ่มบ่วง
                        if (elb != null) {
                            eSel = -1
                            mode = lineOwner
                        } else {
                            cPath = null
                            mode = CropMode.ADD
                        }
                    }
                }
            }

            // ── ไอคอนล้วน: ✕ ✔ มุมบนซ้าย · เครื่องมือ/ตั้งค่า/เพิ่มรูปมุมบนขวา (แยกเป็นฟังก์ชันท้ายไฟล์) ──
            CropTopButtons(
                busy = busy, placing = overlay != null, toolsOpen = ui.toolsOpen, showAdd = allowAddImage,
                onClose = { if (overlay != null) closeOverlay() else onCancel() },
                onOk = { if (overlay != null) placeOverlay() else confirm() },
                onToggleTools = { ui.toolsOpen = !ui.toolsOpen },
                onSettings = { showLoupeSettings = true },
                onExport = { ui.exportOpen = true },
                onAdd = { picker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)) },
            )
            if (overlay == null && ui.toolsOpen) {
                LassoToolsPanel(
                    modifier = Modifier.align(Alignment.TopEnd).padding(end = if (strokeUi) 66.dp else 10.dp, top = 72.dp), // หลบแผงเครื่องมือยางลบฝั่งขวา
                    hasLasso = lassos.isNotEmpty(), hasClip = ui.lassoClip != null, busy = busy,
                    onCopy = { lassoCopyAction(context, ui, work, lassos) },
                    onCut = { lassoCutAction(context, ui, work, lassos) { eraseInsideLassos() } }, // ลบส่วนในบ่วงใช้ฟังก์ชันเดิม (ย้อนกลับได้)
                    onPaste = { lassoPasteStart(context, ui)?.let { overlay = it } },
                    onMove = { startMove() },
                )
            }
            overlay?.let { ov ->
                // โหมดย้าย: จอยอยู่กลางล่าง แผงขนาด/องศา/กุญแจจึงอยู่กลางบน (ใต้แถวปุ่มบน)
                PasteControls(ov, onChange = { n -> overlay = n }, modifier = if (ov.move != null) Modifier.align(Alignment.TopCenter).padding(top = 64.dp) else Modifier.align(Alignment.BottomCenter).padding(bottom = 12.dp))
            }
            if (showLoupeSettings) LoupeSettingsDialog { showLoupeSettings = false }
            if (overlay == null) {
                CropToolRail(
                    mode = mode, curveSub = curveSub, joyMove = joyMove, joyPlaced = joyPlaced,
                    canUndo = undoStack.isNotEmpty() && !busy, canRedo = redoStack.isNotEmpty() && !busy,
                    onMode = { mode = it },
                    onToggleJoyMove = { joyMove = !joyMove },
                    onUndo = { undo() }, onRedo = { redo() }, onFit = { fitView() },
                )
            }


            // ── แผงลอยไอคอนฝั่งขวา: เครื่องมือยางลบ (ปุ่มเล็ก ไม่มีตัวหนังสือ) ──
            if (overlay == null && strokeUi) {
                val pShape = RoundedCornerShape(22.dp)
                val sz = 40.dp
                Column(
                    Modifier
                        .align(Alignment.TopEnd)
                        .padding(end = 8.dp, top = 74.dp, bottom = 8.dp)
                        .clip(pShape)
                        .background(Color(0xB31B1D22))
                        .border(1.dp, Palette.Stroke, pShape)
                        .verticalScroll(rememberScrollState())
                        .padding(5.dp),
                    verticalArrangement = Arrangement.spacedBy(5.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                ) {
                    CropIconButton(CropGlyph.SIZE, size = sz, enabled = !busy, onClick = { padTarget = if (brushCtx) PadTarget.BRUSH else PadTarget.ERASER })
                    if (brushCtx) { // พู่กัน: ปุ่มเลือกสี (วงกลมแสดงสีที่ใช้อยู่) แตะซ้ำเพื่อปิดแผงสี
                        BrushColorButton(brushColor, sz, selected = padTarget == PadTarget.BRUSH_COLOR, enabled = !busy) {
                            padTarget = if (padTarget == PadTarget.BRUSH_COLOR) PadTarget.NONE else PadTarget.BRUSH_COLOR
                        }
                    } else {
                        CropIconButton(CropGlyph.ERASE_IN, size = sz, enabled = lassos.isNotEmpty() && !busy, onClick = { eraseInsideLassos() })
                        CropIconButton(CropGlyph.ERASE_ALONG, size = sz, enabled = lassos.isNotEmpty() && !busy, onClick = { eraseAlongLassos() })
                    }
                    CropIconButton(CropGlyph.INSTANT, size = sz, selected = !eraseLineMode, onClick = {
                        eraseLineMode = false
                        eraseLine = null
                        eSel = -1
                        if (mode == CropMode.CURVE || mode == CropMode.BEND) mode = lineOwner
                    })
                    CropIconButton(CropGlyph.LINE, size = sz, selected = eraseLineMode, onClick = { eraseLineMode = true })
                    if (eraseLineMode) {
                        CropIconButton(CropGlyph.OPEN_LINE, size = sz, selected = !eraseClosed, onClick = {
                            eraseClosed = false
                            eraseLine = null
                            eSel = -1
                        })
                        CropIconButton(CropGlyph.CLOSED_LINE, size = sz, selected = eraseClosed, onClick = {
                            eraseClosed = true
                            eraseLine = null
                            eSel = -1
                        })
                        CropIconButton(CropGlyph.PLUS, size = sz, enabled = eraseLine != null && !busy, onClick = { addEraseNode() })
                        CropIconButton(CropGlyph.MINUS, size = sz, enabled = eraseLine != null && !busy, onClick = {
                            if (eSel in (eraseLine?.nodes?.indices ?: IntRange.EMPTY)) deleteEraseNode()
                            else Toast.makeText(context, "แตะเลือกจุดบนเส้นก่อน (โหมดดัดเส้น)", Toast.LENGTH_SHORT).show()
                        })
                        CropIconButton(CropGlyph.TRASH, size = sz, enabled = eraseLine != null && !busy, onClick = {
                            eraseLine = null
                            eSel = -1
                            if (mode == CropMode.CURVE || mode == CropMode.BEND) mode = lineOwner
                        })
                        CropIconButton(CropGlyph.CHECK, size = sz, tone = CropTone.OK, enabled = eraseLine != null && !busy, onClick = { applyEraseLine() })
                    }
                    CropIconButton(CropGlyph.JOY, size = sz, selected = eraseJoy, onClick = { eraseJoy = !eraseJoy }) // ใช้จอยควบคุมยางลบ
                    if (eraseJoy && strokeTool) CropIconButton(CropGlyph.MOVE, size = sz, selected = joyMove, enabled = joyPlaced, onClick = { joyMove = !joyMove })
                }
            }

            // ── สีที่เซฟไว้ + แบนเนอร์/ตัวอย่างสีตอนดูดสีหรือลบสี (แยกเป็นฟังก์ชันท้ายไฟล์ กันเมธอดหน้าจอนี้ใหญ่เกิน) ──
            ColorOverlayPart(
                brushCtx = brushCtx,
                overlayActive = overlay != null,
                savedColors = savedColors,
                brushColor = brushColor,
                colorDeleteMode = colorDeleteMode,
                colorDeleteSel = colorDeleteSel,
                canvasSize = canvasSize,
                curveMode = mode == CropMode.BEND || mode == CropMode.CURVE,
                eyedropOn = eyedropOn,
                eyedropPos = eyedropPos,
                eyedropColor = eyedropColor,
                onPickColor = { brushColor = it },
                onToggleSel = { sc -> colorDeleteSel = if (sc.id in colorDeleteSel) colorDeleteSel - sc.id else colorDeleteSel + sc.id },
                onMoved = { SavedColorStore.save(context, savedColors) },
                onCancelModes = { cancelColorModes() },
                onConfirmDelete = { confirmDeleteColors() },
            )

            // ไอคอนเลเยอร์มุมล่างขวา: กดแล้วเปิดแผงเลเยอร์ (ตัวแผงอยู่ใน CropLayers.kt เพื่อไม่ให้ฟังก์ชันหน้าจอนี้ใหญ่เกินจนตัวแปลงโค้ดพัง)
            if (overlay == null) {
                LayerOverlay(
                    modifier = Modifier.align(Alignment.BottomEnd),
                    ui = ui,
                    activeBmp = { work },
                    strokeUi = strokeUi,
                    joyLow = mode == CropMode.JOY && joyPlaced,
                    busy = busy,
                    onOp = { op, id ->
                        if (op == LayerOp.UP || op == LayerOp.DOWN) {
                            moveLayer(id, op == LayerOp.UP)
                        } else {
                            when (op) {
                                LayerOp.SELECT -> selectLayer(id)
                                LayerOp.ADD -> addLayer()
                                LayerOp.COPY -> copyLayer()
                                LayerOp.PASTE -> pasteLayer()
                                LayerOp.DELETE -> deleteLayer()
                                LayerOp.LOCK -> toggleLayerLock(id)
                                else -> Unit
                            }
                            true
                        }
                    },
                )
            }

            // แผงตัวเลือกส่งออก (อยู่ท้ายสุดจึงทับทุกอย่าง · ตัวแผงอยู่ใน CropExport.kt)
            if (ui.exportOpen) CropExportPanel(ui, work, lassos, overlay)
        }

        if (overlay == null && mode == CropMode.JOY) JoyOpPanel(opOff, joyMove, joyOp) { joyOp = it }

    }
}

/** ครอบจอย/ปุ่มไปหน้า: moving = ลากย้ายตำแหน่งได้ (มีกรอบม่วง ปุ่มข้างในกดไม่ติดระหว่างย้าย) */
/*
 * ── ฟังก์ชันที่แยกออกมาจาก ImageCropScreen ──
 * ImageCropScreen ยาวเกินจนตัวแปลงโค้ด (D8) สร้างไบต์โค้ดเพี้ยน → java.lang.VerifyError ตอนเปิดหน้านี้
 * จึงย้ายบล็อก UI ที่แยกได้ออกมาเป็นเมธอดของตัวเอง พฤติกรรม/หน้าตาเหมือนเดิมทุกอย่าง
 * (ตัวแปรสถานะยังอยู่ใน ImageCropScreen ส่งเข้ามาเป็นค่า + callback)
 */

/** สีที่เซฟไว้ (ปุ่มลอยลากย้ายได้) + แบนเนอร์/ตัวอย่างสีตอนดูดสีหรือลบสี */
@Composable
private fun androidx.compose.foundation.layout.BoxScope.ColorOverlayPart(
    brushCtx: Boolean,
    overlayActive: Boolean,
    savedColors: List<SavedColor>,
    brushColor: Int,
    colorDeleteMode: Boolean,
    colorDeleteSel: Set<Long>,
    canvasSize: IntSize,
    curveMode: Boolean,
    eyedropOn: Boolean,
    eyedropPos: Offset?,
    eyedropColor: Int?,
    onPickColor: (Int) -> Unit,
    onToggleSel: (SavedColor) -> Unit,
    onMoved: () -> Unit,
    onCancelModes: () -> Unit,
    onConfirmDelete: () -> Unit,
) {
    LaunchedEffect(brushCtx, overlayActive) { // ออกจากพู่กัน/เริ่มวางรูป = เลิกโหมดดูดสี/ลบสี (กันโหมดค้างจนแตะภาพไม่ติด)
        if (!brushCtx || overlayActive) onCancelModes()
    }
    if (!overlayActive && brushCtx) {
        SavedColorLayer(
            colors = savedColors,
            current = brushColor,
            deleteMode = colorDeleteMode,
            marked = colorDeleteSel,
            areaPx = canvasSize,
            onPick = { onPickColor(it.color) },
            onToggle = onToggleSel,
            onMoved = onMoved,
        )
        val bannerTop = if (curveMode) 128.dp else 72.dp
        if (eyedropOn) {
            ColorModeBanner(
                Modifier.align(Alignment.TopCenter).padding(top = bannerTop),
                "ลากนิ้วบนภาพเพื่อดูดสี · ปล่อยนิ้วเพื่อคัดลอกสี",
                onCancel = onCancelModes,
            )
        } else if (colorDeleteMode) {
            ColorModeBanner(
                Modifier.align(Alignment.TopCenter).padding(top = bannerTop),
                "แตะปุ่มสีที่เซฟที่ต้องการลบ (เลือกแล้ว ${colorDeleteSel.size} สี)",
                onCancel = onCancelModes,
                okText = "ตกลง",
                okEnabled = colorDeleteSel.isNotEmpty(),
                onOk = onConfirmDelete,
            )
        }
        val ep = eyedropPos
        if (eyedropOn && ep != null) EyedropPreview(ep, eyedropColor, canvasSize)
        BackHandler(enabled = eyedropOn || colorDeleteMode) { onCancelModes() }
    }
}

/** ปุ่ม ✕ ✔ มุมบนซ้าย + ปุ่มเครื่องมือ/ตั้งค่า/เพิ่มรูปมุมบนขวา */
@Composable
private fun androidx.compose.foundation.layout.BoxScope.CropTopButtons(
    busy: Boolean,
    placing: Boolean,
    toolsOpen: Boolean,
    showAdd: Boolean,
    onClose: () -> Unit,
    onOk: () -> Unit,
    onToggleTools: () -> Unit,
    onSettings: () -> Unit,
    onExport: () -> Unit,
    onAdd: () -> Unit,
) {
    Row(Modifier.align(Alignment.TopStart).padding(10.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
        CropIconButton(CropGlyph.CROSS, tone = CropTone.CANCEL, size = 52.dp, enabled = !busy || placing, onClick = onClose)
        CropIconButton(CropGlyph.CHECK, tone = CropTone.OK, size = 52.dp, busy = busy, enabled = !busy, onClick = onOk)
    }
    Row(Modifier.align(Alignment.TopEnd).padding(10.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
        if (!placing) {
            CropIconButton(CropGlyph.TOOLS, size = 52.dp, selected = toolsOpen, enabled = !busy, onClick = onToggleTools) // เครื่องมือบ่วง: คัดลอก/ตัด/วาง
            CropIconButton(CropGlyph.SETTINGS, size = 52.dp, onClick = onSettings) // ตั้งค่าแว่นขยาย
        }
        CropIconButton(CropGlyph.EXPORT, size = 52.dp, enabled = !busy, onClick = onExport) // ส่งออกภาพ (ตอนกำลังวางรูปอยู่ก็กดได้ แผงจะถามว่ารวมรูปที่วางไหม)
        if (!placing && showAdd) {
            CropIconButton(CropGlyph.ADD_IMAGE, size = 52.dp, enabled = !busy, onClick = onAdd)
        }
    }
}

/** หน้าต่างตั้งค่าแว่นขยาย */
@Composable
private fun LoupeSettingsDialog(onDismiss: () -> Unit) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("ตั้งค่าแว่นขยาย") },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                LoupeSizeSetting()
                LoupeZoomSetting()
                StabilizerSetting() // ความเสถียรของนิ้ว (เส้นนิ่งขึ้น)
            }
        },
        confirmButton = { TextButton(onClick = onDismiss) { Text("เสร็จ") } },
    )
}

/** แผงไอคอนซ้าย: เลือกโหมดบ่วง/ยางลบ/พู่กัน/จอย + ย้อนกลับ/ทำซ้ำ/พอดีจอ */
@Composable
private fun androidx.compose.foundation.layout.BoxScope.CropToolRail(
    mode: CropMode,
    curveSub: CropMode,
    joyMove: Boolean,
    joyPlaced: Boolean,
    canUndo: Boolean,
    canRedo: Boolean,
    onMode: (CropMode) -> Unit,
    onToggleJoyMove: () -> Unit,
    onUndo: () -> Unit,
    onRedo: () -> Unit,
    onFit: () -> Unit,
) {
    val railShape = RoundedCornerShape(26.dp)
    Column(
        Modifier
            .align(Alignment.TopStart)
            .padding(start = 8.dp, top = 74.dp, bottom = 8.dp)
            .clip(railShape)
            .background(Color(0xB31B1D22))
            .border(1.dp, Palette.Stroke, railShape)
            .verticalScroll(rememberScrollState())
            .padding(6.dp),
        verticalArrangement = Arrangement.spacedBy(6.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        CropIconButton(CropGlyph.ADD_LASSO, selected = mode == CropMode.ADD, onClick = { onMode(CropMode.ADD) })
        CropIconButton(CropGlyph.REMOVE_LASSO, selected = mode == CropMode.REMOVE, onClick = { onMode(CropMode.REMOVE) })
        CropIconButton(
            CropGlyph.CURVE,
            selected = mode == CropMode.BEND || mode == CropMode.CURVE,
            onClick = { if (mode != CropMode.BEND && mode != CropMode.CURVE) onMode(curveSub) },
        )
        CropIconButton(CropGlyph.ERASER, selected = mode == CropMode.ERASE, onClick = { onMode(CropMode.ERASE) })
        CropIconButton(CropGlyph.BRUSH, selected = mode == CropMode.BRUSH, onClick = { onMode(CropMode.BRUSH) })
        CropIconButton(CropGlyph.JOY, selected = mode == CropMode.JOY, onClick = { onMode(CropMode.JOY) })
        if (mode == CropMode.JOY) CropIconButton(CropGlyph.MOVE, selected = joyMove, enabled = joyPlaced, onClick = onToggleJoyMove) // เปิด/ปิดโหมดขยับจอยกับปุ่มไปหน้า
        CropIconButton(CropGlyph.UNDO, enabled = canUndo, onClick = onUndo)
        CropIconButton(CropGlyph.REDO, enabled = canRedo, onClick = onRedo)
        CropIconButton(CropGlyph.FIT, onClick = onFit)
    }
}

/** แผงล่างของโหมดจอย: เลือกว่าเป้าวาดบ่วงแบบเพิ่มส่วนหรือลบส่วน */
@Composable
private fun JoyOpPanel(opOff: MutableState<Offset>, joyMove: Boolean, joyOp: CropMode, onOp: (CropMode) -> Unit) {
    Column(
        Modifier.fillMaxWidth().background(Palette.Panel).padding(horizontal = 8.dp, vertical = 6.dp),
        verticalArrangement = Arrangement.spacedBy(6.dp),
    ) {
        MovableBox(opOff, joyMove) { Row(
            Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Text("เป้าวาด", color = Color(0xFFC9C4D4), fontSize = 14.sp)
            FilterChip(
                selected = joyOp == CropMode.ADD,
                onClick = { onOp(CropMode.ADD) },
                label = { Text("＋ เพิ่มส่วน") },
                modifier = Modifier.weight(1f).heightIn(min = 48.dp),
            )
            FilterChip(
                selected = joyOp == CropMode.REMOVE,
                onClick = { onOp(CropMode.REMOVE) },
                label = { Text("－ ลบส่วน") },
                modifier = Modifier.weight(1f).heightIn(min = 48.dp),
            )
        } }
    }
}


@Composable
private fun MovableBox(offset: MutableState<Offset>, moving: Boolean, content: @Composable () -> Unit) {
    val frame = RoundedCornerShape(18.dp)
    Box(
        Modifier
            .offset { IntOffset(offset.value.x.roundToInt(), offset.value.y.roundToInt()) }
            .then(if (moving) Modifier.border(2.dp, Palette.Accent, frame) else Modifier),
    ) {
        content()
        if (moving) {
            Box(
                Modifier
                    .matchParentSize()
                    .pointerInput(Unit) {
                        detectDragGestures { change, drag ->
                            change.consume()
                            offset.value = Offset(offset.value.x + drag.x, offset.value.y + drag.y)
                        }
                    },
            )
        }
    }
}

/** ขนาดจอย (dp) ที่ 100% ของ UI: เดิม 120 ตอนนี้ใหญ่ขึ้น 1 เท่า = 240 */
private const val JOY_SIZE_DP = 240f

/** ขนาดปุ่ม "ไปหน้า" (dp) */
private const val JOY_FWD_DP = 92f

/**
 * จอยหันทิศ: แป้นกลมมีขีดองศารอบวง · ลากนิ้วบนแป้นเพื่อหันลูกศรไปทางที่ต้องการ ลูกศรค้างอยู่ที่ทิศนั้นแม้ปล่อยนิ้ว
 * (จอยไม่ได้ทำให้เป้าเดินเอง ต้องกดปุ่ม "ไปหน้า" ค่อยเดินไปตามทิศนี้) dir = ทิศปัจจุบัน (เวกเตอร์หน่วย) onDir ส่งทิศใหม่ทุกครั้งที่ลาก
 */
@Composable
private fun JoyStick(sizeDp: Dp, dir: MutableState<Offset>, onDir: (Offset) -> Unit) {
    var held by remember { mutableStateOf(false) }
    Canvas(
        Modifier
            .size(sizeDp)
            .pointerInput(Unit) {
                awaitEachGesture {
                    val down = awaitFirstDown(requireUnconsumed = false)
                    val r = size.width / 2f
                    fun update(pos: Offset) {
                        val v = Offset(pos.x - r, pos.y - r)
                        val len = v.getDistance()
                        if (len > r * 0.12f) { // ใกล้จุดกลางเกินไป = ไม่เปลี่ยนทิศ (กันลูกศรสะบัด)
                            val u = Offset(v.x / len, v.y / len)
                            dir.value = u
                            onDir(u)
                        }
                    }
                    held = true
                    update(down.position)
                    down.consume()
                    while (true) {
                        val e = awaitPointerEvent()
                        val ch = e.changes.firstOrNull { it.id == down.id }
                        if (ch == null || !ch.pressed) break
                        update(ch.position)
                        ch.consume()
                    }
                    held = false
                }
            },
    ) {
        val r = size.minDimension / 2f
        val c = center
        val d = dir.value
        val perp = Offset(-d.y, d.x)
        val accent = Palette.Accent
        // ฐานแป้น + ขอบเรืองเมื่อจับ
        drawCircle(Brush.radialGradient(listOf(Color(0xF0343450), Color(0xF012121A)), c, r), r, c)
        if (held) drawCircle(accent.copy(alpha = 0.18f), r, c)
        drawCircle(accent.copy(alpha = if (held) 0.95f else 0.55f), r - 1.5.dp.toPx(), c, style = Stroke(2.dp.toPx()))
        drawCircle(Color(0x1FFFFFFF), r * 0.62f, c, style = Stroke(1.dp.toPx()))
        // ขีดองศารอบวง (ทุก 15° ขีดยาวทุก 90°)
        for (i in 0 until 24) {
            val a = i * (PI / 12.0)
            val cx = cos(a).toFloat()
            val cy = sin(a).toFloat()
            val major = i % 6 == 0
            val r0 = r * (if (major) 0.78f else 0.84f)
            val r1 = r * 0.91f
            drawLine(
                if (major) Color(0xAAFFFFFF) else Color(0x44FFFFFF),
                Offset(c.x + cx * r0, c.y + cy * r0),
                Offset(c.x + cx * r1, c.y + cy * r1),
                (if (major) 2f else 1f).dp.toPx(),
                cap = StrokeCap.Round,
            )
        }
        // แสงลำทิศที่หันอยู่
        val tip = Offset(c.x + d.x * r * 0.74f, c.y + d.y * r * 0.74f)
        val tail = Offset(c.x + d.x * r * 0.38f, c.y + d.y * r * 0.38f)
        drawCircle(Brush.radialGradient(listOf(accent.copy(alpha = if (held) 0.55f else 0.35f), Color.Transparent), tip, r * 0.5f), r * 0.5f, tip)
        // ลูกศรทิศ: ก้านไล่สี + หัวลูกศรขาวขอบม่วง
        drawLine(Brush.linearGradient(listOf(Color(0xFF6E52D6), accent), c, tail), c, tail, 7.dp.toPx(), cap = StrokeCap.Round)
        val hw = r * 0.19f
        val head = androidx.compose.ui.graphics.Path().apply {
            moveTo(tip.x + d.x * r * 0.12f, tip.y + d.y * r * 0.12f)
            lineTo(tail.x + perp.x * hw, tail.y + perp.y * hw)
            lineTo(tail.x - perp.x * hw, tail.y - perp.y * hw)
            close()
        }
        drawPath(head, Color(0xFFF1ECFF))
        drawPath(head, accent, style = Stroke(2.dp.toPx(), join = StrokeJoin.Round))
        // ปุ่มกลางวง
        drawCircle(Brush.radialGradient(listOf(Color(0xFFE3DAFF), accent, Color(0xFF6E52D6)), c, r * 0.14f), r * 0.14f, c)
        drawCircle(Color(0x88FFFFFF), r * 0.14f, c, style = Stroke(1.5.dp.toPx()))
        // ลูกปัดจับบนราง (ตามนิ้วรอบวงตามทิศ)
        val bead = Offset(c.x + d.x * r * 0.88f, c.y + d.y * r * 0.88f)
        drawCircle(accent.copy(alpha = if (held) 0.6f else 0.3f), r * 0.1f, bead)
        drawCircle(Color.White, r * 0.045f, bead)
    }
}

/** ปุ่ม "ไปหน้า": กดค้าง = เป้าเดินไปตามทิศที่จอยชี้ ปล่อย = หยุด · ลูกศรบนปุ่มหันตามทิศจอย */
@Composable
private fun ForwardButton(sizeDp: Dp, dir: State<Offset>, onHold: (Boolean) -> Unit) {
    var held by remember { mutableStateOf(false) }
    DisposableEffect(Unit) { onDispose { onHold(false) } } // ปุ่มหายไปทั้งที่ยังกดอยู่ (เช่นเปิดแผงตัวเลข) ต้องหยุดเป้า ไม่ให้เดินค้าง
    Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(4.dp)) {
        Canvas(
            Modifier
                .size(sizeDp)
                .pointerInput(Unit) {
                    awaitEachGesture {
                        val down = awaitFirstDown(requireUnconsumed = false)
                        held = true
                        onHold(true)
                        down.consume()
                        while (true) {
                            val e = awaitPointerEvent()
                            val ch = e.changes.firstOrNull { it.id == down.id }
                            if (ch == null || !ch.pressed) break
                            ch.consume()
                        }
                        held = false
                        onHold(false)
                    }
                },
        ) {
            val r = size.minDimension / 2f
            val c = center
            val d = dir.value
            val perp = Offset(-d.y, d.x)
            val accent = Palette.Accent
            val face = if (held) listOf(Color(0xFFE3DAFF), accent, Color(0xFF6E52D6)) else listOf(Color(0xFF3A3A52), Color(0xFF26263A), Color(0xFF181824))
            if (held) drawCircle(accent.copy(alpha = 0.28f), r + 0.0f, c)
            val rr = r * (if (held) 0.9f else 0.94f) // ตอนกดปุ่มยุบลงนิดหน่อย
            drawCircle(Brush.radialGradient(face, Offset(c.x - rr * 0.25f, c.y - rr * 0.3f), rr * 1.5f), rr, c)
            drawCircle(accent.copy(alpha = if (held) 1f else 0.6f), rr - 1.5.dp.toPx(), c, style = Stroke(2.5.dp.toPx()))
            // ลูกศรบนปุ่ม: หันตามทิศจอย
            val ink = if (held) Color(0xFF2A1A66) else Color.White
            val t = Offset(c.x + d.x * rr * 0.62f, c.y + d.y * rr * 0.62f)
            val b = Offset(c.x - d.x * rr * 0.42f, c.y - d.y * rr * 0.42f)
            val m = Offset(c.x + d.x * rr * 0.06f, c.y + d.y * rr * 0.06f)
            val hw = rr * 0.34f
            drawLine(ink, b, m, 6.dp.toPx(), cap = StrokeCap.Round)
            val head = androidx.compose.ui.graphics.Path().apply {
                moveTo(t.x, t.y)
                lineTo(m.x + perp.x * hw, m.y + perp.y * hw)
                lineTo(m.x - perp.x * hw, m.y - perp.y * hw)
                close()
            }
            drawPath(head, ink)
            drawPath(head, ink, style = Stroke(3.dp.toPx(), join = StrokeJoin.Round))
        }
        Text("ไปหน้า", color = if (held) Palette.Accent else Color(0xFFC9C4D4), fontSize = 13.sp, fontWeight = FontWeight.Medium)
    }
}

/** ปุ่มกลมแคปซูลที่วางทับภาพ (ปุ่มของโหมดจอย) */
@Composable
private fun CurveBarButton(label: String, enabled: Boolean, active: Boolean = false, onClick: () -> Unit) {
    Box(
        Modifier
            .size(44.dp)
            .clip(RoundedCornerShape(12.dp))
            .background(if (active) Palette.Accent.copy(alpha = 0.35f) else Color.Transparent)
            .clickable(enabled = enabled, onClick = onClick),
        contentAlignment = Alignment.Center,
    ) {
        Text(label, color = if (enabled) Color.White else Color(0x669E9AB0), fontSize = 20.sp)
    }
}

@Composable
private fun OverlayButton(label: String, primary: Boolean, enabled: Boolean, onClick: () -> Unit) {
    val shape = RoundedCornerShape(50)
    Box(
        Modifier
            .heightIn(min = 44.dp)
            .clip(shape)
            .background(if (!enabled) Color(0x99272734) else if (primary) Palette.Accent else Color(0xE6272734))
            .border(1.dp, if (primary && enabled) Palette.Accent else Palette.Stroke, shape)
            .clickable(enabled = enabled, onClick = onClick)
            .padding(horizontal = 16.dp, vertical = 8.dp),
        contentAlignment = Alignment.Center,
    ) {
        Text(
            label,
            color = if (!enabled) Color(0x669E9AB0) else if (primary) Color(0xFF2A1A66) else Color.White,
            fontSize = 14.sp,
            fontWeight = FontWeight.Medium,
        )
    }
}

/** ปุ่มเล็กทรงแคปซูลของแผงยางลบ (สูง 34dp ตัวอักษร 12sp) */
@Composable
private fun MiniChip(text: String, selected: Boolean, modifier: Modifier = Modifier, accent: Boolean = false, enabled: Boolean = true, onClick: () -> Unit) {
    val shape = RoundedCornerShape(17.dp)
    Box(
        modifier
            .height(34.dp)
            .alpha(if (enabled) 1f else 0.38f)
            .clip(shape)
            .background(if (selected) Color(0xFF42338A) else Palette.PanelHigh)
            .border(1.dp, if (selected || accent) Palette.Accent else Palette.Stroke, shape)
            .clickable(enabled = enabled, onClick = onClick)
            .padding(horizontal = 8.dp),
        contentAlignment = Alignment.Center,
    ) { Text(text, fontSize = 12.sp, color = Color(0xFFE7E3EE), maxLines = 1, softWrap = false) }
}

/** ปุ่มเลือกสีพู่กัน: ปุ่มกลมเหมือนปุ่มไอคอน แต่ข้างในเป็นวงสีที่ใช้อยู่ตอนนี้ */
@Composable
private fun BrushColorButton(color: Int, size: Dp, selected: Boolean, enabled: Boolean = true, onClick: () -> Unit) {
    Box(
        Modifier
            .size(size)
            .alpha(if (enabled) 1f else 0.38f)
            .clip(CircleShape)
            .background(if (selected) Palette.Accent.copy(alpha = 0.38f) else Color(0xE6272734))
            .border(if (selected) 2.dp else 1.dp, if (selected) Palette.Accent else Palette.Stroke, CircleShape)
            .clickable(enabled = enabled, onClick = onClick),
        contentAlignment = Alignment.Center,
    ) {
        Box(
            Modifier
                .size(size * 0.56f)
                .clip(CircleShape)
                .background(Color(color))
                .border(2.dp, Color.White, CircleShape),
        )
    }
}

/** สีสำเร็จรูปของพู่กัน (2 แถว แถวละ 8 สี) */
private val BrushSwatches = listOf(
    0xFF000000, 0xFF5F6368, 0xFFB0B3B8, 0xFFFFFFFF, 0xFF8D5524, 0xFFC68642, 0xFFF1C27D, 0xFFFFDBB4,
    0xFFE53935, 0xFFFB8C00, 0xFFFDD835, 0xFF43A047, 0xFF00ACC1, 0xFF1E88E5, 0xFF5E35B1, 0xFFD81B60,
).map { it.toInt() }

/** แถบเลื่อนไล่สี (ค่า 0..1): แตะหรือลากเพื่อเลือก · track = พื้นไล่สีของแถบ */
@Composable
private fun ColorBar(value: Float, track: Brush, onValue: (Float) -> Unit) {
    var wpx by remember { mutableFloatStateOf(1f) }
    val cb by rememberUpdatedState(onValue)
    Box(
        Modifier
            .fillMaxWidth()
            .height(28.dp)
            .onSizeChanged { wpx = it.width.toFloat().coerceAtLeast(1f) }
            .pointerInput(Unit) {
                awaitEachGesture {
                    val down = awaitFirstDown(requireUnconsumed = false)
                    cb((down.position.x / wpx).coerceIn(0f, 1f))
                    down.consume()
                    while (true) {
                        val e = awaitPointerEvent()
                        val ch = e.changes.firstOrNull { it.id == down.id }
                        if (ch == null || !ch.pressed) break
                        cb((ch.position.x / wpx).coerceIn(0f, 1f))
                        ch.consume()
                    }
                }
            },
        contentAlignment = Alignment.CenterStart,
    ) {
        Box(
            Modifier
                .fillMaxWidth()
                .height(14.dp)
                .clip(RoundedCornerShape(7.dp))
                .background(track)
                .border(1.dp, Palette.Stroke, RoundedCornerShape(7.dp)),
        )
        Box(
            Modifier
                .offset { IntOffset((value.coerceIn(0f, 1f) * wpx - 11.dp.toPx()).roundToInt(), 0) }
                .size(22.dp)
                .clip(CircleShape)
                .background(Color.White)
                .border(2.dp, Palette.Accent, CircleShape),
        )
    }
}

/** แผงเลือกสีพู่กัน: ตัวอย่างสี + รหัสสี · สีสำเร็จรูป · แถบไล่สี เฉดสี / ความสด / ความสว่าง (เปลี่ยนแล้วใช้ทันที) · ฝั่งขวาของแผง = ปุ่มเซฟสี / ดูดสี / ลบสีที่เซฟ */
@Composable
private fun BrushColorPanel(
    color: Int,
    onColor: (Int) -> Unit,
    onClose: () -> Unit,
    onSave: () -> Unit,
    onEyedrop: () -> Unit,
    deleteMode: Boolean,
    savedCount: Int,
    onToggleDelete: () -> Unit,
) {
    val hsv0 = remember { FloatArray(3).also { android.graphics.Color.colorToHSV(color, it) } }
    var hue by remember { mutableFloatStateOf(hsv0[0]) }
    var sat by remember { mutableFloatStateOf(hsv0[1]) }
    var bri by remember { mutableFloatStateOf(hsv0[2]) }
    fun push(h: Float, s: Float, v: Float) {
        hue = h
        sat = s
        bri = v
        onColor(android.graphics.Color.HSVToColor(floatArrayOf(h, s, v)))
    }
    // สีเปลี่ยนจากข้างนอกแผง (แตะปุ่มสีที่เซฟ / ดูดสี) → ให้แถบเลื่อนตามสีใหม่ · เปลี่ยนจากแถบเลื่อนเอง สีตรงกันอยู่แล้วจึงไม่รีเซ็ต
    LaunchedEffect(color) {
        val mine = android.graphics.Color.HSVToColor(floatArrayOf(hue, sat, bri)) or (0xFF shl 24)
        if (mine != (color or (0xFF shl 24))) {
            val a = FloatArray(3)
            android.graphics.Color.colorToHSV(color, a)
            hue = a[0]
            sat = a[1]
            bri = a[2]
        }
    }
    val shape = RoundedCornerShape(20.dp)
    Column(
        Modifier
            .widthIn(max = 380.dp)
            .fillMaxWidth()
            .clip(shape)
            .background(Color(0xF01B1D22))
            .border(1.dp, Palette.Stroke, shape)
            .pointerInput(Unit) { detectTapGestures { } } // กันการแตะทะลุลงไปที่ภาพ
            .padding(12.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp),
    ) {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            Box(
                Modifier
                    .size(34.dp)
                    .clip(CircleShape)
                    .background(Color(color))
                    .border(2.dp, Color.White, CircleShape),
            )
            Text("สีพู่กัน", color = Color.White, fontSize = 15.sp, fontWeight = FontWeight.Medium, modifier = Modifier.weight(1f))
            Text(String.format("#%06X", color and 0xFFFFFF), color = Color(0xFFC9C4D4), fontSize = 13.sp)
            Box(
                Modifier
                    .clip(RoundedCornerShape(14.dp))
                    .background(Palette.Accent)
                    .clickable(onClick = onClose)
                    .padding(horizontal = 14.dp, vertical = 7.dp),
            ) { Text("เสร็จ", color = Color(0xFF2A1A66), fontSize = 13.sp, fontWeight = FontWeight.Medium) }
        }
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                for (rowColors in BrushSwatches.chunked(8)) {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        for (sw in rowColors) {
                            val on = (color or 0xFF000000.toInt()) == sw
                            Box(
                                Modifier
                                    .size(28.dp)
                                    .clip(CircleShape)
                                    .background(Color(sw))
                                    .border(if (on) 3.dp else 1.dp, if (on) Palette.Accent else Color(0x66FFFFFF), CircleShape)
                                    .clickable {
                                        val a = FloatArray(3)
                                        android.graphics.Color.colorToHSV(sw, a)
                                        push(a[0], a[1], a[2])
                                    },
                            )
                        }
                    }
                }
                ColorBar(
                    value = hue / 360f,
                    track = Brush.horizontalGradient(
                        listOf(Color(0xFFFF0000), Color(0xFFFFFF00), Color(0xFF00FF00), Color(0xFF00FFFF), Color(0xFF0000FF), Color(0xFFFF00FF), Color(0xFFFF0000)),
                    ),
                ) { push(it * 360f, sat, bri) }
                ColorBar(
                    value = sat,
                    track = Brush.horizontalGradient(
                        listOf(
                            Color(android.graphics.Color.HSVToColor(floatArrayOf(hue, 0f, bri))),
                            Color(android.graphics.Color.HSVToColor(floatArrayOf(hue, 1f, bri))),
                        ),
                    ),
                ) { push(hue, it, bri) }
                ColorBar(
                    value = bri,
                    track = Brush.horizontalGradient(
                        listOf(
                            Color(0xFF000000),
                            Color(android.graphics.Color.HSVToColor(floatArrayOf(hue, sat, 1f))),
                        ),
                    ),
                ) { push(hue, sat, it) }
            }
            // ฝั่งขวาของแผงสี: เซฟสี / ดูดสี / ลบสีที่เซฟ
            val railShape = RoundedCornerShape(16.dp)
            Column(
                Modifier.clip(railShape).background(Color(0x22FFFFFF)).padding(horizontal = 5.dp, vertical = 6.dp),
                verticalArrangement = Arrangement.spacedBy(6.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
            ) {
                ColorToolButton(CropGlyph.SAVE_COLOR, "เซฟสี", selected = false, enabled = true, onClick = onSave)
                ColorToolButton(CropGlyph.EYEDROPPER, "ดูดสี", selected = false, enabled = true, onClick = onEyedrop)
                ColorToolButton(CropGlyph.DELETE_COLOR, "ลบสี", selected = deleteMode, enabled = savedCount > 0 || deleteMode, onClick = onToggleDelete)
            }
        }
    }
}

/** ปุ่มไอคอนกลม + ป้ายชื่อเล็กใต้ปุ่ม (ในแผงสีพู่กัน) */
@Composable
private fun ColorToolButton(glyph: CropGlyph, label: String, selected: Boolean, enabled: Boolean, onClick: () -> Unit) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        CropIconButton(glyph, onClick = onClick, selected = selected, enabled = enabled, size = 40.dp)
        Text(label, color = Color(0xFFC9C4D4), fontSize = 10.sp, modifier = Modifier.alpha(if (enabled) 1f else 0.38f))
    }
}
