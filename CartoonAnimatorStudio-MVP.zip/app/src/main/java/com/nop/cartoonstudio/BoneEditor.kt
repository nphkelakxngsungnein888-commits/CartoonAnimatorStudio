package com.nop.cartoonstudio

import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.ui.graphics.drawscope.withTransform
import androidx.compose.ui.input.pointer.positionChanged
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.gestures.calculateZoom
import androidx.compose.foundation.gestures.calculatePan
import androidx.compose.foundation.gestures.calculateCentroid
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.height
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.foundation.layout.heightIn
import androidx.compose.runtime.key
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.zIndex
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.drawscope.drawIntoCanvas
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlin.math.hypot
import kotlin.math.roundToInt

private val BONE_IDLE = Color(0xFF29B6F6)    // ฟ้า = ยังไม่เลือก
private val BONE_SELECTED = Color(0xFF00E676) // เขียว = เลือกอยู่
private val BONE_CREATING = Color(0xFFFFB74D) // ส้ม = กำลังสร้าง
private val BONE_HAND = Color(0xFFFF80AB)     // ชมพู = กระดูกที่ตั้งเป็นมือ
private val BONE_ITEM = Color(0xFFB388FF)     // ม่วง = กระดูกที่ตั้งเป็นสิ่งของ
private val BONE_LINK = Color(0xFFFFD54F)     // เหลืองทอง = จุดที่ของติดกับมือ / มือที่รับของได้
private const val ITEM_SNAP = 90f             // ลากสิ่งของมาใกล้ปลายมือเท่านี้ (พิกเซล) = ดูดติด

/** โหมดแก้ไขตัวละครในฉาก: title = ชื่อตัวละคร, onConfirm = กด ✔ ตกลง (ปุ่มโหลด/เซฟตัวละครของแอปถูกซ่อน และ ✕ เปลี่ยนเป็นยกเลิก) */
class SceneEditUi(val title: String, val onConfirm: () -> Unit)

/**
 * หน้าจัดกระดูก (รอบที่ 1): มีจุดราก 1 จุด
 * - กดค้างปุ่ม "+" ค้างไว้ แล้วลากบนจอ = เพิ่มกระดูก (ออกจากปลายกระดูกที่เลือกอยู่ หรือจากจุดรากถ้าไม่ได้เลือก)
 * - แตะเส้นกระดูก = เลือก (เส้นเขียว), แตะจุดราก = ยกเลิกการเลือก
 * - ลากที่ปลายของกระดูกที่เลือก = ปรับความยาว/มุม
 */
@Composable
fun BoneEditorScreen(skeleton: Skeleton, onClose: () -> Unit, sceneEdit: SceneEditUi? = null) {
    var editingId by remember { mutableStateOf<Int?>(null) }
    var previewing by remember { mutableStateOf(false) }
    val editing = skeleton.bone(editingId)
    Box(Modifier.fillMaxSize()) {
        // หน้าจัดกระดูกอยู่ใต้หน้าใส่ภาพ/ดูตัวอย่างตลอด เพื่อไม่ให้ค่าที่เลือกไว้หาย
        BoneSkeletonScreen(skeleton, onClose, onEdit = { editingId = it }, onPreview = { previewing = true }, sceneEdit = sceneEdit)
        if (editing != null) BoneImageEditor(skeleton, editing) { editingId = null }
        if (previewing) BonePreview(skeleton) { previewing = false }
    }
}

@Composable
private fun BoneSkeletonScreen(skeleton: Skeleton, onClose: () -> Unit, onEdit: (Int) -> Unit, onPreview: () -> Unit, sceneEdit: SceneEditUi? = null) {
    val context = LocalContext.current
    val paint = remember {
        android.graphics.Paint(android.graphics.Paint.FILTER_BITMAP_FLAG or android.graphics.Paint.ANTI_ALIAS_FLAG)
    }
    var selectedId by remember { mutableStateOf<Int?>(null) }
    var creatingId by remember { mutableStateOf<Int?>(null) }
    var draggingTipId by remember { mutableStateOf<Int?>(null) }
    var adding by remember { mutableStateOf(false) }
    var canvasSize by remember { mutableStateOf(IntSize.Zero) }
    var viewScale by remember { mutableFloatStateOf(1f) } // ซูมดูรูป (2 นิ้ว) · ไม่กระทบพิกัดจริงของกระดูก
    var viewOff by remember { mutableStateOf(Offset.Zero) }
    var showSave by remember { mutableStateOf(false) }
    var showLoad by remember { mutableStateOf(false) }
    var showLayers by remember { mutableStateOf(true) }
    var currentName by remember { mutableStateOf<String?>(null) } // ชื่อตัวละครที่โหลด/เซฟล่าสุด
    var numEdit by remember { mutableStateOf<String?>(null) } // "length" / "angle" = กำลังพิมพ์ตัวเลขแก้ค่า
    var showBoneSettings by remember { mutableStateOf(false) }
    var draggingItemId by remember { mutableStateOf<Int?>(null) } // สิ่งของที่กำลังลากไปติดมือ
    var dragItemPos by remember { mutableStateOf<Offset?>(null) } // ตำแหน่งนิ้ว (พิกัดโลก) ตอนลากสิ่งของ
    var hoverHandId by remember { mutableStateOf<Int?>(null) } // มือที่อยู่ใกล้นิ้วพอจะดูดติด

    BackHandler(onBack = onClose)

    fun toWorld(o: Offset): Offset = Offset((o.x - canvasSize.width / 2f - viewOff.x) / viewScale, (o.y - canvasSize.height / 2f - viewOff.y) / viewScale)

    /** มือที่ใกล้จุด p ที่สุด (ในระยะดูดติด) และติดกับสิ่งของ item ได้ */
    fun handNear(item: Bone, p: Offset): Int? {
        var best: Bone? = null
        var bestD = ITEM_SNAP
        for (h in skeleton.bones) {
            if (!skeleton.canAttach(item, h)) continue
            val t = skeleton.tipOf(h)
            val d = hypot(t.x - p.x, t.y - p.y)
            if (d < bestD) {
                bestD = d
                best = h
            }
        }
        return best?.id
    }

    /** ปล่อยนิ้วหลังลากสิ่งของ: อยู่ใกล้ปลายมือ = ติด ไม่งั้นบอกวิธี */
    fun finishItemDrag() {
        val item = skeleton.bone(draggingItemId)
        val hand = skeleton.bone(hoverHandId)
        if (item != null && hand != null && skeleton.attachItem(item, hand)) {
            Toast.makeText(context, "ติด \"${item.name.ifBlank { "สิ่งของ" }}\" กับ \"${hand.name.ifBlank { "มือ" }}\" แล้ว", Toast.LENGTH_SHORT).show()
        } else if (item != null) {
            val anyHand = skeleton.bones.any { it.role == BoneRole.HAND }
            Toast.makeText(
                context,
                if (anyHand) "ลากไปวางใกล้ปลายมือ (วงชมพู) เพื่อติด" else "ยังไม่มีกระดูกที่ตั้งเป็นมือ — เลือกกระดูกแล้วกด ตั้งค่ากระดูก",
                Toast.LENGTH_SHORT,
            ).show()
        }
        draggingItemId = null
        dragItemPos = null
        hoverHandId = null
    }

    Row(Modifier.fillMaxSize().systemBarsPadding().background(Palette.Bg)) {
        // แถบเครื่องมือด้านซ้าย
        Column(
            Modifier
                .width(84.dp)
                .fillMaxHeight()
                .clip(RoundedCornerShape(topEnd = 22.dp, bottomEnd = 22.dp))
                .background(Palette.Panel)
                .padding(8.dp)
                .verticalScroll(rememberScrollState()),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            ToolButton("✕", if (sceneEdit != null) "ยกเลิก" else "ปิด", onClick = onClose)
            if (sceneEdit != null) { // แก้ไขตัวละครในฉาก: ✔ ตกลง = เลือกช่วงเฟรมแล้วใช้ผลที่แก้
                ToolButton("✔", "ตกลง", style = BtnStyle.PRIMARY, onClick = {
                    if (skeleton.bones.isEmpty()) {
                        Toast.makeText(context, "ต้องมีกระดูกอย่างน้อย 1 เส้น", Toast.LENGTH_SHORT).show()
                    } else {
                        sceneEdit.onConfirm()
                    }
                })
                Text(
                    "แก้ไข\n${sceneEdit.title}",
                    fontSize = 11.sp,
                    lineHeight = 15.sp,
                    maxLines = 3,
                    textAlign = TextAlign.Center,
                    color = Color(0xFFC9C4D4),
                )
            }

            ToolDivider()

            // ปุ่มเพิ่มกระดูก: กดค้างแล้วลากบนจอ
            Box(
                Modifier
                    .size(64.dp)
                    .clip(CircleShape)
                    .border(3.dp, if (adding) Color(0xFFC5E1A5) else Color(0x66C5E1A5), CircleShape)
                    .padding(4.dp)
                    .clip(CircleShape)
                    .background(if (adding) Color(0xFF558B2F) else Color(0xFF8BC34A))
                    .pointerInput(Unit) {
                        detectTapGestures(onPress = {
                            adding = true
                            tryAwaitRelease()
                            adding = false
                        })
                    },
                contentAlignment = Alignment.Center,
            ) { Text("+", fontSize = 34.sp, color = Color.White) }
            Text(
                "เพิ่มกระดูก\n(กดค้าง)",
                fontSize = 11.sp,
                lineHeight = 16.sp,
                textAlign = TextAlign.Center,
                color = Color(0xFFC9C4D4),
            )

            ToolDivider()

            ToolButton("✏️", "แก้ไข", enabled = selectedId != null, onClick = {
                val id = selectedId
                if (id == null) {
                    Toast.makeText(context, "แตะเลือกกระดูกก่อน", Toast.LENGTH_SHORT).show()
                } else {
                    onEdit(id)
                }
            })

            ToolButton("⚙️", "ตั้งค่า\nกระดูก", enabled = selectedId != null, onClick = {
                if (selectedId == null) {
                    Toast.makeText(context, "แตะเลือกกระดูกก่อน", Toast.LENGTH_SHORT).show()
                } else {
                    showBoneSettings = true
                }
            })

            ToolButton("🗑", "ลบ", enabled = selectedId != null, style = BtnStyle.DANGER, onClick = {
                val id = selectedId
                if (id != null) {
                    skeleton.remove(id)
                    selectedId = null
                }
            })

            ToolButton("▶", "ดูตัวอย่าง", onClick = onPreview)

            if (sceneEdit == null) { // หน้าแก้ไขตัวละครในฉากไม่โหลด/เซฟตัวละครของแอป (กันสลับโครงทั้งชุด)
                ToolDivider()

                ToolButton("📂", "โหลด\nตัวละคร", onClick = { showLoad = true })

                ToolButton("💾", "เซฟ\nตัวละคร", style = BtnStyle.PRIMARY, onClick = {
                    if (skeleton.bones.isEmpty()) {
                        Toast.makeText(context, "ยังไม่มีกระดูกให้เซฟ", Toast.LENGTH_SHORT).show()
                    } else {
                        showSave = true
                    }
                })
            }
        }

        // พื้นที่วาดกระดูก (จุดราก = กลางพื้นที่)
        Box(Modifier.weight(1f).fillMaxHeight()) {
            Canvas(
                Modifier
                    .fillMaxSize()
                    .onSizeChanged { canvasSize = it }
                    .pointerInput(skeleton) {
                        detectTapGestures { o ->
                            val p = toWorld(o)
                            if (hypot(p.x, p.y) < 22f) {
                                selectedId = null // แตะจุดราก
                            } else {
                                var best: Bone? = null
                                var bestD = 50f
                                for (b in skeleton.bones) {
                                    val d = distToSegment(p, skeleton.baseOf(b), skeleton.tipOf(b))
                                    if (d < bestD) {
                                        bestD = d
                                        best = b
                                    }
                                }
                                best?.let { selectedId = it.id }
                            }
                        }
                    }
                    .pointerInput(skeleton) {
                        detectDragGestures(
                            onDragStart = { o ->
                                val p = toWorld(o)
                                if (adding) {
                                    val parent = skeleton.bone(selectedId)
                                    val b = skeleton.add(parent?.id, MIN_BONE_LENGTH, 0f)
                                    skeleton.aim(b, p)
                                    creatingId = b.id
                                } else {
                                    val sel = skeleton.bone(selectedId)
                                    if (sel != null) {
                                        val t = skeleton.tipOf(sel)
                                        if (hypot(t.x - p.x, t.y - p.y) < 70f) {
                                            draggingTipId = sel.id
                                        } else if (sel.role == BoneRole.ITEM && distToSegment(p, skeleton.baseOf(sel), t) < 45f) {
                                            // ลากที่ตัวสิ่งของ (ไม่ใช่ปลาย): หน้านี้ติดมือไม่ได้ ให้ไปติดในหน้าแอนิเมต
                                            Toast.makeText(context, "สิ่งของติดมือได้ในหน้าแอนิเมตเท่านั้น (เมนูตัวละคร › ติด)", Toast.LENGTH_SHORT).show()
                                        }
                                    }
                                }
                            },
                            onDragEnd = {
                                if (draggingItemId != null) finishItemDrag()
                                creatingId?.let { selectedId = it }
                                creatingId = null
                                draggingTipId = null
                            },
                            onDragCancel = {
                                draggingItemId = null
                                dragItemPos = null
                                hoverHandId = null
                                creatingId?.let { selectedId = it }
                                creatingId = null
                                draggingTipId = null
                            },
                            onDrag = { change, _ ->
                                change.consume()
                                val dragItem = skeleton.bone(draggingItemId)
                                if (dragItem != null) {
                                    val wp = toWorld(change.position)
                                    dragItemPos = wp
                                    hoverHandId = handNear(dragItem, wp)
                                } else {
                                    val b = skeleton.bone(creatingId ?: draggingTipId)
                                    if (b != null) skeleton.aim(b, toWorld(change.position))
                                }
                            },
                        )
                    }
                    .pointerInput(Unit) { // 2 นิ้ว = ซูม/เลื่อนดูรูป (อยู่ชั้นในสุด รับก่อน แล้วกินการขยับไม่ให้ไปลากกระดูก)
                        awaitEachGesture {
                            awaitFirstDown(requireUnconsumed = false)
                            do {
                                val event = awaitPointerEvent()
                                if (event.changes.count { it.pressed } >= 2) {
                                    val zoom = event.calculateZoom()
                                    val pan = event.calculatePan()
                                    val c = event.calculateCentroid() - Offset(size.width / 2f, size.height / 2f)
                                    val k0 = viewScale
                                    val k1 = (k0 * zoom).coerceIn(0.3f, 12f)
                                    viewOff = Offset(c.x - (c.x - viewOff.x) * (k1 / k0) + pan.x, c.y - (c.y - viewOff.y) * (k1 / k0) + pan.y)
                                    viewScale = k1
                                    event.changes.forEach { if (it.positionChanged()) it.consume() }
                                }
                            } while (event.changes.any { it.pressed })
                        }
                    },
            ) {
                val origin = Offset(this.size.width / 2f, this.size.height / 2f)
                withTransform({
                    translate(viewOff.x, viewOff.y)
                    scale(viewScale, viewScale, pivot = origin)
                }) {
                drawIntoCanvas { c -> // ภาพของกระดูก (วาดใต้เส้นกระดูก ไม่มีกรอบ)
                    for (b in skeleton.bones) {
                        if (b.images.isEmpty()) continue
                        val base = origin + skeleton.baseOf(b)
                        val ang = skeleton.worldAngle(b)
                        for (img in b.images) c.nativeCanvas.drawBitmap(img.bitmap, boneImageMatrix(img, base, ang), paint)
                    }
                }
                for (b in skeleton.bones) {
                    val a = origin + skeleton.baseOf(b)
                    val t = origin + skeleton.tipOf(b)
                    val col = when {
                        b.id == creatingId -> BONE_CREATING
                        b.id == selectedId -> BONE_SELECTED
                        b.role == BoneRole.HAND -> BONE_HAND
                        b.role == BoneRole.ITEM -> BONE_ITEM
                        else -> BONE_IDLE
                    }
                    drawLine(col, a, t, strokeWidth = 7f)
                    drawCircle(col, radius = 10f, center = t)
                    if (b.role == BoneRole.HAND) { // มือ: วงแหวนที่ปลาย
                        drawCircle(col, radius = 18f, center = t, style = Stroke(width = 3f))
                    } else if (b.role == BoneRole.ITEM) { // สิ่งของ: จุดสี่เหลี่ยมที่ปลาย + วงทองที่โคนถ้าติดอยู่กับมือ
                        drawRect(col, topLeft = Offset(t.x - 11f, t.y - 11f), size = androidx.compose.ui.geometry.Size(22f, 22f))
                        if (skeleton.bone(b.parentId)?.role == BoneRole.HAND) drawCircle(BONE_LINK, radius = 15f, center = a, style = Stroke(width = 4f))
                    }
                }
                // ตอนลากสิ่งของ: วงชมพูรอบปลายมือที่ติดได้ มือที่ใกล้นิ้วพอจะเรืองทอง + เส้นประไปหามือ
                val dragItem = skeleton.bone(draggingItemId)
                val fingerPos = dragItemPos
                if (dragItem != null && fingerPos != null) {
                    for (h in skeleton.bones) {
                        if (!skeleton.canAttach(dragItem, h)) continue
                        drawCircle(BONE_HAND.copy(alpha = 0.7f), radius = 26f, center = origin + skeleton.tipOf(h), style = Stroke(width = 4f))
                    }
                    val fp = origin + fingerPos
                    skeleton.bone(hoverHandId)?.let { h ->
                        val ht = origin + skeleton.tipOf(h)
                        drawCircle(BONE_LINK.copy(alpha = 0.3f), radius = 36f, center = ht)
                        drawCircle(BONE_LINK, radius = 36f, center = ht, style = Stroke(width = 6f))
                        drawLine(BONE_LINK, fp, ht, strokeWidth = 4f, pathEffect = PathEffect.dashPathEffect(floatArrayOf(14f, 10f)))
                    }
                    drawCircle(BONE_ITEM, radius = 15f, center = fp)
                    drawCircle(Color.White, radius = 15f, center = fp, style = Stroke(width = 3f))
                }
                drawCircle(BONE_IDLE, radius = 16f, center = origin, style = Stroke(width = 4f))
                drawCircle(BONE_IDLE, radius = 5f, center = origin)
                }
            }

            if (viewScale != 1f || viewOff != Offset.Zero) { // ปุ่มลอยรีเซ็ตซูม (ขวาบน)
                Box(
                    Modifier
                        .align(Alignment.TopEnd)
                        .padding(8.dp)
                        .size(44.dp)
                        .clip(RoundedCornerShape(12.dp))
                        .background(Color(0xE6272734))
                        .border(1.dp, Palette.Stroke, RoundedCornerShape(12.dp))
                        .clickable {
                            viewScale = 1f
                            viewOff = Offset.Zero
                        },
                    contentAlignment = Alignment.Center,
                ) { Text("⌖", color = Color.White, fontSize = 20.sp) }
            }

            currentName?.let { n ->
                Text(
                    "กำลังแก้: $n",
                    Modifier
                        .align(Alignment.TopStart)
                        .padding(8.dp)
                        .clip(RoundedCornerShape(10.dp))
                        .background(Color(0x99000000))
                        .padding(horizontal = 10.dp, vertical = 4.dp),
                    color = Color.White,
                    fontSize = 12.sp,
                    maxLines = 1,
                )
            }

            if (adding) {
                Box(
                    Modifier
                        .align(Alignment.TopCenter)
                        .padding(8.dp)
                        .clip(RoundedCornerShape(12.dp))
                        .background(Color(0xFFFFD600))
                        .padding(horizontal = 12.dp, vertical = 6.dp),
                ) {
                    Text(
                        "ลากบนจอเพื่อสร้างกระดูก (เริ่มจากปลายกระดูกที่เลือก หรือจุดราก)",
                        color = Color.Black,
                        fontSize = 13.sp,
                    )
                }
            }

            // ความยาว / มุม ของกระดูกที่กำลังสร้างหรือเลือกอยู่ (แตะที่ตัวเลขเพื่อพิมพ์ค่าเอง, ปุ่มกุญแจ = ล็อกความยาว)
            val shown = skeleton.bone(creatingId ?: selectedId)
            if (shown != null) {
                val ang = skeleton.worldAngle(shown).roundToInt()
                val canType = creatingId == null
                Column(
                    Modifier
                        .align(Alignment.BottomStart)
                        .padding(8.dp)
                        .clip(RoundedCornerShape(10.dp))
                        .background(Color(0x99000000))
                        .padding(horizontal = 10.dp, vertical = 6.dp),
                    verticalArrangement = Arrangement.spacedBy(4.dp),
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        Text(
                            "ความยาว: ${shown.length.roundToInt()} ✎",
                            Modifier
                                .clickable(enabled = canType) {
                                    if (shown.lengthLocked) {
                                        Toast.makeText(context, "ความยาวถูกล็อกอยู่ — กดกุญแจเพื่อปลดล็อกก่อน", Toast.LENGTH_SHORT).show()
                                    } else {
                                        numEdit = "length"
                                    }
                                }
                                .padding(vertical = 6.dp),
                            color = Color.White,
                            fontSize = 14.sp,
                        )
                        Box(
                            Modifier
                                .size(36.dp)
                                .clip(CircleShape)
                                .background(if (shown.lengthLocked) Palette.Accent else Palette.PanelHigh)
                                .clickable(enabled = canType) { shown.lengthLocked = !shown.lengthLocked },
                            contentAlignment = Alignment.Center,
                        ) { Text(if (shown.lengthLocked) "🔒" else "🔓", fontSize = 16.sp) }
                    }
                    Text(
                        "มุม: ${String.format("%+d", ang)} ✎",
                        Modifier.clickable(enabled = canType) { numEdit = "angle" }.padding(vertical = 6.dp),
                        color = Color.White,
                        fontSize = 14.sp,
                    )
                    Text( // องศาที่หมุนจากข้อ = มุมเทียบกับกระดูกที่พ่วง (วงกลมขาวบนจอ)
                        "จากข้อ: ${String.format("%+d", normalizeAngle(shown.angle).roundToInt())}° ✎",
                        Modifier.clickable(enabled = canType) { numEdit = "rel" }.padding(vertical = 6.dp),
                        color = Color.White,
                        fontSize = 14.sp,
                    )
                    if (shown.role != BoneRole.NORMAL) { // บอกประเภท + ปุ่มถอดสิ่งของออกจากมือ
                        val host = skeleton.bone(shown.parentId)?.takeIf { it.role == BoneRole.HAND }
                        val title = shown.name.ifBlank { if (shown.role == BoneRole.HAND) "มือ" else "สิ่งของ" }
                        Text(
                            if (shown.role == BoneRole.HAND) "🖐 $title"
                            else if (host != null) "🎒 $title · ติดกับ ${host.name.ifBlank { "มือ" }}"
                            else "🎒 $title · ติดมือได้ในหน้าแอนิเมต",
                            color = BONE_LINK,
                            fontSize = 12.sp,
                        )
                        if (shown.role == BoneRole.ITEM && host != null && creatingId == null) {
                            Text(
                                "🔗 ถอดออกจากมือ",
                                Modifier
                                    .clickable {
                                        skeleton.detachItem(shown)
                                        Toast.makeText(context, "ถอด \"$title\" ออกจากมือแล้ว", Toast.LENGTH_SHORT).show()
                                    }
                                    .padding(vertical = 6.dp),
                                color = Color(0xFFFF8A80),
                                fontSize = 13.sp,
                            )
                        }
                    }
                }
            }
        }

        // แผงเลเยอร์ด้านขวา (ซ่อน/แสดงได้)
        if (showLayers) {
            LayerPanel(skeleton, selectedId, onSelect = { selectedId = it }, onCollapse = { showLayers = false })
        } else {
            Box(
                Modifier
                    .width(44.dp)
                    .fillMaxHeight()
                    .clip(RoundedCornerShape(topStart = 22.dp, bottomStart = 22.dp))
                    .background(Palette.Panel)
                    .padding(horizontal = 4.dp, vertical = 8.dp),
                contentAlignment = Alignment.TopCenter,
            ) { ToolButton("☰", "ชั้น", onClick = { showLayers = true }) }
        }
    }

    if (showSave) {
        SaveCharacterDialog(skeleton, currentName.orEmpty(), onSaved = { currentName = it }) { showSave = false }
    }
    val settingsBone = skeleton.bone(selectedId)
    if (showBoneSettings && settingsBone != null) {
        BoneSettingsDialog(skeleton, settingsBone) { showBoneSettings = false }
    }
    numEdit?.let { which ->
        val sel = skeleton.bone(selectedId)
        if (sel != null && which == "length") {
            NumberInputDialog("ใส่ความยาว", sel.length.roundToInt().toString(), allowSign = false, onConfirm = { v ->
                sel.length = maxOf(v, MIN_BONE_LENGTH)
                numEdit = null
            }, onDismiss = { numEdit = null })
        } else if (sel != null && which == "rel") {
            NumberInputDialog("ใส่องศาที่หมุนจากข้อ", normalizeAngle(sel.angle).roundToInt().toString(), allowSign = true, onConfirm = { v ->
                sel.angle = normalizeAngle(v) // เทียบกับกระดูกที่พ่วง (ไม่มี = มุมจริง) ลูกๆ หมุนตามเอง
                numEdit = null
            }, onDismiss = { numEdit = null })
        } else if (sel != null && which == "angle") {
            NumberInputDialog("ใส่มุม (องศา)", skeleton.worldAngle(sel).roundToInt().toString(), allowSign = true, onConfirm = { v ->
                val parentAbs = skeleton.bone(sel.parentId)?.let { skeleton.worldAngle(it) } ?: 0f
                sel.angle = normalizeAngle(v - parentAbs) // ค่าที่พิมพ์ = มุมจริงเหมือนที่แสดงบนจอ
                numEdit = null
            }, onDismiss = { numEdit = null })
        }
    }
    if (showLoad) {
        LoadCharacterPicker(
            hasWork = skeleton.bones.isNotEmpty(),
            onLoaded = { loaded, name ->
                skeleton.replaceWith(loaded)
                selectedId = null
                creatingId = null
                draggingTipId = null
                draggingItemId = null
                dragItemPos = null
                hoverHandId = null
                currentName = name
                showLoad = false
                Toast.makeText(context, "โหลดตัวละคร \"$name\" แล้ว", Toast.LENGTH_SHORT).show()
            },
        ) { showLoad = false }
    }
}

private enum class BtnStyle { NORMAL, PRIMARY, DANGER }

/** ตั้งค่ากระดูก: ตั้งชื่อ + เลือกประเภท (ปกติ / มือ / สิ่งของ) ของกระดูกที่เลือก */
@Composable
private fun BoneSettingsDialog(skeleton: Skeleton, bone: Bone, onDismiss: () -> Unit) {
    var role by remember { mutableStateOf(bone.role) }
    var name by remember { mutableStateOf(bone.name) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("ตั้งค่ากระดูก") },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                OutlinedTextField(
                    value = name,
                    onValueChange = { name = it.take(20) },
                    singleLine = true,
                    label = { Text("ชื่อ (ไม่ใส่ก็ได้)") },
                )
                Text("ประเภท", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                RoleOption("🦴", "ปกติ", "กระดูกทั่วไป", role == BoneRole.NORMAL) { role = BoneRole.NORMAL }
                RoleOption("🖐", "มือ", "รับสิ่งของมาติดที่ปลายกระดูกนี้", role == BoneRole.HAND) { role = BoneRole.HAND }
                RoleOption("🎒", "สิ่งของ", "ติด/ถอดกับมือได้ในหน้าแอนิเมต (เมนูตัวละคร › ติด) ตั้งแต่เฟรมที่เลือกไปจนจบ", role == BoneRole.ITEM) { role = BoneRole.ITEM }
            }
        },
        confirmButton = {
            TextButton(onClick = {
                bone.name = name.trim()
                bone.role = role
                onDismiss()
            }) { Text("ตกลง") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("ยกเลิก") } },
    )
}

@Composable
private fun RoleOption(icon: String, title: String, hint: String, selected: Boolean, onClick: () -> Unit) {
    val shape = RoundedCornerShape(14.dp)
    Row(
        Modifier
            .fillMaxWidth()
            .clip(shape)
            .background(if (selected) Color(0xFF42338A) else Palette.PanelHigh)
            .border(if (selected) 2.dp else 1.dp, if (selected) Palette.Accent else Palette.Stroke, shape)
            .clickable(onClick = onClick)
            .padding(horizontal = 12.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(10.dp),
    ) {
        Text(icon, fontSize = 22.sp)
        Column(Modifier.weight(1f)) {
            Text(title, fontSize = 14.sp, color = Color(0xFFE7E3EE), fontWeight = if (selected) androidx.compose.ui.text.font.FontWeight.Bold else androidx.compose.ui.text.font.FontWeight.Normal)
            Text(hint, fontSize = 11.sp, lineHeight = 15.sp, color = Color(0xFF9E9AB0))
        }
        if (selected) Text("✓", fontSize = 16.sp, color = Palette.Accent)
    }
}

@Composable
private fun ToolDivider() {
    Box(Modifier.fillMaxWidth().padding(horizontal = 6.dp).height(1.dp).background(Palette.Stroke))
}

/** ปุ่มเครื่องมือในแถบข้าง: ไอคอนอยู่บน ชื่ออยู่ล่าง */
@Composable
private fun ToolButton(
    icon: String,
    label: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    enabled: Boolean = true,
    style: BtnStyle = BtnStyle.NORMAL,
) {
    val shape = RoundedCornerShape(14.dp)
    val bg = if (style == BtnStyle.PRIMARY) Palette.Accent else Palette.PanelHigh
    val fg = when (style) {
        BtnStyle.PRIMARY -> Color(0xFF2A1A66)
        BtnStyle.DANGER -> Color(0xFFFF8A80)
        BtnStyle.NORMAL -> Color(0xFFE7E3EE)
    }
    Column(
        modifier
            .fillMaxWidth()
            .heightIn(min = 56.dp)
            .alpha(if (enabled) 1f else 0.38f)
            .clip(shape)
            .background(bg)
            .border(1.dp, if (style == BtnStyle.PRIMARY) Palette.Accent else Palette.Stroke, shape)
            .clickable(enabled = enabled, onClick = onClick)
            .padding(horizontal = 2.dp, vertical = 6.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center,
    ) {
        Text(icon, fontSize = 20.sp, color = fg)
        Text(label, fontSize = 11.sp, lineHeight = 16.sp, color = fg, textAlign = TextAlign.Center)
    }
}

/**
 * แผงเลเยอร์: 1 กระดูก = 1 เลเยอร์ เลขเรียงจากล่างขึ้นบน (กระดูกแรกที่สร้าง = เลเยอร์ 1)
 * แถวบนสุดของรายการ = ชั้นบนสุด ภาพทับแถวที่อยู่ล่างกว่า ลากที่ "≡" เพื่อจัดลำดับ แตะแถวเพื่อเลือกกระดูก
 */
@Composable
private fun LayerPanel(skeleton: Skeleton, selectedId: Int?, onSelect: (Int) -> Unit, onCollapse: () -> Unit) {
    val rowH = 52.dp
    val gap = 6.dp
    val stepPx = with(LocalDensity.current) { (rowH + gap).toPx() }
    var dragId by remember { mutableStateOf<Int?>(null) }
    var dragOffset by remember { mutableFloatStateOf(0f) }
    val total = skeleton.bones.size
    val shown = skeleton.bones.toList().asReversed() // แถวบนสุด = ชั้นบนสุด

    Column(
        Modifier
            .width(104.dp)
            .fillMaxHeight()
            .clip(RoundedCornerShape(topStart = 22.dp, bottomStart = 22.dp))
            .background(Palette.Panel)
            .padding(horizontal = 6.dp, vertical = 8.dp),
        verticalArrangement = Arrangement.spacedBy(6.dp),
    ) {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Text("เลเยอร์", Modifier.weight(1f), fontSize = 14.sp, color = Palette.Accent)
            Box(
                Modifier
                    .size(32.dp)
                    .clip(CircleShape)
                    .background(Palette.PanelHigh)
                    .clickable(onClick = onCollapse),
                contentAlignment = Alignment.Center,
            ) { Text("▸", fontSize = 16.sp, color = Color(0xFFE7E3EE)) }
        }
        Text("ลาก ≡ เพื่อจัดลำดับ\nบนสุด = ทับล่าง", fontSize = 10.sp, lineHeight = 14.sp, color = Color(0xFF9E9AB0))

        if (shown.isEmpty()) {
            Text("ยังไม่มีกระดูก", fontSize = 12.sp, color = Color(0xFF9E9AB0))
        }

        Column(
            Modifier.weight(1f).verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.spacedBy(gap),
        ) {
            shown.forEachIndexed { idx, b ->
                key(b.id) {
                    val dragging = dragId == b.id
                    val selected = b.id == selectedId
                    val shape = RoundedCornerShape(12.dp)
                    Row(
                        Modifier
                            .fillMaxWidth()
                            .height(rowH)
                            .zIndex(if (dragging) 1f else 0f)
                            .graphicsLayer { translationY = if (dragging) dragOffset else 0f }
                            .clip(shape)
                            .background(if (dragging) Color(0xFF3B3B50) else Palette.PanelHigh)
                            .border(if (selected) 2.dp else 1.dp, if (selected) BONE_SELECTED else Palette.Stroke, shape)
                            .clickable { onSelect(b.id) },
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        // ที่จับลาก
                        Box(
                            Modifier
                                .width(28.dp)
                                .fillMaxHeight()
                                .pointerInput(b.id) {
                                    detectDragGestures(
                                        onDragStart = {
                                            dragId = b.id
                                            dragOffset = 0f
                                            onSelect(b.id)
                                        },
                                        onDragEnd = { dragId = null; dragOffset = 0f },
                                        onDragCancel = { dragId = null; dragOffset = 0f },
                                        onDrag = { change, d ->
                                            change.consume()
                                            dragOffset += d.y
                                            // ลงล่าง = ลงชั้นล่าง (ตำแหน่งในลิสต์กระดูกลดลง), ขึ้นบน = ขึ้นชั้นบน
                                            if (dragOffset > stepPx / 2f) {
                                                if (skeleton.moveBone(b.id, -1)) dragOffset -= stepPx
                                                else dragOffset = stepPx / 2f
                                            } else if (dragOffset < -stepPx / 2f) {
                                                if (skeleton.moveBone(b.id, +1)) dragOffset += stepPx
                                                else dragOffset = -stepPx / 2f
                                            }
                                        },
                                    )
                                },
                            contentAlignment = Alignment.Center,
                        ) { Text("≡", fontSize = 22.sp, color = Palette.Accent) }
                        // รูปย่อของเลเยอร์ (ภาพบนสุดของกระดูก) · ไม่มีภาพ = กรอบว่างเลขชั้น · มุมซ้ายล่าง = บทบาท 🖐/🎒
                        Box(
                            Modifier
                                .weight(1f)
                                .padding(end = 4.dp)
                                .height(44.dp)
                                .clip(RoundedCornerShape(8.dp))
                                .background(Color(0xFF1B1D22)),
                            contentAlignment = Alignment.Center,
                        ) {
                            val top = b.images.lastOrNull()
                            if (top != null) {
                                Image(top.bitmap.asImageBitmap(), contentDescription = null, contentScale = ContentScale.Fit, modifier = Modifier.fillMaxSize().padding(2.dp))
                            } else {
                                Text("${total - idx}", fontSize = 14.sp, color = Color(0xFF6F6B80))
                            }
                            val badge = when (b.role) {
                                BoneRole.HAND -> "🖐"
                                BoneRole.ITEM -> "🎒"
                                else -> ""
                            }
                            if (badge.isNotEmpty()) Text(badge, fontSize = 11.sp, modifier = Modifier.align(Alignment.BottomStart).padding(1.dp))
                        }
                    }
                }
            }
        }
    }
}

/** เลือกตัวละครที่เซฟไว้ เพื่อโหลดเข้ามาแก้ไขต่อ (ถ้าตอนนี้มีกระดูกอยู่แล้วจะถามยืนยันก่อนแทนที่) */
@Composable
private fun LoadCharacterPicker(hasWork: Boolean, onLoaded: (Skeleton, String) -> Unit, onDismiss: () -> Unit) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var saved by remember { mutableStateOf<List<SavedCharacter>?>(null) }
    var busy by remember { mutableStateOf(false) }
    var pending by remember { mutableStateOf<String?>(null) }

    LaunchedEffect(Unit) {
        saved = runCatching { withContext(Dispatchers.IO) { CharacterStore.list(context) } }.getOrDefault(emptyList())
    }

    fun load(name: String) {
        busy = true
        scope.launch {
            val r = runCatching { withContext(Dispatchers.IO) { CharacterStore.load(context, name) } }
            busy = false
            r.onSuccess { onLoaded(it, name) }.onFailure {
                Toast.makeText(context, "โหลดไม่สำเร็จ: ${it.message ?: it.javaClass.simpleName}", Toast.LENGTH_LONG).show()
            }
        }
    }

    AlertDialog(
        onDismissRequest = { if (!busy) onDismiss() },
        title = { Text("โหลดตัวละครมาแก้ไข") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                val list = saved
                when {
                    list == null -> Text("กำลังอ่านรายการ...")
                    list.isEmpty() -> Text("ยังไม่มีตัวละครที่เซฟไว้", color = MaterialTheme.colorScheme.onSurfaceVariant)
                    else -> LazyColumn(Modifier.heightIn(max = 320.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        items(list, key = { it.name }) { c ->
                            val shape = RoundedCornerShape(12.dp)
                            Column(
                                Modifier
                                    .fillMaxWidth()
                                    .clip(shape)
                                    .background(Palette.PanelHigh)
                                    .border(1.dp, Palette.Stroke, shape)
                                    .clickable(enabled = !busy) { if (hasWork) pending = c.name else load(c.name) }
                                    .padding(horizontal = 14.dp, vertical = 10.dp),
                            ) {
                                Text(c.name, fontSize = 16.sp)
                                Text(
                                    SimpleDateFormat("d MMM yyyy HH:mm", Locale.getDefault()).format(Date(c.savedAt)),
                                    fontSize = 11.sp,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                                )
                            }
                        }
                    }
                }
                if (busy) Text("กำลังโหลด...", color = MaterialTheme.colorScheme.primary)
            }
        },
        confirmButton = { TextButton(enabled = !busy, onClick = onDismiss) { Text("ปิด") } },
    )

    pending?.let { name ->
        AlertDialog(
            onDismissRequest = { pending = null },
            title = { Text("แทนที่ตัวละครที่กำลังแก้?") },
            text = { Text("กระดูกและภาพที่อยู่บนจอตอนนี้จะถูกแทนที่ด้วย \"$name\" (ถ้ายังไม่ได้เซฟ งานปัจจุบันจะหาย)") },
            confirmButton = { TextButton(onClick = { pending = null; load(name) }) { Text("โหลดเลย") } },
            dismissButton = { TextButton(onClick = { pending = null }) { Text("ยกเลิก") } },
        )
    }
}

/** ตั้งชื่อแล้วเซฟตัวละคร (กระดูก + ภาพ) ลงที่เก็บของแอป ชื่อซ้ำ = เขียนทับตัวเดิม */
@Composable
private fun SaveCharacterDialog(skeleton: Skeleton, initialName: String, onSaved: (String) -> Unit, onDismiss: () -> Unit) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var name by remember { mutableStateOf(initialName) }
    var busy by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }
    var existing by remember { mutableStateOf<List<String>>(emptyList()) }
    var showDelete by remember { mutableStateOf(false) }

    LaunchedEffect(Unit) {
        existing = runCatching { withContext(Dispatchers.IO) { CharacterStore.list(context).map { it.name } } }
            .getOrDefault(emptyList())
    }

    val clean = CharacterStore.cleanName(name)
    val overwrite = clean.isNotEmpty() && clean in existing

    AlertDialog(
        onDismissRequest = { if (!busy) onDismiss() },
        title = { Text("เซฟตัวละคร") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(
                    value = name,
                    onValueChange = { name = it; error = null },
                    label = { Text("ชื่อตัวละคร") },
                    singleLine = true,
                    enabled = !busy,
                )
                if (existing.isNotEmpty()) {
                    val shape = RoundedCornerShape(12.dp)
                    Row(
                        Modifier
                            .fillMaxWidth()
                            .clip(shape)
                            .background(Palette.PanelHigh)
                            .border(1.dp, Color(0x66FF8A80), shape)
                            .clickable(enabled = !busy) { showDelete = true }
                            .padding(vertical = 10.dp),
                        horizontalArrangement = Arrangement.Center,
                        verticalAlignment = Alignment.CenterVertically,
                    ) { Text("🗑  ลบเซฟ", color = Color(0xFFFF8A80), fontSize = 14.sp) }
                }
                if (overwrite) {
                    Text("มีชื่อนี้อยู่แล้ว — การเซฟจะเขียนทับตัวเดิม", color = MaterialTheme.colorScheme.error)
                }
                error?.let { Text(it, color = MaterialTheme.colorScheme.error) }
                if (busy) Text("กำลังบันทึก...", color = MaterialTheme.colorScheme.primary)
            }
        },
        confirmButton = {
            TextButton(
                enabled = !busy,
                onClick = {
                    if (clean.isEmpty()) {
                        error = "ตั้งชื่อตัวละครก่อน"
                    } else {
                        busy = true
                        scope.launch {
                            val r = runCatching { withContext(Dispatchers.IO) { CharacterStore.save(context, clean, skeleton) } }
                            busy = false
                            r.onSuccess {
                                Toast.makeText(context, "เซฟตัวละคร \"$clean\" แล้ว", Toast.LENGTH_SHORT).show()
                                onSaved(clean)
                                onDismiss()
                            }.onFailure {
                                error = "เซฟไม่สำเร็จ: ${it.message ?: it.javaClass.simpleName}"
                            }
                        }
                    }
                },
            ) { Text(if (overwrite) "เขียนทับ" else "เซฟ") }
        },
        dismissButton = { TextButton(enabled = !busy, onClick = onDismiss) { Text("ยกเลิก") } },
    )

    if (showDelete) {
        DeleteSavesDialog(onDeleted = { gone -> existing = existing - gone.toSet() }) { showDelete = false }
    }
}

/** ลบเซฟ: ติ๊กเลือกตัวละครที่จะลบ (เลือกได้หลายตัว) แล้วกดตกลง */
@Composable
private fun DeleteSavesDialog(onDeleted: (List<String>) -> Unit, onDismiss: () -> Unit) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var saved by remember { mutableStateOf<List<SavedCharacter>?>(null) }
    var picked by remember { mutableStateOf<Set<String>>(emptySet()) }
    var busy by remember { mutableStateOf(false) }
    val red = Color(0xFFFF8A80)

    LaunchedEffect(Unit) {
        saved = runCatching { withContext(Dispatchers.IO) { CharacterStore.list(context) } }.getOrDefault(emptyList())
    }

    AlertDialog(
        onDismissRequest = { if (!busy) onDismiss() },
        title = { Text("ลบเซฟ") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                val list = saved
                when {
                    list == null -> Text("กำลังอ่านรายการ...")
                    list.isEmpty() -> Text("ไม่มีตัวละครที่เซฟไว้", color = MaterialTheme.colorScheme.onSurfaceVariant)
                    else -> {
                        Text("แตะเพื่อเลือกตัวละครที่จะลบ", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        LazyColumn(Modifier.heightIn(max = 300.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            items(list, key = { it.name }) { c ->
                                val on = c.name in picked
                                val shape = RoundedCornerShape(12.dp)
                                Row(
                                    Modifier
                                        .fillMaxWidth()
                                        .clip(shape)
                                        .background(if (on) Color(0x33FF8A80) else Palette.PanelHigh)
                                        .border(if (on) 2.dp else 1.dp, if (on) red else Palette.Stroke, shape)
                                        .clickable(enabled = !busy) { picked = if (on) picked - c.name else picked + c.name }
                                        .padding(horizontal = 12.dp, vertical = 10.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(12.dp),
                                ) {
                                    Box(
                                        Modifier
                                            .size(24.dp)
                                            .clip(CircleShape)
                                            .background(if (on) red else Color.Transparent)
                                            .border(2.dp, if (on) red else Palette.Stroke, CircleShape),
                                        contentAlignment = Alignment.Center,
                                    ) { if (on) Text("✓", color = Color(0xFF3B0A0A), fontSize = 14.sp) }
                                    Column(Modifier.weight(1f)) {
                                        Text(c.name, fontSize = 16.sp, maxLines = 1)
                                        Text(
                                            SimpleDateFormat("d MMM yyyy HH:mm", Locale.getDefault()).format(Date(c.savedAt)),
                                            fontSize = 11.sp,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
                if (busy) Text("กำลังลบ...", color = MaterialTheme.colorScheme.primary)
            }
        },
        confirmButton = {
            TextButton(
                enabled = !busy && picked.isNotEmpty(),
                onClick = {
                    busy = true
                    val names = picked.toList()
                    scope.launch {
                        val failed = ArrayList<String>()
                        withContext(Dispatchers.IO) {
                            for (n in names) runCatching { CharacterStore.delete(context, n) }.onFailure { failed.add(n) }
                        }
                        busy = false
                        val done = names - failed.toSet()
                        if (done.isNotEmpty()) onDeleted(done)
                        if (failed.isEmpty()) {
                            Toast.makeText(context, "ลบเซฟแล้ว ${done.size} ตัว", Toast.LENGTH_SHORT).show()
                            onDismiss()
                        } else {
                            Toast.makeText(context, "ลบไม่สำเร็จ: ${failed.joinToString()}", Toast.LENGTH_LONG).show()
                            saved = runCatching { withContext(Dispatchers.IO) { CharacterStore.list(context) } }.getOrDefault(emptyList())
                            picked = emptySet()
                        }
                    }
                },
            ) { Text(if (picked.isEmpty()) "ตกลง" else "ตกลง (ลบ ${picked.size})", color = if (picked.isEmpty()) Color.Unspecified else red) }
        },
        dismissButton = { TextButton(enabled = !busy, onClick = onDismiss) { Text("ยกเลิก") } },
    )
}

/** ใส่ตัวเลข (ความยาว/มุม) ด้วยแผงตัวเลขลอย; allowSign = มีปุ่ม ± สลับเครื่องหมายลบ */
@Composable
private fun NumberInputDialog(title: String, initial: String, allowSign: Boolean, onConfirm: (Float) -> Unit, onDismiss: () -> Unit) {
    FloatingPad(
        title = title,
        unit = "",
        initial = initial.trim().toFloatOrNull()?.takeIf { it.isFinite() } ?: 0f,
        allowDot = true,
        allowZero = true,
        allowSign = allowSign,
        onDismiss = onDismiss,
        onOk = onConfirm,
    )
}

private fun distToSegment(p: Offset, a: Offset, b: Offset): Float {
    val abx = b.x - a.x
    val aby = b.y - a.y
    val len2 = abx * abx + aby * aby
    val t = if (len2 == 0f) 0f else (((p.x - a.x) * abx + (p.y - a.y) * aby) / len2).coerceIn(0f, 1f)
    val cx = a.x + t * abx
    val cy = a.y + t * aby
    return hypot(p.x - cx, p.y - cy)
}
