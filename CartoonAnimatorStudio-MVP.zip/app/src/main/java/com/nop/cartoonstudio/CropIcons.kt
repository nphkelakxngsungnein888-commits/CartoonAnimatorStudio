package com.nop.cartoonstudio

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

/** ไอคอนของปุ่มในหน้าแก้ไขภาพ (ไม่มีตัวหนังสือ) */
internal enum class CropGlyph { ADD_LASSO, REMOVE_LASSO, CURVE, ERASER, JOY, UNDO, REDO, FIT, ADD_IMAGE, CHECK, CROSS, MOVE,
    EDIT, SCALE, ROTATE, FIT_BONE, CANCEL_FIT, FLIP_H, FLIP_V, TRASH,
    SIZE, ERASE_IN, ERASE_ALONG, INSTANT, LINE, OPEN_LINE, CLOSED_LINE, PLUS, MINUS,
}

/** NORMAL = ปุ่มกลมสีเข้ม, OK = เขียว (ถูก), CANCEL = แดง (ผิด) */
internal enum class CropTone { NORMAL, OK, CANCEL }

private val IconGreen = Color(0xFF2FBF71)
private val IconRed = Color(0xFFE5484D)
private val IconBg = Color(0xE6272734)

/** ปุ่มไอคอนกลม: selected = โหมดที่ใช้อยู่, busy = กำลังทำงาน (แสดง …) */
@Composable
internal fun CropIconButton(
    glyph: CropGlyph,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    selected: Boolean = false,
    enabled: Boolean = true,
    busy: Boolean = false,
    tone: CropTone = CropTone.NORMAL,
    size: Dp = 46.dp,
) {
    val bg = when (tone) {
        CropTone.OK -> IconGreen
        CropTone.CANCEL -> IconRed
        CropTone.NORMAL -> if (selected) Palette.Accent.copy(alpha = 0.38f) else IconBg
    }
    val border = when (tone) {
        CropTone.NORMAL -> if (selected) Palette.Accent else Palette.Stroke
        else -> Color(0x66FFFFFF)
    }
    val fg = if (tone != CropTone.NORMAL || selected) Color.White else Color(0xFFD8D4E4)
    Box(
        modifier
            .size(size)
            .alpha(if (enabled) 1f else 0.38f)
            .clip(CircleShape)
            .background(bg)
            .border(if (selected) 2.dp else 1.dp, border, CircleShape)
            .clickable(enabled = enabled, onClick = onClick),
        contentAlignment = Alignment.Center,
    ) {
        val text = when (glyph) {
            CropGlyph.UNDO -> "↶"
            CropGlyph.REDO -> "↷"
            CropGlyph.FIT -> "⤢"
            CropGlyph.CHECK -> "✓"
            CropGlyph.CROSS -> "✕"
            else -> null
        }
        if (busy) {
            Text("…", fontSize = 24.sp, color = fg, fontWeight = FontWeight.Bold)
        } else if (text != null) {
            val big = glyph == CropGlyph.CHECK || glyph == CropGlyph.CROSS
            Text(text, fontSize = if (big) 26.sp else 22.sp, color = fg, fontWeight = if (big) FontWeight.Bold else FontWeight.Normal)
        } else {
            Canvas(Modifier.size(size * 0.56f)) { drawGlyph(glyph, fg) }
        }
    }
}

private fun DrawScope.drawGlyph(g: CropGlyph, fg: Color) {
    val w = size.width
    val h = size.height
    val sw = w * 0.085f
    val round = StrokeCap.Round
    fun badge(center: Offset, plus: Boolean, color: Color) {
        drawCircle(color, w * 0.23f, center)
        drawLine(Color.White, Offset(center.x - w * 0.12f, center.y), Offset(center.x + w * 0.12f, center.y), sw * 0.9f, round)
        if (plus) drawLine(Color.White, Offset(center.x, center.y - h * 0.12f), Offset(center.x, center.y + h * 0.12f), sw * 0.9f, round)
    }
    when (g) {
        CropGlyph.ADD_LASSO, CropGlyph.REMOVE_LASSO -> { // บ่วงเส้นประ + เครื่องหมาย ＋/－
            drawOval(
                fg, Offset(w * 0.02f, h * 0.08f), Size(w * 0.86f, h * 0.66f),
                style = Stroke(sw, cap = round, pathEffect = PathEffect.dashPathEffect(floatArrayOf(sw * 1.7f, sw * 1.5f))),
            )
            val add = g == CropGlyph.ADD_LASSO
            badge(Offset(w * 0.77f, h * 0.77f), add, if (add) IconGreen else IconRed)
        }
        CropGlyph.CURVE -> { // เส้นโค้งเบซีเยร์ + จุดยึดปลายทั้งสอง
            val p0 = Offset(w * 0.08f, h * 0.80f)
            val p1 = Offset(w * 0.30f, h * -0.05f)
            val p2 = Offset(w * 0.70f, h * 1.05f)
            val p3 = Offset(w * 0.92f, h * 0.20f)
            var prev = p0
            for (i in 1..28) {
                val t = i / 28f
                val u = 1f - t
                val x = u * u * u * p0.x + 3 * u * u * t * p1.x + 3 * u * t * t * p2.x + t * t * t * p3.x
                val y = u * u * u * p0.y + 3 * u * u * t * p1.y + 3 * u * t * t * p2.y + t * t * t * p3.y
                drawLine(fg, prev, Offset(x, y), sw, round)
                prev = Offset(x, y)
            }
            drawCircle(Palette.Accent, w * 0.10f, p0)
            drawCircle(Palette.Accent, w * 0.10f, p3)
        }
        CropGlyph.ERASER -> { // ยางลบเอียง + เส้นพื้น
            rotate(-35f, Offset(w / 2f, h / 2f)) {
                val tl = Offset(w * 0.12f, h * 0.30f)
                val body = Size(w * 0.76f, h * 0.36f)
                drawRoundRect(fg, tl, body, CornerRadius(sw * 1.3f), style = Stroke(sw))
                drawRoundRect(fg, tl, Size(body.width * 0.42f, body.height), CornerRadius(sw * 1.3f))
            }
            drawLine(fg, Offset(w * 0.14f, h * 0.92f), Offset(w * 0.90f, h * 0.92f), sw * 0.8f, round)
        }
        CropGlyph.JOY -> { // วงจอย + ก้านเอียง
            drawCircle(fg, w * 0.44f, Offset(w / 2f, h / 2f), style = Stroke(sw))
            drawLine(fg, Offset(w * 0.5f, h * 0.5f), Offset(w * 0.68f, h * 0.30f), sw * 1.3f, round)
            drawCircle(fg, w * 0.14f, Offset(w * 0.68f, h * 0.30f))
        }
        CropGlyph.ADD_IMAGE -> { // กรอบรูป ภูเขา ดวงอาทิตย์ + ＋
            drawRoundRect(fg, Offset(w * 0.02f, h * 0.10f), Size(w * 0.84f, h * 0.72f), CornerRadius(sw * 1.6f), style = Stroke(sw))
            drawCircle(fg, w * 0.09f, Offset(w * 0.27f, h * 0.33f))
            drawLine(fg, Offset(w * 0.10f, h * 0.74f), Offset(w * 0.36f, h * 0.48f), sw, round)
            drawLine(fg, Offset(w * 0.36f, h * 0.48f), Offset(w * 0.50f, h * 0.62f), sw, round)
            drawLine(fg, Offset(w * 0.50f, h * 0.62f), Offset(w * 0.60f, h * 0.52f), sw, round)
            drawLine(fg, Offset(w * 0.60f, h * 0.52f), Offset(w * 0.78f, h * 0.74f), sw, round)
            badge(Offset(w * 0.77f, h * 0.77f), true, IconGreen)
        }
        CropGlyph.MOVE -> { // ลูกศรสี่ทิศ = ขยับ/ย้ายตำแหน่ง
            val c = Offset(w / 2f, h / 2f)
            val r = w * 0.46f
            val a = w * 0.15f
            for ((dx, dy) in listOf(0f to -1f, 1f to 0f, 0f to 1f, -1f to 0f)) {
                val tip = Offset(c.x + dx * r, c.y + dy * r)
                drawLine(fg, c, tip, sw, round)
                val px = -dy
                val py = dx
                drawLine(fg, tip, Offset(tip.x - dx * a + px * a, tip.y - dy * a + py * a), sw, round)
                drawLine(fg, tip, Offset(tip.x - dx * a - px * a, tip.y - dy * a - py * a), sw, round)
            }
        }
        CropGlyph.EDIT -> { // ดินสอ
            drawLine(fg, Offset(w * 0.30f, h * 0.70f), Offset(w * 0.74f, h * 0.26f), sw * 2.4f, round)
            drawLine(fg, Offset(w * 0.12f, h * 0.88f), Offset(w * 0.24f, h * 0.76f), sw * 1.2f, round)
            drawLine(fg, Offset(w * 0.46f, h * 0.92f), Offset(w * 0.92f, h * 0.92f), sw * 0.8f, round)
        }
        CropGlyph.SCALE -> { // ลูกศรสองหัวทแยง = ขยาย
            val a = Offset(w * 0.16f, h * 0.84f)
            val b = Offset(w * 0.84f, h * 0.16f)
            drawLine(fg, a, b, sw, round)
            arrowHead(b, 0.707f, -0.707f, w * 0.26f, fg, sw)
            arrowHead(a, -0.707f, 0.707f, w * 0.26f, fg, sw)
        }
        CropGlyph.ROTATE -> { // ลูกศรวนรอบ = หมุน
            val r = w * 0.36f
            val c = Offset(w / 2f, h / 2f)
            drawArc(fg, -60f, 270f, false, Offset(c.x - r, c.y - r), Size(r * 2, r * 2), style = Stroke(sw, cap = round))
            val tip = Offset(c.x - r * 0.866f, c.y - r * 0.5f)
            arrowHead(tip, 0.5f, -0.866f, w * 0.24f, fg, sw)
        }
        CropGlyph.FIT_BONE, CropGlyph.CANCEL_FIT -> { // กรอบภาพเส้นประ + เส้นกระดูกมีจุดหัว-ท้าย (ยกเลิก = กากบาทแดง)
            drawRoundRect(
                fg, Offset(w * 0.02f, h * 0.18f), Size(w * 0.96f, h * 0.64f), CornerRadius(sw * 1.4f),
                style = Stroke(sw * 0.8f, pathEffect = PathEffect.dashPathEffect(floatArrayOf(sw * 1.6f, sw * 1.3f))),
            )
            drawLine(fg, Offset(w * 0.2f, h * 0.5f), Offset(w * 0.8f, h * 0.5f), sw, round)
            drawCircle(IconGreen, w * 0.1f, Offset(w * 0.2f, h * 0.5f))
            drawCircle(IconRed, w * 0.1f, Offset(w * 0.8f, h * 0.5f))
            if (g == CropGlyph.CANCEL_FIT) {
                drawLine(IconRed, Offset(w * 0.68f, h * 0.68f), Offset(w * 0.96f, h * 0.96f), sw * 1.2f, round)
                drawLine(IconRed, Offset(w * 0.96f, h * 0.68f), Offset(w * 0.68f, h * 0.96f), sw * 1.2f, round)
            }
        }
        CropGlyph.FLIP_H, CropGlyph.FLIP_V -> { // สามเหลี่ยมสองข้างเส้นแกน = พลิก (แนวตั้ง = หมุนภาพ 90°)
            val body: DrawScope.() -> Unit = {
                drawLine(fg, Offset(w * 0.5f, h * 0.08f), Offset(w * 0.5f, h * 0.92f), sw * 0.8f, round)
                val left = Path().apply {
                    moveTo(w * 0.40f, h * 0.24f); lineTo(w * 0.40f, h * 0.78f); lineTo(w * 0.08f, h * 0.78f); close()
                }
                drawPath(left, fg, style = Stroke(sw, cap = round))
                val right = Path().apply {
                    moveTo(w * 0.60f, h * 0.24f); lineTo(w * 0.60f, h * 0.78f); lineTo(w * 0.92f, h * 0.78f); close()
                }
                drawPath(right, fg)
            }
            if (g == CropGlyph.FLIP_V) rotate(90f, Offset(w / 2f, h / 2f)) { body() } else body()
        }
        CropGlyph.TRASH -> { // ถังขยะ
            drawLine(fg, Offset(w * 0.14f, h * 0.26f), Offset(w * 0.86f, h * 0.26f), sw, round)
            drawLine(fg, Offset(w * 0.38f, h * 0.26f), Offset(w * 0.38f, h * 0.12f), sw, round)
            drawLine(fg, Offset(w * 0.38f, h * 0.12f), Offset(w * 0.62f, h * 0.12f), sw, round)
            drawLine(fg, Offset(w * 0.62f, h * 0.12f), Offset(w * 0.62f, h * 0.26f), sw, round)
            drawLine(fg, Offset(w * 0.24f, h * 0.34f), Offset(w * 0.30f, h * 0.90f), sw, round)
            drawLine(fg, Offset(w * 0.30f, h * 0.90f), Offset(w * 0.70f, h * 0.90f), sw, round)
            drawLine(fg, Offset(w * 0.70f, h * 0.90f), Offset(w * 0.76f, h * 0.34f), sw, round)
            drawLine(fg, Offset(w * 0.42f, h * 0.44f), Offset(w * 0.42f, h * 0.78f), sw * 0.8f, round)
            drawLine(fg, Offset(w * 0.58f, h * 0.44f), Offset(w * 0.58f, h * 0.78f), sw * 0.8f, round)
        }
        CropGlyph.SIZE -> { // วงกลมมีเส้นผ่านศูนย์กลางพร้อมขีดปลาย = ขนาดยางลบ
            drawCircle(fg, w * 0.40f, Offset(w / 2f, h / 2f), style = Stroke(sw, cap = round))
            drawLine(fg, Offset(w * 0.10f, h * 0.5f), Offset(w * 0.90f, h * 0.5f), sw * 0.9f, round)
            drawLine(fg, Offset(w * 0.10f, h * 0.38f), Offset(w * 0.10f, h * 0.62f), sw * 0.9f, round)
            drawLine(fg, Offset(w * 0.90f, h * 0.38f), Offset(w * 0.90f, h * 0.62f), sw * 0.9f, round)
        }
        CropGlyph.ERASE_IN -> { // บ่วงประ + พื้นที่ข้างในถูกลบ (ระบายจาง)
            drawCircle(fg.copy(alpha = 0.35f), w * 0.34f, Offset(w / 2f, h / 2f))
            drawCircle(
                fg, w * 0.40f, Offset(w / 2f, h / 2f),
                style = Stroke(sw, pathEffect = PathEffect.dashPathEffect(floatArrayOf(sw * 1.6f, sw * 1.3f))),
            )
        }
        CropGlyph.ERASE_ALONG -> { // แถบหนาตามแนวบ่วง
            drawCircle(fg.copy(alpha = 0.35f), w * 0.34f, Offset(w / 2f, h / 2f), style = Stroke(sw * 3.2f))
            drawCircle(
                fg, w * 0.34f, Offset(w / 2f, h / 2f),
                style = Stroke(sw * 0.8f, pathEffect = PathEffect.dashPathEffect(floatArrayOf(sw * 1.4f, sw * 1.2f))),
            )
        }
        CropGlyph.INSTANT -> { // สายฟ้า = ลบทันที
            val bolt = Path().apply {
                moveTo(w * 0.58f, h * 0.06f); lineTo(w * 0.22f, h * 0.56f); lineTo(w * 0.48f, h * 0.56f)
                lineTo(w * 0.40f, h * 0.94f); lineTo(w * 0.80f, h * 0.40f); lineTo(w * 0.54f, h * 0.40f); close()
            }
            drawPath(bolt, fg)
        }
        CropGlyph.LINE, CropGlyph.OPEN_LINE -> { // เส้นโค้งมีโหนดปลายสองจุด (เส้นเปิด)
            val c = Path().apply {
                moveTo(w * 0.12f, h * 0.76f); cubicTo(w * 0.30f, h * 0.10f, w * 0.60f, h * 0.95f, w * 0.88f, h * 0.24f)
            }
            drawPath(c, fg, style = Stroke(sw, cap = round))
            drawCircle(fg, w * 0.09f, Offset(w * 0.12f, h * 0.76f))
            drawCircle(fg, w * 0.09f, Offset(w * 0.88f, h * 0.24f))
        }
        CropGlyph.CLOSED_LINE -> { // บ่วงปิด
            drawOval(fg, Offset(w * 0.12f, h * 0.22f), Size(w * 0.76f, h * 0.56f), style = Stroke(sw))
            drawCircle(fg, w * 0.09f, Offset(w * 0.12f, h * 0.5f))
            drawCircle(fg, w * 0.09f, Offset(w * 0.88f, h * 0.5f))
        }
        CropGlyph.PLUS -> {
            drawLine(fg, Offset(w * 0.15f, h * 0.5f), Offset(w * 0.85f, h * 0.5f), sw * 1.4f, round)
            drawLine(fg, Offset(w * 0.5f, h * 0.15f), Offset(w * 0.5f, h * 0.85f), sw * 1.4f, round)
        }
        CropGlyph.MINUS -> drawLine(fg, Offset(w * 0.15f, h * 0.5f), Offset(w * 0.85f, h * 0.5f), sw * 1.4f, round)
        else -> {}
    }
}

/** หัวลูกศรที่ปลาย tip ชี้ไปทาง (dx,dy) ซึ่งเป็นเวกเตอร์หน่วย */
private fun DrawScope.arrowHead(tip: Offset, dx: Float, dy: Float, len: Float, color: Color, sw: Float) {
    val px = -dy
    val py = dx
    val bx = tip.x - dx * len
    val by = tip.y - dy * len
    drawLine(color, tip, Offset(bx + px * len * 0.7f, by + py * len * 0.7f), sw, StrokeCap.Round)
    drawLine(color, tip, Offset(bx - px * len * 0.7f, by - py * len * 0.7f), sw, StrokeCap.Round)
}
