package com.nop.cartoonstudio

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Typeface
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.gestures.calculateCentroid
import androidx.compose.foundation.gestures.calculatePan
import androidx.compose.foundation.gestures.calculateZoom
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectDragGesturesAfterLongPress
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.snapshots.SnapshotStateList
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawWithContent
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.input.pointer.PointerEventPass
import androidx.compose.ui.input.pointer.positionChanged
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.zIndex
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.roundToInt

object ImageStudioPrefs {
    private const val FILE = "image_studio_settings"
    private const val ENABLED = "enabled"
    private const val ASK = "ask_before_start"
    fun enabled(context: Context) = context.getSharedPreferences(FILE, Context.MODE_PRIVATE).getBoolean(ENABLED, true)
    fun setEnabled(context: Context, value: Boolean) { context.getSharedPreferences(FILE, Context.MODE_PRIVATE).edit().putBoolean(ENABLED, value).apply() }
    fun ask(context: Context) = context.getSharedPreferences(FILE, Context.MODE_PRIVATE).getBoolean(ASK, true)
    fun setAsk(context: Context, value: Boolean) { context.getSharedPreferences(FILE, Context.MODE_PRIVATE).edit().putBoolean(ASK, value).apply() }
}

// ───────────────────────── ค่าคงที่และสี ─────────────────────────

/** ความยาว Timeline สูงสุด = 100 วินาที (ตรงกับขีดจำกัด 3000 เฟรมของการส่งออก MP4 ที่ 30 fps) */
private const val MAX_TIMELINE_SEC = 1_000_000f // ไม่จำกัดตามจริง (ค่ากันตัวเลขล้นเท่านั้น ≈ 11 วัน)
private const val MAX_TIMELINE_PX = 150_000f // ความกว้าง Timeline สูงสุดที่ Compose วาดได้อย่างปลอดภัย (เกินนี้แอปล้ม): ยาวกว่านี้ระบบลดซูมให้เอง
private const val MIN_CLIP_SEC = 0.5f
private const val OUT_SIZE = 720
private const val OVERLAY_ID = 900001

/** เครื่องมือในโหมดบิดภาพ: ดึงด้วยพู่กัน · Mesh Warp (ลากจุดตาข่ายทีละจุด) · Twist (บิดวนรอบจุด) · PIN (หมุดข้อต่ออัจฉริยะ: งอข้อต่อด้วยมุม ตาข่ายถี่ตามจุด) */
private enum class SculptTool { GRAB, MESH, TWIST, PIN, POINT, PINCH, BULGE, SPIRAL, WAVE, SHEAR, PERSPECTIVE, RIPPLE, PUSH, INFLATE, DEFLATE, SMOOTH, FLATTEN, CREASE, GRAVITY, ELASTIC, MAGNET, MASK, ARC_BEND, TAPER, RIGID_TRANSFORM, RIBBON_BEND, EDGE_SLIDE, CONTOUR_FLOW, FAN_DEFORM, ORIGAMI_FOLD, TOPOLOGY_REMAP, BOUNDARY_TENSION, VISCOUS_MELT, SEGMENT_OFFSET, ASYMMETRIC_WARP, DIRECTIONAL_COMPRESS, SURFACE_ROLL }

/** โหมดบิดขั้นสูงที่ตรงกับเครื่องมือที่เลือก (ใช้ให้ตัวอย่างในคลังค่าตรงกับเครื่องมือ); เครื่องมืออื่นคืน null */
private fun sculptToolDemoMode(tool: SculptTool): AdvancedWarpMode? = when (tool) {
    SculptTool.PINCH -> AdvancedWarpMode.PINCH
    SculptTool.BULGE -> AdvancedWarpMode.BULGE
    SculptTool.SPIRAL -> AdvancedWarpMode.SPIRAL
    SculptTool.WAVE -> AdvancedWarpMode.WAVE
    SculptTool.SHEAR -> AdvancedWarpMode.SHEAR
    SculptTool.PERSPECTIVE -> AdvancedWarpMode.PERSPECTIVE
    SculptTool.RIPPLE -> AdvancedWarpMode.RIPPLE
    SculptTool.PUSH -> AdvancedWarpMode.PUSH
    SculptTool.INFLATE -> AdvancedWarpMode.INFLATE
    SculptTool.DEFLATE -> AdvancedWarpMode.DEFLATE
    SculptTool.SMOOTH -> AdvancedWarpMode.SMOOTH
    SculptTool.FLATTEN -> AdvancedWarpMode.FLATTEN
    SculptTool.CREASE -> AdvancedWarpMode.CREASE
    SculptTool.GRAVITY -> AdvancedWarpMode.GRAVITY
    SculptTool.ELASTIC -> AdvancedWarpMode.ELASTIC
    SculptTool.MAGNET -> AdvancedWarpMode.MAGNET
    SculptTool.ARC_BEND -> AdvancedWarpMode.ARC_BEND
    SculptTool.TAPER -> AdvancedWarpMode.TAPER
    SculptTool.RIGID_TRANSFORM -> AdvancedWarpMode.RIGID_TRANSFORM
    SculptTool.RIBBON_BEND -> AdvancedWarpMode.RIBBON_BEND
    SculptTool.EDGE_SLIDE -> AdvancedWarpMode.EDGE_SLIDE
    SculptTool.CONTOUR_FLOW -> AdvancedWarpMode.CONTOUR_FLOW
    SculptTool.FAN_DEFORM -> AdvancedWarpMode.FAN_DEFORM
    SculptTool.ORIGAMI_FOLD -> AdvancedWarpMode.ORIGAMI_FOLD
    SculptTool.TOPOLOGY_REMAP -> AdvancedWarpMode.TOPOLOGY_REMAP
    SculptTool.BOUNDARY_TENSION -> AdvancedWarpMode.BOUNDARY_TENSION
    SculptTool.VISCOUS_MELT -> AdvancedWarpMode.VISCOUS_MELT
    SculptTool.SEGMENT_OFFSET -> AdvancedWarpMode.SEGMENT_OFFSET
    SculptTool.ASYMMETRIC_WARP -> AdvancedWarpMode.ASYMMETRIC_WARP
    SculptTool.DIRECTIONAL_COMPRESS -> AdvancedWarpMode.DIRECTIONAL_COMPRESS
    SculptTool.SURFACE_ROLL -> AdvancedWarpMode.SURFACE_ROLL
    SculptTool.GRAB, SculptTool.MESH, SculptTool.TWIST, SculptTool.PIN, SculptTool.POINT, SculptTool.MASK -> null
}

/** ค่าเริ่มต้นแนะนำของพู่กันใหม่แต่ละชนิด ใช้ WarpSettings เดิมเพื่อให้บันทึก/โหลดด้วยระบบโปรเจกต์เดิม */
private fun recommendedWarpSettings(tool: SculptTool, base: WarpSettings): WarpSettings = when (tool) {
    SculptTool.ARC_BEND -> base.copy(strength = 75f, angleDeg = 25f, scaleX = 180f, scaleY = 70f, falloff = 80f, maxDeformation = 65f)
    SculptTool.TAPER -> base.copy(strength = 90f, angleDeg = 0f, frequency = 2f, scaleX = 140f, scaleY = 65f, falloff = 75f)
    SculptTool.RIGID_TRANSFORM -> base.copy(strength = 65f, angleDeg = 30f, scaleX = 110f, scaleY = 110f, falloff = 100f, maxDeformation = 100f)
    SculptTool.RIBBON_BEND -> base.copy(strength = 80f, angleDeg = 0f, scaleX = 250f, scaleY = 35f, frequency = 1f, wavelengthPx = 180f, phaseDeg = 0f)
    SculptTool.EDGE_SLIDE -> base.copy(strength = 50f, angleDeg = 90f, edgeProtection = 60f, hardness = 20f, falloff = 80f)
    SculptTool.CONTOUR_FLOW -> base.copy(strength = 60f, angleDeg = 0f, frequency = 2f, wavelengthPx = 120f, phaseDeg = 90f)
    SculptTool.FAN_DEFORM -> base.copy(strength = 75f, angleDeg = 0f, frequency = 5f, phaseDeg = 0f, scaleX = 100f, scaleY = 100f)
    SculptTool.ORIGAMI_FOLD -> base.copy(strength = 65f, angleDeg = 45f, hardness = 65f, falloff = 80f, maxDeformation = 80f)
    SculptTool.TOPOLOGY_REMAP -> base.copy(strength = 45f, frequency = 3f, wavelengthPx = 70f, phaseDeg = 30f, meshSmoothing = 15f)
    SculptTool.BOUNDARY_TENSION -> base.copy(strength = 60f, edgeProtection = 80f, hardness = 30f, smoothness = 70f, maxDeformation = 45f)
    SculptTool.VISCOUS_MELT -> base.copy(strength = 80f, angleDeg = 90f, falloff = 70f, flow = 60f, wavelengthPx = 100f)
    SculptTool.SEGMENT_OFFSET -> base.copy(strength = 80f, angleDeg = 0f, wavelengthPx = 24f, frequency = 6f, phaseDeg = 0f)
    SculptTool.ASYMMETRIC_WARP -> base.copy(strength = 65f, angleDeg = 0f, scaleX = 160f, scaleY = 80f, phaseDeg = 90f, falloff = 75f)
    SculptTool.DIRECTIONAL_COMPRESS -> base.copy(strength = 70f, angleDeg = 0f, scaleX = 100f, scaleY = 100f, smoothness = 70f)
    SculptTool.SURFACE_ROLL -> base.copy(strength = 70f, angleDeg = 0f, wavelengthPx = 120f, frequency = 1f, falloff = 60f)
    else -> base
}

/** ย้อนกลับ/ทำซ้ำได้สูงสุดกี่ครั้ง (การบิดภาพ / หมุดข้อต่อ / Keyframe / จบการบิด) */
private const val UNDO_MAX = 100

/** ภาพถ่ายสถานะของคลิปก่อนแก้ ใช้ย้อนกลับ (เก็บเฉพาะข้อมูลที่แชร์วัตถุกันได้ ไม่กิน RAM มาก) */
private class UndoEntry(
    val clipId: Int, val sculpt: SculptGrid?, val keyframes: List<StudioKeyframe>, val rig: PinRig,
    val file: File? = null, val bitmap: Bitmap? = null, // != null = ก้าวนี้คือการฝังท่าลงภาพ: คืนภาพเดิมด้วย
    val warpLayers: List<WarpLayer> = emptyList(), val physics: WarpPhysicsSettings = WarpPhysicsSettings(),
)

/** ตัวช่วยรวมการแก้ต่อเนื่อง (เช่นพิมพ์/เลื่อนแถบมุม) ให้เป็นก้าวย้อนกลับเดียว */
private class UndoMeta { var key: String = ""; var at: Long = 0L }

/**
 * เซสชันบิดภาพของคลิปหนึ่ง: ทุกครั้งที่กด "บิดภาพ" เริ่มตารางใหม่ (lat = ตารางเว้นระยะเท่ากัน ออฟเซ็ตศูนย์) วางทับท่าที่เห็นอยู่ (e0)
 * ท่าเดิมที่บิดไว้ถือว่าจบแล้ว (อยู่ในท่าของคลิป) การบิดครั้งใหม่ดึงตารางใหม่ แล้วส่งผลไปยังท่าผ่าน Sculpt.compose + JointPins.unbend
 * written = ท่าที่เซสชันเขียนลงคลิปล่าสุด: ถ้าท่าของคลิปเปลี่ยนไปจากนี้ (เลื่อนเส้นแดง/ย้อนกลับ/งอหมุด ฯลฯ) เซสชันเก่าใช้ไม่ได้ → เริ่มตารางใหม่
 */
private class SculptSession(
    val clipId: Int, val base: SculptGrid?, val e0: SculptGrid, val angles: FloatArray?,
    val lat: SculptGrid, val written: SculptGrid?,
)

/** ห่วงบิดที่ผู้ใช้วางเอง: สามค่าต่อห่วง = [x, y, รัศมี] เรียงต่อกัน (พิกัด bitmap ตามที่เห็น) · ไม่จำกัดจำนวน */
private class PointSet(val clipId: Int, val xy: FloatArray)

private fun validSession(s: SculptSession?, clip: StudioImage, pose: StudioKeyframe): SculptSession? =
    if (s != null && s.clipId == clip.id && Sculpt.approxEquals(s.written, pose.sculpt)) s else null

private object StudioColors {
    val Bg = Color(0xFF0B0E13)
    val Panel = Color(0xFF151A22)
    val Panel2 = Color(0xFF1E2530)
    val Line = Color(0xFF2B3442)
    val Ink = Color(0xFFEAF0F8)
    val Sub = Color(0xFF8E9BB0)
    val Accent = Color(0xFF5CC8FF)
    val AccentDim = Color(0xFF1D3A52)
    val Ok = Color(0xFF5AD6A0)
    val Warn = Color(0xFFFFB86B)
    val Danger = Color(0xFFFF6B7A)
    val PlayRed = Color(0xFFFF5C7A)
    val LaneBg = Color(0xFF10151C)
    val LaneActive = Color(0xFF14202C)
    val LaneTints = listOf(
        Color(0xFF5CC8FF), Color(0xFF9D8CFF), Color(0xFF5AD6A0), Color(0xFFFFB86B),
        Color(0xFFFF7FA8), Color(0xFFB5E86B),
    )
}

private fun laneTint(laneId: Int): Color = StudioColors.LaneTints[abs(laneId - 1) % StudioColors.LaneTints.size]

// ───────────────────────── โมเดลข้อมูลในหน้าแก้ไข ─────────────────────────

private data class StudioKeyframe(
    val time: Float, val x: Float, val y: Float, val scale: Float, val rotation: Float, val opacity: Float,
    val sculpt: SculptGrid? = null, // ท่าบิดภาพ (ตาข่าย) ณ จุดนี้ null = ไม่บิด
)

/**
 * คลิปภาพหนึ่งคลิปบน Timeline
 * x, y = ตำแหน่งในหน่วย "โลก" (ด้านสั้นของเฟรม = 600 หน่วย) ใช้หน่วยเดียวกับตัวส่งออกวิดีโอ จึงเห็นอย่างไรก็ได้อย่างนั้น
 * layerId = แทร็ก (เลขมาก = อยู่บนสุด)
 */
private data class StudioImage(
    val id: Int, val file: File, val bitmap: Bitmap, val duration: Float = 3f,
    val x: Float = 0f, val y: Float = 0f, val scale: Float = 1f,
    val rotation: Float = 0f, val opacity: Float = 1f, val visible: Boolean = true,
    val startTime: Float = 0f, val keyframes: List<StudioKeyframe> = emptyList(),
    val name: String = "", val locked: Boolean = false, val layerId: Int = 1,
    val sculpt: SculptGrid? = null, // ท่าบิดภาพของคลิปที่ไม่มี Keyframe (ใช้ตลอดคลิป)
    val sizeLocked: Boolean = false, // ล็อกขนาด: ย่อ/ขยายด้วยสองนิ้วไม่ได้ (เลื่อน/หมุนยังได้)
    val videoLength: Float = 0f, // > 0 = คลิปวิดีโอ: ความยาวไฟล์ต้นฉบับ (วินาที) · bitmap = ภาพปก (ขนาดเดียวกับทุกเฟรม)
    val videoOffset: Float = 0f, // จุดเริ่มเล่นในไฟล์วิดีโอ (วินาที) เปลี่ยนเมื่อตัดหัว/แบ่งคลิป
    val rig: PinRig = PinRig(), // หมุดข้อต่ออัจฉริยะของคลิป (มุมงอของแต่ละหมุดเก็บในท่าบิด sculpt ของแต่ละ Keyframe)
    val warpLayers: List<WarpLayer> = emptyList(),
    val physics: WarpPhysicsSettings = WarpPhysicsSettings(),
)

/** ภาพที่เลือกมาแล้วแต่ยังรอผ่านหน้าตัดภาพ (ตัดพื้นหลังให้โปร่งใส) ก่อนเข้าโปรเจกต์ */
private class PendingImport(val uri: android.net.Uri, val name: String, val bitmap: Bitmap)

private fun clipEnd(c: StudioImage) = c.startTime + c.duration
private fun isVideoClip(c: StudioImage) = c.videoLength > 0f
/** เวลาในไฟล์วิดีโอ (วินาที) ของคลิปวิดีโอ ณ เวลาบนไทม์ไลน์ t (ค้างเฟรมสุดท้ายถ้าเกินความยาวไฟล์) */
private fun videoLocalTime(c: StudioImage, t: Float) = (c.videoOffset + (t - c.startTime)).coerceIn(0f, maxOf(0f, c.videoLength - 0.05f))
private fun isActiveAt(c: StudioImage, t: Float) = c.visible && t >= c.startTime && t < c.startTime + c.duration
private fun clipLabel(c: StudioImage) = c.name.ifBlank { (if (isVideoClip(c)) "วิดีโอ " else "ภาพ ") + c.id }

/**
 * จำนวนช่องตาข่ายของคลิป: ถ้าคลิป/Keyframe ไหนมีท่าบิดอยู่แล้วใช้ขนาดเดียวกัน (ท่าที่ขนาดตารางต่างกันจะกระโดดแทนที่จะค่อย ๆ เปลี่ยน)
 * ถ้ายังไม่เคยบิด = ตามขนาดช่อง cell ที่ตั้ง (null = อัตโนมัติ ค่าเดิมของแอป)
 */
private fun clipGridDims(c: StudioImage, cell: Float?, meshCols: Int = 0, meshRows: Int = 0): Pair<Int, Int> {
    val g = c.sculpt ?: c.keyframes.firstNotNullOfOrNull { it.sculpt } ?: c.warpLayers.firstOrNull()?.grid
    return if (g != null) Pair(g.cols, g.rows) else Sculpt.gridDims(c.bitmap.width, c.bitmap.height, cell, meshCols, meshRows)
}

/** ตาข่ายที่ใช้วาดและส่งออกจริง: ท่าบิดของคลิป + การงอตามมุมของหมุดข้อต่อ (ไม่มีหมุด = ท่าเดิม) ใช้เหมือนกันทั้งหน้าจอและตอนส่งออก */
private fun renderGrid(c: StudioImage, g: SculptGrid?, localTime: Float = 0f): SculptGrid? {
    val stacked = WarpStackMath.composite(g, c.warpLayers)
    val simulated = stacked?.let { WarpStackMath.physicsAt(it, c.physics, localTime) }
    return JointPins.effective(c.rig, c.bitmap.width, c.bitmap.height, simulated)
}

/** ท่านี้มีหมุดข้อต่อที่งออยู่ไหม (งออยู่ = ตำแหน่งที่เห็นไม่ตรงกับตาข่ายตั้งต้น ปั้นด้วยมือ/วางหมุดใหม่ตอนนั้นไม่ได้) */
private fun hasPinAngle(g: SculptGrid?): Boolean = g?.pinAngles?.any { it != 0f } == true

/** ลำดับการซ้อน: แทร็กสูงอยู่บน; แทร็กเดียวกันคลิปที่เริ่มทีหลังอยู่บน (ใช้เหมือนกันทั้งหน้าจอและตอนส่งออก) */
private fun stackOrder(list: List<StudioImage>): List<StudioImage> =
    list.sortedWith(compareBy<StudioImage>({ it.layerId }, { it.startTime }))

private fun f1(v: Float): String = String.format(java.util.Locale.US, "%.1f", v)

private fun fmtClock(t: Float): String {
    val tenths = (t.coerceAtLeast(0f) * 10f).roundToInt()
    return String.format(java.util.Locale.US, "%d:%02d.%d", tenths / 600, (tenths / 10) % 60, tenths % 10)
}

private fun safeCoerce(v: Float, lo: Float, hi: Float): Float = if (hi < lo) lo else v.coerceIn(lo, hi)

/** ขนาด "พอดีเฟรม" ของภาพ (หน่วยโลกต่อพิกเซลของภาพ) ใช้เหมือนกันทั้ง Canvas และตอนส่งออก */
private fun fitScale(bw: Int, bh: Int): Float =
    minOf(Exporter.WORLD_WINDOW / bw.coerceAtLeast(1), Exporter.WORLD_WINDOW / bh.coerceAtLeast(1))

private fun laneIsFree(images: List<StudioImage>, laneId: Int, start: Float, dur: Float, ignoreId: Int): Boolean =
    images.none { it.id != ignoreId && it.layerId == laneId && start < clipEnd(it) - 0.001f && start + dur > it.startTime + 0.001f }

private fun studioPoseAt(
    image: StudioImage, absoluteTime: Float,
    interpolation: String = "Linear", followWarpMotion: Boolean = true, warpMotionStrength: Float = 100f,
): StudioKeyframe {
    val local = (absoluteTime - image.startTime).coerceIn(0f, image.duration)
    val points = image.keyframes.sortedBy { it.time }
    if (points.isEmpty()) return StudioKeyframe(local, image.x, image.y, image.scale, image.rotation, image.opacity, image.sculpt)
    if (local <= points.first().time) return points.first()
    if (local >= points.last().time) return points.last()
    val rightIndex = points.indexOfFirst { it.time >= local }
    val a = points[rightIndex - 1]; val b = points[rightIndex]
    val span = (b.time - a.time).coerceAtLeast(0.0001f)
    val raw = ((local - a.time) / span).coerceIn(0f, 1f)
    val f = when (interpolation) {
        "Smooth" -> raw * raw * (3f - 2f * raw)
        "Ease In" -> raw * raw
        "Ease Out" -> 1f - (1f - raw) * (1f - raw)
        "Bezier" -> {
            var t = raw
            repeat(6) {
                val omt = 1f - t
                val x = 3f * omt * omt * t * 0.25f + 3f * omt * t * t * 0.25f + t * t * t
                val dx = 3f * omt * omt * 0.25f + 6f * omt * t * (0.25f - 0.25f) + 3f * t * t * 0.75f
                if (dx > 0.0001f) t = (t - (x - raw) / dx).coerceIn(0f, 1f)
            }
            val omt = 1f - t
            3f * omt * omt * t * 0.1f + 3f * omt * t * t + t * t * t
        }
        else -> raw
    }
    fun mix(x: Float, y: Float) = x + (y - x) * f
    val warpF = if (followWarpMotion) f * (warpMotionStrength / 100f).coerceIn(0f, 1f) else 0f
    return StudioKeyframe(local, mix(a.x, b.x), mix(a.y, b.y), mix(a.scale, b.scale), mix(a.rotation, b.rotation), mix(a.opacity, b.opacity), Sculpt.lerp(a.sculpt, b.sculpt, warpF))
}

/** แตะที่พิกัดโลก (wx, wy) โดนภาพนี้ไหม (คิดตามตำแหน่ง/ขนาด/มุมหมุน ณ เวลาปัจจุบัน) */
private fun hitsClip(c: StudioImage, pose: StudioKeyframe, wx: Float, wy: Float): Boolean {
    val fit = fitScale(c.bitmap.width, c.bitmap.height)
    val hw = c.bitmap.width * fit / 2f
    val hh = c.bitmap.height * fit / 2f
    val rad = Math.toRadians(pose.rotation.toDouble())
    val cs = kotlin.math.cos(rad).toFloat()
    val sn = kotlin.math.sin(rad).toFloat()
    val qx = wx - pose.x
    val qy = wy - pose.y
    val sc = pose.scale.coerceAtLeast(0.05f)
    val ux = (qx * cs + qy * sn) / sc
    val uy = (-qx * sn + qy * cs) / sc
    return abs(ux) <= hw && abs(uy) <= hh
}

/** พิกัดโลก (wx, wy) -> พิกัดพิกเซลของ bitmap ของคลิป (ตามตำแหน่ง/ขนาด/มุมหมุน ณ ท่านี้) ใช้กับพู่กันบิดภาพ */
private fun worldToBitmap(c: StudioImage, pose: StudioKeyframe, wx: Float, wy: Float): Pair<Float, Float> {
    val fit = fitScale(c.bitmap.width, c.bitmap.height)
    val rad = Math.toRadians(pose.rotation.toDouble())
    val cs = kotlin.math.cos(rad).toFloat()
    val sn = kotlin.math.sin(rad).toFloat()
    val qx = wx - pose.x
    val qy = wy - pose.y
    val sc = pose.scale.coerceAtLeast(0.05f)
    val ux = (qx * cs + qy * sn) / sc
    val uy = (-qx * sn + qy * cs) / sc
    return Pair(ux / fit + c.bitmap.width / 2f, uy / fit + c.bitmap.height / 2f)
}

private fun presetKeyframes(duration: Float, preset: String): List<StudioKeyframe> {
    val pan = preset != "หมุนเบาๆ"
    val rot = preset != "เลื่อนภาพ"
    return listOf(
        StudioKeyframe(0f, if (pan) -40f else 0f, 0f, 1.08f, if (rot) -3f else 0f, 1f),
        StudioKeyframe(duration, if (pan) 40f else 0f, 0f, 1.08f, if (rot) 3f else 0f, 1f),
    )
}

// ───────────────────────── หน้ารายการโปรเจกต์ ─────────────────────────

@Composable
fun ImageStudioScreen(onBack: () -> Unit) {
    val context = LocalContext.current
    val projects = remember { mutableStateListOf<ImageStudioProject>() }
    var activeProjectId by remember { mutableStateOf<String?>(null) }
    var showCreate by remember { mutableStateOf(false) }
    var newName by remember { mutableStateOf("โปรเจกต์รูปภาพ") }
    var message by remember { mutableStateOf<String?>(null) }

    fun refreshProjects() {
        projects.clear()
        projects.addAll(ImageStudioProjectStore.list(context))
    }
    LaunchedEffect(Unit) { refreshProjects() }

    val activeId = activeProjectId
    if (activeId != null) {
        ImageStudioEditorScreen(projectId = activeId, onBack = { activeProjectId = null; refreshProjects() })
        return
    }

    val c = StudioColors
    Column(Modifier.fillMaxSize().background(c.Bg).systemBarsPadding().padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            ToolChip("‹ กลับ", onClick = onBack)
            Spacer(Modifier.width(10.dp))
            Text("สตูดิโอภาพ", color = c.Ink, fontSize = 20.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
        }
        Text("โปรเจกต์รูปภาพ", color = c.Ink, fontSize = 26.sp, fontWeight = FontWeight.Bold)
        Text("เปิดงานล่าสุดหรือสร้างโปรเจกต์ใหม่เพื่อเริ่มตัดต่อภาพและวิดีโอ", color = c.Sub, fontSize = 13.sp)
        Button(
            onClick = { newName = "โปรเจกต์รูปภาพ"; showCreate = true },
            modifier = Modifier.fillMaxWidth().height(50.dp),
            shape = RoundedCornerShape(14.dp),
            colors = ButtonDefaults.buttonColors(containerColor = c.Accent, contentColor = Color(0xFF06141F)),
        ) { Text("＋ สร้างโปรเจกต์ใหม่", fontWeight = FontWeight.Bold) }
        if (projects.isEmpty()) {
            Box(Modifier.weight(1f).fillMaxWidth(), contentAlignment = Alignment.Center) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text("🎞", fontSize = 44.sp)
                    Spacer(Modifier.height(8.dp))
                    Text("ยังไม่มีโปรเจกต์\nกดสร้างโปรเจกต์ใหม่เพื่อเริ่มต้น", color = c.Sub, fontSize = 14.sp)
                }
            }
        } else {
            Text("โปรเจกต์ล่าสุด", color = c.Ink, fontSize = 16.sp, fontWeight = FontWeight.SemiBold)
            LazyColumn(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                items(projects, key = { it.id }) { project ->
                    Row(
                        Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp)).background(c.Panel).padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp),
                    ) {
                        Column(Modifier.weight(1f)) {
                            Text(project.name, color = c.Ink, fontSize = 16.sp, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                            Text("${project.imageCount} ภาพ · แก้ไข ${java.text.DateFormat.getDateTimeInstance().format(java.util.Date(project.updatedAt))}", color = c.Sub, fontSize = 12.sp)
                        }
                        ToolChip("เปิด", onClick = { activeProjectId = project.id }, highlight = true)
                        ToolChip("ลบ", onClick = { ImageStudioProjectStore.delete(context, project.id); refreshProjects() }, danger = true)
                    }
                }
            }
        }
        message?.let { Text(it, color = c.Danger) }
    }
    if (showCreate) {
        AlertDialog(
            onDismissRequest = { showCreate = false },
            containerColor = c.Panel, titleContentColor = c.Ink, textContentColor = c.Ink,
            title = { Text("สร้างโปรเจกต์ใหม่") },
            text = { OutlinedTextField(value = newName, onValueChange = { newName = it }, label = { Text("ชื่อโปรเจกต์") }, singleLine = true, colors = studioFieldColors()) },
            confirmButton = { TextButton(onClick = {
                runCatching { ImageStudioProjectStore.create(context, newName) }
                    .onSuccess { project -> refreshProjects(); showCreate = false; activeProjectId = project.id }
                    .onFailure { message = "สร้างโปรเจกต์ไม่สำเร็จ: ${it.message}" }
            }) { Text("สร้าง", color = c.Accent) } },
            dismissButton = { TextButton(onClick = { showCreate = false }) { Text("ยกเลิก", color = c.Sub) } },
        )
    }
}

@Composable
private fun studioFieldColors() = OutlinedTextFieldDefaults.colors(
    focusedTextColor = StudioColors.Ink, unfocusedTextColor = StudioColors.Ink,
    focusedBorderColor = StudioColors.Accent, unfocusedBorderColor = StudioColors.Line,
    focusedLabelColor = StudioColors.Accent, unfocusedLabelColor = StudioColors.Sub,
    cursorColor = StudioColors.Accent,
)

@Composable
private fun ToolChip(
    label: String, onClick: () -> Unit, enabled: Boolean = true, highlight: Boolean = false, danger: Boolean = false,
) {
    val c = StudioColors
    val bg = when { !enabled -> c.Panel2.copy(alpha = 0.5f); highlight -> c.Accent; else -> c.Panel2 }
    val fg = when { !enabled -> c.Sub.copy(alpha = 0.5f); highlight -> Color(0xFF06141F); danger -> c.Danger; else -> c.Ink }
    val edge = when { !enabled -> c.Line.copy(alpha = 0.4f); highlight -> c.Accent; danger -> c.Danger.copy(alpha = 0.4f); else -> c.Line }
    Box(
        Modifier.heightIn(min = 36.dp).clip(RoundedCornerShape(50)).background(bg)
            .border(1.dp, edge, RoundedCornerShape(50))
            .clickable(enabled = enabled, onClick = onClick).padding(horizontal = 12.dp, vertical = 8.dp),
        contentAlignment = Alignment.Center,
    ) { Text(label, color = fg, fontSize = 13.sp, maxLines = 1, fontWeight = if (highlight) FontWeight.Bold else FontWeight.Normal) }
}

// ───────────────────────── หน้าแก้ไข ─────────────────────────

@Composable
private fun ImageStudioEditorScreen(projectId: String, onBack: () -> Unit) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val c = StudioColors
    val images = remember { mutableStateListOf<StudioImage>() }
    val layerIds = remember { mutableStateListOf<Int>() }
    var selectedId by remember { mutableIntStateOf(-1) }
    var activeLayerId by remember { mutableIntStateOf(1) }
    var playhead by remember { mutableFloatStateOf(0f) }
    var animationMode by remember { mutableStateOf(false) }
    var motionPreset by remember { mutableStateOf("เลื่อนภาพ") }
    var busy by remember { mutableStateOf(false) }
    var exportProgress by remember { mutableFloatStateOf(0f) }
    var previewPlaying by remember { mutableStateOf(false) }
    var status by remember { mutableStateOf<String?>(null) }
    var loadingProject by remember { mutableStateOf(true) }
    var projectLoaded by remember { mutableStateOf(false) }
    var timelineZoom by remember { mutableFloatStateOf(1f) }
    var showProps by remember { mutableStateOf(false) }
    var showExtras by remember { mutableStateOf(false) }
    var showClearConfirm by remember { mutableStateOf(false) }
    var sculptMode by remember { mutableStateOf(false) }
    var keyClip by remember { mutableStateOf<Pair<Int, StudioKeyframe>?>(null) } // ท่าของจุด ◆ ที่คัดลอกไว้ (คลิปเดิม + ท่า)
    val undoStack = remember { ArrayList<UndoEntry>() } // ย้อนกลับการบิดภาพ/หมุด/Keyframe สูงสุด UNDO_MAX ครั้ง
    val undoMeta = remember { UndoMeta() }
    var undoCount by remember { mutableIntStateOf(0) }
    val redoStack = remember { ArrayList<UndoEntry>() } // ก้าวที่ย้อนกลับไปแล้ว ทำซ้ำได้ (ล้างเมื่อแก้อะไรใหม่)
    var redoCount by remember { mutableIntStateOf(0) }
    val pendingImports = remember { mutableStateListOf<PendingImport>() }
    var editClipId by remember { mutableIntStateOf(-1) }
    var lastAssignedId by remember { mutableIntStateOf(0) }
    var brushFrac by remember { mutableFloatStateOf(0.25f) } // รัศมีพู่กัน = สัดส่วนของด้านยาวของภาพ
    var sculptTool by remember { mutableStateOf(SculptTool.GRAB) }
    var selectedPinId by remember { mutableIntStateOf(0) } // หมุดข้อต่อที่เลือกอยู่ (0 = ยังไม่เลือก) ใช้กับเครื่องมือ PIN
    var pinPlacing by remember { mutableStateOf(false) } // กำลังรอแตะบนภาพเพื่อวางหมุดใหม่
    var pinShowMesh by remember { mutableStateOf(true) } // แสดงเส้นตาข่าย (ใช้กับทุกเครื่องมือในโหมดบิดภาพ ชื่อตัวแปรเดิมจากตอนทำเฉพาะหมุด)
    var lensOpen by remember { mutableStateOf(false) } // แว่นขยายในโหมดบิดภาพ (เปิด/ปิดจากปุ่มในแผงบิดภาพ)
    var meshRings by remember { mutableIntStateOf(1) } // Mesh Warp: จำนวนวงจุดข้างเคียงที่ถูกดึงตาม (0 = จุดเดียว)
    var twistDeg by remember { mutableFloatStateOf(90f) } // Twist: มุมสูงสุดที่ลากไกล 1 รัศมี (องศา)
    var warpSettings by remember { mutableStateOf(WarpSettings()) } // ค่าละเอียดระบบบิดภาพทั้งหมด
    var customWarpPresets by remember { mutableStateOf<List<WarpPreset>>(emptyList()) }
    var selectedMeshPoint by remember { mutableIntStateOf(-1) }
    var lockedMeshPoints by remember { mutableStateOf<Set<Int>>(emptySet()) }
    var copiedWarpGrid by remember { mutableStateOf<SculptGrid?>(null) }
    LaunchedEffect(selectedId) { selectedMeshPoint = -1; lockedMeshPoints = emptySet() }
    var meshCell by remember { mutableStateOf<Float?>(null) } // ขนาดช่องตาข่าย (px ของ bitmap) null = อัตโนมัติ (ไม่บันทึกลงโปรเจกต์ ท่าที่บิดแล้วเก็บขนาดตารางของตัวเอง)
    var videoW by remember { mutableIntStateOf(OUT_SIZE) } // ขนาดวิดีโอที่ส่งออก (px) ตั้งที่ปุ่ม "แก้ไข" บันทึกในโปรเจกต์
    var videoH by remember { mutableIntStateOf(OUT_SIZE) }
    var showVideoSize by remember { mutableStateOf(false) }
    var videoFps by remember { mutableIntStateOf(30) } // เฟรมต่อวินาทีของ MP4 ที่ส่งออก (1–60) ตั้งที่ปุ่ม fps ข้างปุ่มส่งออก บันทึกในโปรเจกต์
    var showFpsDialog by remember { mutableStateOf(false) }
    var busyImport by remember { mutableStateOf(false) } // กำลังคัดลอกวิดีโอเข้ามา/ดึงเสียง

    var overlayText by remember { mutableStateOf("") }
    var overlaySticker by remember { mutableStateOf("") }
    var overlayStart by remember { mutableFloatStateOf(0f) }
    var overlayDuration by remember { mutableFloatStateOf(5f) }
    var audioFile by remember { mutableStateOf<File?>(null) }
    var audioStart by remember { mutableFloatStateOf(0f) }
    var audioVolume by remember { mutableFloatStateOf(1f) }

    val timelineEnd = (images.maxOfOrNull { clipEnd(it) } ?: 1f).coerceAtLeast(1f)
    val current = images.firstOrNull { it.id == selectedId }

    // ── ตัวช่วยแก้คลิป ──
    fun indexOfClip(id: Int) = images.indexOfFirst { it.id == id }
    fun selectClip(id: Int) {
        val i = indexOfClip(id)
        if (i >= 0) { selectedId = id; activeLayerId = images[i].layerId } else selectedId = -1
    }
    fun updateClip(id: Int, block: (StudioImage) -> StudioImage) {
        val i = indexOfClip(id)
        if (i >= 0) images[i] = block(images[i])
    }
    fun newTopLane(): Int {
        val id = (layerIds.maxOrNull() ?: 0) + 1
        val all = (layerIds + id).sorted()
        layerIds.clear(); layerIds.addAll(all)
        return id
    }
    fun placeNewClip(duration: Float): Triple<Int, Float, Float> {
        val lane = if (activeLayerId in layerIds) activeLayerId else (layerIds.lastOrNull() ?: 1)
        val start = images.filter { it.layerId == lane }.maxOfOrNull { clipEnd(it) } ?: 0f
        return if (start + MIN_CLIP_SEC <= MAX_TIMELINE_SEC) Triple(lane, start, minOf(duration, MAX_TIMELINE_SEC - start))
        else Triple(newTopLane(), 0f, duration)
    }

    fun saveNow() {
        if (!projectLoaded) return
        runCatching {
            ImageStudioProjectStore.save(
                context, projectId,
                images.map { ImageStudioImageRecord(it.id, it.file.name, it.duration, it.x, it.y, it.scale, it.rotation, it.opacity, it.visible, it.startTime, it.keyframes.map { k -> ImageStudioKeyframeRecord(k.time, k.x, k.y, k.scale, k.rotation, k.opacity, k.sculpt) }, it.name, it.locked, it.layerId, it.sculpt, it.sizeLocked, it.videoLength, it.videoOffset, it.rig, it.warpLayers, it.physics) },
                animationMode, motionPreset, layerIds.toList(), videoW, videoH, videoFps,
                WarpWorkspaceSettings(warpSettings, brushFrac, meshCell, meshRings, twistDeg, customWarpPresets),
            )
        }.onFailure { status = "บันทึกอัตโนมัติไม่สำเร็จ: ${it.message}" }
    }
    fun leave() {
        if (busy) return
        previewPlaying = false
        saveNow()
        onBack()
    }
    BackHandler { leave() }

    fun transformClip(id: Int, dx: Float, dy: Float, zoom: Float, rot: Float) {
        val i = indexOfClip(id)
        if (i < 0) return
        val item = images[i]
        if (item.locked || !isActiveAt(item, playhead)) return
        val pose = studioPoseAt(item, playhead, warpSettings.interpolation, warpSettings.followMotion, warpSettings.motionStrength)
        val nx = (pose.x + dx).coerceIn(-1_000_000f, 1_000_000f) // โหมดสร้างวิดีโอ: ไม่จำกัดตำแหน่ง/ขนาด (กันแค่ค่าเพี้ยน)
        val ny = (pose.y + dy).coerceIn(-1_000_000f, 1_000_000f)
        val ns = if (item.sizeLocked) pose.scale else (pose.scale * zoom).coerceIn(0.01f, 1000f)
        val nr = pose.rotation + rot
        if (item.keyframes.isEmpty()) {
            images[i] = item.copy(x = nx, y = ny, scale = ns, rotation = nr)
        } else {
            val t = (playhead - item.startTime).coerceIn(0f, item.duration)
            val key = StudioKeyframe(t, nx, ny, ns, nr, pose.opacity, pose.sculpt)
            images[i] = item.copy(keyframes = (item.keyframes.filterNot { abs(it.time - t) < 0.03f } + key).sortedBy { it.time }, warpLayers = emptyList())
        }
    }

    /** บันทึกท่าบิดภาพ: ไม่มี Keyframe = บิดทั้งคลิป · มี Keyframe = บันทึกที่จุดเวลาปัจจุบัน (สร้างจุดใหม่ถ้ายังไม่มี) */
    fun sculptClip(id: Int, grid: SculptGrid?, forceKeyframe: Boolean = false) {
        val i = indexOfClip(id)
        if (i < 0) return
        val item = images[i]
        if (item.locked || !isActiveAt(item, playhead)) return
        if (item.keyframes.isEmpty() && !forceKeyframe) { images[i] = item.copy(sculpt = grid, warpLayers = emptyList()); return }
        val pose = studioPoseAt(item, playhead, warpSettings.interpolation, warpSettings.followMotion, warpSettings.motionStrength)
        val t = (playhead - item.startTime).coerceIn(0f, item.duration)
        val key = StudioKeyframe(t, pose.x, pose.y, pose.scale, pose.rotation, pose.opacity, grid)
        images[i] = item.copy(keyframes = (item.keyframes.filterNot { abs(it.time - t) < 0.03f } + key).sortedBy { it.time }, warpLayers = emptyList())
    }

    /** เปลี่ยนความละเอียดตาข่ายของคลิปตามขนาดช่องที่ตั้ง: แปลงท่าบิดทั้งคลิปและทุก Keyframe เป็นจำนวนช่องใหม่ (ทุกท่าขนาดตรงกัน) */
    fun regridClip(id: Int) {
        val i = indexOfClip(id)
        if (i < 0) return
        val item = images[i]
        if (item.locked) return
        val (dc, dr) = Sculpt.gridDims(item.bitmap.width, item.bitmap.height, meshCell, warpSettings.meshCols, warpSettings.meshRows)
        fun rg(g: SculptGrid?): SculptGrid? = JointPins.relayout(item.rig, item.bitmap.width, item.bitmap.height, g, dc, dr) // ตาข่ายถี่ตามหมุดคงอยู่หลังเปลี่ยนความละเอียด
        images[i] = item.copy(
            sculpt = rg(item.sculpt), keyframes = item.keyframes.map { k -> k.copy(sculpt = rg(k.sculpt)) },
            warpLayers = item.warpLayers.map { layer -> layer.copy(grid = rg(layer.grid) ?: layer.grid, mask = layer.mask?.resized(dc, dr)) },
        )
        status = "ปรับตาข่ายเป็น $dc×$dr ช่องแล้ว"
    }

    // ── หมุดข้อต่ออัจฉริยะ (Adaptive Mesh Smart Joint Pin) ──
    /** บีบมุมงอของทุกหมุดในทุกท่าให้อยู่ในช่วงที่ตาข่ายไม่พับ (เรียกหลังเปลี่ยนความนุ่ม/ช่วงมุม) */
    fun clampPinAngles(item: StudioImage): StudioImage {
        fun cg(g: SculptGrid?): SculptGrid? {
            val src = g ?: return null
            val pa = src.pinAngles ?: return src
            var changed = false
            val a = FloatArray(pa.size) { k ->
                val pin = item.rig.pins.getOrNull(k)
                val v = pa[k]
                val nv = if (pin == null) v else JointPins.clampAngle(pin, v)
                if (nv != v) changed = true
                nv
            }
            return if (changed) SculptGrid(src.cols, src.rows, src.off, src.xs, src.ys, a) else src
        }
        return item.copy(sculpt = cg(item.sculpt), keyframes = item.keyframes.map { it.copy(sculpt = cg(it.sculpt)) })
    }

    /** แปลงท่าทั้งหมดของคลิปให้เข้ากับรูปแบบตาข่ายถี่ตามหมุดตอนนี้ (ตำแหน่งเส้นตาข่ายตามหมุด จำนวนช่องเท่าเดิม) */
    fun relayoutItem(item: StudioImage): StudioImage {
        val (dc, dr) = clipGridDims(item, meshCell, warpSettings.meshCols, warpSettings.meshRows)
        val bw = item.bitmap.width
        val bh = item.bitmap.height
        fun rl(g: SculptGrid?): SculptGrid? = JointPins.relayout(item.rig, bw, bh, g, dc, dr)
        return item.copy(sculpt = rl(item.sculpt), keyframes = item.keyframes.map { k -> k.copy(sculpt = rl(k.sculpt)) })
    }

    fun updateRig(id: Int, relayout: Boolean, block: (PinRig) -> PinRig) {
        val i = indexOfClip(id)
        if (i < 0) return
        val item = images[i]
        if (item.locked) return
        var next = clampPinAngles(item.copy(rig = block(item.rig)))
        if (relayout) next = relayoutItem(next)
        images[i] = next
    }

    fun updatePin(id: Int, pinId: Int, relayout: Boolean, block: (JointPin) -> JointPin) {
        updateRig(id, relayout) { r -> r.copy(pins = r.pins.map { if (it.id == pinId) block(it) else it }) }
    }

    fun addPin(id: Int, x: Float, y: Float, dir: Float?) {
        val i = indexOfClip(id)
        if (i < 0) return
        val item = images[i]
        if (item.locked) return
        pinPlacing = false
        if (item.rig.pins.size >= JointPins.MAX_PINS) { status = "ใส่หมุดได้สูงสุด ${JointPins.MAX_PINS} ตัวต่อคลิป"; return }
        val bw = item.bitmap.width
        val bh = item.bitmap.height
        val pin = JointPins.newPin(item.rig, bw, bh, x.coerceIn(0f, bw.toFloat()), y.coerceIn(0f, bh.toFloat()), dir)
        updateRig(id, true) { it.copy(pins = it.pins + pin) }
        selectedPinId = pin.id
        status = "วางหมุดแล้ว · ลากปลายสีเขียวเพื่อหมุนภาพรอบหมุดเป็นวงกลม · ลากจุดแดงเพื่อย้ายหมุด"
    }

    fun movePin(id: Int, pinId: Int, x: Float, y: Float, commit: Boolean) {
        val item = images.firstOrNull { it.id == id } ?: return
        val bw = item.bitmap.width.toFloat()
        val bh = item.bitmap.height.toFloat()
        updatePin(id, pinId, commit) { it.copy(x = x.coerceIn(0f, bw), y = y.coerceIn(0f, bh)) }
    }

    fun deletePin(id: Int, pinId: Int) {
        val i = indexOfClip(id)
        if (i < 0) return
        val item = images[i]
        if (item.locked) return
        val k = JointPins.indexOfId(item.rig.pins, pinId)
        if (k < 0) return
        val removed = item.copy(
            rig = JointPins.removePin(item.rig, k),
            sculpt = JointPins.dropAngle(item.sculpt, k),
            keyframes = item.keyframes.map { it.copy(sculpt = JointPins.dropAngle(it.sculpt, k)) },
        )
        images[i] = relayoutItem(removed)
        selectedPinId = 0
        status = "ลบหมุดแล้ว"
    }

    /** ตั้งมุมงอของหมุดลำดับ k ในท่า ณ เส้นแดง: มี Keyframe = บันทึกที่จุดเวลานี้ (เหมือนการบิดภาพ) ไม่มี = ใช้ทั้งคลิป */
    fun setPinAngle(id: Int, k: Int, deg: Float) {
        val i = indexOfClip(id)
        if (i < 0) return
        val item = images[i]
        if (item.locked || !isActiveAt(item, playhead)) return
        val pin = item.rig.pins.getOrNull(k) ?: return
        val pose = studioPoseAt(item, playhead, warpSettings.interpolation, warpSettings.followMotion, warpSettings.motionStrength)
        val (dc, dr) = clipGridDims(item, meshCell, warpSettings.meshCols, warpSettings.meshRows)
        sculptClip(id, JointPins.withAngle(item.rig, item.bitmap.width, item.bitmap.height, pose.sculpt, dc, dr, k, JointPins.clampAngle(pin, deg)))
    }

    fun resetPinAngles(id: Int) {
        val i = indexOfClip(id)
        if (i < 0) return
        val item = images[i]
        if (item.locked || !isActiveAt(item, playhead)) return
        val pose = studioPoseAt(item, playhead, warpSettings.interpolation, warpSettings.followMotion, warpSettings.motionStrength)
        if (hasPinAngle(pose.sculpt)) sculptClip(id, JointPins.clearAngles(pose.sculpt))
    }

    // ── ย้อนกลับ (สูงสุด UNDO_MAX ครั้ง) ──
    /** จดสถานะของคลิป (ท่าบิด/Keyframe/หมุด) ก่อนแก้ · key != null = การแก้ต่อเนื่องที่ชื่อเดียวกันภายใน 0.7 วินาที นับเป็นก้าวเดียว */
    fun markUndo(id: Int, key: String? = null) {
        val i = indexOfClip(id)
        if (i < 0) return
        if (redoStack.isNotEmpty()) { redoStack.clear(); redoCount = 0 } // แก้อะไรใหม่ = ทำซ้ำก้าวเก่าไม่ได้แล้ว
        val now = System.currentTimeMillis()
        val same = key != null && key == undoMeta.key && now - undoMeta.at < 700L
        undoMeta.key = key ?: ""
        undoMeta.at = now
        if (same) return
        val item = images[i]
        undoStack.add(UndoEntry(id, item.sculpt, item.keyframes, item.rig, warpLayers = item.warpLayers, physics = item.physics))
        while (undoStack.size > UNDO_MAX) undoStack.removeAt(0)
        undoCount = undoStack.size
    }

    /** สร้างการบิดเข้า-ออกเป็น Keyframe ตามช่วงเวลาที่ตั้งจนถึงท้ายคลิป */
    fun createWarpLoop(id: Int, settings: WarpSettings) {
        val i = indexOfClip(id)
        if (i < 0) return
        val item = images[i]
        if (item.locked || !isActiveAt(item, playhead)) return
        val pose = studioPoseAt(item, playhead, settings.interpolation, settings.followMotion, settings.motionStrength)
        val startAt = ((playhead - item.startTime) + settings.deformationDelay).coerceIn(0f, item.duration)
        val halfPeriod = (settings.loopDuration.coerceIn(0.1f, 30f) / settings.warpSpeed.coerceIn(0.1f, 5f) / 2f).coerceAtLeast(0.05f)
        val steps = ((item.duration - startAt) / halfPeriod).toInt().coerceIn(0, 600)
        if (steps < 1) { status = "ช่วงเวลาที่เหลือสั้นเกินไปสำหรับสร้างการบิดวน"; return }
        markUndo(id)
        val currentGrid = pose.sculpt
        val existing = item.keyframes.toMutableList()
        for (k in 0..steps) {
            val t = (startAt + k * halfPeriod).coerceAtMost(item.duration)
            val basePose = studioPoseAt(item, item.startTime + t, settings.interpolation, settings.followMotion, settings.motionStrength)
            val grid = if (k % 2 == 0) currentGrid else null
            existing.removeAll { abs(it.time - t) < 0.03f }
            existing += basePose.copy(time = t, sculpt = grid)
        }
        images[i] = item.copy(keyframes = existing.sortedBy { it.time })
        status = "สร้างคีย์เฟรมการบิดแบบสลับเข้า-ออก ${steps + 1} จุดแล้ว"
    }

    /** ย้อนหนึ่งก้าวจากกอง from แล้วเก็บสถานะปัจจุบันลงกอง to (ย้อนกลับ ↔ ทำซ้ำ ใช้ตัวเดียวกัน) · คืน true ถ้ามีการเปลี่ยนจริง */
    fun stepHistory(from: ArrayList<UndoEntry>, to: ArrayList<UndoEntry>): Boolean {
        var applied = false
        while (from.isNotEmpty() && !applied) {
            val e = from.removeAt(from.size - 1)
            val i = indexOfClip(e.clipId)
            if (i < 0) continue // คลิปถูกลบไปแล้ว
            val cur = images[i]
            if (cur.sculpt == e.sculpt && cur.keyframes == e.keyframes && cur.rig == e.rig && cur.warpLayers == e.warpLayers && cur.physics == e.physics && (e.bitmap == null || cur.bitmap === e.bitmap)) continue // ก้าวที่ไม่ได้เปลี่ยนอะไร ข้ามไป
            // ก้าวที่เกี่ยวกับภาพ (จบการบิด) เก็บภาพปัจจุบันไว้ด้วย เพื่อสลับกลับได้
            to.add(UndoEntry(e.clipId, cur.sculpt, cur.keyframes, cur.rig, if (e.bitmap != null) cur.file else null, if (e.bitmap != null) cur.bitmap else null, cur.warpLayers, cur.physics))
            while (to.size > UNDO_MAX) to.removeAt(0)
            val back = cur.copy(sculpt = e.sculpt, keyframes = e.keyframes, rig = e.rig, warpLayers = e.warpLayers, physics = e.physics)
            images[i] = if (e.bitmap != null && e.file != null) back.copy(file = e.file, bitmap = e.bitmap) else back
            if (selectedPinId != 0 && e.rig.pins.none { it.id == selectedPinId }) selectedPinId = 0
            applied = true
        }
        undoMeta.key = ""
        undoCount = undoStack.size
        redoCount = redoStack.size
        return applied
    }

    fun undoSculpt() {
        val ok = stepHistory(undoStack, redoStack)
        status = if (ok) "ย้อนกลับแล้ว (ย้อนได้อีก ${undoStack.size} ครั้ง · ทำซ้ำได้ ${redoStack.size} ครั้ง)" else "ไม่มีอะไรให้ย้อนกลับ"
    }

    fun redoSculpt() {
        val ok = stepHistory(redoStack, undoStack)
        status = if (ok) "ทำซ้ำแล้ว (ทำซ้ำได้อีก ${redoStack.size} ครั้ง · ย้อนได้ ${undoStack.size} ครั้ง)" else "ไม่มีอะไรให้ทำซ้ำ"
    }

    /**
     * จบการบิดจริง: ฝังท่าที่เห็น ณ เวลา t (ท่าบิด + การงอหมุด) ลงเป็นภาพใหม่ แล้วเริ่มตารางจากศูนย์
     * - ใช้ผืนผ้าใบเดิม (ส่วนที่บิดล้นกรอบจะถูกตัด) · คลิปวิดีโอฝังไม่ได้ (ท่าบิดคงอยู่ในคลิป)
     * - ท่าบิดของ Keyframe ทุกจุดถูกล้าง (เพราะอ้างอิงภาพเดิม) · หมุดข้อต่อย้ายตามไปอยู่ตำแหน่งที่เห็น มุมงอเป็น 0
     * - ย้อนกลับได้ (ปุ่ม ↶ คืนภาพเดิมด้วย)
     */
    fun bakeSculpt(clipId: Int, t: Float) {
        val clip = images.firstOrNull { it.id == clipId } ?: return
        if (clip.locked) return
        val g0 = studioPoseAt(clip, t, warpSettings.interpolation, warpSettings.followMotion, warpSettings.motionStrength).sculpt
        if (g0 == null && clip.warpLayers.isEmpty()) return
        if (isVideoClip(clip)) { status = "คลิปวิดีโอฝังท่าบิดลงภาพไม่ได้ (ท่าบิดยังอยู่ในคลิป)"; return }
        val bw = clip.bitmap.width
        val bh = clip.bitmap.height
        val eff = renderGrid(clip, g0, t - clip.startTime) ?: return
        if (eff.off.all { kotlin.math.abs(it) < 0.01f }) return // ไม่มีอะไรให้ฝัง
        val newPins = clip.rig.pins.map { pin ->
            val (nx, ny) = Sculpt.samplePos(eff, bw, bh, pin.x, pin.y)
            val rad = Math.toRadians(pin.dirDeg.toDouble())
            val (hx, hy) = Sculpt.samplePos(eff, bw, bh, pin.x + kotlin.math.cos(rad).toFloat() * 24f, pin.y + kotlin.math.sin(rad).toFloat() * 24f)
            pin.copy(x = nx, y = ny, dirDeg = Math.toDegrees(kotlin.math.atan2((hy - ny).toDouble(), (hx - nx).toDouble())).toFloat())
        }
        val otherWarp = clip.keyframes.any { k -> k.sculpt != null && !Sculpt.approxEquals(k.sculpt, g0) }
        val src = clip.bitmap
        scope.launch {
            val r = withContext(Dispatchers.IO) {
                runCatching {
                    val out = Bitmap.createBitmap(bw, bh, Bitmap.Config.ARGB_8888)
                    Sculpt.drawMesh(Canvas(out), src, eff, Paint(Paint.FILTER_BITMAP_FLAG or Paint.ANTI_ALIAS_FLAG))
                    val bytes = java.io.ByteArrayOutputStream().also { out.compress(Bitmap.CompressFormat.PNG, 100, it) }.toByteArray()
                    val key = -(1 + (System.currentTimeMillis() % 100000000L).toInt()) // ชื่อไฟล์ไม่ซ้ำ: ไฟล์เดิมเก็บไว้ให้ย้อนกลับได้
                    val file = ImageStudioProjectStore.importImage(context, projectId, key, "bake.png", java.io.ByteArrayInputStream(bytes))
                    Pair(file, out)
                }
            }
            r.onSuccess { (file, out) ->
                val i = indexOfClip(clipId)
                if (i < 0) return@onSuccess
                val cur = images[i]
                undoStack.add(UndoEntry(clipId, cur.sculpt, cur.keyframes, cur.rig, cur.file, cur.bitmap, cur.warpLayers, cur.physics))
                while (undoStack.size > UNDO_MAX) undoStack.removeAt(0)
                undoCount = undoStack.size
                redoStack.clear(); redoCount = 0
                images[i] = cur.copy(file = file, bitmap = out, sculpt = null, keyframes = cur.keyframes.map { it.copy(sculpt = null) }, rig = cur.rig.copy(pins = newPins), warpLayers = emptyList(), physics = WarpPhysicsSettings())
                status = "จบการบิด: ฝังท่าลงภาพแล้ว (ตารางเริ่มใหม่จากศูนย์)" + (if (otherWarp) " · ท่าบิดของคีย์เฟรมอื่นถูกล้าง" else "") + " · ย้อนกลับได้"
            }.onFailure { status = "ฝังท่าบิดลงภาพไม่สำเร็จ: ${it.message}" }
        }
    }

    fun duplicateClip(id: Int) {
        val src = images.firstOrNull { it.id == id } ?: return
        if (images.size >= 30) { status = "เพิ่มได้สูงสุด 30 ภาพต่อหนึ่งงาน"; return }
        runCatching {
            val nextId = (images.maxOfOrNull { it.id } ?: 0) + 1
            val isVid = isVideoClip(src) // วิดีโอ: ใช้ไฟล์และภาพปกเดียวกัน (ไม่คัดลอกไฟล์ใหญ่ซ้ำ)
            val file = if (isVid) src.file else src.file.inputStream().use { ImageStudioProjectStore.importImage(context, projectId, nextId, "copy.${src.file.extension.ifBlank { "img" }}", it) }
            val bmp = if (isVid) src.bitmap else src.bitmap.copy(Bitmap.Config.ARGB_8888, false) ?: throw IllegalStateException("คัดลอกภาพไม่ได้")
            var lane = src.layerId
            var start = clipEnd(src)
            if (start + src.duration > MAX_TIMELINE_SEC || !laneIsFree(images, lane, start, src.duration, -1)) { lane = newTopLane(); start = src.startTime }
            images.add(src.copy(id = nextId, file = file, bitmap = bmp, startTime = start, layerId = lane, name = clipLabel(src) + " (สำเนา)"))
            selectClip(nextId)
            status = "ทำซ้ำคลิปแล้ว"
        }.onFailure { status = "ทำซ้ำไม่สำเร็จ: ${it.message}" }
    }

    fun splitClip(id: Int) {
        val i = indexOfClip(id)
        if (i < 0) return
        val src = images[i]
        val cut = playhead
        if (cut <= src.startTime + MIN_CLIP_SEC || cut >= clipEnd(src) - MIN_CLIP_SEC) { status = "เลื่อนเส้นเวลาไปกลางคลิปก่อนแบ่ง"; return }
        if (images.size >= 30) { status = "เพิ่มได้สูงสุด 30 ภาพต่อหนึ่งงาน"; return }
        runCatching {
            val nextId = (images.maxOfOrNull { it.id } ?: 0) + 1
            val isVid = isVideoClip(src)
            val file = if (isVid) src.file else src.file.inputStream().use { ImageStudioProjectStore.importImage(context, projectId, nextId, "part.${src.file.extension.ifBlank { "img" }}", it) }
            val bmp = if (isVid) src.bitmap else src.bitmap.copy(Bitmap.Config.ARGB_8888, false) ?: throw IllegalStateException("คัดลอกภาพไม่ได้")
            val d1 = cut - src.startTime
            val d2 = src.duration - d1
            val pose = studioPoseAt(src, cut, warpSettings.interpolation, warpSettings.followMotion, warpSettings.motionStrength)
            val hasKeys = src.keyframes.isNotEmpty()
            val keysA = if (hasKeys) src.keyframes.filter { it.time < d1 - 0.01f } + StudioKeyframe(d1, pose.x, pose.y, pose.scale, pose.rotation, pose.opacity, pose.sculpt) else emptyList()
            val keysB = if (hasKeys) listOf(StudioKeyframe(0f, pose.x, pose.y, pose.scale, pose.rotation, pose.opacity, pose.sculpt)) + src.keyframes.filter { it.time > d1 + 0.01f }.map { it.copy(time = it.time - d1) } else emptyList()
            images[i] = src.copy(duration = d1, keyframes = keysA)
            images.add(src.copy(id = nextId, file = file, bitmap = bmp, startTime = cut, duration = d2, keyframes = keysB, name = clipLabel(src) + " (ต่อ)",
                videoOffset = if (isVid) src.videoOffset + d1 else 0f)) // วิดีโอ: ท่อนหลังเล่นต่อจากจุดที่แบ่ง
            selectClip(nextId)
            status = "แบ่งคลิปที่ ${f1(cut)} วินาทีแล้ว"
        }.onFailure { status = "แบ่งคลิปไม่สำเร็จ: ${it.message}" }
    }

    fun deleteClip(id: Int) {
        val i = indexOfClip(id)
        if (i < 0) return
        images.removeAt(i)
        selectedId = images.getOrNull(i.coerceAtMost(images.lastIndex))?.id ?: -1
        status = "ลบคลิปแล้ว"
    }

    // ── เสียง / ข้อความ ──
    val audioPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) scope.launch {
            runCatching { withContext(Dispatchers.IO) { AudioStore.importFrom(context, uri) { } } }
                .onSuccess { imported -> audioFile = File(AudioStore.dir(context), imported.file); status = "เพิ่มแทร็กเสียงแล้ว" }
                .onFailure { status = "เพิ่มเสียงไม่สำเร็จ: ${it.message}" }
        }
    }
    LaunchedEffect(projectId) {
        val prefs = context.getSharedPreferences("image_studio_extra_$projectId", Context.MODE_PRIVATE)
        overlayText = prefs.getString("overlayText", "") ?: ""
        overlaySticker = prefs.getString("overlaySticker", "") ?: ""
        overlayStart = prefs.getFloat("overlayStart", 0f)
        overlayDuration = prefs.getFloat("overlayDuration", 5f)
        audioStart = prefs.getFloat("audioStart", 0f)
        audioVolume = prefs.getFloat("audioVolume", 1f)
        audioFile = prefs.getString("audioPath", null)?.let(::File)?.takeIf { it.isFile }
    }
    LaunchedEffect(overlayText, overlaySticker, overlayStart, overlayDuration, audioFile, audioStart, audioVolume) {
        context.getSharedPreferences("image_studio_extra_$projectId", Context.MODE_PRIVATE).edit()
            .putString("overlayText", overlayText).putString("overlaySticker", overlaySticker)
            .putFloat("overlayStart", overlayStart).putFloat("overlayDuration", overlayDuration)
            .putString("audioPath", audioFile?.absolutePath).putFloat("audioStart", audioStart)
            .putFloat("audioVolume", audioVolume).apply()
    }

    // ── โหลดโปรเจกต์ ──
    LaunchedEffect(projectId) {
        loadingProject = true
        runCatching { ImageStudioProjectStore.loadImages(context, projectId) }
            .onSuccess { loaded ->
                images.clear()
                loaded.forEach { (record, bitmap) ->
                    images.add(StudioImage(
                        record.id, File(context.filesDir, "image_studio/projects/$projectId/images/${record.fileName}"), bitmap,
                        record.duration, record.x, record.y, record.scale, record.rotation, record.opacity, record.visible, record.startTime,
                        record.keyframes.map { StudioKeyframe(it.time, it.x, it.y, it.scale, it.rotation, it.opacity, it.sculpt) },
                        record.name, record.locked, record.layerId, record.sculpt, record.sizeLocked,
                        videoLength = record.videoLength, videoOffset = record.videoOffset, rig = record.rig,
                        warpLayers = record.warpLayers, physics = record.physics,
                    ))
                }
                selectedId = images.firstOrNull()?.id ?: -1
                activeLayerId = images.firstOrNull()?.layerId ?: 1
                val ids = (ImageStudioProjectStore.loadLayerIds(context, projectId) + loaded.map { it.first.layerId } + 1).distinct().sorted()
                layerIds.clear(); layerIds.addAll(ids)
                val settings = ImageStudioProjectStore.loadSettings(context, projectId)
                animationMode = settings.first
                motionPreset = settings.second
                val vs = ImageStudioProjectStore.loadVideoSize(context, projectId)
                videoW = vs.first; videoH = vs.second
                videoFps = ImageStudioProjectStore.loadVideoFps(context, projectId)
                val workspace = ImageStudioProjectStore.loadWarpWorkspace(context, projectId)
                warpSettings = workspace.warp
                brushFrac = workspace.brushFraction
                meshCell = workspace.meshCell
                meshRings = workspace.meshRings
                twistDeg = workspace.twistDegrees
                customWarpPresets = workspace.customPresets
                projectLoaded = true
            }
            .onFailure { status = "เปิดโปรเจกต์ไม่สำเร็จ: ${it.message}"; projectLoaded = false }
        loadingProject = false
    }

    // ── บันทึกอัตโนมัติ ──
    val saveKey = images.joinToString("|") { "${it.id}:${it.duration}:${it.x}:${it.y}:${it.scale}:${it.rotation}:${it.opacity}:${it.visible}:${it.startTime}:${it.keyframes}:${it.name}:${it.locked}:${it.layerId}:${it.sculpt}:${it.sizeLocked}:${it.videoLength}:${it.videoOffset}:${it.rig}:${it.warpLayers}:${it.physics}:${it.file.name}" }
    LaunchedEffect(saveKey, layerIds.toList(), animationMode, motionPreset, loadingProject, videoW, videoH, videoFps, warpSettings, brushFrac, meshCell, meshRings, twistDeg, customWarpPresets) {
        if (!loadingProject && projectLoaded) {
            delay(650)
            saveNow()
        }
    }

    // ── ข้อความสถานะหายเองหลัง 3.5 วินาที ──
    LaunchedEffect(status) {
        val shown = status
        if (shown != null) { delay(3500); if (status == shown) status = null }
    }

    // ── เล่นตัวอย่าง ──
    LaunchedEffect(previewPlaying) {
        if (!previewPlaying) return@LaunchedEffect
        var last = withFrameNanos { it }
        while (true) {
            val now = withFrameNanos { it }
            val dt = (now - last) / 1_000_000_000f
            last = now
            val end = images.maxOfOrNull { clipEnd(it) } ?: 0f
            if (end <= 0f) { previewPlaying = false; break }
            var next = playhead + dt
            if (next >= end) next = 0f
            playhead = next
        }
    }

    // ── เพิ่มภาพ: เลือกไฟล์ -> หน้าตัดภาพ (ตัดพื้นหลังให้โปร่งใส) -> เข้าโปรเจกต์ ──
    fun addClip(nextId: Int, file: File, bmp: Bitmap) {
        val (lane, start, dur) = placeNewClip(3f)
        if (lane !in layerIds) layerIds.add(lane)
        images.add(StudioImage(
            nextId, file, bmp, duration = dur, startTime = start, name = "ภาพ $nextId", layerId = lane,
            keyframes = if (animationMode) presetKeyframes(dur, motionPreset) else emptyList(),
        ))
        selectClip(nextId)
        playhead = start
    }

    fun finishImport(job: PendingImport, result: Bitmap) {
        if (pendingImports.isNotEmpty()) pendingImports.removeAt(0)
        val nextId = maxOf(images.maxOfOrNull { it.id } ?: 0, lastAssignedId) + 1
        lastAssignedId = nextId
        scope.launch {
            val r = withContext(Dispatchers.IO) {
                runCatching {
                    val file: File
                    val bmp: Bitmap
                    if (result === job.bitmap) {
                        // ไม่ได้แก้ภาพ: นำเข้าไฟล์ต้นฉบับเหมือนเดิม
                        val input = context.contentResolver.openInputStream(job.uri) ?: throw IllegalArgumentException("อ่านไฟล์ภาพไม่ได้")
                        file = ImageStudioProjectStore.importImage(context, projectId, nextId, job.name, input)
                        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
                        BitmapFactory.decodeFile(file.absolutePath, bounds)
                        if (bounds.outWidth <= 0 || bounds.outHeight <= 0) throw IllegalArgumentException("ไฟล์ภาพไม่ถูกต้อง")
                        var sample = 1
                        while (max(bounds.outWidth, bounds.outHeight) / sample > 1600) sample *= 2
                        val opts = BitmapFactory.Options().apply { inSampleSize = sample; inPreferredConfig = Bitmap.Config.ARGB_8888 }
                        bmp = BitmapFactory.decodeFile(file.absolutePath, opts) ?: throw IllegalArgumentException("อ่านไฟล์ภาพไม่ได้")
                    } else {
                        // ภาพที่ตัด/ลบแล้ว: ตัดขอบโปร่งใส ย่อถ้าใหญ่ แล้วเก็บเป็น PNG เพื่อคงความโปร่งใส
                        val cut = ImageImport.limitSize(ImageImport.trimTransparent(result), 1600)
                        val bytes = java.io.ByteArrayOutputStream().also { cut.compress(Bitmap.CompressFormat.PNG, 100, it) }.toByteArray()
                        file = ImageStudioProjectStore.importImage(context, projectId, nextId, "cutout.png", java.io.ByteArrayInputStream(bytes))
                        bmp = cut
                    }
                    Pair(file, bmp)
                }
            }
            r.onSuccess { (file, bmp) -> addClip(nextId, file, bmp) }
                .onFailure { status = "เปิดรูปภาพไม่สำเร็จ: ${it.message}" }
        }
    }

    /** แก้ไขภาพของคลิปที่มีอยู่: ผลที่ได้แทนที่ภาพเดิมบนผืนผ้าใบขนาดเดิม (ตำแหน่ง/ขนาด/การบิดของคลิปจึงไม่เปลี่ยน) เก็บเป็น PNG */
    fun finishEdit(clip: StudioImage, out: Bitmap, left: Int, top: Int) {
        editClipId = -1
        val w = clip.bitmap.width
        val h = clip.bitmap.height
        scope.launch {
            val r = withContext(Dispatchers.IO) {
                runCatching {
                    val full = if (out.width == w && out.height == h && left == 0 && top == 0) out
                    else Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888).also { Canvas(it).drawBitmap(out, left.toFloat(), top.toFloat(), null) }
                    val bytes = java.io.ByteArrayOutputStream().also { full.compress(Bitmap.CompressFormat.PNG, 100, it) }.toByteArray()
                    val file = ImageStudioProjectStore.importImage(context, projectId, clip.id, "edit.png", java.io.ByteArrayInputStream(bytes))
                    Pair(file, full)
                }
            }
            r.onSuccess { (file, full) ->
                updateClip(clip.id) { it.copy(file = file, bitmap = full) }
                status = "แก้ไขภาพแล้ว"
            }.onFailure { status = "บันทึกภาพที่แก้ไม่สำเร็จ: ${it.message}" }
        }
    }

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { uris ->
        scope.launch {
            uris.forEach { uri ->
                if (images.size + pendingImports.size >= 30) { status = "เพิ่มได้สูงสุด 30 ภาพต่อหนึ่งงาน"; return@forEach }
                val r = withContext(Dispatchers.IO) { runCatching { ImageImport.decode(context, uri) } }
                r.onSuccess { pendingImports.add(PendingImport(uri, uri.lastPathSegment ?: "image.png", it)) }
                    .onFailure { status = "เปิดรูปภาพไม่สำเร็จ: ${it.message}" }
            }
        }
    }

    // ── เพิ่มวิดีโอ: คัดลอกไฟล์เข้าโปรเจกต์ -> อ่านความยาว/ภาพปก -> วางเป็นคลิปบน Timeline ──
    val videoPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            if (images.size + pendingImports.size >= 30) { status = "เพิ่มได้สูงสุด 30 คลิปต่อหนึ่งงาน"; return@rememberLauncherForActivityResult }
            val nextId = maxOf(images.maxOfOrNull { it.id } ?: 0, lastAssignedId) + 1
            lastAssignedId = nextId
            busyImport = true
            status = "กำลังนำเข้าวิดีโอ…"
            scope.launch {
                val r = withContext(Dispatchers.IO) {
                    runCatching {
                        val input = context.contentResolver.openInputStream(uri) ?: throw IllegalArgumentException("อ่านไฟล์วิดีโอไม่ได้")
                        val file = ImageStudioProjectStore.importImage(context, projectId, nextId, "clip.mp4", input)
                        try {
                            val info = VideoFrames.probe(file)
                            Triple(file, info.poster, info.durationSec)
                        } catch (t: Throwable) { file.delete(); throw t }
                    }
                }
                busyImport = false
                r.onSuccess { (file, poster, len) ->
                    val (lane, start, dur) = placeNewClip(minOf(len, MAX_TIMELINE_SEC))
                    if (lane !in layerIds) layerIds.add(lane)
                    images.add(StudioImage(
                        nextId, file, poster, duration = dur, startTime = start, name = "วิดีโอ $nextId", layerId = lane,
                        videoLength = len,
                    ))
                    selectClip(nextId)
                    playhead = start
                    status = "เพิ่มวิดีโอแล้ว (${f1(len)} วินาที)"
                }.onFailure { status = "เพิ่มวิดีโอไม่สำเร็จ: ${it.message ?: it.javaClass.simpleName}" }
            }
        }
    }

    /** ดึงเสียงของคลิปวิดีโอมาเป็นแทร็กเสียงของงาน (แทนแทร็กเสียงเดิม ถ้ามี) เริ่มพร้อมภาพของคลิป */
    fun useVideoAudio(clip: StudioImage) {
        val st = clip.startTime - clip.videoOffset
        if (st < 0f) { status = "คลิปนี้ถูกตัดหัวไว้มากกว่าตำแหน่งบน Timeline จึงจัดเสียงให้ตรงภาพไม่ได้"; return }
        busyImport = true
        status = "กำลังดึงเสียงจากวิดีโอ…"
        scope.launch {
            runCatching { withContext(Dispatchers.IO) { AudioStore.importFrom(context, android.net.Uri.fromFile(clip.file)) { } } }
                .onSuccess { imported ->
                    audioFile = File(AudioStore.dir(context), imported.file)
                    audioStart = st
                    status = "ใช้เสียงของวิดีโอเป็นแทร็กเสียงแล้ว"
                }
                .onFailure { status = "ดึงเสียงไม่สำเร็จ: ${it.message ?: it.javaClass.simpleName}" }
            busyImport = false
        }
    }

    // ── ส่งออก MP4 ──
    fun startExport() {
        if (images.isEmpty() || busy) return
        previewPlaying = false
        busy = true; exportProgress = 0f; status = "กำลังเตรียมวิดีโอ..."
        val snapshot = images.toList()
        val exportOverlayText = overlayText
        val exportOverlaySticker = overlaySticker
        val exportOverlayStart = overlayStart
        val exportOverlayDuration = overlayDuration
        val exportAudio = audioFile
        val exportAudioStart = audioStart
        val exportAudioVolume = audioVolume
        val exportW = videoW
        val exportH = videoH
        val exportFps = videoFps
        scope.launch {
            val result = withContext(Dispatchers.IO) {
                runCatching {
                    val fps = exportFps // เฟรมต่อวินาทีที่ผู้ใช้ตั้ง (ค่าเริ่มต้น 30)
                    // ความยาววิดีโอ = ปลายคลิปที่อยู่ไกลที่สุดบน Timeline (ตรงกับที่เห็น)
                    val durationSec = snapshot.maxOf { clipEnd(it) }.coerceAtLeast(MIN_CLIP_SEC)
                    val frameCount = (durationSec * fps).roundToInt().coerceAtLeast(1)
                    Exporter.validateVideo(exportW, exportH, 1, frameCount, maxFrames = Long.MAX_VALUE)?.let { throw IllegalArgumentException(it) }
                    val ordered = stackOrder(snapshot) // ล่าง → บน (แทร็กสูงอยู่บน) เหมือนบนหน้าจอ
                    // ช่วงเฟรมที่คลิปแสดง: ใช้ตัวเลขเดียวกันทั้งตอนตั้ง Part และตอนสร้างท่าของแต่ละเฟรม
                    val ranges = HashMap<Int, IntRange>()
                    ordered.forEach { item ->
                        val a = (item.startTime * fps).roundToInt().coerceIn(0, frameCount - 1)
                        val b = (((item.startTime + item.duration) * fps).roundToInt() - 1).coerceIn(a, frameCount - 1)
                        ranges[item.id] = a..b
                    }
                    val parts = ordered.mapIndexed { index, item ->
                        val r = ranges.getValue(item.id)
                        Part(item.id, clipLabel(item), item.bitmap).apply {
                            pivotX = bitmap.width / 2f; pivotY = bitmap.height / 2f
                            scale = fitScale(bitmap.width, bitmap.height) // พอดีเฟรมเหมือนบน Canvas
                            visible = item.visible
                            characterId = item.id
                            characterName = "ภาพ ${index + 1}"
                            charAlpha = 1f
                            appearFrom = r.first
                            appearTo = r.last
                        }
                    }.toMutableList()

                    // คลิปวิดีโอ: ก่อนวาดแต่ละเฟรม สลับภาพของชิ้นส่วนเป็นเฟรมของเวลานั้น (ขนาดเท่าภาพปกเสมอ)
                    val videoJobs = ordered.mapIndexedNotNull { idx, item ->
                        if (isVideoClip(item)) Triple(item, parts[idx], VideoReader(item.file, item.videoLength)) else null
                    }
                    val frameHook: (Float) -> Unit = { pos ->
                        val t = pos / fps
                        for ((item, part, reader) in videoJobs) {
                            if (!item.visible) continue
                            val rg = ranges.getValue(item.id)
                            if (pos < rg.first - 0.001f || pos > rg.last + 0.001f) continue
                            val frame = runCatching { reader.frame(videoLocalTime(item, t), item.bitmap.width, item.bitmap.height, exact = true) }.getOrNull() ?: continue
                            val old = part.bitmap
                            part.bitmap = frame
                            if (old !== item.bitmap) old.recycle() // ภาพปกยังใช้บนจอ ห้าม recycle
                        }
                    }

                    val hasOverlay = exportOverlayText.isNotBlank() || exportOverlaySticker.isNotBlank()
                    val oa = (exportOverlayStart * fps).roundToInt().coerceIn(0, frameCount - 1)
                    val ob = (((exportOverlayStart + exportOverlayDuration) * fps).roundToInt() - 1).coerceIn(oa, frameCount - 1)
                    val overlayBitmap = if (hasOverlay) Bitmap.createBitmap(OUT_SIZE, OUT_SIZE, Bitmap.Config.ARGB_8888).also { bitmap ->
                        val canvas = Canvas(bitmap)
                        val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                            color = android.graphics.Color.WHITE; textSize = 46f
                            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
                            textAlign = Paint.Align.CENTER; setShadowLayer(4f, 2f, 2f, android.graphics.Color.BLACK)
                        }
                        while (paint.measureText(exportOverlayText) > OUT_SIZE - 60f && paint.textSize > 16f) paint.textSize -= 2f
                        val both = exportOverlaySticker.isNotBlank() && exportOverlayText.isNotBlank()
                        if (exportOverlaySticker.isNotBlank()) canvas.drawText(exportOverlaySticker, OUT_SIZE / 2f, if (both) 340f else 382f, paint)
                        if (exportOverlayText.isNotBlank()) canvas.drawText(exportOverlayText, OUT_SIZE / 2f, if (both) 410f else 382f, paint)
                    } else null
                    if (overlayBitmap != null) parts.add(Part(OVERLAY_ID, "ข้อความ/สติกเกอร์", overlayBitmap).apply {
                        scale = Exporter.WORLD_WINDOW / OUT_SIZE
                        appearFrom = oa; appearTo = ob
                    })

                    // สร้างท่าของแต่ละเฟรมตอนที่ตัวเข้ารหัสขอ (ไม่สร้างล่วงหน้าทั้งหมด: วิดีโอยาวหลายนาทีจะกินหน่วยความจำมาก)
                    val frames: List<Map<Int, Pose>> = object : AbstractList<Map<Int, Pose>>() {
                      override val size: Int get() = frameCount
                      override fun get(index: Int): Map<Int, Pose> {
                        val f = index
                        val t = f / fps.toFloat()
                        val map = HashMap<Int, Pose>()
                        ordered.forEach { item ->
                            if (item.visible && f in ranges.getValue(item.id)) {
                                val p = studioPoseAt(item, t, warpSettings.interpolation, warpSettings.followMotion, warpSettings.motionStrength)
                                map[item.id] = Pose(rotation = p.rotation, dx = p.x, dy = p.y, sculpt = renderGrid(item, p.sculpt, t - item.startTime), scale = p.scale, alpha = p.opacity)
                            }
                        }
                        if (overlayBitmap != null && f in oa..ob) map[OVERLAY_ID] = Pose()
                        return map
                      }
                    }
                    val outW = Exporter.videoSize(exportW) // ปัดเป็นพหุคูณของ 16 เหมือนที่กรอบบนผืนผ้าใบคำนวณ
                    val outH = Exporter.videoSize(exportH)
                    val tmp = File(context.cacheDir, "image_studio_${System.currentTimeMillis()}.mp4")
                    try {
                        Exporter.encodeVideo(parts, frames, outW, outH, fps.toFloat(), 1, android.graphics.Color.BLACK, tmp,
                            fpsAt = { fps.toFloat() }, loopN = frameCount,
                            onProgress = { done, total -> exportProgress = done.toFloat() / total.coerceAtLeast(1) },
                            frameHook = if (videoJobs.isEmpty()) null else frameHook, outFps = fps)
                    } finally {
                        videoJobs.forEach { it.third.close() }
                    }
                    var outputVideo = tmp
                    val sound = exportAudio
                    if (sound != null && sound.isFile && exportAudioVolume > 0f) {
                        val aac = AudioExport.encodeAac(listOf(AudioPlaySpec(sound, exportAudioStart, 0f, (durationSec - exportAudioStart).coerceAtLeast(0f), exportAudioVolume)), durationSec.toDouble(), 1) { }
                        val muxed = File(context.cacheDir, "image_studio_mux_${System.currentTimeMillis()}.mp4")
                        AudioExport.muxVideoAudio(tmp, aac, muxed)
                        outputVideo = muxed
                    }
                    val saved = Exporter.saveVideo(context, outputVideo, "image_video_${System.currentTimeMillis()}")
                    tmp.delete(); if (outputVideo != tmp) outputVideo.delete(); overlayBitmap?.recycle()
                    saved
                }
            }
            busy = false
            status = result.fold({ "บันทึกวิดีโอสำเร็จ: $it" }, { "สร้างวิดีโอไม่สำเร็จ: ${it.message ?: it.javaClass.simpleName}" })
        }
    }

    // ───────────── หน้าตัดภาพเต็มจอ: ใช้หน้าเดียวกับตอนสร้างตัวละคร (บ่วง / ดัดโค้ง / ยางลบ / จอย) ─────────────
    val importJob = pendingImports.firstOrNull()
    if (importJob != null) {
        key(importJob) {
            ImageCropScreen(
                bitmap = importJob.bitmap,
                onConfirm = { cropped, _, _ -> finishImport(importJob, cropped) },
                onCancel = { if (pendingImports.isNotEmpty()) pendingImports.removeAt(0) },
            )
        }
        return
    }
    val editTarget = images.firstOrNull { it.id == editClipId }
    if (editTarget != null) {
        key(editTarget.id) {
            ImageCropScreen(
                bitmap = editTarget.bitmap,
                onConfirm = { out, left, top -> finishEdit(editTarget, out, left, top) },
                onCancel = { editClipId = -1 },
                allowAddImage = true, // เพิ่มรูปซ้อนได้ (ไว้ลบแล้วเปลี่ยนส่วนที่ลบ) เหมือนหน้าแก้ไขภาพของตัวละคร
            )
        }
        return
    }

    // ───────────── หน้าจอ ─────────────
    Column(
        Modifier.fillMaxSize().background(c.Bg).systemBarsPadding().padding(horizontal = 10.dp, vertical = 8.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp),
    ) {
        // หัวเรื่อง
        Row(
            Modifier.fillMaxWidth().background(c.Panel, RoundedCornerShape(16.dp)).padding(horizontal = 6.dp, vertical = 4.dp),
            verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp),
        ) {
            Box(Modifier.size(38.dp).clip(CircleShape).clickable(enabled = !busy, onClick = { leave() }), contentAlignment = Alignment.Center) {
                Text("‹", color = c.Ink, fontSize = 26.sp)
            }
            Column(Modifier.weight(1f)) {
                Text("สตูดิโอภาพ", color = c.Ink, fontSize = 16.sp, fontWeight = FontWeight.Bold)
                Text(
                    if (loadingProject) "กำลังเปิดโปรเจกต์…" else "${images.size} คลิป · ${layerIds.size} แทร็ก · ${fmtClock(timelineEnd)}",
                    color = c.Sub, fontSize = 11.sp, maxLines = 1,
                )
            }
            Button(
                onClick = { startExport() },
                enabled = images.isNotEmpty() && !busy && !loadingProject,
                shape = RoundedCornerShape(12.dp),
                contentPadding = PaddingValues(horizontal = 14.dp, vertical = 6.dp),
                colors = ButtonDefaults.buttonColors(containerColor = c.Accent, contentColor = Color(0xFF06141F), disabledContainerColor = c.Panel2, disabledContentColor = c.Sub),
            ) { Text(if (busy) "กำลังสร้าง…" else "ส่งออก MP4", fontWeight = FontWeight.Bold, fontSize = 13.sp) }
        }
        Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.CenterVertically) {
            ToolChip("🖼 เพิ่มภาพ", enabled = !busy && !loadingProject && !busyImport, onClick = { picker.launch(arrayOf("image/*")) })
            ToolChip("🎬 เพิ่มวิดีโอ", enabled = !busy && !loadingProject && !busyImport, onClick = { videoPicker.launch(arrayOf("video/*")) })
            ToolChip("✎ แก้ไขภาพ", enabled = current != null && !isVideoClip(current) && !busy, onClick = { current?.let { previewPlaying = false; editClipId = it.id } })
            ToolChip("📐 ขนาดวิดีโอ", enabled = !busy && !loadingProject, onClick = { showVideoSize = true })
            ToolChip("⏱ $videoFps เฟรม/วินาที", enabled = !busy && !loadingProject, onClick = { showFpsDialog = true })
        }
        if (loadingProject) LinearProgressIndicator(Modifier.fillMaxWidth(), color = c.Accent)
        if (busy) LinearProgressIndicator(progress = { exportProgress }, modifier = Modifier.fillMaxWidth(), color = c.Ok)

        if (images.isEmpty() && !loadingProject) {
            Box(Modifier.weight(1f).fillMaxWidth().background(c.Panel, RoundedCornerShape(18.dp)), contentAlignment = Alignment.Center) {
                Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text("🖼", fontSize = 46.sp)
                    Text("ยังไม่มีรูปภาพหรือวิดีโอ", color = c.Ink, fontSize = 18.sp, fontWeight = FontWeight.Bold)
                    Text("เพิ่มรูปภาพหรือวิดีโอแล้วจัดเวลา/แทร็กบน Timeline ได้เลย", color = c.Sub, fontSize = 13.sp)
                    Button(
                        onClick = { picker.launch(arrayOf("image/*")) },
                        shape = RoundedCornerShape(14.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = c.Accent, contentColor = Color(0xFF06141F)),
                    ) { Text("＋ เพิ่มรูปภาพ", fontWeight = FontWeight.Bold) }
                    Button(
                        onClick = { videoPicker.launch(arrayOf("video/*")) },
                        enabled = !busyImport,
                        shape = RoundedCornerShape(14.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = c.Panel2, contentColor = c.Ink),
                    ) { Text("＋ เพิ่มวิดีโอ", fontWeight = FontWeight.Bold) }
                }
            }
        } else {
            // Canvas
            Box(Modifier.weight(1f).fillMaxWidth().background(c.Panel, RoundedCornerShape(18.dp)).padding(8.dp)) {
                StudioCanvas(
                    images = images, playhead = playhead, selectedId = selectedId,
                    overlayText = overlayText, overlaySticker = overlaySticker, overlayStart = overlayStart, overlayDuration = overlayDuration,
                    onSelect = { id -> if (id < 0) selectedId = -1 else selectClip(id) },
                    onTransform = { id, dx, dy, zoom, rot -> transformClip(id, dx, dy, zoom, rot) },
                    sculptMode = sculptMode && current != null, brushFrac = brushFrac,
                    sculptTool = sculptTool, meshCell = meshCell, meshRings = meshRings, twistDeg = twistDeg, warpSettings = warpSettings, videoW = videoW, videoH = videoH,
                    onSculpt = { id, g -> sculptClip(id, g, warpSettings.autoKeyframe) },
                    onWarpLayers = { id, layers -> updateClip(id) { it.copy(warpLayers = layers) } },
                    lockedMeshPoints = lockedMeshPoints, onMeshPointSelected = { selectedMeshPoint = it },
                    pinSelectedId = selectedPinId, pinPlacing = pinPlacing && sculptTool == SculptTool.PIN, pinShowMesh = pinShowMesh,
                    onPinSelect = { selectedPinId = it },
                    onPinAdd = { id, x, y, dir -> markUndo(id); addPin(id, x, y, dir) },
                    onPinMove = { id, pinId, x, y, commit -> movePin(id, pinId, x, y, commit) },
                    onPinAngle = { id, k, deg -> setPinAngle(id, k, deg) },
                    onNotice = { status = it },
                    onUndoMark = { id -> markUndo(id) },
                    lensOpen = lensOpen, onLensClose = { lensOpen = false },
                    modifier = Modifier.fillMaxSize(),
                )
                // ปุ่มลอยทับเวที: ซ้ายบน=ล็อก · กลางบน=เสียงวิดีโอ+ปรับแต่ง · ขวาบน=ซ่อน · ซ้ายล่าง=เล่น · ขวาล่าง=ย้อนกลับ/ทำซ้ำ
                Box(Modifier.align(Alignment.TopStart)) {
                    ToolChip(if (current?.locked == true) "🔓 ปลดล็อก" else "🔒 ล็อก", onClick = { current?.let { cl -> updateClip(cl.id) { it.copy(locked = !it.locked) } } }, enabled = current != null)
                }
                Row(Modifier.align(Alignment.TopCenter), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    ToolChip("🔊 เสียงวิดีโอ", onClick = { current?.let { useVideoAudio(it) } }, enabled = current != null && isVideoClip(current) && !busy && !busyImport)
                    ToolChip("⚙ ปรับแต่ง", onClick = { showProps = true }, enabled = current != null)
                }
                Box(Modifier.align(Alignment.TopEnd)) {
                    ToolChip(if (current?.visible == false) "แสดง" else "ซ่อน", onClick = { current?.let { cl -> updateClip(cl.id) { it.copy(visible = !it.visible) } } }, enabled = current != null)
                }
                Box(Modifier.align(Alignment.BottomStart)) {
                    ToolChip(if (previewPlaying) "Ⅱ หยุด" else "▶ เล่น", onClick = { previewPlaying = !previewPlaying }, enabled = images.isNotEmpty() && !busy, highlight = true)
                }
                Row(Modifier.align(Alignment.BottomEnd), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    ToolChip(if (undoCount > 0) "↶ ย้อนกลับ ($undoCount)" else "↶ ย้อนกลับ", enabled = undoCount > 0, onClick = { undoSculpt() })
                    ToolChip(if (redoCount > 0) "↷ ทำซ้ำ ($redoCount)" else "↷ ทำซ้ำ", enabled = redoCount > 0, onClick = { redoSculpt() })
                }
            }

            // Timeline (อยู่ใต้เวทีภาพ เหนือแถวปุ่ม)
            StudioTimeline(
                images = images, layerIds = layerIds, selectedId = selectedId, activeLayerId = activeLayerId,
                playhead = playhead, zoom = timelineZoom, timelineEnd = timelineEnd, playing = previewPlaying,
                overlayLabel = (overlaySticker + " " + overlayText).trim(), overlayStart = overlayStart, overlayDuration = overlayDuration,
                audioName = audioFile?.name, audioStart = audioStart,
                onSeek = { playhead = it },
                onSelect = { selectClip(it) },
                onActiveLane = { activeLayerId = it },
                onNewTopLane = { newTopLane() },
                onOverlayChange = { s, d -> overlayStart = s; overlayDuration = d },
                onAudioStart = { audioStart = it },
                onZoom = { timelineZoom = it.coerceIn(0.25f, 40f) },
                onAddLane = { activeLayerId = newTopLane(); status = "เพิ่มแทร็กใหม่แล้ว" },
                onAddKeyframe = {
                    val cl = current
                    if (cl == null) status = "เลือกคลิปก่อน"
                    else if (playhead < cl.startTime || playhead > clipEnd(cl)) status = "เลื่อนเส้นแดงให้อยู่ในคลิปที่เลือกก่อน"
                    else {
                        val lt = (playhead - cl.startTime).coerceIn(0f, cl.duration)
                        val pose = studioPoseAt(cl, playhead, warpSettings.interpolation, warpSettings.followMotion, warpSettings.motionStrength)
                        val key = StudioKeyframe(lt, pose.x, pose.y, pose.scale, pose.rotation, pose.opacity, pose.sculpt)
                        markUndo(cl.id)
                        updateClip(cl.id) { it.copy(keyframes = (it.keyframes.filterNot { k -> abs(k.time - lt) < 0.05f } + key).sortedBy { k -> k.time }) }
                        status = "บันทึกคีย์เฟรมที่ ${f1(lt)} วินาทีแล้ว"
                    }
                },
                onKeyframeEdit = { id -> markUndo(id) },
                canPasteKeyframe = keyClip != null && keyClip?.first == selectedId,
                onCopyKeyframe = {
                    val cl = current
                    if (cl == null) status = "เลือกคลิปก่อน"
                    else {
                        val lt = (playhead - cl.startTime).coerceIn(0f, cl.duration)
                        val nearest = cl.keyframes.minByOrNull { abs(it.time - lt) }
                        val src = if (nearest != null && abs(nearest.time - lt) <= 0.25f) nearest else {
                            val p = studioPoseAt(cl, playhead, warpSettings.interpolation, warpSettings.followMotion, warpSettings.motionStrength) // ไม่มี ◆ ใกล้เส้นแดง: คัดลอกท่าตรงเส้นแดงตอนนี้
                            StudioKeyframe(lt, p.x, p.y, p.scale, p.rotation, p.opacity, p.sculpt)
                        }
                        keyClip = Pair(cl.id, src)
                        status = "คัดลอกท่าของจุด ${f1(src.time)} วินาทีแล้ว · เลื่อนเส้นแดงไปจุดใหม่ แล้วกด ◆📋 วาง"
                    }
                },
                onPasteKeyframe = {
                    val cl = current
                    val kc = keyClip
                    if (cl == null || kc == null) status = "ยังไม่ได้คัดลอกท่า"
                    else if (kc.first != cl.id) status = "วางได้เฉพาะในคลิปเดิมที่คัดลอกมา"
                    else if (playhead < cl.startTime || playhead > clipEnd(cl)) status = "เลื่อนเส้นแดงให้อยู่ในคลิปที่เลือกก่อน"
                    else {
                        val lt = (playhead - cl.startTime).coerceIn(0f, cl.duration)
                        markUndo(cl.id)
                        updateClip(cl.id) { it.copy(keyframes = (it.keyframes.filterNot { k -> abs(k.time - lt) < 0.05f } + kc.second.copy(time = lt)).sortedBy { k -> k.time }) }
                        status = "วางท่าที่ ${f1(lt)} วินาทีแล้ว"
                    }
                },
                onDeleteKeyframe = {
                    val cl = current
                    if (cl == null) status = "เลือกคลิปก่อน"
                    else {
                        val lt = (playhead - cl.startTime).coerceIn(0f, cl.duration)
                        val nearest = cl.keyframes.minByOrNull { abs(it.time - lt) }
                        if (nearest != null && abs(nearest.time - lt) <= 0.25f) {
                            markUndo(cl.id)
                            updateClip(cl.id) { it.copy(keyframes = it.keyframes - nearest) }
                            status = "ลบคีย์เฟรมแล้ว"
                        } else status = "ไม่มีคีย์เฟรมใกล้เส้นเวลา (ห่างเกิน 0.25 วินาที)"
                    }
                },
                modifier = Modifier.fillMaxWidth(),
            )

            // แถบเครื่องมือ
            Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.CenterVertically) {
                ToolChip("✂ แบ่ง", onClick = { current?.let { splitClip(it.id) } }, enabled = current != null && !busy)
                ToolChip("⧉ ทำซ้ำ", onClick = { current?.let { duplicateClip(it.id) } }, enabled = current != null && !busy)
                Box(Modifier.width(1.dp).height(22.dp).background(c.Line))
                ToolChip(if (sculptMode) "✋ จบการบิด" else "✋ บิดภาพ", highlight = sculptMode, enabled = current != null, onClick = {
                    val wasSculpt = sculptMode
                    sculptMode = !sculptMode
                    pinPlacing = false
                    if (wasSculpt) current?.let { cl -> bakeSculpt(cl.id, playhead) } // จบการบิด = จบจริง: ฝังลงภาพ
                    if (sculptMode) { previewPlaying = false; status = "ลากบนภาพเพื่อดึง/บิด · 2 นิ้ว = ซูม/เลื่อนดูภาพ · ถ้ามี ◆ หลายจุด แต่ละจุดจำท่าบิดของตัวเอง" }
                })
                ToolChip(if (current?.sizeLocked == true) "📏 ปลดล็อกขนาด" else "📏 ล็อกขนาด", highlight = current?.sizeLocked == true, enabled = current != null,
                    onClick = { current?.let { cl -> updateClip(cl.id) { it.copy(sizeLocked = !it.sizeLocked) } } })
                Box(Modifier.width(1.dp).height(22.dp).background(c.Line))
                ToolChip("Ｔ ข้อความ", onClick = { showExtras = true }, enabled = !busy)
                ToolChip("♫ เสียง", onClick = { if (audioFile == null) audioPicker.launch(arrayOf("audio/*")) else showExtras = true }, enabled = !busy)
                Box(Modifier.width(1.dp).height(22.dp).background(c.Line))
                ToolChip("🗑 ลบ", onClick = { current?.let { deleteClip(it.id) } }, enabled = current != null && !busy, danger = true)
                ToolChip("ล้างทั้งหมด", onClick = { showClearConfirm = true }, enabled = images.isNotEmpty() && !busy, danger = true)
            }

            if (sculptMode && current != null) {
                SculptPanel(
                    clip = current, tool = sculptTool, onTool = { sculptTool = it; pinPlacing = false },
                    brushFrac = brushFrac, onBrush = { brushFrac = it },
                    meshRings = meshRings, onRings = { meshRings = it },
                    twistDeg = twistDeg, onTwist = { twistDeg = it },
                    meshCell = meshCell, onCell = { meshCell = it },
                    warpSettings = warpSettings, onWarpSettings = { warpSettings = it },
                    onCreateLoop = { current?.let { createWarpLoop(it.id, warpSettings) } },
                    onAdaptiveMesh = { enabled -> current?.let { cl -> markUndo(cl.id); updateRig(cl.id, true) { r -> r.copy(adaptive = enabled) } } },
                    currentGrid = studioPoseAt(current, playhead, warpSettings.interpolation, warpSettings.followMotion, warpSettings.motionStrength).sculpt,
                    onCaptureLayer = { current?.let { cl ->
                        val g = studioPoseAt(cl, playhead, warpSettings.interpolation, warpSettings.followMotion, warpSettings.motionStrength).sculpt
                        if (g != null && cl.keyframes.none { it.sculpt != null }) {
                            markUndo(cl.id)
                            updateClip(cl.id) { it.copy(sculpt = null, warpLayers = it.warpLayers + WarpLayer(System.nanoTime(), "ชั้นบิด ${it.warpLayers.size + 1}", g)) }
                            status = "แยกท่าบิดเป็นชั้นแล้ว"
                        } else status = "แยกชั้นได้เมื่อคลิปไม่มีคีย์เฟรมท่าบิดแยกตามเวลา"
                    } },
                    onWarpLayers = { layers -> current?.let { cl -> markUndo(cl.id, "warpLayers"); updateClip(cl.id) { it.copy(warpLayers = layers) } } },
                    onPhysics = { physics -> current?.let { cl -> markUndo(cl.id, "physics"); updateClip(cl.id) { it.copy(physics = physics) } } },
                    customPresets = customWarpPresets,
                    onSaveCustomPreset = { name -> customWarpPresets = customWarpPresets + WarpPreset(name.trim().ifBlank { "พรีเซ็ตของฉัน" }, "ชุดค่าที่บันทึกโดยผู้ใช้", warpSettings) },
                    onDeleteCustomPreset = { index -> customWarpPresets = customWarpPresets.filterIndexed { i, _ -> i != index } },
                    lockedMeshPoints = lockedMeshPoints, selectedMeshPoint = selectedMeshPoint,
                    onToggleMeshPointLock = { index -> lockedMeshPoints = if (index in lockedMeshPoints) lockedMeshPoints - index else lockedMeshPoints + index },
                    onClearMeshLocks = { lockedMeshPoints = emptySet() },
                    onResetMeshPoint = { index -> current?.let { cl ->
                        val (dc, dr) = clipGridDims(cl, meshCell, warpSettings.meshCols, warpSettings.meshRows)
                        val base = studioPoseAt(cl, playhead, warpSettings.interpolation, warpSettings.followMotion, warpSettings.motionStrength).sculpt
                            ?: JointPins.zeroGrid(cl.rig, cl.bitmap.width, cl.bitmap.height, dc, dr)
                        markUndo(cl.id); sculptClip(cl.id, Sculpt.resetVertex(base, index), warpSettings.autoKeyframe)
                    } },
                    onCopyWarp = { current?.let { cl -> copiedWarpGrid = studioPoseAt(cl, playhead, warpSettings.interpolation, warpSettings.followMotion, warpSettings.motionStrength).sculpt; status = if (copiedWarpGrid != null) "คัดลอกท่าบิดแล้ว" else "คลิปนี้ยังไม่มีท่าบิด" } },
                    onPasteWarp = { current?.let { cl -> copiedWarpGrid?.let { copied ->
                        val (dc, dr) = clipGridDims(cl, meshCell, warpSettings.meshCols, warpSettings.meshRows)
                        val pasted = Sculpt.resample(copied, dc, dr)
                        markUndo(cl.id); sculptClip(cl.id, pasted, warpSettings.autoKeyframe); status = "วางท่าบิดลงคลิปแล้ว"
                    } } },
                    hasCopiedWarp = copiedWarpGrid != null,
                    onResetSettings = { warpSettings = WarpSettings(); brushFrac = 0.25f; meshRings = 1; twistDeg = 90f; meshCell = null; lockedMeshPoints = emptySet(); selectedMeshPoint = -1 },
                    onApplyGrid = { markUndo(current.id); regridClip(current.id); lockedMeshPoints = emptySet(); selectedMeshPoint = -1 },
                    onReset = { markUndo(current.id); sculptClip(current.id, null) },
                    undoCount = undoCount, onUndo = { undoSculpt() }, redoCount = redoCount, onRedo = { redoSculpt() },
                    showMesh = pinShowMesh, onShowMesh = { pinShowMesh = it },
                    lensOpen = lensOpen, onLens = { lensOpen = !lensOpen },
                    pinContent = {
                        Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(5.dp)) {
                            ToolChip("สร้างโครงร่างตัวละคร", highlight = true, onClick = { current?.let { cl ->
                                markUndo(cl.id, "bodyRig")
                                updateRig(cl.id, true) { BodyRigPresets.humanoid(cl.bitmap.width, cl.bitmap.height) }
                                status = "สร้างหมุดคอ แขน ศอก ข้อมือ สะโพก เข่า และข้อเท้าแล้ว"
                            } })
                            ToolChip("เฉพาะแขน", onClick = { current?.let { cl -> markUndo(cl.id, "bodyRig"); updateRig(cl.id, true) { BodyRigPresets.arms(cl.bitmap.width, cl.bitmap.height) } } })
                            ToolChip("เฉพาะขา", onClick = { current?.let { cl -> markUndo(cl.id, "bodyRig"); updateRig(cl.id, true) { BodyRigPresets.legs(cl.bitmap.width, cl.bitmap.height) } } })
                            ToolChip("ล้างโครงร่าง", enabled = current?.rig?.pins?.isNotEmpty() == true, onClick = { current?.let { cl -> markUndo(cl.id, "bodyRig"); updateRig(cl.id, true) { PinRig() } } })
                        }
                        Text("โครงร่างเป็นตำแหน่งเริ่มต้นโดยประมาณ ควรเลื่อนหมุดให้ตรงกับข้อศอก เข่า และข้อต่อจริงของภาพก่อนเริ่มแอนิเมชัน", color = c.Sub, fontSize = 10.sp)
                        PinSection(
                            clip = current, grid = studioPoseAt(current, playhead, warpSettings.interpolation, warpSettings.followMotion, warpSettings.motionStrength).sculpt,
                            selectedPinId = selectedPinId, placing = pinPlacing, showMesh = pinShowMesh,
                            onPlacing = { on -> pinPlacing = on; if (on) status = "แตะที่ข้อต่อบนภาพ (ลากต่อไปทางส่วนที่จะขยับเพื่อตั้งทิศได้เลย)" },
                            onSelect = { selectedPinId = it },
                            onEdit = { pid, relayout, block -> markUndo(current.id, "pin$pid"); updatePin(current.id, pid, relayout, block) },
                            onAngle = { k, deg -> markUndo(current.id, "angle$k"); setPinAngle(current.id, k, deg) },
                            onDelete = { pid -> markUndo(current.id); deletePin(current.id, pid) },
                            onRig = { relayout, block -> markUndo(current.id, "rig"); updateRig(current.id, relayout, block) },
                            onShowMesh = { pinShowMesh = it },
                            onResetAngles = { markUndo(current.id); resetPinAngles(current.id) },
                        )
                    },
                )
            }

        }
        status?.let { Text(it, color = c.Accent, fontSize = 12.sp) }
    }

    // ───────────── กล่องโต้ตอบ ─────────────
    if (showClearConfirm) {
        AlertDialog(
            onDismissRequest = { showClearConfirm = false },
            containerColor = c.Panel, titleContentColor = c.Ink, textContentColor = c.Sub,
            title = { Text("ล้างทั้งหมด?") },
            text = { Text("คลิปและแทร็กทั้งหมดในโปรเจกต์นี้จะถูกลบ") },
            confirmButton = { TextButton(onClick = {
                previewPlaying = false; images.clear(); layerIds.clear(); layerIds.add(1); activeLayerId = 1; selectedId = -1; playhead = 0f
                showClearConfirm = false
            }) { Text("ล้างทั้งหมด", color = c.Danger) } },
            dismissButton = { TextButton(onClick = { showClearConfirm = false }) { Text("ยกเลิก", color = c.Sub) } },
        )
    }
    if (showProps && current != null) {
        ClipPropertiesDialog(
            clip = current, playhead = playhead, animationMode = animationMode, motionPreset = motionPreset,
            onUpdate = { block -> updateClip(current.id, block) },
            onAnimationMode = { animationMode = it },
            onPreset = { motionPreset = it },
            onStatus = { status = it },
            onDismiss = { showProps = false },
        )
    }
    if (showFpsDialog) {
        FpsDialog(
            fps = videoFps, durationSec = timelineEnd,
            onApply = { f -> videoFps = f; showFpsDialog = false; status = "ตั้งค่าเป็น $f เฟรมต่อวินาทีแล้ว" },
            onDismiss = { showFpsDialog = false },
        )
    }
    if (showVideoSize) {
        VideoSizeDialog(
            width = videoW, height = videoH,
            onApply = { w, h -> videoW = w; videoH = h; showVideoSize = false; status = "ตั้งขนาดวิดีโอเป็น สูง ${Exporter.videoSize(h)} × กว้าง ${Exporter.videoSize(w)} px" },
            onDismiss = { showVideoSize = false },
        )
    }
    if (showExtras) {
        ExtrasDialog(
            overlayText = overlayText, overlaySticker = overlaySticker, audioName = audioFile?.name, audioVolume = audioVolume,
            onText = { overlayText = it }, onSticker = { overlaySticker = it },
            onClearOverlay = { overlaySticker = ""; overlayText = "" },
            onVolume = { audioVolume = it },
            onPickAudio = { audioPicker.launch(arrayOf("audio/*")) },
            onRemoveAudio = { audioFile = null },
            onDismiss = { showExtras = false },
        )
    }
}

// ───────────────────────── Canvas ─────────────────────────

@Composable
private fun StudioCanvas(
    images: List<StudioImage>, playhead: Float, selectedId: Int,
    overlayText: String, overlaySticker: String, overlayStart: Float, overlayDuration: Float,
    onSelect: (Int) -> Unit, onTransform: (Int, Float, Float, Float, Float) -> Unit,
    sculptMode: Boolean, brushFrac: Float, onSculpt: (Int, SculptGrid) -> Unit,
    onWarpLayers: (Int, List<WarpLayer>) -> Unit,
    sculptTool: SculptTool, meshCell: Float?, meshRings: Int, twistDeg: Float, warpSettings: WarpSettings, videoW: Int, videoH: Int,
    lockedMeshPoints: Set<Int>, onMeshPointSelected: (Int) -> Unit,
    pinSelectedId: Int, pinPlacing: Boolean, pinShowMesh: Boolean,
    lensOpen: Boolean, onLensClose: () -> Unit,
    onPinSelect: (Int) -> Unit, onPinAdd: (Int, Float, Float, Float?) -> Unit,
    onPinMove: (Int, Int, Float, Float, Boolean) -> Unit, onPinAngle: (Int, Int, Float) -> Unit,
    onNotice: (String) -> Unit, onUndoMark: (Int) -> Unit,
    modifier: Modifier = Modifier,
) {
    val c = StudioColors
    val density = LocalDensity.current
    val meshPaint = remember(warpSettings.antiAliasing, warpSettings.highQualityPreview) {
        val flags = (if (warpSettings.antiAliasing) Paint.ANTI_ALIAS_FLAG else 0) or
            (if (warpSettings.highQualityPreview) Paint.FILTER_BITMAP_FLAG or Paint.DITHER_FLAG else 0)
        Paint(flags)
    }
    val brushFracNow by rememberUpdatedState(brushFrac)
    val onSculptNow by rememberUpdatedState(onSculpt)
    val onWarpLayersNow by rememberUpdatedState(onWarpLayers)
    val playheadNow by rememberUpdatedState(playhead)
    val selectedNow by rememberUpdatedState(selectedId)
    val imagesNow by rememberUpdatedState(images)
    val onSelectNow by rememberUpdatedState(onSelect)
    val onTransformNow by rememberUpdatedState(onTransform)
    val toolNow by rememberUpdatedState(sculptTool)
    val meshCellNow by rememberUpdatedState(meshCell)
    val ringsNow by rememberUpdatedState(meshRings)
    val twistDegNow by rememberUpdatedState(twistDeg)
    val warpSettingsNow by rememberUpdatedState(warpSettings)
    val lockedMeshPointsNow by rememberUpdatedState(lockedMeshPoints)
    val onMeshPointSelectedNow by rememberUpdatedState(onMeshPointSelected)
    val pinSelectedNow by rememberUpdatedState(pinSelectedId)
    val pinPlacingNow by rememberUpdatedState(pinPlacing)
    val onPinSelectNow by rememberUpdatedState(onPinSelect)
    val onPinAddNow by rememberUpdatedState(onPinAdd)
    val onPinMoveNow by rememberUpdatedState(onPinMove)
    val onPinAngleNow by rememberUpdatedState(onPinAngle)
    val onNoticeNow by rememberUpdatedState(onNotice)
    val onUndoMarkNow by rememberUpdatedState(onUndoMark)
    var pointSet by remember { mutableStateOf<PointSet?>(null) } // จุดบิดที่วางเองในเซสชันนี้
    var session by remember { mutableStateOf<SculptSession?>(null) } // ตารางใหม่ของเซสชันบิดภาพนี้ (null = ยังไม่ได้บิด แสดงตารางเปล่า)
    var pinPreview by remember { mutableStateOf<List<Float>?>(null) } // เส้นทิศขณะลากวางหมุด: [เริ่ม x, เริ่ม y, ปลาย x, ปลาย y] (พิกเซล bitmap)
    // คลิปวิดีโอ: เธรดอ่านเฟรมตามเวลาของเส้นแดง (ข้ามเฟรมที่ไม่ทัน ไม่ค้างตอนเล่น) เก็บเฟรมล่าสุดของแต่ละคลิป
    val videoReaders = remember { HashMap<String, VideoReader>() }
    val videoFrames = remember { mutableStateMapOf<Int, Pair<Int, Bitmap>>() } // id คลิป -> (ตราเวลา, เฟรมล่าสุด)
    DisposableEffect(Unit) { onDispose { synchronized(videoReaders) { videoReaders.values.forEach { it.close() }; videoReaders.clear() } } }
    LaunchedEffect(Unit) {
        while (true) {
            var worked = false
            val t = playheadNow
            for (vc in imagesNow) {
                if (!isVideoClip(vc) || !isActiveAt(vc, t)) continue
                val local = videoLocalTime(vc, t)
                val stamp = (local * 20f).roundToInt() * 31 + vc.file.absolutePath.hashCode()
                if (videoFrames[vc.id]?.first == stamp) continue
                val k = minOf(1f, VideoFrames.PREVIEW_SIDE.toFloat() / maxOf(vc.bitmap.width, vc.bitmap.height))
                val fw = maxOf(1, (vc.bitmap.width * k).roundToInt())
                val fh = maxOf(1, (vc.bitmap.height * k).roundToInt())
                val bmp = withContext(Dispatchers.IO) {
                    runCatching {
                        val rd = synchronized(videoReaders) { videoReaders.getOrPut(vc.file.absolutePath) { VideoReader(vc.file, vc.videoLength) } }
                        rd.frame(local, fw, fh, exact = true)
                    }.getOrNull()
                }
                videoFrames[vc.id] = stamp to (bmp ?: videoFrames[vc.id]?.second ?: vc.bitmap)
                worked = true
            }
            delay(if (worked) 8L else 30L)
        }
    }
    val downPos = remember { floatArrayOf(0f, 0f) } // ตำแหน่งที่นิ้ววางลงจริง (detectDragGestures ส่งตำแหน่งหลังพ้นระยะ slop มาให้ ใช้เลือกจุด Mesh Warp ไม่แม่น)
    var sculptRing by remember { mutableStateOf<Triple<Float, Float, Float>?>(null) } // วงรัศมีพู่กัน (กลาง x, y และรัศมี เป็นพิกเซล bitmap) ขณะลาก
    var meshPick by remember { mutableStateOf<Pair<Int, Int>?>(null) } // จุดตาข่ายที่ Mesh Warp กำลังลาก (i, j)
    var maskStrokeLayer by remember { mutableStateOf<WarpLayer?>(null) }
    var maskStrokeLayers by remember { mutableStateOf<List<WarpLayer>?>(null) }
    var maskWorking by remember { mutableStateOf<FloatArray?>(null) }
    var maskStrokeId by remember { mutableIntStateOf(-1) }
    // ซูมดูภาพในโหมดบิดภาพ (ซูมที่จอเท่านั้น ไม่แตะขนาด/ตำแหน่งของคลิป)
    var viewZoom by remember { mutableFloatStateOf(1f) }
    var viewPan by remember { mutableStateOf(Offset.Zero) }
    val zoomed by remember { derivedStateOf { viewZoom > 1.01f } }
    // แว่นขยาย: lensPt = ตำแหน่งที่กดล่าสุด (พิกัดในกรอบเฟรม) · lensPos = ตำแหน่งกล่องแว่นบนจอ (ลากย้ายได้) · lensMag = กำลังขยาย
    var lensPt by remember { mutableStateOf<Offset?>(null) }
    var lensPos by remember { mutableStateOf(Offset(24f, 24f)) }
    var lensMag by remember { mutableFloatStateOf(3f) }
    val onLensCloseNow by rememberUpdatedState(onLensClose)
    LaunchedEffect(sculptMode) { session = null; pointSet = null; if (!sculptMode) { viewZoom = 1f; viewPan = Offset.Zero } } // เข้า/ออกโหมดบิดภาพ = ตารางใหม่ทุกครั้ง
    LaunchedEffect(sculptTool, selectedId) { session = null; pointSet = null } // เปลี่ยนเครื่องมือ/คลิป = สร้างเซสชันใหม่ ไม่ใช้ตารางเก่าที่อาจไม่ตรงกับชั้นบิด

    BoxWithConstraints(modifier, contentAlignment = Alignment.Center) {
        // กรอบเฟรม = สัดส่วนเดียวกับวิดีโอที่ส่งออก (ตั้งขนาดที่ปุ่ม "แก้ไข") ส่วนที่เกินเฟรมจะไม่ปรากฏในวิดีโอ
        val (frameWW, frameWH) = Exporter.frameWorldSize(videoW, videoH) // ขนาดเฟรมหน่วยโลก (กว้าง, สูง) ด้านสั้น = 600
        val aspect = frameWW / frameWH
        val boxW: Dp
        val boxH: Dp
        if (maxWidth / maxHeight > aspect) { boxH = maxHeight; boxW = maxHeight * aspect } else { boxW = maxWidth; boxH = maxWidth / aspect }
        val boxWPx = with(density) { boxW.toPx() }
        val boxHPx = with(density) { boxH.toPx() }
        val unit = boxWPx / frameWW // พิกเซลต่อหน่วยโลก
        val sqPx = Exporter.WORLD_WINDOW * unit // ช่องจัตุรัส 600 หน่วยโลกที่ใช้ "พอดีเฟรม" ของภาพ (เหมือนตอนส่งออก)
        val sqDp = with(density) { sqPx.toDp() }
        val unitNow by rememberUpdatedState(unit)
        val boxWNow by rememberUpdatedState(boxWPx)
        val boxHNow by rememberUpdatedState(boxHPx)

        val stageBody: @Composable (() -> Float) -> Unit = { zf ->
            // ภาพแสดงเฉพาะช่วงเวลาของคลิป และซ้อนกันตามลำดับแทร็ก
            stackOrder(images).forEach { layer ->
                if (isActiveAt(layer, playhead)) {
                    key(layer.id) {
                        val pose = studioPoseAt(layer, playhead, warpSettings.interpolation, warpSettings.followMotion, warpSettings.motionStrength)
                        val g = renderGrid(layer, pose.sculpt, playhead - layer.startTime)
                        val shown = if (isVideoClip(layer)) videoFrames[layer.id]?.second ?: layer.bitmap else layer.bitmap
                        if (g == null || g.isZero()) {
                            Image(
                                shown.asImageBitmap(), null,
                                Modifier.requiredSize(sqDp).graphicsLayer(
                                    translationX = pose.x * unit, translationY = pose.y * unit,
                                    scaleX = pose.scale, scaleY = pose.scale, rotationZ = pose.rotation,
                                    alpha = pose.opacity.coerceIn(0f, 1f),
                                ),
                                contentScale = ContentScale.Fit,
                            )
                        } else {
                            // คลิปที่บิดแล้ว: วาดผ่านตาข่าย ตำแหน่ง/ขนาดเดียวกับ Image ปกติ (พอดีเฟรมกึ่งกลาง)
                            androidx.compose.foundation.Canvas(
                                Modifier.requiredSize(sqDp).graphicsLayer(
                                    translationX = pose.x * unit, translationY = pose.y * unit,
                                    scaleX = pose.scale, scaleY = pose.scale, rotationZ = pose.rotation,
                                    alpha = pose.opacity.coerceIn(0f, 1f),
                                ),
                            ) {
                                val bw = layer.bitmap.width
                                val bh = layer.bitmap.height
                                val fitPx = minOf(size.width / bw, size.height / bh)
                                val nc = drawContext.canvas.nativeCanvas
                                nc.save()
                                nc.translate(size.width / 2f, size.height / 2f)
                                nc.scale(fitPx, fitPx)
                                nc.translate(-bw / 2f, -bh / 2f)
                                Sculpt.drawMesh(nc, shown, g, meshPaint, bw, bh) // เฟรมพรีวิววิดีโอถูกย่อ (≤640) แต่ตาข่ายอยู่ในพิกัดภาพปก (bw×bh)
                                nc.restore()
                            }
                        }
                    }
                }
            }
            // กรอบเลือก + จุดหมุน (เฉพาะคลิปที่เลือกและกำลังแสดงอยู่ ณ เวลานี้)
            val sel = images.firstOrNull { it.id == selectedId }
            if (sel != null && isActiveAt(sel, playhead)) {
                val pose = studioPoseAt(sel, playhead, warpSettings.interpolation, warpSettings.followMotion, warpSettings.motionStrength)
                val fitPx = minOf(sqPx / sel.bitmap.width, sqPx / sel.bitmap.height)
                val frameW = with(density) { (sel.bitmap.width * fitPx).toDp() }
                val frameH = with(density) { (sel.bitmap.height * fitPx).toDp() }
                val frameColor = if (sel.locked) c.Warn else c.Accent
                Box(
                    Modifier.requiredSize(frameW, frameH).graphicsLayer(
                        translationX = pose.x * unit, translationY = pose.y * unit,
                        scaleX = pose.scale, scaleY = pose.scale, rotationZ = pose.rotation,
                    ).drawWithContent { drawContent(); drawRect(frameColor, style = Stroke(1.5.dp.toPx() / zf().coerceAtLeast(1f))) }, // เส้นกรอบคงความหนาบนจอเมื่อซูม
                ) {
                    if (sel.locked) {
                        Text("🔒", fontSize = 14.sp, modifier = Modifier.align(Alignment.TopStart).padding(4.dp))
                    } else if (!sculptMode) {
                        Box(
                            Modifier.align(Alignment.TopCenter).offset(y = 6.dp).size(30.dp).clip(CircleShape)
                                .background(c.AccentDim).border(1.dp, c.Accent, CircleShape)
                                .pointerInput(sel.id) {
                                    detectDragGestures { change, drag ->
                                        change.consume()
                                        onTransformNow(sel.id, 0f, 0f, 1f, drag.x * 0.6f)
                                    }
                                },
                            contentAlignment = Alignment.Center,
                        ) { Text("↻", color = Color.White, fontSize = 15.sp) }
                    }
                    if (sculptMode && !sel.locked) { // เส้นตาข่ายให้เห็นว่าบิดอยู่ตรงไหน
                        androidx.compose.foundation.Canvas(Modifier.fillMaxSize()) {
                            val z = zf().coerceAtLeast(1f) // ซูมจอ: ชดเชยให้เส้น/จุดไม่หนาขึ้นตามการซูม
                            val bw = sel.bitmap.width
                            val bh = sel.bitmap.height
                            val (dc, dr) = clipGridDims(sel, meshCell, warpSettings.meshCols, warpSettings.meshRows)
                            val pinTool = sculptTool == SculptTool.PIN
                            val g0 = pose.sculpt ?: JointPins.zeroGrid(sel.rig, bw, bh, dc, dr) // ท่าของคลิป (ใช้วาดหมุดด้วย)
                            val g = if (pinTool) {
                                renderGrid(sel, g0, playheadNow - sel.startTime) ?: g0 // หมุดข้อต่อ: เส้นตาข่ายจริงตามที่เห็น (งอตามหมุดแล้ว ถี่ตามหมุด)
                            } else {
                                validSession(session, sel, pose)?.lat ?: SculptGrid.zero(dc, dr) // ดึง/Mesh Warp/Twist: ตารางใหม่ของการบิดครั้งนี้
                            }
                            val v = Sculpt.verts(bw, bh, g)
                            val col = if (!pinShowMesh) Color.Transparent else Color(if (pinTool) 0x66FFFFFF else 0x99FFFFFF)
                            val rowW = g.cols + 1
                            for (j in 0..g.rows) for (i in 0 until g.cols) {
                                val a = j * rowW + i
                                val b = a + 1
                                drawLine(col, Offset(v[2 * a] * fitPx, v[2 * a + 1] * fitPx), Offset(v[2 * b] * fitPx, v[2 * b + 1] * fitPx), 1f / z)
                            }
                            for (i in 0..g.cols) for (j in 0 until g.rows) {
                                val a = j * rowW + i
                                val b = a + rowW
                                drawLine(col, Offset(v[2 * a] * fitPx, v[2 * a + 1] * fitPx), Offset(v[2 * b] * fitPx, v[2 * b + 1] * fitPx), 1f / z)
                            }
                            if (sculptTool == SculptTool.MESH) { // จุดควบคุมให้แตะลาก (จุดที่กำลังลากเป็นสีส้ม)
                                var n = 0
                                for (j in 0..g.rows) for (i in 0..g.cols) {
                                    val picked = meshPick?.let { it.first == i && it.second == j } == true
                                    drawCircle(if (picked) c.Warn else c.Accent, (if (picked) 7f else 4f) / z, Offset(v[2 * n] * fitPx, v[2 * n + 1] * fitPx))
                                    n++
                                }
                            }
                            sculptRing?.let { (rx, ry, rr) ->
                                // แสดงขอบเขตหัวพู่กันตามรูปทรง/สเกล/มุมจริงที่ใช้คำนวณการบิด
                                val cx = rx * fitPx
                                val cy = ry * fitPx
                                val baseR = rr * fitPx
                                val rxBrush = baseR * (warpSettings.scaleX / 100f)
                                val ryBrush = baseR * (warpSettings.scaleY / 100f)
                                val native = drawContext.canvas.nativeCanvas
                                val previewPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                                    color = android.graphics.Color.rgb(255, 170, 45)
                                    style = Paint.Style.STROKE
                                    strokeWidth = 2f / z
                                }
                                native.save()
                                native.rotate(warpSettings.angleDeg, cx, cy)
                                when (warpSettings.brushShape) {
                                    "วงรี" -> native.drawOval(android.graphics.RectF(cx - rxBrush * 1.5f, cy - ryBrush * 0.75f, cx + rxBrush * 1.5f, cy + ryBrush * 0.75f), previewPaint)
                                    "สี่เหลี่ยม" -> native.drawRect(cx - rxBrush, cy - ryBrush, cx + rxBrush, cy + ryBrush, previewPaint)
                                    "เพชร" -> native.drawPath(android.graphics.Path().apply {
                                        moveTo(cx, cy - ryBrush); lineTo(cx + rxBrush, cy); lineTo(cx, cy + ryBrush); lineTo(cx - rxBrush, cy); close()
                                    }, previewPaint)
                                    "เส้นแนวนอน" -> native.drawRect(cx - rxBrush, cy - ryBrush * 0.4f, cx + rxBrush, cy + ryBrush * 0.4f, previewPaint)
                                    "เส้นแนวตั้ง" -> native.drawRect(cx - rxBrush * 0.4f, cy - ryBrush, cx + rxBrush * 0.4f, cy + ryBrush, previewPaint)
                                    else -> native.drawOval(android.graphics.RectF(cx - rxBrush, cy - ryBrush, cx + rxBrush, cy + ryBrush), previewPaint)
                                }
                                native.restore()
                            }
                            if (sculptTool == SculptTool.POINT) { // จุดบิดที่วางเอง (วงแหวน)
                                val ps = pointSet?.takeIf { it.clipId == sel.id }
                                if (ps != null) {
                                    val u = 1f / (pose.scale.coerceAtLeast(0.05f) * z)
                                    for (q in 0 until ps.xy.size / 3) {
                                        val ctr = Offset(ps.xy[3 * q] * fitPx, ps.xy[3 * q + 1] * fitPx)
                                        drawCircle(c.Warn.copy(alpha = 0.55f), ps.xy[3 * q + 2] * fitPx, ctr, style = Stroke(width = 2f * u)) // ขอบเขตวงกลมของห่วง
                                        drawCircle(Color.White, 14f * u, ctr, style = Stroke(width = 4.5f * u))
                                        drawCircle(c.Warn, 14f * u, ctr, style = Stroke(width = 2.5f * u))
                                        drawCircle(c.Warn, 3.5f * u, ctr)
                                    }
                                }
                            }
                            if (pinTool) drawPinGizmos(sel, g0, bw, bh, fitPx, 1f / (pose.scale.coerceAtLeast(0.05f) * z), pinSelectedId, pinPreview)
                        }
                    }
                }
            }
        }

        Box(
            Modifier.size(boxW, boxH).clip(RoundedCornerShape(12.dp)).background(Color.Black)
                .border(1.dp, c.Line, RoundedCornerShape(12.dp))
                .pointerInput(sculptMode) { // โหมดบิดภาพ: 2 นิ้ว = ซูม/เลื่อนดูภาพ (ดักก่อนลูก เหมือนหน้าใส่ภาพกระดูก)
                    if (sculptMode) {
                        awaitEachGesture {
                            awaitFirstDown(requireUnconsumed = false, pass = PointerEventPass.Initial)
                            do {
                                val event = awaitPointerEvent(PointerEventPass.Initial)
                                if (event.changes.count { it.pressed } >= 2) {
                                    val zoom = event.calculateZoom()
                                    val pan = event.calculatePan()
                                    val cen = event.calculateCentroid() - Offset(size.width / 2f, size.height / 2f)
                                    val c0 = cen - pan
                                    val k0 = viewZoom
                                    val k1 = (k0 * zoom).coerceIn(1f, 40f)
                                    val ratio = k1 / k0
                                    val maxX = size.width * (k1 - 1f) / 2f // ไม่ให้เลื่อนจนขอบภาพเข้ามาในจอ (ตำแหน่งนิ้วยังอยู่ในกรอบเสมอ)
                                    val maxY = size.height * (k1 - 1f) / 2f
                                    viewPan = Offset(
                                        (cen.x - (c0.x - viewPan.x) * ratio).coerceIn(-maxX, maxX),
                                        (cen.y - (c0.y - viewPan.y) * ratio).coerceIn(-maxY, maxY),
                                    )
                                    viewZoom = k1
                                    event.changes.forEach { if (it.positionChanged()) it.consume() }
                                }
                            } while (event.changes.any { it.pressed })
                        }
                    }
                }
                .graphicsLayer { // ซูมจอ (ตัวรับสัมผัสด้านล่างได้ตำแหน่งในพิกัดก่อนซูม จึงไม่ต้องแก้ตัวคำนวณบิดภาพ)
                    if (sculptMode) { scaleX = viewZoom; scaleY = viewZoom; translationX = viewPan.x; translationY = viewPan.y }
                }
                .pointerInput(Unit) {
                    detectTapGestures { off ->
                        val wx = (off.x - boxWNow / 2f) / unitNow
                        val wy = (off.y - boxHNow / 2f) / unitNow
                        val t = playheadNow
                        val hit = stackOrder(imagesNow).asReversed().firstOrNull { isActiveAt(it, t) && hitsClip(it, studioPoseAt(it, t, warpSettings.interpolation, warpSettings.followMotion, warpSettings.motionStrength), wx, wy) }
                        onSelectNow(hit?.id ?: -1)
                    }
                }
                .pointerInput(Unit) {
                    awaitEachGesture {
                        val down = awaitFirstDown(requireUnconsumed = false)
                        downPos[0] = down.position.x; downPos[1] = down.position.y
                        lensPt = down.position // แว่นขยายดูตำแหน่งที่กดล่าสุด ตามนิ้วตอนลาก
                        while (true) {
                            val ev = awaitPointerEvent()
                            val ch = ev.changes.firstOrNull { it.id == down.id } ?: break
                            if (!ch.pressed) break
                            lensPt = ch.position
                        }
                    }
                }
                .pointerInput(sculptMode) {
                    if (sculptMode) {
                        // โหมดบิดภาพ: นิ้วเดียวลาก (คำนวณจากท่าตอนวางนิ้วทุกครั้ง ไม่สะสมเพี้ยน)
                        //   ดึง = ดึงตาข่ายรอบนิ้ว · Mesh Warp = ลากจุดตาข่ายที่ใกล้นิ้ว · Twist = บิดวนรอบจุดที่แตะ (ลากซ้าย/ขวากำหนดมุม)
                        var sStart: SculptGrid? = null
                        var sSess: SculptSession? = null
                        var sBegan = false
                        var sWts: FloatArray? = null
                        var sStep = 0f; var sAccX = 0f; var sAccY = 0f; var sTargetX = 0f; var sTargetY = 0f; var sId = -1
                        var twCx = 0f; var twCy = 0f; var twR = 1f; var twLimit = 0f
                        // ระยะลากบนจอ (px) -> ระยะในพิกัด bitmap ของคลิป (หักมุมหมุน/ขนาดของคลิป)
                        fun toBitmapDelta(clip: StudioImage, dx: Float, dy: Float): Pair<Float, Float> {
                            val pose = studioPoseAt(clip, playheadNow, warpSettings.interpolation, warpSettings.followMotion, warpSettings.motionStrength)
                            val fit = fitScale(clip.bitmap.width, clip.bitmap.height)
                            val rad = Math.toRadians(pose.rotation.toDouble())
                            val cs = kotlin.math.cos(rad).toFloat()
                            val sn = kotlin.math.sin(rad).toFloat()
                            val sc = pose.scale.coerceAtLeast(0.05f)
                            val wdx = dx / unitNow
                            val wdy = dy / unitNow
                            return Pair(((wdx * cs + wdy * sn) / sc) / fit, ((-wdx * sn + wdy * cs) / sc) / fit)
                        }
                        detectDragGestures(
                            onDragStart = { off ->
                                sStart = null; sSess = null; sBegan = false; sculptRing = null; meshPick = null
                                maskStrokeLayer = null; maskStrokeLayers = null; maskWorking = null; maskStrokeId = -1
                                val clip = imagesNow.firstOrNull { it.id == selectedNow }
                                if (clip != null && !clip.locked && isActiveAt(clip, playheadNow)) {
                                    val tool = toolNow
                                    val pose = studioPoseAt(clip, playheadNow, warpSettings.interpolation, warpSettings.followMotion, warpSettings.motionStrength)
                                    val bw = clip.bitmap.width; val bh = clip.bitmap.height
                                    // ตารางใหม่: ใช้เซสชันเดิมถ้าท่ายังเป็นท่าที่เพิ่งบิดเอง ไม่งั้นเริ่มตารางเปล่าทับท่าที่เห็นอยู่ (หมุดงออยู่ก็บิดได้)
                                    val sess = validSession(session, clip, pose) ?: run {
                                        val (dc, dr) = clipGridDims(clip, meshCellNow, warpSettingsNow.meshCols, warpSettingsNow.meshRows)
                                        val base = pose.sculpt ?: JointPins.zeroGrid(clip.rig, bw, bh, dc, dr)
                                        val e0 = renderGrid(clip, base, playheadNow - clip.startTime) ?: base
                                        SculptSession(clip.id, pose.sculpt, e0, base.pinAngles, SculptGrid.zero(e0.cols, e0.rows), pose.sculpt)
                                    }
                                    session = sess
                                    val g0 = sess.lat // เครื่องมือทำงานกับตารางใหม่ (เว้นระยะเท่ากัน)
                                    // Mesh Warp / Twist ใช้ตำแหน่งที่นิ้ววางจริง · ดึง ใช้ตำแหน่งเดิม (หลังพ้น slop) เหมือนเดิม
                                    val p = if (tool == SculptTool.GRAB) off else Offset(downPos[0], downPos[1])
                                    val (bpx, bpy) = worldToBitmap(clip, pose, (p.x - boxWNow / 2f) / unitNow, (p.y - boxHNow / 2f) / unitNow)
                                    val cellMax = Sculpt.cellMaxPx(bw, bh, g0)
                                    val cellMin = Sculpt.cellMinPx(bw, bh, g0)
                                    val radius = brushFracNow * maxOf(bw, bh) // ดึง: รัศมีเดิมเป๊ะ (ไม่เปลี่ยนพฤติกรรมเดิม)
                                    sAccX = 0f; sAccY = 0f; sTargetX = 0f; sTargetY = 0f; sId = clip.id
                                    when (tool) {
                                        SculptTool.GRAB -> {
                                            sWts = Sculpt.brushWeights(bw, bh, g0, bpx, bpy, radius, 0f, 0f, 0f, warpSettingsNow)
                                            sStep = Sculpt.maxStep(radius, 0f)
                                            sculptRing = Triple(bpx, bpy, radius)
                                            sStart = g0; sSess = sess
                                        }
                                        SculptTool.MESH -> {
                                            val hit = Sculpt.nearestVertex(bw, bh, g0, bpx, bpy)
                                            if (hit.dist <= 1.5f * cellMax) { // แตะไกลจากทุกจุดเกินไป = ไม่ทำอะไร
                                                val vertexIndex = hit.j * (g0.cols + 1) + hit.i
                                                onMeshPointSelectedNow(vertexIndex)
                                                sWts = Sculpt.ringWeights(g0, hit.i, hit.j, ringsNow, warpSettingsNow)
                                                sStep = Sculpt.maxStepRings(cellMin, ringsNow)
                                                meshPick = Pair(hit.i, hit.j)
                                                // ชดเชยระยะ slop ที่นิ้วเลื่อนไปก่อน onDragStart ให้จุดอยู่ใต้นิ้ว
                                                val (ix, iy) = toBitmapDelta(clip, off.x - p.x, off.y - p.y)
                                                sAccX = ix; sAccY = iy; sTargetX = ix; sTargetY = iy
                                                sStart = g0; sSess = sess
                                            }
                                        }
                                        SculptTool.TWIST -> {
                                            // รัศมีต่ำสุด 2 ช่อง: เล็กกว่านั้นแทบไม่มีจุดตาข่ายอยู่ในพู่กัน (ไม่ขยับ)
                                            twCx = bpx; twCy = bpy; twR = maxOf(radius, 2f * cellMax)
                                            twLimit = Sculpt.maxTwist(twR, cellMax)
                                            sculptRing = Triple(bpx, bpy, twR)
                                            sStart = g0; sSess = sess
                                        }
                                        SculptTool.PINCH, SculptTool.BULGE, SculptTool.SPIRAL, SculptTool.WAVE,
                                        SculptTool.SHEAR, SculptTool.PERSPECTIVE, SculptTool.RIPPLE, SculptTool.PUSH,
                                        SculptTool.INFLATE, SculptTool.DEFLATE, SculptTool.SMOOTH, SculptTool.FLATTEN,
                                        SculptTool.CREASE, SculptTool.GRAVITY, SculptTool.ELASTIC, SculptTool.MAGNET,
                                        SculptTool.ARC_BEND, SculptTool.TAPER, SculptTool.RIGID_TRANSFORM, SculptTool.RIBBON_BEND,
                                        SculptTool.EDGE_SLIDE, SculptTool.CONTOUR_FLOW, SculptTool.FAN_DEFORM, SculptTool.ORIGAMI_FOLD,
                                        SculptTool.TOPOLOGY_REMAP, SculptTool.BOUNDARY_TENSION, SculptTool.VISCOUS_MELT,
                                        SculptTool.SEGMENT_OFFSET, SculptTool.ASYMMETRIC_WARP, SculptTool.DIRECTIONAL_COMPRESS,
                                        SculptTool.SURFACE_ROLL -> {
                                            twCx = bpx; twCy = bpy; twR = radius.coerceAtLeast(2f * cellMax)
                                            sculptRing = Triple(bpx, bpy, twR)
                                            sStart = g0; sSess = sess
                                        }
                                        SculptTool.MASK -> {
                                            val layer = clip.warpLayers.lastOrNull { it.enabled && !it.locked }
                                            if (layer == null) onNoticeNow("สร้างชั้นบิดก่อน แล้วจึงใช้พู่กันระบายหน้ากากได้")
                                            else {
                                                val baseMask = layer.mask ?: WarpMask.full(layer.grid.cols, layer.grid.rows)
                                                maskStrokeLayer = layer
                                                maskStrokeLayers = clip.warpLayers
                                                maskWorking = baseMask.weights.copyOf()
                                                maskStrokeId = clip.id
                                                twCx = bpx; twCy = bpy; twR = maxOf(radius, 2f * cellMax)
                                                sculptRing = Triple(bpx, bpy, twR)
                                                onUndoMarkNow(clip.id)
                                            }
                                        }
                                        SculptTool.PIN, SculptTool.POINT -> { /* หมุดข้อต่อ/จุดบิดมีตัวจัดการท่าทางของตัวเอง (ด้านล่าง) */ }
                                    }
                                }
                            },
                            onDragEnd = { sStart = null; sSess = null; sculptRing = null; meshPick = null; maskStrokeLayer = null; maskStrokeLayers = null; maskWorking = null; maskStrokeId = -1 },
                            onDragCancel = { sStart = null; sSess = null; sculptRing = null; meshPick = null; maskStrokeLayer = null; maskStrokeLayers = null; maskWorking = null; maskStrokeId = -1 },
                            onDrag = { change, drag ->
                                val st = sStart
                                val ss = sSess
                                val clip = imagesNow.firstOrNull { it.id == sId }
                                val maskLayer = maskStrokeLayer
                                val maskWorkingNow = maskWorking
                                if (toolNow == SculptTool.MASK && maskLayer != null && clip != null && maskWorkingNow != null) {
                                    change.consume()
                                    val (ax, ay) = toBitmapDelta(clip, drag.x, drag.y)
                                    val oldX = twCx + sAccX; val oldY = twCy + sAccY
                                    sTargetX += ax; sTargetY += ay
                                    val stabilizer = (warpSettingsNow.stabilizer / 100f).coerceIn(0f, 1f)
                                    val response = 1f - stabilizer * 0.95f
                                    sAccX += (sTargetX - sAccX) * response
                                    sAccY += (sTargetY - sAccY) * response
                                    val newX = twCx + sAccX; val newY = twCy + sAccY
                                    val radius = twR.coerceAtLeast(1f)
                                    sculptRing = Triple(newX, newY, radius)
                                    val distance = kotlin.math.hypot(newX - oldX, newY - oldY)
                                    val spacingRatio = abs(warpSettingsNow.spacing / 100f)
                                    val sampleStep = (radius * spacingRatio).coerceAtLeast(1f)
                                    val samples = (kotlin.math.ceil(distance / sampleStep).toInt()).coerceIn(1, 256)
                                    var painted = WarpMask(maskLayer.grid.cols, maskLayer.grid.rows, maskWorkingNow.copyOf())
                                    val grid = maskLayer.grid
                                    val brushAmount = (warpSettingsNow.pressure / 100f).coerceIn(0f,1f) *
                                        (warpSettingsNow.flow / 100f).coerceIn(0f,1f) *
                                        (warpSettingsNow.density / 100f).coerceIn(0f,1f) *
                                        (warpSettingsNow.opacity / 100f).coerceIn(0f,1f)
                                    for (sample in 1..samples) {
                                        val f = sample.toFloat() / samples
                                        val cx = oldX + (newX - oldX) * f
                                        val cy = oldY + (newY - oldY) * f
                                        painted = painted.paint(grid, clip.bitmap.width, clip.bitmap.height, cx, cy, radius, brushAmount, warpSettingsNow.invert, warpSettingsNow)
                                    }
                                    maskWorking = painted.weights.copyOf()
                                    val updatedLayer = maskLayer.copy(mask = painted)
                                    val originalLayers = maskStrokeLayers ?: clip.warpLayers
                                    val updatedLayers = originalLayers.map { if (it.id == updatedLayer.id) updatedLayer else it }
                                    onWarpLayersNow(maskStrokeId, updatedLayers)
                                } else if (st != null && ss != null && clip != null) {
                                    change.consume()
                                    val (ax, ay) = toBitmapDelta(clip, drag.x, drag.y)
                                    sTargetX += ax; sTargetY += ay
                                    val stabilizer = (warpSettingsNow.stabilizer / 100f).coerceIn(0f, 1f)
                                    val response = 1f - stabilizer * 0.95f
                                    sAccX += (sTargetX - sAccX) * response
                                    sAccY += (sTargetY - sAccY) * response
                                    val bw = clip.bitmap.width
                                    val bh = clip.bitmap.height
                                    val advancedMode = when (toolNow) {
                                        SculptTool.PINCH -> AdvancedWarpMode.PINCH
                                        SculptTool.BULGE -> AdvancedWarpMode.BULGE
                                        SculptTool.SPIRAL -> AdvancedWarpMode.SPIRAL
                                        SculptTool.WAVE -> AdvancedWarpMode.WAVE
                                        SculptTool.SHEAR -> AdvancedWarpMode.SHEAR
                                        SculptTool.PERSPECTIVE -> AdvancedWarpMode.PERSPECTIVE
                                        SculptTool.RIPPLE -> AdvancedWarpMode.RIPPLE
                                        SculptTool.PUSH -> AdvancedWarpMode.PUSH
                                        SculptTool.INFLATE -> AdvancedWarpMode.INFLATE
                                        SculptTool.DEFLATE -> AdvancedWarpMode.DEFLATE
                                        SculptTool.SMOOTH -> AdvancedWarpMode.SMOOTH
                                        SculptTool.FLATTEN -> AdvancedWarpMode.FLATTEN
                                        SculptTool.CREASE -> AdvancedWarpMode.CREASE
                                        SculptTool.GRAVITY -> AdvancedWarpMode.GRAVITY
                                        SculptTool.ELASTIC -> AdvancedWarpMode.ELASTIC
                                        SculptTool.MAGNET -> AdvancedWarpMode.MAGNET
                                        SculptTool.ARC_BEND -> AdvancedWarpMode.ARC_BEND
                                        SculptTool.TAPER -> AdvancedWarpMode.TAPER
                                        SculptTool.RIGID_TRANSFORM -> AdvancedWarpMode.RIGID_TRANSFORM
                                        SculptTool.RIBBON_BEND -> AdvancedWarpMode.RIBBON_BEND
                                        SculptTool.EDGE_SLIDE -> AdvancedWarpMode.EDGE_SLIDE
                                        SculptTool.CONTOUR_FLOW -> AdvancedWarpMode.CONTOUR_FLOW
                                        SculptTool.FAN_DEFORM -> AdvancedWarpMode.FAN_DEFORM
                                        SculptTool.ORIGAMI_FOLD -> AdvancedWarpMode.ORIGAMI_FOLD
                                        SculptTool.TOPOLOGY_REMAP -> AdvancedWarpMode.TOPOLOGY_REMAP
                                        SculptTool.BOUNDARY_TENSION -> AdvancedWarpMode.BOUNDARY_TENSION
                                        SculptTool.VISCOUS_MELT -> AdvancedWarpMode.VISCOUS_MELT
                                        SculptTool.SEGMENT_OFFSET -> AdvancedWarpMode.SEGMENT_OFFSET
                                        SculptTool.ASYMMETRIC_WARP -> AdvancedWarpMode.ASYMMETRIC_WARP
                                        SculptTool.DIRECTIONAL_COMPRESS -> AdvancedWarpMode.DIRECTIONAL_COMPRESS
                                        SculptTool.SURFACE_ROLL -> AdvancedWarpMode.SURFACE_ROLL
                                        else -> null
                                    }
                                    val ng: SculptGrid? = when {
                                        toolNow == SculptTool.TWIST -> {
                                            val frac = (sAccX / twR).coerceIn(-1f, 1f)
                                            val ang = frac * minOf(Math.toRadians(twistDegNow.toDouble()).toFloat(), twLimit)
                                            Sculpt.applyTwist(bw, bh, st, twCx, twCy, twR, ang, warpSettingsNow)
                                        }
                                        advancedMode != null -> {
                                            val settings = warpSettingsNow
                                            Sculpt.applyAdvancedWarp(bw, bh, st, twCx, twCy, twR, advancedMode, sAccX, sAccY, settings, lockedMeshPointsNow)
                                        }
                                        else -> {
                                            val w = sWts
                                            if (w != null) Sculpt.smoothGrid(
                                                Sculpt.applyGrab(
                                                    st, w, sAccX, sAccY, sStep,
                                                    lockedIndices = lockedMeshPointsNow, settings = warpSettingsNow,
                                                    width = bw, height = bh, radius = brushFracNow * maxOf(bw, bh),
                                                ),
                                                warpSettingsNow.meshSmoothing, lockedMeshPointsNow, warpSettingsNow.lockHorizontal, warpSettingsNow.lockVertical,
                                            ) else null
                                        }
                                    }
                                    if (ng != null) {
                                        // ตารางใหม่ -> ท่าที่เห็น -> ท่าตั้งต้น (ย้อนการงอหมุด) แล้วบันทึกลงคลิป
                                        val vis = Sculpt.compose(ss.e0, ng, bw, bh)
                                        val b1 = JointPins.unbend(clip.rig, bw, bh, vis, ss.angles)
                                        if (!sBegan) { sBegan = true; onUndoMarkNow(sId) } // 1 สโตรก = 1 ก้าวย้อนกลับ (จดสถานะก่อนแก้ครั้งแรก)
                                        session = SculptSession(ss.clipId, ss.base, ss.e0, ss.angles, ng, b1)
                                        onSculptNow(sId, b1)
                                    }
                                }
                            },
                        )
                    } else {
                        detectTransformGestures { _, pan, zoom, rotation ->
                            // rotation ของ Compose เป็นองศาอยู่แล้ว
                            onTransformNow(selectedNow, pan.x / unitNow, pan.y / unitNow, zoom, rotation)
                        }
                    }
                }
                .pointerInput(sculptMode && sculptTool == SculptTool.PIN) {
                    if (sculptMode && sculptTool == SculptTool.PIN) {
                        // เครื่องมือหมุดข้อต่อ (ตัวจัดการอยู่ชั้นในสุด จึงได้รับเหตุการณ์ก่อน; ถ้าไม่ได้แตะหมุด/ไม่ได้วางหมุด จะไม่ดูดเหตุการณ์ ให้แตะเลือกคลิปได้ตามปกติ)
                        //   วางหมุด = แตะที่ข้อต่อ (ลากต่อไปทางส่วนที่จะขยับเพื่อตั้งทิศ) · ลากจุดแดง = ย้ายหมุด · ลากปลายสีเขียว = งอข้อต่อ
                        awaitEachGesture {
                            val down = awaitFirstDown(requireUnconsumed = false)
                            val clip = imagesNow.firstOrNull { it.id == selectedNow }
                            if (clip == null || clip.locked || !isActiveAt(clip, playheadNow)) return@awaitEachGesture
                            val pose = studioPoseAt(clip, playheadNow, warpSettings.interpolation, warpSettings.followMotion, warpSettings.motionStrength)
                            val bw = clip.bitmap.width
                            val bh = clip.bitmap.height
                            val rig = clip.rig
                            val g = pose.sculpt
                            // ตาข่ายที่เห็นบนจอ (งอ/ปั้นแล้ว): วาง/ย้าย/จับหมุดตอนภาพงออยู่ได้ โดยแปลงตำแหน่งที่เห็นกลับเป็นตำแหน่งบนภาพตั้งต้น
                            val eff = JointPins.effective(rig, bw, bh, g)
                            fun toRest(vx: Float, vy: Float): Pair<Float, Float> = if (eff == null) Pair(vx, vy) else Sculpt.restPoint(eff, bw, bh, vx, vy)
                            fun visPin(k: Int): Pair<Float, Float> =
                                if (eff == null) JointPins.pinPosition(rig, g, k) else Sculpt.samplePos(eff, bw, bh, rig.pins[k].x, rig.pins[k].y)
                            fun toBmp(pt: Offset): Pair<Float, Float> =
                                worldToBitmap(clip, pose, (pt.x - boxWNow / 2f) / unitNow, (pt.y - boxHNow / 2f) / unitNow)
                            val bmpPerPx = 1f / (fitScale(bw, bh) * unitNow * pose.scale.coerceAtLeast(0.05f))
                            val hitR = 24.dp.toPx() * bmpPerPx
                            val (sx, sy) = toBmp(down.position)

                            if (pinPlacingNow) {
                                down.consume()
                                var ex = sx
                                var ey = sy
                                while (true) {
                                    val ev = awaitPointerEvent()
                                    val ch = ev.changes.firstOrNull { it.id == down.id } ?: break
                                    val (mx, my) = toBmp(ch.position)
                                    ex = mx; ey = my
                                    pinPreview = listOf(sx, sy, ex, ey)
                                    ch.consume()
                                    if (!ch.pressed) break
                                }
                                pinPreview = null
                                val far = kotlin.math.hypot(ex - sx, ey - sy) > 18f * bmpPerPx
                                val (rsx, rsy) = toRest(sx, sy)
                                val (rex, rey) = toRest(ex, ey)
                                onPinAddNow(clip.id, rsx, rsy, if (far) Math.toDegrees(kotlin.math.atan2(rey - rsy, rex - rsx).toDouble()).toFloat() else null)
                                return@awaitEachGesture
                            }

                            // หาหมุดที่แตะ: ปลายสีเขียว (งอ) ก่อน แล้วจึงจุดแดง (ย้าย); หมุดที่เลือกอยู่มาก่อน
                            val order = rig.pins.indices.sortedBy { if (rig.pins[it].id == pinSelectedNow) 0 else 1 }
                            var hitKind = 0
                            var hitIdx = -1
                            var bestD = Float.MAX_VALUE
                            for (k in order) {
                                val (hx, hy) = JointPins.handlePosition(rig, g, k, bw, bh, visPin(k))
                                val d = kotlin.math.hypot(hx - sx, hy - sy)
                                if (d <= hitR && d < bestD) { bestD = d; hitKind = 1; hitIdx = k }
                            }
                            if (hitIdx < 0) for (k in order) {
                                val (px, py) = visPin(k)
                                val d = kotlin.math.hypot(px - sx, py - sy)
                                if (d <= hitR * 1.1f && d < bestD) { bestD = d; hitKind = 2; hitIdx = k }
                            }
                            if (hitIdx < 0) return@awaitEachGesture
                            val pin = rig.pins[hitIdx]
                            down.consume()
                            onPinSelectNow(pin.id)
                            if (hitKind == 1) {
                                onUndoMarkNow(clip.id)
                                while (true) {
                                    val ev = awaitPointerEvent()
                                    val ch = ev.changes.firstOrNull { it.id == down.id } ?: break
                                    val (mx, my) = toBmp(ch.position)
                                    onPinAngleNow(clip.id, hitIdx, JointPins.angleToward(rig, g, hitIdx, bw, bh, mx, my, visPin(hitIdx)))
                                    ch.consume()
                                    if (!ch.pressed) break
                                }
                            } else {
                                val movable = JointPins.ancestorsOf(rig.pins, hitIdx).all { (g?.angleOf(it) ?: 0f) == 0f }
                                if (!movable) onNoticeNow("หมุดนี้ติดกับหมุดแม่ที่กำลังงออยู่ ตั้งมุมแม่เป็น 0 ก่อนจึงย้ายได้ (หรือพิมพ์ X/Y ในตั้งค่าละเอียด)")
                                val (ppx, ppy) = visPin(hitIdx)
                                val offX = ppx - sx
                                val offY = ppy - sy
                                var lastX = pin.x
                                var lastY = pin.y
                                var moved = false
                                if (movable) onUndoMarkNow(clip.id)
                                while (true) {
                                    val ev = awaitPointerEvent()
                                    val ch = ev.changes.firstOrNull { it.id == down.id } ?: break
                                    if (movable) {
                                        val (mx, my) = toBmp(ch.position)
                                        val (rmx, rmy) = toRest(mx + offX, my + offY)
                                        lastX = rmx; lastY = rmy
                                        onPinMoveNow(clip.id, pin.id, lastX, lastY, false)
                                        moved = true
                                    }
                                    ch.consume()
                                    if (!ch.pressed) break
                                }
                                if (moved) onPinMoveNow(clip.id, pin.id, lastX, lastY, true) // ปล่อยนิ้ว: จัดตาข่ายถี่ใหม่ให้ตรงตำแหน่งหมุด
                            }
                        }
                    }
                }
                .pointerInput(sculptMode && sculptTool == SculptTool.POINT) {
                    if (sculptMode && sculptTool == SculptTool.POINT) {
                        // จุดบิด: แตะที่ว่าง = วางจุด · ลากจุด = บิดภาพรอบจุด (จุดอื่นเป็นตัวยึด) · แตะจุดเดิม = ลบจุด
                        awaitEachGesture {
                            val down = awaitFirstDown(requireUnconsumed = false)
                            val clip = imagesNow.firstOrNull { it.id == selectedNow }
                            if (clip == null || clip.locked || !isActiveAt(clip, playheadNow)) return@awaitEachGesture
                            val pose = studioPoseAt(clip, playheadNow, warpSettings.interpolation, warpSettings.followMotion, warpSettings.motionStrength)
                            val bw = clip.bitmap.width
                            val bh = clip.bitmap.height
                            fun toBmp(pt: Offset): Pair<Float, Float> =
                                worldToBitmap(clip, pose, (pt.x - boxWNow / 2f) / unitNow, (pt.y - boxHNow / 2f) / unitNow)
                            val bmpPerPx = 1f / (fitScale(bw, bh) * unitNow * pose.scale.coerceAtLeast(0.05f))
                            val hitR = 24.dp.toPx() * bmpPerPx
                            val slop = 10.dp.toPx()
                            val pts = pointSet?.takeIf { it.clipId == clip.id }?.xy ?: FloatArray(0)
                            val (sx, sy) = toBmp(down.position)
                            var hit = -1
                            var best = Float.MAX_VALUE
                            for (q in 0 until pts.size / 3) {
                                val d = kotlin.math.hypot(pts[3 * q] - sx, pts[3 * q + 1] - sy)
                                if (d <= hitR && d < best) { best = d; hit = q }
                            }
                            down.consume()

                            if (hit < 0) { // แตะที่ว่าง = วางห่วงใหม่ (รัศมีตามแถบ "รัศมี"; ถ้านิ้วเลื่อนเกิน slop ไม่วาง)
                                var moved = false
                                while (true) {
                                    val ev = awaitPointerEvent()
                                    if (ev.changes.size > 1) return@awaitEachGesture
                                    val ch = ev.changes.firstOrNull { it.id == down.id } ?: break
                                    if ((ch.position - down.position).getDistance() > slop) moved = true
                                    ch.consume()
                                    if (!ch.pressed) break
                                }
                                if (!moved) pointSet = PointSet(clip.id, pts + floatArrayOf(sx, sy, brushFracNow * maxOf(bw, bh)))
                                return@awaitEachGesture
                            }

                            // ลากห่วง: ภาพในวงกลมบิดตาม (ขอบนุ่ม) บนตารางใหม่ของเซสชัน (หรือเริ่มใหม่ทับท่าที่เห็นอยู่)
                            val sess = validSession(session, clip, pose) ?: run {
                                val (dc, dr) = clipGridDims(clip, meshCellNow, warpSettingsNow.meshCols, warpSettingsNow.meshRows)
                                val base = pose.sculpt ?: JointPins.zeroGrid(clip.rig, bw, bh, dc, dr)
                                val e0 = renderGrid(clip, base, playheadNow - clip.startTime) ?: base
                                SculptSession(clip.id, pose.sculpt, e0, base.pinAngles, SculptGrid.zero(e0.cols, e0.rows), pose.sculpt)
                            }
                            session = sess
                            val st = sess.lat
                            val rcx = pts[3 * hit]
                            val rcy = pts[3 * hit + 1]
                            val rr = pts[3 * hit + 2]
                            var began = false
                            var movedAny = false
                            while (true) {
                                val ev = awaitPointerEvent()
                                if (ev.changes.size > 1) break
                                val ch = ev.changes.firstOrNull { it.id == down.id } ?: break
                                if (movedAny || (ch.position - down.position).getDistance() > slop) {
                                    movedAny = true
                                    val (mx, my) = toBmp(ch.position)
                                    val (cx, cy) = Sculpt.capMove(mx - sx, my - sy, rr)
                                    val ng = Sculpt.applyRing(bw, bh, st, rcx, rcy, rr, cx, cy)
                                    val vis = Sculpt.compose(sess.e0, ng, bw, bh)
                                    val b1 = JointPins.unbend(clip.rig, bw, bh, vis, sess.angles)
                                    if (!began) { began = true; onUndoMarkNow(clip.id) }
                                    session = SculptSession(sess.clipId, sess.base, sess.e0, sess.angles, ng, b1)
                                    // ห่วงนี้ตามนิ้ว · ห่วงอื่นที่อยู่ในวงถูกภาพพาไปด้วย (ให้ยังอยู่บนจุดเดิมของภาพ)
                                    val np = pts.copyOf()
                                    for (q in 0 until pts.size / 3) {
                                        val w = if (q == hit) 1f else Sculpt.ringWeight(rcx, rcy, rr, pts[3 * q], pts[3 * q + 1])
                                        np[3 * q] = pts[3 * q] + cx * w
                                        np[3 * q + 1] = pts[3 * q + 1] + cy * w
                                    }
                                    pointSet = PointSet(clip.id, np)
                                    onSculptNow(clip.id, b1)
                                }
                                ch.consume()
                                if (!ch.pressed) break
                            }
                            if (!movedAny) { // แตะห่วงเดิมโดยไม่ลาก = ลบห่วงนั้น
                                val n = pts.size / 3
                                val np = FloatArray((n - 1) * 3)
                                var o = 0
                                for (q in 0 until n) if (q != hit) { np[o++] = pts[3 * q]; np[o++] = pts[3 * q + 1]; np[o++] = pts[3 * q + 2] }
                                pointSet = PointSet(clip.id, np)
                            }
                        }
                    }
                },
            contentAlignment = Alignment.Center,
        ) {
            stageBody({ viewZoom })
            // ค่ามุมหมุน (องศา) และขนาด (% ของขนาดพอดีเฟรม) ของคลิปที่เลือก
            val sel = images.firstOrNull { it.id == selectedId } // (ประกาศซ้ำ: ตัวเดิมย้ายเข้า stageBody แล้ว)
            if (sel != null && isActiveAt(sel, playhead) && !zoomed) { // ซูมจออยู่ซ่อนป้ายนี้ (ป้ายอยู่ในชั้นที่ถูกซูมไปด้วย)
                val p = studioPoseAt(sel, playhead, warpSettings.interpolation, warpSettings.followMotion, warpSettings.motionStrength)
                val deg = ((p.rotation % 360f) + 540f) % 360f - 180f
                Text(
                    "↻ ${f1(deg)}°   ⤢ ${(p.scale * 100f).roundToInt()}%" + (if (sel.sizeLocked) " 🔒" else ""),
                    color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.SemiBold,
                    modifier = Modifier.align(Alignment.TopCenter).padding(top = 6.dp)
                        .background(Color(0xAA000000), RoundedCornerShape(8.dp)).padding(horizontal = 8.dp, vertical = 3.dp),
                )
            }
            // ข้อความ/สติกเกอร์
            if ((overlayText.isNotBlank() || overlaySticker.isNotBlank()) && playhead >= overlayStart && playhead < overlayStart + overlayDuration) {
                val textSp = with(density) { (sqPx * 46f / OUT_SIZE).toSp() }
                Column(Modifier.align(Alignment.Center), horizontalAlignment = Alignment.CenterHorizontally) {
                    if (overlaySticker.isNotBlank()) Text(overlaySticker, fontSize = textSp)
                    if (overlayText.isNotBlank()) Text(overlayText, color = Color.White, fontSize = textSp, fontWeight = FontWeight.Bold, maxLines = 1)
                }
            }
        }
        // ปุ่มรีเซ็ตซูมจอ (โผล่เมื่อซูมอยู่)
        if (sculptMode && zoomed) {
            Box(
                Modifier.align(Alignment.BottomStart).padding(8.dp).height(28.dp).clip(RoundedCornerShape(14.dp))
                    .background(Color(0xCC000000)).clickable { viewZoom = 1f; viewPan = Offset.Zero }.padding(horizontal = 10.dp),
                contentAlignment = Alignment.Center,
            ) { ZoomResetLabel { viewZoom } }
        }
        // แว่นขยาย: กล่องลากย้ายได้ แสดงภาพบริเวณที่กดล่าสุดขยาย (ขนาดกล่องใช้ค่าเดียวกับแว่นขยายหน้าตัดภาพ ตั้งในหน้าตั้งค่า)
        if (sculptMode && lensOpen) {
            val maxW = constraints.maxWidth.toFloat()
            val maxH = constraints.maxHeight.toFloat()
            val lensPx = LoupeSize.boxPx(density.density, minOf(boxWPx, boxHPx)).coerceAtMost(minOf(maxW, maxH))
            val lensDp = with(density) { lensPx.toDp() }
            val lensShape = RoundedCornerShape(14.dp)
            Box(
                Modifier.align(Alignment.TopStart)
                    .offset { IntOffset(lensPos.x.roundToInt(), lensPos.y.roundToInt()) }
                    .size(lensDp).clip(lensShape).background(Color.Black).border(2.dp, c.Accent, lensShape)
                    .pointerInput(lensPx, constraints.maxWidth, constraints.maxHeight) {
                        detectDragGestures { change, drag ->
                            change.consume()
                            lensPos = Offset(
                                (lensPos.x + drag.x).coerceIn(0f, maxOf(0f, maxW - lensPx)),
                                (lensPos.y + drag.y).coerceIn(0f, maxOf(0f, maxH - lensPx)),
                            )
                        }
                    },
            ) {
                Box(
                    Modifier.align(Alignment.Center).requiredSize(boxW, boxH)
                        .graphicsLayer {
                            val k = lensMag
                            val pt = lensPt ?: Offset(boxWPx / 2f, boxHPx / 2f)
                            scaleX = k; scaleY = k
                            translationX = -k * (pt.x - boxWPx / 2f) // จุดที่กดล่าสุดมาอยู่กลางแว่น
                            translationY = -k * (pt.y - boxHPx / 2f)
                        },
                    contentAlignment = Alignment.Center,
                ) { stageBody({ viewZoom * lensMag }) }
                androidx.compose.foundation.Canvas(Modifier.fillMaxSize()) { // กากบาทกลางแว่น = จุดที่กดล่าสุด
                    val cx = size.width / 2f
                    val cy = size.height / 2f
                    val r = 8.dp.toPx()
                    drawLine(Color.Black, Offset(cx - r, cy), Offset(cx + r, cy), 3f)
                    drawLine(Color.Black, Offset(cx, cy - r), Offset(cx, cy + r), 3f)
                    drawLine(Color.White, Offset(cx - r, cy), Offset(cx + r, cy), 1.5f)
                    drawLine(Color.White, Offset(cx, cy - r), Offset(cx, cy + r), 1.5f)
                }
                Box(
                    Modifier.align(Alignment.TopStart).padding(4.dp).height(26.dp).clip(RoundedCornerShape(13.dp))
                        .background(Color(0xAA000000))
                        .clickable { val mags = listOf(2f, 3f, 4f, 6f, 8f); lensMag = mags.getOrElse(mags.indexOf(lensMag) + 1) { mags[0] } }
                        .padding(horizontal = 8.dp),
                    contentAlignment = Alignment.Center,
                ) { Text("×${lensMag.roundToInt()}", color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Bold) }
                Box(
                    Modifier.align(Alignment.TopEnd).padding(4.dp).size(26.dp).clip(CircleShape)
                        .background(Color(0xAA000000)).clickable { onLensCloseNow() },
                    contentAlignment = Alignment.Center,
                ) { Text("✕", color = Color.White, fontSize = 13.sp) }
            }
        }
    }
}

/** ป้ายรีเซ็ตซูมจอ: อ่านค่าซูมในนี้เอง เพื่อให้ตอนบีบนิ้วซูมรีคอมโพสแค่ป้ายนี้ ไม่ต้องวาดทั้งเฟรมใหม่ */
@Composable
private fun ZoomResetLabel(zoom: () -> Float) {
    Text("🔍 ${f1(zoom())}× · รีเซ็ต", color = Color.White, fontSize = 12.sp)
}

/**
 * วาดหมุดข้อต่อบนภาพ: จุดแดง = หมุด (ย้ายได้) · เส้น/ปลายเขียว = ทิศส่วนที่ขยับ (ลากปลายเพื่องอ)
 * หมุดที่เลือก: เส้นเขียวจาง = ขอบส่วนที่ขยับเต็มที่ · เส้นส้ม = ขอบส่วนที่นิ่ง (ระหว่างสองเส้นคือช่วงโค้งนุ่ม) วงฟ้า = รัศมีตาข่ายถี่ วงส้ม = ระยะส่งผล
 * ทุกตำแหน่งคิดตามการงอของหมุดแม่ จึงตรงกับที่เห็น
 */
private fun DrawScope.drawPinGizmos(clip: StudioImage, g: SculptGrid?, bw: Int, bh: Int, fit: Float, uiScale: Float, selectedId: Int, preview: List<Float>?) {
    val rig = clip.rig
    val col = StudioColors
    val dp = density * uiScale // ขนาดบนจอคงที่แม้คลิปถูกย่อ/ขยาย (กรอบนี้ถูกสเกลตามคลิป)
    val label = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = android.graphics.Color.WHITE; textSize = 10f * dp; textAlign = Paint.Align.CENTER; typeface = Typeface.DEFAULT_BOLD
    }
    val effG = JointPins.effective(rig, bw, bh, g)
    rig.pins.forEachIndexed { k, pin ->
        val sel = pin.id == selectedId
        val (px, py) = if (effG == null) JointPins.pinPosition(rig, g, k) else Sculpt.samplePos(effG, bw, bh, pin.x, pin.y) // ตำแหน่งที่เห็นจริง
        val (hx, hy) = JointPins.handlePosition(rig, g, k, bw, bh, Pair(px, py))
        val p0 = Offset(px * fit, py * fit)
        val p1 = Offset(hx * fit, hy * fit)
        drawCircle(col.Warn.copy(alpha = if (sel) 0.7f else 0.3f), JointPins.radiusOf(pin) * fit, p0, style = Stroke(width = (if (sel) 2f else 1f) * dp)) // วงกลมที่หมุดนี้บิด
        if (sel) {
            if (rig.adaptive) drawCircle(col.Accent.copy(alpha = 0.45f), JointPins.meshRadiusOf(pin, bw, bh) * fit, p0, style = Stroke(width = 1f * dp))
        }
        drawLine(col.Ok, p0, p1, strokeWidth = (if (sel) 3.5f else 2f) * dp)
        drawCircle(col.Ok, (if (sel) 9f else 6.5f) * dp, p1)
        drawCircle(Color.White, (if (sel) 9f else 6.5f) * dp, p1, style = Stroke(width = 1.5f * dp))
        drawCircle(col.Danger, (if (sel) 11f else 9f) * dp, p0)
        drawCircle(Color.White, (if (sel) 11f else 9f) * dp, p0, style = Stroke(width = (if (sel) 2.5f else 1.5f) * dp))
        drawContext.canvas.nativeCanvas.drawText((k + 1).toString(), p0.x, p0.y + label.textSize * 0.35f, label)
    }
    preview?.let { l ->
        if (l.size >= 4) {
            drawLine(col.Ok, Offset(l[0] * fit, l[1] * fit), Offset(l[2] * fit, l[3] * fit), strokeWidth = 3f * dp)
            drawCircle(col.Danger, 10f * dp, Offset(l[0] * fit, l[1] * fit))
            drawCircle(col.Ok, 7f * dp, Offset(l[2] * fit, l[3] * fit))
        }
    }
}

// ───────────────────────── แผงเครื่องมือบิดภาพ / ขนาดวิดีโอ ─────────────────────────

private fun fmtSculptNum(v: Float, decimal: Boolean): String = when {
    !v.isFinite() -> "0"
    kotlin.math.abs(v) >= 1_000_000f || (v != 0f && kotlin.math.abs(v) < 0.0001f) -> v.toString()
    !decimal && v == v.toInt().toFloat() -> v.toInt().toString()
    else -> String.format(java.util.Locale.US, "%.4f", v).trimEnd('0').trimEnd('.')
}

/**
 * ช่องกรอกตัวเลข: รับค่าที่แปลงเป็น Float ได้โดยไม่ตัดจำนวนหลักหรือบังคับช่วง lo..hi; ป้องกันเฉพาะ NaN/Infinity
 * ค่าที่เปลี่ยนจากข้างนอก (เช่นเลื่อนสไลเดอร์) จะอัปเดตข้อความในช่อง แต่ไม่ทับสิ่งที่กำลังพิมพ์ (เช่น "1." ก่อนพิมพ์ทศนิยม)
 */
@Composable
private fun SculptNumField(label: String, value: Float, lo: Float, hi: Float, decimal: Boolean, width: Dp, onValid: (Float) -> Unit) {
    val c = StudioColors
    var text by remember { mutableStateOf(fmtSculptNum(value, decimal)) }
    val tol = if (decimal) 0.06f else 0.6f
    LaunchedEffect(value) {
        val now = text.replace(',', '.').toFloatOrNull()
        if (now == null || abs(now - value) > tol) text = fmtSculptNum(value, decimal)
    }
    val parsed = text.replace(',', '.').toFloatOrNull()
    val ok = parsed != null && parsed.isFinite()
    val paramSpec = remember(label) { ParamPreviewRegistry.find(label) }
    val visualSpec = remember(label) { ParamPreviewRegistry.findVisual(label) }
    var showParamPreview by remember { mutableStateOf(false) }
    var showVisualPreview by remember { mutableStateOf(false) }
    Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
            Text(label, color = c.Sub, fontSize = 10.sp, maxLines = 1)
            if (paramSpec != null || visualSpec != null) ParamPreviewButton { if (paramSpec != null) showParamPreview = true else showVisualPreview = true }
        }
        if (showParamPreview && paramSpec != null) ParamPreviewSheet(paramSpec, if (ok) (parsed ?: value) else value, ParamDemoContext.mode, { v -> onValid(v) }) { showParamPreview = false }
        if (showVisualPreview && visualSpec != null) ParamVisualPreviewSheet(visualSpec, if (ok) (parsed ?: value) else value, { v -> onValid(v) }) { showVisualPreview = false }
        BasicTextField(
            value = text,
            onValueChange = { raw ->
                val t = raw.filter { ch -> ch.isDigit() || ch == '.' || ch == ',' || ch == '-' || ch == '+' || ch == 'e' || ch == 'E' }
                text = t
                val n = t.replace(',', '.').toFloatOrNull()
                if (n != null && n.isFinite()) onValid(n)
            },
            singleLine = true,
            textStyle = TextStyle(color = c.Ink, fontSize = 14.sp),
            cursorBrush = SolidColor(c.Accent),
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Text),
            modifier = Modifier.width(width)
                .background(c.Panel2, RoundedCornerShape(10.dp))
                .border(1.dp, if (ok) c.Line else c.Danger, RoundedCornerShape(10.dp))
                .padding(horizontal = 10.dp, vertical = 7.dp),
        )
    }
}

/** ช่องกรอกตัวเลขที่ติดลบได้ (มุมงอ ฯลฯ): ทำงานเหมือน SculptNumField แต่พิมพ์ "-" นำหน้าได้ */
@Composable
private fun SignedNumField(label: String, value: Float, lo: Float, hi: Float, width: Dp, onValid: (Float) -> Unit) {
    val c = StudioColors
    var text by remember { mutableStateOf(fmtSculptNum(value, true)) }
    LaunchedEffect(value) {
        val now = text.replace(',', '.').toFloatOrNull()
        if (now == null || abs(now - value) > 0.06f) text = fmtSculptNum(value, true)
    }
    val parsed = text.replace(',', '.').toFloatOrNull()
    val ok = parsed != null && parsed.isFinite()
    val paramSpec = remember(label) { ParamPreviewRegistry.find(label) }
    val visualSpec = remember(label) { ParamPreviewRegistry.findVisual(label) }
    var showParamPreview by remember { mutableStateOf(false) }
    var showVisualPreview by remember { mutableStateOf(false) }
    Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
            Text(label, color = c.Sub, fontSize = 10.sp, maxLines = 1)
            if (paramSpec != null || visualSpec != null) ParamPreviewButton { if (paramSpec != null) showParamPreview = true else showVisualPreview = true }
        }
        if (showParamPreview && paramSpec != null) ParamPreviewSheet(paramSpec, if (ok) (parsed ?: value) else value, ParamDemoContext.mode, { v -> onValid(v) }) { showParamPreview = false }
        if (showVisualPreview && visualSpec != null) ParamVisualPreviewSheet(visualSpec, if (ok) (parsed ?: value) else value, { v -> onValid(v) }) { showVisualPreview = false }
        BasicTextField(
            value = text,
            onValueChange = { raw ->
                val t = raw.filter { ch -> ch.isDigit() || ch == '.' || ch == ',' || ch == '-' || ch == '+' || ch == 'e' || ch == 'E' }
                text = t
                val n = t.replace(',', '.').toFloatOrNull()
                if (n != null && n.isFinite()) onValid(n)
            },
            singleLine = true,
            textStyle = TextStyle(color = c.Ink, fontSize = 14.sp),
            cursorBrush = SolidColor(c.Accent),
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Text),
            modifier = Modifier.width(width)
                .background(c.Panel2, RoundedCornerShape(10.dp))
                .border(1.dp, if (ok) c.Line else c.Danger, RoundedCornerShape(10.dp))
                .padding(horizontal = 10.dp, vertical = 7.dp),
        )
    }
}

/** ป้ายสั้น ๆ คั่นกลุ่มในแผงหมุด */
@Composable
private fun PinHeading(text: String) {
    Text(text, color = StudioColors.Accent, fontSize = 11.sp, fontWeight = FontWeight.Bold)
}

/**
 * แผงหมุดข้อต่ออัจฉริยะ (ในโหมดบิดภาพ > 📍 หมุดข้อต่อ)
 * ส่วนหลัก: เลือก/วางหมุด · มุมงอ (พิมพ์ / เลื่อน / ปุ่มเพิ่มลด) · ทิศ · ความนุ่ม
 * ตั้งค่าละเอียด (พับเก็บได้): ชื่อ · ตำแหน่ง X/Y · ระยะส่งผล · จำกัดมุม · ติดกับหมุดแม่ · ตาข่ายถี่ตามจุด (เปิด/ปิด ความถี่ รัศมี) · แสดงเส้นตาข่าย
 */
@Composable
private fun PinSection(
    clip: StudioImage, grid: SculptGrid?, selectedPinId: Int, placing: Boolean, showMesh: Boolean,
    onPlacing: (Boolean) -> Unit, onSelect: (Int) -> Unit,
    onEdit: (Int, Boolean, (JointPin) -> JointPin) -> Unit,
    onAngle: (Int, Float) -> Unit, onDelete: (Int) -> Unit,
    onRig: (Boolean, (PinRig) -> PinRig) -> Unit,
    onShowMesh: (Boolean) -> Unit, onResetAngles: () -> Unit,
) {
    val c = StudioColors
    val rig = clip.rig
    val pins = rig.pins
    val bw = clip.bitmap.width
    val bh = clip.bitmap.height
    val maxSide = maxOf(bw, bh).toFloat()
    val k = pins.indexOfFirst { it.id == selectedPinId }.let { if (it >= 0) it else if (pins.isNotEmpty()) 0 else -1 }
    var expanded by remember { mutableStateOf(false) }
    fun pinLabel(p: JointPin, idx: Int): String = "${idx + 1}" + if (p.name.isNotBlank()) " ${p.name}" else ""

    Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.CenterVertically) {
        ToolChip(
            if (placing) "แตะที่ข้อต่อบนภาพ…" else "＋ วางหมุด", highlight = placing,
            enabled = !clip.locked && (placing || pins.size < JointPins.MAX_PINS), onClick = { onPlacing(!placing) },
        )
        pins.forEachIndexed { idx, p -> ToolChip("📍 " + pinLabel(p, idx), highlight = idx == k, onClick = { onSelect(p.id); onPlacing(false) }) }
    }

    if (k < 0) {
        Text(
            "วิธีใช้: กด ＋ วางหมุด แล้วแตะบนภาพตรงที่จะบิด (วางได้ไม่จำกัด ไม่ต้องรีเซ็ตมุม ไม่ต้องผูกแม่-ลูก)\n" +
                "ลากปลายสีเขียวเพื่อหมุนภาพรอบหมุด หรือพิมพ์มุมในแผงนี้ · วงสีส้มคือขอบเขตการบิด · ทุกหมุดทำงานร่วมกับท่าบิดและคีย์เฟรม",
            color = c.Sub, fontSize = 11.sp,
        )
        return
    }

    val pin = pins[k]
    key(pin.id) {
        val a = grid?.angleOf(k) ?: 0f
        val lo = JointPins.minAngle(pin)
        val hi = JointPins.maxAngle(pin)
        val eff = JointPins.effective(rig, bw, bh, grid)
        val folds = if (eff != null) Sculpt.foldCount(bw, bh, eff) else 0
        val canEdit = !clip.locked

        PinHeadingAngle(a, lo, hi, canEdit, onAngle = { v -> onAngle(k, v) }, onReset = onResetAngles)

        if (folds > 0) {
            Text("⚠ ตาข่ายพับ $folds ช่อง — ลดมุมงอ เพิ่มรัศมีวงกลม หรือย้ายหมุดที่วงซ้อนกันให้ห่างกัน", color = c.Warn, fontSize = 11.sp)
        } else {
            Text("งอได้ไม่จำกัด (พิมพ์มุมเท่าไหร่ก็ได้ · ลากปลายสีเขียววนได้หลายรอบ) · บวก = ตามเข็มบนจอ", color = c.Sub, fontSize = 11.sp)
        }

        PinHeading("ทิศส่วนที่ขยับ (ปลายสีเขียว)")
        Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.Bottom) {
            listOf("→" to 0f, "↘" to 45f, "↓" to 90f, "↙" to 135f, "←" to 180f, "↖" to 225f, "↑" to 270f, "↗" to 315f).forEach { (arrow, deg) ->
                val on = abs(((pin.dirDeg - deg + 540f) % 360f) - 180f) < 1f
                ToolChip(arrow, highlight = on, enabled = canEdit, onClick = { onEdit(pin.id, false) { p -> p.copy(dirDeg = deg) } })
            }
            SculptNumField("ทิศ (°) 0=ขวา 90=ลง", pin.dirDeg, 0f, 360f, true, 150.dp) { v -> onEdit(pin.id, false) { p -> p.copy(dirDeg = v % 360f) } }
        }

        PinHeading("รัศมีวงกลมที่หมุดนี้บิด")
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.Bottom, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            SculptNumField("รัศมี (px)", JointPins.radiusOf(pin), 20f, maxSide, false, 120.dp) { v ->
                onEdit(pin.id, false) { p -> p.copy(reach = v) }
            }
            Slider(
                value = JointPins.radiusOf(pin).coerceIn(20f, maxSide), onValueChange = { v -> onEdit(pin.id, false) { p -> p.copy(reach = v) } },
                valueRange = 20f..maxSide, enabled = canEdit, modifier = Modifier.weight(1f),
                colors = SliderDefaults.colors(thumbColor = c.Accent, activeTrackColor = c.Accent, inactiveTrackColor = c.Line),
            )
        }
        Text("ภาพในวงหมุนรอบหมุด แรงสุดที่หมุด ลดลงนุ่ม ๆ จนไม่ขยับที่ขอบวง", color = c.Sub, fontSize = 11.sp)

        Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.CenterVertically) {
            ToolChip(if (expanded) "▲ ซ่อนตั้งค่าละเอียด" else "⚙ ตั้งค่าละเอียด", highlight = expanded, onClick = { expanded = !expanded })
            ToolChip("🗑 ลบหมุดนี้", danger = true, enabled = canEdit, onClick = { onDelete(pin.id) })
        }

        if (expanded) {
            PinHeading("หมุดนี้")
            Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.Bottom) {
                var nameText by remember { mutableStateOf(pin.name) }
                Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
                    Text("ชื่อ", color = c.Sub, fontSize = 10.sp)
                    BasicTextField(
                        value = nameText,
                        onValueChange = { raw -> val t = raw.take(12); nameText = t; onEdit(pin.id, false) { p -> p.copy(name = t) } },
                        singleLine = true, enabled = canEdit,
                        textStyle = TextStyle(color = c.Ink, fontSize = 14.sp), cursorBrush = SolidColor(c.Accent),
                        modifier = Modifier.width(120.dp).background(c.Panel2, RoundedCornerShape(10.dp)).border(1.dp, c.Line, RoundedCornerShape(10.dp)).padding(horizontal = 10.dp, vertical = 7.dp),
                    )
                }
                SculptNumField("ตำแหน่ง X (px)", pin.x, 0f, bw.toFloat(), false, 110.dp) { v -> onEdit(pin.id, true) { p -> p.copy(x = v) } }
                SculptNumField("ตำแหน่ง Y (px)", pin.y, 0f, bh.toFloat(), false, 110.dp) { v -> onEdit(pin.id, true) { p -> p.copy(y = v) } }
            }
            Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.Bottom) {
                                SignedNumField("จำกัดมุมต่ำสุด (°)", pin.minDeg, -180f, 0f, 150.dp) { v -> onEdit(pin.id, false) { p -> p.copy(minDeg = v) } }
                SignedNumField("จำกัดมุมสูงสุด (°)", pin.maxDeg, 0f, 180f, 150.dp) { v -> onEdit(pin.id, false) { p -> p.copy(maxDeg = v) } }
            }
            Text("จำกัดมุม: เช่น ให้งอได้ทางเดียว ต่ำสุด 0 สูงสุด 120", color = c.Sub, fontSize = 11.sp)

            PinHeading("เพิ่มความละเอียดตาข่ายรอบจุดอัตโนมัติ")
            Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.Bottom) {
                ToolChip(if (rig.adaptive) "ถี่ตามจุด: เปิด" else "ถี่ตามจุด: ปิด", highlight = rig.adaptive, enabled = canEdit, onClick = { onRig(true) { r -> r.copy(adaptive = !r.adaptive) } })
                SculptNumField("ความหนาแน่นตาข่ายรอบหมุด", rig.density, 0f, Float.MAX_VALUE, true, 150.dp) { v -> onRig(true) { r -> r.copy(density = v) } }
                SculptNumField("รัศมีตาข่ายถี่ (px)", JointPins.meshRadiusOf(pin, bw, bh), 10f, maxSide, false, 140.dp) { v -> onEdit(pin.id, true) { p -> p.copy(meshRadius = v) } }
                ToolChip("รัศมีอัตโนมัติ", enabled = canEdit && pin.meshRadius > 0f, onClick = { onEdit(pin.id, true) { p -> p.copy(meshRadius = 0f) } })
            }
            Text("เพิ่มจุดตาข่ายรอบหมุดเพื่อให้ข้อต่อโค้งเนียนขึ้น · ค่าที่พิมพ์เก็บตามจริง แต่การคำนวณปรับความหนาแน่นและรัศมีให้อยู่ในขอบเขตที่เครื่องรองรับ · วงฟ้าบนภาพ = รัศมีตาข่ายถี่", color = c.Sub, fontSize = 11.sp)

            Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.CenterVertically) {
                ToolChip(if (showMesh) "เส้นตาข่าย: แสดง" else "เส้นตาข่าย: ซ่อน", highlight = showMesh, onClick = { onShowMesh(!showMesh) })
            }
        }

        Text(
            "ลากจุดแดง = ย้ายหมุด · ลากปลายสีเขียว = งอข้อต่อ · เส้นเขียวจาง/ส้ม = ขอบช่วงโค้ง · ถ้ามี ◆ หลายจุด แต่ละจุดจำมุมของตัวเอง (เล่นแล้วค่อย ๆ งอระหว่างจุด)",
            color = c.Sub, fontSize = 11.sp,
        )
    }
}

/** แถวมุมงอ: ช่องพิมพ์ + ปุ่มเพิ่ม/ลด + รีเซ็ต + แถบเลื่อน */
@Composable
private fun PinHeadingAngle(angle: Float, lo: Float, hi: Float, enabled: Boolean, onAngle: (Float) -> Unit, onReset: () -> Unit) {
    val c = StudioColors
    Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.Bottom) {
        SignedNumField("มุมงอ (°)", angle, lo, hi, 100.dp) { v -> onAngle(v) }
        listOf(-5f, -1f, 1f, 5f).forEach { d ->
            ToolChip(if (d > 0) "+${d.roundToInt()}" else "${d.roundToInt()}", enabled = enabled, onClick = { onAngle((angle + d).coerceIn(lo, hi)) })
        }
        ToolChip("รีเซ็ตมุม", enabled = enabled, onClick = onReset)
    }
    if (minOf(hi, 360f) > maxOf(lo, -360f)) {
        Slider(
            value = angle.coerceIn(maxOf(lo, -360f), minOf(hi, 360f)), onValueChange = { v -> onAngle(v) }, valueRange = maxOf(lo, -360f)..minOf(hi, 360f), enabled = enabled,
            colors = SliderDefaults.colors(thumbColor = c.Accent, activeTrackColor = c.Accent, inactiveTrackColor = c.Line),
        )
    }
}

/** แผง Advanced Warp: เครื่องมือทุกชนิด + ช่องกรอกค่าละเอียดเป็นหมวด */
@Composable
private fun SculptPanel(
    clip: StudioImage, tool: SculptTool, onTool: (SculptTool) -> Unit,
    brushFrac: Float, onBrush: (Float) -> Unit,
    meshRings: Int, onRings: (Int) -> Unit,
    twistDeg: Float, onTwist: (Float) -> Unit,
    meshCell: Float?, onCell: (Float?) -> Unit,
    warpSettings: WarpSettings, onWarpSettings: (WarpSettings) -> Unit, onCreateLoop: () -> Unit, onAdaptiveMesh: (Boolean) -> Unit,
    currentGrid: SculptGrid?, onCaptureLayer: () -> Unit, onWarpLayers: (List<WarpLayer>) -> Unit, onPhysics: (WarpPhysicsSettings) -> Unit,
    customPresets: List<WarpPreset>, onSaveCustomPreset: (String) -> Unit, onDeleteCustomPreset: (Int) -> Unit,
    lockedMeshPoints: Set<Int>, selectedMeshPoint: Int, onToggleMeshPointLock: (Int) -> Unit, onClearMeshLocks: () -> Unit,
    onResetMeshPoint: (Int) -> Unit, onCopyWarp: () -> Unit, onPasteWarp: () -> Unit, hasCopiedWarp: Boolean,
    onResetSettings: () -> Unit, onApplyGrid: () -> Unit, onReset: () -> Unit, undoCount: Int, onUndo: () -> Unit, redoCount: Int, onRedo: () -> Unit,
    showMesh: Boolean, onShowMesh: (Boolean) -> Unit, lensOpen: Boolean, onLens: () -> Unit,
    pinContent: @Composable () -> Unit,
) {
    val c = StudioColors
    val bw = clip.bitmap.width
    val bh = clip.bitmap.height
    val (gc, gr) = clipGridDims(clip, meshCell, warpSettings.meshCols, warpSettings.meshRows)
    val (pc, pr) = Sculpt.gridDims(bw, bh, meshCell, warpSettings.meshCols, warpSettings.meshRows)
    val layoutGrid = JointPins.zeroGrid(clip.rig, bw, bh, gc, gr)
    val cellMax = Sculpt.cellMaxPx(bw, bh, layoutGrid)
    val cellMin = Sculpt.cellMinPx(bw, bh, layoutGrid)
    val twistRadius = maxOf(brushFrac * maxOf(bw, bh), 2f * cellMax)
    val limitDeg = Math.toDegrees(Sculpt.maxTwist(twistRadius, cellMax).toDouble()).toFloat()
    val twistOver = tool == SculptTool.TWIST && twistDeg > limitDeg
    var section by remember { mutableStateOf("เครื่องมือ") }
    var showParamLibrary by remember { mutableStateOf(false) }
    SideEffect { ParamDemoContext.mode = sculptToolDemoMode(tool) }
    val patch: (WarpSettings.() -> WarpSettings) -> Unit = { edit -> onWarpSettings(warpSettings.edit()) }

    Column(
        Modifier.fillMaxWidth()
            .heightIn(max = if (tool == SculptTool.PIN) 300.dp else 390.dp)
            .background(c.Panel, RoundedCornerShape(14.dp))
            .verticalScroll(rememberScrollState()).padding(8.dp),
        verticalArrangement = Arrangement.spacedBy(7.dp),
    ) {
        Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.CenterVertically) {
            ToolChip("↶ $undoCount", enabled = undoCount > 0, onClick = onUndo)
            ToolChip("↷ $redoCount", enabled = redoCount > 0, onClick = onRedo)
            ToolChip("ใช้ตารางที่ตั้ง", enabled = !clip.locked && !isVideoClip(clip) && (pc != gc || pr != gr), onClick = onApplyGrid)
            ToolChip("คัดลอกท่าบิด", enabled = clip.sculpt != null || clip.keyframes.any { it.sculpt != null }, onClick = onCopyWarp)
            ToolChip("วางท่าบิด", enabled = !clip.locked && hasCopiedWarp, onClick = onPasteWarp)
            ToolChip("รีเซ็ตภาพ", enabled = !clip.locked, onClick = onReset)
            ToolChip("ค่าเริ่มต้น", onClick = onResetSettings)
            ToolChip("คลังตัวอย่างค่า", onClick = { showParamLibrary = true })
            ToolChip(if (lensOpen) "ปิดแว่นขยาย" else "แว่นขยาย", highlight = lensOpen, onClick = onLens)
            ToolChip(if (showMesh) "ซ่อนตาข่าย" else "แสดงตาข่าย", highlight = showMesh, onClick = { onShowMesh(!showMesh) })
        }

        if (showParamLibrary) ParamLibrarySheet(onDismiss = { showParamLibrary = false })

        if (tool == SculptTool.PIN) {
            Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(5.dp)) {
                ToolChip("กลับไปเครื่องมือบิด", highlight = false, onClick = { onTool(SculptTool.GRAB) })
                ToolChip("จุดบิด", onClick = { onTool(SculptTool.POINT) })
            }
            pinContent()
        } else {
            SculptToolPicker(tool, onTool, section) { section = it }

            when (section) {
                "เครื่องมือ" -> SculptSecTools(tool, meshRings, onRings, twistDeg, onTwist, warpSettings, onWarpSettings)
                "พู่กัน" -> SculptSecBrush(brushFrac, onBrush, warpSettings, onWarpSettings)
                "ตาข่าย" -> SculptSecMesh(clip, tool, meshRings, onRings, meshCell, onCell, warpSettings, onWarpSettings, onAdaptiveMesh, lockedMeshPoints, selectedMeshPoint, onToggleMeshPointLock, onClearMeshLocks, onResetMeshPoint, onApplyGrid, gc, gr, pc, pr, cellMax)
                "แอนิเมชัน" -> SculptSecAnim(clip, onTool, warpSettings, onWarpSettings, onCreateLoop)
                "ชั้นบิด" -> SculptSecLayers(clip, currentGrid, onCaptureLayer, onWarpLayers)
                "หน้ากาก" -> SculptSecMask(clip, onWarpLayers)
                "ฟิสิกส์" -> SculptSecPhysics(clip, onPhysics)
                "พรีเซ็ต" -> SculptSecPresets(warpSettings, onWarpSettings, customPresets, onSaveCustomPreset, onDeleteCustomPreset)
                "ความปลอดภัย" -> SculptSecSafety(warpSettings, onWarpSettings)
            }
            SculptHint(tool, limitDeg, twistOver, gc, gr, cellMin)
        }
    }
}

@Composable
private fun ColumnScope.SculptSecTools(
    tool: SculptTool, meshRings: Int, onRings: (Int) -> Unit, twistDeg: Float, onTwist: (Float) -> Unit,
    warpSettings: WarpSettings, onWarpSettings: (WarpSettings) -> Unit,
) {
    val c = StudioColors
    if (tool in setOf(SculptTool.MESH, SculptTool.TWIST, SculptTool.PINCH, SculptTool.BULGE, SculptTool.SPIRAL, SculptTool.WAVE, SculptTool.RIPPLE, SculptTool.SHEAR, SculptTool.PERSPECTIVE, SculptTool.PUSH, SculptTool.FLATTEN, SculptTool.GRAVITY, SculptTool.SMOOTH)) {
        SculptToolFieldsA(tool, meshRings, onRings, twistDeg, onTwist, warpSettings, onWarpSettings)
    } else {
        SculptToolFieldsB(tool, warpSettings, onWarpSettings)
    }
    if (tool in setOf(
            SculptTool.ARC_BEND, SculptTool.TAPER, SculptTool.RIGID_TRANSFORM, SculptTool.RIBBON_BEND,
            SculptTool.EDGE_SLIDE, SculptTool.CONTOUR_FLOW, SculptTool.FAN_DEFORM, SculptTool.ORIGAMI_FOLD,
            SculptTool.TOPOLOGY_REMAP, SculptTool.BOUNDARY_TENSION, SculptTool.VISCOUS_MELT,
            SculptTool.SEGMENT_OFFSET, SculptTool.ASYMMETRIC_WARP, SculptTool.DIRECTIONAL_COMPRESS,
            SculptTool.SURFACE_ROLL,
        )) {
        ToolChip("ใช้ตัวอย่างค่าแนะนำ", highlight = true, onClick = { onWarpSettings(recommendedWarpSettings(tool, warpSettings)) })
        Text("แตะสัญลักษณ์ตัวอย่างข้างช่องตัวเลขเพื่อดูภาพเปรียบเทียบค่าน้อย / ค่าปัจจุบัน / ค่ามาก แล้วเลือกใช้ค่าจากตัวอย่างได้", color = c.Sub, fontSize = 10.sp)
    }
    Text("ลากบนพื้นที่ภาพเพื่อใช้เครื่องมือ · ขนาดและแรงหลักปรับได้ในแท็บพู่กัน", color = c.Sub, fontSize = 11.sp)
}

@Composable
private fun ColumnScope.SculptToolFieldsA(
    tool: SculptTool, meshRings: Int, onRings: (Int) -> Unit, twistDeg: Float, onTwist: (Float) -> Unit,
    warpSettings: WarpSettings, onWarpSettings: (WarpSettings) -> Unit,
) {
    val c = StudioColors
    val patch: (WarpSettings.() -> WarpSettings) -> Unit = { edit -> onWarpSettings(warpSettings.edit()) }
    when (tool) {
        SculptTool.MESH -> SculptNumField("ระยะอิทธิพลรอบจุด (ช่อง)", meshRings.toFloat(), 0f, 6f, false, 150.dp) { onRings(it.roundToInt()) }
        SculptTool.TWIST -> SculptNumField("มุมบิดหมุน (°)", twistDeg, 1f, 720f, true, 150.dp) { onTwist(it) }
        SculptTool.PINCH, SculptTool.BULGE -> {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                SculptNumField("ขนาดวงแนวนอน (%)", warpSettings.scaleX, 10f, 400f, true, 120.dp) { patch { copy(scaleX = it) } }
                SculptNumField("ขนาดวงแนวตั้ง (%)", warpSettings.scaleY, 10f, 400f, true, 120.dp) { patch { copy(scaleY = it) } }
                SignedNumField("หมุนวง (°)", warpSettings.angleDeg, -360f, 360f, 110.dp) { patch { copy(angleDeg = it) } }
            }
            Text(if (tool == SculptTool.PINCH) "ลากเพื่อบีบจุดเข้าหาศูนย์กลาง" else "ลากเพื่อดันจุดออกจากศูนย์กลาง", color = c.Sub, fontSize = 11.sp)
        }
        SculptTool.SPIRAL -> SignedNumField("มุมเกลียว (°)", warpSettings.angleDeg, -720f, 720f, 140.dp) { patch { copy(angleDeg = it) } }
        SculptTool.WAVE, SculptTool.RIPPLE -> {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                SignedNumField("ทิศทาง (°)", warpSettings.angleDeg, -360f, 360f, 110.dp) { patch { copy(angleDeg = it) } }
                SculptNumField("ความถี่", warpSettings.frequency, 0.1f, 40f, true, 100.dp) { patch { copy(frequency = it) } }
            }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                SignedNumField("เฟส (°)", warpSettings.phaseDeg, -360f, 360f, 110.dp) { patch { copy(phaseDeg = it) } }
                SculptNumField("ความยาวคลื่น (px)", warpSettings.wavelengthPx, 2f, 2000f, true, 130.dp) { patch { copy(wavelengthPx = it) } }
            }
            Row(horizontalArrangement = Arrangement.spacedBy(5.dp)) {
                Text("รูปคลื่น", color = c.Sub, fontSize = 11.sp)
                listOf("Sine" to "ไซน์", "Triangle" to "สามเหลี่ยม", "Square" to "สี่เหลี่ยม").forEach { (type,label) -> ToolChip(label, highlight = warpSettings.waveType == type, onClick = { patch { copy(waveType = type) } }) }
            }
        }
        SculptTool.SHEAR, SculptTool.PERSPECTIVE -> {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                SignedNumField("ทิศทาง (°)", warpSettings.angleDeg, -360f, 360f, 110.dp) { patch { copy(angleDeg = it) } }
                SculptNumField("สเกลแนวนอน (%)", warpSettings.scaleX, 10f, 400f, true, 110.dp) { patch { copy(scaleX = it) } }
                SculptNumField("สเกลแนวตั้ง (%)", warpSettings.scaleY, 10f, 400f, true, 110.dp) { patch { copy(scaleY = it) } }
            }
        }
        SculptTool.PUSH -> SignedNumField("ทิศทางหลัก (°)", warpSettings.angleDeg, -360f, 360f, 140.dp) { patch { copy(angleDeg = it) } }
        SculptTool.FLATTEN, SculptTool.GRAVITY -> {
            SignedNumField("มุมทิศทาง (°)", warpSettings.angleDeg, -360f, 360f, 140.dp) { patch { copy(angleDeg = it) } }
            Text(if (tool == SculptTool.FLATTEN) "กำหนดแนวระนาบที่ต้องการให้พื้นผิวเรียบเข้าหา" else "กำหนดทิศทางที่ต้องการผลักพื้นผิวไป", color = c.Sub, fontSize = 11.sp)
        }
        SculptTool.SMOOTH -> SculptNumField("ความแรงการเกลี่ย (%)", warpSettings.strength, 0f, Float.MAX_VALUE, true, 150.dp) { patch { copy(strength = it) } }
        else -> {}
    }
}

@Composable
private fun ColumnScope.SculptToolFieldsB(
    tool: SculptTool, warpSettings: WarpSettings, onWarpSettings: (WarpSettings) -> Unit,
) {
    val c = StudioColors
    val patch: (WarpSettings.() -> WarpSettings) -> Unit = { edit -> onWarpSettings(warpSettings.edit()) }
    when (tool) {
        SculptTool.ARC_BEND -> {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                SculptNumField("ความแรงการบิด (%)", warpSettings.strength, 0f, 200f, true, 120.dp) { patch { copy(strength = it) } }
                SignedNumField("มุมดัด (°)", warpSettings.angleDeg, -360f, 360f, 110.dp) { patch { copy(angleDeg = it) } }
            }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                SculptNumField("ขนาดพู่กัน X (%)", warpSettings.scaleX, 10f, 400f, true, 125.dp) { patch { copy(scaleX = it) } }
                SculptNumField("ขนาดพู่กัน Y (%)", warpSettings.scaleY, 10f, 400f, true, 125.dp) { patch { copy(scaleY = it) } }
                SculptNumField("การลดแรงจากกลางสู่ขอบ (%)", warpSettings.falloff, 0f, 100f, true, 145.dp) { patch { copy(falloff = it) } }
            }
            Text("ตัวอย่าง: แรง 75% · มุม 25° · X 180% · Y 70% · ไล่แรง 80%", color = c.Sub, fontSize = 10.sp)
        }
        SculptTool.TAPER -> {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                SculptNumField("ความแรงการบิด (%)", warpSettings.strength, 0f, 200f, true, 120.dp) { patch { copy(strength = it) } }
                SignedNumField("ทิศเรียว (°)", warpSettings.angleDeg, -360f, 360f, 110.dp) { patch { copy(angleDeg = it) } }
                SculptNumField("ระดับความเรียว", warpSettings.frequency, 0.1f, 10f, true, 100.dp) { patch { copy(frequency = it) } }
            }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                SculptNumField("ขนาดพู่กัน X (%)", warpSettings.scaleX, 10f, 400f, true, 125.dp) { patch { copy(scaleX = it) } }
                SculptNumField("ขนาดพู่กัน Y (%)", warpSettings.scaleY, 10f, 400f, true, 125.dp) { patch { copy(scaleY = it) } }
            }
            Text("ตัวอย่าง: แรง 90% · ทิศ 0° · ระดับความเรียว 2 · X 140% · Y 65%", color = c.Sub, fontSize = 10.sp)
        }
        SculptTool.RIGID_TRANSFORM -> {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                SculptNumField("ความแรงการบิด (%)", warpSettings.strength, 0f, 200f, true, 120.dp) { patch { copy(strength = it) } }
                SignedNumField("มุมหมุน (°)", warpSettings.angleDeg, -180f, 180f, 110.dp) { patch { copy(angleDeg = it) } }
            }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                SculptNumField("ขนาดพู่กัน X (%)", warpSettings.scaleX, 10f, 400f, true, 125.dp) { patch { copy(scaleX = it) } }
                SculptNumField("ขนาดพู่กัน Y (%)", warpSettings.scaleY, 10f, 400f, true, 125.dp) { patch { copy(scaleY = it) } }
                SculptNumField("การลดแรงจากกลางสู่ขอบ (%)", warpSettings.falloff, 0f, 100f, true, 145.dp) { patch { copy(falloff = it) } }
            }
            Text("ตัวอย่าง: แรง 65% · หมุน 30° · X/Y 110% · ไล่แรง 100%", color = c.Sub, fontSize = 10.sp)
        }
        SculptTool.RIBBON_BEND -> {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                SculptNumField("ความแรงการบิด (%)", warpSettings.strength, 0f, 200f, true, 120.dp) { patch { copy(strength = it) } }
                SignedNumField("แนวริบบิ้น (°)", warpSettings.angleDeg, -360f, 360f, 110.dp) { patch { copy(angleDeg = it) } }
            }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                SculptNumField("ขนาดพู่กัน X (%)", warpSettings.scaleX, 10f, 400f, true, 125.dp) { patch { copy(scaleX = it) } }
                SculptNumField("ขนาดพู่กัน Y (%)", warpSettings.scaleY, 10f, 400f, true, 125.dp) { patch { copy(scaleY = it) } }
            }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                SculptNumField("จำนวนรอบริบบิ้น", warpSettings.frequency, 0.1f, 20f, true, 100.dp) { patch { copy(frequency = it) } }
                SculptNumField("ความยาวริบบิ้น (px)", warpSettings.wavelengthPx, 2f, 2000f, true, 130.dp) { patch { copy(wavelengthPx = it) } }
                SignedNumField("เฟสริบบิ้น (°)", warpSettings.phaseDeg, -360f, 360f, 100.dp) { patch { copy(phaseDeg = it) } }
            }
            Text("ตัวอย่าง: แรง 80% · X 250% · Y 35% · 1 รอบ · ความยาว 180 px", color = c.Sub, fontSize = 10.sp)
        }
        SculptTool.EDGE_SLIDE -> {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                SculptNumField("ความแรงการบิด (%)", warpSettings.strength, 0f, 200f, true, 120.dp) { patch { copy(strength = it) } }
                SignedNumField("ทิศเลื่อน (°)", warpSettings.angleDeg, -360f, 360f, 110.dp) { patch { copy(angleDeg = it) } }
            }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                SculptNumField("ป้องกันขอบภาพ (%)", warpSettings.edgeProtection, 0f, 100f, true, 125.dp) { patch { copy(edgeProtection = it) } }
                SculptNumField("ความแข็งขอบพู่กัน (%)", warpSettings.hardness, 0f, 95f, true, 135.dp) { patch { copy(hardness = it) } }
                SculptNumField("การลดแรงจากกลางสู่ขอบ (%)", warpSettings.falloff, 0f, 100f, true, 145.dp) { patch { copy(falloff = it) } }
            }
            Text("ตัวอย่าง: แรง 50% · มุม 90° · ป้องกันขอบ 60% · ความแข็ง 20%", color = c.Sub, fontSize = 10.sp)
        }
        SculptTool.CONTOUR_FLOW -> {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                SculptNumField("ความแรงการบิด (%)", warpSettings.strength, 0f, 200f, true, 120.dp) { patch { copy(strength = it) } }
                SignedNumField("ทิศไหล (°)", warpSettings.angleDeg, -360f, 360f, 110.dp) { patch { copy(angleDeg = it) } }
            }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                SculptNumField("จำนวนริ้วไหล", warpSettings.frequency, 0.1f, 20f, true, 100.dp) { patch { copy(frequency = it) } }
                SculptNumField("ระยะไหล (px)", warpSettings.wavelengthPx, 2f, 2000f, true, 130.dp) { patch { copy(wavelengthPx = it) } }
                SignedNumField("เฟสไหล (°)", warpSettings.phaseDeg, -360f, 360f, 100.dp) { patch { copy(phaseDeg = it) } }
            }
            Text("ตัวอย่าง: แรง 60% · 2 ริ้ว · ระยะ 120 px · เฟส 90°", color = c.Sub, fontSize = 10.sp)
        }
        SculptTool.FAN_DEFORM -> {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                SculptNumField("ความแรงการบิด (%)", warpSettings.strength, 0f, 200f, true, 120.dp) { patch { copy(strength = it) } }
                SignedNumField("แนวพัด (°)", warpSettings.angleDeg, -360f, 360f, 110.dp) { patch { copy(angleDeg = it) } }
                SculptNumField("จำนวนริ้วพัด", warpSettings.frequency, 1f, 24f, true, 100.dp) { patch { copy(frequency = it) } }
            }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                SignedNumField("เฟสพัด (°)", warpSettings.phaseDeg, -360f, 360f, 100.dp) { patch { copy(phaseDeg = it) } }
                SculptNumField("ขนาดพู่กัน X (%)", warpSettings.scaleX, 10f, 400f, true, 125.dp) { patch { copy(scaleX = it) } }
                SculptNumField("ขนาดพู่กัน Y (%)", warpSettings.scaleY, 10f, 400f, true, 125.dp) { patch { copy(scaleY = it) } }
            }
            Text("ตัวอย่าง: แรง 75% · ความถี่ 5 กลีบ · เฟส 0° · X/Y 100%", color = c.Sub, fontSize = 10.sp)
        }
        SculptTool.ORIGAMI_FOLD -> {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                SculptNumField("ความแรงการบิด (%)", warpSettings.strength, 0f, 200f, true, 120.dp) { patch { copy(strength = it) } }
                SignedNumField("แนวพับ (°)", warpSettings.angleDeg, -360f, 360f, 110.dp) { patch { copy(angleDeg = it) } }
            }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                SculptNumField("ความแข็งขอบพู่กัน (%)", warpSettings.hardness, 0f, 95f, true, 135.dp) { patch { copy(hardness = it) } }
                SculptNumField("การลดแรงจากกลางสู่ขอบ (%)", warpSettings.falloff, 0f, 100f, true, 145.dp) { patch { copy(falloff = it) } }
                SculptNumField("ระยะบิดเพิ่มเติม (% รัศมี)", warpSettings.maxDeformation, 0f, 150f, true, 160.dp) { patch { copy(maxDeformation = it) } }
            }
            Text("ตัวอย่าง: แรง 65% · แนวพับ 45° · ความแข็ง 65% · ไล่แรง 80%", color = c.Sub, fontSize = 10.sp)
        }
        SculptTool.TOPOLOGY_REMAP -> {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                SculptNumField("ความแรงการบิด (%)", warpSettings.strength, 0f, 200f, true, 120.dp) { patch { copy(strength = it) } }
                SculptNumField("ความถี่ตาราง", warpSettings.frequency, 0.1f, 20f, true, 100.dp) { patch { copy(frequency = it) } }
                SculptNumField("ขนาดเซลล์รีแมป (px)", warpSettings.wavelengthPx, 2f, 2000f, true, 130.dp) { patch { copy(wavelengthPx = it) } }
            }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                SignedNumField("เฟสตาราง (°)", warpSettings.phaseDeg, -360f, 360f, 100.dp) { patch { copy(phaseDeg = it) } }
                SculptNumField("คลายตาข่าย (%)", warpSettings.meshSmoothing, 0f, 100f, true, 130.dp) { patch { copy(meshSmoothing = it) } }
            }
            Text("ตัวอย่าง: แรง 45% · ความถี่ตาราง 3 · เซลล์ 70 px · เฟส 30° · คลายตาข่าย 15%", color = c.Sub, fontSize = 10.sp)
        }
        SculptTool.BOUNDARY_TENSION -> {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                SculptNumField("ความแรงการบิด (%)", warpSettings.strength, 0f, 200f, true, 120.dp) { patch { copy(strength = it) } }
                SculptNumField("ป้องกันขอบภาพ (%)", warpSettings.edgeProtection, 0f, 100f, true, 125.dp) { patch { copy(edgeProtection = it) } }
            }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                SculptNumField("ความแข็งขอบพู่กัน (%)", warpSettings.hardness, 0f, 95f, true, 135.dp) { patch { copy(hardness = it) } }
                SculptNumField("ความนุ่มของผลบิด (%)", warpSettings.smoothness, 0f, 100f, true, 130.dp) { patch { copy(smoothness = it) } }
                SculptNumField("ระยะบิดเพิ่มเติม (% รัศมี)", warpSettings.maxDeformation, 0f, 150f, true, 160.dp) { patch { copy(maxDeformation = it) } }
            }
            Text("ตัวอย่าง: แรง 60% · ป้องกันขอบ 80% · ความแข็ง 30% · ความนุ่ม 70%", color = c.Sub, fontSize = 10.sp)
        }
        SculptTool.VISCOUS_MELT -> {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                SculptNumField("ความแรงการบิด (%)", warpSettings.strength, 0f, 200f, true, 120.dp) { patch { copy(strength = it) } }
                SignedNumField("ทิศละลาย (°)", warpSettings.angleDeg, -360f, 360f, 110.dp) { patch { copy(angleDeg = it) } }
            }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                SculptNumField("การลดแรงจากกลางสู่ขอบ (%)", warpSettings.falloff, 0f, 100f, true, 145.dp) { patch { copy(falloff = it) } }
                SculptNumField("ปริมาณผลต่อครั้ง (%)", warpSettings.flow, 0f, 100f, true, 130.dp) { patch { copy(flow = it) } }
                SculptNumField("ระยะละลายหนืด (px)", warpSettings.wavelengthPx, 2f, 2000f, true, 130.dp) { patch { copy(wavelengthPx = it) } }
            }
            Text("ตัวอย่าง: แรง 80% · ทิศ 90° ลง · ไล่แรง 70% · ปริมาณ 60% · 100 px", color = c.Sub, fontSize = 10.sp)
        }
        SculptTool.SEGMENT_OFFSET -> {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                SculptNumField("ความแรงการบิด (%)", warpSettings.strength, 0f, 200f, true, 120.dp) { patch { copy(strength = it) } }
                SignedNumField("แนวแถบ (°)", warpSettings.angleDeg, -360f, 360f, 110.dp) { patch { copy(angleDeg = it) } }
            }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                SculptNumField("ความกว้างช่วง (px)", warpSettings.wavelengthPx, 2f, 2000f, true, 130.dp) { patch { copy(wavelengthPx = it) } }
                SculptNumField("จำนวนแถบต่อช่วง", warpSettings.frequency, 0.1f, 20f, true, 100.dp) { patch { copy(frequency = it) } }
                SignedNumField("เฟสแถบ (°)", warpSettings.phaseDeg, -360f, 360f, 100.dp) { patch { copy(phaseDeg = it) } }
            }
            Text("ตัวอย่าง: แรง 80% · มุม 0° · ช่วง 24 px · 6 แถบต่อช่วง · เฟส 0°", color = c.Sub, fontSize = 10.sp)
        }
        SculptTool.ASYMMETRIC_WARP -> {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                SculptNumField("ความแรงการบิด (%)", warpSettings.strength, 0f, 200f, true, 120.dp) { patch { copy(strength = it) } }
                SignedNumField("แกนบิดไม่สมมาตร (°)", warpSettings.angleDeg, -360f, 360f, 110.dp) { patch { copy(angleDeg = it) } }
            }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                SculptNumField("ขนาดพู่กัน X (%)", warpSettings.scaleX, 10f, 400f, true, 125.dp) { patch { copy(scaleX = it) } }
                SculptNumField("ขนาดพู่กัน Y (%)", warpSettings.scaleY, 10f, 400f, true, 125.dp) { patch { copy(scaleY = it) } }
                SignedNumField("อคติซ้าย/ขวา (°)", warpSettings.phaseDeg, -360f, 360f, 100.dp) { patch { copy(phaseDeg = it) } }
            }
            SculptNumField("การลดแรงจากกลางสู่ขอบ (%)", warpSettings.falloff, 0f, 100f, true, 145.dp) { patch { copy(falloff = it) } }
            Text("ตัวอย่าง: แรง 65% · X 160% · Y 80% · อคติซ้าย/ขวา 90° · ไล่แรง 75%", color = c.Sub, fontSize = 10.sp)
        }
        SculptTool.DIRECTIONAL_COMPRESS -> {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                SculptNumField("ความแรงการบิด (%)", warpSettings.strength, 0f, 200f, true, 120.dp) { patch { copy(strength = it) } }
                SignedNumField("แกนบีบ (°)", warpSettings.angleDeg, -360f, 360f, 110.dp) { patch { copy(angleDeg = it) } }
            }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                SculptNumField("ขนาดพู่กัน X (%)", warpSettings.scaleX, 10f, 400f, true, 125.dp) { patch { copy(scaleX = it) } }
                SculptNumField("ขนาดพู่กัน Y (%)", warpSettings.scaleY, 10f, 400f, true, 125.dp) { patch { copy(scaleY = it) } }
                SculptNumField("ความนุ่มของผลบิด (%)", warpSettings.smoothness, 0f, 100f, true, 130.dp) { patch { copy(smoothness = it) } }
            }
            Text("ตัวอย่าง: แรง 70% · แนวบีบ 0° · ขนาด X/Y 100% · ความนุ่ม 70%", color = c.Sub, fontSize = 10.sp)
        }
        SculptTool.SURFACE_ROLL -> {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                SculptNumField("ความแรงการบิด (%)", warpSettings.strength, 0f, 200f, true, 120.dp) { patch { copy(strength = it) } }
                SignedNumField("แกนม้วน (°)", warpSettings.angleDeg, -360f, 360f, 110.dp) { patch { copy(angleDeg = it) } }
            }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                SculptNumField("รัศมีม้วน (px)", warpSettings.wavelengthPx, 2f, 2000f, true, 130.dp) { patch { copy(wavelengthPx = it) } }
                SculptNumField("จำนวนรอบม้วน", warpSettings.frequency, 0.1f, 8f, true, 100.dp) { patch { copy(frequency = it) } }
                SculptNumField("การลดแรงจากกลางสู่ขอบ (%)", warpSettings.falloff, 0f, 100f, true, 145.dp) { patch { copy(falloff = it) } }
            }
            Text("ตัวอย่าง: แรง 70% · รัศมี 120 px · 1 รอบม้วน · ไล่แรง 60%", color = c.Sub, fontSize = 10.sp)
        }
        SculptTool.MASK -> Text("ลากเพื่อระบายสีขาวให้ชั้นบิดมีผลมากขึ้น · เปิดตัวเลือกกลับทิศในแท็บความปลอดภัยเพื่อลบหน้ากาก", color = c.Sub, fontSize = 11.sp)
        SculptTool.INFLATE, SculptTool.DEFLATE, SculptTool.CREASE, SculptTool.ELASTIC, SculptTool.MAGNET -> Text(
            when (tool) {
                SculptTool.INFLATE -> "พองพื้นผิวออกจากจุดศูนย์กลาง"
                SculptTool.DEFLATE -> "ยุบพื้นผิวเข้าหาศูนย์กลาง"
                SculptTool.CREASE -> "สร้างรอยพับโดยรวมจุดเข้าหาแนวกลาง"
                SculptTool.ELASTIC -> "เพิ่มแรงยืดหยุ่นให้การขยายตัว"
                else -> "ดูดจุดตาข่ายเข้าหาศูนย์กลางพู่กัน"
            }, color = c.Sub, fontSize = 11.sp)
        else -> Text(
            when (tool) {
                SculptTool.GRAB -> "ลากบนภาพเพื่อดึงบริเวณรอบจุดที่แตะ"
                SculptTool.MESH -> "แตะใกล้จุดตาข่าย แล้วลากเพื่อย้ายจุดและวงข้างเคียง"
                SculptTool.TWIST -> "แตะกำหนดศูนย์กลาง แล้วลากซ้าย/ขวาเพื่อหมุน"
                SculptTool.POINT -> "แตะพื้นที่ว่างเพื่อเพิ่มจุดบิด และลากจุดเพื่อบิดภาพเฉพาะวง"
                else -> "เลือกเครื่องมือบิดเพื่อกำหนดพารามิเตอร์เฉพาะเครื่องมือ"
            }, color = c.Sub, fontSize = 11.sp,
        )
    }
}

@Composable
private fun ColumnScope.SculptSecBrush(
    brushFrac: Float, onBrush: (Float) -> Unit, warpSettings: WarpSettings, onWarpSettings: (WarpSettings) -> Unit,
) {
    val c = StudioColors
    val patch: (WarpSettings.() -> WarpSettings) -> Unit = { edit -> onWarpSettings(warpSettings.edit()) }
    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        SculptNumField("ความแรงการบิด (%)", warpSettings.strength, 0f, 200f, true, 140.dp) { patch { copy(strength = it) } }
        SculptNumField("รัศมี (%)", brushFrac * 100f, 5f, 100f, true, 110.dp) { onBrush(it / 100f) }
        SignedNumField("มุมพู่กัน (°)", warpSettings.angleDeg, -360f, 360f, 110.dp) { patch { copy(angleDeg = it) } }
    }
    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        SculptNumField("ขนาดพู่กัน X (%)", warpSettings.scaleX, 10f, 400f, true, 130.dp) { patch { copy(scaleX = it) } }
        SculptNumField("ขนาดพู่กัน Y (%)", warpSettings.scaleY, 10f, 400f, true, 130.dp) { patch { copy(scaleY = it) } }
    }
    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        SculptNumField("การลดแรงจากกลางสู่ขอบ (%)", warpSettings.falloff, 0f, 100f, true, 110.dp) { patch { copy(falloff = it) } }
        SculptNumField("ความแข็งขอบพู่กัน (%)", warpSettings.hardness, 0f, 95f, true, 110.dp) { patch { copy(hardness = it) } }
        SculptNumField("ความนุ่มของผลบิด (%)", warpSettings.smoothness, 0f, 100f, true, 120.dp) { patch { copy(smoothness = it) } }
    }
    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        SculptNumField("แรงกดจำลอง (%)", warpSettings.pressure, 0f, 100f, true, 110.dp) { patch { copy(pressure = it) } }
        SculptNumField("เส้นโค้งแรงกด", warpSettings.pressureCurve, 0.25f, 3f, true, 110.dp) { patch { copy(pressureCurve = it) } }
        SculptNumField("ปริมาณผลต่อครั้ง (%)", warpSettings.flow, 0f, 100f, true, 100.dp) { patch { copy(flow = it) } }
    }
    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        SculptNumField("ความหนาแน่น (%)", warpSettings.density, 0f, 100f, true, 110.dp) { patch { copy(density = it) } }
        SculptNumField("ลดอาการมือสั่น (%)", warpSettings.stabilizer, 0f, 100f, true, 110.dp) { patch { copy(stabilizer = it) } }
        SculptNumField("ระยะห่างจุดระบายหน้ากาก (%)", warpSettings.spacing, -Float.MAX_VALUE, Float.MAX_VALUE, true, 120.dp) { patch { copy(spacing = it) } }
    }
    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        SculptNumField("ความทึบ/แรงรวม (%)", warpSettings.opacity, 0f, 100f, true, 120.dp) { patch { copy(opacity = it) } }
        SculptNumField("คลายตาข่าย (%)", warpSettings.meshSmoothing, 0f, 100f, true, 120.dp) { patch { copy(meshSmoothing = it) } }
    }
    Row(verticalAlignment = Alignment.CenterVertically) {
        Checkbox(checked = warpSettings.accumulate, onCheckedChange = { patch { copy(accumulate = it) } })
        Text("สะสมแรงตามระยะลาก", color = c.Ink, fontSize = 12.sp)
    }
    SculptNumField("ระยะบิดเพิ่มเติม (% รัศมี)", warpSettings.maxDeformation, 0f, Float.MAX_VALUE, true, 190.dp) { patch { copy(maxDeformation = it) } }
    Text("รูปทรงหัวพู่กัน", color = c.Sub, fontSize = 11.sp, fontWeight = FontWeight.SemiBold)
    Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(5.dp)) {
        listOf("วงกลม", "วงรี", "สี่เหลี่ยม", "เพชร", "เส้นแนวนอน", "เส้นแนวตั้ง").forEach { shape ->
            ToolChip(shape, highlight = warpSettings.brushShape == shape, onClick = { patch { copy(brushShape = shape) } })
        }
    }
    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(9.dp)) {
        Box(Modifier.size(58.dp, 38.dp).background(c.Panel, RoundedCornerShape(8.dp)).drawWithContent {
            drawContent()
            val cx = size.width / 2f; val cy = size.height / 2f
            val pw = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = android.graphics.Color.rgb(255, 170, 45); style = Paint.Style.STROKE; strokeWidth = 2f }
            val nx = size.width * 0.34f; val ny = size.height * 0.34f
            val cv = drawContext.canvas.nativeCanvas
            cv.save(); cv.rotate(warpSettings.angleDeg, cx, cy)
            when (warpSettings.brushShape) {
                "วงรี" -> cv.drawOval(android.graphics.RectF(cx - nx * 1.5f, cy - ny * 0.75f, cx + nx * 1.5f, cy + ny * 0.75f), pw)
                "สี่เหลี่ยม" -> cv.drawRect(cx - nx, cy - ny, cx + nx, cy + ny, pw)
                "เพชร" -> cv.drawPath(android.graphics.Path().apply { moveTo(cx,cy-ny); lineTo(cx+nx,cy); lineTo(cx,cy+ny); lineTo(cx-nx,cy); close() }, pw)
                "เส้นแนวนอน" -> cv.drawRect(cx-nx,cy-ny*0.4f,cx+nx,cy+ny*0.4f,pw)
                "เส้นแนวตั้ง" -> cv.drawRect(cx-nx*0.4f,cy-ny,cx+nx*0.4f,cy+ny,pw)
                else -> cv.drawOval(android.graphics.RectF(cx-nx,cy-ny,cx+nx,cy+ny),pw)
            }
            cv.restore()
        })
        Text("ตัวอย่างหัวพู่กัน: ${warpSettings.brushShape}", color = c.Sub, fontSize = 11.sp)
    }
    Text("พลวัตแรงพู่กัน", color = c.Sub, fontSize = 11.sp, fontWeight = FontWeight.SemiBold)
    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        SculptNumField("แรงเริ่มต้น (%)", warpSettings.startForce, -Float.MAX_VALUE, Float.MAX_VALUE, true, 110.dp) { patch { copy(startForce = it) } }
        SculptNumField("แรงตอนปล่อย (%)", warpSettings.endForce, -Float.MAX_VALUE, Float.MAX_VALUE, true, 110.dp) { patch { copy(endForce = it) } }
    }
    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        SculptNumField("ตอบสนองระยะลาก (%)", warpSettings.distanceResponse, -Float.MAX_VALUE, Float.MAX_VALUE, true, 130.dp) { patch { copy(distanceResponse = it) } }
        SculptNumField("สุ่มแรง (%)", warpSettings.forceJitter, -Float.MAX_VALUE, Float.MAX_VALUE, true, 110.dp) { patch { copy(forceJitter = it) } }
        SculptNumField("สุ่มขนาด (%)", warpSettings.sizeJitter, -Float.MAX_VALUE, Float.MAX_VALUE, true, 110.dp) { patch { copy(sizeJitter = it) } }
    }
    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        SculptNumField("สุ่มมุม (°)", warpSettings.angleJitter, -Float.MAX_VALUE, Float.MAX_VALUE, true, 110.dp) { patch { copy(angleJitter = it) } }
    }
    Text("การทำงาน: ตัวกันมือสั่นจะกรองเส้นทางลากจริงโดยเพิ่มระยะหน่วงเมื่อปรับค่าสูง · รูปทรงหัวพู่กันเปลี่ยนพื้นที่อิทธิพลจริง · การสุ่มแรง/ขนาด/มุมใช้ค่า noise แบบคงที่ตามจุดตาข่ายเพื่อไม่ให้ภาพกระพริบ · แรงเริ่มต้นและแรงปลายทางคำนวณตามระยะลาก · ค่าที่กรอกไม่ถูกตัดช่วง", color = c.Sub, fontSize = 10.sp)
}

@Composable
private fun ColumnScope.SculptSecMesh(
    clip: StudioImage, tool: SculptTool, meshRings: Int, onRings: (Int) -> Unit, meshCell: Float?, onCell: (Float?) -> Unit,
    warpSettings: WarpSettings, onWarpSettings: (WarpSettings) -> Unit, onAdaptiveMesh: (Boolean) -> Unit,
    lockedMeshPoints: Set<Int>, selectedMeshPoint: Int, onToggleMeshPointLock: (Int) -> Unit, onClearMeshLocks: () -> Unit,
    onResetMeshPoint: (Int) -> Unit, onApplyGrid: () -> Unit, gc: Int, gr: Int, pc: Int, pr: Int, cellMax: Float,
) {
    val c = StudioColors
    val patch: (WarpSettings.() -> WarpSettings) -> Unit = { edit -> onWarpSettings(warpSettings.edit()) }
    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        SculptNumField("จำนวนช่องแนวนอน", if (warpSettings.meshCols > 0) warpSettings.meshCols.toFloat() else pc.toFloat(), 4f, 40f, false, 110.dp) { patch { copy(meshCols = it.roundToInt()) } }
        SculptNumField("จำนวนช่องแนวตั้ง", if (warpSettings.meshRows > 0) warpSettings.meshRows.toFloat() else pr.toFloat(), 4f, 40f, false, 110.dp) { patch { copy(meshRows = it.roundToInt()) } }
        SculptNumField("ขนาดช่อง (px)", meshCell ?: cellMax, Sculpt.CELL_MIN, Sculpt.CELL_MAX, false, 110.dp) { v -> onWarpSettings(warpSettings.copy(meshCols = 0, meshRows = 0)); onCell(v) }
    }
    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
        ToolChip("X อัตโนมัติ", enabled = warpSettings.meshCols != 0, onClick = { patch { copy(meshCols = 0) } })
        ToolChip("Y อัตโนมัติ", enabled = warpSettings.meshRows != 0, onClick = { patch { copy(meshRows = 0) } })
        ToolChip("ขนาดช่องอัตโนมัติ", enabled = meshCell != null, onClick = { onCell(null) })
        ToolChip("ปรับใช้ $pc×$pr", highlight = true, enabled = !clip.locked && (pc != gc || pr != gr), onClick = onApplyGrid)
    }
    Row(verticalAlignment = Alignment.CenterVertically) {
        Checkbox(checked = clip.rig.adaptive, onCheckedChange = onAdaptiveMesh)
        Text("เพิ่มความละเอียดตาข่ายรอบหมุดข้อต่ออัตโนมัติ", color = c.Ink, fontSize = 12.sp)
    }
    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        SculptNumField("ระยะจุดขั้นต่ำ (px)", warpSettings.minPointDistance, 0f, 500f, true, 130.dp) { patch { copy(minPointDistance = it) } }
    }
    Text("ตารางปัจจุบัน $gc×$gr · ตารางเป้าหมาย $pc×$pr · ช่องกรอกไม่ตัดค่าตัวเลข · ช่องเล็กลง = รายละเอียดสูงขึ้นและใช้ทรัพยากรมากขึ้น", color = c.Sub, fontSize = 11.sp)
    if (tool == SculptTool.MESH) {
        SculptNumField("ระยะอิทธิพลรอบจุด (ช่อง)", meshRings.toFloat(), 0f, 6f, false, 150.dp) { onRings(it.roundToInt()) }
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.CenterVertically) {
            Text(if (selectedMeshPoint >= 0) "จุดที่เลือก #${selectedMeshPoint + 1}" else "ยังไม่ได้เลือกจุด", color = c.Sub, fontSize = 11.sp)
            ToolChip(if (selectedMeshPoint in lockedMeshPoints) "ปลดล็อกจุด" else "ล็อกจุด", enabled = selectedMeshPoint >= 0, onClick = { if (selectedMeshPoint >= 0) onToggleMeshPointLock(selectedMeshPoint) })
            ToolChip("รีเซ็ตจุด", enabled = selectedMeshPoint >= 0 && !clip.locked, onClick = { if (selectedMeshPoint >= 0) onResetMeshPoint(selectedMeshPoint) })
            ToolChip("ปลดล็อกทั้งหมด", enabled = lockedMeshPoints.isNotEmpty(), onClick = onClearMeshLocks)
        }
    }
}

@Composable
private fun ColumnScope.SculptSecAnim(
    clip: StudioImage, onTool: (SculptTool) -> Unit, warpSettings: WarpSettings, onWarpSettings: (WarpSettings) -> Unit, onCreateLoop: () -> Unit,
) {
    val c = StudioColors
    val patch: (WarpSettings.() -> WarpSettings) -> Unit = { edit -> onWarpSettings(warpSettings.edit()) }
    Row(verticalAlignment = Alignment.CenterVertically) {
        Checkbox(checked = warpSettings.autoKeyframe, onCheckedChange = { patch { copy(autoKeyframe = it) } })
        Text("สร้างคีย์เฟรมอัตโนมัติ ณ ตำแหน่งเส้นเวลา", color = c.Ink, fontSize = 12.sp)
    }
    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        SculptNumField("ระยะเวลาต่อรอบ (วินาที)", warpSettings.loopDuration, 0.1f, 30f, true, 140.dp) { patch { copy(loopDuration = it) } }
        SculptNumField("หน่วงก่อนเริ่ม (วินาที)", warpSettings.deformationDelay, 0f, 30f, true, 140.dp) { patch { copy(deformationDelay = it) } }
        SculptNumField("ความเร็ว (×)", warpSettings.warpSpeed, 0.1f, 5f, true, 100.dp) { patch { copy(warpSpeed = it) } }
    }
    Row(verticalAlignment = Alignment.CenterVertically) {
        Checkbox(checked = warpSettings.followMotion, onCheckedChange = { patch { copy(followMotion = it) } })
        Text("ให้ท่าบิดเปลี่ยนตามคีย์เฟรม", color = c.Ink, fontSize = 12.sp)
    }
    SculptNumField("ความแรงการเปลี่ยนท่าบิด (%)", warpSettings.motionStrength, 0f, 100f, true, 170.dp) { patch { copy(motionStrength = it) } }
    Text("รูปแบบการเปลี่ยนผ่านระหว่างคีย์เฟรม", color = c.Sub, fontSize = 11.sp)
    Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(5.dp)) {
        listOf("Linear" to "เส้นตรง", "Smooth" to "นุ่มนวล", "Ease In" to "ค่อยเริ่ม", "Ease Out" to "ค่อยจบ", "Bezier" to "เส้นโค้ง").forEach { (mode,label) -> ToolChip(label, highlight = warpSettings.interpolation == mode, onClick = { patch { copy(interpolation = mode) } }) }
    }
    Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(5.dp)) {
        ToolChip("พรีเซ็ตนุ่ม", onClick = { onWarpSettings(warpSettings.copy(strength = 40f, falloff = 85f, hardness = 0f, smoothness = 90f, pressure = 75f, maxDeformation = 35f)) })
        ToolChip("พรีเซ็ตแรง", onClick = { onWarpSettings(warpSettings.copy(strength = 150f, falloff = 55f, hardness = 25f, smoothness = 45f, pressure = 100f, maxDeformation = 120f)) })
        ToolChip("พรีเซ็ตน้ำ", onClick = { onTool(SculptTool.RIPPLE); onWarpSettings(warpSettings.copy(strength = 75f, frequency = 5f, wavelengthPx = 60f, waveType = "Sine")) })
    }
    ToolChip("สร้างคีย์เฟรมวนบิดจนจบคลิป", enabled = !clip.locked, highlight = true, onClick = onCreateLoop)
    Text("หากมีคีย์เฟรมอยู่แล้ว ระบบจะบันทึกท่าตามตำแหน่งเส้นเวลา และสลับระหว่างท่าปัจจุบันกับท่าตรงจนจบคลิป", color = c.Sub, fontSize = 11.sp)
}

@Composable
private fun ColumnScope.SculptSecLayers(
    clip: StudioImage, currentGrid: SculptGrid?, onCaptureLayer: () -> Unit, onWarpLayers: (List<WarpLayer>) -> Unit,
) {
    val c = StudioColors
    Text("ชั้นบิดแบบไม่ทำลายต้นฉบับ", color = c.Ink, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
    Text("แต่ละชั้นเก็บรูปทรงแยกกัน เปิด/ปิด ปรับความทึบ และเลือกวิธีผสมได้ ชั้นจะถูกบันทึกไปกับโปรเจกต์", color = c.Sub, fontSize = 11.sp)
    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
        ToolChip("สร้างชั้นจากท่าปัจจุบัน", highlight = true, enabled = !clip.locked && currentGrid != null && clip.keyframes.none { it.sculpt != null }, onClick = onCaptureLayer)
        ToolChip("ลบชั้นที่ปิดทั้งหมด", enabled = !clip.locked && clip.warpLayers.any { !it.enabled }, onClick = { onWarpLayers(clip.warpLayers.filter { it.enabled }) })
    }
    if (clip.warpLayers.isEmpty()) Text("ยังไม่มีชั้นบิด · สร้างจากท่าปัจจุบันหลังจากบิดภาพแล้ว", color = c.Sub, fontSize = 11.sp)
    clip.warpLayers.forEachIndexed { index, layer ->
        Column(Modifier.fillMaxWidth().background(c.Panel2, RoundedCornerShape(10.dp)).padding(8.dp), verticalArrangement = Arrangement.spacedBy(5.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                Checkbox(checked = layer.enabled, onCheckedChange = { v -> onWarpLayers(clip.warpLayers.toMutableList().also { it[index] = layer.copy(enabled = v) }) })
                Text(layer.name, color = c.Ink, fontSize = 12.sp, modifier = Modifier.weight(1f))
                ToolChip("ขึ้น", enabled = index > 0, onClick = { onWarpLayers(clip.warpLayers.toMutableList().also { val a=it[index-1]; it[index-1]=it[index]; it[index]=a }) })
                ToolChip("ลง", enabled = index < clip.warpLayers.lastIndex, onClick = { onWarpLayers(clip.warpLayers.toMutableList().also { val a=it[index+1]; it[index+1]=it[index]; it[index]=a }) })
                ToolChip(if (layer.locked) "ปลดล็อก" else "ล็อก", onClick = { onWarpLayers(clip.warpLayers.toMutableList().also { it[index] = layer.copy(locked = !layer.locked) }) })
                ToolChip("ลบ", enabled = !layer.locked, onClick = { onWarpLayers(clip.warpLayers.filterIndexed { i, _ -> i != index }) })
            }
            Text("ความทึบ ${"%.0f".format(java.util.Locale.US, layer.opacity * 100f)}%", color = c.Sub, fontSize = 10.sp)
            Slider(value = layer.opacity.coerceIn(0f,1f), onValueChange = { v -> onWarpLayers(clip.warpLayers.toMutableList().also { it[index] = layer.copy(opacity = v) }) })
            Row(horizontalArrangement = Arrangement.spacedBy(5.dp)) {
                listOf(WarpBlendMode.ADD to "บวก", WarpBlendMode.SUBTRACT to "ลบ", WarpBlendMode.REPLACE to "แทนที่", WarpBlendMode.MULTIPLY to "คูณ").forEach { (mode,label) ->
                    ToolChip(label, highlight = layer.blend == mode, onClick = { onWarpLayers(clip.warpLayers.toMutableList().also { it[index] = layer.copy(blend = mode) }) })
                }
            }
            Row(horizontalArrangement = Arrangement.spacedBy(5.dp)) {
                ToolChip(if (layer.mask == null) "สร้างหน้ากากเต็ม" else "กลับหน้ากาก", onClick = {
                    val nextMask = layer.mask?.let { mask -> WarpMask(mask.cols, mask.rows, FloatArray(mask.weights.size) { 1f - mask.weight(it) }) }
                        ?: WarpMask.full(layer.grid.cols, layer.grid.rows)
                    onWarpLayers(clip.warpLayers.toMutableList().also { it[index] = layer.copy(mask = nextMask) })
                })
                ToolChip("ล้างหน้ากาก", enabled = layer.mask != null, onClick = { onWarpLayers(clip.warpLayers.toMutableList().also { it[index] = layer.copy(mask = null) }) })
            }
            Text(if (layer.mask == null) "หน้ากาก: ไม่มี (มีผลเต็มพื้นที่)" else "หน้ากาก: มีน้ำหนักแยกตามจุดตาข่าย ${layer.mask.weights.size} จุด", color = c.Sub, fontSize = 10.sp)
        }
    }
}

@Composable
private fun ColumnScope.SculptSecMask(
    clip: StudioImage, onWarpLayers: (List<WarpLayer>) -> Unit,
) {
    val c = StudioColors
    Text("หน้ากากควบคุมพื้นที่ที่ชั้นบิดมีผล", color = c.Ink, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
    Text("สีขาว = มีผลเต็มที่ · สีดำ = ไม่ได้รับผล · สีเทา = มีผลบางส่วน หน้ากากทำงานต่อจุดตาข่ายและปรับขนาดตามความละเอียดตาข่าย · พู่กันจะระบายชั้นที่เปิดใช้งานลำดับท้ายสุด", color = c.Sub, fontSize = 11.sp)
    if (clip.warpLayers.isEmpty()) Text("ต้องสร้างชั้นบิดก่อน จึงจะเพิ่มหน้ากากให้ชั้นนั้นได้", color = c.Sub, fontSize = 11.sp)
    clip.warpLayers.forEachIndexed { index, layer ->
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            Text(layer.name, color = c.Ink, fontSize = 12.sp, modifier = Modifier.weight(1f))
            ToolChip("หน้ากากเต็ม", enabled = layer.mask == null, onClick = { onWarpLayers(clip.warpLayers.toMutableList().also { it[index] = layer.copy(mask = WarpMask.full(layer.grid.cols, layer.grid.rows)) }) })
            ToolChip("กลับสี", enabled = layer.mask != null, onClick = { val m=layer.mask!!; onWarpLayers(clip.warpLayers.toMutableList().also { it[index] = layer.copy(mask = WarpMask(m.cols,m.rows,FloatArray(m.weights.size){1f-m.weight(it)})) }) })
            ToolChip("ล้าง", enabled = layer.mask != null, onClick = { onWarpLayers(clip.warpLayers.toMutableList().also { it[index] = layer.copy(mask = null) }) })
        }
    }
    Text("เลือกเครื่องมือ ‘ระบายหน้ากาก’ แล้วลากบนภาพเพื่อระบาย · ใช้ ‘กลับทิศ’ ในแท็บความปลอดภัยเพื่อลบ · พู่กันจะเลือกชั้นที่เปิดใช้งานลำดับท้ายสุด", color = c.Sub, fontSize = 10.sp)
}

@Composable
private fun ColumnScope.SculptSecPhysics(
    clip: StudioImage, onPhysics: (WarpPhysicsSettings) -> Unit,
) {
    val c = StudioColors
    val p = clip.physics
    Text("ฟิสิกส์การเคลื่อนไหวรอง", color = c.Ink, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
    Text("คำนวณผลจากเวลาแบบกำหนดซ้ำได้ จึงแสดงผลสอดคล้องกันระหว่างหน้าพรีวิวและการส่งออก", color = c.Sub, fontSize = 11.sp)
    Row(verticalAlignment = Alignment.CenterVertically) {
        Checkbox(checked = p.enabled, onCheckedChange = { onPhysics(p.copy(enabled = it)) })
        Text("เปิดใช้ฟิสิกส์กับชั้นบิดของคลิปนี้", color = c.Ink, fontSize = 12.sp)
    }
    val physicsFields = listOf(
        Triple("แรงโน้มถ่วง X", p.gravityX) { v: Float -> p.copy(gravityX=v) },
        Triple("แรงโน้มถ่วง Y", p.gravityY) { v: Float -> p.copy(gravityY=v) },
        Triple("มวล", p.mass) { v: Float -> p.copy(mass=v) },
        Triple("ความแข็งสปริง", p.stiffness) { v: Float -> p.copy(stiffness=v) },
        Triple("แรงหน่วง", p.damping) { v: Float -> p.copy(damping=v) },
        Triple("ความยืดหยุ่น", p.elasticity) { v: Float -> p.copy(elasticity=v) },
        Triple("แรงสปริง", p.springStrength) { v: Float -> p.copy(springStrength=v) },
        Triple("แรงเด้ง", p.bounce) { v: Float -> p.copy(bounce=v) },
        Triple("แรงต้าน", p.drag) { v: Float -> p.copy(drag=v) },
        Triple("แรงลม X", p.windX) { v: Float -> p.copy(windX=v) },
        Triple("แรงลม Y", p.windY) { v: Float -> p.copy(windY=v) },
        Triple("ความเร็วคืนรูป", p.recoverySpeed) { v: Float -> p.copy(recoverySpeed=v) },
        Triple("ขีดการยืดเชิงกายภาพ", p.maxStretch) { v: Float -> p.copy(maxStretch=v) },
    )
    physicsFields.chunked(2).forEach { pair ->
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            pair.forEach { (label,value,make) -> SculptNumField(label, value, -Float.MAX_VALUE, Float.MAX_VALUE, true, 140.dp) { onPhysics(make(it)) } }
        }
    }
    Text("แรงโน้มถ่วงและแรงลมกำหนดแรงภายนอก · มวลสูงทำให้ตอบสนองช้าลง · ความแข็งสปริงดึงกลับสู่รูปเดิม · แรงหน่วงและแรงต้านลดการสั่น · ความยืดหยุ่นและแรงเด้งกำหนดการคืนตัว · ความเร็วคืนรูปกำหนดอัตรากลับสู่ตำแหน่งเดิม · ขีดการยืดกำหนดระยะทางกายภาพที่อนุญาต", color = c.Sub, fontSize = 10.sp)
    Row(verticalAlignment = Alignment.CenterVertically) {
        Checkbox(checked = p.collision, onCheckedChange = { onPhysics(p.copy(collision = it)) })
        Text("เปิดการชน (เตรียมค่าระบบชน)", color = c.Ink, fontSize = 12.sp)
    }
    Text("ข้อจำกัดปัจจุบัน: แรงชนยังไม่ถูกจำลองกับวัตถุอื่น; ค่าชนถูกเก็บไว้สำหรับระบบชนในขั้นต่อไป", color = c.Warn, fontSize = 10.sp)
}

@Composable
private fun ColumnScope.SculptSecPresets(
    warpSettings: WarpSettings, onWarpSettings: (WarpSettings) -> Unit, customPresets: List<WarpPreset>,
    onSaveCustomPreset: (String) -> Unit, onDeleteCustomPreset: (Int) -> Unit,
) {
    val c = StudioColors
    Text("ชุดค่าพร้อมใช้", color = c.Ink, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
    var presetName by remember { mutableStateOf("ชุดค่าของฉัน") }
    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
        BasicTextField(value = presetName, onValueChange = { presetName = it }, singleLine = true,
            textStyle = TextStyle(color = c.Ink, fontSize = 12.sp), cursorBrush = SolidColor(c.Accent),
            modifier = Modifier.weight(1f).background(c.Panel2, RoundedCornerShape(8.dp)).padding(9.dp))
        ToolChip("บันทึกค่าปัจจุบัน", highlight = true, onClick = { onSaveCustomPreset(presetName) })
    }
    WarpPresets.all.forEach { preset ->
        Column(Modifier.fillMaxWidth().background(c.Panel2, RoundedCornerShape(9.dp)).padding(8.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(preset.name, color = c.Ink, fontSize = 12.sp, modifier = Modifier.weight(1f))
                ToolChip("ใช้ชุดค่านี้", highlight = true, onClick = { onWarpSettings(preset.settings) })
            }
            Text(preset.description, color = c.Sub, fontSize = 10.sp)
        }
    }
    if (customPresets.isNotEmpty()) Text("พรีเซ็ตที่บันทึกไว้", color = c.Ink, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
    customPresets.forEachIndexed { index, preset ->
        Row(Modifier.fillMaxWidth().background(c.Panel2, RoundedCornerShape(9.dp)).padding(8.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            Column(Modifier.weight(1f)) {
                Text(preset.name, color = c.Ink, fontSize = 12.sp)
                Text(preset.description, color = c.Sub, fontSize = 10.sp)
            }
            ToolChip("ใช้", highlight = true, onClick = { onWarpSettings(preset.settings) })
            ToolChip("ลบ", onClick = { onDeleteCustomPreset(index) })
        }
    }
}

@Composable
private fun ColumnScope.SculptSecSafety(
    warpSettings: WarpSettings, onWarpSettings: (WarpSettings) -> Unit,
) {
    val c = StudioColors
    val patch: (WarpSettings.() -> WarpSettings) -> Unit = { edit -> onWarpSettings(warpSettings.edit()) }
    Row(verticalAlignment = Alignment.CenterVertically) {
        Checkbox(checked = warpSettings.preventFolding, onCheckedChange = { patch { copy(preventFolding = it) } })
        Text("ป้องกันตาข่ายพับ: ลดแรงอัตโนมัติเมื่อเสี่ยงรูปทรงกลับด้าน", color = c.Ink, fontSize = 12.sp)
    }
    Row(verticalAlignment = Alignment.CenterVertically) {
        Checkbox(checked = warpSettings.preserveBoundary, onCheckedChange = { patch { copy(preserveBoundary = it) } })
        Text("รักษาขอบภาพไม่ให้เคลื่อนตามพู่กัน", color = c.Ink, fontSize = 12.sp)
    }
    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        SculptNumField("ป้องกันขอบภาพ (%)", warpSettings.edgeProtection, 0f, 100f, true, 140.dp) { patch { copy(edgeProtection = it) } }
        Row(verticalAlignment = Alignment.CenterVertically) {
            Checkbox(checked = warpSettings.centerLock, onCheckedChange = { patch { copy(centerLock = it) } })
            Text("ล็อกกลาง", color = c.Ink, fontSize = 11.sp)
        }
    }
    Row(verticalAlignment = Alignment.CenterVertically) {
        Checkbox(checked = warpSettings.symmetry, onCheckedChange = { patch { copy(symmetry = it) } })
        Text("สมมาตร: สะท้อนการบิดไปอีกด้านของแกนกลางภาพ", color = c.Ink, fontSize = 12.sp)
    }
    Row(verticalAlignment = Alignment.CenterVertically) {
        Checkbox(checked = warpSettings.invert, onCheckedChange = { patch { copy(invert = it) } })
        Text("กลับทิศ: สลับผลบิดจากเข้าเป็นออกหรือจากออกเป็นเข้า", color = c.Ink, fontSize = 12.sp)
    }
    Row(verticalAlignment = Alignment.CenterVertically) {
        Checkbox(checked = warpSettings.lockHorizontal, onCheckedChange = { patch { copy(lockHorizontal = it) } })
        Text("ล็อกแกน X / Horizontal", color = c.Ink, fontSize = 12.sp)
    }
    Row(verticalAlignment = Alignment.CenterVertically) {
        Checkbox(checked = warpSettings.lockVertical, onCheckedChange = { patch { copy(lockVertical = it) } })
        Text("ล็อกแกน Y / Vertical", color = c.Ink, fontSize = 12.sp)
    }
    Row(verticalAlignment = Alignment.CenterVertically) {
        Checkbox(checked = warpSettings.boundaryClamp, onCheckedChange = { patch { copy(boundaryClamp = it) } })
        Text("กักขอบเขต: ป้องกันจุดตาข่ายออกนอกภาพ", color = c.Ink, fontSize = 12.sp)
    }
    Row(verticalAlignment = Alignment.CenterVertically) {
        Checkbox(checked = warpSettings.preventSelfIntersection, onCheckedChange = { patch { copy(preventSelfIntersection = it) } })
        Text("ป้องกันช่องตาข่ายกลับด้าน / ตัดกัน", color = c.Ink, fontSize = 12.sp)
    }
    Row(verticalAlignment = Alignment.CenterVertically) {
        Checkbox(checked = warpSettings.highQualityPreview, onCheckedChange = { patch { copy(highQualityPreview = it) } })
        Text("แสดงตัวอย่างคุณภาพสูง: กรองภาพและลดแถบสี", color = c.Ink, fontSize = 12.sp)
    }
    Row(verticalAlignment = Alignment.CenterVertically) {
        Checkbox(checked = warpSettings.antiAliasing, onCheckedChange = { patch { copy(antiAliasing = it) } })
        Text("ลดรอยหยักของขอบภาพ", color = c.Ink, fontSize = 12.sp)
    }
}

@Composable
private fun ColumnScope.SculptHint(tool: SculptTool, limitDeg: Float, twistOver: Boolean, gc: Int, gr: Int, cellMin: Float) {
    val c = StudioColors
    val hint = when (tool) {
        SculptTool.GRAB -> "ดึง: ลากบนภาพเพื่อย้ายจุดตาข่ายรอบพู่กัน"
        SculptTool.MESH -> "ตาข่าย: แตะจุดสีฟ้าแล้วลาก · จำกัดระยะต่อครั้งเพื่อป้องกันตาข่ายพับ"
        SculptTool.TWIST -> "บิดหมุน: แตะกำหนดศูนย์กลางแล้วลากซ้าย/ขวา · ขอบเขตปลอดภัยประมาณ ${limitDeg.roundToInt()}°" + if (twistOver) " · มุมที่ตั้งจะถูกลดลงตามความปลอดภัย" else ""
        SculptTool.PINCH -> "บีบเข้า: ดึงรูปเข้าหาศูนย์กลาง · ปรับวงรีแนวนอนและแนวตั้งได้"
        SculptTool.BULGE -> "ดันนูน: ผลักรูปออกจากศูนย์กลาง · ปรับวงรีแนวนอนและแนวตั้งได้"
        SculptTool.SPIRAL -> "เกลียว: หมุนจุดรอบศูนย์กลางตามมุมที่กำหนด"
        SculptTool.WAVE -> "คลื่น: สร้างคลื่นตามทิศทาง ความถี่ ระยะเริ่มต้น และความยาวคลื่น"
        SculptTool.SHEAR -> "เฉือน: เฉือนรูปตามแกนแนวนอนและแนวตั้งด้วยระยะลาก"
        SculptTool.PERSPECTIVE -> "มุมมอง: ปรับระนาบภาพให้เกิดมุมมองจากแรงลาก"
        SculptTool.RIPPLE -> "กระเพื่อม: สร้างคลื่นวงแหวนรอบจุดศูนย์กลาง"
        SculptTool.PUSH -> "ผลัก: ดันหรือดึงตาข่ายตามทิศทางการลาก"
        SculptTool.INFLATE -> "พอง: ขยายพื้นผิวออกจากจุดศูนย์กลาง เหมาะกับแก้ม กล้ามเนื้อ และชิ้นส่วนการ์ตูน"
        SculptTool.DEFLATE -> "ยุบ: ดึงพื้นผิวเข้าด้านใน ใช้ลดความนูน"
        SculptTool.SMOOTH -> "เกลี่ย: เฉลี่ยความต่างของจุดตาข่ายให้การบิดนุ่มและต่อเนื่อง"
        SculptTool.FLATTEN -> "แบน: ดึงจุดเข้าหาแนวระนาบตามมุมที่กำหนด"
        SculptTool.CREASE -> "รอยพับ: รวมรูปทรงเข้าหาแนวกลางเพื่อสร้างรอยพับ"
        SculptTool.GRAVITY -> "แรงโน้มถ่วง: ดึงพื้นผิวไปตามทิศทางที่กำหนด"
        SculptTool.ELASTIC -> "ยืดหยุ่น: ขยายและคืนรูปแบบสปริง"
        SculptTool.MAGNET -> "แม่เหล็ก: ดูดจุดตาข่ายเข้าหาศูนย์กลาง"
        SculptTool.ARC_BEND -> "ดัดโค้ง: โค้งพื้นผิวเป็นส่วนโค้งตามทิศและความยาวของแนวพู่กัน"
        SculptTool.TAPER -> "เรียว: ทำให้ด้านหนึ่งของพื้นที่แคบลง อีกด้านกว้างขึ้นตามแกนที่เลือก"
        SculptTool.RIGID_TRANSFORM -> "ย้าย/หมุนแข็ง: เคลื่อนและหมุนพื้นที่เหมือนแผ่นเดียว โดยไล่แรงที่ขอบให้ต่อกับภาพเดิม"
        SculptTool.RIBBON_BEND -> "ดัดแถบ: บิดพื้นที่เป็นแถบยาวแคบและปรับความโค้งด้วยความถี่/ความยาวคลื่น"
        SculptTool.EDGE_SLIDE -> "เลื่อนขอบ: เลื่อนจุดตาข่ายไปตามแนวสัมผัสรอบศูนย์กลาง ไม่ดันเข้า/ออกตรง ๆ"
        SculptTool.CONTOUR_FLOW -> "ไหลตามเส้น: สร้างสนามไหลวนตามเส้นระดับด้วยความถี่และเฟส"
        SculptTool.FAN_DEFORM -> "แผ่พัด: กระจายและหุบพื้นผิวเป็นกลีบรัศมีรอบจุดที่แตะ"
        SculptTool.ORIGAMI_FOLD -> "พับกระดาษ: พับด้านหนึ่งเข้าหาแนวสันพับ ปรับความแข็งของรอยพับได้"
        SculptTool.TOPOLOGY_REMAP -> "รีแมปตาข่าย: เลื่อนตำแหน่งจุดตาข่ายเป็นสนามลายตารางไขว้ โดยไม่เปลี่ยนจำนวนจุดหรือเส้นเชื่อม"
        SculptTool.BOUNDARY_TENSION -> "แรงตึงขอบ: ดึงจุดบริเวณขอบวงพู่กันเข้าหาศูนย์กลางเพื่อสร้างแรงตึง"
        SculptTool.VISCOUS_MELT -> "ละลายหนืด: ทำให้พื้นผิวไหลย้อยตามทิศที่ตั้ง พร้อมแรงหน่วงตามระยะ"
        SculptTool.SEGMENT_OFFSET -> "เหลื่อมแถบ: แบ่งภาพเป็นแถบแล้วเลื่อนสลับกันเพื่อสร้างเอฟเฟกต์เหลื่อม"
        SculptTool.ASYMMETRIC_WARP -> "บิดไม่สมมาตร: ให้น้ำหนักการบิดสองฝั่งของแกนไม่เท่ากัน"
        SculptTool.DIRECTIONAL_COMPRESS -> "บีบตามแกน: บีบแกนที่เลือกและชดเชยอีกแกนเพื่อคงพื้นที่โดยประมาณ"
        SculptTool.SURFACE_ROLL -> "ม้วนผิว: ม้วนพื้นผิวรอบแกนคล้ายแผ่นวัสดุโค้งเป็นทรงกระบอก"
        SculptTool.MASK -> "ระบายหน้ากาก: ลากบนภาพเพื่อกำหนดบริเวณที่ชั้นบิดมีผล · ใช้กลับทิศเพื่อลบ"
        SculptTool.PIN -> "หมุดข้อต่อ"
        SculptTool.POINT -> "ลากหมุดที่วางไว้เพื่อบิดภาพในวง"
    }
    Text("$hint\nตาข่ายของคลิปนี้ $gc×$gr ช่อง (ช่องเล็กสุดประมาณ ${cellMin.roundToInt()} พิกเซล)", color = if (twistOver) c.Warn else c.Sub, fontSize = 11.sp)
}

// ───────────────────────── ตัวเลือกเครื่องมือบิด: ปุ่มเดียว + สไลด์เลือก ─────────────────────────

private class SculptToolInfo(val tool: SculptTool, val icon: String, val label: String, val desc: String)
private class SculptToolGroup(val title: String, val tools: List<SculptToolInfo>)

/**
 * เครื่องมือที่ซ้ำกัน (สูตรใน Sculpt.kt บรรทัด deltaAt ใช้ทิศ/โปรไฟล์เดียวกันทุกตัว) ถูกรวมเหลือตัวเดียว:
 *  INFLATE ≡ BULGE (ดันออก) และ DEFLATE ≡ PINCH ≡ MAGNET (ดึงเข้า) — ซ่อนจากหน้าจอ แต่ยังคงอยู่ใน enum/ตัวคำนวณ
 *  ตามคำสั่งผู้ใช้: ตัด บีบเข้า/เกลี่ย/เกลียว/คลื่น และทั้งหมวด พับ/ดัด ออกจากเมนู (ไม่มีทางเลือกจากหน้าจอแล้ว; ตัวคำนวณยังอยู่เพื่อไม่ให้ท่าที่บันทึกไว้เสีย)
 */
private val SCULPT_TOOL_GROUPS: List<SculptToolGroup> = listOf(
    SculptToolGroup("ควบคุมหลัก", listOf(
        SculptToolInfo(SculptTool.GRAB, "✋", "ดึง", "ลากบริเวณรอบจุดที่แตะ"),
        SculptToolInfo(SculptTool.MESH, "▦", "ตาข่าย", "แตะจุดตาข่ายแล้วลากย้ายทีละจุด"),
        SculptToolInfo(SculptTool.POINT, "📍", "จุดบิด", "วางจุดแล้วบิดเฉพาะวงรอบจุด"),
        SculptToolInfo(SculptTool.MASK, "🖌", "ระบายหน้ากาก", "ระบายบริเวณที่ชั้นบิดมีผล"),
        SculptToolInfo(SculptTool.PIN, "📌", "หมุดข้อต่อ", "ตั้งหมุดข้อต่อให้ขยับเป็นข้อ ๆ"),
    )),
    SculptToolGroup("รูปทรง", listOf(
        SculptToolInfo(SculptTool.BULGE, "🎈", "ดันนูน / พอง", "ผลักรูปออกจากศูนย์กลาง (รวมพอง)"),
        SculptToolInfo(SculptTool.PUSH, "👉", "ผลัก", "ดันหรือดึงตาข่ายตามทิศที่ลาก"),
        SculptToolInfo(SculptTool.FLATTEN, "▬", "แบน", "ดึงจุดเข้าหาแนวระนาบที่กำหนด"),
        SculptToolInfo(SculptTool.ELASTIC, "⇔", "ยืดหยุ่น", "ขยายและคืนรูปแบบสปริง"),
        SculptToolInfo(SculptTool.TAPER, "🔺", "เรียว", "ด้านหนึ่งแคบลง อีกด้านกว้างขึ้น"),
        SculptToolInfo(SculptTool.DIRECTIONAL_COMPRESS, "🗜", "บีบตามแกน", "บีบแกนที่เลือก ชดเชยอีกแกน"),
    )),
    SculptToolGroup("หมุน / เฉือน", listOf(
        SculptToolInfo(SculptTool.TWIST, "🔄", "บิดหมุน", "แตะศูนย์กลางแล้วลากซ้าย/ขวาเพื่อหมุน"),
        SculptToolInfo(SculptTool.SHEAR, "▱", "เฉือน", "เฉือนตามแกนแนวนอนและแนวตั้ง"),
        SculptToolInfo(SculptTool.PERSPECTIVE, "📐", "มุมมอง", "ปรับระนาบภาพให้เกิดมุมมอง"),
        SculptToolInfo(SculptTool.ASYMMETRIC_WARP, "⚖", "บิดไม่สมมาตร", "น้ำหนักบิดสองฝั่งของแกนไม่เท่ากัน"),
        SculptToolInfo(SculptTool.RIGID_TRANSFORM, "🔲", "ย้าย/หมุนแข็ง", "เคลื่อนและหมุนพื้นที่เป็นแผ่นเดียว"),
    )),
    SculptToolGroup("คลื่น", listOf(
        SculptToolInfo(SculptTool.RIPPLE, "💧", "กระเพื่อม", "คลื่นวงแหวนรอบจุดศูนย์กลาง"),
        SculptToolInfo(SculptTool.FAN_DEFORM, "🌸", "แผ่พัด", "แผ่และหุบเป็นกลีบรอบจุดที่แตะ"),
        SculptToolInfo(SculptTool.TOPOLOGY_REMAP, "🧩", "รีแมปตาข่าย", "เลื่อนจุดตาข่ายเป็นลายตารางไขว้"),
        SculptToolInfo(SculptTool.SEGMENT_OFFSET, "☰", "เหลื่อมแถบ", "แบ่งเป็นแถบแล้วเลื่อนสลับกัน"),
    )),
    SculptToolGroup("ไหล", listOf(
        SculptToolInfo(SculptTool.CONTOUR_FLOW, "🌬", "ไหลตามเส้น", "สนามไหลวนตามเส้นระดับ"),
        SculptToolInfo(SculptTool.VISCOUS_MELT, "🍯", "ละลายหนืด", "ไหลย้อยตามทิศที่ตั้ง"),
        SculptToolInfo(SculptTool.GRAVITY, "⬇", "แรงโน้มถ่วง", "ดึงพื้นผิวไปตามทิศที่กำหนด"),
        SculptToolInfo(SculptTool.BOUNDARY_TENSION, "🎯", "แรงตึงขอบ", "ดึงจุดขอบวงเข้าหาศูนย์กลาง"),
    )),
)

private val SCULPT_TOOL_INFO: Map<SculptTool, SculptToolInfo> =
    SCULPT_TOOL_GROUPS.flatMap { it.tools }.associateBy { it.tool }

/** เครื่องมือที่เลือกจากสไลด์ล่าสุด 3 ตัว (จำไว้ตลอดการใช้งานแอป ไม่บันทึกลงไฟล์) */
private object SculptRecentTools {
    val list = mutableStateListOf(SculptTool.GRAB, SculptTool.MESH, SculptTool.POINT)
    fun push(t: SculptTool) {
        if (t !in SCULPT_TOOL_INFO) return
        list.remove(t)
        list.add(0, t)
        while (list.size > 3) list.removeAt(list.size - 1)
    }
}

@Composable
private fun SculptToolCard(info: SculptToolInfo, selected: Boolean, modifier: Modifier, onClick: () -> Unit) {
    val c = StudioColors
    val shape = RoundedCornerShape(14.dp)
    Column(
        modifier.clip(shape)
            .background(if (selected) c.AccentDim else c.Panel2)
            .border(1.dp, if (selected) c.Accent else c.Line, shape)
            .clickable(onClick = onClick).padding(10.dp),
        verticalArrangement = Arrangement.spacedBy(3.dp),
    ) {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            Text(info.icon, fontSize = 18.sp)
            Text(info.label, color = if (selected) c.Accent else c.Ink, fontSize = 14.sp, fontWeight = FontWeight.SemiBold, maxLines = 1)
        }
        Text(info.desc, color = c.Sub, fontSize = 11.sp, lineHeight = 14.sp, maxLines = 2)
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun SculptToolSheet(current: SculptTool, onPick: (SculptTool) -> Unit, onDismiss: () -> Unit) {
    val c = StudioColors
    val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)
    ModalBottomSheet(onDismissRequest = onDismiss, sheetState = sheetState, containerColor = c.Panel, contentColor = c.Ink) {
        Column(
            Modifier.fillMaxWidth().verticalScroll(rememberScrollState()).padding(horizontal = 14.dp).padding(bottom = 28.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            Text("เลือกเครื่องมือบิด", color = c.Ink, fontSize = 18.sp, fontWeight = FontWeight.Bold)
            Text("แตะการ์ดเพื่อเลือก · เครื่องมือที่สูตรซ้ำกันถูกรวมไว้แล้ว", color = c.Sub, fontSize = 11.sp)
            SCULPT_TOOL_GROUPS.forEach { group ->
                Text(group.title, color = c.Accent, fontSize = 13.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.padding(top = 8.dp))
                group.tools.chunked(2).forEach { pair ->
                    Row(Modifier.fillMaxWidth().height(IntrinsicSize.Min), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        pair.forEach { info ->
                            SculptToolCard(info, info.tool == current, Modifier.weight(1f).fillMaxHeight()) { onPick(info.tool) }
                        }
                        if (pair.size == 1) Spacer(Modifier.weight(1f))
                    }
                }
            }
        }
    }
}

@Composable
private fun ColumnScope.SculptToolPicker(tool: SculptTool, onTool: (SculptTool) -> Unit, section: String, onSection: (String) -> Unit) {
    val c = StudioColors
    var showSheet by remember { mutableStateOf(false) }
    val current = SCULPT_TOOL_INFO[tool]
    val onAccent = Color(0xFF06141F)
    Text("เครื่องมือบิดภาพ", color = c.Sub, fontSize = 11.sp, fontWeight = FontWeight.SemiBold)
    Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.CenterVertically) {
        Row(
            Modifier.clip(RoundedCornerShape(50)).background(c.Accent).clickable { showSheet = true }.padding(horizontal = 14.dp, vertical = 9.dp),
            verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp),
        ) {
            Text(current?.icon ?: "🛠", fontSize = 14.sp)
            Text(current?.label ?: "เลือกเครื่องมือ", color = onAccent, fontSize = 13.sp, fontWeight = FontWeight.Bold, maxLines = 1)
            Text("▾", color = onAccent, fontSize = 12.sp)
        }
        SculptRecentTools.list.forEach { t ->
            val info = SCULPT_TOOL_INFO[t]
            if (info != null) ToolChip(info.label, highlight = t == tool, onClick = { onTool(t) })
        }
    }
    if (showSheet) SculptToolSheet(tool, onPick = { t -> SculptRecentTools.push(t); onTool(t); showSheet = false }, onDismiss = { showSheet = false })
    Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(5.dp)) {
        listOf("เครื่องมือ", "พู่กัน", "ตาข่าย", "แอนิเมชัน", "ชั้นบิด", "หน้ากาก", "ฟิสิกส์", "พรีเซ็ต", "ความปลอดภัย").forEach { name ->
            ToolChip(name, highlight = section == name, onClick = { onSection(name) })
        }
    }
}

/** ตั้งเฟรมต่อวินาที (fps) ของ MP4 ที่ส่งออก 1–60: พิมพ์เลข / เลื่อนแถบ / เลือกค่ายอดนิยม · บอกจำนวนเฟรมรวมและผลต่อเวลาส่งออก */
@Composable
private fun FpsDialog(fps: Int, durationSec: Float, onApply: (Int) -> Unit, onDismiss: () -> Unit) {
    val c = StudioColors
    var text by remember { mutableStateOf(fps.toString()) }
    val v = text.toIntOrNull()
    val rangeOk = v != null && v >= 1
    val dur = durationSec.coerceAtLeast(MIN_CLIP_SEC)
    val total = if (rangeOk) (dur * v!!).roundToInt() else 0
    val ok = rangeOk
    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = c.Panel, titleContentColor = c.Ink, textContentColor = c.Ink,
        title = { Text("เฟรมต่อวินาที (FPS)") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(14.dp)) {
                OutlinedTextField(
                    value = text, onValueChange = { raw -> text = raw.filter { ch -> ch.isDigit() }.take(4) },
                    label = { Text("เฟรมต่อวินาที") }, suffix = { Text("เฟรม/วินาที") }, singleLine = true, isError = !rangeOk,
                    textStyle = TextStyle(fontSize = 26.sp, fontWeight = FontWeight.Bold, color = c.Ink),
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), colors = studioFieldColors(),
                    modifier = Modifier.fillMaxWidth(),
                )
                Slider(
                    value = (v ?: fps).coerceIn(1, 60).toFloat(), onValueChange = { text = it.roundToInt().toString() },
                    valueRange = 1f..60f, steps = 58,
                    colors = SliderDefaults.colors(thumbColor = c.Accent, activeTrackColor = c.Accent, inactiveTrackColor = c.Panel2),
                )
                Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    listOf(12, 15, 24, 30, 48, 60).forEach { p -> ToolChip("$p", highlight = v == p, onClick = { text = p.toString() }) }
                }
                Column(
                    Modifier.fillMaxWidth().background(c.Panel2, RoundedCornerShape(14.dp)).padding(12.dp),
                    verticalArrangement = Arrangement.spacedBy(4.dp),
                ) {
                    if (rangeOk) {
                        Text("1 วินาที = $v เฟรม", color = c.Ink, fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
                        Text("งานนี้ยาว ${f1(dur)} วินาที → รวม $total เฟรม", color = c.Sub, fontSize = 12.sp)
                        if (v!! > 60) Text("เกิน 60: เครื่องบางรุ่นเข้ารหัสไม่ได้ ถ้าส่งออกไม่สำเร็จให้ลดค่าลง", color = c.Warn, fontSize = 12.sp)
                        if (total > 36000) Text("งานยาวมาก ส่งออกอาจใช้เวลานานและกินพื้นที่เครื่อง", color = c.Warn, fontSize = 12.sp)
                        if (v != 30) Text(
                            "ส่งออกใช้เวลาราว ${String.format(java.util.Locale.US, "%.1f", v!! / 30f)}× ของ 30 fps",
                            color = c.Sub, fontSize = 12.sp,
                        )
                        Text("สูงขึ้น = ลื่นขึ้น แต่ส่งออกช้าลงและไฟล์ใหญ่ขึ้น · 24 = แนวหนัง · 30 = ทั่วไป · 60 = ลื่นมาก", color = c.Sub, fontSize = 11.sp)
                    } else {
                        Text("ใส่ตัวเลขตั้งแต่ 1 ขึ้นไป", color = c.Danger, fontSize = 13.sp)
                    }
                }
            }
        },
        confirmButton = { TextButton(enabled = ok, onClick = { onApply(v!!) }) { Text("ตกลง", color = if (ok) c.Accent else c.Sub) } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("ยกเลิก", color = c.Sub) } },
    )
}

/** ตั้งขนาดวิดีโอ [ความสูง] × [ความกว้าง] (px): ผืนผ้าใบเปลี่ยนสัดส่วนตามทันที และเป็นขนาดตอนส่งออก MP4 (บันทึกในโปรเจกต์) */
@Composable
private fun VideoSizeDialog(width: Int, height: Int, onApply: (Int, Int) -> Unit, onDismiss: () -> Unit) {
    val c = StudioColors
    var hText by remember { mutableStateOf(height.toString()) }
    var wText by remember { mutableStateOf(width.toString()) }
    val h = hText.toIntOrNull()
    val w = wText.toIntOrNull()
    val hOk = h != null && h in 64..1920
    val wOk = w != null && w in 64..1920
    val presets = listOf(
        Triple("แนวตั้ง 9:16", 1280, 720), Triple("แนวนอน 16:9", 720, 1280), Triple("จัตุรัส 1:1", 720, 720), Triple("แนวตั้ง 4:5", 900, 720),
    )
    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = c.Panel, titleContentColor = c.Ink, textContentColor = c.Ink,
        title = { Text("ขนาดวิดีโอ") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = hText, onValueChange = { raw -> hText = raw.filter { ch -> ch.isDigit() }.take(4) },
                        label = { Text("สูง") }, suffix = { Text("พิกเซล") }, singleLine = true, isError = !hOk,
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), colors = studioFieldColors(), modifier = Modifier.weight(1f),
                    )
                    Text("×", color = c.Ink, fontSize = 20.sp)
                    OutlinedTextField(
                        value = wText, onValueChange = { raw -> wText = raw.filter { ch -> ch.isDigit() }.take(4) },
                        label = { Text("กว้าง") }, suffix = { Text("พิกเซล") }, singleLine = true, isError = !wOk,
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), colors = studioFieldColors(), modifier = Modifier.weight(1f),
                    )
                }
                Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    presets.forEach { (label, ph, pw) -> ToolChip(label, onClick = { hText = ph.toString(); wText = pw.toString() }) }
                }
                Text(
                    if (hOk && wOk) "ส่งออกจริง สูง ${Exporter.videoSize(h!!)} × กว้าง ${Exporter.videoSize(w!!)} px (ปัดเป็นพหุคูณของ 16) · ใส่ได้ 64–1920"
                    else "ใส่ตัวเลข 64–1920 ทั้งสองช่อง",
                    color = if (hOk && wOk) c.Sub else c.Danger, fontSize = 12.sp,
                )
            }
        },
        confirmButton = { TextButton(enabled = hOk && wOk, onClick = { onApply(w!!, h!!) }) { Text("ตกลง", color = if (hOk && wOk) c.Accent else c.Sub) } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("ยกเลิก", color = c.Sub) } },
    )
}

// ───────────────────────── Timeline (ตัวจัดการเลเยอร์) ─────────────────────────

@Composable
private fun StudioTimeline(
    images: SnapshotStateList<StudioImage>,
    layerIds: SnapshotStateList<Int>,
    selectedId: Int,
    activeLayerId: Int,
    playhead: Float,
    zoom: Float,
    timelineEnd: Float,
    playing: Boolean,
    overlayLabel: String,
    overlayStart: Float,
    overlayDuration: Float,
    audioName: String?,
    audioStart: Float,
    onSeek: (Float) -> Unit,
    onSelect: (Int) -> Unit,
    onActiveLane: (Int) -> Unit,
    onNewTopLane: () -> Int,
    onOverlayChange: (Float, Float) -> Unit,
    onAudioStart: (Float) -> Unit,
    onZoom: (Float) -> Unit,
    onAddLane: () -> Unit,
    onAddKeyframe: () -> Unit,
    onDeleteKeyframe: () -> Unit,
    onKeyframeEdit: (Int) -> Unit = {},
    canPasteKeyframe: Boolean = false, onCopyKeyframe: () -> Unit = {}, onPasteKeyframe: () -> Unit = {},
    modifier: Modifier = Modifier,
) {
    val c = StudioColors
    val density = LocalDensity.current
    val selectedClip = images.firstOrNull { it.id == selectedId }
    val hScroll = rememberScrollState()
    val vScroll = rememberScrollState()
    val rawPps = with(density) { 56.dp.toPx() } * zoom // พิกเซลต่อวินาทีตามซูม
    val laneH = 50.dp
    val laneGap = 4.dp
    val rowH = laneH + laneGap
    val extraH = 30.dp
    val headerW = 46.dp
    val displayLanes = layerIds.sortedDescending() // แถวบนสุด = แทร็กสูงสุด = อยู่บนสุดของภาพ
    val hasOverlay = overlayLabel.isNotBlank()
    val hasAudio = audioName != null
    val extraRows = (if (hasOverlay) 1 else 0) + (if (hasAudio) 1 else 0)
    val lanesHeight = rowH * displayLanes.size + (extraH + laneGap) * extraRows
    val totalSec = (timelineEnd + 6f).coerceAtLeast(12f).coerceAtMost(MAX_TIMELINE_SEC + 6f)
    val pps = minOf(rawPps, MAX_TIMELINE_PX / totalSec) // งานยาวมาก: จำกัดความกว้างรวมไม่ให้เกินที่วาดได้ (ลดซูมอัตโนมัติ)
    val contentWidth = with(density) { (totalSec * pps).toDp() }
    var viewportPx by remember { mutableIntStateOf(0) }
    val maxZoomEff = maxOf(0.25f, MAX_TIMELINE_PX / totalSec / with(density) { 56.dp.toPx() }) // ซูมสูงสุดที่วาดได้จริง
    val zoomNow by rememberUpdatedState(zoom)
    val maxZoomNow by rememberUpdatedState(maxZoomEff)
    val onZoomNow by rememberUpdatedState(onZoom)
    var pendingScroll by remember { mutableStateOf<Int?>(null) }
    LaunchedEffect(zoom) { // ซูมด้วยสองนิ้วแล้ว เลื่อนให้จุดเวลาใต้นิ้วอยู่ที่เดิม (รอให้ความกว้างใหม่คำนวณเสร็จก่อน)
        val target = pendingScroll
        if (target != null) { pendingScroll = null; withFrameNanos { }; hScroll.scrollTo(target.coerceAtLeast(0)) }
    }
    val timelineEndNow by rememberUpdatedState(timelineEnd)
    val overlayStartNow by rememberUpdatedState(overlayStart)
    val overlayDurationNow by rememberUpdatedState(overlayDuration)
    val audioStartNow by rememberUpdatedState(audioStart)
    val playheadNow by rememberUpdatedState(playhead)
    val labelPaint = remember(density) {
        Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xFF8E9BB0.toInt(); textSize = with(density) { 10.sp.toPx() } }
    }

    // ตอนเล่น เลื่อน Timeline ตามเส้นเวลา
    LaunchedEffect(playhead, playing) {
        if (playing && viewportPx > 0) {
            val x = playhead * pps
            if (x < hScroll.value || x > hScroll.value + viewportPx - 48f) hScroll.scrollTo((x - viewportPx * 0.2f).toInt().coerceAtLeast(0))
        }
    }

    Column(
        modifier.background(c.Panel, RoundedCornerShape(16.dp)).padding(8.dp)
            .pointerInput(Unit) { // ถ่าง/หนีบสองนิ้วบน Timeline = ซูมแกนเวลา (ดักก่อนลูก ไม่รบกวนการลากด้วยนิ้วเดียว)
                awaitEachGesture {
                    awaitFirstDown(requireUnconsumed = false, pass = PointerEventPass.Initial)
                    do {
                        val event = awaitPointerEvent(PointerEventPass.Initial)
                        if (event.changes.count { it.pressed } >= 2) {
                            val z = event.calculateZoom()
                            if (z != 1f) {
                                val k0 = zoomNow
                                val k1 = (k0 * z).coerceIn(0.25f, maxOf(0.25f, maxZoomNow))
                                if (k1 != k0) {
                                    val focusPx = event.calculateCentroid().x - (46.dp.toPx() + 8.dp.toPx()) // ตำแหน่งนิ้วในพื้นที่แถบคลิป
                                    pendingScroll = ((hScroll.value + focusPx) * (k1 / k0) - focusPx).roundToInt()
                                    onZoomNow(k1)
                                }
                            }
                            event.changes.forEach { it.consume() }
                        }
                    } while (event.changes.any { it.pressed })
                }
            },
        verticalArrangement = Arrangement.spacedBy(6.dp),
    ) {
        Row(Modifier.horizontalScroll(rememberScrollState()), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            Text("เส้นเวลา", color = c.Ink, fontSize = 12.sp, fontWeight = FontWeight.Bold)
            Text("${fmtClock(playhead)} / ${fmtClock(timelineEnd)}", color = c.Accent, fontSize = 12.sp)
            ToolChip("◆＋", highlight = true, enabled = selectedClip != null, onClick = onAddKeyframe)
            ToolChip("◆−", enabled = selectedClip != null && selectedClip.keyframes.isNotEmpty(), onClick = onDeleteKeyframe)
            ToolChip("◆⧉ คัดลอก", enabled = selectedClip != null, onClick = onCopyKeyframe)
            ToolChip("◆📋 วาง", enabled = selectedClip != null && canPasteKeyframe, onClick = onPasteKeyframe)
            ToolChip("−", onClick = { onZoom(zoom / 1.25f) })
            Text("${f1(zoom)}×", color = c.Sub, fontSize = 11.sp)
            ToolChip("＋", onClick = { onZoom(minOf(zoom * 1.25f, maxZoomEff)) })
            ToolChip("＋ แทร็ก", onClick = onAddLane)
        }

        // ไม้บรรทัดเวลา (แตะ/ลากเพื่อเลื่อนเส้นเวลา)
        Row(verticalAlignment = Alignment.CenterVertically) {
            Spacer(Modifier.width(headerW))
            Box(Modifier.weight(1f).height(24.dp).clip(RoundedCornerShape(6.dp)).background(c.Panel2).horizontalScroll(hScroll, enabled = false)) {
                Box(
                    Modifier.width(contentWidth).fillMaxHeight()
                        .pointerInput(pps) { detectTapGestures { off -> onSeek((off.x / pps).coerceIn(0f, timelineEndNow)) } }
                        .pointerInput(pps) { detectHorizontalDragGestures { change, _ -> change.consume(); onSeek((change.position.x / pps).coerceIn(0f, timelineEndNow)) } },
                ) {
                    androidx.compose.foundation.Canvas(Modifier.fillMaxSize()) {
                        val step = listOf(0.5f, 1f, 2f, 5f, 10f, 20f, 30f).firstOrNull { it * pps >= 64f } ?: 60f
                        var t = 0f
                        while (t <= totalSec) {
                            val x = t * pps
                            drawLine(c.Line, Offset(x, size.height * 0.55f), Offset(x, size.height), 1f)
                            val label = if (t == t.toInt().toFloat()) "${t.toInt()}s" else "${f1(t)}s"
                            drawContext.canvas.nativeCanvas.drawText(label, x + 4f, size.height * 0.5f, labelPaint)
                            t += step
                        }
                    }
                    Box(Modifier.offset(x = with(density) { (playhead * pps).toDp() } - 1.dp).width(2.dp).fillMaxHeight().background(c.PlayRed))
                }
            }
        }

        // แถวแทร็ก
        Row(Modifier.fillMaxWidth().heightIn(max = 230.dp).verticalScroll(vScroll)) {
            Column(Modifier.width(headerW), verticalArrangement = Arrangement.spacedBy(laneGap)) {
                displayLanes.forEachIndexed { row, laneId ->
                    val laneClips = images.filter { it.layerId == laneId }
                    val allHidden = laneClips.isNotEmpty() && laneClips.none { it.visible }
                    Box(
                        Modifier.width(headerW).height(laneH).clip(RoundedCornerShape(8.dp))
                            .background(if (laneId == activeLayerId) c.AccentDim else c.Panel2)
                            .clickable { onActiveLane(laneId) },
                        contentAlignment = Alignment.Center,
                    ) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text("ชั้น${displayLanes.size - row}", color = laneTint(laneId), fontSize = 12.sp, fontWeight = FontWeight.Bold)
                            if (laneClips.isEmpty()) {
                                if (displayLanes.size > 1) Text("✕", color = c.Danger, fontSize = 13.sp, modifier = Modifier.clickable { layerIds.remove(laneId) }.padding(horizontal = 6.dp))
                            } else {
                                Text(if (allHidden) "🚫" else "👁", fontSize = 13.sp, modifier = Modifier.clickable {
                                    laneClips.forEach { lc -> val i = images.indexOfFirst { it.id == lc.id }; if (i >= 0) images[i] = images[i].copy(visible = allHidden) }
                                }.padding(horizontal = 6.dp))
                            }
                        }
                    }
                }
                if (hasOverlay) ExtraHeader("T", extraH)
                if (hasAudio) ExtraHeader("♫", extraH)
            }
            Box(Modifier.weight(1f).onSizeChanged { viewportPx = it.width }.horizontalScroll(hScroll)) {
                Box(
                    Modifier.width(contentWidth).height(lanesHeight)
                        .pointerInput(pps) { detectTapGestures { off -> onSeek((off.x / pps).coerceIn(0f, timelineEndNow)) } },
                ) {
                    displayLanes.forEachIndexed { row, laneId ->
                        Box(Modifier.offset(y = rowH * row).fillMaxWidth().height(laneH).background(if (laneId == activeLayerId) c.LaneActive else c.LaneBg, RoundedCornerShape(8.dp)))
                    }
                    images.forEach { clip ->
                        key(clip.id) {
                            val row = displayLanes.indexOf(clip.layerId)
                            if (row >= 0) {
                                TimelineClip(
                                    clip = clip, row = row, pps = pps, laneH = laneH, rowH = rowH,
                                    selected = clip.id == selectedId, tint = laneTint(clip.layerId),
                                    images = images, layerIds = layerIds, playhead = { playheadNow },
                                    onSelect = onSelect, onSeek = onSeek, onNewTopLane = onNewTopLane, onKeyframeEdit = onKeyframeEdit,
                                )
                            }
                        }
                    }
                    // แถวข้อความ/สติกเกอร์ และเสียง (ลากซ้าย–ขวาเพื่อเปลี่ยนเวลา)
                    var extraIndex = 0
                    if (hasOverlay) {
                        val y = rowH * displayLanes.size + (extraH + laneGap) * extraIndex
                        extraIndex++
                        Box(
                            Modifier.offset(x = with(density) { (overlayStart * pps).toDp() }, y = y)
                                .width(with(density) { (overlayDuration * pps).toDp() }).height(extraH)
                                .clip(RoundedCornerShape(8.dp)).background(c.Warn.copy(alpha = 0.85f))
                                .pointerInput(pps) {
                                    detectHorizontalDragGestures { change, amount ->
                                        change.consume()
                                        val s = safeCoerce(overlayStartNow + amount / pps, 0f, MAX_TIMELINE_SEC - overlayDurationNow)
                                        onOverlayChange(s, overlayDurationNow)
                                    }
                                },
                            contentAlignment = Alignment.CenterStart,
                        ) {
                            Text(overlayLabel, color = Color(0xFF2A1800), fontSize = 11.sp, maxLines = 1, overflow = TextOverflow.Clip, modifier = Modifier.padding(start = 8.dp, end = 16.dp))
                            Box(
                                Modifier.align(Alignment.CenterEnd).width(14.dp).fillMaxHeight().background(Color.Black.copy(alpha = 0.2f))
                                    .pointerInput(pps) {
                                        detectHorizontalDragGestures { change, amount ->
                                            change.consume()
                                            val d = safeCoerce(overlayDurationNow + amount / pps, MIN_CLIP_SEC, MAX_TIMELINE_SEC - overlayStartNow)
                                            onOverlayChange(overlayStartNow, d)
                                        }
                                    },
                                contentAlignment = Alignment.Center,
                            ) { Box(Modifier.width(3.dp).height(16.dp).background(Color.White.copy(alpha = 0.85f), RoundedCornerShape(2.dp))) }
                        }
                    }
                    if (hasAudio) {
                        val y = rowH * displayLanes.size + (extraH + laneGap) * extraIndex
                        val audioLen = maxOf(1f, timelineEnd - audioStart)
                        Box(
                            Modifier.offset(x = with(density) { (audioStart * pps).toDp() }, y = y)
                                .width(with(density) { (audioLen * pps).toDp() }).height(extraH)
                                .clip(RoundedCornerShape(8.dp)).background(c.Ok.copy(alpha = 0.75f))
                                .pointerInput(pps) {
                                    detectHorizontalDragGestures { change, amount ->
                                        change.consume()
                                        onAudioStart(safeCoerce(audioStartNow + amount / pps, 0f, MAX_TIMELINE_SEC))
                                    }
                                },
                            contentAlignment = Alignment.CenterStart,
                        ) { Text("♫ ${audioName ?: ""}", color = Color(0xFF042316), fontSize = 11.sp, maxLines = 1, overflow = TextOverflow.Clip, modifier = Modifier.padding(horizontal = 8.dp)) }
                    }
                    // เส้นเวลา
                    Box(Modifier.zIndex(5f).offset(x = with(density) { (playhead * pps).toDp() } - 1.dp).width(2.dp).fillMaxHeight().background(c.PlayRed))
                }
            }
        }
        Text(
            "แตะเพื่อเลือก · กดค้างแล้วลากซ้าย–ขวาเปลี่ยนเวลา · ลากขึ้น–ลงย้ายแทร็ก · ลากขอบคลิปปรับระยะเวลา · คลิปที่ทับกันซ้อนตามแทร็ก (V สูงอยู่บน)",
            color = c.Sub, fontSize = 10.sp, lineHeight = 13.sp,
        )
    }
}

@Composable
private fun ExtraHeader(label: String, height: Dp) {
    Box(Modifier.width(46.dp).height(height).clip(RoundedCornerShape(8.dp)).background(StudioColors.Panel2), contentAlignment = Alignment.Center) {
        Text(label, color = StudioColors.Sub, fontSize = 13.sp, fontWeight = FontWeight.Bold)
    }
}

/** ปุ่มไอคอนเล็กบนแถบหัวเรื่อง */
@Composable
private fun HeaderIconButton(icon: String, enabled: Boolean, onClick: () -> Unit) {
    val c = StudioColors
    Box(
        Modifier.size(36.dp).clip(RoundedCornerShape(12.dp)).background(c.Panel2).border(1.dp, c.Line, RoundedCornerShape(12.dp))
            .clickable(enabled = enabled, onClick = onClick),
        contentAlignment = Alignment.Center,
    ) { Text(icon, fontSize = 16.sp, color = if (enabled) c.Ink else c.Sub) }
}

@Composable
private fun TimelineClip(
    clip: StudioImage, row: Int, pps: Float, laneH: Dp, rowH: Dp, selected: Boolean, tint: Color,
    images: SnapshotStateList<StudioImage>, layerIds: SnapshotStateList<Int>,
    playhead: () -> Float, onSelect: (Int) -> Unit, onSeek: (Float) -> Unit, onNewTopLane: () -> Int,
    onKeyframeEdit: (Int) -> Unit = {},
) {
    val density = LocalDensity.current
    val latest by rememberUpdatedState(clip)
    val latestRow by rememberUpdatedState(row)
    val latestPps by rememberUpdatedState(pps)
    val latestPlayhead by rememberUpdatedState(playhead)
    var dragging by remember { mutableStateOf(false) }
    val rowPx = with(density) { rowH.toPx() }
    val snapPx = with(density) { 10.dp.toPx() }

    // แม่เหล็ก: ดูดเข้าหาจุดเริ่ม/จบของคลิปอื่น, เส้นเวลา, และจุด 0
    fun magnet(t: Float, ignoreId: Int): Float? {
        val thresh = snapPx / latestPps
        var best: Float? = null
        var bestDist = Float.MAX_VALUE
        fun consider(target: Float) { val d = abs(target - t); if (d < thresh && d < bestDist) { best = target; bestDist = d } }
        consider(0f); consider(latestPlayhead())
        images.forEach { if (it.id != ignoreId) { consider(it.startTime); consider(clipEnd(it)) } }
        return best
    }
    fun roundTenth(t: Float) = (t * 10f).roundToInt() / 10f
    fun setClip(id: Int, block: (StudioImage) -> StudioImage) {
        val i = images.indexOfFirst { it.id == id }
        if (i >= 0) images[i] = block(images[i])
    }

    val widthDp = with(density) { (clip.duration * pps).toDp() }
    val color = if (selected) tint else tint.copy(alpha = 0.7f)
    Box(
        Modifier.offset(x = with(density) { (clip.startTime * pps).toDp() }, y = rowH * row)
            .width(widthDp).height(laneH)
            .zIndex(if (dragging) 3f else if (selected) 1f else 0f)
            .clip(RoundedCornerShape(10.dp))
            .background(color.copy(alpha = 0.35f))
            .border(if (selected) 2.dp else 1.dp, if (selected) Color.White else color, RoundedCornerShape(10.dp))
            .pointerInput(clip.id) { detectTapGestures(onTap = { onSelect(latest.id) }) }
            // กดค้างแล้วลาก: ซ้าย–ขวา = เปลี่ยนเวลา · ขึ้น–ลง = ย้ายแทร็ก
            .pointerInput(clip.id) {
                var startAt = 0f
                var startRow = 0
                var dx = 0f
                var dy = 0f
                var blocked = false
                val created = mutableSetOf<Int>()
                fun finishDrop() {
                    dragging = false
                    val cur = latest
                    // คลิปทับกันในแทร็กเดียวกันไม่ได้: ย้ายไปแทร็กว่างที่ใกล้ที่สุด (ไม่มีก็สร้างแทร็กใหม่ด้านบน)
                    if (!laneIsFree(images, cur.layerId, cur.startTime, cur.duration, cur.id)) {
                        val ids = layerIds.sortedDescending()
                        val rowNow = ids.indexOf(cur.layerId)
                        val order = ids.indices.sortedBy { abs(it - rowNow) * 2 + if (it > rowNow) 1 else 0 }
                        val free = order.map { ids[it] }.firstOrNull { laneIsFree(images, it, cur.startTime, cur.duration, cur.id) }
                        val lane = free ?: onNewTopLane()
                        setClip(cur.id) { it.copy(layerId = lane) }
                    }
                    created.forEach { id -> if (images.none { it.layerId == id } && layerIds.size > 1) layerIds.remove(id) }
                    created.clear()
                }
                detectDragGesturesAfterLongPress(
                    onDragStart = {
                        val cur = latest
                        blocked = cur.locked
                        startAt = cur.startTime
                        startRow = latestRow
                        dx = 0f; dy = 0f
                        created.clear()
                        dragging = true
                        onSelect(cur.id)
                    },
                    onDrag = { change, amount ->
                        change.consume()
                        if (!blocked) {
                            dx += amount.x; dy += amount.y
                            val cur = latest
                            val maxStart = (MAX_TIMELINE_SEC - cur.duration).coerceAtLeast(0f)
                            val raw = safeCoerce(startAt + dx / latestPps, 0f, maxStart)
                            val ms = magnet(raw, cur.id)
                            val me = magnet(raw + cur.duration, cur.id)
                            val newStart = safeCoerce(
                                when { ms != null -> ms; me != null -> me - cur.duration; else -> roundTenth(raw) }, 0f, maxStart,
                            )
                            val shift = (dy / rowPx).roundToInt()
                            if (startRow + shift < 0) { created.add(onNewTopLane()); startRow += 1 }
                            val targetRow = startRow + shift
                            val ids = layerIds.sortedDescending()
                            val laneId = ids[targetRow.coerceIn(0, ids.lastIndex)]
                            setClip(cur.id) { it.copy(startTime = newStart, layerId = laneId) }
                        }
                    },
                    onDragEnd = { finishDrop() },
                    onDragCancel = { finishDrop() },
                )
            },
    ) {
        Image(
            clip.bitmap.asImageBitmap(), null,
            Modifier.fillMaxSize().graphicsLayer(alpha = if (clip.visible) 0.65f else 0.2f),
            contentScale = ContentScale.Crop,
        )
        Box(Modifier.align(Alignment.BottomCenter).fillMaxWidth().height(20.dp).background(Brush.verticalGradient(listOf(Color.Transparent, Color(0xCC000000)))))
        Text(
            "${if (clip.locked) "🔒 " else ""}${if (!clip.visible) "🚫 " else ""}${clipLabel(clip)} · ${f1(clip.duration)}s",
            color = Color.White, fontSize = 10.sp, maxLines = 1, overflow = TextOverflow.Clip,
            modifier = Modifier.align(Alignment.BottomStart).padding(start = 16.dp, end = 16.dp, bottom = 2.dp),
        )
        // ขอบซ้าย: ปรับจุดเริ่ม (จุดจบคงเดิม)
        Box(
            Modifier.align(Alignment.CenterStart).width(14.dp).fillMaxHeight().background(Color.Black.copy(alpha = 0.3f))
                .pointerInput(clip.id) {
                    var baseStart = 0f
                    var baseEnd = 0f
                    var baseKeys: List<StudioKeyframe> = emptyList()
                    var baseOffset = 0f
                    var acc = 0f
                    var blocked = false
                    detectHorizontalDragGestures(
                        onDragStart = {
                            val cur = latest
                            baseStart = cur.startTime; baseEnd = clipEnd(cur); baseKeys = cur.keyframes; baseOffset = cur.videoOffset
                            acc = 0f; blocked = cur.locked
                            onSelect(cur.id)
                        },
                        onHorizontalDrag = { change, amount ->
                            change.consume()
                            acc += amount
                            if (!blocked) {
                                val cur = latest
                                val prevEnd = images.filter { it.id != cur.id && it.layerId == cur.layerId && clipEnd(it) <= baseStart + 0.01f }.maxOfOrNull { clipEnd(it) } ?: 0f
                                val raw = baseStart + acc / latestPps
                                val snapped = magnet(raw, cur.id) ?: roundTenth(raw)
                                val minStart = if (isVideoClip(cur)) maxOf(prevEnd, baseStart - baseOffset) else prevEnd // วิดีโอ: ขยายซ้ายได้ไม่เกินหัวไฟล์
                                val ns = safeCoerce(snapped, minStart, baseEnd - MIN_CLIP_SEC)
                                val nd = baseEnd - ns
                                val shift = ns - baseStart
                                setClip(cur.id) { it.copy(startTime = ns, duration = nd, keyframes = baseKeys.map { k -> k.copy(time = (k.time - shift).coerceIn(0f, nd)) },
                                    videoOffset = if (isVideoClip(it)) (baseOffset + shift).coerceAtLeast(0f) else it.videoOffset) }
                            }
                        },
                    )
                },
            contentAlignment = Alignment.Center,
        ) { Box(Modifier.width(3.dp).height(22.dp).background(Color.White.copy(alpha = 0.85f), RoundedCornerShape(2.dp))) }
        // ขอบขวา: ปรับระยะเวลา
        Box(
            Modifier.align(Alignment.CenterEnd).width(14.dp).fillMaxHeight().background(Color.Black.copy(alpha = 0.3f))
                .pointerInput(clip.id) {
                    var baseDuration = 0f
                    var acc = 0f
                    var blocked = false
                    detectHorizontalDragGestures(
                        onDragStart = {
                            val cur = latest
                            baseDuration = cur.duration; acc = 0f; blocked = cur.locked
                            onSelect(cur.id)
                        },
                        onHorizontalDrag = { change, amount ->
                            change.consume()
                            acc += amount
                            if (!blocked) {
                                val cur = latest
                                val nextStart = images.filter { it.id != cur.id && it.layerId == cur.layerId && it.startTime >= cur.startTime + 0.01f }.minOfOrNull { it.startTime } ?: MAX_TIMELINE_SEC
                                val srcEnd = if (isVideoClip(cur)) cur.startTime + (cur.videoLength - cur.videoOffset) else Float.MAX_VALUE // วิดีโอ: ยืดเกินความยาวไฟล์ไม่ได้
                                val maxEnd = minOf(nextStart, MAX_TIMELINE_SEC, srcEnd)
                                val raw = cur.startTime + baseDuration + acc / latestPps
                                val snapped = magnet(raw, cur.id) ?: roundTenth(raw)
                                val end = safeCoerce(snapped, cur.startTime + MIN_CLIP_SEC, maxEnd)
                                setClip(cur.id) { it.copy(duration = end - cur.startTime) }
                            }
                        },
                    )
                },
            contentAlignment = Alignment.Center,
        ) { Box(Modifier.width(3.dp).height(22.dp).background(Color.White.copy(alpha = 0.85f), RoundedCornerShape(2.dp))) }
        // จุด Keyframe (◆) อยู่กลางแถบภาพ: แตะ = เลือกคลิปและเลื่อนเส้นเวลาไปที่จุดนั้น · กดค้างแล้วลากซ้าย–ขวา = ย้ายเวลาของจุด (ไม่ข้ามจุดอื่น)
        clip.keyframes.forEachIndexed { idx, k ->
            val halfPx = with(density) { 15.dp.toPx() }
            val xPx = safeCoerce(k.time * pps, halfPx, clip.duration * pps - halfPx)
            val atPlayhead = selected && abs(k.time - (latestPlayhead() - clip.startTime)) < 0.05f
            Box(
                Modifier.align(Alignment.CenterStart)
                    .offset(x = with(density) { (xPx - halfPx).toDp() })
                    .size(30.dp)
                    .pointerInput(clip.id, idx) {
                        detectTapGestures(onTap = {
                            val kt = latest.keyframes.getOrNull(idx)?.time ?: return@detectTapGestures
                            onSelect(latest.id); onSeek(latest.startTime + kt)
                        })
                    }
                    .pointerInput(clip.id, idx) {
                        var acc = 0f
                        var baseT = 0f
                        var began = false
                        detectDragGesturesAfterLongPress(
                            onDragStart = {
                                acc = 0f; began = false
                                baseT = latest.keyframes.getOrNull(idx)?.time ?: 0f
                                onSelect(latest.id)
                            },
                            onDragEnd = { began = false },
                            onDragCancel = { began = false },
                            onDrag = { change, drag ->
                                change.consume()
                                acc += drag.x
                                val cur = latest
                                val me = cur.keyframes.getOrNull(idx) ?: return@detectDragGesturesAfterLongPress
                                val lo = (cur.keyframes.getOrNull(idx - 1)?.time ?: -0.05f) + 0.05f
                                val hi = (cur.keyframes.getOrNull(idx + 1)?.time ?: (cur.duration + 0.05f)) - 0.05f
                                val newT = safeCoerce(roundTenth(baseT + acc / latestPps), maxOf(0f, lo), minOf(cur.duration, hi))
                                if (newT != me.time) {
                                    if (!began) { began = true; onKeyframeEdit(cur.id) } // ก้าวย้อนกลับเดียวต่อการลาก
                                    setClip(cur.id) { c0 -> c0.copy(keyframes = c0.keyframes.mapIndexed { i2, kk -> if (i2 == idx) kk.copy(time = newT) else kk }) }
                                    onSeek(cur.startTime + newT)
                                }
                            },
                        )
                    },
                contentAlignment = Alignment.Center,
            ) {
                Box(
                    Modifier.size(20.dp).graphicsLayer(rotationZ = 45f)
                        .background(if (atPlayhead) StudioColors.Accent else StudioColors.Warn)
                        .border(1.5.dp, Color(0xFF1A1200)),
                )
            }
        }
    }
}

// ───────────────────────── ตัวอย่างการเคลื่อนไหวของสไตล์ที่เลือก ─────────────────────────

/** กรอบเล็กเล่นวนซ้ำ: ใช้ค่าจาก presetKeyframes และวิธีวาดเดียวกับ Canvas หลัก (หน่วยโลก 600 ต่อด้านสั้นของเฟรม) */
@Composable
private fun MotionPreview(bitmap: Bitmap, preset: String) {
    val c = StudioColors
    val density = LocalDensity.current
    val period = 2f
    var t by remember { mutableFloatStateOf(0f) }
    LaunchedEffect(Unit) {
        var last = withFrameNanos { it }
        while (true) {
            val now = withFrameNanos { it }
            t = (t + (now - last) / 1_000_000_000f) % period
            last = now
        }
    }
    val keys = remember(preset) { presetKeyframes(period, preset) }
    val a = keys.first()
    val b = keys.last()
    val f = (t / period).coerceIn(0f, 1f)
    val side = 140.dp
    val unit = with(density) { side.toPx() } / Exporter.WORLD_WINDOW
    Box(Modifier.size(side).clip(RoundedCornerShape(12.dp)).background(Color.Black).border(1.dp, c.Line, RoundedCornerShape(12.dp))) {
        Image(
            bitmap.asImageBitmap(), null,
            Modifier.fillMaxSize().graphicsLayer(
                translationX = (a.x + (b.x - a.x) * f) * unit, translationY = (a.y + (b.y - a.y) * f) * unit,
                scaleX = a.scale + (b.scale - a.scale) * f, scaleY = a.scale + (b.scale - a.scale) * f,
                rotationZ = a.rotation + (b.rotation - a.rotation) * f,
            ),
            contentScale = ContentScale.Fit,
        )
    }
}

// ───────────────────────── กล่องโต้ตอบ: ปรับแต่งคลิป ─────────────────────────

@Composable
private fun ClipPropertiesDialog(
    clip: StudioImage, playhead: Float, animationMode: Boolean, motionPreset: String,
    onUpdate: ((StudioImage) -> StudioImage) -> Unit,
    onAnimationMode: (Boolean) -> Unit, onPreset: (String) -> Unit,
    onStatus: (String) -> Unit, onDismiss: () -> Unit,
) {
    val c = StudioColors
    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = c.Panel, titleContentColor = c.Ink, textContentColor = c.Ink,
        title = { Text("ปรับแต่งคลิป") },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(value = clip.name, onValueChange = { v -> onUpdate { it.copy(name = v) } }, label = { Text("ชื่อคลิป") }, singleLine = true, colors = studioFieldColors())
                Text("เริ่ม ${f1(clip.startTime)} วิ · ยาว ${f1(clip.duration)} วิ · จบ ${f1(clipEnd(clip))} วิ", color = c.Sub, fontSize = 12.sp)
                Text("ความทึบ ${(clip.opacity * 100).toInt()}%", color = c.Ink, fontSize = 13.sp)
                Slider(
                    value = clip.opacity, onValueChange = { v -> onUpdate { it.copy(opacity = v) } }, valueRange = 0f..1f,
                    colors = SliderDefaults.colors(thumbColor = c.Accent, activeTrackColor = c.Accent, inactiveTrackColor = c.Line),
                )
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    ToolChip("รีเซ็ตตำแหน่ง/ขนาด", onClick = { onUpdate { it.copy(x = 0f, y = 0f, scale = 1f, rotation = 0f, opacity = 1f, keyframes = emptyList()) } }, enabled = !clip.locked)
                }
                Spacer(Modifier.height(2.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text("โหมดภาพเคลื่อนไหว", color = c.Ink, fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
                        Text("ภาพที่เพิ่มใหม่จะได้คีย์เฟรมตามรูปแบบที่เลือกอัตโนมัติ", color = c.Sub, fontSize = 11.sp)
                    }
                    Switch(checked = animationMode, onCheckedChange = onAnimationMode)
                }
                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    listOf("เลื่อนภาพ", "หมุนเบาๆ", "เลื่อนและหมุน").forEach { preset ->
                        ToolChip(preset, highlight = motionPreset == preset, onClick = { onPreset(preset) })
                    }
                }
                Text("ตัวอย่าง: $motionPreset (วนซ้ำทุก 2 วินาที)", color = c.Sub, fontSize = 11.sp)
                Box(Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) { MotionPreview(clip.bitmap, motionPreset) }
                ToolChip("ใส่การเคลื่อนไหวให้คลิปนี้", enabled = !clip.locked, onClick = {
                    onUpdate { it.copy(keyframes = presetKeyframes(it.duration, motionPreset).map { k -> k.copy(sculpt = it.sculpt) }) }
                    onStatus("ใส่การเคลื่อนไหว \"$motionPreset\" แล้ว")
                })
            }
        },
        confirmButton = { TextButton(onClick = onDismiss) { Text("เสร็จสิ้น", color = c.Accent) } },
    )
}

// ───────────────────────── กล่องโต้ตอบ: ข้อความ/สติกเกอร์/เสียง ─────────────────────────

@Composable
private fun ExtrasDialog(
    overlayText: String, overlaySticker: String, audioName: String?, audioVolume: Float,
    onText: (String) -> Unit, onSticker: (String) -> Unit, onClearOverlay: () -> Unit,
    onVolume: (Float) -> Unit, onPickAudio: () -> Unit, onRemoveAudio: () -> Unit, onDismiss: () -> Unit,
) {
    val c = StudioColors
    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = c.Panel, titleContentColor = c.Ink, textContentColor = c.Ink,
        title = { Text("ข้อความ สติกเกอร์ และเสียง") },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(value = overlayText, onValueChange = onText, label = { Text("ข้อความบนภาพ") }, singleLine = true, colors = studioFieldColors())
                Text("สติกเกอร์", color = c.Sub, fontSize = 12.sp)
                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    listOf("⭐", "❤️", "✨", "🔥", "🌟").forEach { s -> ToolChip(s, highlight = overlaySticker == s, onClick = { onSticker(s) }) }
                }
                ToolChip("ล้างข้อความ/สติกเกอร์", danger = true, onClick = onClearOverlay)
                Text("ลากแถบสีส้ม (T) บน Timeline เพื่อกำหนดเวลา และลากขอบขวาเพื่อปรับความยาว", color = c.Sub, fontSize = 11.sp)
                Spacer(Modifier.height(4.dp))
                Text("เสียง", color = c.Ink, fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
                if (audioName != null) {
                    Text("♫ $audioName", color = c.Ok, fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    Text("ระดับเสียง ${(audioVolume * 100).toInt()}%", color = c.Ink, fontSize = 13.sp)
                    Slider(value = audioVolume, onValueChange = onVolume, valueRange = 0f..1f, colors = SliderDefaults.colors(thumbColor = c.Ok, activeTrackColor = c.Ok, inactiveTrackColor = c.Line))
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        ToolChip("เปลี่ยนไฟล์เสียง", onClick = onPickAudio)
                        ToolChip("ลบเสียง", danger = true, onClick = onRemoveAudio)
                    }
                    Text("ลากแถบสีเขียว (♫) บน Timeline เพื่อกำหนดเวลาเริ่มเสียง", color = c.Sub, fontSize = 11.sp)
                } else {
                    ToolChip("＋ เพิ่มไฟล์เสียง", onClick = onPickAudio, highlight = true)
                }
            }
        },
        confirmButton = { TextButton(onClick = onDismiss) { Text("เสร็จสิ้น", color = c.Accent) } },
    )
}

// ───────────────────────── ตั้งค่า ─────────────────────────

@Composable
fun ImageStudioSettings(onOpen: () -> Unit) {
    val context = LocalContext.current
    var enabled by remember { mutableStateOf(ImageStudioPrefs.enabled(context)) }
    var ask by remember { mutableStateOf(ImageStudioPrefs.ask(context)) }
    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Text("โหมดรูปภาพ", style = MaterialTheme.typography.titleSmall, color = MaterialTheme.colorScheme.primary)
        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text("เปิดใช้งานโหมดรูปภาพ")
                Text("สร้างวิดีโอและแอนิเมชันจากภาพนิ่ง", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            Switch(checked = enabled, onCheckedChange = { enabled = it; ImageStudioPrefs.setEnabled(context, it) })
        }
        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text("ถามก่อนเริ่มทำ")
                Text("แสดงหน้าต่างยืนยันก่อนเข้าโหมด", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            Switch(checked = ask, onCheckedChange = { ask = it; ImageStudioPrefs.setAsk(context, it) }, enabled = enabled)
        }
        OutlinedButton(onClick = onOpen, enabled = enabled, modifier = Modifier.fillMaxWidth()) { Text("เปิดโหมดรูปภาพ") }
    }
}
