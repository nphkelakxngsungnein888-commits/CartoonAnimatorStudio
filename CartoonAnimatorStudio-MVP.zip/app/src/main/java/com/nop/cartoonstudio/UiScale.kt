package com.nop.cartoonstudio

import android.content.Context
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Slider
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Density
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlin.math.roundToInt

/**
 * ขนาดปุ่ม/เมนู/ตัวหนังสือ (UI) ของทั้งแอป — ตั้งในเมนูตั้งค่า
 *
 * หลักการ: คูณ "ความหนาแน่นจอ" (Density) ของทั้งแอปด้วยค่าเดียว ทำให้ dp และ sp ทุกตัวย่อ/ขยายพร้อมกัน
 * ปุ่ม ช่องว่าง ขอบมน ไอคอน ตัวหนังสือ กล่องโต้ตอบ และทุกหน้า (แอนิเมต / สร้างตัวละคร / ครอปรูป / ส่งออก)
 * จึงสเกลเป็นสัดส่วนเดียวกันเสมอ ไม่แยกกัน ตัวหนังสือจึงไม่ล้นปุ่ม
 *
 * 1.0 (100%) = ขนาดปัจจุบันซึ่งเป็นขนาดใหญ่สุด · เล็กสุด = 1/3 ของขนาดปัจจุบัน (33%)
 * ผืนผ้าใบและงานที่วาดไม่ถูกแตะ (พิกัดโลก/พิกเซลคงเดิม) มีแต่ส่วนควบคุมที่ย่อ/ขยาย
 */
object UiScale {
    const val MIN = 1f / 3f
    const val MAX = 1f
    const val DEFAULT = 1f

    private const val PREFS = "ui_prefs"
    private const val KEY = "ui_scale"

    /** ค่าปัจจุบัน (Compose อ่านแล้วจะวาดใหม่ทั้งแอปเมื่อค่าเปลี่ยน) */
    var value by mutableFloatStateOf(DEFAULT)
        private set

    /** ปัดเป็นทีละ 1% และกันค่านอกช่วง/ค่าเพี้ยน (NaN) */
    fun sanitize(v: Float): Float {
        if (v.isNaN()) return DEFAULT
        return ((v * 100f).roundToInt() / 100f).coerceIn(MIN, MAX)
    }

    /** เรียกตอนเปิดแอป ก่อน setContent เพื่อไม่ให้หน้าจอกระพริบจากขนาดเต็มเป็นขนาดที่ตั้งไว้ */
    fun load(context: Context) {
        value = try {
            sanitize(context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getFloat(KEY, DEFAULT))
        } catch (e: Throwable) {
            DEFAULT
        }
    }

    fun set(context: Context, v: Float) {
        value = sanitize(v)
        try {
            context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putFloat(KEY, value).apply()
        } catch (_: Throwable) {
            // เก็บไม่สำเร็จ: ยังใช้ค่านี้ได้ในรอบนี้ (แค่ไม่จำข้ามการเปิดแอป)
        }
    }

    fun reset(context: Context) = set(context, DEFAULT)
}

/** ครอบทั้งแอป: คูณความหนาแน่นด้วย UiScale (ขนาดฟอนต์ที่ผู้ใช้ตั้งในระบบ Android ยังมีผลตามเดิม) */
@Composable
fun ProvideUiScale(content: @Composable () -> Unit) {
    val base = LocalDensity.current
    val s = UiScale.value
    val scaled = remember(base.density, base.fontScale, s) { Density(base.density * s, base.fontScale) }
    CompositionLocalProvider(LocalDensity provides scaled, content = content)
}

/**
 * ช่องปรับขนาดปุ่มและ UI ในเมนูตั้งค่า: สไลเดอร์ + ปุ่มลัด + ตัวอย่าง + รีเซ็ต
 *
 * ระหว่างลากสไลเดอร์ "ยังไม่ใช้จริง" แต่โชว์ตัวอย่างสดแทน แล้วจึงใช้ตอนปล่อยนิ้ว
 * เพราะถ้าสเกลทั้งแอปทันทีขณะลาก สไลเดอร์ที่นิ้วจับอยู่จะหดขยายตามไปด้วย ทำให้ค่ากระโดดไปมา/สั่น
 */
@Composable
fun UiScaleSetting() {
    val context = LocalContext.current
    val applied = UiScale.value
    var draft by remember { mutableFloatStateOf(applied) }
    var dragging by remember { mutableStateOf(false) }
    LaunchedEffect(applied) { if (!dragging) draft = applied }

    val card = RoundedCornerShape(16.dp)
    val draftPct = (UiScale.sanitize(draft) * 100f).roundToInt()
    Column(
        Modifier
            .fillMaxWidth()
            .clip(card)
            .background(Palette.PanelHigh)
            .border(1.dp, Palette.Stroke, card)
            .padding(12.dp),
        verticalArrangement = Arrangement.spacedBy(6.dp),
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("ขนาดปุ่มและ UI", Modifier.weight(1f), fontWeight = FontWeight.Bold, color = Palette.Accent)
            Text("$draftPct%", color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.Bold)
        }

        Slider(
            value = draft,
            onValueChange = { dragging = true; draft = it.coerceIn(UiScale.MIN, UiScale.MAX) },
            onValueChangeFinished = {
                dragging = false
                UiScale.set(context, draft)
                draft = UiScale.value
            },
            valueRange = UiScale.MIN..UiScale.MAX,
        )

        // ปุ่มลัด
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            listOf(33, 50, 75, 100).forEach { pct ->
                FilterChip(
                    selected = draftPct == pct,
                    onClick = { dragging = false; UiScale.set(context, pct / 100f); draft = UiScale.value },
                    label = { Text("$pct%", maxLines = 1) },
                )
            }
        }

        // ตัวอย่างสด: วาดที่ขนาด "ที่กำลังเลือก" เทียบกับขนาดที่ใช้อยู่ตอนนี้
        val base = LocalDensity.current
        val ratio = UiScale.sanitize(draft) / applied
        val previewDensity = remember(base.density, base.fontScale, ratio) { Density(base.density * ratio, base.fontScale) }
        Box(
            Modifier
                .fillMaxWidth()
                .height(96.dp)
                .clip(RoundedCornerShape(12.dp))
                .background(Palette.Panel)
                .border(1.dp, Palette.Stroke, RoundedCornerShape(12.dp)),
            contentAlignment = Alignment.Center,
        ) {
            CompositionLocalProvider(LocalDensity provides previewDensity) {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Box(
                        Modifier
                            .size(24.dp)
                            .clip(CircleShape)
                            .background(Palette.PanelHigh)
                            .border(1.dp, Palette.Stroke, CircleShape),
                        contentAlignment = Alignment.Center,
                    ) { Text("⚙", fontSize = 12.sp) }
                    Box(
                        Modifier
                            .height(24.dp)
                            .clip(RoundedCornerShape(50))
                            .background(Palette.Accent)
                            .padding(horizontal = 12.dp),
                        contentAlignment = Alignment.Center,
                    ) { Text("ตัวอย่าง", fontSize = 12.sp, color = Color(0xFF2A1A66), fontWeight = FontWeight.Medium) }
                }
            }
        }

        OutlinedButton(
            onClick = { dragging = false; UiScale.reset(context); draft = UiScale.value },
            enabled = applied != UiScale.DEFAULT || draft != UiScale.DEFAULT,
            modifier = Modifier.fillMaxWidth(),
        ) { Text("รีเซ็ตขนาด (100%)") }

        Text(
            "ย่อ/ขยายทั้งแอป (ปุ่ม เมนู ตัวหนังสือ ทุกหน้า) พร้อมกันในสัดส่วนเดียวกัน · 100% = ใหญ่สุด เล็กสุด 33% (เล็กกว่าปัจจุบัน 3 เท่า) · ลากแล้วปล่อยเพื่อใช้",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
    }
}

/**
 * ขนาดแว่นขยายในหน้าตัดภาพ/ยางลบ/จอย: ตั้งเป็นเลข 10–100
 * 10 = ขนาดเดิม (กล่องกว้าง 130 dp) · 100 = ใหญ่สุด (90% ของด้านสั้นของพื้นที่ภาพ) · ระหว่างนั้นไล่ขนาดเป็นเส้นตรง
 */
object LoupeSize {
    const val MIN = 10f
    const val MAX = 100f
    const val DEFAULT = 10f

    private const val PREFS = "ui_prefs"
    private const val KEY = "loupe_size"

    var value by mutableFloatStateOf(DEFAULT)
        private set

    fun sanitize(v: Float): Float {
        if (v.isNaN()) return DEFAULT
        return v.roundToInt().toFloat().coerceIn(MIN, MAX)
    }

    fun load(context: Context) {
        value = try {
            sanitize(context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getFloat(KEY, DEFAULT))
        } catch (e: Throwable) {
            DEFAULT
        }
    }

    fun set(context: Context, v: Float) {
        value = sanitize(v)
        try {
            context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putFloat(KEY, value).apply()
        } catch (_: Throwable) {
            // เก็บไม่สำเร็จ: ใช้ค่านี้ในรอบนี้ได้ (แค่ไม่จำข้ามการเปิดแอป)
        }
    }

    /** ขนาดกล่องแว่นขยายเป็นพิกเซล: density = ความหนาแน่นจอ, shortSide = ด้านสั้นของพื้นที่ภาพ (พิกเซล) */
    fun boxPx(density: Float, shortSide: Float): Float {
        val basePx = 130f * density
        val maxPx = maxOf(basePx, shortSide * 0.9f)
        val t = (value - MIN) / (MAX - MIN)
        return basePx + (maxPx - basePx) * t
    }
}

/** ช่องปรับขนาดแว่นขยายในเมนูตั้งค่า: สไลเดอร์ 10–100 + ช่องตัวเลข (แตะแล้วขึ้นแผงเลข) + รีเซ็ต */
@Composable
fun LoupeSizeSetting() {
    val context = LocalContext.current
    var showPad by remember { mutableStateOf(false) }
    var draft by remember { mutableFloatStateOf(LoupeSize.value) }
    var dragging by remember { mutableStateOf(false) }
    LaunchedEffect(LoupeSize.value) { if (!dragging) draft = LoupeSize.value }

    val card = RoundedCornerShape(16.dp)
    Column(
        Modifier
            .fillMaxWidth()
            .clip(card)
            .background(Palette.PanelHigh)
            .border(1.dp, Palette.Stroke, card)
            .padding(12.dp),
        verticalArrangement = Arrangement.spacedBy(6.dp),
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("ขนาดแว่นขยาย", Modifier.weight(1f), fontWeight = FontWeight.Bold, color = Palette.Accent)
            Box(
                Modifier
                    .clip(RoundedCornerShape(50))
                    .background(Palette.Panel)
                    .border(1.dp, Palette.Accent, RoundedCornerShape(50))
                    .clickable { showPad = true }
                    .padding(horizontal = 14.dp, vertical = 4.dp),
            ) { Text("${LoupeSize.sanitize(draft).roundToInt()}  ✎", color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.Bold) }
        }
        Slider(
            value = draft,
            onValueChange = { dragging = true; draft = it.coerceIn(LoupeSize.MIN, LoupeSize.MAX) },
            onValueChangeFinished = {
                dragging = false
                LoupeSize.set(context, draft)
                draft = LoupeSize.value
            },
            valueRange = LoupeSize.MIN..LoupeSize.MAX,
        )
        OutlinedButton(
            onClick = { dragging = false; LoupeSize.set(context, LoupeSize.DEFAULT); draft = LoupeSize.value },
            enabled = LoupeSize.value != LoupeSize.DEFAULT || draft != LoupeSize.DEFAULT,
            modifier = Modifier.fillMaxWidth(),
        ) { Text("รีเซ็ตขนาด (10)") }
        Text(
            "ขนาดกล่องแว่นขยายที่โผล่ตอนลากนิ้วในหน้าตัดภาพ ยางลบ และจอย · 10 = ขนาดเดิม · 100 = ใหญ่สุด (ประมาณ 90% ของด้านสั้นของพื้นที่ภาพ)",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
    }
    if (showPad) {
        NumberPadDialog(
            title = "ขนาดแว่นขยาย (10–100)",
            unit = "",
            initial = LoupeSize.value,
            onDismiss = { showPad = false },
            onOk = { v ->
                LoupeSize.set(context, v)
                draft = LoupeSize.value
                showPad = false
            },
        )
    }
}

/** ช่องปรับขนาดแผงตัวเลขลอยในเมนูตั้งค่า: สไลเดอร์ 10–100 (50 = ขนาดตั้งต้น) + ช่องตัวเลข + รีเซ็ต + ปุ่มจัดการปักหมุด */
@Composable
fun PadSizeSetting() {
    val context = LocalContext.current
    var showPad by remember { mutableStateOf(false) }
    var draft by remember { mutableFloatStateOf(PadPrefs.size) }
    var dragging by remember { mutableStateOf(false) }
    LaunchedEffect(PadPrefs.size) { if (!dragging) draft = PadPrefs.size }

    val card = RoundedCornerShape(16.dp)
    Column(
        Modifier
            .fillMaxWidth()
            .clip(card)
            .background(Palette.PanelHigh)
            .border(1.dp, Palette.Stroke, card)
            .padding(12.dp),
        verticalArrangement = Arrangement.spacedBy(6.dp),
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("ขนาดแผงตัวเลข", Modifier.weight(1f), fontWeight = FontWeight.Bold, color = Palette.Accent)
            Box(
                Modifier
                    .clip(RoundedCornerShape(50))
                    .background(Palette.Panel)
                    .border(1.dp, Palette.Accent, RoundedCornerShape(50))
                    .clickable { showPad = true }
                    .padding(horizontal = 14.dp, vertical = 4.dp),
            ) { Text("${PadPrefs.sanitizeSize(draft).roundToInt()}  ✎", color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.Bold) }
        }
        Slider(
            value = draft,
            onValueChange = { dragging = true; draft = it.coerceIn(PadPrefs.SIZE_MIN, PadPrefs.SIZE_MAX) },
            onValueChangeFinished = {
                dragging = false
                PadPrefs.setSize(context, draft)
                draft = PadPrefs.size
            },
            valueRange = PadPrefs.SIZE_MIN..PadPrefs.SIZE_MAX,
        )
        OutlinedButton(
            onClick = { dragging = false; PadPrefs.setSize(context, PadPrefs.SIZE_DEFAULT); draft = PadPrefs.size },
            enabled = PadPrefs.size != PadPrefs.SIZE_DEFAULT || draft != PadPrefs.SIZE_DEFAULT,
            modifier = Modifier.fillMaxWidth(),
        ) { Text("รีเซ็ตขนาด (50)") }
        Text(
            "ขนาดแผงตัวเลขที่ลอยขึ้นตอนใส่ค่า · 50 = ขนาดตั้งต้น น้อยกว่า = เล็กลง มากกว่า = ใหญ่ขึ้น · ในแผงลากที่แถบหัวเพื่อย้าย · ปุ่ม −/＋ ปรับขนาด · 📌 จำตำแหน่ง · ↺ กลับกลางล่าง",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
    }
    if (showPad) {
        NumberPadDialog(
            title = "ขนาดแผงตัวเลข (10–100)",
            unit = "",
            initial = PadPrefs.size,
            onDismiss = { showPad = false },
            onOk = { v ->
                PadPrefs.setSize(context, v)
                draft = PadPrefs.size
                showPad = false
            },
        )
    }
}

/** กำลังซูมของแว่นขยายในหน้าแก้ไขรูปภาพ: เท่าของระดับซูมที่ดูภาพอยู่ตอนนี้ (1.5–10 เท่า ตั้งต้น 3 เท่า) */
object LoupeZoom {
    const val MIN = 1.5f
    const val MAX = 10f
    const val DEFAULT = 3f

    private const val PREFS = "ui_prefs"
    private const val KEY = "loupe_zoom"

    var value by mutableFloatStateOf(DEFAULT)
        private set

    fun sanitize(v: Float): Float {
        if (v.isNaN()) return DEFAULT
        return ((v * 10f).roundToInt() / 10f).coerceIn(MIN, MAX)
    }

    fun load(context: Context) {
        value = try {
            sanitize(context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getFloat(KEY, DEFAULT))
        } catch (e: Throwable) {
            DEFAULT
        }
    }

    fun set(context: Context, v: Float) {
        value = sanitize(v)
        try {
            context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putFloat(KEY, value).apply()
        } catch (_: Throwable) {
            // เก็บไม่สำเร็จ: ใช้ค่านี้ในรอบนี้ได้
        }
    }
}

/** ช่องปรับกำลังซูมของแว่นขยาย: สไลเดอร์ 1.5–10 เท่า + ช่องตัวเลข (แตะแล้วขึ้นแผงเลข) + รีเซ็ต */
@Composable
fun LoupeZoomSetting() {
    val context = LocalContext.current
    var showPad by remember { mutableStateOf(false) }
    var draft by remember { mutableFloatStateOf(LoupeZoom.value) }
    var dragging by remember { mutableStateOf(false) }
    LaunchedEffect(LoupeZoom.value) { if (!dragging) draft = LoupeZoom.value }

    val card = RoundedCornerShape(16.dp)
    Column(
        Modifier
            .fillMaxWidth()
            .clip(card)
            .background(Palette.PanelHigh)
            .border(1.dp, Palette.Stroke, card)
            .padding(12.dp),
        verticalArrangement = Arrangement.spacedBy(6.dp),
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("กำลังซูมแว่นขยาย", Modifier.weight(1f), fontWeight = FontWeight.Bold, color = Palette.Accent)
            Box(
                Modifier
                    .clip(RoundedCornerShape(50))
                    .background(Palette.Panel)
                    .border(1.dp, Palette.Accent, RoundedCornerShape(50))
                    .clickable { showPad = true }
                    .padding(horizontal = 14.dp, vertical = 4.dp),
            ) { Text("×${LoupeZoom.sanitize(draft)}  ✎", color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.Bold) }
        }
        Slider(
            value = draft,
            onValueChange = { dragging = true; draft = it.coerceIn(LoupeZoom.MIN, LoupeZoom.MAX) },
            onValueChangeFinished = {
                dragging = false
                LoupeZoom.set(context, draft)
                draft = LoupeZoom.value
            },
            valueRange = LoupeZoom.MIN..LoupeZoom.MAX,
        )
        OutlinedButton(
            onClick = { dragging = false; LoupeZoom.set(context, LoupeZoom.DEFAULT); draft = LoupeZoom.value },
            enabled = LoupeZoom.value != LoupeZoom.DEFAULT || draft != LoupeZoom.DEFAULT,
            modifier = Modifier.fillMaxWidth(),
        ) { Text("รีเซ็ตกำลังซูม (×3)") }
    }
    if (showPad) {
        NumberPadDialog(
            title = "กำลังซูมแว่นขยาย (1.5–10 เท่า)",
            unit = "เท่า",
            initial = LoupeZoom.value,
            onDismiss = { showPad = false },
            onOk = { v ->
                LoupeZoom.set(context, v)
                draft = LoupeZoom.value
                showPad = false
            },
        )
    }
}
