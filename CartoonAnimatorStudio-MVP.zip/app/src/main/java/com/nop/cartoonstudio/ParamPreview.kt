package com.nop.cartoonstudio

import android.graphics.Bitmap
import android.graphics.Paint
import android.graphics.RectF
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.FloatState
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.clipToBounds
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.drawIntoCanvas
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlin.math.roundToInt

// ───────────────────────────────────────────────────────────────────────────────
//  คลังตัวอย่างค่า (Param Preview Library)
//  ทุกค่าที่ปรับได้ในเครื่องมือปั้น/บิดภาพ มีตัวอย่างวนสั้นๆ เทียบ น้อย | ค่าที่ตั้งอยู่ | มาก
//  ตัวอย่างสร้างด้วยเอนจินจริงของแอป (Sculpt.applyAdvancedWarp) บนภาพสาธิตขาว-ดำที่วาดด้วยโค้ด
//  ค่าใหม่ในอนาคต: เพิ่ม spec 1 บล็อกใน ParamPreviewRegistry.specs แล้วจะโผล่ในคลังเอง
//  ถ้าเพิ่ม property ใหม่ใน WarpSettings แต่ยังไม่มี spec คลังจะแสดงรายชื่อใต้หัวข้อ "ยังไม่มีตัวอย่าง"
// ───────────────────────────────────────────────────────────────────────────────

private val PvBg = Color(0xFF000000)
private val PvInk = Color(0xFFFFFFFF)
private val PvSub = Color(0xFF9A9A9A)
private val PvLine = Color(0xFF3A3A3A)
private val PvChip = Color(0xFF1C1C1C)

/** ข้อมูลตัวอย่างของ 1 ค่า (1 ช่องกรอกในแอป) */
class ParamSpec(
    /** ป้ายเดียวกับช่องกรอกในแอปเป๊ะๆ (ใช้จับคู่กับ SculptNumField / SignedNumField) */
    val label: String,
    /** ชื่อ property ใน WarpSettings (ใช้ตรวจว่ามีค่าไหนยังไม่มีตัวอย่าง) */
    val field: String,
    val group: String,
    /** ค่า "น้อย" และ "มาก" ของตัวอย่าง (ผู้พัฒนากำหนดให้เห็นผลชัด ไม่จำเป็นต้องเท่าขอบเขตของช่องกรอก) */
    val lo: Float,
    val hi: Float,
    val unit: String,
    val hint: String,
    val get: (WarpSettings) -> Float,
    val set: (WarpSettings, Float) -> WarpSettings,
    /** โหมดสาธิตสำรอง ใช้เมื่อเปิดจากคลัง หรือเครื่องมือที่เลือกไม่ใช่โหมดบิดขั้นสูง */
    val mode: AdvancedWarpMode? = null,
    /** true = ใช้โหมดของ spec เสมอ (ไม่ตามเครื่องมือที่เลือก) เพราะค่านี้เห็นผลเฉพาะบางโหมด */
    val forceMode: Boolean = false,
    val integer: Boolean = false,
    /** ตำแหน่งจุดวางพู่กันแนวนอน (0..1) */
    val cxFrac: Float = 0.5f,
    /** เริ่มจากตาข่ายที่ขรุขระ (ใช้กับค่าที่เกี่ยวกับการเกลี่ย/คลายตาข่าย) */
    val noisyStart: Boolean = false,
    /** ปรับค่าตั้งต้นของตัวอย่างให้เห็นผล (เช่นทำวงให้เป็นวงรีก่อนหมุน) พร้อมคำอธิบาย */
    val base: (WarpSettings) -> WarpSettings = { it },
    val baseNote: String = "",
    /** ค่าฟิสิกส์ใช้เอนจิน WarpStackMath.physicsAt แทนค่า WarpSettings */
    val physicsGet: ((WarpPhysicsSettings) -> Float)? = null,
    val physicsSet: ((WarpPhysicsSettings, Float) -> WarpPhysicsSettings)? = null,
    /** แสดงกราฟเวลาแทนภาพบิด สำหรับค่าที่ควบคุมคีย์เฟรมและจังหวะ */
    val timelinePreview: Boolean = false,
    /** ใช้เส้นทางดึงจริง เพื่อสาธิตสวิตช์ที่มีผลกับ applyGrab/brushWeights */
    val grabPreview: Boolean = false,
)

/** บริบทเครื่องมือที่เลือกอยู่ (ตั้งค่าจากแผงปั้นภาพ) เพื่อให้ตัวอย่างใช้โหมดตรงกับเครื่องมือ */
object ParamDemoContext {
    @Volatile var mode: AdvancedWarpMode? = null
}

object ParamPreviewRegistry {
    private const val G_BRUSH = "แรงและขอบพู่กัน"
    private const val G_SHAPE = "ขนาดและมุมของวงพู่กัน"
    private const val G_WAVE = "คลื่นและกระเพื่อม"
    private const val G_PRESS = "แรงกดและจังหวะ"
    private const val G_SAFE = "ความปลอดภัยและการคลายตาข่าย"
    private const val G_MESH = "ความละเอียดตาข่าย"
    private const val G_ANIM = "เวลาและแอนิเมชัน"
    private const val G_PHYSICS = "ฟิสิกส์การเคลื่อนไหว"

    private fun scale(label: String, axisX: Boolean) = ParamSpec(
        label = label, field = if (axisX) "scaleX" else "scaleY", group = G_SHAPE,
        lo = 40f, hi = 250f, unit = "%",
        hint = if (axisX) "ยืด/หดวงพู่กันตามแนวนอน (ดูวงขาวบางๆ ในภาพ)" else "ยืด/หดวงพู่กันตามแนวตั้ง (ดูวงขาวบางๆ ในภาพ)",
        get = { if (axisX) it.scaleX else it.scaleY },
        set = { s, v -> if (axisX) s.copy(scaleX = v) else s.copy(scaleY = v) },
        mode = AdvancedWarpMode.BULGE,
    )

    private fun angle(
        label: String, hint: String, mode: AdvancedWarpMode, lo: Float = -90f, hi: Float = 90f,
        base: (WarpSettings) -> WarpSettings = { it }, baseNote: String = "",
    ) = ParamSpec(
        label = label, field = "angleDeg", group = G_SHAPE, lo = lo, hi = hi, unit = "°", hint = hint,
        get = { it.angleDeg }, set = { s, v -> s.copy(angleDeg = v) }, mode = mode, base = base, baseNote = baseNote,
    )

    private fun strength(label: String, lo: Float, hi: Float, hint: String, mode: AdvancedWarpMode, noisy: Boolean = false) = ParamSpec(
        label = label, field = "strength", group = G_BRUSH, lo = lo, hi = hi, unit = "%", hint = hint,
        get = { it.strength }, set = { s, v -> s.copy(strength = v) }, mode = mode, noisyStart = noisy,
    )

    val specs: List<ParamSpec> = listOf(
        // ── แรงและขอบพู่กัน ──
        strength("ความแรงการบิด (%)", 25f, 150f, "ยิ่งมาก ภาพยิ่งถูกดัน/บีบไกลจากจุดวางพู่กัน (ถูกจำกัดด้วยระยะบิดสูงสุด)", AdvancedWarpMode.BULGE),
        strength("ความแรงการเกลี่ย (%)", 10f, 100f, "เกลี่ยตาข่ายที่ขรุขระให้เรียบ ยิ่งมากยิ่งเรียบ (ภาพเริ่มจากตาข่ายขรุขระแล้วค่อยๆ เรียบ)", AdvancedWarpMode.SMOOTH, noisy = true),
        ParamSpec(
            label = "การลดแรงจากกลางสู่ขอบ (%)", field = "falloff", group = G_BRUSH, lo = 0f, hi = 100f, unit = "%",
            hint = "น้อย = แรงเกือบเท่ากันทั้งวง · มาก = แรงตกเร็วจากกลางวงไปขอบ",
            get = { it.falloff }, set = { s, v -> s.copy(falloff = v) }, mode = AdvancedWarpMode.BULGE,
        ),
        ParamSpec(
            label = "ความแข็งขอบพู่กัน (%)", field = "hardness", group = G_BRUSH, lo = 0f, hi = 95f, unit = "%",
            hint = "มาก = บริเวณกลางวงที่ได้แรงเต็มกว้างขึ้น ขอบวงชัดขึ้น",
            get = { it.hardness }, set = { s, v -> s.copy(hardness = v) }, mode = AdvancedWarpMode.BULGE,
        ),
        ParamSpec(
            label = "ความนุ่มของผลบิด (%)", field = "smoothness", group = G_BRUSH, lo = 0f, hi = 100f, unit = "%",
            hint = "มาก = การไล่แรงจากกลางสู่ขอบเนียนขึ้น (ผสมกับเส้นโค้งแบบนุ่ม)",
            get = { it.smoothness }, set = { s, v -> s.copy(smoothness = v) }, mode = AdvancedWarpMode.BULGE,
        ),

        // ── ขนาดและมุมของวงพู่กัน ──
        scale("ขนาดวงแนวนอน (%)", true), scale("ขนาดวงแนวตั้ง (%)", false),
        scale("สเกลแนวนอน (%)", true), scale("สเกลแนวตั้ง (%)", false),
        scale("ขนาดพู่กัน X (%)", true), scale("ขนาดพู่กัน Y (%)", false),
        angle(
            "หมุนวง (°)", "หมุนวงพู่กันที่เป็นวงรี", AdvancedWarpMode.BULGE,
            base = { it.copy(scaleX = 220f) }, baseNote = "ขนาดวงแนวนอนตั้งเป็น 220% เพื่อให้เห็นการหมุน",
        ),
        angle(
            "มุมพู่กัน (°)", "หมุนวงพู่กันที่เป็นวงรี", AdvancedWarpMode.BULGE,
            base = { it.copy(scaleX = 220f) }, baseNote = "ขนาดพู่กัน X ตั้งเป็น 220% เพื่อให้เห็นการหมุน",
        ),
        angle("มุมเกลียว (°)", "ค่าบวก/ลบ = เกลียวหมุนคนละทิศ ยิ่งมากยิ่งบิดมาก", AdvancedWarpMode.SPIRAL, lo = -240f, hi = 240f),
        angle("ทิศทาง (°)", "หมุนทิศทางของผล (แนวคลื่น / แนวเฉือน)", AdvancedWarpMode.WAVE),
        angle("ทิศทางหลัก (°)", "ทิศที่ผลักเพิ่มจากทิศที่ลาก", AdvancedWarpMode.PUSH),
        angle("มุมทิศทาง (°)", "ทิศทางของระนาบ (แบน) หรือทิศที่ผลัก (แรงโน้มถ่วง)", AdvancedWarpMode.GRAVITY),

        // ── คลื่นและกระเพื่อม ──
        ParamSpec(
            label = "ความถี่", field = "frequency", group = G_WAVE, lo = 1f, hi = 12f, unit = "",
            hint = "จำนวนรอบคลื่นในระยะหนึ่ง ยิ่งมากคลื่นยิ่งถี่",
            get = { it.frequency }, set = { s, v -> s.copy(frequency = v) }, mode = AdvancedWarpMode.WAVE,
        ),
        ParamSpec(
            label = "เฟส (°)", field = "phaseDeg", group = G_WAVE, lo = -180f, hi = 180f, unit = "°",
            hint = "เลื่อนตำแหน่งสันคลื่น (ไม่เปลี่ยนความถี่)",
            get = { it.phaseDeg }, set = { s, v -> s.copy(phaseDeg = v) }, mode = AdvancedWarpMode.WAVE,
        ),
        ParamSpec(
            label = "ความยาวคลื่น (px)", field = "wavelengthPx", group = G_WAVE, lo = 30f, hi = 200f, unit = "px",
            hint = "ระยะต่อ 1 รอบคลื่น น้อย = คลื่นแน่น · มาก = คลื่นกว้าง (ภาพสาธิตกว้าง 400 px)",
            get = { it.wavelengthPx }, set = { s, v -> s.copy(wavelengthPx = v) }, mode = AdvancedWarpMode.WAVE,
        ),

        // ── แรงกดและจังหวะ ──
        ParamSpec(
            label = "แรงกดจำลอง (%)", field = "pressure", group = G_PRESS, lo = 10f, hi = 100f, unit = "%",
            hint = "จำลองแรงกดนิ้ว ยิ่งมากผลยิ่งแรง", get = { it.pressure }, set = { s, v -> s.copy(pressure = v) }, mode = AdvancedWarpMode.BULGE,
        ),
        ParamSpec(
            label = "เส้นโค้งแรงกด", field = "pressureCurve", group = G_PRESS, lo = 0.25f, hi = 3f, unit = "",
            hint = "ปรับว่าแรงกดแปลงเป็นผลอย่างไร (มีผลเมื่อแรงกดจำลองน้อยกว่า 100%) น้อย = แรงขึ้น · มาก = เบาลง",
            get = { it.pressureCurve }, set = { s, v -> s.copy(pressureCurve = v) }, mode = AdvancedWarpMode.BULGE,
            base = { it.copy(pressure = 50f) }, baseNote = "แรงกดจำลองตั้งเป็น 50% เพื่อให้เห็นผลของเส้นโค้ง",
        ),
        ParamSpec(
            label = "ปริมาณผลต่อครั้ง (%)", field = "flow", group = G_PRESS, lo = 10f, hi = 100f, unit = "%",
            hint = "สัดส่วนของผลที่ใช้จริงต่อการลาก 1 ครั้ง", get = { it.flow }, set = { s, v -> s.copy(flow = v) }, mode = AdvancedWarpMode.BULGE,
        ),
        ParamSpec(
            label = "ความหนาแน่น (%)", field = "density", group = G_PRESS, lo = 10f, hi = 100f, unit = "%",
            hint = "คูณลดแรงรวมของพู่กัน ยิ่งมากผลยิ่งเต็ม", get = { it.density }, set = { s, v -> s.copy(density = v) }, mode = AdvancedWarpMode.BULGE,
        ),
        ParamSpec(
            label = "ความทึบ/แรงรวม (%)", field = "opacity", group = G_PRESS, lo = 10f, hi = 100f, unit = "%",
            hint = "คูณแรงรวมของพู่กันทั้งหมด", get = { it.opacity }, set = { s, v -> s.copy(opacity = v) }, mode = AdvancedWarpMode.BULGE,
        ),
        ParamSpec(
            label = "ระยะห่างจุดระบายหน้ากาก (%)", field = "spacing", group = G_PRESS, lo = 0f, hi = 100f, unit = "%",
            hint = "กำหนดระยะระหว่างจุดระบายหน้ากาก; ระยะน้อยลงจะวางจุดถี่ขึ้น",
            get = { it.spacing }, set = { s, v -> s.copy(spacing = v) }, mode = AdvancedWarpMode.BULGE,
        ),
        ParamSpec(
            label = "ลดอาการมือสั่น (%)", field = "stabilizer", group = G_PRESS, lo = 0f, hi = 100f, unit = "%",
            hint = "ตามโค้ดปัจจุบัน ค่านี้ลดระยะที่ลากลง (ไม่ได้เกลี่ยเส้นทางลาก) ยิ่งมากการบิดยิ่งน้อย",
            get = { it.stabilizer }, set = { s, v -> s.copy(stabilizer = v) }, mode = AdvancedWarpMode.BULGE,
        ),

        // ── ความปลอดภัยและการคลายตาข่าย ──
        ParamSpec(
            label = "ระยะบิดเพิ่มเติม (% รัศมี)", field = "maxDeformation", group = G_SAFE, lo = 10f, hi = 150f, unit = "%",
            hint = "เพดานระยะที่แต่ละจุดขยับได้เมื่อเทียบกับรัศมีพู่กัน; ค่าสูงอนุญาตให้จุดตาข่ายเคลื่อนที่ได้ไกลขึ้น",
            get = { it.maxDeformation }, set = { s, v -> s.copy(maxDeformation = v) }, mode = AdvancedWarpMode.BULGE,
        ),
        ParamSpec(
            label = "ป้องกันขอบภาพ (%)", field = "edgeProtection", group = G_SAFE, lo = 0f, hi = 100f, unit = "%",
            hint = "ลดผลของพู่กันที่อยู่ใกล้ขอบภาพ มาก = ขอบภาพนิ่งขึ้น (วางพู่กันใกล้ขอบซ้าย)",
            get = { it.edgeProtection }, set = { s, v -> s.copy(edgeProtection = v) }, mode = AdvancedWarpMode.BULGE, cxFrac = 0.2f,
        ),
        ParamSpec(
            label = "ระยะจุดขั้นต่ำ (px)", field = "minPointDistance", group = G_SAFE, lo = 0f, hi = 18f, unit = "px",
            hint = "ห้ามจุดตาข่ายที่ติดกันเข้าใกล้กันเกินระยะนี้ (ตาข่ายสาธิตห่างกัน 20 px) ถ้าตั้งเท่าหรือเกินระยะเดิม ตามโค้ดจะไม่ขยับเลย",
            get = { it.minPointDistance }, set = { s, v -> s.copy(minPointDistance = v) }, mode = AdvancedWarpMode.PINCH, forceMode = true,
        ),
        ParamSpec(
            label = "คลายตาข่าย (%)", field = "meshSmoothing", group = G_SAFE, lo = 0f, hi = 100f, unit = "%",
            hint = "เกลี่ยจุดตาข่ายเข้าหาเพื่อนบ้านหลังบิด (ภาพเริ่มจากตาข่ายขรุขระ)",
            get = { it.meshSmoothing }, set = { s, v -> s.copy(meshSmoothing = v) }, mode = AdvancedWarpMode.PUSH, noisyStart = true,
        ),

        // ── ความละเอียดตาข่าย ──
        ParamSpec(
            label = "จำนวนช่องแนวนอน", field = "meshCols", group = G_MESH, lo = 4f, hi = 40f, unit = "ช่อง",
            hint = "น้อย = ตาข่ายหยาบ ขอบการบิดเป็นเหลี่ยม · มาก = เนียนแต่ใช้เครื่องมากขึ้น",
            get = { if (it.meshCols > 0) it.meshCols.toFloat() else ParamDemo.DEFAULT_CELLS.toFloat() },
            set = { s, v -> s.copy(meshCols = v.roundToInt()) }, mode = AdvancedWarpMode.BULGE, integer = true,
        ),
        ParamSpec(
            label = "จำนวนช่องแนวตั้ง", field = "meshRows", group = G_MESH, lo = 4f, hi = 40f, unit = "ช่อง",
            hint = "น้อย = ตาข่ายหยาบ ขอบการบิดเป็นเหลี่ยม · มาก = เนียนแต่ใช้เครื่องมากขึ้น",
            get = { if (it.meshRows > 0) it.meshRows.toFloat() else ParamDemo.DEFAULT_CELLS.toFloat() },
            set = { s, v -> s.copy(meshRows = v.roundToInt()) }, mode = AdvancedWarpMode.BULGE, integer = true,
        ),

        // ── พลวัตพู่กัน (ก่อนหน้านี้มีช่องปรับ แต่ยังไม่มีตัวอย่าง) ──
        ParamSpec(
            label = "แรงเริ่มต้น (%)", field = "startForce", group = G_PRESS, lo = 0f, hi = 200f, unit = "%",
            hint = "แรงที่ใช้เมื่อเริ่มลาก เทียบกับแรงหลัก; ค่าต่ำเริ่มเบา ค่าสูงเริ่มแรง",
            get = { it.startForce }, set = { s, v -> s.copy(startForce = v) }, mode = AdvancedWarpMode.BULGE,
        ),
        ParamSpec(
            label = "แรงตอนปล่อย (%)", field = "endForce", group = G_PRESS, lo = 0f, hi = 200f, unit = "%",
            hint = "แรงที่ใช้เมื่อสิ้นสุดการลาก; เปรียบเทียบกับแรงเริ่มต้นเพื่อเห็นการไล่แรง",
            get = { it.endForce }, set = { s, v -> s.copy(endForce = v) }, mode = AdvancedWarpMode.BULGE,
        ),
        ParamSpec(
            label = "ตอบสนองระยะลาก (%)", field = "distanceResponse", group = G_PRESS, lo = -100f, hi = 300f, unit = "%",
            hint = "เปลี่ยนแรงตามระยะลาก; ค่าบวกเพิ่มแรงเมื่อขยับไกล ค่าลบลดแรง",
            get = { it.distanceResponse }, set = { s, v -> s.copy(distanceResponse = v) }, mode = AdvancedWarpMode.BULGE,
        ),
        ParamSpec(
            label = "สุ่มแรง (%)", field = "forceJitter", group = G_PRESS, lo = 0f, hi = 100f, unit = "%",
            hint = "กระจายแรงระหว่างจุดตาข่ายด้วย noise คงที่; ค่าสูงเห็นแรงไม่สม่ำเสมอชัดขึ้น",
            get = { it.forceJitter }, set = { s, v -> s.copy(forceJitter = v) }, mode = AdvancedWarpMode.BULGE,
        ),
        ParamSpec(
            label = "สุ่มขนาด (%)", field = "sizeJitter", group = G_PRESS, lo = 0f, hi = 100f, unit = "%",
            hint = "สุ่มขนาดอิทธิพลของพู่กันแยกตามจุดตาข่าย; ค่าสูงทำให้ขอบไม่สม่ำเสมอมากขึ้น",
            get = { it.sizeJitter }, set = { s, v -> s.copy(sizeJitter = v) }, mode = AdvancedWarpMode.BULGE,
        ),
        ParamSpec(
            label = "สุ่มมุม (°)", field = "angleJitter", group = G_PRESS, lo = 0f, hi = 90f, unit = "°",
            hint = "สุ่มทิศทางของพู่กันในแต่ละจุดตาข่าย; ค่าสูงทำให้แนวผลบิดกระจายมากขึ้น",
            get = { it.angleJitter }, set = { s, v -> s.copy(angleJitter = v) }, mode = AdvancedWarpMode.BULGE,
        ),

        // ── แอนิเมชัน ──
        ParamSpec(
            label = "ระยะเวลาต่อรอบ (วินาที)", field = "loopDuration", group = G_ANIM, lo = 0.1f, hi = 30f, unit = " วินาที",
            hint = "ระยะเวลาของหนึ่งรอบการเปลี่ยนท่าบิด; กราฟตัวอย่างแสดงช่วงเริ่มจนจบหนึ่งรอบ",
            get = { it.loopDuration }, set = { s, v -> s.copy(loopDuration = v) }, timelinePreview = true,
        ),
        ParamSpec(
            label = "หน่วงก่อนเริ่ม (วินาที)", field = "deformationDelay", group = G_ANIM, lo = 0f, hi = 10f, unit = " วินาที",
            hint = "เลื่อนจุดเริ่มการเปลี่ยนท่าไปด้านขวาบนเส้นเวลา; ค่าสูงเริ่มช้าลง",
            get = { it.deformationDelay }, set = { s, v -> s.copy(deformationDelay = v) }, timelinePreview = true,
        ),
        ParamSpec(
            label = "ความเร็ว (×)", field = "warpSpeed", group = G_ANIM, lo = 0.1f, hi = 5f, unit = "×",
            hint = "คูณความเร็วของรอบบิด; ค่าสูงจบรอบเร็วขึ้น ค่าต่ำจบรอบช้าลง",
            get = { it.warpSpeed }, set = { s, v -> s.copy(warpSpeed = v) }, timelinePreview = true,
        ),
        ParamSpec(
            label = "ความแรงการเปลี่ยนท่าบิด (%)", field = "motionStrength", group = G_ANIM, lo = 0f, hi = 100f, unit = "%",
            hint = "กำหนดสัดส่วนการติดตามการเคลื่อนไหวของคีย์เฟรม; ค่าสูงตามท่ามากขึ้น",
            get = { it.motionStrength }, set = { s, v -> s.copy(motionStrength = v) }, timelinePreview = true,
        ),
    ) + listOf(
        physicsSpec("แรงโน้มถ่วง X", "gravityX", -2000f, 2000f, "px/s²", "แรงโน้มถ่วงแนวนอน; ค่าบวกเคลื่อนไปทางขวา ค่าลบไปทางซ้าย", { it.gravityX }) { s, v -> s.copy(gravityX = v) },
        physicsSpec("แรงโน้มถ่วง Y", "gravityY", -2000f, 2000f, "px/s²", "แรงโน้มถ่วงแนวตั้ง; ค่าบวกลงด้านล่าง ค่าลบขึ้นด้านบน", { it.gravityY }) { s, v -> s.copy(gravityY = v) },
        physicsSpec("มวล", "mass", 0.1f, 20f, "", "มวลสูงทำให้ตอบสนองต่อแรงน้อยลง; มวลต่ำตอบสนองไวขึ้น", { it.mass }) { s, v -> s.copy(mass = v) },
        physicsSpec("ความแข็งสปริง", "stiffness", 0f, 1000f, "", "ค่าความแข็งสูงทำให้การสั่นตอบสนองเร็วขึ้น", { it.stiffness }) { s, v -> s.copy(stiffness = v) },
        physicsSpec("แรงหน่วง", "damping", 0f, 100f, "", "แรงหน่วงสูงลดการแกว่งและทำให้หยุดเร็วขึ้น", { it.damping }) { s, v -> s.copy(damping = v) },
        physicsSpec("ความยืดหยุ่น", "elasticity", 0f, 2f, "", "สัดส่วนแรงภายนอกที่ส่งผลกับการเคลื่อนที่", { it.elasticity }) { s, v -> s.copy(elasticity = v) },
        physicsSpec("แรงสปริง", "springStrength", 0f, 500f, "", "แรงดึงกลับเข้าหารูปตั้งต้น; ค่าสูงคืนรูปแรงขึ้น", { it.springStrength }) { s, v -> s.copy(springStrength = v) },
        physicsSpec("แรงเด้ง", "bounce", 0f, 2f, "", "เพิ่มการเด้งกลับหลังการเคลื่อนที่", { it.bounce }) { s, v -> s.copy(bounce = v) },
        physicsSpec("แรงต้าน", "drag", 0f, 2f, "", "ต้านการเคลื่อนที่โดยรวม; ค่าสูงทำให้เคลื่อนที่ช้าลง", { it.drag }) { s, v -> s.copy(drag = v) },
        physicsSpec("แรงลม X", "windX", -2000f, 2000f, "px/s²", "แรงลมแนวนอน; ค่าบวกพัดไปทางขวา", { it.windX }) { s, v -> s.copy(windX = v) },
        physicsSpec("แรงลม Y", "windY", -2000f, 2000f, "px/s²", "แรงลมแนวตั้ง; ค่าบวกพัดลงด้านล่าง", { it.windY }) { s, v -> s.copy(windY = v) },
        physicsSpec("ความเร็วคืนรูป", "recoverySpeed", 0f, 30f, "", "ความเร็วในการคืนรูป; ค่าสูงกลับเข้าหาตำแหน่งเดิมเร็วขึ้น", { it.recoverySpeed }) { s, v -> s.copy(recoverySpeed = v) },
        physicsSpec("ขีดการยืดเชิงกายภาพ", "maxStretch", 0.1f, 5f, "×", "จำกัดระยะที่จุดตาข่ายยืดออกได้; ค่าสูงยอมให้ยืดได้ไกลขึ้น", { it.maxStretch }) { s, v -> s.copy(maxStretch = v) },
    )

    private fun physicsSpec(
        label: String, field: String, lo: Float, hi: Float, unit: String, hint: String,
        getValue: (WarpPhysicsSettings) -> Float,
        setValue: (WarpPhysicsSettings, Float) -> WarpPhysicsSettings,
    ) = ParamSpec(
        label = label, field = "physics.$field", group = G_PHYSICS, lo = lo, hi = hi, unit = unit, hint = hint,
        get = { 0f }, set = { s, _ -> s }, mode = AdvancedWarpMode.ELASTIC,
        physicsGet = getValue, physicsSet = setValue,
    )

    data class OptionVariant(val label: String, val description: String, val settings: WarpSettings)
    data class OptionSpec(val label: String, val field: String, val group: String, val hint: String, val mode: AdvancedWarpMode, val variants: List<OptionVariant>, val timeline: Boolean = false, val grabPreview: Boolean = false)

    /** ตัวอย่างค่าประเภทสวิตช์/ตัวเลือก: ใช้ค่าจริงกับเอนจินเดียวกัน ไม่ใช่แค่ข้อความ */
    val optionSpecs: List<OptionSpec> = listOf(
        OptionSpec("รูปทรงหัวพู่กัน", "brushShape", "รูปแบบและสวิตช์", "กำหนดพื้นที่ที่พู่กันครอบคลุม แต่ละรูปทรงส่งผลกับจุดตาข่ายต่างกัน", AdvancedWarpMode.BULGE,
            listOf("วงกลม", "วงรี", "สี่เหลี่ยม", "เพชร", "เส้นแนวนอน", "เส้นแนวตั้ง").map { shape -> OptionVariant(shape, "ตัวอย่างพื้นที่อิทธิพลของหัวพู่กันแบบ$shape", WarpSettings(brushShape = shape, strength = 100f, scaleX = 180f, scaleY = 90f)) }),
        OptionSpec("รูปคลื่น", "waveType", "รูปแบบและสวิตช์", "เปลี่ยนรูปทรงของคลื่นที่สร้างจากเครื่องมือคลื่น", AdvancedWarpMode.WAVE,
            listOf("Sine" to "คลื่นโค้งต่อเนื่อง", "Triangle" to "คลื่นยอดแหลมเป็นช่วง", "Square" to "คลื่นสลับระดับ") .map { (v,d) -> OptionVariant(v, d, WarpSettings(waveType = v, strength = 100f, frequency = 4f, wavelengthPx = 80f)) }),
        OptionSpec("รูปแบบการเปลี่ยนผ่าน", "interpolation", "รูปแบบและสวิตช์", "เปรียบเทียบกราฟการเปลี่ยนค่าระหว่างคีย์เฟรม", AdvancedWarpMode.BULGE,
            listOf("Linear" to "เปลี่ยนด้วยอัตราคงที่", "Smooth" to "เริ่มและจบอย่างนุ่มนวล", "Ease In" to "เริ่มช้าแล้วเร็วขึ้น", "Ease Out" to "เริ่มเร็วแล้วช้าลง", "Bezier" to "เส้นโค้งแบบ Bezier") .map { (v,d) -> OptionVariant(v, d, WarpSettings(interpolation = v, loopDuration = 1f, warpSpeed = 1f, motionStrength = 100f)) }, timeline = true),
        booleanOption("สะสมแรงตามระยะลาก", "accumulate", "เพิ่มแรงตามระยะลาก", { it.copy(accumulate = false) }, { it.copy(accumulate = true) }, grabPreview = true),
        booleanOption("ล็อกกลาง", "centerLock", "กันการบิดบริเวณกลางวงพู่กัน", { it.copy(centerLock = false) }, { it.copy(centerLock = true) }, grabPreview = true),
        booleanOption("สมมาตร", "symmetry", "สะท้อนผลบิดไปอีกด้านของแกนกลาง", { it.copy(symmetry = false) }, { it.copy(symmetry = true) }, grabPreview = true),
        booleanOption("กลับทิศ", "invert", "สลับทิศทางของผลบิด", { it.copy(invert = false) }, { it.copy(invert = true) }, grabPreview = true),
        booleanOption("ล็อกแกน X / Horizontal", "lockHorizontal", "หยุดการเคลื่อนที่ตามแกน X", { it.copy(lockHorizontal = false) }, { it.copy(lockHorizontal = true) }, grabPreview = true),
        booleanOption("ล็อกแกน Y / Vertical", "lockVertical", "หยุดการเคลื่อนที่ตามแกน Y", { it.copy(lockVertical = false) }, { it.copy(lockVertical = true) }, grabPreview = true),
        booleanOption("รักษาขอบภาพ", "preserveBoundary", "ลดแรงบิดบริเวณขอบภาพ", { it.copy(preserveBoundary = false) }, { it.copy(preserveBoundary = true) }, grabPreview = true),
        booleanOption("กักขอบเขต", "boundaryClamp", "จำกัดจุดตาข่ายไม่ให้ออกนอกภาพ", { it.copy(boundaryClamp = false) }, { it.copy(boundaryClamp = true) }, grabPreview = true),
        booleanOption("ป้องกันตาข่ายพับ", "preventFolding", "ลดแรงบิดอัตโนมัติเมื่อเสี่ยงทำให้ตาข่ายพับ", { it.copy(preventFolding = false, preventSelfIntersection = false) }, { it.copy(preventFolding = true, preventSelfIntersection = false) }),
        booleanOption("ป้องกันช่องตาข่ายกลับด้าน / ตัดกัน", "preventSelfIntersection", "ลดแรงบิดเมื่อช่องตาข่ายเสี่ยงกลับด้านหรือตัดกัน", { it.copy(preventFolding = false, preventSelfIntersection = false) }, { it.copy(preventFolding = false, preventSelfIntersection = true) }),
        booleanOption("แสดงตัวอย่างคุณภาพสูง", "highQualityPreview", "ควบคุมคุณภาพการกรองภาพขณะดูตัวอย่าง ไม่เปลี่ยนรูปทรงตาข่าย", { it.copy(highQualityPreview = false) }, { it.copy(highQualityPreview = true) }),
        booleanOption("ลดรอยหยักของขอบภาพ", "antiAliasing", "ควบคุมการลบรอยหยักขณะวาด ไม่เปลี่ยนรูปทรงตาข่าย", { it.copy(antiAliasing = false) }, { it.copy(antiAliasing = true) }),
        booleanOption("สร้างคีย์เฟรมอัตโนมัติ", "autoKeyframe", "บันทึกค่าที่แก้ไขเป็นคีย์เฟรม ณ ตำแหน่งเส้นเวลา", { it.copy(autoKeyframe = false) }, { it.copy(autoKeyframe = true) }, timeline = true),
        booleanOption("ให้ท่าบิดเปลี่ยนตามคีย์เฟรม", "followMotion", "ให้ท่าบิดติดตามการเคลื่อนไหวของคีย์เฟรม", { it.copy(followMotion = false) }, { it.copy(followMotion = true) }, timeline = true),
    )

    private fun booleanOption(
        label: String, field: String, hint: String,
        off: (WarpSettings) -> WarpSettings, on: (WarpSettings) -> WarpSettings,
        timeline: Boolean = false,
        grabPreview: Boolean = false,
    ) = OptionSpec(label, field, "รูปแบบและสวิตช์", hint, AdvancedWarpMode.BULGE,
        listOf(OptionVariant("ปิด", "ตัวอย่างเมื่อปิดตัวเลือก", off(WarpSettings(strength = 100f))), OptionVariant("เปิด", "ตัวอย่างเมื่อเปิดตัวเลือก", on(WarpSettings(strength = 100f)))), timeline, grabPreview)

    enum class VisualKind { ANGLE, RADIUS, GRID, RINGS, POSITION_X, POSITION_Y, DENSITY }
    data class VisualSpec(
        val label: String, val group: String, val lo: Float, val hi: Float, val unit: String,
        val hint: String, val kind: VisualKind, val integer: Boolean = false,
    )

    /** ช่องตัวเลขของเครื่องมือเฉพาะทางที่ไม่ได้เก็บใน WarpSettings ก็มีแผนภาพเทียบค่าให้ดู */
    val visualSpecs: List<VisualSpec> = listOf(
        VisualSpec("มุมบิดหมุน (°)", "เครื่องมือเฉพาะทาง", -360f, 360f, "°", "มุมที่ใช้หมุนตาข่ายรอบจุดกึ่งกลาง; แผนภาพแสดงทิศการหมุน", VisualKind.ANGLE),
        VisualSpec("รัศมี (%)", "เครื่องมือเฉพาะทาง", 5f, 100f, "%", "ขนาดรัศมีพู่กันเทียบกับด้านยาวของภาพ", VisualKind.RADIUS),
        VisualSpec("ขนาดช่อง (px)", "เครื่องมือเฉพาะทาง", 8f, 160f, " px", "ระยะห่างระหว่างเส้นตาข่าย; ค่าน้อยทำให้ตาข่ายละเอียดขึ้น", VisualKind.GRID, true),
        VisualSpec("ระยะอิทธิพลรอบจุด (ช่อง)", "เครื่องมือเฉพาะทาง", 0f, 6f, " ช่อง", "จำนวนวงแหวนของจุดข้างเคียงที่เคลื่อนตามจุดที่ลาก", VisualKind.RINGS, true),
        VisualSpec("ทิศ (°) 0=ขวา 90=ลง", "หมุดข้อต่อ", 0f, 360f, "°", "ทิศของส่วนภาพที่อยู่ด้านหน้าหมุด; 0° ขวา, 90° ลง, 180° ซ้าย, 270° ขึ้น", VisualKind.ANGLE),
        VisualSpec("รัศมี (px)", "หมุดข้อต่อ", 20f, 400f, " px", "ระยะส่งผลจากหมุด; ขอบวงเป็นจุดที่น้ำหนักการหมุนลดลงเป็นศูนย์", VisualKind.RADIUS),
        VisualSpec("ตำแหน่ง X (px)", "หมุดข้อต่อ", 0f, 400f, " px", "ตำแหน่งหมุดตามแกนนอนของภาพ; ซ้ายเป็น 0 และขวาเป็นความกว้างภาพ", VisualKind.POSITION_X),
        VisualSpec("ตำแหน่ง Y (px)", "หมุดข้อต่อ", 0f, 400f, " px", "ตำแหน่งหมุดตามแกนตั้งของภาพ; บนเป็น 0 และล่างเป็นความสูงภาพ", VisualKind.POSITION_Y),
        VisualSpec("จำกัดมุมต่ำสุด (°)", "หมุดข้อต่อ", -180f, 0f, "°", "ขอบเขตมุมงอด้านต่ำสุด; แผนภาพแสดงตำแหน่งปลายช่วง", VisualKind.ANGLE),
        VisualSpec("จำกัดมุมสูงสุด (°)", "หมุดข้อต่อ", 0f, 180f, "°", "ขอบเขตมุมงอด้านสูงสุด; แผนภาพแสดงตำแหน่งปลายช่วง", VisualKind.ANGLE),
        VisualSpec("ความหนาแน่นตาข่ายรอบหมุด", "หมุดข้อต่อ", 0f, 6f, "", "จำนวนระดับการเพิ่มความละเอียดรอบหมุด; ค่าสูงเพิ่มเส้นตาข่ายใกล้ข้อต่อ", VisualKind.DENSITY),
        VisualSpec("รัศมีตาข่ายถี่ (px)", "หมุดข้อต่อ", 10f, 400f, " px", "ขนาดพื้นที่รอบหมุดที่เพิ่มความละเอียดตาข่าย", VisualKind.RADIUS),
        VisualSpec("มุมงอ (°)", "หมุดข้อต่อ", -180f, 180f, "°", "มุมหมุนของส่วนภาพด้านหน้าหมุดเมื่อเทียบกับแนวตั้งต้น", VisualKind.ANGLE),
    )
    private val visualByLabel: Map<String, VisualSpec> by lazy { visualSpecs.associateBy { it.label } }

    private val byLabel: Map<String, ParamSpec> by lazy { specs.associateBy { it.label } }
    private val optionByLabel: Map<String, OptionSpec> by lazy { optionSpecs.associateBy { it.label } }

    fun find(label: String): ParamSpec? = byLabel[label]
    fun findOption(label: String): OptionSpec? = optionByLabel[label]
    fun findVisual(label: String): VisualSpec? = visualByLabel[label]

    /** property ของ WarpSettings ที่ยังไม่มีตัวอย่างแบบตัวเลขหรือตัวเลือก */
    fun missingFields(): List<String> {
        val covered = (specs.map { it.field } + optionSpecs.map { it.field }).toSet()
        return WarpSettings::class.java.declaredFields
            .filter { !it.isSynthetic && !java.lang.reflect.Modifier.isStatic(it.modifiers) }
            .map { it.name }
            .filter { it !in covered }
    }
}

/** เอนจินสร้างภาพตัวอย่าง: ใช้ Sculpt.applyAdvancedWarp ตัวจริงของแอป */
object ParamDemo {
    const val SIZE = 400
    const val DEFAULT_CELLS = 20
    const val LOOP_SEC = 1.8f

    val bitmap: Bitmap by lazy { buildBitmap() }

    private fun buildBitmap(): Bitmap {
        val bmp = Bitmap.createBitmap(SIZE, SIZE, Bitmap.Config.ARGB_8888)
        val c = android.graphics.Canvas(bmp)
        c.drawColor(android.graphics.Color.BLACK)
        val gridPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.STROKE; strokeWidth = 1.5f; color = android.graphics.Color.argb(90, 255, 255, 255)
        }
        for (i in 0..16) {
            val p = i * 25f
            c.drawLine(p, 0f, p, SIZE.toFloat(), gridPaint)
            c.drawLine(0f, p, SIZE.toFloat(), p, gridPaint)
        }
        val line = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.STROKE; strokeWidth = 6f; color = android.graphics.Color.WHITE; strokeCap = Paint.Cap.ROUND
        }
        val fill = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL; color = android.graphics.Color.WHITE }
        c.drawCircle(200f, 200f, 130f, line)
        line.strokeWidth = 2.5f
        c.drawCircle(200f, 200f, 185f, line)
        line.strokeWidth = 6f
        c.drawCircle(160f, 175f, 14f, fill)
        c.drawCircle(240f, 175f, 14f, fill)
        c.drawLine(200f, 190f, 194f, 225f, line)
        c.drawArc(RectF(140f, 200f, 260f, 290f), 20f, 140f, false, line)
        line.strokeWidth = 4f
        c.drawRect(3f, 3f, SIZE - 3f, SIZE - 3f, line)
        return bmp
    }

    /** ความคืบหน้าการลาก 0..1 ตามเฟสของลูป (ลากออก → ค้าง → คืนกลับ) */
    fun progress(phase: Float): Float {
        fun ss(x: Float): Float { val t = x.coerceIn(0f, 1f); return t * t * (3f - 2f * t) }
        return when {
            phase < 0.40f -> ss(phase / 0.40f)
            phase < 0.55f -> 1f
            phase < 0.95f -> 1f - ss((phase - 0.55f) / 0.40f)
            else -> 0f
        }
    }

    private fun noisyGrid(cols: Int, rows: Int): SculptGrid {
        val g = SculptGrid.zero(cols, rows)
        val off = g.off.copyOf()
        val rnd = java.util.Random(7L)
        val cell = SIZE.toFloat() / maxOf(cols, rows)
        var n = 0
        for (j in 0..rows) for (i in 0..cols) {
            val rx = rnd.nextFloat() - 0.5f
            val ry = rnd.nextFloat() - 0.5f
            if (i in 1 until cols && j in 1 until rows) {
                off[2 * n] = rx * cell * 0.7f
                off[2 * n + 1] = ry * cell * 0.7f
            }
            n++
        }
        return g.withOff(off)
    }

    /** ตาข่ายของตัวอย่างที่ความคืบหน้า p (คำนวณเหมือนแอปจริง: ลดระยะลากด้วย stabilizer แล้วส่งเข้า applyAdvancedWarp) */
    fun gridFor(s: WarpSettings, mode: AdvancedWarpMode, cxFrac: Float, noisy: Boolean, p: Float, grabPreview: Boolean = false): SculptGrid {
        val cols = if (s.meshCols > 0) s.meshCols.coerceIn(4, 40) else DEFAULT_CELLS
        val rows = if (s.meshRows > 0) s.meshRows.coerceIn(4, 40) else DEFAULT_CELLS
        val start = if (noisy) noisyGrid(cols, rows) else SculptGrid.zero(cols, rows)
        val r = SIZE * 0.4f
        val cx = SIZE * cxFrac
        val cy = SIZE * 0.5f
        val keep = 1f - s.stabilizer.coerceIn(0f, 100f) / 100f * 0.85f
        val dx = r * 0.6f * keep
        val dy = r * 0.18f * keep
        fun apply(amountX: Float, amountY: Float): SculptGrid {
            return if (grabPreview) {
                val weights = Sculpt.brushWeights(SIZE, SIZE, start, cx, cy, r, cx, cy, 0f, s)
                Sculpt.applyGrab(start, weights, amountX, amountY, r, settings = s, width = SIZE, height = SIZE, radius = r)
            } else {
                Sculpt.applyAdvancedWarp(SIZE, SIZE, start, cx, cy, r, mode, amountX, amountY, s)
            }
        }
        return if (noisy) {
            val full = apply(dx, dy)
            Sculpt.lerp(start, full, p) ?: full
        } else apply(dx * p, dy * p)
    }

    /** กราฟตัวอย่างเส้นเวลา: ใช้ค่าระยะเวลา หน่วง ความเร็ว แรง และ interpolation ของ WarpSettings */
    fun drawTimeline(canvas: android.graphics.Canvas, settings: WarpSettings) {
        val gridPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = android.graphics.Color.argb(70, 255, 255, 255); strokeWidth = 1.5f; style = Paint.Style.STROKE
        }
        val axisPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = android.graphics.Color.argb(190, 255, 255, 255); strokeWidth = 2.5f; style = Paint.Style.STROKE
        }
        val curvePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = android.graphics.Color.WHITE; strokeWidth = 6f; style = Paint.Style.STROKE; strokeCap = Paint.Cap.ROUND; strokeJoin = Paint.Join.ROUND
        }
        for (i in 1..4) {
            val x = SIZE * i / 5f
            val y = SIZE * i / 5f
            canvas.drawLine(x, 28f, x, SIZE - 28f, gridPaint)
            canvas.drawLine(28f, y, SIZE - 28f, y, gridPaint)
        }
        val left = 34f; val right = SIZE - 28f; val top = 32f; val bottom = SIZE - 34f
        canvas.drawLine(left, bottom, right, bottom, axisPaint)
        canvas.drawLine(left, top, left, bottom, axisPaint)
        val duration = (settings.loopDuration.coerceIn(0.1f, 30f) / settings.warpSpeed.coerceIn(0.1f, 5f)).coerceAtLeast(0.05f)
        val delay = settings.deformationDelay.coerceIn(0f, 30f)
        val span = (delay + duration).coerceAtLeast(0.1f)
        val strength = settings.motionStrength.coerceIn(0f, 100f) / 100f
        val path = android.graphics.Path()
        for (i in 0..100) {
            val t = i / 100f * span
            val u = ((t - delay) / duration).coerceIn(0f, 1f)
            val eased = when (settings.interpolation) {
                "Smooth" -> u * u * (3f - 2f * u)
                "Ease In" -> u * u
                "Ease Out" -> 1f - (1f - u) * (1f - u)
                "Bezier" -> u * u * (3f - 2f * u)
                else -> u
            }
            val x = left + (right - left) * t / span
            val y = bottom - (bottom - top) * eased * strength
            if (i == 0) path.moveTo(x, y) else path.lineTo(x, y)
        }
        canvas.drawPath(path, curvePaint)
        val marker = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = android.graphics.Color.WHITE; style = Paint.Style.FILL }
        canvas.drawCircle(left, bottom, 7f, marker)
        canvas.drawCircle(right, top + (bottom - top) * (1f - strength), 7f, marker)
    }

    fun modeThai(m: AdvancedWarpMode): String = when (m) {
        AdvancedWarpMode.PINCH -> "บีบเข้า"
        AdvancedWarpMode.BULGE -> "ดันนูน"
        AdvancedWarpMode.SPIRAL -> "เกลียว"
        AdvancedWarpMode.WAVE -> "คลื่น"
        AdvancedWarpMode.SHEAR -> "เฉือน"
        AdvancedWarpMode.PERSPECTIVE -> "มุมมอง"
        AdvancedWarpMode.RIPPLE -> "กระเพื่อม"
        AdvancedWarpMode.PUSH -> "ผลัก"
        AdvancedWarpMode.INFLATE -> "พอง"
        AdvancedWarpMode.DEFLATE -> "ยุบ"
        AdvancedWarpMode.SMOOTH -> "เกลี่ย"
        AdvancedWarpMode.FLATTEN -> "แบน"
        AdvancedWarpMode.CREASE -> "รอยพับ"
        AdvancedWarpMode.GRAVITY -> "แรงโน้มถ่วง"
        AdvancedWarpMode.ELASTIC -> "ยืดหยุ่น"
        AdvancedWarpMode.MAGNET -> "แม่เหล็ก"
        else -> m.name
    }
}

private fun fmtParam(v: Float, integer: Boolean): String =
    if (integer) v.roundToInt().toString()
    else String.format(java.util.Locale.US, "%.2f", v).trimEnd('0').trimEnd('.')

/** นาฬิกาของตัวอย่าง: อัปเดตประมาณ 30 ครั้ง/วินาที (เฉพาะตอนแผงเปิดอยู่) */
@Composable
private fun rememberDemoPhase(): FloatState {
    val phase = remember { mutableFloatStateOf(0f) }
    LaunchedEffect(Unit) {
        val begin = androidx.compose.runtime.withFrameNanos { it }
        var last = 0L
        while (true) {
            androidx.compose.runtime.withFrameNanos { now ->
                if (now - last > 33_000_000L) {
                    last = now
                    val sec = (now - begin) / 1_000_000_000.0
                    phase.floatValue = ((sec % ParamDemo.LOOP_SEC) / ParamDemo.LOOP_SEC).toFloat()
                }
            }
        }
    }
    return phase
}

@Composable
private fun DemoPanel(
    s: WarpSettings, mode: AdvancedWarpMode, spec: ParamSpec, phase: FloatState, modifier: Modifier,
    physicsSettings: WarpPhysicsSettings? = null,
) {
    val q = (ParamDemo.progress(phase.floatValue) * 40f).roundToInt()
    // โหมดเกลี่ยบนตาข่ายเรียบไม่เห็นผล จึงเริ่มจากตาข่ายขรุขระเสมอ
    val noisy = spec.noisyStart || mode == AdvancedWarpMode.SMOOTH
    val baseGrid = remember(s, mode, spec, noisy, q) { ParamDemo.gridFor(s, mode, spec.cxFrac, noisy, q / 40f, spec.grabPreview) }
    val grid = remember(baseGrid, physicsSettings) {
        if (physicsSettings != null) WarpStackMath.physicsAt(baseGrid, physicsSettings.copy(enabled = true), 0.35f) else baseGrid
    }
    val paint = remember { Paint(Paint.ANTI_ALIAS_FLAG).apply { isFilterBitmap = true } }
    val ring = remember {
        Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; color = android.graphics.Color.argb(150, 255, 255, 255) }
    }
    Canvas(modifier.clipToBounds().background(PvBg).border(1.dp, PvLine)) {
        val sc = size.width / ParamDemo.SIZE
        drawIntoCanvas { cv ->
            val n = cv.nativeCanvas
            n.save()
            n.scale(sc, sc)
            if (spec.timelinePreview) {
                ParamDemo.drawTimeline(n, s)
            } else {
                Sculpt.drawMesh(n, ParamDemo.bitmap, grid, paint)
                // วงขาวบางๆ = ขอบเขตพู่กัน (หมุน/ยืดตามค่าขนาดและมุม)
                ring.strokeWidth = 1.5f / sc
                n.save()
                n.translate(ParamDemo.SIZE * spec.cxFrac, ParamDemo.SIZE * 0.5f)
                n.rotate(s.angleDeg)
                n.scale((s.scaleX / 100f).coerceIn(0.1f, 4f), (s.scaleY / 100f).coerceIn(0.1f, 4f))
                n.drawCircle(0f, 0f, ParamDemo.SIZE * 0.4f, ring)
                n.restore()
            }
            n.restore()
        }
    }
}

@Composable
private fun PvButton(text: String, primary: Boolean, modifier: Modifier = Modifier, onClick: () -> Unit) {
    Box(
        modifier.clip(RoundedCornerShape(50))
            .background(if (primary) PvInk else PvChip)
            .border(1.dp, PvLine, RoundedCornerShape(50))
            .clickable(onClick = onClick).padding(horizontal = 16.dp, vertical = 10.dp),
        contentAlignment = Alignment.Center,
    ) { Text(text, color = if (primary) PvBg else PvInk, fontSize = 14.sp, fontWeight = FontWeight.SemiBold) }
}

@Composable
private fun VisualDemoPanel(spec: ParamPreviewRegistry.VisualSpec, value: Float, modifier: Modifier) {
    Canvas(modifier.clipToBounds().background(PvBg).border(1.dp, PvLine)) {
        val sc = size.width / ParamDemo.SIZE
        drawIntoCanvas { cv ->
            val n = cv.nativeCanvas
            n.save(); n.scale(sc, sc)
            val grid = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = android.graphics.Color.argb(70, 255, 255, 255); strokeWidth = 1.5f; style = Paint.Style.STROKE }
            val line = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = android.graphics.Color.WHITE; strokeWidth = 4f; style = Paint.Style.STROKE; strokeCap = Paint.Cap.ROUND }
            val fill = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = android.graphics.Color.WHITE; style = Paint.Style.FILL }
            for (i in 0..16) { val p = i * 25f; n.drawLine(p, 0f, p, 400f, grid); n.drawLine(0f, p, 400f, p, grid) }
            val t = ((value - spec.lo) / (spec.hi - spec.lo).coerceAtLeast(0.0001f)).coerceIn(0f, 1f)
            when (spec.kind) {
                ParamPreviewRegistry.VisualKind.ANGLE -> {
                    val cx = 200f; val cy = 200f; val rad = 125f
                    n.drawCircle(cx, cy, 95f, grid)
                    val deg = Math.toRadians(value.toDouble())
                    val ex = cx + kotlin.math.cos(deg).toFloat() * rad
                    val ey = cy + kotlin.math.sin(deg).toFloat() * rad
                    n.drawCircle(cx, cy, 10f, fill); n.drawLine(cx, cy, ex, ey, line); n.drawCircle(ex, ey, 9f, fill)
                }
                ParamPreviewRegistry.VisualKind.RADIUS -> {
                    val r = 22f + t * 155f
                    n.drawCircle(200f, 200f, 8f, fill); n.drawCircle(200f, 200f, r, line)
                }
                ParamPreviewRegistry.VisualKind.GRID -> {
                    val spacing = (10f + t * 70f).coerceAtLeast(8f)
                    var x = 0f; while (x <= 400f) { n.drawLine(x, 0f, x, 400f, line); x += spacing }
                    var y = 0f; while (y <= 400f) { n.drawLine(0f, y, 400f, y, line); y += spacing }
                }
                ParamPreviewRegistry.VisualKind.RINGS -> {
                    n.drawCircle(200f, 200f, 7f, fill)
                    val count = value.roundToInt().coerceIn(0, 6)
                    for (i in 1..count) n.drawCircle(200f, 200f, i * 28f, line)
                }
                ParamPreviewRegistry.VisualKind.POSITION_X -> {
                    val x = 30f + t * 340f
                    n.drawLine(30f, 200f, 370f, 200f, grid); n.drawLine(x, 30f, x, 370f, line); n.drawCircle(x, 200f, 11f, fill)
                }
                ParamPreviewRegistry.VisualKind.POSITION_Y -> {
                    val y = 30f + t * 340f
                    n.drawLine(200f, 30f, 200f, 370f, grid); n.drawLine(30f, y, 370f, y, line); n.drawCircle(200f, y, 11f, fill)
                }
                ParamPreviewRegistry.VisualKind.DENSITY -> {
                    val count = (2 + (t * 12f).roundToInt()).coerceIn(2, 14)
                    for (i in 0..count) {
                        val y = 45f + i * (310f / count)
                        n.drawLine(20f, y, 380f, y, if (i % 2 == 0) line else grid)
                    }
                    n.drawCircle(200f, 200f, 22f, fill)
                }
            }
            n.restore()
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ParamVisualPreviewSheet(spec: ParamPreviewRegistry.VisualSpec, initial: Float, onApply: ((Float) -> Unit)?, onDismiss: () -> Unit) {
    val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)
    var value by remember(spec) { mutableFloatStateOf(initial) }
    ModalBottomSheet(onDismissRequest = onDismiss, sheetState = sheetState, containerColor = PvBg, contentColor = PvInk) {
        Column(Modifier.fillMaxWidth().verticalScroll(rememberScrollState()).padding(horizontal = 16.dp).padding(bottom = 28.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Text(spec.label, color = PvInk, fontSize = 17.sp, fontWeight = FontWeight.Bold)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf(spec.lo, value, spec.hi).forEachIndexed { index, v ->
                    Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        VisualDemoPanel(spec, v, Modifier.fillMaxWidth().aspectRatio(1f))
                        Text(listOf("น้อย", "ค่าที่ตั้งอยู่", "มาก")[index], color = PvSub, fontSize = 11.sp)
                        Text(fmtParam(v, spec.integer) + spec.unit, color = PvInk, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                    }
                }
            }
            Slider(value = value.coerceIn(spec.lo, spec.hi), onValueChange = { value = if (spec.integer) it.roundToInt().toFloat() else it }, valueRange = spec.lo..spec.hi, colors = SliderDefaults.colors(thumbColor = PvInk, activeTrackColor = PvInk, inactiveTrackColor = Color(0xFF444444)))
            Text(spec.hint, color = PvInk, fontSize = 13.sp)
            Text("แผนภาพอธิบายพารามิเตอร์เฉพาะทาง ไม่ได้แก้ไขภาพต้นฉบับจนกว่าจะกดใช้ค่านี้", color = PvSub, fontSize = 11.sp)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                if (onApply != null) PvButton("ใช้ค่านี้", primary = true, modifier = Modifier.weight(1f)) { onApply(value); onDismiss() }
                PvButton("ปิด", primary = false, modifier = Modifier.weight(1f)) { onDismiss() }
            }
        }
    }
}

/** ปุ่มเล็ก ▶ ข้างป้ายของช่องกรอก เปิดตัวอย่างของค่านั้น */
@Composable
fun ParamPreviewButton(onClick: () -> Unit) {
    Box(
        Modifier.clip(RoundedCornerShape(50)).background(Color(0xFF2A2A2A)).clickable(onClick = onClick)
            .padding(horizontal = 5.dp, vertical = 2.dp),
        contentAlignment = Alignment.Center,
    ) { Text("▶", color = Color.White, fontSize = 8.sp) }
}

/** ปุ่มเปิดตัวอย่างของสวิตช์/ตัวเลือก */
@Composable
fun ParamOptionPreviewButton(onClick: () -> Unit) = ParamPreviewButton(onClick)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ParamOptionPreviewSheet(spec: ParamPreviewRegistry.OptionSpec, onDismiss: () -> Unit) {
    val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)
    val phase = rememberDemoPhase()
    val dummy = remember(spec) {
        ParamSpec(spec.label, spec.field, spec.group, 0f, 1f, "", spec.hint,
            get = { 0f }, set = { s, _ -> s }, mode = spec.mode, timelinePreview = spec.timeline, grabPreview = spec.grabPreview)
    }
    ModalBottomSheet(onDismissRequest = onDismiss, sheetState = sheetState, containerColor = PvBg, contentColor = PvInk) {
        Column(
            Modifier.fillMaxWidth().verticalScroll(rememberScrollState()).padding(horizontal = 16.dp).padding(bottom = 28.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp),
        ) {
            Text(spec.label, color = PvInk, fontSize = 17.sp, fontWeight = FontWeight.Bold)
            Text(spec.hint, color = PvSub, fontSize = 12.sp)
            spec.variants.forEach { variant ->
                Column(Modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(5.dp)) {
                    Text(variant.label, color = PvInk, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
                    DemoPanel(variant.settings, spec.mode, dummy, phase, Modifier.fillMaxWidth().aspectRatio(1.6f))
                    Text(variant.description, color = PvSub, fontSize = 11.sp)
                }
            }
            PvButton("ปิด", primary = false, modifier = Modifier.fillMaxWidth()) { onDismiss() }
        }
    }
}

/**
 * แผงเลื่อนขึ้นแสดงตัวอย่างของ 1 ค่า
 * initial = ค่าที่ตั้งอยู่ตอนนี้ · localMode = โหมดของเครื่องมือที่เลือกอยู่ (null = ใช้โหมดสำรองของ spec)
 * onApply = null เมื่อเปิดจากคลัง (ดูอย่างเดียว ไม่มีปุ่ม "ใช้ค่านี้")
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ParamPreviewSheet(spec: ParamSpec, initial: Float, localMode: AdvancedWarpMode?, onApply: ((Float) -> Unit)?, onDismiss: () -> Unit) {
    val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)
    var value by remember { mutableFloatStateOf(initial) }
    val mode = if (spec.forceMode && spec.mode != null) spec.mode else (localMode ?: spec.mode ?: AdvancedWarpMode.BULGE)
    val phase = rememberDemoPhase()
    val base = remember(spec) { spec.base(WarpSettings()) }
    val loS = spec.set(base, spec.lo)
    val midS = spec.set(base, value)
    val hiS = spec.set(base, spec.hi)
    val physicsBase = remember(spec) { WarpPhysicsSettings(enabled = true) }
    val loPhysics = spec.physicsSet?.invoke(physicsBase, spec.lo)
    val midPhysics = spec.physicsSet?.invoke(physicsBase, value)
    val hiPhysics = spec.physicsSet?.invoke(physicsBase, spec.hi)
    ModalBottomSheet(onDismissRequest = onDismiss, sheetState = sheetState, containerColor = PvBg, contentColor = PvInk) {
        Column(
            Modifier.fillMaxWidth().verticalScroll(rememberScrollState()).padding(horizontal = 16.dp).padding(bottom = 28.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp),
        ) {
            Text(spec.label, color = PvInk, fontSize = 17.sp, fontWeight = FontWeight.Bold)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    DemoPanel(loS, mode, spec, phase, Modifier.fillMaxWidth().aspectRatio(1f), loPhysics)
                    Text("น้อย", color = PvSub, fontSize = 11.sp)
                    Text(fmtParam(spec.lo, spec.integer) + spec.unit, color = PvInk, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
                }
                Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    DemoPanel(midS, mode, spec, phase, Modifier.fillMaxWidth().aspectRatio(1f), midPhysics)
                    Text("ค่าที่ตั้งอยู่", color = PvSub, fontSize = 11.sp)
                    Text(fmtParam(value, spec.integer) + spec.unit, color = PvInk, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
                }
                Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    DemoPanel(hiS, mode, spec, phase, Modifier.fillMaxWidth().aspectRatio(1f), hiPhysics)
                    Text("มาก", color = PvSub, fontSize = 11.sp)
                    Text(fmtParam(spec.hi, spec.integer) + spec.unit, color = PvInk, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
                }
            }
            Slider(
                value = value.coerceIn(spec.lo, spec.hi),
                onValueChange = { value = if (spec.integer) it.roundToInt().toFloat() else it },
                valueRange = spec.lo..spec.hi,
                steps = if (spec.integer) ((spec.hi - spec.lo).toInt() - 1).coerceAtLeast(0) else 0,
                colors = SliderDefaults.colors(thumbColor = PvInk, activeTrackColor = PvInk, inactiveTrackColor = Color(0xFF444444)),
            )
            Text(spec.hint, color = PvInk, fontSize = 13.sp)
            val note = buildString {
                append("โหมดสาธิต: ").append(ParamDemo.modeThai(mode))
                append(if (spec.timelinePreview) " · กราฟเส้นเวลาอ้างอิงค่าระยะเวลา/หน่วง/ความเร็ว" else if (spec.physicsSet != null) " · คำนวณด้วย WarpStackMath.physicsAt ที่เวลา 0.35 วินาที" else " · ภาพสาธิต ${ParamDemo.SIZE}×${ParamDemo.SIZE} px · ค่าอื่นเป็นค่าเริ่มต้น")
                if (spec.baseNote.isNotEmpty()) append(" ยกเว้น: ").append(spec.baseNote)
                if (value < spec.lo || value > spec.hi) append(" · ค่าที่ตั้งอยู่เกินช่วงของแถบเลื่อน (แต่ภาพกลางใช้ค่าจริง)")
            }
            Text(note, color = PvSub, fontSize = 11.sp)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                if (onApply != null) PvButton("ใช้ค่านี้", primary = true, modifier = Modifier.weight(1f)) { onApply(value); onDismiss() }
                PvButton("ปิด", primary = false, modifier = Modifier.weight(1f)) { onDismiss() }
            }
        }
    }
}

/** หน้า "คลังตัวอย่างค่า": รวมทุกค่าที่มีตัวอย่าง แตะเพื่อเปิดดู */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ParamLibrarySheet(onDismiss: () -> Unit) {
    val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)
    var open by remember { mutableStateOf<ParamSpec?>(null) }
    var openOption by remember { mutableStateOf<ParamPreviewRegistry.OptionSpec?>(null) }
    var openVisual by remember { mutableStateOf<ParamPreviewRegistry.VisualSpec?>(null) }
    val missing = remember { ParamPreviewRegistry.missingFields() }
    ModalBottomSheet(onDismissRequest = onDismiss, sheetState = sheetState, containerColor = PvBg, contentColor = PvInk) {
        Column(
            Modifier.fillMaxWidth().verticalScroll(rememberScrollState()).padding(horizontal = 16.dp).padding(bottom = 28.dp),
            verticalArrangement = Arrangement.spacedBy(6.dp),
        ) {
            Text("คลังตัวอย่างค่า", color = PvInk, fontSize = 18.sp, fontWeight = FontWeight.Bold)
            Text("ตัวอย่างค่าตัวเลข ตัวเลือก และเครื่องมือเฉพาะทาง (${ParamPreviewRegistry.specs.size + ParamPreviewRegistry.optionSpecs.size + ParamPreviewRegistry.visualSpecs.size} รายการ)", color = PvSub, fontSize = 12.sp)
            ParamPreviewRegistry.specs.groupBy { it.group }.forEach { (group, list) ->
                Text(group, color = PvInk, fontSize = 13.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.padding(top = 10.dp))
                list.forEach { spec ->
                    Row(
                        Modifier.fillMaxWidth().clip(RoundedCornerShape(10.dp)).background(PvChip)
                            .clickable { open = spec }.padding(horizontal = 12.dp, vertical = 11.dp),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Text(spec.label, color = PvInk, fontSize = 14.sp, modifier = Modifier.weight(1f))
                        Text("▶", color = PvSub, fontSize = 11.sp)
                    }
                }
            }
            ParamPreviewRegistry.optionSpecs.groupBy { it.group }.forEach { (group, list) ->
                Text(group, color = PvInk, fontSize = 13.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.padding(top = 10.dp))
                list.forEach { spec ->
                    Row(
                        Modifier.fillMaxWidth().clip(RoundedCornerShape(10.dp)).background(PvChip)
                            .clickable { openOption = spec }.padding(horizontal = 12.dp, vertical = 11.dp),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Text(spec.label, color = PvInk, fontSize = 14.sp, modifier = Modifier.weight(1f))
                        Text("▶", color = PvSub, fontSize = 11.sp)
                    }
                }
            }
            ParamPreviewRegistry.visualSpecs.groupBy { it.group }.forEach { (group, list) ->
                Text(group, color = PvInk, fontSize = 13.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.padding(top = 10.dp))
                list.forEach { spec ->
                    Row(
                        Modifier.fillMaxWidth().clip(RoundedCornerShape(10.dp)).background(PvChip)
                            .clickable { openVisual = spec }.padding(horizontal = 12.dp, vertical = 11.dp),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Text(spec.label, color = PvInk, fontSize = 14.sp, modifier = Modifier.weight(1f))
                        Text("▶", color = PvSub, fontSize = 11.sp)
                    }
                }
            }
            if (missing.isNotEmpty()) {
                Text("ยังไม่มีตัวอย่างสำหรับ property ของ WarpSettings", color = PvInk, fontSize = 13.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.padding(top = 14.dp))
                Text(missing.joinToString(", "), color = PvSub, fontSize = 11.sp)
            } else {
                Text("ตรวจสอบ WarpSettings แล้ว: ไม่พบ property ที่ขาดตัวอย่าง", color = PvSub, fontSize = 11.sp, modifier = Modifier.padding(top = 14.dp))
            }
        }
    }
    open?.let { spec ->
        val initial = spec.physicsGet?.invoke(WarpPhysicsSettings()) ?: spec.get(WarpSettings())
        ParamPreviewSheet(spec, initial, null, null) { open = null }
    }
    openOption?.let { spec -> ParamOptionPreviewSheet(spec) { openOption = null } }
    openVisual?.let { spec -> ParamVisualPreviewSheet(spec, (spec.lo + spec.hi) / 2f, null) { openVisual = null } }
}
