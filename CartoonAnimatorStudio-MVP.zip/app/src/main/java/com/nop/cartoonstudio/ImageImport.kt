package com.nop.cartoonstudio

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import java.io.IOException
import kotlin.math.max
import kotlin.math.roundToInt

object ImageImport {
    /** ด้านยาวสุดหลังโหลด (ลดหน่วยความจำ ภาพเล็กกว่านี้จะไม่ถูกย่อ) */
    const val MAX_SIDE = 2048

    /** ด้านยาวสุดของภาพที่เก็บเป็นชิ้นส่วนตัวละคร (ใหญ่กว่านี้ถูกย่อตอนนำเข้า): ภาพที่แสดงบนจอกว้างราว 300 หน่วย ใหญ่กว่านี้ไม่ได้ช่วยให้คมขึ้นแต่กินหน่วยความจำ */
    const val IMPORT_MAX_SIDE = 1024

    /**
     * ตัดขอบโปร่งใสรอบภาพทิ้ง ให้กรอบภาพแนบรูปร่างจริง (พิกเซลที่ความทึบไม่เกิน alphaThreshold จาก 255 ถือว่าว่าง)
     * คืนภาพเดิมถ้าไม่มีช่องโปร่งใส (เช่น JPEG) ไม่มีขอบให้ตัด หรือโปร่งใสทั้งภาพ ไม่ recycle ภาพต้นฉบับ
     */
    fun trimTransparent(src: Bitmap, alphaThreshold: Int = 8): Bitmap {
        if (!src.hasAlpha()) return src
        val w = src.width
        val h = src.height
        val row = IntArray(w)
        var top = -1
        var bottom = -1
        var left = w
        var right = -1
        for (y in 0 until h) {
            src.getPixels(row, 0, w, 0, y, w, 1)
            var first = -1
            var last = -1
            for (x in 0 until w) {
                if ((row[x] ushr 24) > alphaThreshold) {
                    if (first < 0) first = x
                    last = x
                }
            }
            if (first >= 0) {
                if (top < 0) top = y
                bottom = y
                if (first < left) left = first
                if (last > right) right = last
            }
        }
        if (top < 0) return src
        if (left == 0 && top == 0 && right == w - 1 && bottom == h - 1) return src
        return Bitmap.createBitmap(src, left, top, right - left + 1, bottom - top + 1)
    }

    /** ย่อภาพให้ด้านยาวสุดไม่เกิน maxSide (คงสัดส่วนและความโปร่งใส) ย่อทีละครึ่งก่อนเพื่อให้คม คืนภาพเดิมถ้าเล็กพอแล้ว ไม่ recycle ภาพต้นฉบับ */
    fun limitSize(src: Bitmap, maxSide: Int = IMPORT_MAX_SIDE): Bitmap {
        val longest = max(src.width, src.height)
        if (longest <= maxSide) return src
        var cur = src
        while (max(cur.width, cur.height) / 2 >= maxSide) {
            val next = Bitmap.createScaledBitmap(cur, max(1, cur.width / 2), max(1, cur.height / 2), true)
            if (cur !== src) cur.recycle()
            cur = next
        }
        val k = maxSide.toFloat() / longest
        val out = Bitmap.createScaledBitmap(cur, max(1, (src.width * k).roundToInt()), max(1, (src.height * k).roundToInt()), true)
        if (cur !== src && cur !== out) cur.recycle()
        return out
    }

    /**
     * อ่านไฟล์ภาพจากดิสก์ให้ด้านยาวสุดไม่เกิน maxSide โดยไม่เล็กเกินจำเป็น
     * (วิธีเดิมหาร 2 ซ้ำจนต่ำกว่า maxSide: ภาพ 4000px เหลือ 1000px แต่ภาพ 3000px ได้ 1500px)
     * วิธีนี้หารได้เท่าที่ผลยังไม่ต่ำกว่า maxSide แล้วย่อเนียนลงเหลือ maxSide พอดี · ตั้งคำใบ้ mipmap ให้ตอนย่อภาพเล็กลงบนจอไม่เป็นรอยหยัก
     * คืน null ถ้าอ่านไม่ได้ · ควรเรียกใน Dispatchers.IO
     */
    fun decodeFileSharp(path: String, maxSide: Int): Bitmap? {
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeFile(path, bounds)
        if (bounds.outWidth <= 0 || bounds.outHeight <= 0) return null
        var sample = 1
        while (max(bounds.outWidth, bounds.outHeight) / (sample * 2) >= maxSide) sample *= 2
        val opts = BitmapFactory.Options().apply { inSampleSize = sample; inPreferredConfig = Bitmap.Config.ARGB_8888 }
        val raw = BitmapFactory.decodeFile(path, opts) ?: return null
        val out = limitSize(raw, maxSide)
        if (out !== raw) raw.recycle()
        runCatching { out.setHasMipMap(true) }
        synchronized(fromFile) { fromFile.add(out) }
        return out
    }

    /** ภาพที่ถอดจากไฟล์ตรงๆ และยังไม่ถูกแก้ในหน่วยความจำ (อ้างอิงแบบเดียวกับตัวภาพ ไม่กันไม่ให้ถูกเก็บคืน) = ไฟล์บนดิสก์ตรงกับภาพนี้ จึงถอดความละเอียดสูงจากไฟล์เดียวกันได้ */
    private val fromFile: MutableSet<Bitmap> = java.util.Collections.newSetFromMap(java.util.WeakHashMap<Bitmap, Boolean>())
    fun isFromFile(b: Bitmap): Boolean = synchronized(fromFile) { fromFile.contains(b) }

    /** ผลถอดความละเอียดสูง: side = ด้านยาวสุดของภาพที่ได้ (พิกเซล) */
    class HiDecoded(val side: Int, val bitmap: Bitmap)

    /**
     * ถอดไฟล์ต้นฉบับที่ความละเอียดสูงกว่าภาพในหน่วยความจำ (curW×curH) ให้ด้านยาว ≥ wantSide เท่าที่ได้ แต่ไม่เกิน capSide
     * ใช้ inSampleSize ที่เป็นเลขยกกำลังสอง (ไม่ย่อซ้ำ ภาพคม) · คืน null ถ้าไฟล์ไม่ใหญ่กว่าภาพเดิมอย่างมีนัย, สัดส่วนไม่ตรง, หน่วยความจำไม่พอ หรืออ่านไม่ได้
     * ควรเรียกใน Dispatchers.IO
     */
    fun decodeHiRes(path: String, curW: Int, curH: Int, wantSide: Int, capSide: Int = 4096): HiDecoded? {
        return try {
            val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            BitmapFactory.decodeFile(path, bounds)
            val ow = bounds.outWidth
            val oh = bounds.outHeight
            if (ow <= 0 || oh <= 0 || curW <= 0 || curH <= 0) return null
            val fileMax = max(ow, oh)
            val curMax = max(curW, curH)
            if (fileMax <= curMax * 1.2f) return null // ไม่ใหญ่กว่าเดิมพอ ไม่คุ้มถอดใหม่
            val aspectFile = ow.toFloat() / oh
            val aspectCur = curW.toFloat() / curH
            if (kotlin.math.abs(aspectFile - aspectCur) / aspectCur > 0.02f) return null // ไฟล์ไม่ตรงกับภาพ (กันภาพเพี้ยน)
            val want = minOf(wantSide, capSide, fileMax)
            var sample = 1
            while (fileMax / (sample * 2) >= want) sample *= 2
            val budget = Runtime.getRuntime().maxMemory() / 5 // ไม่ให้ภาพเดียวกินเกินหนึ่งในห้าของหน่วยความจำที่แอปใช้ได้
            while ((ow / sample).toLong() * (oh / sample) * 4L > budget) sample *= 2
            if (fileMax / sample <= curMax * 1.2f) return null
            val opts = BitmapFactory.Options().apply { inSampleSize = sample; inPreferredConfig = Bitmap.Config.ARGB_8888 }
            val bmp = BitmapFactory.decodeFile(path, opts) ?: return null
            runCatching { bmp.setHasMipMap(true) }
            HiDecoded(max(bmp.width, bmp.height), bmp)
        } catch (e: OutOfMemoryError) {
            null
        }
    }

    /** เตรียมภาพก่อนเป็นชิ้นส่วน: ตัดขอบโปร่งใส แล้วย่อถ้าใหญ่เกิน ควรเรียกนอก main thread */
    fun prepare(src: Bitmap): Bitmap = limitSize(trimTransparent(src))

    /** โหลดภาพเป็น ARGB_8888 (คงช่องอัลฟา/ความโปร่งใสของ PNG) ควรเรียกใน Dispatchers.IO */
    fun decode(context: Context, uri: Uri): Bitmap {
        val resolver = context.contentResolver
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        val s1 = resolver.openInputStream(uri) ?: throw IOException("เปิดไฟล์ไม่ได้")
        s1.use { BitmapFactory.decodeStream(it, null, bounds) }
        if (bounds.outWidth <= 0 || bounds.outHeight <= 0) {
            throw IOException("ไฟล์นี้ไม่ใช่รูปภาพที่อ่านได้")
        }
        var sample = 1
        while (bounds.outWidth / sample > MAX_SIDE || bounds.outHeight / sample > MAX_SIDE) sample *= 2

        val opts = BitmapFactory.Options().apply {
            inSampleSize = sample
            inPreferredConfig = Bitmap.Config.ARGB_8888
        }
        val s2 = resolver.openInputStream(uri) ?: throw IOException("เปิดไฟล์ไม่ได้")
        return s2.use { BitmapFactory.decodeStream(it, null, opts) }
            ?: throw IOException("ถอดรหัสรูปภาพไม่สำเร็จ")
    }
}
