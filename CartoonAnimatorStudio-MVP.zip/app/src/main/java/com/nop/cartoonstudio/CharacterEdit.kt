package com.nop.cartoonstudio

import android.graphics.Bitmap
import android.graphics.Matrix
import android.graphics.Paint
import kotlin.math.abs
import kotlin.math.max

/**
 * แก้ไขตัวละครที่อยู่ในฉากแอนิเมต (ปุ่ม "✏ แก้ไขตัวละคร" ในเมนูตัวละคร)
 * ฉากเก็บตัวละครเป็นชิ้นส่วนที่รวมภาพแล้ว (1 กระดูก = 1 ชิ้น = 1 ภาพ) ไม่ได้เก็บโครงกระดูกเดิมไว้ จึงสร้างโครงกระดูกชั่วคราวย้อนกลับจากชิ้นส่วน
 * ให้แก้ในหน้าจัดกระดูกเดิม พอกดตกลงค่อยแปลงกลับเป็นชิ้นส่วนใหม่ (ฉากไม่ถูกแตะจนกว่าจะกดตกลง)
 */

/** ค่าของกระดูกตอนเปิดหน้าแก้ไข ไว้เทียบว่าผู้ใช้แก้เส้นนี้ไหม (เส้นที่ไม่ถูกแก้ใช้ค่าเดิมของชิ้นส่วนตรงๆ ไม่คำนวณใหม่ ท่าและการปั้นจึงไม่เพี้ยน) */
class BoneInit(
    val partId: Int,
    val length: Float,
    val angle: Float,
    val bitmap: Bitmap?, // null = กระดูกนี้ไม่มีภาพ (ชิ้นเดิมเป็นภาพโปร่งใส 1x1)
    val imgX: Float,
    val imgY: Float,
    val imgRot: Float,
    val imgScale: Float,
)

/**
 * หน้าแก้ไขตัวละครที่เปิดอยู่
 * unit = หน่วยในหน้าแก้ไข ต่อ 1 หน่วยของฉาก (ขยายโครงให้พอดีจอ จะได้จับกระดูกได้ถนัดแม้ตัวละครในฉากถูกย่อไว้)
 * fromFrame = เฟรมที่เปิดอยู่ตอนกดแก้ไข (เริ่มที่ 0) appearFrom/appearTo = ช่วงเฟรมที่ตัวละครเดิมแสดง (appearTo = -1 = จนจบ)
 */
class CharEditSession(
    val characterId: Int,
    val name: String,
    val fromFrame: Int,
    val appearFrom: Int,
    val appearTo: Int,
    val skeleton: Skeleton,
    val boneInit: Map<Int, BoneInit>,
    val unit: Float,
)

/** ข้อมูลของชิ้นส่วนหนึ่งชิ้นที่จะสร้างเข้าฉาก (key ไว้โยงพ่อ-ลูก: ชิ้นจากการแก้ = id กระดูก, สำเนาของเดิม = id ชิ้นเดิม) */
class PartSpec(
    val key: Int,
    val parentKey: Int?,
    val oldPartId: Int?, // ชิ้นเดิมที่ตรงกัน (ไว้คัดลอกท่าทางทุกเฟรม) null = ชิ้นใหม่ที่เพิ่มตอนแก้
    val name: String,
    val bitmap: Bitmap,
    val pivotX: Float,
    val pivotY: Float,
    val scale: Float,
    val x: Float,
    val y: Float,
    val restRotation: Float,
    val boneLength: Float,
    val hasTip: Boolean,
    val tipX: Float,
    val tipY: Float,
    val flipX: Boolean,
    val role: BoneRole,
    val homeRest: Float,
    val visible: Boolean,
    val freed: Boolean,
    val mirrorH: Boolean,
    val mirrorV: Boolean,
    val charScale: Float,
    val charAlpha: Float,
    val bitmapChanged: Boolean, // ภาพของชิ้นนี้ถูกแก้/สร้างใหม่ (การปั้นรายเฟรมของชิ้นเดิมใช้กับภาพใหม่ไม่ได้ ต้องล้าง)
)

object CharacterEditConvert {
    private const val TARGET_EXTENT = 360f // ขนาดโครงในหน้าแก้ไข (พิกเซล ด้านที่ยาวกว่า)
    private const val EPS = 1e-3f

    /** สร้างโครงกระดูกชั่วคราวจากชิ้นส่วนของตัวละคร cid ในฉาก (ลำดับชั้น = ลำดับวาดเดิม) คืน null ถ้าไม่มีตัวละครนี้ */
    fun open(project: Project, cid: Int, fromFrame: Int): CharEditSession? {
        val ps = project.parts.filter { it.characterId == cid }
        if (ps.isEmpty()) return null
        val ids = ps.map { it.id }.toSet()
        val sk = Skeleton()
        val boneOfPart = HashMap<Int, Int>() // id ชิ้นส่วน -> id กระดูก

        val pending = ArrayList<Part>(ps)
        var progress = true
        while (pending.isNotEmpty() && progress) { // เติมพ่อก่อนลูกเสมอ (ลำดับวาดอาจให้ลูกอยู่ก่อนพ่อ)
            progress = false
            val iter = pending.iterator()
            while (iter.hasNext()) {
                val p = iter.next()
                val pp = p.parentId?.takeIf { it in ids && it != p.id }
                if (pp != null && !boneOfPart.containsKey(pp)) continue
                addBone(sk, p, pp?.let { boneOfPart[it] }, boneOfPart)
                iter.remove()
                progress = true
            }
        }
        for (p in pending) addBone(sk, p, null, boneOfPart) // เหลือค้าง (พ่อวนกัน): ถือเป็นชิ้นราก
        sk.reorder(ps.mapNotNull { boneOfPart[it.id] }) // คืนลำดับวาดเดิม

        // ขยายโครงให้ด้านที่ยาวที่สุดประมาณ TARGET_EXTENT พิกเซล
        var minX = 0f
        var minY = 0f
        var maxX = 0f
        var maxY = 0f
        for (b in sk.bones) {
            val a = sk.baseOf(b)
            val t = sk.tipOf(b)
            for (pt in listOf(a, t)) {
                if (pt.x < minX) minX = pt.x
                if (pt.y < minY) minY = pt.y
                if (pt.x > maxX) maxX = pt.x
                if (pt.y > maxY) maxY = pt.y
            }
        }
        val extent = max(maxX - minX, maxY - minY)
        val u = if (extent < 1f) 1f else (TARGET_EXTENT / extent).coerceIn(0.01f, 1000f)

        val partOfBone = HashMap<Int, Int>()
        for ((partId, boneId) in boneOfPart) partOfBone[boneId] = partId
        val init = HashMap<Int, BoneInit>()
        for (b in sk.bones) {
            b.length = b.length * u
            val img = b.images.firstOrNull()
            if (img != null) {
                img.x = img.x * u
                img.y = img.y * u
                img.scale = img.scale * u
            }
            init[b.id] = BoneInit(
                partOfBone[b.id] ?: 0, b.length, b.angle,
                img?.bitmap, img?.x ?: 0f, img?.y ?: 0f, img?.rotation ?: 0f, img?.scale ?: 1f,
            )
        }
        val first = ps.first()
        return CharEditSession(
            cid, first.characterName.ifBlank { "ตัวละคร" }, fromFrame, first.appearFrom, first.appearTo, sk, init, u,
        )
    }

    private fun mirrored(src: Bitmap): Bitmap {
        val m = Matrix()
        m.preScale(-1f, 1f)
        return Bitmap.createBitmap(src, 0, 0, src.width, src.height, m, true)
    }

    /** เพิ่มกระดูก 1 เส้นจากชิ้นส่วน p (ค่าในหน่วยฉาก ยังไม่ขยาย): ภาพ 1 ภาพ ตำแหน่งภาพคิดย้อนจากข้อต่อ จุดหมุน และขนาดของชิ้น */
    private fun addBone(sk: Skeleton, p: Part, parentBoneId: Int?, boneOfPart: MutableMap<Int, Int>) {
        // มุมของกระดูก = -restRotation (ชิ้นส่วนหมุนตามเข็ม กระดูกหมุนทวนเข็ม) สิ่งของที่ไม่ติดมือใช้มุมจริงในกรอบโลก (homeRest)
        val rel = if (parentBoneId == null && p.role == BoneRole.ITEM) -p.homeRest else -p.restRotation
        val b = sk.add(parentBoneId, max(p.boneLength, 1f), normalizeAngle(rel))
        b.role = p.role
        b.name = p.name
        boneOfPart[p.id] = b.id
        val src = p.bitmap
        if (src.width == 1 && src.height == 1) return // ชิ้นที่ไม่มีภาพ (ภาพโปร่งใส 1x1) = กระดูกที่ไม่มีภาพ
        val flip = p.flipX
        val bmp = if (flip) mirrored(src) else src
        val px = if (flip) src.width - p.pivotX else p.pivotX
        val img = BoneImage(bmp)
        img.x = (bmp.width / 2f - px) * p.scale // กึ่งกลางภาพในกรอบกระดูก (โคน = ข้อต่อ = (0,0))
        img.y = (bmp.height / 2f - p.pivotY) * p.scale
        img.rotation = 0f
        img.scale = p.scale
        b.images.add(img)
    }

    /**
     * แปลงโครงกระดูกที่แก้แล้วกลับเป็นข้อมูลชิ้นส่วน (เรียงตามลำดับชั้นของกระดูก = ลำดับวาด)
     * เส้นที่ไม่ถูกแก้ (ความยาว มุม ภาพ) ใช้ค่าเดิมของชิ้นส่วนตรงๆ เส้นที่แก้ภาพ = รวมภาพใหม่ เส้นที่เพิ่มใหม่ = ชิ้นใหม่
     * คืน null ถ้าไม่มีกระดูกเหลือ ควรเรียกบน main thread (อ่าน state ของ Compose)
     */
    fun rebuild(project: Project, s: CharEditSession): List<PartSpec>? {
        val sk = s.skeleton
        if (sk.bones.isEmpty()) return null
        for (b in sk.bones.toList()) if (b.role == BoneRole.ITEM && b.parentId != null) sk.detachItem(b) // สิ่งของในฉากไม่ติดมือแบบตายตัว (ติด/ถอดเป็นรายเฟรมในหน้าแอนิเมต)

        val oldParts = project.parts.filter { it.characterId == s.characterId }
        val proto = oldParts.firstOrNull()
        val rootPart = oldParts.firstOrNull { it.parentId == null && it.role != BoneRole.ITEM } ?: proto
        val originX = rootPart?.x ?: 0f // จุดรากของโครงในฉาก (ชิ้นรากทุกชิ้นของตัวละครอยู่จุดเดียวกัน)
        val originY = rootPart?.y ?: 0f
        val u = s.unit
        val paint = Paint(Paint.FILTER_BITMAP_FLAG or Paint.ANTI_ALIAS_FLAG)
        val out = ArrayList<PartSpec>()

        sk.bones.forEachIndexed { index, b ->
            val ini = s.boneInit[b.id]
            val old = ini?.let { project.part(it.partId) }?.takeIf { it.characterId == s.characterId }
            val lenSame = ini != null && abs(b.length - ini.length) < EPS
            val angSame = ini != null && abs(normalizeAngle(b.angle - ini.angle)) < EPS
            val img = b.images.firstOrNull()
            val imgSame = old != null && ini != null && b.images.size <= 1 && (
                if (ini.bitmap == null) {
                    img == null
                } else {
                    img != null && img.bitmap === ini.bitmap &&
                        abs(img.x - ini.imgX) < EPS && abs(img.y - ini.imgY) < EPS &&
                        abs(img.rotation - ini.imgRot) < EPS && abs(img.scale - ini.imgScale) < 1e-5f
                }
                )
            val parentBone = sk.bone(b.parentId)
            val isFreeItem = parentBone == null && b.role == BoneRole.ITEM
            val keep: Part? = if (angSame && old != null && old.role == b.role) old else null // มุมไม่เปลี่ยน = ใช้มุมพื้นฐานเดิมเป๊ะ

            val newLen = if (lenSame && old != null) old.boneLength else b.length / u
            val restRot = keep?.restRotation ?: -b.angle
            val homeRest = if (keep != null && isFreeItem) keep.homeRest else -sk.worldAngle(b)

            var x = originX
            var y = originY
            if (parentBone == null) {
                if (old != null && old.parentId == null) { // ชิ้นราก/สิ่งของเดิม: อยู่ที่เดิม
                    x = old.x
                    y = old.y
                }
            } else {
                val pIni = s.boneInit[parentBone.id]
                val pOld = pIni?.let { project.part(it.partId) }
                val parentLenSame = pIni != null && pOld != null && abs(parentBone.length - pIni.length) < EPS
                if (old != null && pIni != null && parentLenSame && old.parentId == pIni.partId) {
                    x = old.x
                    y = old.y
                } else { // ชิ้นลูกอยู่ที่ปลายกระดูกพ่อ (พ่อยาวขึ้น/สั้นลง ลูกเลื่อนตาม)
                    x = if (parentLenSame && pOld != null) pOld.boneLength else parentBone.length / u
                    y = 0f
                }
            }

            val ref = old ?: proto
            val name = b.name.ifBlank { "กระดูก ${index + 1}" }
            if (imgSame && old != null) {
                out.add(
                    PartSpec(
                        key = b.id, parentKey = parentBone?.id, oldPartId = old.id, name = name,
                        bitmap = old.bitmap, pivotX = old.pivotX, pivotY = old.pivotY, scale = old.scale,
                        x = x, y = y, restRotation = restRot, boneLength = newLen,
                        hasTip = old.hasTip, tipX = old.tipX, tipY = old.tipY, flipX = old.flipX,
                        role = b.role, homeRest = homeRest,
                        visible = old.visible, freed = old.freed,
                        mirrorH = ref?.mirrorH ?: false, mirrorV = ref?.mirrorV ?: false,
                        charScale = ref?.charScale ?: 1f, charAlpha = ref?.charAlpha ?: 1f,
                        bitmapChanged = false,
                    ),
                )
            } else {
                val flat = CharacterToParts.flatten(b, paint) // รวมภาพของกระดูกเส้นนี้เป็นภาพเดียว (ภาพต่อหน่วยในหน้าแก้ไข = flat.k)
                out.add(
                    PartSpec(
                        key = b.id, parentKey = parentBone?.id, oldPartId = old?.id, name = name,
                        bitmap = flat.bitmap, pivotX = flat.pivotX, pivotY = flat.pivotY, scale = 1f / flat.k / u,
                        x = x, y = y, restRotation = restRot, boneLength = newLen,
                        hasTip = false, tipX = 0f, tipY = 0f, flipX = false,
                        role = b.role, homeRest = homeRest,
                        visible = old?.visible ?: true, freed = old?.freed ?: false,
                        mirrorH = ref?.mirrorH ?: false, mirrorV = ref?.mirrorV ?: false,
                        charScale = ref?.charScale ?: 1f, charAlpha = ref?.charAlpha ?: 1f,
                        bitmapChanged = true,
                    ),
                )
            }
        }
        return out
    }

    /** สำเนาของชิ้นส่วนเดิมทั้งตัวละคร (ใช้เป็นฉบับเดิมที่แสดงต่อหลังช่วงที่แก้) */
    fun cloneSpecs(parts: List<Part>): List<PartSpec> {
        val ids = parts.map { it.id }.toSet()
        return parts.map { p ->
            PartSpec(
                key = p.id, parentKey = p.parentId?.takeIf { it in ids && it != p.id }, oldPartId = p.id, name = p.name,
                bitmap = p.bitmap, pivotX = p.pivotX, pivotY = p.pivotY, scale = p.scale,
                x = p.x, y = p.y, restRotation = p.restRotation, boneLength = p.boneLength,
                hasTip = p.hasTip, tipX = p.tipX, tipY = p.tipY, flipX = p.flipX,
                role = p.role, homeRest = p.homeRest,
                visible = p.visible, freed = p.freed,
                mirrorH = p.mirrorH, mirrorV = p.mirrorV, charScale = p.charScale, charAlpha = p.charAlpha,
                bitmapChanged = false,
            )
        }
    }
}
