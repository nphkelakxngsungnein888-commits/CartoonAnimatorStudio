package com.nop.cartoonstudio

import android.content.Context
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Slider
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlin.math.roundToInt

/**
 * ความเสถียรของนิ้วตอนวาด (Stabilizer: ตัวช่วยให้เส้นนิ่งขึ้น) · 0 = ปิด (เส้นตามนิ้วทุกจุดเหมือนเดิม) · 100 = นิ่งมากสุด
 * วิธีทำ: ปลายพู่กันเหมือนถูกเชือกผูกตามนิ้ว นิ้วต้องเคลื่อนห่างเกินความยาวเชือกปลายพู่กันถึงจะขยับตาม
 * ความสั่นเล็กๆ ของนิ้วจึงไม่ลงบนเส้น (ยิ่งตั้งสูง เชือกยิ่งยาว เส้นยิ่งเนียน แต่ปลายเส้นจะตามนิ้วช้าลง)
 */
object StrokeStabilizer {
    const val MIN = 0
    const val MAX = 100
    const val DEFAULT = 0

    /** ความยาวเชือกสูงสุด (หน่วย dp) ตอนตั้งค่า 100 */
    private const val MAX_LEASH_DP = 36f

    private const val PREFS = "ui_prefs"
    private const val KEY = "stroke_stabilizer"

    var value by mutableIntStateOf(DEFAULT)
        private set

    fun sanitize(v: Int): Int = v.coerceIn(MIN, MAX)

    fun load(context: Context) {
        value = try {
            sanitize(context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getInt(KEY, DEFAULT))
        } catch (e: Throwable) {
            DEFAULT
        }
    }

    fun set(context: Context, v: Int) {
        value = sanitize(v)
        try {
            context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putInt(KEY, value).apply()
        } catch (_: Throwable) {
            // เก็บไม่สำเร็จ: ใช้ค่านี้ในรอบนี้ได้
        }
    }

    /** ความยาวเชือกเป็นพิกเซลจอ (ตามขนาดจริงบนจอ ไม่เปลี่ยนตามระดับซูมของภาพ) · 0 = ปิด */
    fun leashPx(density: Float): Float = value / MAX.toFloat() * MAX_LEASH_DP * density

    /** ปลายพู่กัน pen ตามนิ้ว finger ด้วยเชือกยาว leash: นิ้วอยู่ในวงเชือก = ปลายอยู่นิ่ง · นอกวง = ปลายถูกลากตามให้ห่างนิ้วเท่าเชือก */
    fun follow(pen: Offset, finger: Offset, leash: Float): Offset {
        if (leash <= 0f) return finger
        val d = (finger - pen).getDistance()
        if (d <= leash) return pen
        val k = (d - leash) / d
        return Offset(pen.x + (finger.x - pen.x) * k, pen.y + (finger.y - pen.y) * k)
    }
}

/** ช่องปรับความเสถียรของนิ้ว: สไลเดอร์ 0–100 + รีเซ็ต (วางในกล่องตั้งค่าของหน้าแก้ไขภาพ ต่อจากตั้งค่าแว่นขยาย) */
@Composable
fun StabilizerSetting() {
    val context = LocalContext.current
    var draft by remember { mutableFloatStateOf(StrokeStabilizer.value.toFloat()) }
    var dragging by remember { mutableStateOf(false) }
    LaunchedEffect(StrokeStabilizer.value) { if (!dragging) draft = StrokeStabilizer.value.toFloat() }

    val card = RoundedCornerShape(16.dp)
    Column(
        Modifier
            .fillMaxWidth()
            .clip(card)
            .background(Palette.PanelHigh)
            .border(1.dp, Palette.Stroke, card)
            .padding(12.dp),
        verticalArrangement = Arrangement.spacedBy(6.dp),
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("ความเสถียรของนิ้ว", Modifier.weight(1f), fontWeight = FontWeight.Bold, color = Palette.Accent)
            val shown = draft.roundToInt()
            Text(if (shown == 0) "ปิด" else "$shown", color = Palette.Accent, fontWeight = FontWeight.Bold)
        }
        Text(
            "ยิ่งสูง เส้นยิ่งนิ่งและเนียน (นิ้วสั่นไม่ลงบนเส้น) แต่ปลายเส้นจะตามนิ้วช้าลงนิดหน่อย · ใช้กับพู่กัน ยางลบ และการวาดบ่วง",
            color = Color(0xFFC9C4D4),
            fontSize = 12.sp,
        )
        Slider(
            value = draft,
            onValueChange = { dragging = true; draft = it.coerceIn(StrokeStabilizer.MIN.toFloat(), StrokeStabilizer.MAX.toFloat()) },
            onValueChangeFinished = {
                dragging = false
                StrokeStabilizer.set(context, draft.roundToInt())
                draft = StrokeStabilizer.value.toFloat()
            },
            valueRange = StrokeStabilizer.MIN.toFloat()..StrokeStabilizer.MAX.toFloat(),
        )
        OutlinedButton(
            onClick = { dragging = false; StrokeStabilizer.set(context, StrokeStabilizer.DEFAULT); draft = StrokeStabilizer.value.toFloat() },
            enabled = StrokeStabilizer.value != StrokeStabilizer.DEFAULT || draft.roundToInt() != StrokeStabilizer.DEFAULT,
            modifier = Modifier.fillMaxWidth(),
        ) { Text("ปิดความเสถียร (ตามนิ้วทุกจุด)") }
    }
}
