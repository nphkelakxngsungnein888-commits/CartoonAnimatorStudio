package com.nop.cartoonstudio

import android.graphics.Bitmap
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGesturesAfterLongPress
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.defaultMinSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

/**
 * เลเยอร์ 1 ชั้นในหน้าแก้ไขภาพ (กระดาษใสซ้อนกันแบบ ibisPaint) · id ไม่ซ้ำ · bmp = ภาพของชั้นนั้น ขนาดเท่าผืนผ้าใบ
 * หมายเหตุ: ชั้นที่กำลังแก้อยู่ ภาพจริงอยู่ที่ work ในหน้าจอ ค่า bmp ในรายการอาจเก่ากว่า
 */
internal class LayerItem(val id: Int, val bmp: Bitmap)

/**
 * สถานะเลเยอร์ทั้งหมดของหน้าแก้ไขภาพ รวมไว้ในก้อนเดียว
 * (ฟังก์ชันหน้าจอ ImageCropScreen ใหญ่มาก ถ้ามีตัวแปรท้องถิ่นเพิ่มหลายตัวจะเจอ VerifyError ตอนเปิดหน้านี้)
 * layers = ล่างสุด → บนสุด · activeId = เลเยอร์ที่เลือก · locked = เลเยอร์ที่ล็อก · clip = เลเยอร์ที่คัดลอกไว้
 */
internal class CropLayerUi(first: Bitmap) {
    var layers by mutableStateOf(listOf(LayerItem(1, first)))
    var activeId by mutableIntStateOf(1)
    var nextId by mutableIntStateOf(2)
    var locked by mutableStateOf<Set<Int>>(emptySet())
    var panelOpen by mutableStateOf(false)
    var clip by mutableStateOf<Bitmap?>(null)
    var lassoClip by mutableStateOf<LassoClip?>(null) // ส่วนที่คัดลอก/ตัดจากบ่วงไว้ (เครื่องมือบ่วง · ดู CropPaste.kt) ไว้วาง
    var exportOpen by mutableStateOf(false) // แผงตัวเลือกส่งออก (CropExport.kt) เปิดอยู่ไหม
    var toolsOpen by mutableStateOf(false) // แผงเครื่องมือบ่วง (คัดลอก/ตัด/วาง) เปิดอยู่ไหม
    var mixOn by mutableStateOf(false) // พู่กัน: ผสมสีกับสีเดิมของเลเยอร์เดียวกัน (ปุ่มอยู่ในแผงสีพู่กัน · ดู BrushMix.kt)
    var mixStrength by mutableFloatStateOf(1f) // ความแรงการผสม 0..1 (1 = เฉลี่ยครึ่งๆ กับสีเดิม)
    var mix: BrushMix? = null // ตัวผสมสีของเส้นที่กำลังลาก (ไม่ใช่ state ไม่ต้องให้หน้าจอวาดใหม่)

    /** เริ่มเส้นพู่กันใหม่: ผสมสีเปิดอยู่ = คืนแคนวาสมาสก์ให้พู่กันวาดลงแทน target · ไม่ผสม = null (ผู้เรียกใช้แคนวาสของ target ตามปกติ) */
    fun beginMix(base: Bitmap, target: Bitmap, brush: Boolean, color: Int): android.graphics.Canvas? {
        val m = if (brush && mixOn) BrushMix.create(base, target, color, mixStrength) else null
        mix = m
        return m?.canvas
    }

    fun endMix() {
        mix = null
    }
}

/** คำสั่งจากแผงเลเยอร์ไปยังหน้าแก้ไขภาพ (ส่งผ่านฟังก์ชันเดียว ไม่ต้องสร้างตัวรับคำสั่งหลายตัวในฟังก์ชันหน้าจอ) */
internal enum class LayerOp { SELECT, ADD, COPY, PASTE, DELETE, LOCK, UP, DOWN }

/** ไอคอนเลเยอร์มุมล่างขวา + แผงเลเยอร์ที่เปิดเหนือไอคอน (วางใน Box ของหน้าแก้ไขภาพ) */
@Composable
internal fun LayerOverlay(
    modifier: Modifier, ui: CropLayerUi, activeBmp: () -> Bitmap,
    strokeUi: Boolean, joyLow: Boolean, busy: Boolean,
    onOp: (LayerOp, Int) -> Boolean,
) {
    Column(
        modifier.padding(end = if (strokeUi) 66.dp else 10.dp, bottom = if (joyLow) 172.dp else 10.dp), // หลบแผงเครื่องมือขวา / ปุ่มของจอย
        horizontalAlignment = Alignment.End,
        verticalArrangement = Arrangement.spacedBy(8.dp),
    ) {
        if (ui.panelOpen) {
            CropLayerPanel(
                layers = ui.layers, activeId = ui.activeId, activeBmp = activeBmp(), lockedIds = ui.locked,
                canPaste = ui.clip != null && !busy, busy = busy,
                onSelect = { onOp(LayerOp.SELECT, it) },
                onAdd = { onOp(LayerOp.ADD, 0) },
                onCopy = { onOp(LayerOp.COPY, 0) },
                onPaste = { onOp(LayerOp.PASTE, 0) },
                onDelete = { onOp(LayerOp.DELETE, 0) },
                onToggleLock = { onOp(LayerOp.LOCK, it) },
                onMove = { id, up -> onOp(if (up) LayerOp.UP else LayerOp.DOWN, id) },
            )
        }
        LayerFab(open = ui.panelOpen, count = ui.layers.size, onClick = { ui.panelOpen = !ui.panelOpen })
    }
    BackHandler(enabled = ui.panelOpen) { ui.panelOpen = false } // กดย้อนกลับตอนแผงเปิด = ปิดแผงก่อน (ไม่ออกจากหน้า)
}

private val LayerInk = Color(0xFFE7E3EE)
private val LayerSub = Color(0xFFC9C4D4)
private val LayerDanger = Color(0xFFE5484D)
private val LayerGold = Color(0xFFFFC83D)
private val LayerFabBg = Color(0xE6272734)

/** ไอคอนที่วาดเอง (ไม่พึ่งไฟล์ภาพ) สำหรับปุ่มในแผงเลเยอร์ */
private enum class LayerGlyph { STACK, ADD, COPY, PASTE, TRASH, LOCK, UNLOCK, GRIP }

@Composable
private fun LayerGlyphIcon(kind: LayerGlyph, tint: Color, iconSize: Dp = 20.dp) {
    Canvas(Modifier.size(iconSize)) {
        val w = size.width
        val h = size.height
        val round = StrokeCap.Round
        val stroke = Stroke(width = w * 0.1f, cap = round, join = StrokeJoin.Round)
        when (kind) {
            LayerGlyph.STACK -> { // กระดาษสามแผ่นซ้อนกัน: แผ่นบนทึบ สองแผ่นล่างเป็นเส้น
                val top = Path().apply {
                    moveTo(w * 0.5f, h * 0.06f); lineTo(w * 0.94f, h * 0.30f); lineTo(w * 0.5f, h * 0.54f); lineTo(w * 0.06f, h * 0.30f); close()
                }
                drawPath(top, tint)
                for (dy in listOf(0.16f, 0.32f)) {
                    val chevron = Path().apply {
                        moveTo(w * 0.06f, h * (0.30f + dy)); lineTo(w * 0.5f, h * (0.54f + dy)); lineTo(w * 0.94f, h * (0.30f + dy))
                    }
                    drawPath(chevron, tint, style = stroke)
                }
            }
            LayerGlyph.ADD -> {
                drawLine(tint, Offset(w * 0.18f, h * 0.5f), Offset(w * 0.82f, h * 0.5f), strokeWidth = w * 0.13f, cap = round)
                drawLine(tint, Offset(w * 0.5f, h * 0.18f), Offset(w * 0.5f, h * 0.82f), strokeWidth = w * 0.13f, cap = round)
            }
            LayerGlyph.COPY -> { // สี่เหลี่ยมสองใบซ้อนเหลื่อมกัน
                val back = Path().apply {
                    moveTo(w * 0.34f, h * 0.28f); lineTo(w * 0.34f, h * 0.10f); lineTo(w * 0.88f, h * 0.10f)
                    lineTo(w * 0.88f, h * 0.66f); lineTo(w * 0.70f, h * 0.66f)
                }
                drawPath(back, tint, style = stroke)
                drawRoundRect(
                    tint, topLeft = Offset(w * 0.12f, h * 0.30f), size = Size(w * 0.58f, h * 0.60f),
                    cornerRadius = CornerRadius(w * 0.1f), style = stroke,
                )
            }
            LayerGlyph.PASTE -> { // คลิปบอร์ด
                drawRoundRect(
                    tint, topLeft = Offset(w * 0.16f, h * 0.18f), size = Size(w * 0.68f, h * 0.74f),
                    cornerRadius = CornerRadius(w * 0.1f), style = stroke,
                )
                drawRoundRect(
                    tint, topLeft = Offset(w * 0.34f, h * 0.06f), size = Size(w * 0.32f, h * 0.18f),
                    cornerRadius = CornerRadius(w * 0.06f),
                )
                drawLine(tint, Offset(w * 0.32f, h * 0.50f), Offset(w * 0.68f, h * 0.50f), strokeWidth = w * 0.08f, cap = round)
                drawLine(tint, Offset(w * 0.32f, h * 0.70f), Offset(w * 0.56f, h * 0.70f), strokeWidth = w * 0.08f, cap = round)
            }
            LayerGlyph.TRASH -> { // ถังขยะ
                drawLine(tint, Offset(w * 0.14f, h * 0.26f), Offset(w * 0.86f, h * 0.26f), strokeWidth = w * 0.1f, cap = round)
                val handle = Path().apply {
                    moveTo(w * 0.38f, h * 0.26f); lineTo(w * 0.38f, h * 0.10f); lineTo(w * 0.62f, h * 0.10f); lineTo(w * 0.62f, h * 0.26f)
                }
                drawPath(handle, tint, style = stroke)
                val body = Path().apply {
                    moveTo(w * 0.22f, h * 0.34f); lineTo(w * 0.28f, h * 0.90f); lineTo(w * 0.72f, h * 0.90f); lineTo(w * 0.78f, h * 0.34f)
                }
                drawPath(body, tint, style = stroke)
                drawLine(tint, Offset(w * 0.42f, h * 0.46f), Offset(w * 0.42f, h * 0.76f), strokeWidth = w * 0.08f, cap = round)
                drawLine(tint, Offset(w * 0.58f, h * 0.46f), Offset(w * 0.58f, h * 0.76f), strokeWidth = w * 0.08f, cap = round)
            }
            LayerGlyph.LOCK, LayerGlyph.UNLOCK -> { // กุญแจ: ปิด = ล็อก · เปิด = ห่วงยกขึ้น
                val locked = kind == LayerGlyph.LOCK
                val bodyTop = h * 0.48f
                val r = w * 0.26f
                val cx = w * 0.5f
                drawRoundRect(
                    tint, topLeft = Offset(w * 0.12f, bodyTop), size = Size(w * 0.76f, h * 0.48f),
                    cornerRadius = CornerRadius(w * 0.12f),
                )
                val top = if (locked) h * 0.08f else 0f
                val shackle = Path().apply {
                    moveTo(cx - r, bodyTop)
                    lineTo(cx - r, top + r)
                    arcTo(Rect(cx - r, top, cx + r, top + 2 * r), 180f, 180f, false)
                    lineTo(cx + r, if (locked) bodyTop else bodyTop - h * 0.14f)
                }
                drawPath(shackle, tint, style = Stroke(width = w * 0.13f, cap = round))
            }
            LayerGlyph.GRIP -> { // มือจับ: กดค้างแล้วลาก
                for (fy in listOf(0.30f, 0.50f, 0.70f)) {
                    drawLine(tint, Offset(w * 0.2f, h * fy), Offset(w * 0.8f, h * fy), strokeWidth = w * 0.09f, cap = round)
                }
            }
        }
    }
}

/** ปุ่มไอคอนเลเยอร์มุมล่างขวา (ทรงเดียวกับปุ่มกลมอื่นในหน้านี้ · มีเลขจำนวนเลเยอร์เป็นป้ายเล็ก) */
@Composable
internal fun LayerFab(open: Boolean, count: Int, onClick: () -> Unit) {
    Box(Modifier.size(54.dp)) {
        Box(
            Modifier.align(Alignment.Center).size(46.dp).clip(CircleShape)
                .background(if (open) Palette.Accent.copy(alpha = 0.38f) else LayerFabBg)
                .border(if (open) 2.dp else 1.dp, if (open) Palette.Accent else Palette.Stroke, CircleShape)
                .clickable(onClick = onClick),
            contentAlignment = Alignment.Center,
        ) { LayerGlyphIcon(LayerGlyph.STACK, if (open) Color.White else Color(0xFFD8D4E4), 24.dp) }
        if (count > 1) {
            Box(
                Modifier.align(Alignment.TopEnd).defaultMinSize(minWidth = 18.dp, minHeight = 18.dp).clip(CircleShape)
                    .background(Palette.Accent).padding(horizontal = 4.dp),
                contentAlignment = Alignment.Center,
            ) { Text(count.toString(), color = Color(0xFF2A1A66), fontSize = 10.sp, fontWeight = FontWeight.Bold, maxLines = 1) }
        }
    }
}

/** ปุ่มเครื่องมือสี่เหลี่ยมมุมมนในแผงเลเยอร์: ไอคอน + ป้ายชื่อเล็กด้านล่าง */
@Composable
private fun LayerToolButton(
    glyph: LayerGlyph, label: String, onClick: () -> Unit,
    enabled: Boolean = true, danger: Boolean = false, active: Boolean = false,
) {
    val tint = when { !enabled -> LayerSub.copy(alpha = 0.4f); danger -> LayerDanger; active -> LayerGold; else -> Palette.Accent }
    val edge = when { !enabled -> Palette.Stroke.copy(alpha = 0.4f); danger -> LayerDanger.copy(alpha = 0.45f); active -> LayerGold.copy(alpha = 0.6f); else -> Palette.Stroke }
    val shape = RoundedCornerShape(13.dp)
    Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.width(46.dp)) {
        Box(
            Modifier.size(42.dp).clip(shape)
                .background(if (active) LayerGold.copy(alpha = 0.14f) else Palette.PanelHigh)
                .border(1.dp, edge, shape)
                .clickable(enabled = enabled, onClick = onClick),
            contentAlignment = Alignment.Center,
        ) { LayerGlyphIcon(glyph, tint, 22.dp) }
        Text(label, color = if (enabled) LayerSub else LayerSub.copy(alpha = 0.4f), fontSize = 10.sp, maxLines = 1, modifier = Modifier.padding(top = 3.dp))
    }
}

/**
 * แผงเลเยอร์: แถวบนสุด = เลเยอร์บนสุด (ทับเลเยอร์ล่าง)
 * กดแถว = เลือกเลเยอร์ที่จะแก้ · กดกุญแจที่แถว = ล็อก/ปลดล็อก · กดค้างที่แถวแล้วลากขึ้น/ลง = เลื่อนลำดับ
 * activeBmp = ภาพปัจจุบันของเลเยอร์ที่เลือก (ใช้แสดงรูปย่อ เพราะค่าในรายการอาจเก่ากว่า)
 */
@Composable
internal fun CropLayerPanel(
    layers: List<LayerItem>, activeId: Int, activeBmp: Bitmap, lockedIds: Set<Int>,
    canPaste: Boolean, busy: Boolean,
    onSelect: (Int) -> Unit, onAdd: () -> Unit, onCopy: () -> Unit, onPaste: () -> Unit,
    onDelete: () -> Unit, onToggleLock: (Int) -> Unit, onMove: (Int, Boolean) -> Boolean,
) {
    val shape = RoundedCornerShape(18.dp)
    val ordered = layers.asReversed()
    val activeLocked = activeId in lockedIds
    val rowH = 54.dp
    val rowGap = 4.dp
    val stepPx = with(LocalDensity.current) { (rowH + rowGap).toPx() }
    val onMoveNow by rememberUpdatedState(onMove)
    Column(
        Modifier.width(266.dp).clip(shape).background(Palette.Panel.copy(alpha = 0.97f)).border(1.dp, Palette.Stroke, shape)
            .pointerInput(Unit) { detectTapGestures { } } // กันแตะทะลุแผงไปโดนภาพด้านหลัง
            .padding(10.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp),
    ) {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            LayerGlyphIcon(LayerGlyph.STACK, Palette.Accent, 16.dp)
            Text("เลเยอร์ (${layers.size})", color = LayerInk, fontSize = 14.sp, fontWeight = FontWeight.Bold)
        }
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            LayerToolButton(LayerGlyph.ADD, "เพิ่ม", onClick = onAdd, enabled = !busy)
            LayerToolButton(LayerGlyph.COPY, "คัดลอก", onClick = onCopy, enabled = !busy)
            LayerToolButton(LayerGlyph.PASTE, "วาง", onClick = onPaste, enabled = canPaste)
            LayerToolButton(LayerGlyph.TRASH, "ลบ", onClick = onDelete, enabled = !busy && layers.size > 1, danger = true)
            LayerToolButton(
                if (activeLocked) LayerGlyph.LOCK else LayerGlyph.UNLOCK,
                if (activeLocked) "ปลดล็อก" else "ล็อก",
                onClick = { onToggleLock(activeId) }, active = activeLocked,
            )
        }
        Text("กดค้างที่เลเยอร์ แล้วลากขึ้น/ลง เพื่อเลื่อนลำดับ (บนสุด = ทับเลเยอร์ล่าง)", color = LayerSub, fontSize = 10.5.sp)
        LazyColumn(Modifier.heightIn(max = 190.dp), verticalArrangement = Arrangement.spacedBy(rowGap)) {
            items(ordered, key = { it.id }) { layer ->
                var dragging by remember { mutableStateOf(false) }
                var acc by remember { mutableFloatStateOf(0f) }
                val isActive = layer.id == activeId
                val isLocked = layer.id in lockedIds
                val rowShape = RoundedCornerShape(12.dp)
                val bmp = if (isActive) activeBmp else layer.bmp
                val thumb = remember(bmp) { bmp.asImageBitmap() }
                Row(
                    Modifier.fillMaxWidth().height(rowH).clip(rowShape)
                        .background(if (dragging) Palette.Stroke else if (isActive) Palette.Accent.copy(alpha = 0.28f) else Palette.PanelHigh)
                        .border(if (isActive || dragging) 1.5.dp else 1.dp, if (dragging) LayerGold else if (isActive) Palette.Accent else Palette.Stroke, rowShape)
                        .clickable { onSelect(layer.id) }
                        .pointerInput(layer.id) {
                            detectDragGesturesAfterLongPress(
                                onDragStart = { dragging = true; acc = 0f; onSelect(layer.id) },
                                onDragEnd = { dragging = false; acc = 0f },
                                onDragCancel = { dragging = false; acc = 0f },
                                onDrag = { change, amount ->
                                    change.consume()
                                    acc += amount.y
                                    while (acc <= -stepPx) { if (onMoveNow(layer.id, true)) acc += stepPx else { acc = 0f; break } }
                                    while (acc >= stepPx) { if (onMoveNow(layer.id, false)) acc -= stepPx else { acc = 0f; break } }
                                },
                            )
                        }
                        .padding(horizontal = 7.dp),
                    verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp),
                ) {
                    Image(
                        thumb, null, contentScale = ContentScale.Fit,
                        modifier = Modifier.size(40.dp).clip(RoundedCornerShape(8.dp)).background(Color(0xFF3A3A4A)),
                    )
                    Column(Modifier.weight(1f)) {
                        Text(
                            "เลเยอร์ ${layer.id}", color = LayerInk, fontSize = 12.5.sp, maxLines = 1, overflow = TextOverflow.Ellipsis,
                            fontWeight = if (isActive) FontWeight.Bold else FontWeight.Normal,
                        )
                        Text(if (isLocked) "ล็อกอยู่" else if (isActive) "กำลังแก้" else "", color = LayerSub, fontSize = 10.5.sp, maxLines = 1)
                    }
                    Box(Modifier.size(30.dp).clip(CircleShape).clickable { onToggleLock(layer.id) }, contentAlignment = Alignment.Center) {
                        LayerGlyphIcon(if (isLocked) LayerGlyph.LOCK else LayerGlyph.UNLOCK, if (isLocked) LayerGold else LayerSub.copy(alpha = 0.6f), 15.dp)
                    }
                    LayerGlyphIcon(LayerGlyph.GRIP, LayerSub.copy(alpha = if (dragging) 1f else 0.55f), 18.dp)
                }
            }
        }
    }
}
