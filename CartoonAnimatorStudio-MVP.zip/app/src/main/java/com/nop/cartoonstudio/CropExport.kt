package com.nop.cartoonstudio

import android.content.ContentValues
import android.content.Context
import android.graphics.Bitmap
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream
import java.io.IOException
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.ceil
import kotlin.math.floor
import kotlin.math.roundToInt

/*
 * ปุ่ม "ส่งออก" ของหน้าแก้ไขภาพ: เด้งแผงตัวเลือก (ส่งอะไร · ชนิดไฟล์ · ขนาด · ชื่อไฟล์) แล้วกด "ส่งออก" บันทึกลงแกลเลอรี Pictures/CartoonAnimatorStudio
 * ส่งเฉพาะส่วนในบ่วง (ไม่มีบ่วง = ทั้งผืน) · ไม่แตะภาพที่กำลังแก้ ส่งออกแล้วค้างอยู่หน้าแก้ไขภาพเหมือนเดิม
 * แยกมาไว้ไฟล์นี้ เพื่อไม่ให้ ImageCropScreen ใหญ่ขึ้น (เคยเกิด VerifyError) · สถานะ "เปิดแผงอยู่ไหม" = CropLayerUi.exportOpen
 */

private enum class ExpFmt(val ext: String, val label: String) { PNG("png", "PNG"), JPG("jpg", "JPG"), WEBP("webp", "WebP") }

private const val EXPORT_MAX_SIDE = 8192
private const val EXPORT_MAX_PIXELS = 40_000_000L

private fun defaultExportName(): String = "CartoonAnimator_" + SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())

/** ชื่อไฟล์ที่ปลอดภัย: ตัดอักขระที่ตั้งชื่อไฟล์ไม่ได้ และนามสกุลที่พิมพ์ซ้ำ · ว่าง = ใช้ชื่ออัตโนมัติ */
private fun cleanExportName(raw: String): String {
    var s = raw.replace(Regex("[\\\\/:*?\"<>|\\n\\r\\t]"), "").trim()
    s = s.replace(Regex("\\.(png|jpe?g|webp)$", RegexOption.IGNORE_CASE), "").trim().trimEnd('.')
    return if (s.isEmpty()) defaultExportName() else s.take(100)
}

/** ขนาดของส่วนที่จะส่งออก (กรอบที่ครอบบ่วงทั้งหมด คำนวณเหมือน cropByLassosAt) · ไม่มีบ่วง = ทั้งภาพ · null = บ่วงอยู่นอกภาพ */
private fun exportRegionSize(w: Int, h: Int, lassos: List<Path>): Pair<Int, Int>? {
    if (lassos.isEmpty()) return Pair(w, h)
    val rect = RectF()
    val tmp = RectF()
    var first = true
    for (p in lassos) {
        p.computeBounds(tmp, true)
        if (first) {
            rect.set(tmp)
            first = false
        } else {
            rect.union(tmp)
        }
    }
    val l = floor(rect.left).toInt().coerceIn(0, w)
    val t = floor(rect.top).toInt().coerceIn(0, h)
    val r = ceil(rect.right).toInt().coerceIn(0, w)
    val b = ceil(rect.bottom).toInt().coerceIn(0, h)
    return if (r - l < 1 || b - t < 1) null else Pair(r - l, b - t)
}

/**
 * ประกอบภาพต้นทางใหม่ (ไม่แตะของเดิม): allLayers = ซ้อนทุกเลเยอร์ตามลำดับ · ไม่ใช่ = เฉพาะเลเยอร์ที่เลือก
 * เลเยอร์ที่เลือกใช้ work (ภาพที่แก้อยู่ล่าสุด) · includeOv = วางรูปที่กำลังวางอยู่ลงไปด้วย (ในชั้นของเลเยอร์ที่เลือก)
 * ไม่รวมรูปที่กำลังวาง + เป็นโหมดย้าย = ใช้ภาพก่อนเจาะรู (ชิ้นที่ยกออกยังอยู่ที่เดิม)
 */
private fun composeExportSource(
    layers: List<LayerItem>, activeId: Int, work: Bitmap, ov: Overlay?, includeOv: Boolean, allLayers: Boolean,
): Bitmap? {
    val out = runCatching { Bitmap.createBitmap(work.width, work.height, Bitmap.Config.ARGB_8888) }.getOrNull() ?: return null
    val cv = android.graphics.Canvas(out)
    val paint = Paint(Paint.FILTER_BITMAP_FLAG or Paint.ANTI_ALIAS_FLAG)
    val mv = ov?.move
    for (ly in layers) {
        val active = ly.id == activeId
        if (!allLayers && !active) continue
        val base = if (active) (if (mv != null && !includeOv) mv.before else work) else ly.bmp
        cv.drawBitmap(base, 0f, 0f, null)
        if (active && ov != null && includeOv) {
            val m = Matrix() // เหมือนตอนกด ✔ วางรูป (placeOverlay)
            m.postTranslate(-ov.bmp.width / 2f, -ov.bmp.height / 2f)
            m.postScale(ov.scale, ov.scale * ov.ratio)
            m.postRotate(ov.angle)
            m.postTranslate(ov.cx, ov.cy)
            cv.drawBitmap(ov.bmp, m, paint)
        }
    }
    return out
}

/** บันทึกลงแกลเลอรี (Android 10+ ผ่าน MediaStore · ต่ำกว่านั้นลงโฟลเดอร์ของแอป) คืนตำแหน่งที่บันทึก · ควรเรียกนอก main thread */
private fun saveExportImage(context: Context, bmp: Bitmap, baseName: String, fmt: ExpFmt): String {
    val format = when (fmt) {
        ExpFmt.PNG -> Bitmap.CompressFormat.PNG
        ExpFmt.JPG -> Bitmap.CompressFormat.JPEG
        ExpFmt.WEBP -> if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) Bitmap.CompressFormat.WEBP_LOSSLESS else Bitmap.CompressFormat.WEBP
    }
    val quality = if (fmt == ExpFmt.JPG) 95 else 100
    val mime = when (fmt) {
        ExpFmt.PNG -> "image/png"
        ExpFmt.JPG -> "image/jpeg"
        ExpFmt.WEBP -> "image/webp"
    }
    val fileName = "$baseName.${fmt.ext}"
    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
        val values = ContentValues().apply {
            put(MediaStore.Images.Media.DISPLAY_NAME, fileName)
            put(MediaStore.Images.Media.MIME_TYPE, mime)
            put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/CartoonAnimatorStudio")
            put(MediaStore.Images.Media.IS_PENDING, 1)
        }
        val resolver = context.contentResolver
        val uri = resolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values)
            ?: throw IOException("สร้างไฟล์ในแกลเลอรีไม่ได้")
        try {
            val out = resolver.openOutputStream(uri) ?: throw IOException("เปิดไฟล์เพื่อเขียนไม่ได้")
            out.use {
                if (!bmp.compress(format, quality, it)) throw IOException("เข้ารหัส ${fmt.label} ไม่สำเร็จ")
            }
            values.clear()
            values.put(MediaStore.Images.Media.IS_PENDING, 0)
            resolver.update(uri, values, null, null)
        } catch (e: Exception) {
            resolver.delete(uri, null, null)
            throw e
        }
        return "Pictures/CartoonAnimatorStudio/$fileName"
    } else {
        val dir = File(context.getExternalFilesDir(Environment.DIRECTORY_PICTURES), "CartoonAnimatorStudio")
        if (!dir.exists() && !dir.mkdirs()) throw IOException("สร้างโฟลเดอร์ไม่ได้")
        val f = File(dir, fileName)
        FileOutputStream(f).use {
            if (!bmp.compress(format, quality, it)) throw IOException("เข้ารหัส ${fmt.label} ไม่สำเร็จ")
        }
        return f.absolutePath
    }
}

/** งานส่งออกทั้งหมด (ประกอบ → ตัดตามบ่วง → ปรับขนาด → พื้นขาวถ้า JPG → บันทึก) ใช้ใน Dispatchers.Default · คืนตำแหน่งที่บันทึก */
private fun runExport(
    context: Context, layers: List<LayerItem>, activeId: Int, work: Bitmap, lassos: List<Path>, ov: Overlay?,
    includeOv: Boolean, allLayers: Boolean, fmt: ExpFmt, outW: Int, outH: Int, baseName: String,
): String {
    val made = ArrayList<Bitmap>() // บิตแมปที่สร้างขึ้นเองในงานนี้ (ปล่อยคืนตอนจบ) · ห้ามใส่ work / บิตแมปของเลเยอร์
    try {
        val src = composeExportSource(layers, activeId, work, ov, includeOv, allLayers) ?: throw IOException("หน่วยความจำไม่พอสำหรับประกอบภาพ")
        made.add(src)
        var cur = src
        if (lassos.isNotEmpty()) {
            val r = cropByLassosAt(src, lassos) ?: throw IOException("บ่วงอยู่นอกภาพ")
            cur = r.bmp
            if (cur !== src) made.add(cur)
        }
        if (cur.width != outW || cur.height != outH) {
            cur = Bitmap.createScaledBitmap(cur, outW, outH, true)
            made.add(cur)
        }
        if (fmt == ExpFmt.JPG) { // JPG ไม่มีความโปร่งใส ลงพื้นขาว
            val flat = Bitmap.createBitmap(cur.width, cur.height, Bitmap.Config.ARGB_8888)
            made.add(flat)
            val fc = android.graphics.Canvas(flat)
            fc.drawColor(android.graphics.Color.WHITE)
            fc.drawBitmap(cur, 0f, 0f, null)
            cur = flat
        }
        return saveExportImage(context, cur, baseName, fmt)
    } finally {
        for (b in made) if (!b.isRecycled) b.recycle()
    }
}

// ───────────────────────── แผงตัวเลือกส่งออก ─────────────────────────

/**
 * แผงเต็มจอ (ฉากมืด + การ์ดกลางจอ) วางท้ายสุดใน Box ของหน้าแก้ไขภาพ
 * work = ภาพของเลเยอร์ที่เลือกตอนนี้ · lassos = บ่วงปัจจุบัน (ว่าง = ทั้งผืน) · overlay = รูปที่กำลังวางอยู่ (null = ไม่มี) → ถามว่าจะรวมไหม
 */
@Composable
internal fun CropExportPanel(ui: CropLayerUi, work: Bitmap, lassos: List<Path>, overlay: Overlay?) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val region = remember(lassos, work.width, work.height) { exportRegionSize(work.width, work.height, lassos) }
    var allLayers by remember { mutableStateOf(false) }
    var fmtIdx by remember { mutableIntStateOf(0) }
    var includeOv by remember { mutableStateOf(true) }
    var name by remember { mutableStateOf(defaultExportName()) }
    var outW by remember { mutableIntStateOf(region?.first ?: work.width) }
    var outH by remember { mutableIntStateOf(region?.second ?: work.height) }
    var locked by remember { mutableStateOf(true) }
    var pad by remember { mutableIntStateOf(0) } // 0 = ปิดแผงตัวเลข · 1 = กว้าง · 2 = สูง
    var busy by remember { mutableStateOf(false) }
    val fmt = ExpFmt.values()[fmtIdx]
    val rw = region?.first ?: work.width
    val rh = region?.second ?: work.height
    val aspect = rw.toFloat() / rh.toFloat()

    BackHandler(enabled = !busy) { ui.exportOpen = false }

    Box(
        Modifier
            .fillMaxSize()
            .background(Color(0x99000000))
            .pointerInput(Unit) { detectTapGestures { } }, // กันการแตะทะลุลงไปโดนภาพด้านหลัง
        contentAlignment = Alignment.Center,
    ) {
        val shape = RoundedCornerShape(24.dp)
        Column(
            Modifier
                .fillMaxWidth(0.94f)
                .heightIn(max = 620.dp)
                .clip(shape)
                .background(Palette.PanelHigh)
                .border(1.dp, Palette.Stroke, shape)
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            Text("ส่งออกภาพ", color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.Bold)

            if (ui.layers.size > 1) {
                ExportLabel("ส่งอะไร")
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OptChip("เลเยอร์ที่เลือก", !allLayers, Modifier.weight(1f)) { allLayers = false }
                    OptChip("รวมทุกเลเยอร์", allLayers, Modifier.weight(1f)) { allLayers = true }
                }
            }

            ExportLabel("ชนิดไฟล์")
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                ExpFmt.values().forEachIndexed { i, f -> OptChip(f.label, fmtIdx == i, Modifier.weight(1f)) { fmtIdx = i } }
            }
            Text(
                if (fmt == ExpFmt.JPG) "JPG ไม่มีพื้นโปร่งใส ส่วนโปร่งใสจะเป็นสีขาว" else "คงพื้นโปร่งใสไว้",
                color = Color(0xFFC9C4D4), fontSize = 12.sp,
            )

            if (overlay != null) {
                ExportLabel("รูปที่กำลังวางอยู่ (ยังไม่กด ✔)")
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OptChip("รวมด้วย", includeOv, Modifier.weight(1f)) { includeOv = true }
                    OptChip("ไม่รวม", !includeOv, Modifier.weight(1f)) { includeOv = false }
                }
            }

            ExportLabel("ส่วนที่ส่งออก")
            Text(
                when {
                    region == null -> "บ่วงอยู่นอกภาพ ส่งออกไม่ได้ (วาดบ่วงใหม่ก่อน)"
                    lassos.isEmpty() -> "ทั้งผืนผ้าใบ (ไม่มีบ่วง) · ${rw}×${rh} พิกเซล"
                    else -> "เฉพาะส่วนในบ่วง · ${rw}×${rh} พิกเซล"
                },
                color = if (region == null) Color(0xFFFF8A80) else Color.White, fontSize = 14.sp,
            )

            ExportLabel("ขนาดที่ส่งออก (พิกเซล)")
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                LockButton(locked) { locked = !locked }
                ValueChip("กว้าง", "$outW", enabled = !busy) { pad = 1 }
                ValueChip("สูง", "$outH", enabled = !busy) { pad = 2 }
            }

            ExportLabel("ชื่อไฟล์")
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                OutlinedTextField(
                    value = name, onValueChange = { name = it.take(100) }, singleLine = true, enabled = !busy,
                    textStyle = TextStyle(color = Color.White, fontSize = 15.sp), modifier = Modifier.weight(1f),
                )
                Text(".${fmt.ext}", color = Color(0xFFC9C4D4), fontSize = 14.sp)
            }

            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                OutlinedButton(onClick = { ui.exportOpen = false }, enabled = !busy, modifier = Modifier.weight(1f)) { Text("ยกเลิก") }
                Button(
                    enabled = !busy && region != null,
                    modifier = Modifier.weight(1f),
                    onClick = {
                        if (outW.toLong() * outH.toLong() > EXPORT_MAX_PIXELS) {
                            QuickToast.show(context, "ภาพใหญ่เกินไป (สูงสุดราว 40 ล้านพิกเซล) ลดขนาดลงก่อน")
                        } else {
                            val layers = ui.layers
                            val activeId = ui.activeId
                            val base = cleanExportName(name)
                            scope.launch {
                                busy = true
                                val res = withContext(Dispatchers.Default) {
                                    runCatching { runExport(context, layers, activeId, work, lassos, overlay, includeOv, allLayers, fmt, outW, outH, base) }
                                }
                                busy = false
                                res.onSuccess { path ->
                                    QuickToast.show(context, "บันทึกแล้ว: $path", 3000L)
                                    ui.exportOpen = false // ปิดแผง ค้างอยู่หน้าแก้ไขภาพ ไม่เปลี่ยนอะไร
                                }.onFailure {
                                    Toast.makeText(context, "ส่งออกไม่สำเร็จ: ${it.message ?: it.javaClass.simpleName}", Toast.LENGTH_LONG).show()
                                }
                            }
                        }
                    },
                ) { Text(if (busy) "กำลังส่งออก…" else "ส่งออก") }
            }
        }
    }

    when (pad) {
        1 -> FloatingPad(
            title = "กว้าง", unit = "px", initial = outW.toFloat(),
            onDismiss = { pad = 0 },
            onOk = { v ->
                val nw = v.roundToInt().coerceIn(1, EXPORT_MAX_SIDE)
                outW = nw
                if (locked) outH = (nw / aspect).roundToInt().coerceIn(1, EXPORT_MAX_SIDE) // ล็อกสัดส่วน: สูงตามกว้างเทียบสัดส่วนของส่วนที่ส่งออก
                pad = 0
            },
        )
        2 -> FloatingPad(
            title = "สูง", unit = "px", initial = outH.toFloat(),
            onDismiss = { pad = 0 },
            onOk = { v ->
                val nh = v.roundToInt().coerceIn(1, EXPORT_MAX_SIDE)
                outH = nh
                if (locked) outW = (nh * aspect).roundToInt().coerceIn(1, EXPORT_MAX_SIDE)
                pad = 0
            },
        )
    }
}

@Composable
private fun ExportLabel(text: String) {
    Text(text, color = Color(0xFFC9C4D4), fontSize = 13.sp, fontWeight = FontWeight.Medium)
}

@Composable
private fun OptChip(label: String, selected: Boolean, modifier: Modifier, onClick: () -> Unit) {
    val shape = RoundedCornerShape(14.dp)
    Box(
        modifier
            .clip(shape)
            .background(if (selected) Palette.Accent.copy(alpha = 0.38f) else Palette.Panel)
            .border(if (selected) 2.dp else 1.dp, if (selected) Palette.Accent else Palette.Stroke, shape)
            .clickable(onClick = onClick)
            .padding(horizontal = 10.dp, vertical = 11.dp),
        contentAlignment = Alignment.Center,
    ) {
        Text(label, color = Color.White, fontSize = 14.sp, fontWeight = if (selected) FontWeight.Bold else FontWeight.Normal)
    }
}
