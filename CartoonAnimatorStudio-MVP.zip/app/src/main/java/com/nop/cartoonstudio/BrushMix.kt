package com.nop.cartoonstudio

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Path
import android.graphics.RectF
import kotlin.math.ceil
import kotlin.math.floor
import kotlin.math.max
import kotlin.math.min

/**
 * ผสมสีของพู่กันในหน้าแก้ไขภาพ (แยกไฟล์ เพื่อไม่ให้ ImageCropScreen ใหญ่ขึ้น · เคยเกิด VerifyError)
 *
 * หลักการ: พู่กันไม่ระบายลงภาพตรงๆ แต่ลงบน "มาสก์ความครอบคลุม" (ALPHA_8 ขนาดเท่าภาพ) ก่อน
 * แล้วคำนวณพิกเซลผลลัพธ์จาก base (ภาพของเลเยอร์เดียวกันก่อนเริ่มลากเส้นนี้) + มาสก์ ลงบน target
 *  - ใช้ base ของเลเยอร์ที่กำลังวาดเท่านั้น → สีของเลเยอร์อื่นไม่เข้ามาผสม
 *  - คำนวณจาก base ทุกครั้ง ไม่ใช่จากผลล่าสุด → ลากทับตัวเองในเส้นเดียวกันไม่ผสมซ้ำ · ลากเส้นใหม่ทับค่อยผสมเพิ่ม
 *
 * สูตร (สีแบบ straight ไม่ premultiply) ต่อ 1 พิกเซล: strength = 0..1
 *   k   = baseAlpha * 0.5 * strength           // น้ำหนักสีเดิมที่ผสมเข้าไป (สูงสุด 0.5 = เฉลี่ยครึ่งๆ ที่ strength 100%)
 *   Cp  = brush*(1-k) + base*k                  // สีที่พู่กันวางลงพิกเซลนี้
 *   a'  = cov + baseAlpha*(1-cov)               // cov = ความครอบคลุมจากมาสก์ (ขอบนุ่ม anti-alias)
 *   rgb'= (Cp*cov + base*baseAlpha*(1-cov)) / a'
 * ที่ baseAlpha = 0 (ว่างเปล่า) ได้สีพู่กันเต็ม · strength = 0 เท่ากับระบายปกติ
 */
internal class BrushMix private constructor(
    private val base: Bitmap,
    private val target: Bitmap,
    private val mask: Bitmap,
    /** แคนวาสของมาสก์: ให้พู่กันวาดลงที่นี่แทนการวาดลง target */
    val canvas: Canvas,
    private val color: Int,
    private val strength: Float,
) {
    private var bufBase = IntArray(0)
    private var bufMask = IntArray(0)
    private val tmpRect = RectF()

    /** คำนวณพิกเซลใหม่ในกรอบ (พิกัดภาพ) แล้วเขียนลง target */
    fun flush(left: Float, top: Float, right: Float, bottom: Float) {
        if (base.isRecycled || target.isRecycled || mask.isRecycled) return
        val w = target.width
        val h = target.height
        val x0 = max(0, floor(left).toInt())
        val y0 = max(0, floor(top).toInt())
        val x1 = min(w, ceil(right).toInt())
        val y1 = min(h, ceil(bottom).toInt())
        val rw = x1 - x0
        val rh = y1 - y0
        if (rw <= 0 || rh <= 0) return
        val n = rw * rh
        if (bufBase.size < n) {
            bufBase = IntArray(n)
            bufMask = IntArray(n)
        }
        base.getPixels(bufBase, 0, rw, x0, y0, rw, rh)
        mask.getPixels(bufMask, 0, rw, x0, y0, rw, rh)

        val br = (color shr 16) and 0xFF
        val bg = (color shr 8) and 0xFF
        val bb = color and 0xFF
        val brushA = ((color ushr 24) and 0xFF) / 255f
        val half = 0.5f * strength.coerceIn(0f, 1f)

        for (i in 0 until n) {
            val m = (bufMask[i] ushr 24) and 0xFF
            if (m == 0) continue // ไม่โดนพู่กัน: คงค่า base (เท่ากับ target เดิม)
            val cov = (m / 255f) * brushA
            if (cov <= 0f) continue
            val p = bufBase[i]
            val ab = ((p ushr 24) and 0xFF) / 255f
            val pr = (p shr 16) and 0xFF
            val pg = (p shr 8) and 0xFF
            val pb = p and 0xFF
            val k = ab * half
            val cr = br * (1f - k) + pr * k
            val cg = bg * (1f - k) + pg * k
            val cb = bb * (1f - k) + pb * k
            val inv = ab * (1f - cov)
            val oa = cov + inv
            if (oa <= 0f) continue
            val outR = (cr * cov + pr * inv) / oa
            val outG = (cg * cov + pg * inv) / oa
            val outB = (cb * cov + pb * inv) / oa
            val a8 = (oa * 255f + 0.5f).toInt().coerceIn(0, 255)
            bufBase[i] = (a8 shl 24) or
                ((outR + 0.5f).toInt().coerceIn(0, 255) shl 16) or
                ((outG + 0.5f).toInt().coerceIn(0, 255) shl 8) or
                (outB + 0.5f).toInt().coerceIn(0, 255)
        }
        target.setPixels(bufBase, 0, rw, x0, y0, rw, rh)
    }

    /** จุดกลม 1 จุด (รัศมี radius) กลางที่ (cx, cy) */
    fun flushDot(cx: Float, cy: Float, radius: Float) {
        val r = radius + 2f
        flush(cx - r, cy - r, cx + r, cy + r)
    }

    /** รอยลากช่วง a → b ความกว้าง width */
    fun flushSeg(ax: Float, ay: Float, bx: Float, by: Float, width: Float) {
        val r = width / 2f + 2f
        flush(min(ax, bx) - r, min(ay, by) - r, max(ax, bx) + r, max(ay, by) + r)
    }

    /** เส้น/บ่วงทั้งก้อน (ใช้ตอนกด "ตกลง" ของพู่กันแบบเส้น) */
    fun flushPath(path: Path, width: Float) {
        path.computeBounds(tmpRect, true)
        val r = width / 2f + 2f
        flush(tmpRect.left - r, tmpRect.top - r, tmpRect.right + r, tmpRect.bottom + r)
    }

    companion object {
        /** สร้างตัวผสมสี · หน่วยความจำไม่พอ = null (ผู้เรียกระบายแบบปกติแทน) */
        fun create(base: Bitmap, target: Bitmap, color: Int, strength: Float): BrushMix? {
            if (base.width != target.width || base.height != target.height) return null
            val mask = runCatching { Bitmap.createBitmap(target.width, target.height, Bitmap.Config.ALPHA_8) }.getOrNull() ?: return null
            return BrushMix(base, target, mask, Canvas(mask), color, strength)
        }
    }
}
