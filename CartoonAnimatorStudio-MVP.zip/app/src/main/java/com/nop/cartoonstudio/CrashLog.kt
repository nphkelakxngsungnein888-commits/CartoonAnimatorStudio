package com.nop.cartoonstudio

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.sp
import java.io.File

/**
 * จดสาเหตุที่แอปเด้ง (Crash) ลงไฟล์ แล้วโชว์ให้อ่าน/คัดลอกตอนเปิดแอปครั้งถัดไป
 * (ไว้ตรวจสาเหตุบนมือถือ ไม่ต้องใช้คอมดู logcat) · ไม่กระทบการทำงานอื่นของแอป
 */
internal object CrashLog {
    private const val FILE = "last_crash.txt"

    fun install(ctx: Context) {
        val app = ctx.applicationContext
        val old = Thread.getDefaultUncaughtExceptionHandler()
        Thread.setDefaultUncaughtExceptionHandler { t, e ->
            runCatching {
                File(app.filesDir, FILE).writeText("เธรด: ${t.name}\n" + summarize(e))
            }
            old?.uncaughtException(t, e) // ให้ระบบปิดแอปตามปกติ
        }
    }

    /** สรุปสาเหตุให้สั้นอ่านบนมือถือ: ชื่อข้อผิดพลาด + บรรทัดแรกๆ + บรรทัดที่อยู่ในโค้ดของแอปนี้ (ไล่ตามสาเหตุต้นทางด้วย) */
    private fun summarize(t: Throwable): String {
        val sb = StringBuilder()
        var cur: Throwable? = t
        var depth = 0
        while (cur != null && depth < 5) {
            if (depth > 0) sb.append("สาเหตุต้นทาง: ")
            sb.append(cur.javaClass.name).append(": ").append(cur.message).append('\n')
            val fr = cur.stackTrace
            val mine = fr.filter { it.className.startsWith("com.nop.cartoonstudio") }.take(8)
            (fr.take(4) + mine).distinct().forEach { sb.append("  at ").append(it.toString()).append('\n') }
            cur = cur.cause
            depth++
        }
        return sb.toString()
    }

    fun read(ctx: Context): String? =
        runCatching { File(ctx.applicationContext.filesDir, FILE).takeIf { it.exists() }?.readText() }.getOrNull()

    fun clear(ctx: Context) {
        runCatching { File(ctx.applicationContext.filesDir, FILE).delete() }
    }
}

/** กล่องบอกสาเหตุที่แอปเด้งครั้งก่อน (มีปุ่มคัดลอกไปวางส่งให้ผู้ช่วยดู) · ไม่มีบันทึก = ไม่แสดงอะไร */
@Composable
internal fun CrashLogDialog() {
    val context = LocalContext.current
    var text by remember { mutableStateOf(CrashLog.read(context)) }
    val t = text ?: return
    AlertDialog(
        onDismissRequest = { },
        title = { Text("แอปเพิ่งเด้งครั้งก่อน") },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState())) {
                Text(t.take(4000), fontSize = 11.sp, lineHeight = 14.sp)
            }
        },
        confirmButton = {
            TextButton(onClick = {
                runCatching {
                    val cm = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                    cm.setPrimaryClip(ClipData.newPlainText("crash", t))
                }
            }) { Text("คัดลอก") }
        },
        dismissButton = {
            TextButton(onClick = { CrashLog.clear(context); text = null }) { Text("ปิด") }
        },
    )
}
