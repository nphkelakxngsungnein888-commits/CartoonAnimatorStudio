package com.nop.cartoonstudio

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.media.MediaMetadataRetriever
import android.os.Build
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.isActive
import java.io.File
import java.io.FileOutputStream
import java.io.IOException
import java.util.concurrent.atomic.AtomicInteger

/** ตัวช่วยอ่านเฟรมจากไฟล์วิดีโอสำหรับคลิปวิดีโอใน Image Studio */
object VideoFrames {
    /** ด้านยาวสุดของเฟรมที่ใช้ตอนส่งออก/ภาพปก (พิกเซล) */
    const val MAX_SIDE = 1280

    /** ด้านยาวสุดของเฟรมที่ใช้แสดงตัวอย่างบนจอ (เบากว่าเพื่อให้เล่นลื่น) */
    const val PREVIEW_SIDE = 640

    class Info(val durationSec: Float, val poster: Bitmap)

    /** อ่านความยาวและภาพปก (เฟรมที่ offsetSec) ควรเรียกใน Dispatchers.IO ถ้าอ่านไม่ได้จะ throw */
    fun probe(file: File, offsetSec: Float = 0f): Info {
        val r = MediaMetadataRetriever()
        try {
            r.setDataSource(file.absolutePath)
            val hasVideo = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_HAS_VIDEO)
            if (hasVideo != "yes") throw IOException("ไฟล์นี้ไม่มีภาพวิดีโอ")
            val ms = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: 0L
            if (ms <= 0L) throw IOException("อ่านความยาววิดีโอไม่ได้")
            val raw = r.getFrameAtTime((offsetSec * 1_000_000f).toLong(), MediaMetadataRetriever.OPTION_CLOSEST_SYNC)
                ?: r.getFrameAtTime(0L, MediaMetadataRetriever.OPTION_CLOSEST_SYNC)
                ?: throw IOException("ถอดรหัสภาพวิดีโอไม่ได้ (รูปแบบนี้เครื่องไม่รองรับ)")
            return Info(ms / 1000f, fit(raw, MAX_SIDE))
        } finally {
            runCatching { r.release() }
        }
    }

    /** ย่อให้ด้านยาวสุดไม่เกิน maxSide (คงสัดส่วน) และให้เป็น ARGB_8888 ที่แก้ไขได้ */
    private fun fit(src: Bitmap, maxSide: Int): Bitmap {
        val longest = maxOf(src.width, src.height)
        val k = if (longest > maxSide) maxSide.toFloat() / longest else 1f
        val w = maxOf(1, Math.round(src.width * k))
        val h = maxOf(1, Math.round(src.height * k))
        val out = if (w == src.width && h == src.height && src.config == Bitmap.Config.ARGB_8888) src
        else Bitmap.createScaledBitmap(src, w, h, true)
        if (out !== src) src.recycle()
        return out
    }
}

/** ตัวอ่านเฟรมของไฟล์วิดีโอหนึ่งไฟล์ (เรียกจากหลายเธรดได้ ทีละครั้ง) ต้อง close() เมื่อเลิกใช้ */
class VideoReader(private val file: File, private val lengthSec: Float) {
    private var mmr: MediaMetadataRetriever? = null

    /**
     * เฟรมที่เวลา sec (วินาทีในไฟล์) ย่อให้ได้ขนาด w×h พอดี คืน null ถ้าอ่านไม่ได้
     * exact = true ใช้เฟรมที่ใกล้เวลาที่สุดจริง (ส่งออก) · false = เฟรมหลักใกล้เวลา (เร็วกว่า)
     */
    @Synchronized
    fun frame(sec: Float, w: Int, h: Int, exact: Boolean = true): Bitmap? {
        val r = mmr ?: MediaMetadataRetriever().also { it.setDataSource(file.absolutePath); mmr = it }
        val t = sec.coerceIn(0f, maxOf(0f, lengthSec - 0.05f))
        val us = (t * 1_000_000f).toLong()
        val opt = if (exact) MediaMetadataRetriever.OPTION_CLOSEST else MediaMetadataRetriever.OPTION_CLOSEST_SYNC
        val raw = (if (Build.VERSION.SDK_INT >= 27) r.getScaledFrameAtTime(us, opt, w, h) else r.getFrameAtTime(us, opt))
            ?: return null
        if (raw.width == w && raw.height == h) return raw
        val out = Bitmap.createScaledBitmap(raw, w, h, true)
        if (out !== raw) raw.recycle()
        return out
    }

    @Synchronized
    fun close() {
        runCatching { mmr?.release() }
        mmr = null
    }
}

/**
 * แคชเฟรมพรีวิวของคลิปวิดีโอ (JPEG ย่อ) เพื่อให้เล่นบนจอลื่น
 * เหตุผล: MediaMetadataRetriever ดึงทีละเฟรมต้องเลื่อนหาตำแหน่งแล้วถอดรหัสใหม่ทุกครั้ง (ช้ากว่าเวลาจริงถ้าวิดีโอมีคีย์เฟรมห่าง)
 * จึงถอดล่วงหน้าเป็นไฟล์ครั้งเดียว แล้วตอนเล่นอ่านจากไฟล์ซึ่งเร็วและสม่ำเสมอ · เฟรมที่ยังไม่พร้อมให้ผู้เรียกถอดสดแบบเดิม
 */
object VideoProxy {
    const val FPS = 24
    private const val JPEG_QUALITY = 85
    private const val WORKERS = 2

    /** ดัชนีเฟรมพร็อกซีของเวลา sec (วินาทีในไฟล์) */
    fun indexOf(sec: Float): Int = Math.round(sec * FPS)

    /** ดัชนีเฟรมสุดท้ายที่ใช้ได้ (ตรงกับเวลาสูงสุดที่ videoLocalTime ให้) */
    fun lastIndex(lengthSec: Float): Int = maxOf(0, Math.round(maxOf(0f, lengthSec - 0.05f) * FPS))

    fun dir(context: Context, file: File, w: Int, h: Int): File =
        File(File(context.cacheDir, "video_proxy"), "${file.absolutePath.hashCode()}_${file.length()}_${w}x$h").apply { mkdirs() }

    private fun frameFile(dir: File, index: Int) = File(dir, "p$index.jpg")

    /** อ่านเฟรมพร็อกซี (null = ยังไม่มี/อ่านไม่ได้) */
    fun load(dir: File, index: Int): Bitmap? {
        val f = frameFile(dir, index)
        if (!f.exists()) return null
        return runCatching { BitmapFactory.decodeFile(f.absolutePath) }.getOrNull()
    }

    /** ลบแคชที่ไม่ได้ใช้เกิน maxAgeDays วัน */
    fun cleanOld(context: Context, maxAgeDays: Int = 7) {
        val limit = System.currentTimeMillis() - maxAgeDays * 86_400_000L
        File(context.cacheDir, "video_proxy").listFiles()?.forEach { if (it.lastModified() < limit) it.deleteRecursively() }
    }

    /**
     * ถอดเฟรมพร็อกซีดัชนี from..to ขนาด w×h เก็บลงแคช (ข้ามเฟรมที่มีแล้ว) ใช้ตัวอ่านสองตัวแบ่งเฟรมคู่/คี่
     * onProgress เรียกจากเธรด IO · ยกเลิกได้ด้วยการ cancel coroutine
     */
    suspend fun build(dir: File, file: File, lengthSec: Float, from: Int, to: Int, w: Int, h: Int, onProgress: (Float) -> Unit) {
        val total = (to - from + 1).coerceAtLeast(1)
        val done = AtomicInteger(0)
        coroutineScope {
            (0 until WORKERS).map { worker ->
                async(Dispatchers.IO) {
                    val reader = VideoReader(file, lengthSec)
                    try {
                        var i = from + worker
                        while (i <= to && isActive) {
                            val target = frameFile(dir, i)
                            if (!target.exists()) {
                                val bmp = runCatching { reader.frame(i / FPS.toFloat(), w, h, exact = true) }.getOrNull()
                                if (bmp != null) {
                                    runCatching {
                                        val tmp = File(dir, "p$i.tmp")
                                        FileOutputStream(tmp).use { out -> bmp.compress(Bitmap.CompressFormat.JPEG, JPEG_QUALITY, out) }
                                        if (!tmp.renameTo(target)) tmp.delete()
                                    }
                                    bmp.recycle()
                                }
                            }
                            onProgress(done.incrementAndGet().toFloat() / total)
                            i += WORKERS
                        }
                    } finally {
                        reader.close()
                    }
                }
            }.awaitAll()
        }
    }
}
