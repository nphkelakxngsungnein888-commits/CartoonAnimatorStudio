package com.nop.cartoonstudio

import android.graphics.Bitmap
import android.media.MediaMetadataRetriever
import android.os.Build
import java.io.File
import java.io.IOException

/** ตัวช่วยอ่านเฟรมจากไฟล์วิดีโอสำหรับคลิปวิดีโอใน Image Studio */
object VideoFrames {
    /** ด้านยาวสุดของเฟรมที่ใช้ตอนส่งออก/ภาพปก (พิกเซล) */
    const val MAX_SIDE = 1280

    /** ด้านยาวสุดของเฟรมที่ใช้แสดงตัวอย่างบนจอ (เบากว่าเพื่อให้เล่นลื่น) */
    const val PREVIEW_SIDE = 640

    class Info(val durationSec: Float, val poster: Bitmap)

    /** อ่านความยาวและภาพปก (เฟรมที่ offsetSec) ควรเรียกใน Dispatchers.IO ถ้าอ่านไม่ได้จะ throw */
    fun probe(file: File, offsetSec: Float = 0f): Info {
        val r = MediaMetadataRetriever()
        try {
            r.setDataSource(file.absolutePath)
            val hasVideo = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_HAS_VIDEO)
            if (hasVideo != "yes") throw IOException("ไฟล์นี้ไม่มีภาพวิดีโอ")
            val ms = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: 0L
            if (ms <= 0L) throw IOException("อ่านความยาววิดีโอไม่ได้")
            val raw = r.getFrameAtTime((offsetSec * 1_000_000f).toLong(), MediaMetadataRetriever.OPTION_CLOSEST_SYNC)
                ?: r.getFrameAtTime(0L, MediaMetadataRetriever.OPTION_CLOSEST_SYNC)
                ?: throw IOException("ถอดรหัสภาพวิดีโอไม่ได้ (รูปแบบนี้เครื่องไม่รองรับ)")
            return Info(ms / 1000f, fit(raw, MAX_SIDE))
        } finally {
            runCatching { r.release() }
        }
    }

    /** ย่อให้ด้านยาวสุดไม่เกิน maxSide (คงสัดส่วน) และให้เป็น ARGB_8888 ที่แก้ไขได้ */
    private fun fit(src: Bitmap, maxSide: Int): Bitmap {
        val longest = maxOf(src.width, src.height)
        val k = if (longest > maxSide) maxSide.toFloat() / longest else 1f
        val w = maxOf(1, Math.round(src.width * k))
        val h = maxOf(1, Math.round(src.height * k))
        val out = if (w == src.width && h == src.height && src.config == Bitmap.Config.ARGB_8888) src
        else Bitmap.createScaledBitmap(src, w, h, true)
        if (out !== src) src.recycle()
        return out
    }
}

/** ตัวอ่านเฟรมของไฟล์วิดีโอหนึ่งไฟล์ (เรียกจากหลายเธรดได้ ทีละครั้ง) ต้อง close() เมื่อเลิกใช้ */
class VideoReader(private val file: File, private val lengthSec: Float) {
    private var mmr: MediaMetadataRetriever? = null

    /**
     * เฟรมที่เวลา sec (วินาทีในไฟล์) ย่อให้ได้ขนาด w×h พอดี คืน null ถ้าอ่านไม่ได้
     * exact = true ใช้เฟรมที่ใกล้เวลาที่สุดจริง (ส่งออก) · false = เฟรมหลักใกล้เวลา (เร็วกว่า)
     */
    @Synchronized
    fun frame(sec: Float, w: Int, h: Int, exact: Boolean = true): Bitmap? {
        val r = mmr ?: MediaMetadataRetriever().also { it.setDataSource(file.absolutePath); mmr = it }
        val t = sec.coerceIn(0f, maxOf(0f, lengthSec - 0.05f))
        val us = (t * 1_000_000f).toLong()
        val opt = if (exact) MediaMetadataRetriever.OPTION_CLOSEST else MediaMetadataRetriever.OPTION_CLOSEST_SYNC
        val raw = (if (Build.VERSION.SDK_INT >= 27) r.getScaledFrameAtTime(us, opt, w, h) else r.getFrameAtTime(us, opt))
            ?: return null
        if (raw.width == w && raw.height == h) return raw
        val out = Bitmap.createScaledBitmap(raw, w, h, true)
        if (out !== raw) raw.recycle()
        return out
    }

    @Synchronized
    fun close() {
        runCatching { mmr?.release() }
        mmr = null
    }
}
