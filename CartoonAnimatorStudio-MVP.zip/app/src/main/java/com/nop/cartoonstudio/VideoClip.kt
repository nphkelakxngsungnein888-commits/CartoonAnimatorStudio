package com.nop.cartoonstudio

import android.graphics.Bitmap
import android.media.Image
import android.media.MediaCodec
import android.media.MediaCodecInfo
import android.media.MediaExtractor
import android.media.MediaFormat
import android.media.MediaMetadataRetriever
import android.os.Build
import java.io.File
import java.io.IOException
import java.util.concurrent.LinkedBlockingDeque
import java.util.concurrent.TimeUnit

/** ตัวช่วยอ่านเฟรมจากไฟล์วิดีโอสำหรับคลิปวิดีโอใน Image Studio */
object VideoFrames {
    /** ด้านยาวสุดของเฟรมที่ใช้ตอนส่งออก/ภาพปก (พิกเซล) */
    const val MAX_SIDE = 1280

    /** ด้านยาวสุดของเฟรมสำรองตอนเล่น (ถอดสดด้วย MediaMetadataRetriever เมื่อตัวถอดรหัสแบบสตรีมยังไม่พร้อม) */
    const val PREVIEW_SIDE = 960

    class Info(val durationSec: Float, val poster: Bitmap)

    /** อ่านความยาวและภาพปก (เฟรมที่ offsetSec) ควรเรียกใน Dispatchers.IO ถ้าอ่านไม่ได้จะ throw */
    fun probe(file: File, offsetSec: Float = 0f): Info {
        val r = MediaMetadataRetriever()
        try {
            r.setDataSource(file.absolutePath)
            val hasVideo = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_HAS_VIDEO)
            if (hasVideo != "yes") throw IOException("ไฟล์นี้ไม่มีภาพวิดีโอ")
            val ms = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: 0L
            if (ms <= 0L) throw IOException("อ่านความยาววิดีโอไม่ได้")
            val raw = r.getFrameAtTime((offsetSec * 1_000_000f).toLong(), MediaMetadataRetriever.OPTION_CLOSEST_SYNC)
                ?: r.getFrameAtTime(0L, MediaMetadataRetriever.OPTION_CLOSEST_SYNC)
                ?: throw IOException("ถอดรหัสภาพวิดีโอไม่ได้ (รูปแบบนี้เครื่องไม่รองรับ)")
            return Info(ms / 1000f, fit(raw, MAX_SIDE))
        } finally {
            runCatching { r.release() }
        }
    }

    /** ย่อให้ด้านยาวสุดไม่เกิน maxSide (คงสัดส่วน) และให้เป็น ARGB_8888 ที่แก้ไขได้ */
    private fun fit(src: Bitmap, maxSide: Int): Bitmap {
        val longest = maxOf(src.width, src.height)
        val k = if (longest > maxSide) maxSide.toFloat() / longest else 1f
        val w = maxOf(1, Math.round(src.width * k))
        val h = maxOf(1, Math.round(src.height * k))
        val out = if (w == src.width && h == src.height && src.config == Bitmap.Config.ARGB_8888) src
        else Bitmap.createScaledBitmap(src, w, h, true)
        if (out !== src) src.recycle()
        return out
    }
}

/** ตัวอ่านเฟรมของไฟล์วิดีโอหนึ่งไฟล์ (เรียกจากหลายเธรดได้ ทีละครั้ง) ต้อง close() เมื่อเลิกใช้ */
class VideoReader(private val file: File, private val lengthSec: Float) {
    private var mmr: MediaMetadataRetriever? = null

    /**
     * เฟรมที่เวลา sec (วินาทีในไฟล์) ย่อให้ได้ขนาด w×h พอดี คืน null ถ้าอ่านไม่ได้
     * exact = true ใช้เฟรมที่ใกล้เวลาที่สุดจริง (ส่งออก) · false = เฟรมหลักใกล้เวลา (เร็วกว่า)
     */
    @Synchronized
    fun frame(sec: Float, w: Int, h: Int, exact: Boolean = true): Bitmap? {
        val r = mmr ?: MediaMetadataRetriever().also { it.setDataSource(file.absolutePath); mmr = it }
        val t = sec.coerceIn(0f, maxOf(0f, lengthSec - 0.05f))
        val us = (t * 1_000_000f).toLong()
        val opt = if (exact) MediaMetadataRetriever.OPTION_CLOSEST else MediaMetadataRetriever.OPTION_CLOSEST_SYNC
        val raw = (if (Build.VERSION.SDK_INT >= 27) r.getScaledFrameAtTime(us, opt, w, h) else r.getFrameAtTime(us, opt))
            ?: return null
        if (raw.width == w && raw.height == h) return raw
        val out = Bitmap.createScaledBitmap(raw, w, h, true)
        if (out !== raw) raw.recycle()
        return out
    }

    @Synchronized
    fun close() {
        runCatching { mmr?.release() }
        mmr = null
    }
}

/**
 * ตัวถอดรหัสวิดีโอแบบสตรีม (MediaExtractor + MediaCodec) สำหรับเล่นพรีวิวบนจอให้ลื่นโดยไม่ต้องรอเตรียม
 * ถอดเฟรมต่อเนื่องไปข้างหน้าด้วยฮาร์ดแวร์ในเธรดของตัวเอง เก็บเฟรมที่ถอดแล้วไว้ในคิวสั้น ๆ
 * (ต่างจาก MediaMetadataRetriever ที่ต้องเลื่อนหาตำแหน่งและถอดรหัสใหม่ทุกเฟรม)
 * เรียก ensure / frameFor / close จากเธรดเดียว (เธรดหลักของ UI) · ถ้าถอดไม่ได้ failed = true ให้ผู้เรียกใช้วิธีเดิมแทน
 */
class VideoStream(private val file: File, private val outW: Int, private val outH: Int) {
    private class Frame(val gen: Int, val ptsUs: Long, val bmp: Bitmap)

    private val queue = LinkedBlockingDeque<Frame>(CAP)
    @Volatile private var gen = 0
    @Volatile private var closed = false
    @Volatile var failed = false
        private set
    @Volatile private var thread: Thread? = null
    @Volatile private var startUs = 0L
    @Volatile private var wantUs = 0L
    @Volatile private var lastProducedUs = -1L
    @Volatile private var lastStartNs = 0L

    /** บอกเวลาที่ต้องการแสดง (วินาทีในไฟล์) · เวลาต่อเนื่องจากที่ถอดอยู่แล้ว = ไม่ทำอะไร · กระโดดไกล/ย้อนกลับ = เริ่มถอดใหม่จากจุดนั้น */
    fun ensure(sec: Float) {
        if (closed || failed) return
        val us = (sec * 1_000_000f).toLong()
        wantUs = us
        val th = thread
        val now = System.nanoTime()
        if (th != null && lastProducedUs < 0 && now - lastStartNs > 3_000_000_000L) { failed = true; return } // 3 วินาทีแล้วยังไม่มีเฟรมเลย = ใช้ไม่ได้
        val restart = when {
            th == null -> true
            now - lastStartNs < 250_000_000L -> false // กันเริ่มใหม่ถี่เกินไปตอนลากเส้นแดง
            us < startUs - 200_000L -> true
            lastProducedUs < 0 -> Math.abs(us - startUs) > 1_000_000L
            us > lastProducedUs + 1_000_000L -> true
            !th.isAlive && us < lastProducedUs - 150_000L -> true
            else -> false
        }
        if (restart) start(us)
    }

    /** เฟรมล่าสุดที่เวลาแสดง ≤ sec คืน (เวลาเฟรมเป็นไมโครวินาที, ภาพ) · null = ยังไม่มี หรือเก่ากว่า 0.5 วินาที */
    fun frameFor(sec: Float): Pair<Long, Bitmap>? {
        if (closed || failed) return null
        val us = (sec * 1_000_000f).toLong()
        val g = gen
        while (true) { val h = queue.peekFirst() ?: break; if (h.gen == g) break; queue.pollFirst() } // ทิ้งเฟรมของรอบเก่า
        var best: Frame? = null
        for (f in queue.toTypedArray()) {
            if (f.gen != g) continue
            if (f.ptsUs <= us + 20_000L) best = f else break
        }
        val b = best ?: return null
        while (true) { val h = queue.peekFirst() ?: break; if (h === b) break; queue.pollFirst() } // ทิ้งเฟรมที่เก่ากว่าเฟรมที่ใช้
        return if (b.ptsUs < us - 500_000L) null else b.ptsUs to b.bmp
    }

    fun close() {
        closed = true
        gen++
        queue.clear()
    }

    private fun start(us: Long) {
        gen++
        val g = gen
        startUs = us
        wantUs = us
        lastProducedUs = -1L
        lastStartNs = System.nanoTime()
        queue.clear()
        thread = Thread({
            try {
                decodeLoop(us, g)
            } catch (e: Throwable) {
                if (gen == g && !closed) failed = true
            }
        }, "VideoStream").apply { isDaemon = true; start() }
    }

    private fun decodeLoop(startUs: Long, g: Int) {
        val ex = MediaExtractor()
        var codec: MediaCodec? = null
        try {
            ex.setDataSource(file.absolutePath)
            var track = -1
            var fmt: MediaFormat? = null
            for (i in 0 until ex.trackCount) {
                val f = ex.getTrackFormat(i)
                if ((f.getString(MediaFormat.KEY_MIME) ?: "").startsWith("video/")) { track = i; fmt = f; break }
            }
            if (track < 0 || fmt == null) throw IOException("ไม่พบแทร็กวิดีโอ")
            ex.selectTrack(track)
            val mime = fmt.getString(MediaFormat.KEY_MIME) ?: throw IOException("ไม่ทราบชนิดวิดีโอ")
            val rot = if (fmt.containsKey(MediaFormat.KEY_ROTATION)) fmt.getInteger(MediaFormat.KEY_ROTATION) else 0
            val big = maxOf(fmt.getInteger(MediaFormat.KEY_WIDTH), fmt.getInteger(MediaFormat.KEY_HEIGHT)) >= 1280
            val std = if (fmt.containsKey(MediaFormat.KEY_COLOR_STANDARD)) fmt.getInteger(MediaFormat.KEY_COLOR_STANDARD) else 0
            val is709 = when (std) { MediaFormat.COLOR_STANDARD_BT709, MediaFormat.COLOR_STANDARD_BT2020 -> true; 0 -> big; else -> false }
            val fullRange = fmt.containsKey(MediaFormat.KEY_COLOR_RANGE) && fmt.getInteger(MediaFormat.KEY_COLOR_RANGE) == MediaFormat.COLOR_RANGE_FULL
            fmt.setInteger(MediaFormat.KEY_COLOR_FORMAT, MediaCodecInfo.CodecCapabilities.COLOR_FormatYUV420Flexible)
            val dec = MediaCodec.createDecoderByType(mime)
            codec = dec
            dec.configure(fmt, null, null, 0)
            dec.start()
            ex.seekTo(startUs, MediaExtractor.SEEK_TO_PREVIOUS_SYNC)

            val info = MediaCodec.BufferInfo()
            var inputDone = false
            var outputDone = false
            while (!outputDone && gen == g && !closed) {
                if (!inputDone) {
                    val ii = dec.dequeueInputBuffer(5_000)
                    if (ii >= 0) {
                        val buf = dec.getInputBuffer(ii) ?: throw IOException("ไม่มีบัฟเฟอร์รับข้อมูล")
                        val n = ex.readSampleData(buf, 0)
                        if (n < 0) {
                            dec.queueInputBuffer(ii, 0, 0, 0L, MediaCodec.BUFFER_FLAG_END_OF_STREAM)
                            inputDone = true
                        } else {
                            dec.queueInputBuffer(ii, 0, n, ex.sampleTime, 0)
                            ex.advance()
                        }
                    }
                }
                val oi = dec.dequeueOutputBuffer(info, 5_000)
                if (oi >= 0) {
                    val eos = (info.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0
                    val pts = info.presentationTimeUs
                    // ข้ามเฟรมที่อยู่ก่อนจุดเริ่ม (ไล่ถอดจากคีย์เฟรม) และเฟรมที่ช้ากว่าเวลาที่ต้องการแล้ว (ตามให้ทัน ไม่แปลงสี)
                    val skip = pts < startUs - 60_000L || pts + 120_000L < wantUs
                    if (info.size > 0 && !skip) {
                        val img = dec.getOutputImage(oi) ?: throw IOException("ตัวถอดรหัสไม่ให้ภาพ YUV")
                        val bmp = try { yuvToBitmap(img, rot, fullRange, is709, outW, outH) } finally { img.close() }
                        var queued = false
                        while (gen == g && !closed) {
                            if (queue.offer(Frame(g, pts, bmp), 50, TimeUnit.MILLISECONDS)) { queued = true; break }
                        }
                        if (queued) lastProducedUs = pts
                    }
                    dec.releaseOutputBuffer(oi, false)
                    if (eos) outputDone = true
                }
            }
        } finally {
            runCatching { codec?.stop() }
            runCatching { codec?.release() }
            runCatching { ex.release() }
        }
    }

    private companion object {
        const val CAP = 6
    }
}

/**
 * แปลงภาพ YUV_420_888 จากตัวถอดรหัสเป็น Bitmap ขนาด outW×outH พร้อมหมุนตามมุม rot (องศาตามเข็มที่ต้องหมุนเพื่อแสดง)
 * ย่อ/ขยายแบบจุดใกล้สุด · ใช้ค่าสัมประสิทธิ์สี BT.709 หรือ BT.601 ตามที่ระบุ (ช่วง limited หรือ full)
 */
private fun yuvToBitmap(img: Image, rot: Int, fullRange: Boolean, is709: Boolean, outW: Int, outH: Int): Bitmap {
    val crop = img.cropRect
    val cl = crop.left
    val ct = crop.top
    val sw = crop.width()
    val sh = crop.height()
    val planes = img.planes
    val yBuf = ByteArray(planes[0].buffer.remaining()).also { planes[0].buffer.get(it) }
    val uBuf = ByteArray(planes[1].buffer.remaining()).also { planes[1].buffer.get(it) }
    val vBuf = ByteArray(planes[2].buffer.remaining()).also { planes[2].buffer.get(it) }
    val yRow = planes[0].rowStride
    val yPix = planes[0].pixelStride
    val uRow = planes[1].rowStride
    val uPix = planes[1].pixelStride
    val vRow = planes[2].rowStride
    val vPix = planes[2].pixelStride
    val turned = rot == 90 || rot == 270
    val dispW = if (turned) sh else sw
    val dispH = if (turned) sw else sh
    // ค่าสัมประสิทธิ์ ×1024: rV, gU, gV, bU
    val rV: Int; val gU: Int; val gV: Int; val bU: Int
    if (is709) {
        if (fullRange) { rV = 1613; gU = 192; gV = 479; bU = 1900 } else { rV = 1836; gU = 218; gV = 546; bU = 2163 }
    } else {
        if (fullRange) { rV = 1436; gU = 352; gV = 731; bU = 1815 } else { rV = 1634; gU = 401; gV = 832; bU = 2066 }
    }
    val out = IntArray(outW * outH)
    var o = 0
    for (dy in 0 until outH) {
        val v = dy * dispH / outH
        for (dx in 0 until outW) {
            val u = dx * dispW / outW
            val sx: Int
            val sy: Int
            when (rot) {
                90 -> { sx = v; sy = sh - 1 - u }
                180 -> { sx = sw - 1 - u; sy = sh - 1 - v }
                270 -> { sx = sw - 1 - v; sy = u }
                else -> { sx = u; sy = v }
            }
            val px = cl + sx
            val py = ct + sy
            val yv = yBuf[py * yRow + px * yPix].toInt() and 0xFF
            val uv = (uBuf[(py shr 1) * uRow + (px shr 1) * uPix].toInt() and 0xFF) - 128
            val vv = (vBuf[(py shr 1) * vRow + (px shr 1) * vPix].toInt() and 0xFF) - 128
            val c = if (fullRange) yv * 1024 else (yv - 16) * 1192
            var r = (c + rV * vv) shr 10
            var g = (c - gU * uv - gV * vv) shr 10
            var b = (c + bU * uv) shr 10
            if (r < 0) r = 0 else if (r > 255) r = 255
            if (g < 0) g = 0 else if (g > 255) g = 255
            if (b < 0) b = 0 else if (b > 255) b = 255
            out[o++] = (0xFF shl 24) or (r shl 16) or (g shl 8) or b
        }
    }
    return Bitmap.createBitmap(out, outW, outH, Bitmap.Config.ARGB_8888)
}
