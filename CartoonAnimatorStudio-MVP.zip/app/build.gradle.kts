plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    id("org.jetbrains.kotlin.plugin.compose")
}

android {
    namespace = "com.nop.cartoonstudio"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.nop.cartoonstudio"
        minSdk = 26
        targetSdk = 34
        // versionCode ต้องเพิ่มขึ้นทุก build ไม่งั้น Android ไม่ยอมติดตั้งทับ (มองเป็นการลดเวอร์ชัน) จึงใช้ "นาทีนับจากปี 1970" ซึ่งเพิ่มขึ้นเสมอ
        // ไม่พึ่งว่า workflow จะส่งเลข build มาหรือไม่
        versionCode = (System.currentTimeMillis() / 60_000L).toInt()
        versionName = "0.9.1-advanced-warp-studio"
        // ใช้ในปุ่ม "อัปเดตแอป": รูปแบบ owner/repo ส่งมาจาก GitHub Actions (-PupdateRepo=...)
        // ถ้า workflow ไม่ได้ส่ง -PupdateRepo มา ใช้ GITHUB_REPOSITORY ที่ GitHub Actions ตั้งให้อัตโนมัติ
        buildConfigField("String", "UPDATE_REPO", "\"${project.findProperty("updateRepo") ?: System.getenv("GITHUB_REPOSITORY") ?: ""}\"")
        // เวลาที่ build แอปนี้ (มิลลิวินาที) ใช้เทียบว่า APK บน Release ใหม่กว่าตัวที่ติดตั้งอยู่ไหม (ไม่พึ่งเวลาที่ผู้ใช้กดติดตั้ง)
        buildConfigField("long", "BUILD_TIME", "${System.currentTimeMillis()}L")
    }

    // ลายเซ็น debug คงที่ (ไฟล์ debug.keystore) เพื่อให้ติดตั้งทับเวอร์ชันเก่าได้ทุกรอบ build
    signingConfigs {
        getByName("debug") {
            storeFile = file("debug.keystore")
            storePassword = "android"
            keyAlias = "androiddebugkey"
            keyPassword = "android"
        }
    }

    buildTypes {
        release { isMinifyEnabled = false }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
        isCoreLibraryDesugaringEnabled = true // NewPipeExtractor ใช้ API ของ Java 10+ (เช่น URLDecoder.decode แบบ Charset) ที่ Android ต่ำกว่า 13 ไม่มี
    }
    kotlinOptions { jvmTarget = "17" }
    packaging {
        resources { excludes += setOf("META-INF/DEPENDENCIES", "META-INF/LICENSE*", "META-INF/NOTICE*", "META-INF/INDEX.LIST") }
    }
    buildFeatures {
        compose = true
        buildConfig = true
    }
}

dependencies {
    implementation(platform("androidx.compose:compose-bom:2024.09.00"))
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.activity:activity-compose:1.9.2")
    implementation("androidx.lifecycle:lifecycle-viewmodel:2.8.5")
    implementation("androidx.compose.ui:ui")
    implementation("androidx.compose.foundation:foundation")
    implementation("androidx.compose.material3:material3")
    // โหลดเสียงจากลิงค์: NewPipeExtractor ดึงสตรีมเสียง YouTube (สัญญาอนุญาต GPL-3.0) + OkHttp เป็นตัวโหลด
    implementation("com.github.TeamNewPipe:NewPipeExtractor:v0.26.5")
    coreLibraryDesugaring("com.android.tools:desugar_jdk_libs_nio:2.1.5")
    implementation("com.squareup.okhttp3:okhttp:4.12.0")
}
