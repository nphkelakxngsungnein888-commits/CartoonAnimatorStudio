pluginManagement {
    repositories {
        google()
        mavenCentral()
        gradlePluginPortal()
    }
}
dependencyResolutionManagement {
    repositoriesMode.set(RepositoriesMode.FAIL_ON_PROJECT_REPOS)
    repositories {
        google()
        mavenCentral()
        maven("https://jitpack.io") // NewPipeExtractor (ใช้โหลดเสียงจากลิงค์ YouTube)
    }
}
rootProject.name = "CartoonAnimatorStudio"
include(":app")
