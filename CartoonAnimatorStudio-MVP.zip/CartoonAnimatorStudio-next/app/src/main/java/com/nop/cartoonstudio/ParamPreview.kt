package com.nop.cartoonstudio

import android.graphics.Bitmap
import android.graphics.Paint
import android.graphics.RectF
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.FloatState
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.clipToBounds
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.drawIntoCanvas
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlin.math.roundToInt

// ───────────────────────────────────────────────────────────────────────────────
//  คลังตัวอย่างค่า (Param Preview Library)
//  ทุกค่าที่ปรับได้ในเครื่องมือปั้น/บิดภาพ มีตัวอย่างวนสั้นๆ เทียบ น้อย | ค่าที่ตั้งอยู่ | มาก
//  ตัวอย่างสร้างด้วยเอนจินจริงของแอป (Sculpt.applyAdvancedWarp) บนภาพสาธิตขาว-ดำที่วาดด้วยโค้ด
//  ค่าใหม่ในอนาคต: เพิ่ม spec 1 บล็อกใน ParamPreviewRegistry.specs แล้วจะโผล่ในคลังเอง
//  ถ้าเพิ่ม property ใหม่ใน WarpSettings แต่ยังไม่มี spec คลังจะแสดงรายชื่อใต้หัวข้อ "ยังไม่มีตัวอย่าง"
// ───────────────────────────────────────────────────────────────────────────────

private val PvBg = Color(0xFF000000)
private val PvInk = Color(0xFFFFFFFF)
private val PvSub = Color(0xFF9A9A9A)
private val PvLine = Color(0xFF3A3A3A)
private val PvChip = Color(0xFF1C1C1C)

/** ข้อมูลตัวอย่างของ 1 ค่า (1 ช่องกรอกในแอป) */
class ParamSpec(
    /** ป้ายเดียวกับช่องกรอกในแอปเป๊ะๆ (ใช้จับคู่กับ SculptNumField / SignedNumField) */
    val label: String,
    /** ชื่อ property ใน WarpSettings (ใช้ตรวจว่ามีค่าไหนยังไม่มีตัวอย่าง) */
    val field: String,
    val group: String,
    /** ค่า "น้อย" และ "มาก" ของตัวอย่าง (ผู้พัฒนากำหนดให้เห็นผลชัด ไม่จำเป็นต้องเท่าขอบเขตของช่องกรอก) */
    val lo: Float,
    val hi: Float,
    val unit: String,
    val hint: String,
    val get: (WarpSettings) -> Float,
    val set: (WarpSettings, Float) -> WarpSettings,
    /** โหมดสาธิตสำรอง ใช้เมื่อเปิดจากคลัง หรือเครื่องมือที่เลือกไม่ใช่โหมดบิดขั้นสูง */
    val mode: AdvancedWarpMode? = null,
    /** true = ใช้โหมดของ spec เสมอ (ไม่ตามเครื่องมือที่เลือก) เพราะค่านี้เห็นผลเฉพาะบางโหมด */
    val forceMode: Boolean = false,
    val integer: Boolean = false,
    /** ตำแหน่งจุดวางพู่กันแนวนอน (0..1) */
    val cxFrac: Float = 0.5f,
    /** เริ่มจากตาข่ายที่ขรุขระ (ใช้กับค่าที่เกี่ยวกับการเกลี่ย/คลายตาข่าย) */
    val noisyStart: Boolean = false,
    /** ปรับค่าตั้งต้นของตัวอย่างให้เห็นผล (เช่นทำวงให้เป็นวงรีก่อนหมุน) พร้อมคำอธิบาย */
    val base: (WarpSettings) -> WarpSettings = { it },
    val baseNote: String = "",
)

/** บริบทเครื่องมือที่เลือกอยู่ (ตั้งค่าจากแผงปั้นภาพ) เพื่อให้ตัวอย่างใช้โหมดตรงกับเครื่องมือ */
object ParamDemoContext {
    @Volatile var mode: AdvancedWarpMode? = null
}

object ParamPreviewRegistry {
    private const val G_BRUSH = "แรงและขอบพู่กัน"
    private const val G_SHAPE = "ขนาดและมุมของวงพู่กัน"
    private const val G_WAVE = "คลื่นและกระเพื่อม"
    private const val G_PRESS = "แรงกดและจังหวะ"
    private const val G_SAFE = "ความปลอดภัยและการคลายตาข่าย"
    private const val G_MESH = "ความละเอียดตาข่าย"

    private fun scale(label: String, axisX: Boolean) = ParamSpec(
        label = label, field = if (axisX) "scaleX" else "scaleY", group = G_SHAPE,
        lo = 40f, hi = 250f, unit = "%",
        hint = if (axisX) "ยืด/หดวงพู่กันตามแนวนอน (ดูวงขาวบางๆ ในภาพ)" else "ยืด/หดวงพู่กันตามแนวตั้ง (ดูวงขาวบางๆ ในภาพ)",
        get = { if (axisX) it.scaleX else it.scaleY },
        set = { s, v -> if (axisX) s.copy(scaleX = v) else s.copy(scaleY = v) },
        mode = AdvancedWarpMode.BULGE,
    )

    private fun angle(
        label: String, hint: String, mode: AdvancedWarpMode, lo: Float = -90f, hi: Float = 90f,
        base: (WarpSettings) -> WarpSettings = { it }, baseNote: String = "",
    ) = ParamSpec(
        label = label, field = "angleDeg", group = G_SHAPE, lo = lo, hi = hi, unit = "°", hint = hint,
        get = { it.angleDeg }, set = { s, v -> s.copy(angleDeg = v) }, mode = mode, base = base, baseNote = baseNote,
    )

    private fun strength(label: String, lo: Float, hi: Float, hint: String, mode: AdvancedWarpMode, noisy: Boolean = false) = ParamSpec(
        label = label, field = "strength", group = G_BRUSH, lo = lo, hi = hi, unit = "%", hint = hint,
        get = { it.strength }, set = { s, v -> s.copy(strength = v) }, mode = mode, noisyStart = noisy,
    )

    val specs: List<ParamSpec> = listOf(
        // ── แรงและขอบพู่กัน ──
        strength("ความแรงการบิด (%)", 25f, 150f, "ยิ่งมาก ภาพยิ่งถูกดัน/บีบไกลจากจุดวางพู่กัน (ถูกจำกัดด้วยระยะบิดสูงสุด)", AdvancedWarpMode.BULGE),
        strength("ความแรงการเกลี่ย (%)", 10f, 100f, "เกลี่ยตาข่ายที่ขรุขระให้เรียบ ยิ่งมากยิ่งเรียบ (ภาพเริ่มจากตาข่ายขรุขระแล้วค่อยๆ เรียบ)", AdvancedWarpMode.SMOOTH, noisy = true),
        ParamSpec(
            label = "การลดแรงจากกลางสู่ขอบ (%)", field = "falloff", group = G_BRUSH, lo = 0f, hi = 100f, unit = "%",
            hint = "น้อย = แรงเกือบเท่ากันทั้งวง · มาก = แรงตกเร็วจากกลางวงไปขอบ",
            get = { it.falloff }, set = { s, v -> s.copy(falloff = v) }, mode = AdvancedWarpMode.BULGE,
        ),
        ParamSpec(
            label = "ความแข็งขอบพู่กัน (%)", field = "hardness", group = G_BRUSH, lo = 0f, hi = 95f, unit = "%",
            hint = "มาก = บริเวณกลางวงที่ได้แรงเต็มกว้างขึ้น ขอบวงชัดขึ้น",
            get = { it.hardness }, set = { s, v -> s.copy(hardness = v) }, mode = AdvancedWarpMode.BULGE,
        ),
        ParamSpec(
            label = "ความนุ่มของผลบิด (%)", field = "smoothness", group = G_BRUSH, lo = 0f, hi = 100f, unit = "%",
            hint = "มาก = การไล่แรงจากกลางสู่ขอบเนียนขึ้น (ผสมกับเส้นโค้งแบบนุ่ม)",
            get = { it.smoothness }, set = { s, v -> s.copy(smoothness = v) }, mode = AdvancedWarpMode.BULGE,
        ),

        // ── ขนาดและมุมของวงพู่กัน ──
        scale("ขนาดวงแนวนอน (%)", true), scale("ขนาดวงแนวตั้ง (%)", false),
        scale("สเกลแนวนอน (%)", true), scale("สเกลแนวตั้ง (%)", false),
        scale("ขนาดพู่กัน X (%)", true), scale("ขนาดพู่กัน Y (%)", false),
        angle(
            "หมุนวง (°)", "หมุนวงพู่กันที่เป็นวงรี", AdvancedWarpMode.BULGE,
            base = { it.copy(scaleX = 220f) }, baseNote = "ขนาดวงแนวนอนตั้งเป็น 220% เพื่อให้เห็นการหมุน",
        ),
        angle(
            "มุมพู่กัน (°)", "หมุนวงพู่กันที่เป็นวงรี", AdvancedWarpMode.BULGE,
            base = { it.copy(scaleX = 220f) }, baseNote = "ขนาดพู่กัน X ตั้งเป็น 220% เพื่อให้เห็นการหมุน",
        ),
        angle("มุมเกลียว (°)", "ค่าบวก/ลบ = เกลียวหมุนคนละทิศ ยิ่งมากยิ่งบิดมาก", AdvancedWarpMode.SPIRAL, lo = -240f, hi = 240f),
        angle("ทิศทาง (°)", "หมุนทิศทางของผล (แนวคลื่น / แนวเฉือน)", AdvancedWarpMode.WAVE),
        angle("ทิศทางหลัก (°)", "ทิศที่ผลักเพิ่มจากทิศที่ลาก", AdvancedWarpMode.PUSH),
        angle("มุมทิศทาง (°)", "ทิศทางของระนาบ (แบน) หรือทิศที่ผลัก (แรงโน้มถ่วง)", AdvancedWarpMode.GRAVITY),

        // ── คลื่นและกระเพื่อม ──
        ParamSpec(
            label = "ความถี่", field = "frequency", group = G_WAVE, lo = 1f, hi = 12f, unit = "",
            hint = "จำนวนรอบคลื่นในระยะหนึ่ง ยิ่งมากคลื่นยิ่งถี่",
            get = { it.frequency }, set = { s, v -> s.copy(frequency = v) }, mode = AdvancedWarpMode.WAVE,
        ),
        ParamSpec(
            label = "เฟส (°)", field = "phaseDeg", group = G_WAVE, lo = -180f, hi = 180f, unit = "°",
            hint = "เลื่อนตำแหน่งสันคลื่น (ไม่เปลี่ยนความถี่)",
            get = { it.phaseDeg }, set = { s, v -> s.copy(phaseDeg = v) }, mode = AdvancedWarpMode.WAVE,
        ),
        ParamSpec(
            label = "ความยาวคลื่น (px)", field = "wavelengthPx", group = G_WAVE, lo = 30f, hi = 200f, unit = "px",
            hint = "ระยะต่อ 1 รอบคลื่น น้อย = คลื่นแน่น · มาก = คลื่นกว้าง (ภาพสาธิตกว้าง 400 px)",
            get = { it.wavelengthPx }, set = { s, v -> s.copy(wavelengthPx = v) }, mode = AdvancedWarpMode.WAVE,
        ),

        // ── แรงกดและจังหวะ ──
        ParamSpec(
            label = "แรงกดจำลอง (%)", field = "pressure", group = G_PRESS, lo = 10f, hi = 100f, unit = "%",
            hint = "จำลองแรงกดนิ้ว ยิ่งมากผลยิ่งแรง", get = { it.pressure }, set = { s, v -> s.copy(pressure = v) }, mode = AdvancedWarpMode.BULGE,
        ),
        ParamSpec(
            label = "เส้นโค้งแรงกด", field = "pressureCurve", group = G_PRESS, lo = 0.25f, hi = 3f, unit = "",
            hint = "ปรับว่าแรงกดแปลงเป็นผลอย่างไร (มีผลเมื่อแรงกดจำลองน้อยกว่า 100%) น้อย = แรงขึ้น · มาก = เบาลง",
            get = { it.pressureCurve }, set = { s, v -> s.copy(pressureCurve = v) }, mode = AdvancedWarpMode.BULGE,
            base = { it.copy(pressure = 50f) }, baseNote = "แรงกดจำลองตั้งเป็น 50% เพื่อให้เห็นผลของเส้นโค้ง",
        ),
        ParamSpec(
            label = "ปริมาณผลต่อครั้ง (%)", field = "flow", group = G_PRESS, lo = 10f, hi = 100f, unit = "%",
            hint = "สัดส่วนของผลที่ใช้จริงต่อการลาก 1 ครั้ง", get = { it.flow }, set = { s, v -> s.copy(flow = v) }, mode = AdvancedWarpMode.BULGE,
        ),
        ParamSpec(
            label = "ความหนาแน่น (%)", field = "density", group = G_PRESS, lo = 10f, hi = 100f, unit = "%",
            hint = "คูณลดแรงรวมของพู่กัน ยิ่งมากผลยิ่งเต็ม", get = { it.density }, set = { s, v -> s.copy(density = v) }, mode = AdvancedWarpMode.BULGE,
        ),
        ParamSpec(
            label = "ความทึบ/แรงรวม (%)", field = "opacity", group = G_PRESS, lo = 10f, hi = 100f, unit = "%",
            hint = "คูณแรงรวมของพู่กันทั้งหมด", get = { it.opacity }, set = { s, v -> s.copy(opacity = v) }, mode = AdvancedWarpMode.BULGE,
        ),
        ParamSpec(
            label = "ระยะห่างจังหวะพู่กัน (%)", field = "spacing", group = G_PRESS, lo = 1f, hi = 100f, unit = "%",
            hint = "ตามโค้ดปัจจุบัน ค่านี้ลดแรงได้อย่างมากราว 20% เท่านั้น จึงเห็นต่างกันเล็กน้อย",
            get = { it.spacing }, set = { s, v -> s.copy(spacing = v) }, mode = AdvancedWarpMode.BULGE,
        ),
        ParamSpec(
            label = "ลดอาการมือสั่น (%)", field = "stabilizer", group = G_PRESS, lo = 0f, hi = 100f, unit = "%",
            hint = "ตามโค้ดปัจจุบัน ค่านี้ลดระยะที่ลากลง (ไม่ได้เกลี่ยเส้นทางลาก) ยิ่งมากการบิดยิ่งน้อย",
            get = { it.stabilizer }, set = { s, v -> s.copy(stabilizer = v) }, mode = AdvancedWarpMode.BULGE,
        ),

        // ── ความปลอดภัยและการคลายตาข่าย ──
        ParamSpec(
            label = "ระยะบิดสูงสุดที่แนะนำ (% รัศมี)", field = "maxDeformation", group = G_SAFE, lo = 10f, hi = 100f, unit = "%",
            hint = "เพดานระยะที่แต่ละจุดขยับได้ (เทียบกับรัศมีพู่กัน) น้อย = ถูกตัดเพดานเร็ว",
            get = { it.maxDeformation }, set = { s, v -> s.copy(maxDeformation = v) }, mode = AdvancedWarpMode.BULGE,
        ),
        ParamSpec(
            label = "ป้องกันขอบภาพ (%)", field = "edgeProtection", group = G_SAFE, lo = 0f, hi = 100f, unit = "%",
            hint = "ลดผลของพู่กันที่อยู่ใกล้ขอบภาพ มาก = ขอบภาพนิ่งขึ้น (วางพู่กันใกล้ขอบซ้าย)",
            get = { it.edgeProtection }, set = { s, v -> s.copy(edgeProtection = v) }, mode = AdvancedWarpMode.BULGE, cxFrac = 0.2f,
        ),
        ParamSpec(
            label = "ระยะจุดขั้นต่ำ (px)", field = "minPointDistance", group = G_SAFE, lo = 0f, hi = 18f, unit = "px",
            hint = "ห้ามจุดตาข่ายที่ติดกันเข้าใกล้กันเกินระยะนี้ (ตาข่ายสาธิตห่างกัน 20 px) ถ้าตั้งเท่าหรือเกินระยะเดิม ตามโค้ดจะไม่ขยับเลย",
            get = { it.minPointDistance }, set = { s, v -> s.copy(minPointDistance = v) }, mode = AdvancedWarpMode.PINCH, forceMode = true,
        ),
        ParamSpec(
            label = "คลายตาข่าย (%)", field = "meshSmoothing", group = G_SAFE, lo = 0f, hi = 100f, unit = "%",
            hint = "เกลี่ยจุดตาข่ายเข้าหาเพื่อนบ้านหลังบิด (ภาพเริ่มจากตาข่ายขรุขระ)",
            get = { it.meshSmoothing }, set = { s, v -> s.copy(meshSmoothing = v) }, mode = AdvancedWarpMode.PUSH, noisyStart = true,
        ),

        // ── ความละเอียดตาข่าย ──
        ParamSpec(
            label = "จำนวนช่องแนวนอน", field = "meshCols", group = G_MESH, lo = 4f, hi = 40f, unit = "ช่อง",
            hint = "น้อย = ตาข่ายหยาบ ขอบการบิดเป็นเหลี่ยม · มาก = เนียนแต่ใช้เครื่องมากขึ้น",
            get = { if (it.meshCols > 0) it.meshCols.toFloat() else ParamDemo.DEFAULT_CELLS.toFloat() },
            set = { s, v -> s.copy(meshCols = v.roundToInt()) }, mode = AdvancedWarpMode.BULGE, integer = true,
        ),
        ParamSpec(
            label = "จำนวนช่องแนวตั้ง", field = "meshRows", group = G_MESH, lo = 4f, hi = 40f, unit = "ช่อง",
            hint = "น้อย = ตาข่ายหยาบ ขอบการบิดเป็นเหลี่ยม · มาก = เนียนแต่ใช้เครื่องมากขึ้น",
            get = { if (it.meshRows > 0) it.meshRows.toFloat() else ParamDemo.DEFAULT_CELLS.toFloat() },
            set = { s, v -> s.copy(meshRows = v.roundToInt()) }, mode = AdvancedWarpMode.BULGE, integer = true,
        ),
    )

    private val byLabel: Map<String, ParamSpec> by lazy { specs.associateBy { it.label } }

    fun find(label: String): ParamSpec? = byLabel[label]

    /** property ของ WarpSettings ที่ยังไม่มี spec (ค่าใหม่ในอนาคตจะโผล่ที่นี่จนกว่าจะเพิ่มตัวอย่าง) */
    fun missingFields(): List<String> {
        val covered = specs.map { it.field }.toSet()
        return WarpSettings::class.java.declaredFields
            .filter { !it.isSynthetic && !java.lang.reflect.Modifier.isStatic(it.modifiers) }
            .map { it.name }
            .filter { it !in covered }
    }
}

/** เอนจินสร้างภาพตัวอย่าง: ใช้ Sculpt.applyAdvancedWarp ตัวจริงของแอป */
object ParamDemo {
    const val SIZE = 400
    const val DEFAULT_CELLS = 20
    const val LOOP_SEC = 1.8f

    val bitmap: Bitmap by lazy { buildBitmap() }

    private fun buildBitmap(): Bitmap {
        val bmp = Bitmap.createBitmap(SIZE, SIZE, Bitmap.Config.ARGB_8888)
        val c = android.graphics.Canvas(bmp)
        c.drawColor(android.graphics.Color.BLACK)
        val gridPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.STROKE; strokeWidth = 1.5f; color = android.graphics.Color.argb(90, 255, 255, 255)
        }
        for (i in 0..16) {
            val p = i * 25f
            c.drawLine(p, 0f, p, SIZE.toFloat(), gridPaint)
            c.drawLine(0f, p, SIZE.toFloat(), p, gridPaint)
        }
        val line = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.STROKE; strokeWidth = 6f; color = android.graphics.Color.WHITE; strokeCap = Paint.Cap.ROUND
        }
        val fill = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL; color = android.graphics.Color.WHITE }
        c.drawCircle(200f, 200f, 130f, line)
        line.strokeWidth = 2.5f
        c.drawCircle(200f, 200f, 185f, line)
        line.strokeWidth = 6f
        c.drawCircle(160f, 175f, 14f, fill)
        c.drawCircle(240f, 175f, 14f, fill)
        c.drawLine(200f, 190f, 194f, 225f, line)
        c.drawArc(RectF(140f, 200f, 260f, 290f), 20f, 140f, false, line)
        line.strokeWidth = 4f
        c.drawRect(3f, 3f, SIZE - 3f, SIZE - 3f, line)
        return bmp
    }

    /** ความคืบหน้าการลาก 0..1 ตามเฟสของลูป (ลากออก → ค้าง → คืนกลับ) */
    fun progress(phase: Float): Float {
        fun ss(x: Float): Float { val t = x.coerceIn(0f, 1f); return t * t * (3f - 2f * t) }
        return when {
            phase < 0.40f -> ss(phase / 0.40f)
            phase < 0.55f -> 1f
            phase < 0.95f -> 1f - ss((phase - 0.55f) / 0.40f)
            else -> 0f
        }
    }

    private fun noisyGrid(cols: Int, rows: Int): SculptGrid {
        val g = SculptGrid.zero(cols, rows)
        val off = g.off.copyOf()
        val rnd = java.util.Random(7L)
        val cell = SIZE.toFloat() / maxOf(cols, rows)
        var n = 0
        for (j in 0..rows) for (i in 0..cols) {
            val rx = rnd.nextFloat() - 0.5f
            val ry = rnd.nextFloat() - 0.5f
            if (i in 1 until cols && j in 1 until rows) {
                off[2 * n] = rx * cell * 0.7f
                off[2 * n + 1] = ry * cell * 0.7f
            }
            n++
        }
        return g.withOff(off)
    }

    /** ตาข่ายของตัวอย่างที่ความคืบหน้า p (คำนวณเหมือนแอปจริง: ลดระยะลากด้วย stabilizer แล้วส่งเข้า applyAdvancedWarp) */
    fun gridFor(s: WarpSettings, mode: AdvancedWarpMode, cxFrac: Float, noisy: Boolean, p: Float): SculptGrid {
        val cols = if (s.meshCols > 0) s.meshCols.coerceIn(4, 40) else DEFAULT_CELLS
        val rows = if (s.meshRows > 0) s.meshRows.coerceIn(4, 40) else DEFAULT_CELLS
        val start = if (noisy) noisyGrid(cols, rows) else SculptGrid.zero(cols, rows)
        val r = SIZE * 0.4f
        val cx = SIZE * cxFrac
        val cy = SIZE * 0.5f
        val keep = 1f - s.stabilizer.coerceIn(0f, 100f) / 100f * 0.85f
        val dx = r * 0.6f * keep
        val dy = r * 0.18f * keep
        return if (noisy) {
            val full = Sculpt.applyAdvancedWarp(SIZE, SIZE, start, cx, cy, r, mode, dx, dy, s)
            Sculpt.lerp(start, full, p) ?: full
        } else {
            Sculpt.applyAdvancedWarp(SIZE, SIZE, start, cx, cy, r, mode, dx * p, dy * p, s)
        }
    }

    fun modeThai(m: AdvancedWarpMode): String = when (m) {
        AdvancedWarpMode.PINCH -> "บีบเข้า"
        AdvancedWarpMode.BULGE -> "ดันนูน"
        AdvancedWarpMode.SPIRAL -> "เกลียว"
        AdvancedWarpMode.WAVE -> "คลื่น"
        AdvancedWarpMode.SHEAR -> "เฉือน"
        AdvancedWarpMode.PERSPECTIVE -> "มุมมอง"
        AdvancedWarpMode.RIPPLE -> "กระเพื่อม"
        AdvancedWarpMode.PUSH -> "ผลัก"
        AdvancedWarpMode.INFLATE -> "พอง"
        AdvancedWarpMode.DEFLATE -> "ยุบ"
        AdvancedWarpMode.SMOOTH -> "เกลี่ย"
        AdvancedWarpMode.FLATTEN -> "แบน"
        AdvancedWarpMode.CREASE -> "รอยพับ"
        AdvancedWarpMode.GRAVITY -> "แรงโน้มถ่วง"
        AdvancedWarpMode.ELASTIC -> "ยืดหยุ่น"
        AdvancedWarpMode.MAGNET -> "แม่เหล็ก"
        else -> m.name
    }
}

private fun fmtParam(v: Float, integer: Boolean): String =
    if (integer) v.roundToInt().toString()
    else String.format(java.util.Locale.US, "%.2f", v).trimEnd('0').trimEnd('.')

/** นาฬิกาของตัวอย่าง: อัปเดตประมาณ 30 ครั้ง/วินาที (เฉพาะตอนแผงเปิดอยู่) */
@Composable
private fun rememberDemoPhase(): FloatState {
    val phase = remember { mutableFloatStateOf(0f) }
    LaunchedEffect(Unit) {
        val begin = androidx.compose.runtime.withFrameNanos { it }
        var last = 0L
        while (true) {
            androidx.compose.runtime.withFrameNanos { now ->
                if (now - last > 33_000_000L) {
                    last = now
                    val sec = (now - begin) / 1_000_000_000.0
                    phase.floatValue = ((sec % ParamDemo.LOOP_SEC) / ParamDemo.LOOP_SEC).toFloat()
                }
            }
        }
    }
    return phase
}

@Composable
private fun DemoPanel(s: WarpSettings, mode: AdvancedWarpMode, spec: ParamSpec, phase: FloatState, modifier: Modifier) {
    val q = (ParamDemo.progress(phase.floatValue) * 40f).roundToInt()
    // โหมดเกลี่ยบนตาข่ายเรียบไม่เห็นผล จึงเริ่มจากตาข่ายขรุขระเสมอ
    val noisy = spec.noisyStart || mode == AdvancedWarpMode.SMOOTH
    val grid = remember(s, mode, spec, noisy, q) { ParamDemo.gridFor(s, mode, spec.cxFrac, noisy, q / 40f) }
    val paint = remember { Paint(Paint.ANTI_ALIAS_FLAG).apply { isFilterBitmap = true } }
    val ring = remember {
        Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; color = android.graphics.Color.argb(150, 255, 255, 255) }
    }
    Canvas(modifier.clipToBounds().background(PvBg).border(1.dp, PvLine)) {
        val sc = size.width / ParamDemo.SIZE
        drawIntoCanvas { cv ->
            val n = cv.nativeCanvas
            n.save()
            n.scale(sc, sc)
            Sculpt.drawMesh(n, ParamDemo.bitmap, grid, paint)
            // วงขาวบางๆ = ขอบเขตพู่กัน (หมุน/ยืดตามค่าขนาดและมุม)
            ring.strokeWidth = 1.5f / sc
            n.save()
            n.translate(ParamDemo.SIZE * spec.cxFrac, ParamDemo.SIZE * 0.5f)
            n.rotate(s.angleDeg)
            n.scale((s.scaleX / 100f).coerceIn(0.1f, 4f), (s.scaleY / 100f).coerceIn(0.1f, 4f))
            n.drawCircle(0f, 0f, ParamDemo.SIZE * 0.4f, ring)
            n.restore()
            n.restore()
        }
    }
}

@Composable
private fun PvButton(text: String, primary: Boolean, modifier: Modifier = Modifier, onClick: () -> Unit) {
    Box(
        modifier.clip(RoundedCornerShape(50))
            .background(if (primary) PvInk else PvChip)
            .border(1.dp, PvLine, RoundedCornerShape(50))
            .clickable(onClick = onClick).padding(horizontal = 16.dp, vertical = 10.dp),
        contentAlignment = Alignment.Center,
    ) { Text(text, color = if (primary) PvBg else PvInk, fontSize = 14.sp, fontWeight = FontWeight.SemiBold) }
}

/** ปุ่มเล็ก ▶ ข้างป้ายของช่องกรอก เปิดตัวอย่างของค่านั้น */
@Composable
fun ParamPreviewButton(onClick: () -> Unit) {
    Box(
        Modifier.clip(RoundedCornerShape(50)).background(Color(0xFF2A2A2A)).clickable(onClick = onClick)
            .padding(horizontal = 5.dp, vertical = 2.dp),
        contentAlignment = Alignment.Center,
    ) { Text("▶", color = Color.White, fontSize = 8.sp) }
}

/**
 * แผงเลื่อนขึ้นแสดงตัวอย่างของ 1 ค่า
 * initial = ค่าที่ตั้งอยู่ตอนนี้ · localMode = โหมดของเครื่องมือที่เลือกอยู่ (null = ใช้โหมดสำรองของ spec)
 * onApply = null เมื่อเปิดจากคลัง (ดูอย่างเดียว ไม่มีปุ่ม "ใช้ค่านี้")
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ParamPreviewSheet(spec: ParamSpec, initial: Float, localMode: AdvancedWarpMode?, onApply: ((Float) -> Unit)?, onDismiss: () -> Unit) {
    val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)
    var value by remember { mutableFloatStateOf(initial) }
    val mode = if (spec.forceMode && spec.mode != null) spec.mode else (localMode ?: spec.mode ?: AdvancedWarpMode.BULGE)
    val phase = rememberDemoPhase()
    val base = remember(spec) { spec.base(WarpSettings()) }
    val loS = spec.set(base, spec.lo)
    val midS = spec.set(base, value)
    val hiS = spec.set(base, spec.hi)
    ModalBottomSheet(onDismissRequest = onDismiss, sheetState = sheetState, containerColor = PvBg, contentColor = PvInk) {
        Column(
            Modifier.fillMaxWidth().verticalScroll(rememberScrollState()).padding(horizontal = 16.dp).padding(bottom = 28.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp),
        ) {
            Text(spec.label, color = PvInk, fontSize = 17.sp, fontWeight = FontWeight.Bold)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    DemoPanel(loS, mode, spec, phase, Modifier.fillMaxWidth().aspectRatio(1f))
                    Text("น้อย", color = PvSub, fontSize = 11.sp)
                    Text(fmtParam(spec.lo, spec.integer) + spec.unit, color = PvInk, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
                }
                Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    DemoPanel(midS, mode, spec, phase, Modifier.fillMaxWidth().aspectRatio(1f))
                    Text("ค่าที่ตั้งอยู่", color = PvSub, fontSize = 11.sp)
                    Text(fmtParam(value, spec.integer) + spec.unit, color = PvInk, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
                }
                Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    DemoPanel(hiS, mode, spec, phase, Modifier.fillMaxWidth().aspectRatio(1f))
                    Text("มาก", color = PvSub, fontSize = 11.sp)
                    Text(fmtParam(spec.hi, spec.integer) + spec.unit, color = PvInk, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
                }
            }
            Slider(
                value = value.coerceIn(spec.lo, spec.hi),
                onValueChange = { value = if (spec.integer) it.roundToInt().toFloat() else it },
                valueRange = spec.lo..spec.hi,
                steps = if (spec.integer) ((spec.hi - spec.lo).toInt() - 1).coerceAtLeast(0) else 0,
                colors = SliderDefaults.colors(thumbColor = PvInk, activeTrackColor = PvInk, inactiveTrackColor = Color(0xFF444444)),
            )
            Text(spec.hint, color = PvInk, fontSize = 13.sp)
            val note = buildString {
                append("โหมดสาธิต: ").append(ParamDemo.modeThai(mode))
                append(" · ภาพสาธิต ${ParamDemo.SIZE}×${ParamDemo.SIZE} px · ค่าอื่นเป็นค่าเริ่มต้น")
                if (spec.baseNote.isNotEmpty()) append(" ยกเว้น: ").append(spec.baseNote)
                if (value < spec.lo || value > spec.hi) append(" · ค่าที่ตั้งอยู่เกินช่วงของแถบเลื่อน (แต่ภาพกลางใช้ค่าจริง)")
            }
            Text(note, color = PvSub, fontSize = 11.sp)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                if (onApply != null) PvButton("ใช้ค่านี้", primary = true, modifier = Modifier.weight(1f)) { onApply(value); onDismiss() }
                PvButton("ปิด", primary = false, modifier = Modifier.weight(1f)) { onDismiss() }
            }
        }
    }
}

/** หน้า "คลังตัวอย่างค่า": รวมทุกค่าที่มีตัวอย่าง แตะเพื่อเปิดดู */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ParamLibrarySheet(onDismiss: () -> Unit) {
    val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)
    var open by remember { mutableStateOf<ParamSpec?>(null) }
    val missing = remember { ParamPreviewRegistry.missingFields() }
    ModalBottomSheet(onDismissRequest = onDismiss, sheetState = sheetState, containerColor = PvBg, contentColor = PvInk) {
        Column(
            Modifier.fillMaxWidth().verticalScroll(rememberScrollState()).padding(horizontal = 16.dp).padding(bottom = 28.dp),
            verticalArrangement = Arrangement.spacedBy(6.dp),
        ) {
            Text("คลังตัวอย่างค่า", color = PvInk, fontSize = 18.sp, fontWeight = FontWeight.Bold)
            Text("แตะค่าที่ต้องการเพื่อดูตัวอย่างเทียบ น้อย | ตอนนี้ | มาก (${ParamPreviewRegistry.specs.size} รายการ)", color = PvSub, fontSize = 12.sp)
            ParamPreviewRegistry.specs.groupBy { it.group }.forEach { (group, list) ->
                Text(group, color = PvInk, fontSize = 13.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.padding(top = 10.dp))
                list.forEach { spec ->
                    Row(
                        Modifier.fillMaxWidth().clip(RoundedCornerShape(10.dp)).background(PvChip)
                            .clickable { open = spec }.padding(horizontal = 12.dp, vertical = 11.dp),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Text(spec.label, color = PvInk, fontSize = 14.sp, modifier = Modifier.weight(1f))
                        Text("▶", color = PvSub, fontSize = 11.sp)
                    }
                }
            }
            if (missing.isNotEmpty()) {
                Text("ยังไม่มีตัวอย่าง (ค่าใหม่จะโผล่ที่นี่จนกว่าจะเพิ่มตัวอย่าง)", color = PvInk, fontSize = 13.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.padding(top = 14.dp))
                Text(missing.joinToString(", "), color = PvSub, fontSize = 11.sp)
            }
        }
    }
    open?.let { spec ->
        ParamPreviewSheet(spec, spec.get(WarpSettings()), null, null) { open = null }
    }
}
