package com.nop.cartoonstudio

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.InputStream
import java.util.UUID

/** Persistent storage for Image Studio projects. Each project owns copies of its source images. */
data class ImageStudioProject(
    val id: String,
    val name: String,
    val updatedAt: Long,
    val imageCount: Int,
)

data class ImageStudioKeyframeRecord(
    val time: Float, val x: Float, val y: Float, val scale: Float, val rotation: Float, val opacity: Float,
    val sculpt: SculptGrid? = null,
)

data class ImageStudioImageRecord(
    val id: Int,
    val fileName: String,
    val duration: Float,
    val x: Float = 0f,
    val y: Float = 0f,
    val scale: Float = 1f,
    val rotation: Float = 0f,
    val opacity: Float = 1f,
    val visible: Boolean = true,
    val startTime: Float = 0f,
    val keyframes: List<ImageStudioKeyframeRecord> = emptyList(),
    val name: String = "", val locked: Boolean = false, val layerId: Int = 1,
    val sculpt: SculptGrid? = null, val sizeLocked: Boolean = false,
    val videoLength: Float = 0f, // > 0 = คลิปวิดีโอ (ความยาวไฟล์ต้นฉบับ วินาที) · 0 = รูปภาพ
    val videoOffset: Float = 0f, // จุดเริ่มเล่นในไฟล์วิดีโอ (วินาที)
    val rig: PinRig = PinRig(), // หมุดข้อต่ออัจฉริยะของคลิป (ไม่มี = ไม่ใช้)
    val warpLayers: List<WarpLayer> = emptyList(),
    val physics: WarpPhysicsSettings = WarpPhysicsSettings(),
)

object ImageStudioProjectStore {
    private fun sculptToJson(g: SculptGrid): JSONObject = JSONObject().put("cols", g.cols).put("rows", g.rows)
        .put("off", JSONArray().apply { g.off.forEach { put(Math.round(it * 100f) / 100.0) } })
        .also { o ->
            g.xs?.let { xs -> o.put("xs", JSONArray().apply { xs.forEach { put(Math.round(it * 100000f) / 100000.0) } }) }
            g.ys?.let { ys -> o.put("ys", JSONArray().apply { ys.forEach { put(Math.round(it * 100000f) / 100000.0) } }) }
            g.pinAngles?.takeIf { pa -> pa.any { it != 0f } }?.let { pa -> o.put("pa", JSONArray().apply { pa.forEach { put(Math.round(it * 100f) / 100.0) } }) }
        }

    private fun breaksFromJson(arr: JSONArray?, n: Int): FloatArray? {
        if (arr == null || arr.length() != n + 1) return null
        val out = FloatArray(n + 1) { arr.optDouble(it, 0.0).toFloat() }
        // ต้องเรียงจากน้อยไปมาก เริ่ม 0 จบ 1 ไม่งั้นทิ้ง (ใช้ตาข่ายเว้นระยะเท่ากันแทน)
        for (i in 1..n) if (out[i] < out[i - 1]) return null
        return if (out[0] < -0.001f || out[n] > 1.001f) null else out
    }

    private fun sculptFromJson(o: JSONObject?): SculptGrid? {
        if (o == null) return null
        val cols = o.optInt("cols", 0)
        val rows = o.optInt("rows", 0)
        val arr = o.optJSONArray("off") ?: return null
        if (cols < 1 || rows < 1 || cols > 64 || rows > 64 || arr.length() != (cols + 1) * (rows + 1) * 2) return null
        val pa = o.optJSONArray("pa")?.let { a -> FloatArray(a.length().coerceAtMost(JointPins.MAX_PINS)) { a.optDouble(it, 0.0).toFloat() } }
        return SculptGrid(
            cols, rows, FloatArray(arr.length()) { arr.optDouble(it, 0.0).toFloat() },
            breaksFromJson(o.optJSONArray("xs"), cols), breaksFromJson(o.optJSONArray("ys"), rows), pa,
        )
    }

    private fun warpLayerToJson(layer: WarpLayer): JSONObject = JSONObject()
        .put("id", layer.id).put("name", layer.name).put("grid", sculptToJson(layer.grid))
        .put("opacity", layer.opacity.toDouble()).put("enabled", layer.enabled).put("blend", layer.blend.name).put("locked", layer.locked)
        .also { o -> layer.mask?.let { mask -> o.put("mask", JSONObject().put("cols", mask.cols).put("rows", mask.rows)
            .put("weights", JSONArray().apply { mask.weights.forEach { put(it.toDouble()) } })) } }

    private fun warpLayerFromJson(o: JSONObject?): WarpLayer? {
        if (o == null) return null
        val grid = sculptFromJson(o.optJSONObject("grid")) ?: return null
        val mask = o.optJSONObject("mask")?.let { m ->
            val cols = m.optInt("cols", grid.cols); val rows = m.optInt("rows", grid.rows)
            val a = m.optJSONArray("weights") ?: return@let null
            if (cols < 1 || rows < 1 || cols > 64 || rows > 64 || a.length() != (cols + 1) * (rows + 1)) null
            else WarpMask(cols, rows, FloatArray(a.length()) { a.optDouble(it, 1.0).toFloat().let { v -> if (v.isFinite()) v.coerceIn(0f,1f) else 0f } })
        }
        return WarpLayer(o.optLong("id", System.nanoTime()), o.optString("name", "ชั้นบิด"), grid, mask,
            o.optDouble("opacity", 1.0).toFloat().let { if (it.isFinite()) it.coerceIn(0f,1f) else 1f },
            o.optBoolean("enabled", true), runCatching { WarpBlendMode.valueOf(o.optString("blend", "ADD")) }.getOrDefault(WarpBlendMode.ADD),
            o.optBoolean("locked", false))
    }

    private fun physicsToJson(p: WarpPhysicsSettings): JSONObject = JSONObject()
        .put("enabled",p.enabled).put("gx",p.gravityX.toDouble()).put("gy",p.gravityY.toDouble())
        .put("mass",p.mass.toDouble()).put("stiffness",p.stiffness.toDouble()).put("damping",p.damping.toDouble())
        .put("elasticity",p.elasticity.toDouble()).put("spring",p.springStrength.toDouble()).put("bounce",p.bounce.toDouble())
        .put("drag",p.drag.toDouble()).put("wx",p.windX.toDouble()).put("wy",p.windY.toDouble())
        .put("collision",p.collision).put("recovery",p.recoverySpeed.toDouble()).put("maxStretch",p.maxStretch.toDouble())

    private fun physicsFromJson(o: JSONObject?): WarpPhysicsSettings = if (o == null) WarpPhysicsSettings() else WarpPhysicsSettings(
        enabled=o.optBoolean("enabled",false), gravityX=o.optDouble("gx",0.0).toFloat(), gravityY=o.optDouble("gy",980.0).toFloat(),
        mass=o.optDouble("mass",1.0).toFloat(), stiffness=o.optDouble("stiffness",180.0).toFloat(), damping=o.optDouble("damping",18.0).toFloat(),
        elasticity=o.optDouble("elasticity",0.35).toFloat(), springStrength=o.optDouble("spring",120.0).toFloat(), bounce=o.optDouble("bounce",0.2).toFloat(),
        drag=o.optDouble("drag",0.05).toFloat(), windX=o.optDouble("wx",0.0).toFloat(), windY=o.optDouble("wy",0.0).toFloat(),
        collision=o.optBoolean("collision",false), recoverySpeed=o.optDouble("recovery",5.0).toFloat(), maxStretch=o.optDouble("maxStretch",1.5).toFloat()
    )

    private fun rigToJson(r: PinRig): JSONObject = JSONObject().put("adaptive", r.adaptive).put("density", r.density.toDouble())
        .put("pins", JSONArray().apply {
            r.pins.forEach { p ->
                put(JSONObject().put("id", p.id).put("name", p.name).put("x", p.x.toDouble()).put("y", p.y.toDouble())
                    .put("dir", p.dirDeg.toDouble()).put("soft", p.soft.toDouble()).put("reach", p.reach.toDouble())
                    .put("meshR", p.meshRadius.toDouble()).put("parent", p.parentId)
                    .put("min", p.minDeg.toDouble()).put("max", p.maxDeg.toDouble()))
            }
        })

    private fun rigFromJson(o: JSONObject?): PinRig {
        if (o == null) return PinRig()
        val arr = o.optJSONArray("pins") ?: JSONArray()
        val pins = ArrayList<JointPin>()
        for (i in 0 until arr.length()) {
            if (pins.size >= JointPins.MAX_PINS) break
            val p = arr.optJSONObject(i) ?: continue
            val id = p.optInt("id", 0)
            if (id <= 0 || pins.any { it.id == id }) continue
            pins.add(JointPin(
                id = id, name = p.optString("name", ""),
                x = p.optDouble("x", 0.0).toFloat(), y = p.optDouble("y", 0.0).toFloat(),
                dirDeg = p.optDouble("dir", 0.0).toFloat(),
                soft = p.optDouble("soft", 45.0).toFloat().coerceIn(JointPins.SOFT_MIN, JointPins.SOFT_MAX),
                reach = p.optDouble("reach", 0.0).toFloat().coerceAtLeast(0f),
                meshRadius = p.optDouble("meshR", 0.0).toFloat().coerceAtLeast(0f),
                parentId = p.optInt("parent", 0),
                minDeg = p.optDouble("min", -180.0).toFloat().coerceIn(-180f, 180f),
                maxDeg = p.optDouble("max", 180.0).toFloat().coerceIn(-180f, 180f),
            ))
        }
        return PinRig(pins, o.optBoolean("adaptive", true), o.optDouble("density", 3.0).toFloat().coerceIn(0f, JointPins.DENSITY_MAX))
    }

    private const val MANIFEST = "project.json"
    private fun root(context: Context) = File(context.filesDir, "image_studio/projects").apply { mkdirs() }
    private fun directory(context: Context, id: String) = File(root(context), id)

    fun list(context: Context): List<ImageStudioProject> = root(context).listFiles()
        ?.filter { it.isDirectory }
        ?.mapNotNull { dir -> runCatching { readProject(dir) }.getOrNull() }
        ?.sortedByDescending { it.updatedAt }
        ?: emptyList()

    fun create(context: Context, name: String): ImageStudioProject {
        val id = UUID.randomUUID().toString()
        val dir = directory(context, id)
        check(dir.mkdirs()) { "ไม่สามารถสร้างโฟลเดอร์โปรเจกต์ได้" }
        File(dir, "images").mkdirs()
        val project = ImageStudioProject(id, name.trim().ifBlank { "โปรเจกต์ใหม่" }, System.currentTimeMillis(), 0)
        writeManifest(context, project, emptyList(), false, "เลื่อนภาพ")
        return project
    }

    fun delete(context: Context, id: String): Boolean = directory(context, id).deleteRecursively()

    fun importImage(context: Context, projectId: String, imageId: Int, sourceName: String, input: InputStream): File {
        val imageDir = File(directory(context, projectId), "images").apply { mkdirs() }
        val safeExt = sourceName.substringAfterLast('.', "img").lowercase().filter { it.isLetterOrDigit() }.take(8).ifBlank { "img" }
        val file = File(imageDir, "image_${imageId}.$safeExt")
        input.use { source -> file.outputStream().use { target -> source.copyTo(target) } }
        return file
    }

    fun loadSettings(context: Context, projectId: String): Pair<Boolean, String> {
        val json = JSONObject(File(directory(context, projectId), MANIFEST).readText())
        return json.optBoolean("animationMode", false) to json.optString("motionPreset", "เลื่อนภาพ")
    }

    /** ขนาดวิดีโอที่ตั้งไว้ในโปรเจกต์ (กว้าง, สูง) px: โปรเจกต์เก่าที่ไม่มีค่านี้ใช้ 720 x 720 */
    fun loadVideoSize(context: Context, projectId: String): Pair<Int, Int> {
        val json = JSONObject(File(directory(context, projectId), MANIFEST).readText())
        return json.optInt("videoWidth", 720).coerceIn(64, 1920) to json.optInt("videoHeight", 720).coerceIn(64, 1920)
    }

    /** อัตราเฟรมที่ตั้งไว้ (เฟรมต่อวินาที) ตั้งแต่ 1 ขึ้นไป ไม่มีเพดาน: โปรเจกต์เก่าที่ไม่มีค่านี้ใช้ 30 */
    fun loadVideoFps(context: Context, projectId: String): Int {
        val json = JSONObject(File(directory(context, projectId), MANIFEST).readText())
        return json.optInt("videoFps", 30).coerceAtLeast(1)
    }

    private fun warpSettingsFromJson(w: JSONObject?): WarpSettings {
        val d = WarpSettings()
        if (w == null) return d
        return d.copy(
            strength=w.optDouble("strength",d.strength.toDouble()).toFloat(), falloff=w.optDouble("falloff",d.falloff.toDouble()).toFloat(),
            hardness=w.optDouble("hardness",d.hardness.toDouble()).toFloat(), smoothness=w.optDouble("smoothness",d.smoothness.toDouble()).toFloat(),
            angleDeg=w.optDouble("angle",d.angleDeg.toDouble()).toFloat(), scaleX=w.optDouble("sx",d.scaleX.toDouble()).toFloat(), scaleY=w.optDouble("sy",d.scaleY.toDouble()).toFloat(),
            frequency=w.optDouble("frequency",d.frequency.toDouble()).toFloat(), phaseDeg=w.optDouble("phase",d.phaseDeg.toDouble()).toFloat(), wavelengthPx=w.optDouble("wavelength",d.wavelengthPx.toDouble()).toFloat(),
            waveType=w.optString("waveType",d.waveType), pressure=w.optDouble("pressure",d.pressure.toDouble()).toFloat(), pressureCurve=w.optDouble("pressureCurve",d.pressureCurve.toDouble()).toFloat(),
            flow=w.optDouble("flow",d.flow.toDouble()).toFloat(), density=w.optDouble("density",d.density.toDouble()).toFloat(), stabilizer=w.optDouble("stabilizer",d.stabilizer.toDouble()).toFloat(),
            spacing=w.optDouble("spacing",d.spacing.toDouble()).toFloat(), opacity=w.optDouble("opacity",d.opacity.toDouble()).toFloat(), maxDeformation=w.optDouble("maxDeformation",d.maxDeformation.toDouble()).toFloat(),
            edgeProtection=w.optDouble("edgeProtection",d.edgeProtection.toDouble()).toFloat(), minPointDistance=w.optDouble("minPointDistance",d.minPointDistance.toDouble()).toFloat(), meshSmoothing=w.optDouble("meshSmoothing",d.meshSmoothing.toDouble()).toFloat(),
            centerLock=w.optBoolean("centerLock",d.centerLock), symmetry=w.optBoolean("symmetry",d.symmetry), lockHorizontal=w.optBoolean("lockHorizontal",d.lockHorizontal), lockVertical=w.optBoolean("lockVertical",d.lockVertical),
            invert=w.optBoolean("invert",d.invert), accumulate=w.optBoolean("accumulate",d.accumulate), preserveBoundary=w.optBoolean("preserveBoundary",d.preserveBoundary), boundaryClamp=w.optBoolean("boundaryClamp",d.boundaryClamp),
            preventFolding=w.optBoolean("preventFolding",d.preventFolding), preventSelfIntersection=w.optBoolean("preventSelfIntersection",d.preventSelfIntersection), antiAliasing=w.optBoolean("antiAliasing",d.antiAliasing), highQualityPreview=w.optBoolean("highQualityPreview",d.highQualityPreview),
            autoKeyframe=w.optBoolean("autoKeyframe",d.autoKeyframe), followMotion=w.optBoolean("followMotion",d.followMotion), motionStrength=w.optDouble("motionStrength",d.motionStrength.toDouble()).toFloat(),
            interpolation=w.optString("interpolation",d.interpolation), loopDuration=w.optDouble("loopDuration",d.loopDuration.toDouble()).toFloat(), deformationDelay=w.optDouble("deformationDelay",d.deformationDelay.toDouble()).toFloat(),
            warpSpeed=w.optDouble("warpSpeed",d.warpSpeed.toDouble()).toFloat(), meshCols=w.optInt("meshCols",d.meshCols), meshRows=w.optInt("meshRows",d.meshRows),
        )
    }

    private fun warpSettingsToJson(s: WarpSettings): JSONObject = JSONObject()
        .put("strength",s.strength.toDouble()).put("falloff",s.falloff.toDouble()).put("hardness",s.hardness.toDouble()).put("smoothness",s.smoothness.toDouble())
        .put("angle",s.angleDeg.toDouble()).put("sx",s.scaleX.toDouble()).put("sy",s.scaleY.toDouble()).put("frequency",s.frequency.toDouble()).put("phase",s.phaseDeg.toDouble()).put("wavelength",s.wavelengthPx.toDouble()).put("waveType",s.waveType)
        .put("pressure",s.pressure.toDouble()).put("pressureCurve",s.pressureCurve.toDouble()).put("flow",s.flow.toDouble()).put("density",s.density.toDouble()).put("stabilizer",s.stabilizer.toDouble())
        .put("spacing",s.spacing.toDouble()).put("opacity",s.opacity.toDouble()).put("maxDeformation",s.maxDeformation.toDouble()).put("edgeProtection",s.edgeProtection.toDouble()).put("minPointDistance",s.minPointDistance.toDouble()).put("meshSmoothing",s.meshSmoothing.toDouble())
        .put("centerLock",s.centerLock).put("symmetry",s.symmetry).put("lockHorizontal",s.lockHorizontal).put("lockVertical",s.lockVertical).put("invert",s.invert).put("accumulate",s.accumulate)
        .put("preserveBoundary",s.preserveBoundary).put("boundaryClamp",s.boundaryClamp).put("preventFolding",s.preventFolding).put("preventSelfIntersection",s.preventSelfIntersection).put("antiAliasing",s.antiAliasing).put("highQualityPreview",s.highQualityPreview)
        .put("autoKeyframe",s.autoKeyframe).put("followMotion",s.followMotion).put("motionStrength",s.motionStrength.toDouble()).put("interpolation",s.interpolation).put("loopDuration",s.loopDuration.toDouble())
        .put("deformationDelay",s.deformationDelay.toDouble()).put("warpSpeed",s.warpSpeed.toDouble()).put("meshCols",s.meshCols).put("meshRows",s.meshRows)

    fun loadWarpWorkspace(context: Context, projectId: String): WarpWorkspaceSettings {
        val json = JSONObject(File(directory(context, projectId), MANIFEST).readText())
        val o = json.optJSONObject("warpWorkspace") ?: return WarpWorkspaceSettings()
        val settings = warpSettingsFromJson(o.optJSONObject("settings"))
        val cell = if (o.isNull("meshCell")) null else o.optDouble("meshCell", Double.NaN).toFloat().takeIf { it.isFinite() }
        val presetsJson = o.optJSONArray("customPresets") ?: JSONArray()
        val customPresets = (0 until presetsJson.length()).mapNotNull { i ->
            val preset = presetsJson.optJSONObject(i) ?: return@mapNotNull null
            WarpPreset(preset.optString("name", "พรีเซ็ตของฉัน"), preset.optString("description", "ชุดค่าที่บันทึกโดยผู้ใช้"), warpSettingsFromJson(preset.optJSONObject("settings")))
        }
        return WarpWorkspaceSettings(settings, o.optDouble("brushFraction",0.25).toFloat(), cell, o.optInt("meshRings",1), o.optDouble("twistDegrees",90.0).toFloat(), customPresets)
    }

    private fun warpWorkspaceToJson(workspace: WarpWorkspaceSettings): JSONObject {
        val settings = warpSettingsToJson(workspace.warp)
        val presets = JSONArray().apply { workspace.customPresets.forEach { preset ->
            put(JSONObject().put("name",preset.name).put("description",preset.description).put("settings",warpSettingsToJson(preset.settings)))
        } }
        return JSONObject().put("settings",settings).put("brushFraction",workspace.brushFraction.toDouble()).put("meshRings",workspace.meshRings).put("twistDegrees",workspace.twistDegrees.toDouble()).put("customPresets",presets)
            .also { if (workspace.meshCell == null) it.put("meshCell", JSONObject.NULL) else it.put("meshCell", workspace.meshCell!!.toDouble()) }
    }

    fun loadLayerIds(context: Context, projectId: String): List<Int> {
        val json = JSONObject(File(directory(context, projectId), MANIFEST).readText())
        val array = json.optJSONArray("layers") ?: JSONArray()
        return (0 until array.length()).mapNotNull { array.optInt(it, -1).takeIf { id -> id > 0 } }.distinct().sorted()
    }

    fun loadImages(context: Context, projectId: String): List<Pair<ImageStudioImageRecord, Bitmap>> {
        val dir = directory(context, projectId)
        val json = JSONObject(File(dir, MANIFEST).readText())
        val array = json.optJSONArray("images") ?: JSONArray()
        val result = mutableListOf<Pair<ImageStudioImageRecord, Bitmap>>()
        var legacyTimelineCursor = 0f
        for (i in 0 until array.length()) {
            val item = array.optJSONObject(i) ?: continue
            val duration = item.optDouble("duration", 3.0).toFloat().coerceIn(0.5f, 1_000_000f)
            val startTime = if (item.has("startTime")) item.optDouble("startTime", 0.0).toFloat().coerceIn(0f, 1_000_000f) else legacyTimelineCursor
            legacyTimelineCursor = maxOf(legacyTimelineCursor, startTime + duration)
            val keyArray = item.optJSONArray("keyframes") ?: JSONArray()
            val keyframes = (0 until keyArray.length()).mapNotNull { index ->
                val key = keyArray.optJSONObject(index) ?: return@mapNotNull null
                ImageStudioKeyframeRecord(
                    key.optDouble("time", 0.0).toFloat().coerceIn(0f, duration),
                    key.optDouble("x", 0.0).toFloat().coerceIn(-1500f, 1500f), // ช่วงเดียวกับตอนลากในแอป (transformClip)
                    key.optDouble("y", 0.0).toFloat().coerceIn(-1500f, 1500f),
                    key.optDouble("scale", 1.0).toFloat().coerceIn(0.1f, 8f),
                    key.optDouble("rotation", 0.0).toFloat().coerceIn(-180f, 180f),
                    key.optDouble("opacity", 1.0).toFloat().coerceIn(0f, 1f),
                    sculptFromJson(key.optJSONObject("sculpt")),
                )
            }.sortedBy { it.time }
            val record = ImageStudioImageRecord(
                item.optInt("id"), item.optString("fileName"), duration,
                item.optDouble("x", 0.0).toFloat(), item.optDouble("y", 0.0).toFloat(),
                item.optDouble("scale", 1.0).toFloat(), item.optDouble("rotation", 0.0).toFloat(),
                item.optDouble("opacity", 1.0).toFloat(), item.optBoolean("visible", true),
                startTime, keyframes, item.optString("name", ""), item.optBoolean("locked", false), item.optInt("layerId", 1).coerceAtLeast(1),
                sculptFromJson(item.optJSONObject("sculpt")), item.optBoolean("sizeLocked", false),
                item.optDouble("videoLength", 0.0).toFloat().coerceAtLeast(0f), item.optDouble("videoOffset", 0.0).toFloat().coerceAtLeast(0f),
                rigFromJson(item.optJSONObject("pinRig")),
                item.optJSONArray("warpLayers")?.let { a -> (0 until a.length()).mapNotNull { warpLayerFromJson(a.optJSONObject(it)) } } ?: emptyList(),
                physicsFromJson(item.optJSONObject("physics")),
            )
            val file = File(File(dir, "images"), record.fileName)
            if (!file.isFile) throw IllegalStateException("ไม่พบไฟล์ภาพ ${record.fileName}")
            if (record.videoLength > 0f) { // คลิปวิดีโอ: ภาพปกคือเฟรมที่จุดเริ่มเล่น
                val poster = runCatching { VideoFrames.probe(file, record.videoOffset).poster }.getOrNull()
                    ?: throw IllegalStateException("เปิดไฟล์วิดีโอ ${record.fileName} ไม่ได้")
                result += record to poster
                continue
            }
            val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            BitmapFactory.decodeFile(file.absolutePath, bounds)
            if (bounds.outWidth <= 0 || bounds.outHeight <= 0) throw IllegalStateException("ไฟล์ภาพ ${record.fileName} เสียหาย")
            var sample = 1
            while (maxOf(bounds.outWidth, bounds.outHeight) / sample > 1600) sample *= 2
            val bitmap = BitmapFactory.decodeFile(file.absolutePath, BitmapFactory.Options().apply { inSampleSize = sample })
                ?: throw IllegalStateException("ไม่สามารถถอดรหัสภาพ ${record.fileName} ได้")
            result += record to bitmap
        }
        return result
    }

    fun save(
        context: Context,
        projectId: String,
        images: List<ImageStudioImageRecord>,
        animationMode: Boolean,
        motionPreset: String,
        layerIds: List<Int> = images.map { it.layerId }.distinct(),
        videoWidth: Int = 720,
        videoHeight: Int = 720,
        videoFps: Int = 30,
        warpWorkspace: WarpWorkspaceSettings = WarpWorkspaceSettings(),
    ) {
        val old = runCatching { readProject(directory(context, projectId)) }.getOrNull()
        val project = ImageStudioProject(projectId, old?.name ?: "โปรเจกต์รูปภาพ", System.currentTimeMillis(), images.size)
        writeManifest(context, project, images, animationMode, motionPreset, layerIds, videoWidth, videoHeight, videoFps, warpWorkspace)
        val keep = images.map { it.fileName }.toSet()
        File(directory(context, projectId), "images").listFiles()?.forEach { file ->
            // ไฟล์ที่เพิ่งเขียน (เช่น วิดีโอที่กำลังคัดลอกเข้ามา ยังไม่เป็นคลิป) ห้ามลบ
            if (file.isFile && file.name !in keep && System.currentTimeMillis() - file.lastModified() > 60_000L) file.delete()
        }
    }

    private fun readProject(dir: File): ImageStudioProject {
        val json = JSONObject(File(dir, MANIFEST).readText())
        val images = json.optJSONArray("images") ?: JSONArray()
        return ImageStudioProject(
            json.getString("id"), json.optString("name", "โปรเจกต์รูปภาพ"),
            json.optLong("updatedAt", dir.lastModified()), images.length(),
        )
    }

    private fun writeManifest(
        context: Context,
        project: ImageStudioProject,
        images: List<ImageStudioImageRecord>,
        animationMode: Boolean,
        motionPreset: String,
        layerIds: List<Int> = images.map { it.layerId }.distinct(),
        videoWidth: Int = 720,
        videoHeight: Int = 720,
        videoFps: Int = 30,
        warpWorkspace: WarpWorkspaceSettings = WarpWorkspaceSettings(),
    ) {
        val array = JSONArray()
        images.forEach { item ->
            array.put(JSONObject().put("id", item.id).put("fileName", item.fileName).put("duration", item.duration.toDouble())
                .put("x", item.x.toDouble()).put("y", item.y.toDouble())
                .put("scale", item.scale.toDouble()).put("rotation", item.rotation.toDouble())
                .put("opacity", item.opacity.toDouble()).put("visible", item.visible)
                .put("startTime", item.startTime.toDouble()).put("name", item.name).put("locked", item.locked).put("layerId", item.layerId)
                .put("keyframes", JSONArray().apply { item.keyframes.forEach { key ->
                    put(JSONObject().put("time", key.time.toDouble()).put("x", key.x.toDouble()).put("y", key.y.toDouble())
                        .put("scale", key.scale.toDouble()).put("rotation", key.rotation.toDouble()).put("opacity", key.opacity.toDouble())
                        .also { o -> key.sculpt?.takeIf { !it.isZero() }?.let { o.put("sculpt", sculptToJson(it)) } })
                } })
                .put("sizeLocked", item.sizeLocked)
                .also { o -> if (item.videoLength > 0f) o.put("videoLength", item.videoLength.toDouble()).put("videoOffset", item.videoOffset.toDouble()) }
                .also { o -> item.sculpt?.takeIf { !it.isZero() }?.let { o.put("sculpt", sculptToJson(it)) } }
                .also { o -> if (item.rig.pins.isNotEmpty()) o.put("pinRig", rigToJson(item.rig)) }
                .also { o -> if (item.warpLayers.isNotEmpty()) o.put("warpLayers", JSONArray().apply { item.warpLayers.forEach { put(warpLayerToJson(it)) } }) }
                .also { o -> if (item.physics != WarpPhysicsSettings()) o.put("physics", physicsToJson(item.physics)) })
        }
        val json = JSONObject()
            .put("schemaVersion", 2)
            .put("id", project.id)
            .put("name", project.name)
            .put("updatedAt", System.currentTimeMillis())
            .put("animationMode", animationMode)
            .put("motionPreset", motionPreset)
            .put("videoWidth", videoWidth)
            .put("videoHeight", videoHeight)
            .put("videoFps", videoFps)
            .put("warpWorkspace", warpWorkspaceToJson(warpWorkspace))
            .put("layers", JSONArray().apply { layerIds.distinct().sorted().forEach { put(it) } })
            .put("images", array)
        val dir = directory(context, project.id)
        dir.mkdirs()
        val temp = File(dir, "$MANIFEST.tmp")
        temp.writeText(json.toString())
        val target = File(dir, MANIFEST)
        val backup = File(dir, "$MANIFEST.bak")
        if (backup.exists()) backup.delete()
        if (target.exists() && !target.renameTo(backup)) {
            temp.delete()
            throw IllegalStateException("ไม่สามารถสำรองข้อมูลโปรเจกต์เดิมได้")
        }
        if (!temp.renameTo(target)) {
            if (backup.exists()) backup.renameTo(target)
            temp.delete()
            throw IllegalStateException("ไม่สามารถบันทึกข้อมูลโปรเจกต์ได้")
        }
        backup.delete()
    }
}
